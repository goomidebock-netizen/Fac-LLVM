#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_release(void *object);
void *fac_obj_weak(void *object);
void fac_obj_weak_retain(void *weak);
void fac_obj_weak_release(void *weak);
int32_t fac_obj_weak_alive(void *weak);
}

int main(int argc, char **argv) {
  const uint64_t iterations = argc > 1 ? std::strtoull(argv[1], nullptr, 10) : 3000000ULL;
  constexpr int samples = 9;
  void *object = fac_obj_new(8, nullptr, nullptr, nullptr, nullptr);
  if (!object) return 2;
  void *weak = fac_obj_weak(object);
  if (!weak) { fac_obj_release(object); return 3; }

  volatile int32_t sink = 0;
  auto runAlive = [&](uint64_t count) {
    const auto start = std::chrono::steady_clock::now();
    for (uint64_t i = 0; i < count; ++i) sink += fac_obj_weak_alive(weak);
    const auto stop = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::nano>(stop - start).count() / static_cast<double>(count);
  };
  auto runRetainRelease = [&](uint64_t count) {
    const auto start = std::chrono::steady_clock::now();
    for (uint64_t i = 0; i < count; ++i) {
      fac_obj_weak_retain(weak);
      fac_obj_weak_release(weak);
    }
    const auto stop = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::nano>(stop - start).count() / static_cast<double>(count);
  };
  (void)runAlive(iterations / 4 + 1);
  (void)runRetainRelease(iterations / 4 + 1);
  std::vector<double> alive, retainRelease;
  alive.reserve(samples); retainRelease.reserve(samples);
  for (int i = 0; i < samples; ++i) {
    alive.push_back(runAlive(iterations));
    retainRelease.push_back(runRetainRelease(iterations));
  }
  std::sort(alive.begin(), alive.end());
  std::sort(retainRelease.begin(), retainRelease.end());
  std::printf("iterations=%llu samples=%d weak_alive_median_ns=%.2f weak_retain_release_pair_median_ns=%.2f sink=%d\n",
              static_cast<unsigned long long>(iterations), samples,
              alive[samples / 2], retainRelease[samples / 2], (int)sink);
  fac_obj_weak_release(weak);
  fac_obj_release(object);
  return 0;
}
