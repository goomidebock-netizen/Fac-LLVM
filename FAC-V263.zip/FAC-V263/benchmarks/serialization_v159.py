#!/usr/bin/env python3
"""Measure FAC binary-copy, frozen-buffer ByteView and JSON decode paths.

The FAC program checks that every path computes the same checksum. Reported
allocation counters cover FAC runtime-tracked allocations only, not STL/libc,
allocator metadata, or total process RSS.
"""
from __future__ import annotations

import argparse
import os
import pathlib
import re
import statistics
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT / "benchmarks" / "serialization_v159.fac"
LINE = re.compile(r"^(COPY|VIEW|JSON) ns=(\d+) allocs=(\d+) peak=(-?\d+) checksum=(\d+)$")


def run(cmd: list[str], *, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=False)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--facc", default=str(ROOT / "build" / "facc"))
    ap.add_argument("--runs", type=int, default=5)
    args = ap.parse_args()
    if args.runs < 3:
        ap.error("--runs must be at least 3 to report a median")

    with tempfile.TemporaryDirectory(prefix="fac-serialization-v159-") as tmp:
        binary = str(pathlib.Path(tmp) / "serialization-v159")
        cp = run([args.facc, str(SOURCE), "-O2", "-o", binary])
        if cp.returncode:
            print("compile failed:\n" + cp.stderr)
            return cp.returncode

        samples: dict[str, list[tuple[int, int, int]]] = {k: [] for k in ("COPY", "VIEW", "JSON")}
        checksums: dict[str, set[str]] = {k: set() for k in samples}
        for run_index in range(args.runs):
            result = run([binary])
            if result.returncode:
                print(f"run {run_index + 1} failed:\n{result.stderr}")
                return result.returncode
            seen: set[str] = set()
            for line in result.stdout.splitlines():
                match = LINE.match(line.strip())
                if not match:
                    continue
                name, ns, allocs, peak, checksum = match.groups()
                samples[name].append((int(ns), int(allocs), int(peak)))
                checksums[name].add(checksum)
                seen.add(name)
            if seen != set(samples):
                print(f"run {run_index + 1} did not return all benchmark cases:\n{result.stdout}")
                return 2

        if any(len(v) != args.runs for v in samples.values()) or len({next(iter(s)) for s in checksums.values()}) != 1:
            print("benchmark measurements or checksums are inconsistent")
            return 2

        medians = {name: tuple(statistics.median(row[i] for row in values) for i in range(3))
                   for name, values in samples.items()}
        print("FAC serialization benchmark — 64 KiB payload, 12 decode iterations per sample")
        print(f"Median of {args.runs} process runs; FAC allocator counters only (not total RSS).")
        print(f"{'path':<12} {'time (ms)':>12} {'allocations':>14} {'peak extra (KiB)':>18}")
        for name in ("COPY", "VIEW", "JSON"):
            ns, allocs, peak = medians[name]
            print(f"{name:<12} {ns / 1_000_000:>12.3f} {allocs:>14.0f} {peak / 1024:>18.2f}")
        copy_ns, view_ns, json_ns = medians["COPY"][0], medians["VIEW"][0], medians["JSON"][0]
        print(f"ByteView speedup vs readBytes: {copy_ns / view_ns:.2f}x")
        print(f"ByteView speedup vs JSON decode: {json_ns / view_ns:.2f}x")
        print(f"validated checksum: {next(iter(checksums['VIEW']))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
