#!/usr/bin/env python3
"""Measure FAC frontend memory retained when the LLVM backend is launched.

Linux-only probe: FAC_CC is replaced with a tiny helper that samples its
parent facc process via /proc/<pid>/status after frontend/codegen has finished.
The helper exits successfully without performing native code generation.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import statistics
import subprocess
import tempfile
import time


def parse_status(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for line in path.read_text(encoding="ascii").splitlines():
        fields = line.split()
        if len(fields) >= 2 and fields[0] in {"VmRSS:", "VmHWM:"}:
            values[fields[0][:-1]] = int(fields[1])
    return values


def generate_sources(root: Path, modules: int, functions: int) -> int:
    total = 0
    for module_index in range(modules):
        path = root / f"mod{module_index:03d}.fac"
        with path.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(f"module mod{module_index:03d}\n")
            for function_index in range(functions):
                body = (
                    f"public function int f{function_index:03d}(int x) "
                    f"{{ var int y = x + {function_index % 17 + 1}; "
                    f"var int z = y * {function_index % 7 + 2}; "
                    f"return z + {function_index % 13} }}\n"
                )
                stream.write(body)
        total += path.stat().st_size
    main = root / "main.fac"
    with main.open("w", encoding="utf-8", newline="\n") as stream:
        for module_index in range(modules):
            stream.write(f"import mod{module_index:03d}.fac\n")
        stream.write("public function void main() { }\n")
    total += main.stat().st_size
    return total


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("compiler", nargs="?", default="build/facc", help="path to facc (default: build/facc)")
    parser.add_argument("--modules", type=int, default=129)
    parser.add_argument("--functions", type=int, default=250, help="functions per imported module")
    parser.add_argument("--repeat", type=int, default=3)
    args = parser.parse_args()
    compiler = Path(args.compiler).resolve()
    if not compiler.is_file():
        parser.error(f"compiler not found: {compiler}")
    if not Path("/proc/self/status").is_file():
        parser.error("this memory probe requires Linux /proc")
    if args.modules < 1 or args.modules > 1000 or args.functions < 1 or args.functions > 2000 or args.repeat < 1 or args.repeat > 20:
        parser.error("use modules 1..1000, functions 1..2000 and repeat 1..20")

    with tempfile.TemporaryDirectory(prefix="fac-memory-") as tmp:
        root = Path(tmp)
        source_bytes = generate_sources(root, args.modules, args.functions)
        probe = root / "backend-probe"
        probe.write_text(
            "#!/bin/sh\n"
            "p=\"$PPID\"\n"
            "awk '/^(VmRSS|VmHWM):/ { print $1, $2, $3 }' \"/proc/$p/status\" > \"$FAC_MEMORY_PROBE\" 2>/dev/null || true\n"
            "exit 0\n",
            encoding="ascii",
        )
        probe.chmod(0o755)

        elapsed_ms: list[float] = []
        retained_rss_kb: list[int] = []
        peak_rss_kb: list[int] = []
        for index in range(args.repeat):
            sample = root / f"sample-{index}.txt"
            output = root / f"out-{index}"
            env = os.environ.copy()
            env["FAC_CC"] = str(probe)
            env["FAC_MEMORY_PROBE"] = str(sample)
            start = time.perf_counter()
            result = subprocess.run(
                [str(compiler), str(root / "main.fac"), "-O0", "-o", str(output)],
                cwd=root,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=False,
            )
            elapsed_ms.append((time.perf_counter() - start) * 1000.0)
            if result.returncode != 0:
                raise RuntimeError(
                    f"facc failed ({result.returncode}) on repetition {index + 1}:\n{result.stderr}"
                )
            if not sample.exists():
                raise RuntimeError("backend probe did not capture /proc/<facc-pid>/status")
            usage = parse_status(sample)
            if "VmRSS" not in usage or "VmHWM" not in usage:
                raise RuntimeError(f"incomplete /proc status sample: {sample.read_text()}")
            retained_rss_kb.append(usage["VmRSS"])
            peak_rss_kb.append(usage["VmHWM"])

        print(f"modules: {args.modules + 1} including main")
        print(f"functions: {args.modules * args.functions + 1} including main")
        print(f"source bytes: {source_bytes}")
        print(f"repetitions: {args.repeat}")
        print(f"median compile-to-backend: {statistics.median(elapsed_ms):.2f} ms")
        print(f"median RSS at backend launch: {statistics.median(retained_rss_kb):.0f} KiB")
        print(f"median process peak RSS: {statistics.median(peak_rss_kb):.0f} KiB")
        print("note: backend is a probe stub; this measures retained compiler memory before native backend work.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
