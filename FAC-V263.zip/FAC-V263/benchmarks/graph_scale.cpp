#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

extern "C" {
void *fac_g_new(int32_t, int32_t);
void fac_g_addnode(void *, const void *);
void fac_g_addarc2(void *, const void *, const void *);
int32_t fac_g_hasedge(void *, const void *, const void *);
void fac_ds_free(void *);
}

using Clock = std::chrono::steady_clock;
static volatile uint64_t sink = 0;

static double insertion_ms(int32_t count) {
  void *graph = fac_g_new(3, (int32_t)sizeof(int32_t));
  const auto start = Clock::now();
  for (int32_t i = 0; i < count; ++i) fac_g_addnode(graph, &i);
  const auto stop = Clock::now();
  fac_ds_free(graph);
  return std::chrono::duration<double, std::milli>(stop - start).count();
}

static double high_degree_ms(int32_t count, int32_t queries) {
  void *graph = fac_g_new(3, (int32_t)sizeof(int32_t));
  const int32_t center = -1;
  for (int32_t i = 0; i < count; ++i) fac_g_addarc2(graph, &center, &i);
  uint64_t hits = 0;
  const auto start = Clock::now();
  for (int32_t q = 0; q < queries; ++q) {
    const int32_t leaf = (q * 7919LL) % count;
    hits += (uint64_t)fac_g_hasedge(graph, &center, &leaf);
  }
  const auto stop = Clock::now();
  sink += hits;
  fac_ds_free(graph);
  return std::chrono::duration<double, std::milli>(stop - start).count();
}

static double median(std::vector<double> values) {
  std::sort(values.begin(), values.end());
  return values[values.size() / 2];
}

int main(int argc, char **argv) {
  const int32_t maxNodes = argc > 1 ? (int32_t)std::strtol(argv[1], nullptr, 10) : 100000;
  if (maxNodes < 100 || maxNodes > 1000000) return 2;
  std::puts("nodes,insert_median_ms,star_build_plus_lookup_median_ms,queries");
  for (int32_t count = 1000; count <= maxNodes; count *= 2) {
    std::vector<double> insert, star;
    for (int repeat = 0; repeat < 5; ++repeat) {
      insert.push_back(insertion_ms(count));
      star.push_back(high_degree_ms(count, count * 20));
    }
    std::printf("%d,%.3f,%.3f,%d\n", count, median(insert), median(star), count * 20);
    if (count > maxNodes / 2) break;
  }
  std::printf("checksum=%llu\n", (unsigned long long)sink);
  return sink ? 0 : 3;
}
