// FAC runtime memory profile for list capacity growth.
// Build: c++ -std=c++17 -O2 -pthread benchmarks/memory_profile.cpp build/fac_rt.o -ldl -o build/bench_memory_profile
// Run:   build/bench_memory_profile [element-count]
#include <cstdint>
#include <cstdio>
#include <chrono>
#include <cstdlib>

extern "C" {
struct FacList {
  void *data;
  int64_t len, cap;
  int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};
FacList *fac_list_new(int32_t, int32_t);
void fac_list_insert(FacList *, int64_t, const void *);
void fac_list_free(FacList *);
void fac_mem_start_tracking();
void fac_mem_reset_peak();
uint64_t fac_mem_used();
uint64_t fac_mem_peak();
uint64_t fac_mem_blocks();
uint64_t fac_mem_allocs();
uint64_t fac_mem_reallocs();
uint64_t fac_runtime_stack_bytes();
}

int main(int argc, char **argv) {
  const int64_t count = argc > 1 ? std::strtoll(argv[1], nullptr, 10) : 524289;
  if (count < 1 || count > 10000000) return 2;
  fac_mem_start_tracking();
  const uint64_t stackBytes = fac_runtime_stack_bytes();
  fac_mem_reset_peak();
  FacList *list = fac_list_new((int32_t)sizeof(int64_t), 0);
  const auto begin = std::chrono::steady_clock::now();
  for (int64_t i = 0; i < count; ++i) fac_list_insert(list, list->len, &i);
  const auto end = std::chrono::steady_clock::now();
  const double seconds = std::chrono::duration<double>(end - begin).count();
  const uint64_t live = fac_mem_used();
  const uint64_t peak = fac_mem_peak();
  const uint64_t blocks = fac_mem_blocks();
  const uint64_t allocs = fac_mem_allocs();
  const uint64_t reallocs = fac_mem_reallocs();
  const int64_t capacity = list->cap;
  std::printf("elements=%lld capacity=%lld slack=%.2f%% append_seconds=%.6f\n",
      (long long)count, (long long)capacity,
      100.0 * (double)(capacity - count) / (double)capacity, seconds);
  std::printf("tracked_live=%llu tracked_peak=%llu blocks=%llu allocs=%llu reallocs=%llu\n",
      (unsigned long long)live, (unsigned long long)peak,
      (unsigned long long)blocks, (unsigned long long)allocs,
      (unsigned long long)reallocs);
  std::printf("tls_inline_bytes_per_thread=%llu\n", (unsigned long long)stackBytes);
  fac_list_free(list);
  std::printf("tracked_after_free=%llu blocks_after_free=%llu\n",
      (unsigned long long)fac_mem_used(),
      (unsigned long long)fac_mem_blocks());
  return fac_mem_used() == 0 && fac_mem_blocks() == 0 ? 0 : 1;
}
