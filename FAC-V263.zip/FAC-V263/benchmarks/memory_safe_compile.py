#!/usr/bin/env python3
"""Compare frontend compile-time overhead of normal, --secure and --memory-safe."""
from __future__ import annotations
import argparse
import pathlib
import statistics
import subprocess
import tempfile
import time


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compiler", default="./build/facc")
    parser.add_argument("--functions", type=int, default=240)
    parser.add_argument("--runs", type=int, default=9)
    parser.add_argument("--opt", choices=("-O0", "-O1", "-O2", "-O3"), default="-O0")
    args = parser.parse_args()
    if args.functions < 2 or args.runs < 3:
        parser.error("functions must be >= 2 and runs must be >= 3")

    compiler = str(pathlib.Path(args.compiler).resolve())
    with tempfile.TemporaryDirectory(prefix="fac-memory-safe-bench-") as td:
        temp = pathlib.Path(td)
        source = temp / "compile_stress.fac"
        lines: list[str] = []
        for index in range(args.functions):
            expr = "value + 1" if index == 0 else f"f{index - 1}(value) + 1"
            lines.append(f"function int f{index}(int value) {{ return {expr} }}")
        lines.append(f"public function void main() {{ var int result = f{args.functions - 1}(1) }}")
        source.write_text("\n".join(lines) + "\n", encoding="utf-8")

        for name, extra in (("normal", []), ("secure", ["--secure"]), ("memory-safe", ["--memory-safe"])):
            durations: list[float] = []
            for run in range(args.runs):
                output = temp / f"{name}-{run}.ll"
                command = [compiler, str(source), *extra, "--emit-ll", args.opt, "-o", str(output)]
                start = time.perf_counter()
                result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
                durations.append((time.perf_counter() - start) * 1000.0)
                if result.returncode != 0:
                    raise RuntimeError(f"{name} compile failed:\n{result.stderr}")
            print(
                f"{name:12s} median={statistics.median(durations):8.3f} ms "
                f"min={min(durations):8.3f} ms max={max(durations):8.3f} ms"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
