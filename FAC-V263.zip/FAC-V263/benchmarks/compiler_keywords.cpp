// Reproducible benchmark for the parser's closed keyword/type vocabularies.
// Build: c++ -std=c++17 -O3 -DNDEBUG -Isrc benchmarks/compiler_keywords.cpp -o build/bench_keywords
// Run:   build/bench_keywords [iterations] [repetitions]
#include "parser.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char **argv) {
  const size_t iterations = argc > 1 ? static_cast<size_t>(std::strtoull(argv[1], nullptr, 10)) : 2000000;
  const int repetitions = argc > 2 ? std::max(3, std::atoi(argv[2])) : 9;
  if (iterations == 0 || iterations > 100000000) {
    std::cerr << "iterations must be between 1 and 100000000\n";
    return 2;
  }
  const std::vector<std::string> words = {
      "int", "string", "long", "boolean", "struct", "function", "public", "private",
      "readonly", "terminal", "my_value", "someFunction", "HashMap", "await", "foo",
      "this", "self", "weak", "instanceof", "continue", "array", "matrix", "uint",
      "float", "unknownIdentifier"};

  volatile size_t hits = 0;
  std::vector<double> samples;
  samples.reserve(static_cast<size_t>(repetitions));
  for (int run = 0; run <= repetitions; ++run) {
    const auto begin = std::chrono::steady_clock::now();
    for (size_t i = 0; i < iterations; ++i) {
      const std::string &word = words[i % words.size()];
      hits += Parser::isReserved(word) ? 1u : 0u;
      hits += Parser::isTypeWord(word) ? 1u : 0u;
    }
    const auto end = std::chrono::steady_clock::now();
    if (run != 0)
      samples.push_back(std::chrono::duration<double, std::milli>(end - begin).count());
  }
  std::sort(samples.begin(), samples.end());
  std::cout << "iterations=" << iterations
            << " lookups=" << (iterations * 2)
            << " words=" << words.size()
            << " median_ms=" << samples[samples.size() / 2]
            << " hits=" << hits << '\n';
  return hits == 0;
}
