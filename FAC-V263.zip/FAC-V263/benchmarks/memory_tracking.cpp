// FAC runtime tracking benchmark: compare allocation-registry overhead and peak.
// Build: c++ -std=c++17 -O2 -pthread benchmarks/memory_tracking.cpp build/fac_rt.o -lm -ldl -o build/memory_tracking
// Run: build/memory_tracking [allocations]
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

extern "C" {
void *fac_alloc(int64_t);
void *fac_realloc(void *, int64_t);
void fac_free(void *);
void fac_mem_start_tracking();
void fac_mem_reset_peak();
uint64_t fac_mem_used();
uint64_t fac_mem_peak();
uint64_t fac_mem_blocks();
uint64_t fac_mem_reserved();
}

int main(int argc, char **argv) {
  const int64_t count = argc > 1 ? std::strtoll(argv[1], nullptr, 10) : 250000;
  if (count < 1 || count > 5000000) return 2;
  fac_mem_start_tracking();
  fac_mem_reset_peak();
  const uint64_t base = fac_mem_used();
  std::vector<void *> blocks;
  blocks.reserve((size_t)count);
  const auto begin = std::chrono::steady_clock::now();
  uint64_t expected = 0;
  for (int64_t i = 0; i < count; ++i) {
    const int64_t n = 24 + (i & 31);
    blocks.push_back(fac_alloc(n));
    expected += (uint64_t)n;
  }
  for (int64_t i = 1; i < count; i += 2) {
    blocks[(size_t)i] = fac_realloc(blocks[(size_t)i], 96);
    expected += 96u - (uint64_t)(24 + (i & 31));
  }
  const uint64_t peak = fac_mem_peak();
  const uint64_t reservedAtPeak = fac_mem_reserved();
  const uint64_t liveAtPeak = fac_mem_used() - base;
  const uint64_t blocksAtPeak = fac_mem_blocks();
  for (void *p : blocks) fac_free(p);
  const auto end = std::chrono::steady_clock::now();
  const double seconds = std::chrono::duration<double>(end - begin).count();
  std::printf("allocations=%lld seconds=%.6f ops_per_sec=%.0f expected_peak=%llu observed_peak=%llu reserved=%llu live_after=%llu blocks_after=%llu\n",
      (long long)count, seconds, (double)(count * 2) / seconds,
      (unsigned long long)expected, (unsigned long long)peak,
      (unsigned long long)reservedAtPeak,
      (unsigned long long)(fac_mem_used() - base),
      (unsigned long long)fac_mem_blocks());
  std::printf("live_at_peak=%llu blocks_at_peak=%llu\n",
      (unsigned long long)liveAtPeak, (unsigned long long)blocksAtPeak);
  return fac_mem_used() == base && fac_mem_blocks() == 0 ? 0 : 1;
}
