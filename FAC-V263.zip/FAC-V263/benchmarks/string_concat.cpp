#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
FacStr *fac_str_from_chars(const char *, int64_t);
FacStr *fac_str_cat(FacStr *, FacStr *);
FacStr *fac_str_cat_many(FacStr *const *, int64_t);
void fac_str_free(FacStr *);
}

int main(int argc, char **argv) {
  int64_t rounds = argc > 1 ? std::strtoll(argv[1], nullptr, 10) : 1000000;
  constexpr int N = 8;
  FacStr *parts[N];
  for (int i = 0; i < N; ++i) parts[i] = fac_str_from_chars("abcdefghij", 10);
  volatile int64_t checksum = 0;
  auto start = std::chrono::steady_clock::now();
  for (int64_t r = 0; r < rounds; ++r) {
    FacStr *v = fac_str_cat(parts[0], parts[1]);
    for (int i = 2; i < N; ++i) {
      FacStr *next = fac_str_cat(v, parts[i]);
      fac_str_free(v);
      v = next;
    }
    checksum += v->len;
    fac_str_free(v);
  }
  auto middle = std::chrono::steady_clock::now();
  for (int64_t r = 0; r < rounds; ++r) {
    FacStr *v = fac_str_cat_many(parts, N);
    checksum += v->len;
    fac_str_free(v);
  }
  auto end = std::chrono::steady_clock::now();
  double chained = std::chrono::duration<double>(middle - start).count();
  double flattened = std::chrono::duration<double>(end - middle).count();
  std::printf("binary chain: %.6f s\nflat cat_many: %.6f s\nratio: %.2fx\nchecksum: %lld\n",
      chained, flattened, flattened > 0 ? chained / flattened : 0.0, (long long)checksum);
  for (FacStr *p : parts) fac_str_free(p);
}
