// Microbenchmark for FAC runtime immutable-string copy semantics.
// Build after `make`:
// clang++ -std=c++17 -O2 -pthread benchmarks/string_copy.cpp build/fac_rt.o -ldl -o build/bench_string_copy
// Run: build/bench_string_copy [iterations]
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>

extern "C" {
struct FacStr;
FacStr *fac_str_from_chars(const char *, int64_t);
FacStr *fac_str_dup(FacStr *);
void fac_str_free(FacStr *);
}

int main(int argc, char **argv) {
  const int64_t iterations = argc > 1 ? std::strtoll(argv[1], nullptr, 10) : 3000000;
  if (iterations < 1) return 2;
  const std::string payload(1024, 'x');
  FacStr *base = fac_str_from_chars(payload.data(), (int64_t)payload.size());
  volatile uintptr_t sink = 0;
  const auto begin = std::chrono::steady_clock::now();
  for (int64_t i = 0; i < iterations; ++i) {
    FacStr *copy = fac_str_dup(base);
    sink ^= reinterpret_cast<uintptr_t>(copy);
    fac_str_free(copy);
  }
  const auto end = std::chrono::steady_clock::now();
  fac_str_free(base);
  const double seconds = std::chrono::duration<double>(end - begin).count();
  std::printf("%.6f sec; %.0f copies/sec; sink=%zu\n", seconds,
              (double)iterations / seconds, (size_t)sink);
}
