// Repeated short-lived Runtime workspaces used by stable sort and reverse.
// Input generation and fixture storage are outside the measured section.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

extern "C" {
void fac_sort_cmp(void *, int64_t, int64_t, void *, int32_t (*)(void *, const void *, const void *));
void fac_reverse(void *, int64_t, int32_t);
struct FacList {
  void *data; int64_t len, cap; int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};
FacList *fac_list_new(int32_t, int32_t);
void fac_list_grow(FacList *);
void fac_list_insert(FacList *, int64_t, const void *);
void fac_list_remove(FacList *, int64_t);
void fac_list_free(FacList *);
}

static int32_t compare_i32(void *, const void *a, const void *b) {
  const int32_t x = *static_cast<const int32_t *>(a);
  const int32_t y = *static_cast<const int32_t *>(b);
  return (x > y) - (x < y);
}

template <typename F>
static double measure_ns(size_t rounds, F &&fn) {
  const auto begin = std::chrono::steady_clock::now();
  for (size_t i = 0; i < rounds; ++i) fn(i);
  const auto end = std::chrono::steady_clock::now();
  return std::chrono::duration<double, std::nano>(end - begin).count() / (double)rounds;
}

static double median(std::vector<double> v) {
  std::sort(v.begin(), v.end());
  return v[v.size() / 2];
}

template <typename F>
static double repeated_median(size_t samples, size_t rounds, F &&fn) {
  std::vector<double> times;
  times.reserve(samples);
  for (size_t s = 0; s < samples; ++s) times.push_back(measure_ns(rounds, fn));
  return median(std::move(times));
}

int main(int argc, char **argv) {
  const size_t samples = argc > 1 ? (size_t)std::strtoul(argv[1], nullptr, 10) : 9;
  if (samples < 3 || samples > 31) return 2;

  int32_t sort8Base[8] = {7, -2, 9, 0, 4, 4, 1, -8};
  int32_t sort8Data[8]{};
  const double sort8 = repeated_median(samples, 15000, [&](size_t) {
    std::memcpy(sort8Data, sort8Base, sizeof(sort8Base));
    fac_sort_cmp(sort8Data, 8, (int64_t)sizeof(int32_t), nullptr, compare_i32);
  });

  constexpr size_t sort128Rounds = 2500;
  std::vector<int32_t> sort128Base(128), sort128Data(128);
  for (size_t i = 0; i < sort128Base.size(); ++i)
    sort128Base[i] = (int32_t)((i * 73u + 19u) % 127u);
  const double sort128 = repeated_median(samples, sort128Rounds, [&](size_t) {
    std::memcpy(sort128Data.data(), sort128Base.data(), sort128Base.size() * sizeof(int32_t));
    fac_sort_cmp(sort128Data.data(), (int64_t)sort128Data.size(), (int64_t)sizeof(int32_t), nullptr, compare_i32);
  });

  int32_t reverse2Data[2] = {3, 7};
  const double reverse2 = repeated_median(samples, 30000, [&](size_t i) {
    reverse2Data[0] = (int32_t)i;
    reverse2Data[1] = (int32_t)(i + 1);
    fac_reverse(reverse2Data, 2, (int32_t)sizeof(int32_t));
  });

  int32_t reverse32Data[32]{};
  const double reverse32 = repeated_median(samples, 20000, [&](size_t i) {
    for (size_t j = 0; j < 32; ++j) reverse32Data[j] = (int32_t)(j + i);
    fac_reverse(reverse32Data, 32, (int32_t)sizeof(int32_t));
  });

  // Repeatedly insert a value sourced from inside the same list, forcing the
  // Runtime to snapshot the aliased element before shifting the list.
  FacList *list = fac_list_new((int32_t)sizeof(int64_t), 0);
  fac_list_grow(list);
  auto *listData = static_cast<int64_t *>(list->data);
  for (int i = 0; i < 8; ++i) listData[i] = i * 17;
  list->len = 8;
  fac_list_insert(list, 0, &listData[7]);
  fac_list_remove(list, 0); // grow once outside the timed region
  const double listAlias = repeated_median(samples, 80000, [&](size_t) {
    fac_list_insert(list, 0, &listData[7]);
    fac_list_remove(list, 0);
  });
  fac_list_free(list);

  std::printf("temporary_scratch samples=%zu sort8_ns_op=%.2f sort128_ns_op=%.2f reverse2_ns_op=%.2f reverse32_ns_op=%.2f list_alias_insert_remove_ns_op=%.2f\n",
      samples, sort8, sort128, reverse2, reverse32, listAlias);
  return 0;
}
