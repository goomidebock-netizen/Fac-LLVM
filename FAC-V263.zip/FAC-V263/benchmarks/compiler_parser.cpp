// Reproducible synthetic parser benchmark.
// Build: c++ -std=c++17 -O2 -DNDEBUG -Isrc benchmarks/compiler_parser.cpp src/lexer.cpp -o build/bench_parser
// Run:   build/bench_parser [function-count] [repetitions]
#include "parser.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>

int main(int argc, char **argv) {
  const size_t functions = argc > 1 ? static_cast<size_t>(std::strtoull(argv[1], nullptr, 10)) : 5000;
  const int repetitions = argc > 2 ? std::max(3, std::atoi(argv[2])) : 8;
  if (!functions || functions > 50000) {
    std::cerr << "function-count must be between 1 and 50000\n";
    return 2;
  }
  std::string source;
  source.reserve(functions * 120);
  for (size_t i = 0; i < functions; ++i) {
    source += "function int f" + std::to_string(i) + "(int x, int y) { "
              "var int z = x + y * 3; z += x; "
              "if (z > 10) { z = z - 1; } return z; }\n";
  }
  size_t astFunctions = 0;
  for (int r = 0; r < repetitions; ++r) {
    const auto begin = std::chrono::steady_clock::now();
    auto tokens = lex(source);
    const auto afterLex = std::chrono::steady_clock::now();
    Parser parser;
    parser.t = std::move(tokens);
    Program program = parser.parseProgram("compiler_parser_benchmark.fac");
    const auto afterParse = std::chrono::steady_clock::now();
    if (program.funcs.size() != functions) {
      std::cerr << "unexpected AST function count\n";
      return 1;
    }
    astFunctions += program.funcs.size();
    const double lexMs = std::chrono::duration<double, std::milli>(afterLex - begin).count();
    const double parseMs = std::chrono::duration<double, std::milli>(afterParse - afterLex).count();
    std::cout << "run=" << r << " lex_ms=" << lexMs << " parse_ms=" << parseMs
              << " total_ms=" << (lexMs + parseMs) << '\n';
  }
  return astFunctions == 0;
}
