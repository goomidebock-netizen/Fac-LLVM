#!/usr/bin/env python3
"""Measure repeated generic specialization lookups in a synthetic FAC unit."""
from __future__ import annotations
import argparse
import pathlib
import statistics
import subprocess
import tempfile
import time


def make_source(path: pathlib.Path, templates: int, uses_per_template: int) -> None:
    with path.open("w", encoding="utf-8") as out:
        for index in range(templates):
            out.write(f"public struct Box{index}<T> {{ public T value }}\n")
        out.write("public struct Many {\n")
        for index in range(templates):
            for use in range(uses_per_template):
                out.write(f"  public struct Box{index}<int> item{index}_{use}\n")
        out.write("}\npublic function void main() {}\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("compiler", nargs="?", default="./build/facc")
    parser.add_argument("--templates", type=int, default=100)
    parser.add_argument("--uses", type=int, default=40)
    parser.add_argument("--rounds", type=int, default=9)
    args = parser.parse_args()
    if args.templates < 1 or args.uses < 1 or args.rounds < 3:
        parser.error("templates/uses must be positive and rounds must be at least 3")
    compiler = pathlib.Path(args.compiler).resolve()
    if not compiler.is_file():
        parser.error(f"compiler not found: {compiler}")
    with tempfile.TemporaryDirectory(prefix="fac-generic-bench-") as tmp:
        root = pathlib.Path(tmp)
        source, ir = root / "generic.fac", root / "generic.ll"
        make_source(source, args.templates, args.uses)
        durations = []
        for _ in range(args.rounds):
            start = time.perf_counter()
            result = subprocess.run([str(compiler), str(source), "--emit-ll", "-o", str(ir)],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
            durations.append(time.perf_counter() - start)
            if result.returncode:
                raise SystemExit(result.stderr.strip() or f"compiler exited {result.returncode}")
        median = statistics.median(durations)
        print(f"generic specialization benchmark: {args.templates} templates, "
              f"{args.uses} uses/template, {args.templates * args.uses} references, "
              f"{args.rounds} rounds")
        print("times_s=" + ",".join(f"{value:.6f}" for value in durations))
        print(f"median_s={median:.6f}")
        print(f"ir_bytes={ir.stat().st_size}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
