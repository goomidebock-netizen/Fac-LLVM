// Reproducible semantic subtype-check benchmark.
// Build: c++ -std=c++17 -O2 -DNDEBUG -Isrc benchmarks/compiler_semantic.cpp -o build/bench_semantic
// Run:   build/bench_semantic [class-count] [repetitions]
#include "codegen.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

struct Query { std::string child, base; };
static void populate(Gen &g, int classes) {
  for (int i = 0; i < classes; ++i) {
    const std::string name = "C" + std::to_string(i);
    StructInfo &info = g.structs[name];
    info.name = name;
    info.isClass = true;
    if (i) info.parent = "C" + std::to_string(i - 1);
  }
}

int main(int argc, char **argv) {
  const int classes = argc > 1 ? std::max(100, std::min(10000, std::atoi(argv[1]))) : 2048;
  const int repetitions = argc > 2 ? std::max(3, std::min(1000, std::atoi(argv[2]))) : 15;
  Gen gen;
  populate(gen, classes);
  std::vector<Query> queries;
  queries.reserve((size_t)classes * 2);
  for (int i = 1; i < classes; ++i) {
    queries.push_back({"C" + std::to_string(i), "C" + std::to_string(i / 2)});
    queries.push_back({"C" + std::to_string(i), "C0"});
  }

  volatile size_t hits = 0;
  const auto coldBegin = std::chrono::steady_clock::now();
  for (const Query &q : queries) hits += gen.isSubclass(q.child, q.base);
  const auto coldEnd = std::chrono::steady_clock::now();
  std::vector<double> samples;
  for (int r = 0; r < repetitions; ++r) {
    const auto begin = std::chrono::steady_clock::now();
    for (const Query &q : queries) hits += gen.isSubclass(q.child, q.base);
    const auto end = std::chrono::steady_clock::now();
    samples.push_back(std::chrono::duration<double, std::milli>(end - begin).count());
  }
  std::sort(samples.begin(), samples.end());
  std::cout << "classes=" << classes << " queries_per_round=" << queries.size()
            << " repetitions=" << repetitions
            << " cold_ms=" << std::chrono::duration<double, std::milli>(coldEnd - coldBegin).count()
            << " repeated_median_ms=" << samples[samples.size() / 2]
            << " hits=" << hits << '\n';
  return hits == 0;
}
