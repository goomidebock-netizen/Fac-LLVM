#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
}

int main(int argc, char **argv) {
  const uint64_t iterations = argc > 1 ? std::strtoull(argv[1], nullptr, 10) : 2000000ULL;
  constexpr int samples = 9;
  void *object = fac_obj_new(8, nullptr, nullptr, nullptr, nullptr);
  if (!object) return 2;

  auto run = [&](uint64_t count) {
    const auto start = std::chrono::steady_clock::now();
    for (uint64_t i = 0; i < count; ++i) {
      fac_obj_retain(object);
      fac_obj_release(object);
    }
    const auto stop = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::nano>(stop - start).count() /
           static_cast<double>(count);
  };

  (void)run(iterations / 4 + 1); // warm-up
  std::vector<double> nsPerPair;
  nsPerPair.reserve(samples);
  for (int i = 0; i < samples; ++i) nsPerPair.push_back(run(iterations));
  std::sort(nsPerPair.begin(), nsPerPair.end());
  std::printf("iterations=%llu samples=%d median_ns_per_retain_release=%.2f min=%.2f\n",
              static_cast<unsigned long long>(iterations), samples,
              nsPerPair[samples / 2], nsPerPair.front());
  fac_obj_release(object);
  return 0;
}
