#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

extern "C" {
struct FacStr;
void *fac_g_new(int32_t, int32_t);
void fac_g_addedge2(void *, const void *, const void *);
int32_t fac_g_hasedge(void *, const void *, const void *);
void fac_ds_free(void *);
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
}

static volatile uint64_t sink = 0;

static double bench_integer(int64_t nodeCount, int64_t queries) {
  void *graph = fac_g_new(4, (int32_t)sizeof(int64_t));
  for (int64_t i = 0; i < nodeCount; ++i) {
    const int64_t next = (i + 1) % nodeCount;
    fac_g_addedge2(graph, &i, &next);
  }
  uint64_t hits = 0;
  const auto start = std::chrono::steady_clock::now();
  for (int64_t q = 0; q < queries; ++q) {
    const int64_t a = (q * 1315423911ULL) % nodeCount;
    const int64_t b = (a + 1) % nodeCount;
    hits += (uint64_t)fac_g_hasedge(graph, &a, &b);
  }
  const auto stop = std::chrono::steady_clock::now();
  sink += hits;
  fac_ds_free(graph);
  return std::chrono::duration<double, std::milli>(stop - start).count();
}

static double bench_string(int64_t nodeCount, int64_t queries) {
  std::vector<FacStr *> keys;
  keys.reserve((size_t)nodeCount);
  for (int64_t i = 0; i < nodeCount; ++i) {
    const std::string value = "graph-key/long-prefix/" + std::to_string(i);
    keys.push_back(fac_str_from_chars(value.data(), (int64_t)value.size()));
  }
  void *graph = fac_g_new(14, (int32_t)sizeof(FacStr *));
  for (int64_t i = 0; i < nodeCount; ++i) {
    const int64_t next = (i + 1) % nodeCount;
    fac_g_addedge2(graph, &keys[(size_t)i], &keys[(size_t)next]);
  }
  uint64_t hits = 0;
  const auto start = std::chrono::steady_clock::now();
  for (int64_t q = 0; q < queries; ++q) {
    const int64_t a = (q * 1315423911ULL) % nodeCount;
    const int64_t b = (a + 1) % nodeCount;
    hits += (uint64_t)fac_g_hasedge(graph, &keys[(size_t)a], &keys[(size_t)b]);
  }
  const auto stop = std::chrono::steady_clock::now();
  sink += hits;
  fac_ds_free(graph);
  for (FacStr *key : keys) fac_str_free(key);
  return std::chrono::duration<double, std::milli>(stop - start).count();
}

int main(int argc, char **argv) {
  const int64_t nodes = argc > 1 ? std::strtoll(argv[1], nullptr, 10) : 12000;
  const int64_t queries = argc > 2 ? std::strtoll(argv[2], nullptr, 10) : 500000;
  if (nodes < 2 || nodes > 1000000 || queries < 1 || queries > 100000000) return 2;
  // One untimed warm-up per key type, then report medians from five runs.
  (void)bench_integer(nodes, 1000);
  (void)bench_string(nodes, 1000);
  std::vector<double> integer, strings;
  for (int i = 0; i < 5; ++i) {
    integer.push_back(bench_integer(nodes, queries));
    strings.push_back(bench_string(nodes, queries));
  }
  auto median = [](std::vector<double> values) {
    std::sort(values.begin(), values.end());
    return values[values.size() / 2];
  };
  std::printf("Graph lookup: nodes=%lld queries=%lld repeats=5\n",
              (long long)nodes, (long long)queries);
  std::printf("int64 median_ms=%.3f\n", median(integer));
  std::printf("string median_ms=%.3f\n", median(strings));
  std::printf("checksum=%llu\n", (unsigned long long)sink);
  return sink == 0 ? 3 : 0;
}
