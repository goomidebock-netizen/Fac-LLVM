// Focused FAC runtime benchmark: dynamic string creation + destruction.
#include <cstdint>
#include <cstdio>
#include <chrono>

extern "C" void *fac_str_from_chars(const char *, int64_t);
extern "C" void fac_str_free(void *);

int main() {
  static const char text[] = "The quick brown fox jumps over the lazy dog. FAC runtime allocation benchmark.";
  constexpr int rounds = 3000000;
  auto start = std::chrono::steady_clock::now();
  uint64_t checksum = 0;
  for (int i = 0; i < rounds; ++i) {
    void *s = fac_str_from_chars(text, (int64_t)sizeof(text) - 1);
    checksum += (uintptr_t)s & 1u;
    fac_str_free(s);
  }
  auto end = std::chrono::steady_clock::now();
  std::printf("rounds=%d seconds=%.6f checksum=%llu\n", rounds,
              std::chrono::duration<double>(end - start).count(),
              (unsigned long long)checksum);
}
