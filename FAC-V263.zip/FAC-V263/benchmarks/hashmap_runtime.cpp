#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

extern "C" {
void *fac_hm_new(int32_t keyCode, int32_t keySize, int32_t valueCode, int32_t valueSize);
void fac_hm_set(void *map, const void *key, const void *value);
void fac_hm_get(void *map, const void *key, void *out);
int32_t fac_hm_has(void *map, const void *key);
void fac_ds_free(void *dataStructure);
}

using Clock = std::chrono::steady_clock;

static double milliseconds(Clock::time_point start, Clock::time_point end) {
  return std::chrono::duration<double, std::milli>(end - start).count();
}

static double median(std::vector<double> samples) {
  std::sort(samples.begin(), samples.end());
  const size_t middle = samples.size() / 2;
  return samples.size() % 2 ? samples[middle]
                            : (samples[middle - 1] + samples[middle]) / 2.0;
}

int main(int argc, char **argv) {
  int count = 1'000'000;
  int runs = 7;
  if (argc > 1) count = std::atoi(argv[1]);
  if (argc > 2) runs = std::atoi(argv[2]);
  if (count <= 0 || count > INT32_MAX / 2 || runs < 3 || runs > 31) {
    std::fprintf(stderr, "usage: %s [positive-item-count] [runs: 3..31]\n", argv[0]);
    return 2;
  }

  std::vector<double> setTimes, getTimes, hasTimes;
  setTimes.reserve((size_t)runs);
  getTimes.reserve((size_t)runs);
  hasTimes.reserve((size_t)runs);
  int64_t expectedSum = (int64_t)count * (count - 1);
  int expectedHits = count / 2 + (count % 2);

  for (int run = 0; run < runs + 1; ++run) { // first round warms the process/allocator
    void *map = fac_hm_new(3, (int32_t)sizeof(int32_t), 3, (int32_t)sizeof(int32_t));
    int64_t sum = 0;
    int hits = 0;

    auto start = Clock::now();
    for (int32_t key = 0; key < count; ++key) {
      const int32_t value = key * 2;
      fac_hm_set(map, &key, &value);
    }
    auto inserted = Clock::now();

    for (int32_t key = 0; key < count; ++key) {
      int32_t value = 0;
      fac_hm_get(map, &key, &value);
      sum += value;
    }
    auto read = Clock::now();

    for (int32_t key = 0; key < count * 2; key += 2)
      hits += fac_hm_has(map, &key) != 0;
    auto checked = Clock::now();

    if (sum != expectedSum || hits != expectedHits) {
      std::fprintf(stderr, "checksum mismatch: sum=%lld hits=%d\n",
                   (long long)sum, hits);
      fac_ds_free(map);
      return 1;
    }
    if (run != 0) {
      setTimes.push_back(milliseconds(start, inserted));
      getTimes.push_back(milliseconds(inserted, read));
      hasTimes.push_back(milliseconds(read, checked));
    }
    fac_ds_free(map);
  }

  std::printf("items=%d runs=%d median_ms set=%.3f get=%.3f has=%.3f checksum=%lld/%d\n",
              count, runs, median(setTimes), median(getTimes), median(hasTimes),
              (long long)expectedSum, expectedHits);
  return 0;
}
