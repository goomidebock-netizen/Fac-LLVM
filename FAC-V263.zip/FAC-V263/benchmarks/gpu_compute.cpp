#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

extern "C" {
void *fac_gpu_buffer_create(int64_t);
void fac_gpu_buffer_free(void *);
int32_t fac_gpu_write_f64(void *, int64_t, double);
double fac_gpu_read_f64(void *, int64_t);
int32_t fac_gpu_add_f64(void *, void *, void *, int64_t);
int32_t fac_gpu_scale_f64(void *, void *, int64_t, double);
}

using Clock = std::chrono::steady_clock;
static double millis(Clock::time_point begin, Clock::time_point end) {
  return std::chrono::duration<double, std::milli>(end - begin).count();
}

int main(int argc, char **argv) {
  const int64_t count = argc > 1 ? std::strtoll(argv[1], nullptr, 10) : (1LL << 20);
  if (count <= 0 || count > (1LL << 22)) {
    std::fprintf(stderr, "usage: %s [elements: 1..4194304]\n", argv[0]);
    return 2;
  }
  void *a = fac_gpu_buffer_create(count * 8), *b = fac_gpu_buffer_create(count * 8),
       *out = fac_gpu_buffer_create(count * 8);
  if (!a || !b || !out) return 2;
  for (int64_t i = 0; i < count; ++i) {
    if (!fac_gpu_write_f64(a, i, (double)(i % 997) * 0.125) ||
        !fac_gpu_write_f64(b, i, (double)(i % 991) * 0.25)) return 2;
  }

  constexpr int runs = 11;
  std::vector<double> addTimes, scaleTimes;
  addTimes.reserve(runs); scaleTimes.reserve(runs);
  for (int r = 0; r < runs + 2; ++r) {
    auto begin = Clock::now();
    if (!fac_gpu_add_f64(out, a, b, count)) return 3;
    auto end = Clock::now();
    if (r >= 2) addTimes.push_back(millis(begin, end));
    begin = Clock::now();
    if (!fac_gpu_scale_f64(out, a, count, 1.25)) return 3;
    end = Clock::now();
    if (r >= 2) scaleTimes.push_back(millis(begin, end));
  }
  std::sort(addTimes.begin(), addTimes.end());
  std::sort(scaleTimes.begin(), scaleTimes.end());
  double checksum = 0.0;
  for (int64_t i = 0; i < count; i += std::max<int64_t>(1, count / 1024)) checksum += fac_gpu_read_f64(out, i);
  std::printf("elements=%lld block=512 add_median_ms=%.3f scale_median_ms=%.3f checksum=%.9f\n",
              (long long)count, addTimes[runs / 2], scaleTimes[runs / 2], checksum);
  fac_gpu_buffer_free(out); fac_gpu_buffer_free(b); fac_gpu_buffer_free(a);
  return std::isfinite(checksum) ? 0 : 4;
}
