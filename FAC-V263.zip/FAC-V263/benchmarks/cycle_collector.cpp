#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <stdexcept>
#include <string>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void fac_cycle_visit(void *object);
int64_t fac_obj_collect_cycles();
uint64_t fac_obj_live_count();
void fac_mem_start_tracking();
uint64_t fac_mem_blocks();
}

using Clock = std::chrono::steady_clock;
static volatile uint64_t g_sink = 0;

struct BenchNode {
  std::vector<void *> edges;
};

static void trace_node(void *opaque) {
  const auto *node = static_cast<const BenchNode *>(opaque);
  for (void *child : node->edges) fac_cycle_visit(child);
}

static void drop_node(void *opaque) {
  auto *node = static_cast<BenchNode *>(opaque);
  for (void *child : node->edges) fac_obj_release(child);
  node->edges.clear();
  node->edges.~vector<void *>();
}

static BenchNode *make_node() {
  void *storage = fac_obj_new(static_cast<int64_t>(sizeof(BenchNode)),
      reinterpret_cast<void *>(drop_node), nullptr,
      reinterpret_cast<void *>(trace_node), nullptr);
  if (!storage) throw std::bad_alloc();
  return new (storage) BenchNode();
}

struct Case {
  const char *shape;
  int nodes;
  int degree;
  bool externalRoot;
};

static double run_once(const Case &test) {
  const uint64_t liveBefore = fac_obj_live_count();
  const uint64_t blocksBefore = fac_mem_blocks();
  std::vector<BenchNode *> nodes;
  nodes.reserve(static_cast<size_t>(test.nodes));
  for (int i = 0; i < test.nodes; ++i) nodes.push_back(make_node());

  // A directed circulant graph is strongly connected because every node links
  // to its successor. Additional offsets vary density without changing shape.
  for (int i = 0; i < test.nodes; ++i) {
    BenchNode *from = nodes[static_cast<size_t>(i)];
    from->edges.reserve(static_cast<size_t>(test.degree));
    for (int offset = 1; offset <= test.degree; ++offset) {
      void *to = nodes[static_cast<size_t>((i + offset) % test.nodes)];
      from->edges.push_back(to);
      fac_obj_retain(to);
    }
  }

  // Drop all builder roots before timing. A rooted case keeps one genuine
  // external reference so the collector must traverse and preserve the SCC.
  BenchNode *root = test.externalRoot ? nodes[static_cast<size_t>(test.nodes / 2)] : nullptr;
  if (root) fac_obj_retain(root);
  for (BenchNode *node : nodes) fac_obj_release(node);
  nodes.clear();

  const auto start = Clock::now();
  const int64_t collected = fac_obj_collect_cycles();
  const auto stop = Clock::now();
  g_sink += static_cast<uint64_t>(collected);

  const int64_t expected = test.externalRoot ? 0 : test.nodes;
  if (collected != expected ||
      fac_obj_live_count() != liveBefore + (test.externalRoot ? test.nodes : 0)) {
    std::fprintf(stderr,
        "FAIL %s nodes=%d degree=%d rooted=%d: collected=%lld\n",
        test.shape, test.nodes, test.degree, test.externalRoot ? 1 : 0,
        static_cast<long long>(collected));
    std::exit(3);
  }
  if (root) {
    fac_obj_release(root);
    if (fac_obj_collect_cycles() != test.nodes) {
      std::fprintf(stderr, "FAIL rooted cleanup %s nodes=%d\n", test.shape, test.nodes);
      std::exit(3);
    }
  }
  if (fac_obj_live_count() != liveBefore || fac_mem_blocks() != blocksBefore) {
    std::fprintf(stderr,
        "FAIL %s nodes=%d degree=%d rooted=%d: live=%llu/%llu blocks=%llu/%llu\n",
        test.shape, test.nodes, test.degree, test.externalRoot ? 1 : 0,
        static_cast<unsigned long long>(fac_obj_live_count()),
        static_cast<unsigned long long>(liveBefore),
        static_cast<unsigned long long>(fac_mem_blocks()),
        static_cast<unsigned long long>(blocksBefore));
    std::exit(3);
  }
  return std::chrono::duration<double, std::micro>(stop - start).count();
}

static double median(std::vector<double> values) {
  std::sort(values.begin(), values.end());
  return values[values.size() / 2];
}

int main(int argc, char **argv) {
  const int repeats = argc > 1 ? std::atoi(argv[1]) : 5;
  if (repeats < 3 || repeats > 21 || (repeats % 2) == 0) {
    std::fprintf(stderr, "usage: %s [odd_repeats:3..21]\n", argv[0]);
    return 2;
  }
  fac_mem_start_tracking();
  const Case cases[] = {
    {"sparse", 1024, 2, false},
    {"sparse", 4096, 2, false},
    {"sparse", 16384, 2, false},
    {"sparse", 32768, 2, false},
    {"sparse", 32768, 8, false},
    {"dense", 128, 127, false},
    {"dense", 256, 255, false},
    {"dense", 512, 511, false},
    {"sparse-rooted", 16384, 2, true},
    {"dense-rooted", 512, 255, true},
  };
  std::puts("shape,nodes,edges,degree,external_root,repeats,median_collect_us");
  for (const Case &test : cases) {
    (void)run_once(test); // warm-up
    std::vector<double> samples;
    samples.reserve(static_cast<size_t>(repeats));
    for (int i = 0; i < repeats; ++i) samples.push_back(run_once(test));
    std::printf("%s,%d,%lld,%d,%d,%d,%.3f\n", test.shape, test.nodes,
        static_cast<long long>(test.nodes) * test.degree, test.degree,
        test.externalRoot ? 1 : 0, repeats, median(samples));
  }
  std::printf("checksum=%llu live=%llu blocks=%llu\n",
      static_cast<unsigned long long>(g_sink),
      static_cast<unsigned long long>(fac_obj_live_count()),
      static_cast<unsigned long long>(fac_mem_blocks()));
  return fac_obj_live_count() == 0 && fac_mem_blocks() == 0 && g_sink != 0 ? 0 : 4;
}
