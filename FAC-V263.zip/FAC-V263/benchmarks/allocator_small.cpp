// FAC small-allocation benchmark: measures alloc/realloc/free with optional
// memory diagnostics enabled. The pointer vector is reserved outside the timed
// region so the reported time is dominated by the FAC allocator path.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

extern "C" {
void *fac_alloc(int64_t);
void *fac_realloc(void *, int64_t);
void fac_free(void *);
void fac_mem_start_tracking();
uint64_t fac_mem_used();
uint64_t fac_mem_blocks();
uint64_t fac_mem_allocs();
uint64_t fac_mem_reallocs();
}

static double run_sample(std::vector<void *> &blocks, int64_t count) {
  blocks.clear();
  const auto begin = std::chrono::steady_clock::now();
  for (int64_t i = 0; i < count; ++i) {
    const int64_t bytes = 24 + (i & 31);
    blocks.push_back(fac_alloc(bytes));
  }
  for (int64_t i = 1; i < count; i += 2) {
    const int64_t bytes = 80 + (i & 15);
    blocks[(size_t)i] = fac_realloc(blocks[(size_t)i], bytes);
  }
  for (size_t i = blocks.size(); i > 0; --i) fac_free(blocks[i - 1]);
  const auto end = std::chrono::steady_clock::now();
  blocks.clear();
  return std::chrono::duration<double, std::nano>(end - begin).count();
}

int main(int argc, char **argv) {
  const bool tracked = argc > 1 && std::strcmp(argv[1], "tracked") == 0;
  const int64_t count = argc > 2 ? std::strtoll(argv[2], nullptr, 10) : 200000;
  const int samples = argc > 3 ? std::atoi(argv[3]) : 7;
  if (count < 1000 || count > 2000000 || samples < 3 || samples > 31) return 2;
  if (tracked) fac_mem_start_tracking();

  std::vector<void *> blocks;
  blocks.reserve((size_t)count);
  (void)run_sample(blocks, count / 4); // allocator warm-up

  std::vector<double> times;
  times.reserve((size_t)samples);
  for (int i = 0; i < samples; ++i) {
    times.push_back(run_sample(blocks, count));
    if (fac_mem_used() != 0 || fac_mem_blocks() != 0) {
      std::fprintf(stderr, "allocator accounting did not return to zero after sample %d\n", i);
      return 1;
    }
  }
  std::sort(times.begin(), times.end());
  const double median = times[times.size() / 2];
  const double operations = (double)count * 2.5; // alloc + half realloc + free
  std::printf("mode=%s count=%lld samples=%d median_ns=%.0f ns_per_operation=%.2f allocs=%llu reallocs=%llu live=%llu blocks=%llu\n",
      tracked ? "tracked" : "plain", (long long)count, samples, median,
      median / operations,
      (unsigned long long)fac_mem_allocs(),
      (unsigned long long)fac_mem_reallocs(),
      (unsigned long long)fac_mem_used(),
      (unsigned long long)fac_mem_blocks());
  return 0;
}
