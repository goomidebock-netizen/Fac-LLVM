#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

extern "C" {
struct FacStr;
void *fac_hm_new(int32_t, int32_t, int32_t, int32_t);
void fac_hm_set(void *, const void *, const void *);
void *fac_ti_new();
void fac_ti_insert(void *, const void *);
int64_t fac_ds_len(void *);
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
}
int main(int argc, char **argv) {
  const std::string mode = argc > 1 ? argv[1] : "map";
  if (mode == "map") {
    void *m = fac_hm_new(4, 8, 4, 8);
    for (int64_t i = 0; i < 250000; ++i) { int64_t v = i ^ 0x5a5a5a5a; fac_hm_set(m, &i, &v); }
    std::printf("map entries=%lld\n", (long long)fac_ds_len(m));
  } else if (mode == "trie") {
    void *t = fac_ti_new();
    for (int i = 0; i < 100000; ++i) {
      std::string word = "shared-prefix-for-fac-trie-" + std::to_string(i);
      FacStr *s = fac_str_from_chars(word.data(), (int64_t)word.size());
      fac_ti_insert(t, &s); fac_str_free(s);
    }
    std::printf("trie words=%lld\n", (long long)fac_ds_len(t));
  } else return 2;
}
