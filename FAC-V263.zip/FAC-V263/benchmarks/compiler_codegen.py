#!/usr/bin/env python3
"""Measure FAC source-to-LLVM-IR time and IR size for constant-heavy functions.

Usage: python3 benchmarks/compiler_codegen.py [facc-path] [function-count] [repetitions]
This intentionally stops at textual IR generation; it does not measure LLVM's
backend optimization, native-code linking, or program execution time.
"""
from __future__ import annotations

import os
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def main() -> int:
    compiler = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "./build/facc")
    functions = int(sys.argv[2]) if len(sys.argv) > 2 else 600
    repetitions = max(3, int(sys.argv[3]) if len(sys.argv) > 3 else 8)
    if not os.path.isfile(compiler) or not os.access(compiler, os.X_OK):
        print(f"compiler is not executable: {compiler}", file=sys.stderr)
        return 2
    if not 1 <= functions <= 20000:
        print("function-count must be between 1 and 20000", file=sys.stderr)
        return 2

    constant = "(((2 + 3) * 4 - 5) + ((6 * 7) - (8 + 9)) + ((10 + 11) * (12 - 2)))"
    pieces = ["import terminal.fac\n"]
    for index in range(functions):
        pieces.append(f"function int cg_{index}(int x) {{ return x + {constant} }}\n")
    pieces.append("public function void main() { terminal.out.println(cg_0(7)) }\n")
    source = "".join(pieces)

    with tempfile.TemporaryDirectory(prefix="fac-codegen-bench-") as td:
        source_path = Path(td) / "codegen_bench.fac"
        ir_path = Path(td) / "codegen_bench.ll"
        source_path.write_text(source, encoding="utf-8")
        samples: list[float] = []
        ir_bytes = 0
        for run in range(repetitions + 1):  # one warm-up
            begin = time.perf_counter()
            result = subprocess.run(
                [compiler, str(source_path), "--emit-ll", "-o", str(ir_path)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                check=False,
            )
            elapsed_ms = (time.perf_counter() - begin) * 1000.0
            if result.returncode != 0:
                sys.stderr.write(result.stderr.decode("utf-8", errors="replace"))
                return result.returncode or 1
            ir_bytes = ir_path.stat().st_size
            if run:
                samples.append(elapsed_ms)
        print(
            f"functions={functions} source_bytes={len(source.encode('utf-8'))} "
            f"ir_bytes={ir_bytes} median_ms={statistics.median(samples):.3f} "
            f"runs={len(samples)}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
