// Synthetic compiler-front-end microbenchmark. Build with:
// c++ -std=c++17 -O2 -Isrc benchmarks/compiler_lexer.cpp src/lexer.cpp -o build/lexer-bench
#include "parser.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char **argv) {
  const size_t statements = argc > 1 ? (size_t)std::strtoull(argv[1], nullptr, 10) : 20000;
  std::string source;
  source.reserve(statements * 96);
  for (size_t i = 0; i < statements; ++i) {
    source += "value";
    source += std::to_string(i);
    source += " += (left * right) >= other && flag || mask != 0;\n";
  }
  volatile size_t tokenSink = 0;
  std::vector<double> samples;
  samples.reserve(7);
  for (int run = 0; run < 8; ++run) {
    const auto begin = std::chrono::steady_clock::now();
    const auto tokens = lex(source);
    const auto end = std::chrono::steady_clock::now();
    tokenSink += tokens.size();
    if (run != 0) samples.push_back(std::chrono::duration<double, std::milli>(end - begin).count());
  }
  std::sort(samples.begin(), samples.end());
  std::cout << "statements=" << statements << " tokens=" << (tokenSink / 8)
            << " warm_median_ms=" << samples[samples.size() / 2] << '\n';
  return tokenSink == 0;
}
