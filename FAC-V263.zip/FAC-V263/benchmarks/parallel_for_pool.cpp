#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>

extern "C" void fac_parallel_for(int32_t, void *);

struct Work {
  void *entry;
  std::atomic<uint64_t> calls{0};
  static void run(void *opaque, int32_t) {
    static_cast<Work *>(opaque)->calls.fetch_add(1, std::memory_order_relaxed);
  }
  Work() : entry(reinterpret_cast<void *>(run)) {}
};

int main(int argc, char **argv) {
  const int rounds = argc > 1 ? std::max(1, std::atoi(argv[1])) : 500;
  const int count = argc > 2 ? std::max(1, std::atoi(argv[2])) : 8;
  Work work;
  for (int i = 0; i < 8; ++i) fac_parallel_for(count, &work); // pool warm-up
  work.calls.store(0, std::memory_order_relaxed);
  const auto begin = std::chrono::steady_clock::now();
  for (int i = 0; i < rounds; ++i) fac_parallel_for(count, &work);
  const auto end = std::chrono::steady_clock::now();
  const uint64_t expected = (uint64_t)rounds * (uint64_t)count;
  const auto elapsed = std::chrono::duration<double, std::milli>(end - begin).count();
  if (work.calls.load(std::memory_order_relaxed) != expected) return 2;
  std::printf("rounds=%d items=%d callbacks=%llu elapsed_ms=%.3f\n", rounds, count,
              (unsigned long long)expected, elapsed);
  return 0;
}
