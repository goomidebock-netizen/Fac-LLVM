#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <climits>

extern "C" int64_t fac_crypto_randint(int64_t lo, int64_t hi);

int main(int argc, char **argv) {
  const uint64_t count = argc > 1 ? std::strtoull(argv[1], nullptr, 10) : 1000000ULL;
  volatile uint64_t sink = 0;
  const auto start = std::chrono::steady_clock::now();
  for (uint64_t i = 0; i < count; ++i)
    sink ^= (uint64_t)fac_crypto_randint(-1000000, 1000000);
  const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
  std::printf("crypto.randomInt calls=%llu seconds=%.6f calls_per_second=%.0f sink=%llu\n",
              (unsigned long long)count, seconds, seconds > 0 ? count / seconds : 0.0,
              (unsigned long long)sink);
  return 0;
}
