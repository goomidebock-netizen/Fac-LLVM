#!/bin/sh
# เทสต์ mixer เสียง (SDL2 backend, Linux/macOS): ใช้ SDL_AUDIODRIVER=disk เขียน PCM ลงไฟล์แล้ววิเคราะห์ความถี่ ไม่ต้องมีการ์ดเสียง
cd "$(dirname "$0")/.." || exit 1
./build/facc tests/audio/mixer.fac -o /tmp/fac_audio_t ${1:--O2} || exit 1
rm -f /tmp/fac_audio.raw
SDL_AUDIODRIVER=disk SDL_DISKAUDIOFILE=/tmp/fac_audio.raw /tmp/fac_audio_t > /tmp/fac_audio_out 2>/dev/null || exit 1
printf 'available=true\nplay a=true\nplay b=true\nplaying=2\nplaying after=0\nloop=true\nlooping=1\nstopped=0\ndone\n' | diff - /tmp/fac_audio_out || exit 1
python3 tests/audio/check_mixer.py /tmp/fac_audio.raw
