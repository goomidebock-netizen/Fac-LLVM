if(NOT DEFINED FAC_BUILD_DIR OR NOT DEFINED FAC_TEST_SOURCE OR
   NOT DEFINED FAC_TEST_BINARY OR NOT DEFINED FAC_INSTALL_PREFIX OR
   NOT DEFINED FAC_GENERATOR OR NOT DEFINED FAC_CXX_COMPILER)
  message(FATAL_ERROR "package_consumer.cmake missing required arguments")
endif()

set(install_args --install "${FAC_BUILD_DIR}" --prefix "${FAC_INSTALL_PREFIX}")
if(DEFINED FAC_CONFIG AND NOT FAC_CONFIG STREQUAL "")
  list(APPEND install_args --config "${FAC_CONFIG}")
endif()
execute_process(
  COMMAND "${CMAKE_COMMAND}" ${install_args}
  RESULT_VARIABLE result
)
if(NOT result EQUAL 0)
  message(FATAL_ERROR "FAC install step failed: ${result}")
endif()

set(configure_args
  -S "${FAC_TEST_SOURCE}"
  -B "${FAC_TEST_BINARY}"
  -G "${FAC_GENERATOR}"
  "-DCMAKE_PREFIX_PATH=${FAC_INSTALL_PREFIX}"
  "-DCMAKE_CXX_COMPILER=${FAC_CXX_COMPILER}"
)
if(DEFINED FAC_CONFIG AND NOT FAC_CONFIG STREQUAL "")
  list(APPEND configure_args "-DCMAKE_BUILD_TYPE=${FAC_CONFIG}")
endif()
execute_process(
  COMMAND "${CMAKE_COMMAND}" ${configure_args}
  RESULT_VARIABLE result
)
if(NOT result EQUAL 0)
  message(FATAL_ERROR "FAC package consumer configure failed: ${result}")
endif()

set(build_args --build "${FAC_TEST_BINARY}" --parallel 2)
if(DEFINED FAC_CONFIG AND NOT FAC_CONFIG STREQUAL "")
  list(APPEND build_args --config "${FAC_CONFIG}")
endif()
execute_process(
  COMMAND "${CMAKE_COMMAND}" ${build_args}
  RESULT_VARIABLE result
)
if(NOT result EQUAL 0)
  message(FATAL_ERROR "FAC package consumer build failed: ${result}")
endif()
