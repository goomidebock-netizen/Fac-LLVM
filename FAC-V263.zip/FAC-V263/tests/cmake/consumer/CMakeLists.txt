cmake_minimum_required(VERSION 3.20)
project(FACInstalledConsumer LANGUAGES CXX)
find_package(FAC 0.2 REQUIRED CONFIG)

add_executable(fac_installed_runtime_consumer main.cpp)
target_link_libraries(fac_installed_runtime_consumer PRIVATE FAC::Runtime)

# Exercise the exported executable target as well as the static Runtime.
add_custom_target(check_installed_compiler ALL
  COMMAND "$<TARGET_FILE:FAC::Compiler>" --version
  VERBATIM
)
