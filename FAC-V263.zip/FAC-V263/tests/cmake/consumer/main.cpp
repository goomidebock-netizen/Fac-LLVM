#include <cstdint>

extern "C" void *fac_g_new(int32_t kind, int32_t key_size);
extern "C" void fac_ds_free(void *value);

int main() {
  const int32_t key = 131;
  void *graph = fac_g_new(3, static_cast<int32_t>(sizeof(key)));
  if (!graph) return 1;
  fac_ds_free(graph);
  return 0;
}
