#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
OPT=${1:--O0}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-java-entry.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0

run_ok() {
  name=$1; expected=$2; shift 2
  if ! "$FAC_COMPILER" "tests/java_entry/$name.fac" -o "$TMP/$name" "$OPT" >"$TMP/$name.compile.out" 2>"$TMP/$name.compile.err"; then
    echo "FAIL $name: compile failed"; cat "$TMP/$name.compile.err"; fail=$((fail+1)); return
  fi
  if ! "$TMP/$name" "$@" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name: program failed"; cat "$TMP/$name.err"; fail=$((fail+1)); return
  fi
  printf '%b' "$expected" >"$TMP/$name.expected"
  if diff -u "$TMP/$name.expected" "$TMP/$name.out" >/dev/null; then pass=$((pass+1));
  else echo "FAIL $name: output mismatch"; diff -u "$TMP/$name.expected" "$TMP/$name.out"; fail=$((fail+1)); fi
}

run_bad() {
  name=$1; expected=$2
  if "$FAC_COMPILER" "tests/java_entry/$name.fac" -o "$TMP/$name" "$OPT" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name: invalid entry point was accepted"; fail=$((fail+1));
  elif grep -Fq "$expected" "$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name: wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
}

run_ok hello_args 'Hello, World!\nargc=2\narg0=alpha\n' alpha beta
run_ok hello_args 'Hello, World!\nargc=0\n'
run_ok hello_noargs 'Class entry without arguments\n'
run_ok legacy_main 'Legacy entry preserved\n'
run_bad bad_main_arg 'parameter ของ Java-style main ต้องเป็น `list dyn string args`'
run_bad bad_main_nonstatic 'Java-style entry point ต้องเป็น static method'
run_bad bad_main_private 'Java-style entry point ต้องเป็น public method'
run_bad bad_main_return 'Java-style entry point ต้อง return void'
run_bad bad_main_ambiguous 'พบ class entry point มากกว่าหนึ่งตัว'
run_bad bad_main_both_styles 'พบ entry point ซ้ำกัน'

echo "java-style entry tests ($OPT): pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
