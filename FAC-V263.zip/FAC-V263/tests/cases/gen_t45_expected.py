#!/usr/bin/env python3
"""oracle ของ t45_oop_virtual: เขียนโปรแกรมเดียวกันเป็น Python class (virtual dispatch + super() ของ Python เองเป็นตัวตัดสิน)
ใช้: python3 tests/cases/gen_t45_expected.py > tests/cases/t45_oop_virtual.out"""
class Base:
    def __init__(s, h): s.hp = h
    def score(s): return s.hp * 10 + s.power()
    def describe(s): return s.name() + ":" + str(s.score())
class Warrior(Base):
    def name(s): return "warrior"
    def power(s): return 7
class Mage(Base):
    def __init__(s, h, m): super().__init__(h); s.mana = m
    def name(s): return "mage"
    def power(s): return s.mana * 2
    def score(s): return super().score() + 1000
class Archmage(Mage):
    def name(s): return "arch" + super().name()
    def power(s): return super().power() + 100
class Rock:
    def name(s): return "rock"
class Both:
    def __init__(s, x): s.v = x
    def name(s): return "both" + str(s.v)
    def score(s): return s.v * 3
class Counter:
    def __init__(s): s.n = 0
    def inc(s): s.n += 1
    def get(s): return s.n
class Holder:
    def __init__(s, w): s.who = w
    def who2(s): return s.who.name() + "!"
def twice(s): return s.score() * 2
def make(k): return Warrior(1) if k == 0 else Mage(2, 3) if k == 1 else Archmage(1, 1)
out = []
P = lambda *a: out.append("".join(str(x) for x in a))
w = Warrior(5); P("w: ", w.describe(), " ", w.score(), " ", w.power(), " ", w.name())
m = Mage(4, 6); P("m: ", m.describe(), " ", m.score(), " ", m.power())
a = Archmage(3, 5); P("a: ", a.describe(), " ", a.score(), " ", a.power(), " ", a.name())
ab = a; P("ab: ", ab.describe(), " ", ab.score(), " ", ab.name())
e = a; n = e; sc = e
P("iface: ", e.describe(), " ", e.name(), " ", e.score(), " ", n.name(), " ", sc.score(), " ", twice(sc), " ", twice(w))
es = [make(k) for k in range(3)]
total = sum(x.score() for x in es); names = "".join(x.name() + "," for x in es)
P("list: ", total, " ", names, " ", es[2].describe())
ns = [Rock(), Both(4), a, es[0]]
P("named: ", "".join(x.name() + ";" for x in ns))
bo = Both(7); P("both: ", bo.name(), " ", bo.name(), " ", bo.score(), " ", twice(bo))
h = Holder(Archmage(2, 2)); P("holder: ", h.who.name(), " ", h.who2())
h.who = Rock(); P("holder2: ", h.who2())
c = Counter(); c.inc(); c.inc(); P("direct: ", c.get(), " ", c.n)
P("null call code=7")      # เรียก method ผ่าน object ที่เป็น null -> Error code 7
print("\n".join(out))
