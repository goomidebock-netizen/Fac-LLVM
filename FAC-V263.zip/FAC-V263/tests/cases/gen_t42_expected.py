#!/usr/bin/env python3
"""oracle ของ t42_collide: เขียนด้วยอัลกอริทึมคนละแบบกับ stdlib/collide.fac (ไม่ได้ลอกสูตร)
  - separate: brute force เลื่อน A ทีละ 0.5 ในแต่ละทิศจนไม่ซ้อน (ค่าทั้งหมดเป็นผลคูณของ 0.5 จึงแม่นยำ)
  - rayRect: ตัดรังสีกับขอบทั้ง 4 ด้วย Fraction (รวมกรณีรังสีทับขอบ/จุดเริ่มอยู่ข้างใน)
  - circleRect: ระยะจากจุดศูนย์กลางถึงขอบสี่เหลี่ยมด้วย max(0, ...) ต่อแกน   ใช้: python3 gen_t42_expected.py > t42_collide.out"""
import math
from fractions import Fraction as F
seed = 12345
def rnd():
    global seed
    seed = (seed * 1103515245 + 12345) % 2147483648
    return (seed // 65536) % 32768
def half(r, s): return (rnd() % r - s) * 0.5
def ov(ax, ay, aw, ah, bx, by, bw, bh): return max(ax, bx) < min(ax + aw, bx + bw) and max(ay, by) < min(ay + ah, by + bh)
def separate(a, b):
    if not ov(*a, *b): return (0.0, 0.0)
    best = None
    for name, (sx, sy) in (("L", (-1, 0)), ("R", (1, 0)), ("U", (0, -1)), ("D", (0, 1))):
        k = 1
        while ov(a[0] + sx * k * 0.5, a[1] + sy * k * 0.5, a[2], a[3], *b): k += 1
        dist = k * 0.5
        if best is None or dist < best[0]: best = (dist, sx * dist, sy * dist)
    return (best[1] + 0.0, best[2] + 0.0)     # +0.0 กัน -0.0
def cross(a, b): return a[0] * b[1] - a[1] * b[0]
def dot(a, b): return a[0] * b[0] + a[1] * b[1]
def ray(o, d, r):
    x, y, w, h = map(F, r); o = (F(o[0]), F(o[1])); d = (F(d[0]), F(d[1]))
    if x <= o[0] <= x + w and y <= o[1] <= y + h: return F(0)
    pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    c = []
    for i in range(4):
        P, Q = pts[i], pts[(i + 1) % 4]; e = (Q[0] - P[0], Q[1] - P[1]); po = (P[0] - o[0], P[1] - o[1]); den = cross(d, e)
        if den != 0:
            t = cross(po, e) / den; u = cross(po, d) / den
            if t >= 0 and 0 <= u <= 1: c.append(t)
        elif cross(po, d) == 0:
            dd = dot(d, d); ta = dot(po, d) / dd; tb = dot((Q[0] - o[0], Q[1] - o[1]), d) / dd
            if max(ta, tb) >= 0: c.append(max(min(ta, tb), F(0)))
    return min(c) if c else None
def circle_rect(cx, cy, r, x, y, w, h):
    dx = max(x - cx, 0, cx - (x + w)); dy = max(y - cy, 0, cy - (y + h)); return F(dx) ** 2 + F(dy) ** 2 < F(r) ** 2
out = []
for i in range(400):
    ax = half(41, 20); ay = half(41, 20); aw = (rnd() % 20 + 1) * 0.5; ah = (rnd() % 20 + 1) * 0.5
    bx = half(41, 20); by = half(41, 20); bw = (rnd() % 20 + 1) * 0.5; bh = (rnd() % 20 + 1) * 0.5
    cr = (rnd() % 8 + 1) * 0.5; dr = (rnd() % 8 + 1) * 0.5
    px = half(41, 20); py = half(41, 20); ox = half(41, 20); oy = half(41, 20)
    rdx = float(rnd() % 7 - 3); rdy = float(rnd() % 7 - 3)
    if rdx == 0.0 and rdy == 0.0: rdx = 1.0
    sx, sy = separate((ax, ay, aw, ah), (bx, by, bw, bh))
    t = ray((ox, oy), (rdx, rdy), (bx, by, bw, bh))
    ti = -1 if t is None else int(math.floor(float(t) * 1000000.0 + 0.5))
    R = int(ov(ax, ay, aw, ah, bx, by, bw, bh))
    C = int((F(ax) - F(bx)) ** 2 + (F(ay) - F(by)) ** 2 < (F(cr) + F(dr)) ** 2)
    CR = int(circle_rect(ax, ay, cr, bx, by, bw, bh))
    P1 = int(bx <= px < bx + bw and by <= py < by + bh)
    P2 = int((F(px) - F(ax)) ** 2 + (F(py) - F(ay)) ** 2 < F(cr) ** 2)
    D = int(math.sqrt((ax - bx) ** 2 + (ay - by) ** 2) * 1000.0 + 0.5)
    out.append(f"{i} R={R} C={C} CR={CR} P={P1}{P2} S={sx!r},{sy!r} T={ti} D={D}")
print("\n".join(out))
