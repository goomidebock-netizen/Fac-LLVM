#!/usr/bin/env python3
"""oracle ของ t47_entity_world: โมเดล World ตามสเปกใน stdlib/entity.fac เขียนด้วย Python class (virtual dispatch ของ Python)
ใช้: python3 tests/cases/gen_t47_expected.py > tests/cases/t47_entity_world.out"""
out = []; seq = [0]; items = []
class Ticker:
    def __init__(s, i, l): s.id = i; s.life = l
    def update(s): s.life -= 1; out.append(f"update {s.id}")
    def draw(s): out.append(f"draw {s.id}")
    def alive(s): return s.life > 0
class Spawner:
    def __init__(s, i): s.id = i; s.left = 2
    def update(s):
        if s.left > 0: s.left -= 1; seq[0] += 1; items.append(Ticker(100 + seq[0], 2))
        out.append(f"update {s.id}")
    def draw(s): out.append(f"draw {s.id}")
    def alive(s): return s.left > 0
class Painter:
    def __init__(s, x): s.x = x
    def update(s): s.x += 1
    def alive(s): return True
def world_update():
    n = len(items)
    for e in list(items[:n]): e.update()
    items[:] = [e for e in items if e.alive()]        # ถอดตัวที่ตาย คงลำดับ
items += [Ticker(1, 1), Spawner(2), Ticker(3, 3)]
for f in range(4):
    out.append(f"frame {f} count={len(items)}")
    world_update()
    for e in items: e.draw()
out.append(f"end count={len(items)}")
items.clear(); p = Painter(2); items.append(p); world_update()
camx = 1; px = p.x - camx                              # วาดพิกเซลแดงที่ (x-camX, 1)
screen = {(px, 1): 0xFF0000}
out.append(f"painter px={screen.get((2, 1), 0)} other={screen.get((3, 1), 0)}")
print("\n".join(out))
