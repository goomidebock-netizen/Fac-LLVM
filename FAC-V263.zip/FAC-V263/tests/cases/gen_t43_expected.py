#!/usr/bin/env python3
"""oracle ของ t43_tilemap (เขียนคนละอัลกอริทึมกับ stdlib/tilemap.fac)
  - draw: คำนวณทีละพิกเซลของจอ -> พิกัดโลก -> ไทล์ -> พิกเซลใน atlas -> ผสม alpha (ไม่ใช้การไล่ทีละไทล์แบบ Fac)
  - hitsSolid: เศษส่วนแม่นยำ, ตรวจซ้อนทับกับไทล์ตันทุกอันโดยตรง (ไม่ใช้ช่วงคอลัมน์/แถว); นอกแผนที่นับเป็นตัน
  - move: แยกก้าวย่อยตามสเปก แล้วหา "ตำแหน่งชิดกำแพง" ด้วยการสแกนตำแหน่งผู้สมัคร (ขอบไทล์ - ขนาด) แทนสูตร snap
ใช้: python3 tests/cases/gen_t43_expected.py > tests/cases/t43_tilemap.out   (ต้องรัน tests/assets/game_assets.py ก่อน)"""
import math, os, sys
from fractions import Fraction as F
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets"))
from game_assets import tiles_px, mix, pack
seed = 2024
def rnd():
    global seed
    seed = (seed * 1103515245 + 12345) % 2147483648
    return (seed // 65536) % 32768
def checksum(img):
    s = 7
    for row in img:
        for p in row: s = (s * 31 + pack(p)) % 1000000007
    return s
atlas = [[tiles_px(x, y) for x in range(64)] for y in range(32)]
TS = 16
# ---- 1) draw ----
cols, rows = 14, 10
grid = [[rnd() % 10 for c in range(cols)] for r in range(rows)]
out = []
camX = [0, 5, -7, 60, 150, -100, 3, 120, 176, 191, -47, 16]
camY = [0, 3, -4, 50, 100, -100, -9, 95, 130, 120, -39, -17]
for cx, cy in zip(camX, camY):
    img = []
    for sy in range(40):
        row = []
        for sx in range(48):
            wx, wy = cx + sx, cy + sy; px = (10, 20, 30)
            c, r = wx // TS, wy // TS            # // ปัดลงเสมอ (รวมค่าติดลบ)
            if 0 <= c < cols and 0 <= r < rows:
                tid = grid[r][c]
                if tid >= 1:
                    cell = tid - 1
                    if cell // 4 < 2:               # ช่องที่เกิน atlas (id 9) ถูกข้าม
                        px = mix(px, atlas[(cell // 4) * 16 + wy % TS][(cell % 4) * 16 + wx % TS])
            row.append(px)
        img.append(row)
    out.append(f"draw cam=({cx},{cy}) sum={checksum(img)}")
out.append("colAt: -1 -1 -2 0 0 1 rowAt: -1 9")
# ---- 2) แผนที่ตัน ----
W2, H2 = 20, 15
g2 = [[0] * W2 for _ in range(H2)]
for r in range(H2):
    for c in range(W2):
        idv = 0; roll = rnd() % 10
        if roll in (5, 6): idv = 1
        if roll in (7, 8): idv = 2
        if roll == 9: idv = 3
        if r == 0 or c == 0 or r == 14 or c == 19: idv = 2
        g2[r][c] = idv
SOLID = {2, 3}                                       # setSolid(1,true) แล้ว (1,false) -> 1 ไม่ตัน
out.append("solid ids: false true true false at(0,0)=true at(-1,5)=true at(20,5)=true")
solids = [(c * TS, r * TS) for r in range(H2) for c in range(W2) if g2[r][c] in SOLID]
def hits(x, y, w, h):
    x, y, w, h = F(x), F(y), F(w), F(h)
    if x < 0 or y < 0 or x + w > W2 * TS or y + h > H2 * TS: return True
    return any(x < sx + TS and sx < x + w and y < sy + TS and sy < y + h for sx, sy in solids)
def b(v): return 1 if v else 0
for i in range(250):
    px = rnd() % 1280 * 0.25; py = rnd() % 960 * 0.25; rw = (rnd() % 5) * 2 + 4; rh = (rnd() % 5) * 2 + 4
    out.append(f"hits {i} {b(hits(px, py, rw, rh))}")
def edges_x(w): return [F(c * TS) - w for c in range(-2, W2 + 3)]
def move(x, y, w, h, dx, dy):
    x, y, w, h, dx, dy = map(F, (x, y, w, h, dx, dy))
    n = math.floor(1 + (abs(dx) + abs(dy)) / F(TS, 2)); sx = dx / n; sy = dy / n
    for _ in range(n):
        if sx != 0:
            t = x + sx
            if not hits(t, y, w, h): x = t
            else:
                cand = [c for c in ([F(c * TS) - w for c in range(-2, W2 + 3)] if sx > 0 else [F(c * TS) for c in range(-2, W2 + 3)] ) + [x]
                        if min(x, t) <= c <= max(x, t) and not hits(c, y, w, h)]
                x = max(cand) if sx > 0 else min(cand)
        if sy != 0:
            t = y + sy
            if not hits(x, t, w, h): y = t
            else:
                cand = [c for c in ([F(c * TS) - h for c in range(-2, H2 + 3)] if sy > 0 else [F(c * TS) for c in range(-2, H2 + 3)]) + [y]
                        if min(y, t) <= c <= max(y, t) and not hits(x, c, w, h)]
                y = max(cand) if sy > 0 else min(cand)
    return x, y
def scaled(v): return int(math.floor(float(v) * 10000.0 + 0.5))
for i in range(250):
    px = rnd() % 1280 * 0.25; py = rnd() % 960 * 0.25; rw = (rnd() % 5) * 2 + 4; rh = (rnd() % 5) * 2 + 4
    dx = (rnd() % 385 - 192) * 0.25; dy = (rnd() % 385 - 192) * 0.25
    if hits(px, py, rw, rh): out.append(f"move {i} skip")
    else:
        nx, ny = move(px, py, rw, rh, dx, dy); out.append(f"move {i} {scaled(nx)} {scaled(ny)}")
print("\n".join(out))
