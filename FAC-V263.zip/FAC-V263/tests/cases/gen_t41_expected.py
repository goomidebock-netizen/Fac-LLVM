#!/usr/bin/env python3
"""ค่าคาดหวังของ t41_game_loop จากโมเดล accumulator แบบจำนวนเต็มที่เขียนแยกอิสระ (ไม่ได้อ่านโค้ด Fac)  ใช้: python3 gen_t41_expected.py > t41_game_loop.out"""
def scen(name, hz, cap, els):
    upd = 10**9 // hz; acc = 0; total = 0; out = []
    for i, e in enumerate(els):
        e = max(0, min(e, 250_000_000)); acc += e; n = 0
        while acc >= upd and n < cap: n += 1; acc -= upd
        if acc >= upd: acc = 0          # เกินเพดาน: ทิ้งส่วนที่ค้าง
        total += n
        out.append(f"{name} f{i} u={n} a={int(acc / upd * 1000.0 + 0.5)}")
    sim = total * upd / 1e9
    out.append(f"{name} total updates={total} frames={len(els)} draws={len(els)} sim={sim!r}")
    return out
L = []
a = [20_000_000] * 5
L += scen("A", 50, 5, a) + scen("B", 100, 5, a)
L += scen("C", 50, 5, [30_000_000, 30_000_000, 5_000_000, 45_000_000, 0, 90_000_000, 250_000_000, 17_000_000, -5_000_000, 999_999_999])
L += scen("D", 50, 3, [100_000_000, 20_000_000, 40_000_000])
# E: 5 fps -> 200ms/เฟรม ที่ 50Hz = 10 update ต่อเฟรม แต่เพดาน 5 และ quit ที่ update ที่ 3 -> updates=3 draws=1 frames=1
L.append("E quit: updates=3 draws=1 quitting=true frames=1")
# F: 25 เฟรม x 20ms ที่ 100Hz (10ms) = 2 update/เฟรม = 50 update, เวลาจำลอง 0.5s, dt=0.01
L.append(f"F simulate: updates=50 draws=25 time={50 * 10_000_000 / 1e9!r} dt={10_000_000 / 1e9!r}")
L.append(f"F dt60={(10**9 // 60) / 1e9!r}")
for w in ("hz=0", "hz=1001", "cap=0", "sim fps=0", "run fps=5000"): L.append(f"{w} -> code=2")
L.append("G run: updates=30 drawsOk=true paced=true bounded=true quitting=true")
print("\n".join(L))
