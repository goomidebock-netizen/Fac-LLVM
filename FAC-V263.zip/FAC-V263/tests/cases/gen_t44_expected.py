#!/usr/bin/env python3
"""oracle ของ t44_camera_anim_input (เขียนแยกจาก stdlib/camera.fac, anim.fac, input.fac)
  - camera: สูตรคณิตศาสตร์ตรงๆ (exp, floor) และตัวเลขที่ตรวจด้วยมือ; anim: โมเดลเวลาแบบจำนวนเต็มนาโนวินาที
  - Anim.draw: ประกอบภาพทีละพิกเซลปลายทาง -> พิกเซลใน sprite (พลิก = ย้อนคอลัมน์) -> ผสม alpha
  - input: เครื่องสถานะระดับ action (down = มีคีย์ใดคีย์หนึ่งกด; pressed = down และเฟรมก่อนไม่ down; released = ตรงข้าม)
ใช้: python3 tests/cases/gen_t44_expected.py > tests/cases/t44_camera_anim_input.out"""
import math, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets"))
from game_assets import hero_pixel, mix, pack
out = []
def scaled(v): return int(math.floor(v * 1000000.0 + 0.5))
# ---------- Camera ----------
out += ["snap center: 120.0 90.0", "snap topleft clamp: 0.0 0.0", "snap botright clamp: 240.0 180.0", "small world centered: -30.0 -20.0"]
cx, cy = 37.5, -12.25
out.append(f"transform: {100.0 - cx!r} {0.0 - cy!r} {62.5 + cx!r} {12.25 + cy!r} px={math.floor(cx)} py={math.floor(cy)}")
out.append(f"floor: {math.floor(-30.5)} {math.floor(12.9)}")
def sees(x, y, w, h, camx=100.0, camy=100.0, vw=160, vh=120): return x < camx + vw and x + w > camx and y < camy + vh and y + h > camy
out.append("sees: " + "".join(str(int(sees(*r))) for r in [(0, 0, 100, 100), (0, 0, 100.5, 100.5), (259.5, 219.5, 10, 10), (260, 219.5, 10, 10), (150, 150, 1, 1)]))
def follow(n, dt, speed=4.0, tx=500.0, ty=300.0, vw=100, vh=100):
    x = y = 0.0; k = 1.0 - math.exp(0.0 - speed * dt)
    for _ in range(n): x += (tx - vw / 2.0 - x) * k; y += (ty - vh / 2.0 - y) * k
    return x, y
fx, fy = follow(30, 1.0 / 60.0)
out.append(f"follow30: {scaled(fx)} {scaled(fy)}")
ax, ay = follow(60, 1.0 / 60.0); bx, by = follow(30, 1.0 / 30.0)
out.append(f"framerate independent: {int(abs(ax - bx) < 1e-9)} {int(abs(ay - by) < 1e-9)} x={scaled(ax)}")
out += ["speed<=0 snaps: -50.0 -50.0", "camera bad size code=2", "camera bad bounds code=2"]
# ---------- Anim (จำนวนเต็มนาโนวินาที) ----------
class A:
    def __init__(s, count, fps, loop): s.n = count; s.fns = int(1e9 / fps + 0.5); s.loop = loop; s.t = 0
    def upd(s, dt):
        if dt > 0:
            s.t += int(dt * 1e9 + 0.5); cyc = s.fns * s.n
            if s.loop: s.t %= cyc
            elif s.t > cyc: s.t = cyc
    def frame(s): return min(s.t // s.fns, s.n - 1)
    def fin(s): return (not s.loop) and s.t >= s.fns * s.n
a = A(4, 12.0, True)
for i, dt in enumerate([0.05, 0.05, 0.0, 0.2, 0.0833333, 1.0, -1.0, 0.0416667, 0.3333333]):
    a.upd(dt); out.append(f"loop f{i}: frame={a.frame()} cell={a.frame()} finished={int(a.fin())}")
o = A(3, 10.0, False)
for i in range(6):
    o.upd(0.1); out.append(f"once f{i}: frame={o.frame()} cell={4 + o.frame()} finished={int(o.fin())}")
o.upd(5.0); out.append(f"once after 5s: frame={o.frame()} finished={int(o.fin())}")
o.t = 0; out.append(f"once reset: frame={o.frame()} finished={int(o.fin())}")
out += ["anim bad fps code=2", "anim bad count code=2"]
# ---------- Anim.draw ----------
w8 = A(4, 8.0, True); w8.upd(0.26); cell = 8 + w8.frame(); out.append(f"walk cell={cell}")
BG = (10, 20, 30)
def sprite(sx, sy): return hero_pixel(cell // 4, cell % 4, sx, sy)       # ช่อง cell ของ sheet 4 คอลัมน์ ขนาด 16x16
def render(draws):
    img = [[BG] * 32 for _ in range(24)]
    for (X, Y, flip) in draws:
        for cy_ in range(24):
            for cx_ in range(32):
                sx, sy = cx_ - X, cy_ - Y
                if 0 <= sx < 16 and 0 <= sy < 16:
                    img[cy_][cx_] = mix(img[cy_][cx_], sprite(15 - sx if flip else sx, sy))
    s = 7
    for row in img:
        for p in row: s = (s * 31 + pack(p)) % 1000000007
    return s
out.append(f"draw plain sum={render([(4, 3, False)])}")
out.append(f"draw flip sum={render([(4, 3, True)])}")
out.append(f"draw clipped sum={render([(-5, -4, True), (20, 15, False), (24, -9, True), (-9, 18, False)])}")
# ---------- Input ----------
BIND = {"jump": ["space", "w"], "left": ["left", "a"], "right": ["right", "d"], "fire": ["ctrl"]}
keys = {}                  # คีย์เสมือนที่ inject
prev = {k: False for k in BIND}
def isdown(act): return any(keys.get(k, False) for k in BIND.get(act, []))
def fl(act, cur): return ("D" if cur[act] else "-") + ("P" if cur[act] and not prev[act] else "-") + ("R" if (not cur[act]) and prev[act] else "-")
out.append(f"bindings={sum(len(v) for v in BIND.values())}")
ops = ["", "+space", "", "+w", "-space", "-w", "+left,+d", "-d", "-left", "unbind", "+space", "bind", "-space"]
for f, op in enumerate(ops):
    if op == "unbind": BIND["jump"] = []
    if op == "bind": BIND["jump"] = ["space"]
    for t in op.split(","):
        if t.startswith("+"): keys[t[1:]] = True
        if t.startswith("-"): keys[t[1:]] = False
    cur = {k: isdown(k) for k in BIND}
    axis = (1.0 if cur["right"] else 0.0) - (1.0 if cur["left"] else 0.0)
    out.append(f"input f{f} [{op}] jump={fl('jump', cur)} left={fl('left', cur)} right={fl('right', cur)} fire={fl('fire', cur)} axis={axis!r} n={sum(len(v) for v in BIND.values())}")
    prev = dict(cur)
keys["ctrl"] = True; cur = {k: isdown(k) for k in BIND}; fd = fl("fire", cur); prev = dict(cur)
for k in keys: keys[k] = False
cur = {k: isdown(k) for k in BIND}
out.append(f"ctrl: {fd} then {fl('fire', cur)}")
out.append("cleared: n=0 jump=--- axis=0.0")
print("\n".join(out))
