#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
CXX=${CXX:-c++}
TMP=${TMPDIR:-/tmp}/fac-lexer-test-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
"$CXX" -std=c++17 -O2 -I"$ROOT/src" "$ROOT/tests/lexer/numeric_literals.cpp" "$ROOT/src/lexer.cpp" -o "$TMP/numeric_literals"
"$TMP/numeric_literals"
