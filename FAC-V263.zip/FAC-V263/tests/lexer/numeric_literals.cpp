#include "parser.hpp"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>

static int failures = 0;
static void check(bool ok, const char *label) {
  if (!ok) { std::cerr << "FAIL: " << label << "\n"; ++failures; }
}

static Tok one(const std::string &source) {
  const auto tokens = lex(source);
  if (tokens.size() != 2 || tokens[1].t != Tok::End)
    throw std::runtime_error("expected exactly one token");
  return tokens[0];
}

static void expectError(const std::string &source, const char *label) {
  try { (void)lex(source); check(false, label); }
  catch (const CompileError &) { check(true, label); }
}

int main() {
  try {
    Tok t = one("0"); check(t.t == Tok::Int && t.iv == 0 && !t.big, "decimal zero");
    t = one("9223372036854775807");
    check(t.t == Tok::Int && t.iv == INT64_MAX && !t.big, "signed long maximum");
    t = one("9223372036854775808");
    check(t.t == Tok::Int && t.iv == INT64_MIN && t.big, "signed long unary-minus boundary");
    t = one("1_234_567"); check(t.t == Tok::Int && t.iv == 1234567, "decimal separators");
    t = one("1.25"); check(t.t == Tok::Float && std::abs(t.dv - 1.25) < 1e-12, "decimal float");
    t = one("1_000.5"); check(t.t == Tok::Float && std::abs(t.dv - 1000.5) < 1e-12, "float with integer separator");
    t = one("1.25e-2"); check(t.t == Tok::Float && std::abs(t.dv - 0.0125) < 1e-12, "scientific notation");
    t = one("1_2.5e+2"); check(t.t == Tok::Float && std::abs(t.dv - 1250.0) < 1e-9, "separated scientific notation");
    t = one("0xFFFFFFFFFFFFFFFF"); check(t.t == Tok::Int && t.iv == -1, "hexadecimal 64-bit pattern");
    t = one("0xFFFF_FFFF"); check(t.t == Tok::Int && (uint32_t)t.iv == 0xFFFFFFFFu, "hex separators");
    t = one("0b1010_1101"); check(t.t == Tok::Int && t.iv == 173, "binary separators");
    t = one("0o7_7_7"); check(t.t == Tok::Int && t.iv == 511, "octal separators");

    expectError("9223372036854775809", "decimal overflow");
    expectError("0x10000000000000000", "hexadecimal overflow");
    expectError("0b102", "invalid binary digit");
    expectError("0o8", "invalid octal digit");
    expectError("0x", "missing hexadecimal digits");
    expectError("0b___", "separator-only binary literal");
  } catch (const std::exception &e) {
    std::cerr << "unexpected exception: " << e.what() << "\n";
    return 2;
  }
  if (failures) return 1;
  std::cout << "lexer numeric literals: 18 checks passed\n";
  return 0;
}
