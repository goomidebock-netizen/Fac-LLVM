#include "ast.hpp"

#include <iostream>
#include <memory>
#include <string>

int main() {
  auto original = std::make_unique<Node>(NK::Func, 7);
  original->s = "choose";
  original->lifetimeParams = {"long", "short"};
  original->lifetimeOutlives.emplace_back(0, 1);

  original->ts.kind = "ptr";
  original->ts.base = "int";
  original->ts.lifetime = "short";
  original->ts.lifetimeParamIndex = 1;
  original->ts.hasSize = true;
  original->ts.size = std::make_unique<Node>(NK::IntLit, 7);
  original->ts.size->iv = 4;

  TypeSpec functionType;
  functionType.base = "function";
  functionType.hasSig = true;
  functionType.genericArgName = "T";
  TypeSpec argumentType;
  argumentType.base = "string";
  functionType.sig.push_back(std::move(argumentType));
  functionType.sigReturnType = std::make_shared<TypeSpec>();
  functionType.sigReturnType->base = "bool";
  original->ts.genericArgs.push_back(std::move(functionType));

  Param parameter;
  parameter.name = "value";
  parameter.ts = cloneTypeSpec(original->ts);
  parameter.noescape = true;
  parameter.def = std::make_unique<Node>(NK::NullLit, 7);
  original->params.push_back(std::move(parameter));

  auto cloned = cloneNode(original.get());
  const bool copied = cloned && cloned.get() != original.get() &&
      cloned->s == "choose" && cloned->lifetimeParams == original->lifetimeParams &&
      cloned->lifetimeOutlives == original->lifetimeOutlives &&
      cloned->ts.lifetime == "short" && cloned->ts.lifetimeParamIndex == 1 &&
      cloned->ts.size && cloned->ts.size.get() != original->ts.size.get() &&
      cloned->ts.size->iv == 4 && cloned->params.size() == 1 &&
      cloned->params[0].name == "value" && cloned->params[0].noescape &&
      cloned->params[0].def &&
      cloned->ts.genericArgs.size() == 1 &&
      cloned->ts.genericArgs[0].sigReturnType &&
      cloned->ts.genericArgs[0].sigReturnType->base == "bool" &&
      cloned->ts.genericArgs[0].genericArgName == "T";

  if (!copied) {
    std::cerr << "AST model clone regression failed\n";
    return 1;
  }
  std::cout << "AST model regression: 1/1 passed\n";
  return 0;
}
