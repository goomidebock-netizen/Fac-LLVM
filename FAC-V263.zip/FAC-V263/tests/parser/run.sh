#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
CXX=${CXX:-c++}
TMP=${TMPDIR:-/tmp}/fac-parser-test-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
"$CXX" -std=c++17 -O2 -I"$ROOT/src" "$ROOT/tests/parser/parser_regression.cpp" "$ROOT/src/lexer.cpp" -o "$TMP/parser_regression"
"$CXX" -std=c++17 -O2 -I"$ROOT/src" "$ROOT/tests/parser/ast_model_regression.cpp" -o "$TMP/ast_model_regression"
"$TMP/ast_model_regression"
"$TMP/parser_regression"
"$CXX" -std=c++17 -O2 -I"$ROOT/src" "$ROOT/tests/parser/ast_model_regression.cpp" -o "$TMP/ast_model_regression"
"$TMP/ast_model_regression"
