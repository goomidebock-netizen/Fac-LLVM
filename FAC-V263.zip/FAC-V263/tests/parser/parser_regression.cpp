#include "parser.hpp"
#include <iostream>
#include <string>
#include <vector>

static int failures = 0;
static int checks = 0;
static void check(bool ok, const std::string &label) {
  ++checks;
  if (!ok) { std::cerr << "FAIL: " << label << "\n"; ++failures; }
}
static NP parse(const std::string &source) {
  Parser p; p.t = lex(source); NP n = p.parseExpr();
  if (p.cur().t != Tok::End) throw std::runtime_error("parser left trailing token: " + p.cur().s);
  return n;
}
static void assign(const std::string &op) {
  NP n = parse("left " + op + " right");
  check(n && n->k == NK::Assign && n->s == op && n->c.size() == 2, "assignment operator " + op);
}
int main() {
  try {
    const std::vector<std::string> assignments = {
      "=", "+=", "-=", "*=", "/=", "%=", "**=", "&=", "|=", "^=", "~=", "&&=", "||=", "<<=", ">>="
    };
    for (const auto &op : assignments) assign(op);

    check(Parser::isTypeWord("int") && Parser::isTypeWord("unichar"), "primitive type keywords are recognized");
    check(!Parser::isTypeWord("integer") && !Parser::isTypeWord("String"), "type-word lookup remains exact and case-sensitive");
    check(Parser::isReserved("readonly") && Parser::isReserved("static_assert"), "language keywords are recognized as reserved");
    check(Parser::isReserved("int") && Parser::isReserved("void"), "type words remain reserved identifiers");
    check(!Parser::isReserved("readonly_value") && !Parser::isReserved("terminal"), "ordinary identifiers are not reserved by prefix");

    {
      Parser lp; lp.t = lex("function lifetime<a, b> int choose(int value) { return value }");
      NP fn = lp.parseFunc();
      check(fn && fn->lifetimeParams.size() == 2 && fn->lifetimeParams[0] == "a" && fn->lifetimeParams[1] == "b",
            "named lifetime parameters are retained in function AST");
      check(lp.cur().t == Tok::End, "lifetime parameter declaration consumes complete function");
    }
    {
      bool duplicateLifetime = false;
      try { Parser lp; lp.t = lex("function lifetime<a, a> int choose(int value) { return value }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { duplicateLifetime = std::string(e.what()).find("lifetime parameter ซ้ำ") != std::string::npos; }
      check(duplicateLifetime, "duplicate named lifetime parameters are rejected");
    }
    {
      Parser lp;
      lp.t = lex("function lifetime<a> ptr<a> int choose(ptr<a> int left, ptr<a> int right) { return left }");
      NP fn = lp.parseFunc();
      check(fn && fn->ts.kind == "ptr" && fn->ts.base == "int" && fn->ts.lifetime == "a" && fn->ts.lifetimeParamIndex == 0,
            "pointer return lifetime is bound to its declared lifetime parameter index");
      check(fn && fn->params.size() == 2 && fn->params[0].ts.lifetimeParamIndex == 0 && fn->params[1].ts.lifetimeParamIndex == 0,
            "multiple pointer parameters can bind to the same named lifetime");
      NP cloned = cloneNode(fn.get());
      check(cloned && cloned->ts.lifetime == "a" && cloned->ts.lifetimeParamIndex == 0 &&
            cloned->params.size() == 2 && cloned->params[1].ts.lifetimeParamIndex == 0,
            "AST cloning preserves named lifetime bindings and parameter indices");
    }
    {
      bool unknownLifetime = false;
      try { Parser lp; lp.t = lex("function lifetime<a> int choose(ptr<b> int value) { return 0 }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { unknownLifetime = std::string(e.what()).find("ไม่พบ lifetime parameter 'b'") != std::string::npos; }
      check(unknownLifetime, "pointer annotations must resolve to a declared lifetime parameter");
    }
    {
      bool missingLifetime = false;
      try { Parser lp; lp.t = lex("function ptr<a> int choose(ptr<a> int value) { return value }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { missingLifetime = std::string(e.what()).find("ต้องประกาศ function lifetime") != std::string::npos; }
      check(missingLifetime, "pointer annotations require a function lifetime declaration");
    }
    {
      bool unprovidedReturnLifetime = false;
      try { Parser lp; lp.t = lex("function lifetime<a> ptr<a> int choose(ptr<b> int value) { return value }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { unprovidedReturnLifetime = std::string(e.what()).find("ไม่พบ lifetime parameter 'b'") != std::string::npos; }
      check(unprovidedReturnLifetime, "return lifetime cannot be confused with another parameter lifetime");
    }
    {
      bool returnNeedsParameter = false;
      try { Parser lp; lp.t = lex("function lifetime<a> ptr<a> int choose(int value) { return null }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { returnNeedsParameter = std::string(e.what()).find("ต้องผูกกับ pointer parameter") != std::string::npos; }
      check(returnNeedsParameter, "pointer return lifetime must be supplied by a matching pointer parameter");
    }
    {
      bool nonPointerLifetime = false;
      try { Parser lp; lp.t = lex("function lifetime<a> var<a> int choose(int value) { return value }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { nonPointerLifetime = std::string(e.what()).find("ใช้ได้เฉพาะชนิด ptr") != std::string::npos; }
      check(nonPointerLifetime, "lifetime annotations are restricted to direct pointer types");
    }

    {
      Parser lp;
      lp.t = lex("function lifetime<a, b> ptr<b> int shorten(ptr<a> int value) where a: b { return value }");
      NP fn = lp.parseFunc();
      check(fn && fn->lifetimeOutlives.size() == 1 && fn->lifetimeOutlives[0] == std::make_pair(0, 1),
            "direct outlives constraint is resolved to ordered lifetime indices");
      check(fn && fn->ts.lifetimeParamIndex == 1 && fn->params[0].ts.lifetimeParamIndex == 0,
            "a longer-lived pointer parameter may supply a shorter-lived pointer return");
      NP cloned = cloneNode(fn.get());
      check(cloned && cloned->lifetimeOutlives == fn->lifetimeOutlives,
            "AST cloning preserves outlives relationships");
    }
    {
      Parser lp;
      lp.t = lex("function lifetime<a, b, c> ptr<c> int shorten(ptr<a> int value) where a: b, b: c { return value }");
      NP fn = lp.parseFunc();
      check(fn && fn->lifetimeOutlives.size() == 2 && fn->ts.lifetimeParamIndex == 2,
            "transitive outlives chain permits return at the shortest lifetime");
    }
    {
      bool reverseOutlivesRejected = false;
      try { Parser lp; lp.t = lex("function lifetime<a, b> ptr<a> int unsafePick(ptr<b> int value) where a: b { return value }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { reverseOutlivesRejected = std::string(e.what()).find("มี lifetime ยาวพอ") != std::string::npos; }
      check(reverseOutlivesRejected, "outlives relationship cannot be used in the unsafe reverse direction");
    }
    {
      bool unknownLonger = false;
      try { Parser lp; lp.t = lex("function lifetime<a> int f(int x) where missing: a { return x }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { unknownLonger = std::string(e.what()).find("ไม่พบ lifetime parameter 'missing'") != std::string::npos; }
      check(unknownLonger, "outlives constraints reject unknown longer lifetime names");
    }
    {
      bool unknownShorter = false;
      try { Parser lp; lp.t = lex("function lifetime<a> int f(int x) where a: missing { return x }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { unknownShorter = std::string(e.what()).find("ไม่พบ lifetime parameter 'missing'") != std::string::npos; }
      check(unknownShorter, "outlives constraints reject unknown shorter lifetime names");
    }
    {
      bool noLifetimeList = false;
      try { Parser lp; lp.t = lex("function int f(int x) where a: b { return x }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { noLifetimeList = std::string(e.what()).find("ต้องมี function lifetime") != std::string::npos; }
      check(noLifetimeList, "outlives clauses require a declared lifetime parameter list");
    }
    {
      bool duplicateOutlives = false;
      try { Parser lp; lp.t = lex("function lifetime<a, b> int f(int x) where a: b, a: b { return x }"); (void)lp.parseFunc(); }
      catch (const CompileError &e) { duplicateOutlives = std::string(e.what()).find("where lifetime constraint ซ้ำ") != std::string::npos; }
      check(duplicateOutlives, "duplicate outlives constraints are rejected");
    }
    {
      Parser gp;
      gp.t = lex("struct DefaultBox<T = int, const int N: positive = (2 * 8)> { array var T values[N] }");
      Program parsed = gp.parseProgram("defaults.fac");
      check(parsed.structs.size() == 1 && parsed.structs[0]->typeParams.size() == 2 &&
            parsed.structs[0]->genericHasDefault.size() == 2 &&
            parsed.structs[0]->genericHasDefault[0] && parsed.structs[0]->genericHasDefault[1] &&
            parsed.structs[0]->genericDefaults[0].base == "int" &&
            parsed.structs[0]->genericDefaults[1].constExpr,
            "generic type and const defaults are retained in declaration order");
      NP cloned = cloneNode(parsed.structs[0].get());
      check(cloned && cloned->genericHasDefault.size() == 2 &&
            cloned->genericDefaults[0].base == "int" && cloned->genericDefaults[1].constExpr,
            "AST cloning preserves generic type and const defaults");
    }
    {
      std::vector<TypeSpec> arguments(1);
      arguments[0].genericArgName = "N";
      arguments[0].isConstValue = true;
      arguments[0].constValue = 8;
      std::vector<bool> supplied;
      std::string diagnostic;
      const bool ordered = orderNamedGenericArgumentsWithDefaults(
          arguments, {"T", "N"}, {true, true}, supplied, diagnostic);
      check(ordered && arguments.size() == 2 && !supplied[0] && supplied[1] &&
            arguments[0].base.empty() && arguments[1].isConstValue &&
            arguments[1].constValue == 8,
            "partial named generic arguments leave explicit default slots for materialization");
    }
    {
      bool nonTrailingDefault = false;
      try {
        Parser gp;
        gp.t = lex("struct Invalid<T = int, U> { public T value }");
        (void)gp.parseProgram("invalid.fac");
      } catch (const CompileError &e) {
        nonTrailingDefault = std::string(e.what()).find("generic parameters ที่มี default ต้องอยู่ท้าย declaration") != std::string::npos;
      }
      check(nonTrailingDefault, "generic default parameters must be trailing");
    }
    {
      bool forwardTypeDefault = false;
      try {
        Parser gp;
        gp.t = lex("struct Invalid<U = T, T = int> { public U value }");
        (void)gp.parseProgram("forward-type-default.fac");
      } catch (const CompileError &e) {
        forwardTypeDefault = std::string(e.what()).find("อ้างถึง parameter ภายหลัง 'T'") != std::string::npos;
      }
      check(forwardTypeDefault, "type defaults reject references to later generic parameters");
    }
    {
      bool forwardConstDefault = false;
      try {
        Parser gp;
        gp.t = lex("struct Invalid<const int M = (N * 2), const int N = 4> { array var int values[M] }");
        (void)gp.parseProgram("forward-const-default.fac");
      } catch (const CompileError &e) {
        forwardConstDefault = std::string(e.what()).find("อ้างถึง parameter ภายหลัง 'N'") != std::string::npos;
      }
      check(forwardConstDefault, "const defaults reject references to later generic parameters");
    }
    {
      NP call = parse("make<N = (2 * 8), T = int>()");
      check(call && call->k == NK::Call && !call->c.empty() &&
            call->c[0]->ts.genericArgs.size() == 2 &&
            call->c[0]->ts.genericArgs[0].genericArgName == "N" &&
            call->c[0]->ts.genericArgs[0].constExpr &&
            call->c[0]->ts.genericArgs[1].genericArgName == "T" &&
            call->c[0]->ts.genericArgs[1].base == "int",
            "named generic type and const arguments are retained in source order");
    }
    {
      NP call = parse("value.make<N = (2 * 8), T = int>()");
      check(call && call->c[0]->k == NK::Member &&
            call->c[0]->explicitTypeArgs.size() == 2 &&
            call->c[0]->explicitTypeArgs[0].genericArgName == "N" &&
            call->c[0]->explicitTypeArgs[1].genericArgName == "T",
            "named generic method arguments are parsed without changing relational expressions");
    }
    {
      std::vector<TypeSpec> arguments(2);
      arguments[0].genericArgName = "N"; arguments[0].isConstValue = true; arguments[0].constValue = 8;
      arguments[1].genericArgName = "T"; arguments[1].base = "int";
      std::string diagnostic;
      const bool ordered = orderNamedGenericArguments(arguments, {"T", "N"}, diagnostic);
      check(ordered && arguments[0].base == "int" && arguments[0].genericArgName.empty() &&
            arguments[1].isConstValue && arguments[1].constValue == 8 &&
            arguments[1].genericArgName.empty(),
            "named generic argument mapping canonicalizes mixed type and const arguments");
    }
    {
      std::vector<TypeSpec> arguments(2);
      arguments[0].genericArgName = "T"; arguments[1].genericArgName = "T";
      std::string diagnostic;
      const bool ordered = orderNamedGenericArguments(arguments, {"T", "N"}, diagnostic);
      check(!ordered && diagnostic.find("ระบุ generic parameter 'T' ซ้ำ") != std::string::npos,
            "duplicate named generic arguments are rejected");
    }
    {
      bool outlivesIsReserved = Parser::isReserved("where");
      check(outlivesIsReserved, "where is reserved for lifetime relationship clauses");
    }

    NP n = parse("a = b = c");
    check(n->k == NK::Assign && n->s == "=" && n->c[1]->k == NK::Assign, "assignment remains right associative");

    n = parse("a + b * c");
    check(n->k == NK::Binary && n->s == "+" && n->c[1]->k == NK::Binary && n->c[1]->s == "*", "multiplication binds tighter than addition");
    n = parse("a << b + c");
    check(n->k == NK::Binary && n->s == "<<" && n->c[1]->k == NK::Binary && n->c[1]->s == "+", "addition binds tighter than shift");
    n = parse("a || b && c");
    check(n->k == NK::Binary && n->s == "||" && n->c[1]->k == NK::Binary && n->c[1]->s == "&&", "logical AND binds tighter than OR");
    n = parse("a ** b ** c");
    check(n->k == NK::Binary && n->s == "**" && n->c[1]->k == NK::Binary && n->c[1]->s == "**", "power remains right associative");
    n = parse("a++");
    check(n->k == NK::PostInc && n->s == "++", "post increment is not an assignment operator");
    n = parse("a && b");
    check(n->k == NK::Binary && n->s == "&&", "logical AND is not an assignment operator");
    n = parse("a ** b");
    check(n->k == NK::Binary && n->s == "**", "power is not an assignment operator");

    bool gotDiagnostic = false;
    try { (void)parse("a +="); }
    catch (const CompileError &e) { gotDiagnostic = e.line == 1 && std::string(e.what()).find("นิพจน์ไม่ถูกต้อง") != std::string::npos; }
    check(gotDiagnostic, "incomplete assignment keeps a source diagnostic");
    bool gotColumn = false;
    try { (void)parse("a +=\n  )"); }
    catch (const CompileError &e) { gotColumn = e.line == 2 && e.column == 3; }
    check(gotColumn, "parser diagnostic reports the unexpected token column");

    auto bomTokens = lex("\xEF\xBB\xBFname");
    check(bomTokens[0].column == 1, "UTF-8 BOM does not shift the first source column");
    auto commentTokens = lex("#* first line\nsecond line *#\n  value");
    check(commentTokens[0].line == 3 && commentTokens[0].column == 3, "block-comment newlines preserve token line and column");

    auto upPath = lex("for++(2) { for++(3) { for++.for++.i } }");
    bool sawUpPath = false;
    for (const auto &token : upPath) if (token.t == Tok::LoopUp)
      sawUpPath = token.iv == 1 && token.s == "for++.for++.i";
    check(sawUpPath, "nested ascending selector records the outer-loop depth");

    auto downPath = lex("for--(2) { for--(3) { for--.for--.i } }");
    bool sawDownPath = false;
    for (const auto &token : downPath) if (token.t == Tok::LoopForDown)
      sawDownPath = token.iv == 1 && token.s == "for--.for--.i";
    check(sawDownPath, "nested descending selector records the outer-loop depth");

    auto mixedPath = lex("for++(2) { for--(3) { for--.for++.i } }");
    bool sawMixedPath = false;
    for (const auto &token : mixedPath) if (token.t == Tok::LoopForDown)
      sawMixedPath = token.iv == 1 && token.s == "for--.for++.i";
    check(sawMixedPath, "mixed direction selector preserves inner-to-outer path");

    auto reverseMixedPath = lex("for--(2) { for++(3) { for++.for--.i } }");
    bool sawReverseMixedPath = false;
    for (const auto &token : reverseMixedPath) if (token.t == Tok::LoopUp)
      sawReverseMixedPath = token.iv == 1 && token.s == "for++.for--.i";
    check(sawReverseMixedPath, "ascending inner selector can address a descending outer loop");

    auto prefixPath = lex("++for(2) { --for(3) { --for.++for.i } }");
    bool sawPrefixPath = false;
    for (const auto &token : prefixPath) if (token.t == Tok::LoopDownFor)
      sawPrefixPath = token.iv == 1 && token.s == "--for.++for.i";
    check(sawPrefixPath, "legacy prefix loop selector supports mixed aliases");
  } catch (const std::exception &e) {
    std::cerr << "unexpected exception: " << e.what() << "\n";
    return 2;
  }
  if (failures) return 1;
  std::cout << "parser regression: " << checks << " checks passed\n";
  return 0;
}
