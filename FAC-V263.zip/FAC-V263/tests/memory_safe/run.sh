#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
T=$(mktemp -d "${TMPDIR:-/tmp}/fac-memory-safe.XXXXXXXX")
trap 'rm -rf "$T"' EXIT
pass=0
fail=0

if "$FAC_COMPILER" tests/memory_safe/good_basic.fac --memory-safe --emit-ll -O0 -o "$T/good.ll" >"$T/good.out" 2>"$T/good.err"; then
  if test -s "$T/good.ll" && grep -q 'llvm.sadd.with.overflow' "$T/good.ll"; then pass=$((pass+1)); else echo 'FAIL safe subset IR omitted overflow guard'; fail=$((fail+1)); fi
else
  echo 'FAIL safe subset rejected ordinary managed code'; cat "$T/good.err"; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/memory_safe/good_math.fac --memory-safe --emit-ll -O0 -o "$T/math.ll" >"$T/math.out" 2>"$T/math.err"; then pass=$((pass+1)); else echo 'FAIL safe pure math built-in rejected'; cat "$T/math.err"; fail=$((fail+1)); fi

# Checked borrows are part of the ownership-first safe subset. The profile
# enables strict ownership analysis before code generation.
for source in tests/memory_safe/good_ref_param.fac tests/memory_safe/good_local_borrow.fac tests/memory_safe/good_heap_object_field_borrow.fac tests/memory_safe/good_heap_nested_field_borrow.fac; do
  out="$T/$(basename "$source" .fac).ll"
  if "$FAC_COMPILER" "$source" --memory-safe --emit-ll -O0 -o "$out" >"$T/out" 2>"$T/err" && test -s "$out"; then
    pass=$((pass+1))
  else
    echo "FAIL --memory-safe rejected a statically checked borrow in $source"; cat "$T/err"; fail=$((fail+1))
  fi
done

# Exercise borrow aliases at runtime too, not only at LLVM-emission time.
for item in "good_ref_param:14" "good_local_borrow:9"; do
  name=${item%%:*}; expected=${item#*:}
  out="$T/$name"
  if "$FAC_COMPILER" "tests/memory_safe/$name.fac" --memory-safe -O0 -o "$out" >"$T/out" 2>"$T/err" && "$out" >"$T/run.out" 2>"$T/run.err" && grep -Fxq "$expected" "$T/run.out"; then
    pass=$((pass+1))
  else
    echo "FAIL checked borrow runtime smoke for $name"; cat "$T/err" "$T/run.err" "$T/run.out"; fail=$((fail+1))
  fi
done
if "$FAC_COMPILER" tests/memory_safe/good_heap_object_field_borrow.fac --memory-safe -O0 -o "$T/good_heap_object_field_borrow" >"$T/heap-borrow-build.out" 2>"$T/heap-borrow-build.err"; then
  if "$T/good_heap_object_field_borrow" >"$T/heap-borrow-run.out" 2>"$T/heap-borrow-run.err" && printf '15\n15\n' | diff -u - "$T/heap-borrow-run.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL managed heap-field borrow did not alias the object field'; cat "$T/heap-borrow-run.err" "$T/heap-borrow-run.out"; fail=$((fail+1)); fi
else echo 'FAIL memory-safe rejected a checked borrow of a managed object field'; cat "$T/heap-borrow-build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/memory_safe/good_heap_nested_field_borrow.fac --memory-safe -O0 -o "$T/good_heap_nested_field_borrow" >"$T/nested-heap-borrow-build.out" 2>"$T/nested-heap-borrow-build.err"; then
  if "$T/good_heap_nested_field_borrow" >"$T/nested-heap-borrow-run.out" 2>"$T/nested-heap-borrow-run.err" && printf '30\n50\n' | diff -u - "$T/nested-heap-borrow-run.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL nested managed heap-field borrows did not preserve disjoint aliases'; cat "$T/nested-heap-borrow-run.err" "$T/nested-heap-borrow-run.out"; fail=$((fail+1)); fi
else echo 'FAIL memory-safe rejected disjoint borrows of nested managed-object fields'; cat "$T/nested-heap-borrow-build.err"; fail=$((fail+1)); fi

# Managed objects, lists and payload enums stay available: the profile should
# constrain unsafe escape hatches, not disable all managed high-level code.
for source in tests/cases/t33_object_overwrite_cleanup.fac tests/cases/t57_object_list_init.fac tests/cases/t110_managed_payload_enum.fac; do
  if "$FAC_COMPILER" "$source" --memory-safe --emit-ll -O0 -o "$T/managed.ll" >"$T/out" 2>"$T/err"; then
    pass=$((pass+1))
  else
    echo "FAIL --memory-safe rejected managed-code fixture $source"; cat "$T/err"; fail=$((fail+1))
  fi
done
managed="$T/managed-object-smoke"
if "$FAC_COMPILER" tests/cases/t33_object_overwrite_cleanup.fac --memory-safe -O0 -o "$managed" >"$T/out" 2>"$T/err"; then
  if "$managed" >"$T/run.out" 2>"$T/run.err" && grep -Fq '99 payload' "$T/run.out"; then pass=$((pass+1));
  else echo 'FAIL managed object/list runtime smoke'; cat "$T/run.err" "$T/run.out"; fail=$((fail+1)); fi
else echo 'FAIL compiling managed object/list runtime smoke'; cat "$T/err"; fail=$((fail+1)); fi

for source in \
  tests/memory_safe/bad_pointer.fac \
  tests/memory_safe/bad_heap.fac \
  tests/memory_safe/bad_unsafe.fac \
  tests/memory_safe/bad_extern.fac \
  tests/memory_safe/bad_link.fac \
  tests/memory_safe/bad_raw_memory.fac \
  tests/memory_safe/bad_cstr.fac \
  tests/memory_safe/bad_builtin_handle.fac \
  tests/memory_safe/bad_shell_alias.fac \
  tests/memory_safe/bad_export.fac \
  tests/memory_safe/bad_file_handle.fac \
  tests/memory_safe/bad_thread_handle.fac \
  tests/memory_safe/bad_alias_ptr.fac
 do
  if "$FAC_COMPILER" "$source" --memory-safe --emit-ll -O0 -o "$T/bad.ll" >"$T/out" 2>"$T/err"; then
    echo "FAIL --memory-safe accepted $source"; fail=$((fail+1))
  elif grep -Fq 'memory-safe:' "$T/err"; then
    pass=$((pass+1))
  else
    echo "FAIL $source rejected without memory-safe diagnostic"; cat "$T/err"; fail=$((fail+1))
  fi
done

# Ref syntax is accepted only when the strict checker can prove the borrow safe.
for source in tests/memory_safe/bad_ref_param.fac tests/memory_safe/bad_ref_local.fac; do
  if "$FAC_COMPILER" "$source" --memory-safe --emit-ll -O0 -o "$T/bad-borrow.ll" >"$T/out" 2>"$T/err"; then
    echo "FAIL --memory-safe accepted an invalid borrow in $source"; fail=$((fail+1))
  elif grep -Fq 'strict-ownership:' "$T/err"; then
    pass=$((pass+1))
  else
    echo "FAIL invalid borrow did not fail through strict ownership analysis: $source"; cat "$T/err"; fail=$((fail+1))
  fi
done
if "$FAC_COMPILER" tests/memory_safe/bad_heap_object_field_borrow_owner_write.fac --memory-safe --emit-ll -O0 -o "$T/bad-heap-borrow.ll" >"$T/out" 2>"$T/err"; then
  echo 'FAIL --memory-safe allowed an owner write while a heap-field mutable borrow was live'; fail=$((fail+1))
elif grep -Fq "cannot modify owner 'cell' while an overlapping local borrow is active" "$T/err"; then pass=$((pass+1));
else echo 'FAIL heap-field borrow conflict produced an unexpected diagnostic'; cat "$T/err"; fail=$((fail+1)); fi
for source in tests/memory_safe/bad_heap_nested_field_owner_write.fac tests/memory_safe/bad_heap_nested_field_overlap.fac tests/memory_safe/bad_heap_nested_object_reference_borrow.fac; do
  if "$FAC_COMPILER" "$source" --memory-safe --emit-ll -O0 -o "$T/bad-nested-heap-borrow.ll" >"$T/out" 2>"$T/err"; then
    echo "FAIL --memory-safe accepted an overlapping nested heap-field borrow in $source"; fail=$((fail+1))
  elif grep -Fq 'strict-ownership:' "$T/err"; then pass=$((pass+1));
  else echo "FAIL nested heap-field borrow conflict produced an unexpected diagnostic: $source"; cat "$T/err"; fail=$((fail+1)); fi
done

# Reference bindings cannot live in module globals or aggregate fields.
for item in "bad_ref_global:ref local borrow ใช้ประกาศได้เฉพาะภายใน function/block" \
            "bad_ref_field:field ไม่สามารถเก็บ local ref borrow ได้"; do
  source=${item%%:*}; expected=${item#*:}
  if "$FAC_COMPILER" "tests/memory_safe/$source.fac" --memory-safe --emit-ll -O0 -o "$T/bad-storage.ll" >"$T/out" 2>"$T/err"; then
    echo "FAIL --memory-safe accepted non-local borrow storage in $source"; fail=$((fail+1))
  elif grep -Fq "$expected" "$T/err"; then
    pass=$((pass+1))
  else
    echo "FAIL borrow storage boundary produced an unexpected diagnostic: $source"; cat "$T/err"; fail=$((fail+1))
  fi
done

if "$FAC_COMPILER" tests/memory_safe/good_basic.fac --memory-safe --unsafe-fast --emit-ll -o "$T/unsafe.ll" >"$T/out" 2>"$T/err"; then
  echo 'FAIL --memory-safe accepted --unsafe-fast'; fail=$((fail+1))
elif grep -Fq -- '--safe ใช้ร่วมกับ' "$T/err"; then pass=$((pass+1))
else echo 'FAIL --unsafe-fast diagnostic'; cat "$T/err"; fail=$((fail+1)); fi

# Bounds and signed-overflow checks remain enabled in the profile.
for source in tests/memory_safe/bad_bounds_runtime.fac tests/memory_safe/bad_overflow_runtime.fac; do
  out="$T/$(basename "$source" .fac)"
  if "$FAC_COMPILER" "$source" --memory-safe -O0 -o "$out" >"$T/out" 2>"$T/err"; then
    if "$out" >"$T/run.out" 2>"$T/run.err"; then
      echo "FAIL memory-safety guard did not stop $source"; fail=$((fail+1))
    elif grep -Eqi 'index out of range|overflow' "$T/run.err"; then pass=$((pass+1))
    else echo "FAIL unexpected guard failure for $source"; cat "$T/run.err"; fail=$((fail+1)); fi
  else echo "FAIL could not compile guard test $source"; cat "$T/err"; fail=$((fail+1)); fi
done

# The profile must not accept caller-supplied native code or linker escape hatches.
if "$FAC_COMPILER" tests/memory_safe/good_basic.fac --memory-safe -lm --emit-ll -o "$T/link.ll" >"$T/out" 2>"$T/err"; then
  echo 'FAIL --memory-safe accepted external linker flags'; fail=$((fail+1))
elif grep -Fq -- '--memory-safe ไม่อนุญาต native objects' "$T/err"; then pass=$((pass+1))
else echo 'FAIL external linker flag diagnostic'; cat "$T/err"; fail=$((fail+1)); fi

printf 'memory-safe profile tests: pass=%s fail=%s\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
