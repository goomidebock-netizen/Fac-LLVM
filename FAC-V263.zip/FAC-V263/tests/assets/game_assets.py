#!/usr/bin/env python3
"""สร้าง asset 2D ที่ใช้ร่วมกันโดยตัวอย่างและเทสต์ (procedural, deterministic, ไม่ต้องใช้ Pillow) + ฟังก์ชันพิกเซลที่ oracle ของเทสต์เรียกใช้
   เขียน examples/assets/tiles.png (64x32 = 4x2 ไทล์ 16x16) และ hero.png (64x64 = 4x4 ช่อง 16x16)  ใช้: python3 tests/assets/game_assets.py [โฟลเดอร์ปลายทาง]"""
import os, struct, sys, zlib
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "examples", "assets")
def chunk(t, b): return struct.pack(">I", len(b)) + t + b + struct.pack(">I", zlib.crc32(t + b) & 0xffffffff)
def write_png(path, W, H, px):
    raw = b"".join(b"\x00" + bytes(c for x in range(W) for c in px(x, y)) for y in range(H))
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
def h(t, x, y): return (t * 131 + x * 31 + y * 17 + x * y * 7) % 256
def tile_pixel(t, x, y):   # t = 1..8
    n = h(t, x, y)
    if t == 1: return (60 + n % 20, 140 + n % 30, 50, 255)
    if t == 2: return (230, 110, 170, 255) if n % 23 == 0 else (60 + n % 20, 140 + n % 30, 50, 255)
    if t == 3: return (170 + n % 15, 140 + n % 15, 100, 255)
    if t == 4: return (90, 90, 100, 255) if (y % 8 == 0 or (x + (y // 8) * 8) % 16 == 0) else (150 + n % 20, 70, 60, 255)
    if t == 5: return (40, 90 + n % 20 + ((x + y) % 8) * 3, 180, 255)
    if t == 6:   # ต้นไม้: นอกวงกลมโปร่งใส, ขอบวงกลม alpha 128, ข้างในทึบ
        d2 = (x - 7.5) ** 2 + (y - 7.5) ** 2
        if d2 > 8.0 ** 2: return (0, 0, 0, 0)
        if d2 > 6.5 ** 2: return (20, 90, 30, 128)
        return (30 + n % 20, 110 + n % 25, 40, 255)
    if t == 7: return (220, 200, 140 + n % 10, 255)
    return (0, 0, 0, 110)       # t == 8: เงา (alpha คงที่ 110)
def tiles_px(x, y): return tile_pixel((y // 16) * 4 + x // 16 + 1, x % 16, y % 16)
def hero_pixel(row, frame, x, y):   # row 0 ลง, 1 ขึ้น, 2 ขวา, 3 ว่าง; ไม่สมมาตรซ้าย-ขวา เพื่อให้การพลิกตรวจได้
    bob = (frame % 2)               # ตัวขยับขึ้นลงตามเฟรม
    head = (x - 8) ** 2 + (y - (4 + bob)) ** 2 <= 9
    body = 5 <= x <= 10 and 7 + bob <= y <= 11
    leg_l = x in (5, 6) and 12 <= y <= 14 - (frame // 2 % 2)
    leg_r = x in (9, 10) and 12 <= y <= 13 + (frame // 2 % 2)
    arm = (x in (11, 12) and 8 + bob <= y <= 10 + bob) if row == 2 else (x == 4 and 8 + bob <= y <= 10 + bob)
    nose = (row == 2 and x == 12 and y == 4 + bob)
    base = [(220, 60, 60), (60, 90, 220), (60, 200, 90), (200, 200, 60)][row]
    if nose: return (255, 255, 255, 255)
    if head: return (240, 200, 160, 255)
    if body or arm: return (base[0], base[1], base[2], 255)
    if leg_l or leg_r: return (50, 50, 70, 255)
    return (0, 0, 0, 0)
def hero_px(x, y): return hero_pixel(y // 16, x // 16, x % 16, y % 16)
def pack(c): return (c[0] << 16) | (c[1] << 8) | c[2]
def mix(dst, src):   # ตรงกับ graphic.blend / blitAlpha: (s*a + d*(255-a)) / 255 ต่อ channel (จำนวนเต็ม)
    r, g, b, a = src
    if a == 0: return dst
    if a >= 255: return (r, g, b)
    return tuple((s * a + d * (255 - a)) // 255 for s, d in zip((r, g, b), dst))
if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    write_png(os.path.join(OUT, "tiles.png"), 64, 32, tiles_px); write_png(os.path.join(OUT, "hero.png"), 64, 64, hero_px); print("assets written")
