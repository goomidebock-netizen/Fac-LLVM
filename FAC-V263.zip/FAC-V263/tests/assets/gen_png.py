#!/usr/bin/env python3
"""สร้าง PNG ทดสอบด้วย encoder อิสระ (zlib + filter ครบ 5 แบบ + Adam7) พร้อมคำนวณค่าที่คาดหวังจากข้อมูลต้นทางโดยตรง
ใช้: python3 tests/assets/gen_png.py  -> เขียน tests/assets/png/*.png และ tests/cases/t38_png_decode.out"""
import zlib, struct, os, random
D = os.path.join(os.path.dirname(__file__), "png"); os.makedirs(D, exist_ok=True)
def chunk(t, b): return struct.pack(">I", len(b)) + t + b + struct.pack(">I", zlib.crc32(t + b) & 0xffffffff)
def pack_row(vals, depth):  # vals: ตัวอย่างต่อ channel เรียงต่อกัน -> bytes
    if depth == 8: return bytes(vals)
    if depth == 16: return b"".join(struct.pack(">H", v) for v in vals)
    out = bytearray(); acc = 0; nb = 0
    for v in vals:
        acc = (acc << depth) | v; nb += depth
        if nb == 8: out.append(acc); acc = 0; nb = 0
    if nb: out.append(acc << (8 - nb))
    return bytes(out)
def filt(ft, row, prev, bpp):
    o = bytearray()
    for i, x in enumerate(row):
        a = row[i - bpp] if i >= bpp else 0; b = prev[i]; c = prev[i - bpp] if i >= bpp else 0
        if ft == 0: p = 0
        elif ft == 1: p = a
        elif ft == 2: p = b
        elif ft == 3: p = (a + b) >> 1
        else:
            q = a + b - c; pa, pb, pc = abs(q - a), abs(q - b), abs(q - c); p = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
        o.append((x - p) & 255)
    return bytes(o)
CH = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}
def encode(name, W, H, ctype, depth, px, plte=None, trns=None, interlace=0):
    """px[y][x] = tuple ของตัวอย่างดิบต่อ channel"""
    chans = CH[ctype]; bpp = max(1, chans * depth // 8)
    passes = [(0, 0, 1, 1)] if not interlace else [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    raw = bytearray(); n = 0
    for xs, ys, dx, dy in passes:
        xs_ = list(range(xs, W, dx)); ys_ = list(range(ys, H, dy))
        if not xs_ or not ys_: continue
        prev = bytes(((len(xs_) * chans * depth + 7) // 8,)[0] * [0])
        for y in ys_:
            row = pack_row([v for x in xs_ for v in px[y][x]], depth)
            ft = n % 5; n += 1
            raw += bytes([ft]) + filt(ft, row, prev, bpp); prev = row
    out = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", W, H, depth, ctype, 0, 0, interlace))
    if plte: out += chunk(b"PLTE", bytes(c for e in plte for c in e))
    if trns is not None: out += chunk(b"tRNS", b"".join(struct.pack(">H", v) for v in trns) if ctype in (0, 2) else bytes(trns))   # gray/RGB: 16-bit ต่อ component
    z = zlib.compress(bytes(raw), 9); h = len(z) // 3 + 1
    out += chunk(b"IDAT", z[:h]) + chunk(b"IDAT", z[h:]) + chunk(b"IEND", b"")   # IDAT แยกหลาย chunk
    open(os.path.join(D, name + ".png"), "wb").write(out)
def rgba_of(ctype, depth, s, plte, trns):  # -> (r,g,b,a,hasAlpha) แบบ 8-bit ตามกติกา decoder (16-bit ใช้ byte สูง)
    m = (1 << depth) - 1
    t8 = (lambda v: v >> 8) if depth == 16 else (lambda v: v) if depth == 8 else (lambda v: v * 255 // m)
    if ctype == 0: g = t8(s[0]); a = 0 if (trns is not None and s[0] == trns[0]) else 255; return (g, g, g, a)
    if ctype == 2: a = 0 if (trns is not None and tuple(s) == tuple(trns)) else 255; return (t8(s[0]), t8(s[1]), t8(s[2]), a)
    if ctype == 3: e = plte[s[0]]; a = trns[s[0]] if trns is not None and s[0] < len(trns) else 255; return (e[0], e[1], e[2], a)
    if ctype == 4: g = t8(s[0]); return (g, g, g, t8(s[1]))
    return (t8(s[0]), t8(s[1]), t8(s[2]), t8(s[3]))
rnd = random.Random(12345)
CASES = []
def mk(name, W, H, ctype, depth, plte=None, trns=None, interlace=0, gen=None):
    m = (1 << depth) - 1
    px = [[tuple(rnd.randint(0, m) for _ in range(CH[ctype])) for _ in range(W)] for _ in range(H)]
    if gen: px = [[gen(x, y) for x in range(W)] for y in range(H)]
    if ctype == 3: px = [[(v[0] % len(plte),) for v in row] for row in px]
    if trns is not None and ctype == 0: px[1][2] = (trns[0],)
    if trns is not None and ctype == 2: px[1][2] = tuple(trns)
    encode(name, W, H, ctype, depth, px, plte, trns, interlace)
    CASES.append((name, W, H, ctype, depth, px, plte, trns))
pal16 = [(i * 16 % 256, 255 - i * 16 % 256, (i * 37) % 256) for i in range(16)]
mk("gray1", 19, 5, 0, 1); mk("gray2", 11, 6, 0, 2); mk("gray4", 9, 9, 0, 4, interlace=1); mk("gray8", 13, 7, 0, 8); mk("gray16", 6, 4, 0, 16)
mk("gray8_trns", 7, 5, 0, 8, trns=(77,))
mk("graya8", 10, 6, 4, 8); mk("graya16", 5, 5, 4, 16)
mk("rgb8", 17, 11, 2, 8); mk("rgb16", 7, 5, 2, 16); mk("rgb8_trns", 8, 4, 2, 8, trns=(10, 20, 30)); mk("rgb8_adam7", 23, 14, 2, 8, interlace=1)
mk("rgba8", 16, 16, 6, 8, gen=lambda x, y: (x * 16, y * 16, (x * y) % 256, (x + y) * 8)); mk("rgba16", 6, 3, 6, 16)
mk("rgba8_adam7", 21, 13, 6, 8, interlace=1); mk("rgba8_tiny", 1, 1, 6, 8); mk("rgba8_wide", 300, 2, 6, 8)
mk("pal1", 20, 4, 3, 1, plte=pal16[:2]); mk("pal2", 13, 5, 3, 2, plte=pal16[:4]); mk("pal4", 15, 5, 3, 4, plte=pal16, trns=[255, 128, 0, 64], interlace=1); mk("pal8", 12, 8, 3, 8, plte=pal16 * 4)
lines = []
for (name, W, H, ctype, depth, px, plte, trns) in CASES:
    cols = [[rgba_of(ctype, depth, px[y][x], plte, trns) for x in range(W)] for y in range(H)]
    has = ctype in (4, 6) or (trns is not None and ctype in (0, 2, 3))
    sr = sum(c[0] + c[1] + c[2] for r in cols for c in r); sa = sum(c[3] for r in cols for c in r)
    lines.append(f"{name} {W}x{H} alpha={'true' if has else 'false'} rgbsum={sr} alphasum={sa if has else W*H*255}")
    for (x, y) in [(0, 0), (W - 1, H - 1), (W // 2, H // 2)]:
        c = cols[y][x]; lines.append(f"  ({x},{y}) {c[0]*65536 + c[1]*256 + c[2]} a={c[3] if has else 255}")
open(os.path.join(os.path.dirname(__file__), "png_expected.txt"), "w").write("\n".join(lines) + "\n")
names = [c[0] for c in CASES]
open(os.path.join(os.path.dirname(__file__), "png_names.txt"), "w").write("\n".join(names) + "\n")
print(len(CASES), "files")

# ---------- ไฟล์เสียหาย (ต้อง throw Error ไม่ crash) ----------
BD = os.path.join(os.path.dirname(__file__), "png_bad"); os.makedirs(BD, exist_ok=True)
def parse(b):
    pos = 8; res = []
    while pos < len(b):
        ln = struct.unpack(">I", b[pos:pos+4])[0]; t = b[pos+4:pos+8]; res.append((t, b[pos+8:pos+8+ln])); pos += 12 + ln
    return res
def build(chs): return b"\x89PNG\r\n\x1a\n" + b"".join(chunk(t, d) for t, d in chs)
base = open(os.path.join(D, "rgba8_adam7.png"), "rb").read(); chs = parse(base)
def with_idat(f): return [(t, f(d)) if t == b"IDAT" else (t, d) for t, d in chs]
bad = {}
bad["truncated"] = base[:60]
bad["notpng"] = b"hello, this is not a png file at all\n" * 3
i = base.index(b"IDAT") + 10; bad["badcrc"] = base[:i] + bytes([base[i] ^ 0xFF]) + base[i+1:]
bad["badzlib"] = build(with_idat(lambda d: d[:6] + bytes(x ^ 0x5A for x in d[6:14]) + d[14:]))
bad["zerowidth"] = build([(t, struct.pack(">IIBBBBB", 0, 5, 8, 6, 0, 0, 0)) if t == b"IHDR" else (t, d) for t, d in chs])
bad["hugedim"] = build([(t, struct.pack(">IIBBBBB", 70000, 70000, 8, 6, 0, 0, 0)) if t == b"IHDR" else (t, d) for t, d in chs])
bad["badbitdepth"] = build([(t, struct.pack(">IIBBBBB", 4, 4, 16, 3, 0, 0, 0)) if t == b"IHDR" else (t, d) for t, d in chs])
bad["noiend"] = build([(t, d) for t, d in chs if t != b"IEND"])
bad["criticalchunk"] = build([chs[0], (b"ABCD", b"xx")] + chs[1:])
bad["nodata"] = build([chs[0], (b"IEND", b"")])
def refilter(d):
    raw = bytearray(zlib.decompress(d)); raw[0] = 9; return zlib.compress(bytes(raw))
bad["badfilter"] = build([(t, refilter(b"".join(d for tt, d in chs if tt == b"IDAT"))) if t == b"IDAT" else (t, d) for t, d in chs if t != b"IDAT"][:1] + [(b"IDAT", refilter(b"".join(d for tt, d in chs if tt == b"IDAT")))] + [(b"IEND", b"")])
def shortraw(d): return zlib.compress(zlib.decompress(d)[:-7])
bad["shortdata"] = build([chs[0], (b"IDAT", shortraw(b"".join(d for tt, d in chs if tt == b"IDAT"))), (b"IEND", b"")])
pi = [[(3,) for _ in range(4)] for _ in range(4)]   # index 3 แต่ PLTE มี 2 สี
encode("_tmp_pal", 4, 4, 3, 2, pi, plte=[(1, 2, 3), (4, 5, 6)]); bad["badpalette"] = open(os.path.join(D, "_tmp_pal.png"), "rb").read(); os.remove(os.path.join(D, "_tmp_pal.png"))
for k, v in bad.items(): open(os.path.join(BD, k + ".png"), "wb").write(v)
open(os.path.join(os.path.dirname(__file__), "png_bad_names.txt"), "w").write("\n".join(bad) + "\n")
print(len(bad), "bad files")
