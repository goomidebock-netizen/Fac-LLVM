#!/usr/bin/env python3
"""สร้างไฟล์ PNG กลายพันธุ์จาก tests/assets/png (แก้ CRC ให้ถูกเพื่อให้ความเสียหายไปถึง inflate/unfilter) ใช้: gen_mutants.py OUTDIR [N] [SEED]"""
import os, random, struct, sys, zlib
out = sys.argv[1]; n = int(sys.argv[2]) if len(sys.argv) > 2 else 600; seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
os.makedirs(out, exist_ok=True); rnd = random.Random(seed)
src = os.path.join(os.path.dirname(__file__), "..", "assets", "png"); files = sorted(os.listdir(src))
def parse(b):
    pos = 8; res = []
    while pos + 12 <= len(b):
        ln = struct.unpack(">I", b[pos:pos+4])[0]; res.append([b[pos+4:pos+8], bytearray(b[pos+8:pos+8+ln])]); pos += 12 + ln
    return res
def build(chs): return b"\x89PNG\r\n\x1a\n" + b"".join(struct.pack(">I", len(d)) + t + bytes(d) + struct.pack(">I", zlib.crc32(t + bytes(d)) & 0xffffffff) for t, d in chs)
names = []
for k in range(n):
    chs = parse(open(os.path.join(src, rnd.choice(files)), "rb").read()); mode = rnd.randint(0, 5)
    tgt = [c for c in chs if c[0] == (b"IDAT" if mode < 3 else rnd.choice([b"IHDR", b"IHDR", b"PLTE", b"tRNS", b"IDAT"]))] or chs
    c = rnd.choice(tgt)
    if c[1]:
        for _ in range(rnd.randint(1, 4)):
            i = rnd.randrange(len(c[1])); c[1][i] = rnd.randrange(256) if rnd.random() < .7 else c[1][i] ^ (1 << rnd.randrange(8))
    if mode == 5 and len(chs) > 3: del chs[rnd.randrange(1, len(chs) - 1)]
    if mode == 4 and c[0] == b"IDAT": c[1] = c[1][:rnd.randrange(len(c[1]) + 1)]
    name = "m%04d" % k; open(os.path.join(out, name + ".png"), "wb").write(build(chs)); names.append(name)
open(os.path.join(out, "list.txt"), "w").write("\n".join(names) + "\n")
