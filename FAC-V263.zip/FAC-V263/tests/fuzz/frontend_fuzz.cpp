#include "parser.hpp"

#include <algorithm>
#include <cstdint>
#include <iostream>
#include <random>
#include <string>
#include <vector>

namespace {
constexpr uint64_t kSeed = 0xFAC0172A5EEDULL;
constexpr size_t kCases = 5000;
constexpr size_t kMaxSourceBytes = 2048;

const std::vector<std::string> kSeeds = {
    "function int main() { return 0 }",
    "function int add(int a, int b) { return a + b }",
    "struct Pair { int left; int right }",
    "enum Maybe { None, Some(int) }",
    "function void f() { if (true) { var int x = 1 } else { return } }",
    "function int f(int n) { for++(n) { if (i == 2) continue } return n }",
    "function int f() { try { throw Error(\"x\", 1) } catch (Error e) { return e.code } }",
    "static_assert(1 + 2 == 3, \"math\")",
    "function string f(string s) { return \"value={s}\" }",
    "import terminal.fac\nfunction int main() { return 0 }",
    "function int broken( { return ;",
    "class Box<T> { T value; }",
    "function int f() { return (((((((1))))))) }",
};

const std::string kAlphabet =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
    "{}[]();,:.+-*/%<>=!&|^~?#\\\"' \t\r\n";

std::string randomBytes(std::mt19937_64 &rng, size_t maxSize) {
  std::uniform_int_distribution<size_t> sizeDist(0, maxSize);
  std::uniform_int_distribution<unsigned> byteDist(0, 255);
  const size_t size = sizeDist(rng);
  std::string out(size, '\0');
  for (char &c : out) c = static_cast<char>(byteDist(rng));
  return out;
}

std::string mutate(const std::string &base, std::mt19937_64 &rng) {
  std::string out = base;
  std::uniform_int_distribution<int> opCountDist(1, 10);
  std::uniform_int_distribution<int> opDist(0, 5);
  std::uniform_int_distribution<unsigned> byteDist(0, 255);
  std::uniform_int_distribution<size_t> alphaDist(0, kAlphabet.size() - 1);

  for (int op = 0, count = opCountDist(rng); op < count; ++op) {
    const int kind = opDist(rng);
    if (kind == 0 && !out.empty()) { // overwrite one byte, including invalid UTF-8
      std::uniform_int_distribution<size_t> at(0, out.size() - 1);
      out[at(rng)] = static_cast<char>(byteDist(rng));
    } else if (kind == 1 && out.size() < kMaxSourceBytes) { // insert token-like byte
      std::uniform_int_distribution<size_t> at(0, out.size());
      out.insert(out.begin() + static_cast<std::ptrdiff_t>(at(rng)), kAlphabet[alphaDist(rng)]);
    } else if (kind == 2 && !out.empty()) { // delete a bounded span
      std::uniform_int_distribution<size_t> at(0, out.size() - 1);
      const size_t begin = at(rng);
      std::uniform_int_distribution<size_t> length(1, std::min<size_t>(32, out.size() - begin));
      out.erase(begin, length(rng));
    } else if (kind == 3 && out.size() < kMaxSourceBytes) { // append hostile byte sequence
      static const unsigned char hostile[] = {0x00, 0x80, 0xC0, 0xC1, 0xED, 0xF0, 0xF4, 0xFF};
      std::uniform_int_distribution<size_t> at(0, out.size());
      std::uniform_int_distribution<size_t> which(0, sizeof(hostile) - 1);
      out.insert(out.begin() + static_cast<std::ptrdiff_t>(at(rng)),
                 static_cast<char>(hostile[which(rng)]));
    } else if (kind == 4) { // append a structurally interesting tail
      static const std::vector<std::string> tails = {
          "\"", "\\", "} } }", "((((((", "/*", "#* unterminated", "for++.for--.",
          "0xFFFFFFFFFFFFFFFFF", "\\uD800", "\xEF\xBB\xBF", "\n;\n"};
      std::uniform_int_distribution<size_t> which(0, tails.size() - 1);
      const std::string &tail = tails[which(rng)];
      if (out.size() + tail.size() <= kMaxSourceBytes) out += tail;
    } else if (kind == 5 && out.size() < kMaxSourceBytes) { // splice a random token
      static const std::vector<std::string> tokens = {
          "function", "return", "int", "string", "dyn", "ptr", "new", "match",
          "case", "try", "catch", "static_assert", "==", "=>", "?.", "...", "\n"};
      std::uniform_int_distribution<size_t> at(0, out.size());
      std::uniform_int_distribution<size_t> which(0, tokens.size() - 1);
      const std::string &token = tokens[which(rng)];
      if (out.size() + token.size() <= kMaxSourceBytes)
        out.insert(at(rng), token);
    }
  }
  return out;
}

bool checkTokenStream(const std::vector<Tok> &tokens, size_t caseNo) {
  if (tokens.empty() || tokens.back().t != Tok::End) {
    std::cerr << "fuzz case " << caseNo << ": lexer omitted terminal End token\n";
    return false;
  }
  for (size_t i = 0; i + 1 < tokens.size(); ++i) {
    if (tokens[i].t == Tok::End) {
      std::cerr << "fuzz case " << caseNo << ": early End token at index " << i << '\n';
      return false;
    }
  }
  return true;
}
} // namespace

int main() {
  std::mt19937_64 rng(kSeed);
  std::uniform_int_distribution<size_t> seedDist(0, kSeeds.size() - 1);
  std::uniform_int_distribution<int> modeDist(0, 4);
  size_t lexRejected = 0;
  size_t parserRejected = 0;
  size_t accepted = 0;

  for (size_t i = 0; i < kCases; ++i) {
    std::string source;
    switch (modeDist(rng)) {
      case 0: source = kSeeds[seedDist(rng)]; break;
      case 1: source = mutate(kSeeds[seedDist(rng)], rng); break;
      case 2: source = randomBytes(rng, 512); break;
      case 3: source = mutate(randomBytes(rng, 256), rng); break;
      default: {
        const size_t depth = static_cast<size_t>(rng() % 1800);
        source = "function int deep() { return ";
        source.append(depth, '(');
        source += "1";
        source.append(depth, ')');
        source += " }";
        break;
      }
    }

    try {
      std::vector<Tok> tokens = lex(source);
      if (!checkTokenStream(tokens, i)) return 1;
      try {
        Parser parser;
        parser.t = std::move(tokens);
        (void)parser.parseProgram("<frontend-fuzz>");
        ++accepted;
      } catch (const CompileError &) {
        ++parserRejected;
      }
    } catch (const CompileError &) {
      ++lexRejected;
    } catch (const std::exception &e) {
      std::cerr << "fuzz case " << i << ": unexpected exception: " << e.what() << '\n';
      return 2;
    }
  }

  std::cout << "frontend fuzz: PASS seed=" << kSeed
            << " cases=" << kCases
            << " accepted=" << accepted
            << " lex-rejected=" << lexRejected
            << " parser-rejected=" << parserRejected << '\n';
  return 0;
}
