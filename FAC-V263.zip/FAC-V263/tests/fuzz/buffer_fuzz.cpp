#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <limits>
#include <random>
#include <string>
#include <vector>

struct FacStr { char *data; int64_t len, cap, ncp, flags; };
extern "C" {
void fac_str_free(FacStr *);
void *fac_gpu_buffer_create(int64_t);
void fac_gpu_buffer_free(void *);
int64_t fac_gpu_buffer_size(void *);
int32_t fac_gpu_buffer_write(void *, int64_t, FacStr *);
FacStr *fac_gpu_buffer_read(void *, int64_t, int64_t);
int32_t fac_gpu_buffer_copy(void *, int64_t, void *, int64_t, int64_t);
}

namespace {
constexpr uint64_t kSeed = 0xB0FF3A5EEDULL;
constexpr size_t kOperations = 30000;

std::string readBytes(void *buffer, int64_t offset, int64_t length) {
  FacStr *result = fac_gpu_buffer_read(buffer, offset, length);
  if (!result) throw std::runtime_error("buffer read returned null for a valid range");
  std::string bytes(result->data, static_cast<size_t>(result->len));
  fac_str_free(result);
  return bytes;
}

bool verify(void *buffer, const std::vector<uint8_t> &expected, size_t step) {
  if (fac_gpu_buffer_size(buffer) != static_cast<int64_t>(expected.size())) {
    std::cerr << "buffer fuzz step " << step << ": reported size mismatch\n";
    return false;
  }
  const std::string actual = readBytes(buffer, 0, static_cast<int64_t>(expected.size()));
  if (actual.size() != expected.size() ||
      (!expected.empty() && std::memcmp(actual.data(), expected.data(), expected.size()) != 0)) {
    size_t at = 0;
    while (at < actual.size() && at < expected.size() &&
           static_cast<uint8_t>(actual[at]) == expected[at]) ++at;
    std::cerr << "buffer fuzz step " << step << ": byte model mismatch at byte " << at
              << " expected=" << (at < expected.size() ? static_cast<unsigned>(expected[at]) : 999u)
              << " actual=" << (at < actual.size() ? static_cast<unsigned char>(actual[at]) : 999u) << '\n';
    return false;
  }
  return true;
}

int64_t randomOffset(std::mt19937_64 &rng, size_t size) {
  switch (rng() % 8) {
    case 0: return -1;
    case 1: return 0;
    case 2: return static_cast<int64_t>(size);
    case 3: return static_cast<int64_t>(size) + 1;
    case 4: return std::numeric_limits<int64_t>::max();
    case 5: return std::numeric_limits<int64_t>::min();
    default: {
      const int64_t span = static_cast<int64_t>(size) + 4;
      return static_cast<int64_t>(rng() % static_cast<uint64_t>(span)) - 2;
    }
  }
}
} // namespace

int main() {
  std::mt19937_64 rng(kSeed);
  const size_t sizeA = static_cast<size_t>(rng() % 257);
  const size_t sizeB = static_cast<size_t>(rng() % 257);
  void *a = fac_gpu_buffer_create(static_cast<int64_t>(sizeA));
  void *b = fac_gpu_buffer_create(static_cast<int64_t>(sizeB));
  if (!a || !b) return 1;
  std::vector<uint8_t> modelA(sizeA, 0), modelB(sizeB, 0);
  std::vector<uint8_t> *models[] = {&modelA, &modelB};
  void *buffers[] = {a, b};
  std::string lastOp;

  for (size_t step = 0; step < kOperations; ++step) {
    const unsigned op = static_cast<unsigned>(rng() % 4);
    const unsigned dstIndex = static_cast<unsigned>(rng() & 1u);
    auto &dstModel = *models[dstIndex];
    void *dst = buffers[dstIndex];

    if (op == 0) { // write random arbitrary bytes, including NUL and invalid UTF-8
      const int64_t offset = randomOffset(rng, dstModel.size());
      const size_t length = static_cast<size_t>(rng() % 65);
      std::string payload(length, '\0');
      for (char &ch : payload) ch = static_cast<char>(rng() & 0xffu);
      // The C ABI write call borrows the FacStr only for this call. Construct
      // the ABI view directly so embedded NUL bytes are preserved in this
      // binary-buffer test (fac_str_from_chars intentionally treats input as
      // a NUL-terminated text string).
      FacStr value{payload.data(), static_cast<int64_t>(payload.size()),
                   static_cast<int64_t>(payload.size()), static_cast<int64_t>(payload.size()), 0};
      const bool valid = offset >= 0 && offset <= static_cast<int64_t>(dstModel.size()) &&
          static_cast<uint64_t>(length) <= dstModel.size() - static_cast<size_t>(offset);
      const int32_t result = fac_gpu_buffer_write(dst, offset, &value);
      lastOp = "write index=" + std::to_string(dstIndex) + " offset=" + std::to_string(offset) + " len=" + std::to_string(length) + " valid=" + std::to_string(valid);
      if ((result != 0) != valid) {
        std::cerr << "buffer fuzz step " << step << ": write validation mismatch\n";
        return 3;
      }
      if (valid && length) std::copy(payload.begin(), payload.end(), dstModel.begin() + offset);
    } else if (op == 1) { // copy, including same-buffer memmove overlap
      const unsigned srcIndex = (rng() % 3 == 0) ? dstIndex : static_cast<unsigned>(rng() & 1u);
      auto &srcModel = *models[srcIndex];
      void *src = buffers[srcIndex];
      const int64_t dstOffset = randomOffset(rng, dstModel.size());
      const int64_t srcOffset = randomOffset(rng, srcModel.size());
      int64_t length = 0;
      switch (rng() % 7) {
        case 0: length = -1; break;
        case 1: length = std::numeric_limits<int64_t>::max(); break;
        case 2: length = 0; break;
        default: length = static_cast<int64_t>(rng() % 65); break;
      }
      const bool valid = dstOffset >= 0 && srcOffset >= 0 && length >= 0 &&
          dstOffset <= static_cast<int64_t>(dstModel.size()) &&
          srcOffset <= static_cast<int64_t>(srcModel.size()) &&
          length <= static_cast<int64_t>(dstModel.size()) - dstOffset &&
          length <= static_cast<int64_t>(srcModel.size()) - srcOffset;
      const int32_t result = fac_gpu_buffer_copy(dst, dstOffset, src, srcOffset, length);
      lastOp = "copy dst=" + std::to_string(dstIndex) + " src=" + std::to_string(srcIndex) + " doff=" + std::to_string(dstOffset) + " soff=" + std::to_string(srcOffset) + " len=" + std::to_string(length) + " valid=" + std::to_string(valid);
      if ((result != 0) != valid) {
        std::cerr << "buffer fuzz step " << step << ": copy validation mismatch\n";
        return 4;
      }
      if (valid && length) {
        std::vector<uint8_t> snapshot(srcModel.begin() + srcOffset,
                                     srcModel.begin() + srcOffset + length);
        std::copy(snapshot.begin(), snapshot.end(), dstModel.begin() + dstOffset);
      }
    } else if (op == 2) { // read an always-valid random range
      const size_t offset = dstModel.empty() ? 0 : static_cast<size_t>(rng() % (dstModel.size() + 1));
      const size_t maxLength = dstModel.size() - offset;
      const size_t length = maxLength ? static_cast<size_t>(rng() % (maxLength + 1)) : 0;
      lastOp = "read index=" + std::to_string(dstIndex) + " offset=" + std::to_string(offset) + " len=" + std::to_string(length);
      const std::string actual = readBytes(dst, static_cast<int64_t>(offset), static_cast<int64_t>(length));
      if (actual.size() != length ||
          (length && std::memcmp(actual.data(), dstModel.data() + offset, length) != 0)) {
        std::cerr << "buffer fuzz step " << step << ": read mismatch\n";
        return 5;
      }
    } else { // self-copy with overlapping and boundary cases
      const int64_t offset = randomOffset(rng, dstModel.size());
      const int64_t count = static_cast<int64_t>(rng() % 33);
      const bool valid = offset >= 0 && offset <= static_cast<int64_t>(dstModel.size()) &&
          count <= static_cast<int64_t>(dstModel.size()) - offset;
      lastOp = "self-copy index=" + std::to_string(dstIndex) + " offset=" + std::to_string(offset) + " len=" + std::to_string(count) + " valid=" + std::to_string(valid);
      const int32_t result = fac_gpu_buffer_copy(dst, offset, dst, offset, count);
      if ((result != 0) != valid) {
        std::cerr << "buffer fuzz step " << step << ": self-copy validation mismatch\n";
        return 6;
      }
      // Exact self-copy leaves the model unchanged.
    }

    if (!verify(a, modelA, step) || !verify(b, modelB, step)) {
      std::cerr << "last operation: " << lastOp << '\n';
      return 7;
    }
  }

  fac_gpu_buffer_free(b);
  fac_gpu_buffer_free(a);
  std::cout << "buffer fuzz: PASS seed=" << kSeed
            << " operations=" << kOperations
            << " sizes=" << sizeA << ',' << sizeB << '\n';
  return 0;
}
