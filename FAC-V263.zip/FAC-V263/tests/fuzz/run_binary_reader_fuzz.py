#!/usr/bin/env python3
"""Deterministic malformed-FACB mutation corpus executed by the FAC BinaryReader.

This is a bounded regression/fuzz corpus, not a coverage-guided fuzzer. It builds
valid V2 headers and CRC32 trailers around deliberately malformed record bodies,
then compiles one FAC harness that exercises the real stdlib decoder.
"""
from __future__ import annotations

import argparse
import pathlib
import struct
import subprocess
import tempfile
import zlib

ROOT = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = b"tests.v158"
RECORD = b"Fuzz"
MALFORMED_CASE_COUNT = 19


def u32(value: int) -> bytes:
    return struct.pack("<I", value)


def blob(data: bytes) -> bytes:
    return u32(len(data)) + data


def packet(
    fields: list[tuple[bytes, int, bytes]],
    *,
    count: int | None = None,
    tail: bytes = b"",
    record_name: bytes = RECORD,
) -> bytes:
    out = bytearray(b"FACB")
    out += struct.pack("<HHH", 2, 1, 1)  # format, CRC32 flag, schema version
    out += blob(SCHEMA)
    out += b"R" + blob(record_name)
    out += u32(len(fields) if count is None else count)
    for name, tag, payload in fields:
        out += blob(name) + bytes([tag]) + payload
    out += tail
    out += struct.pack("<I", zlib.crc32(out) & 0xFFFFFFFF)
    return bytes(out)


def fac_list(data: bytes) -> str:
    return "{" + ", ".join(str(b) for b in data) + "}"


def build_source() -> str:
    cases: list[tuple[str, bytes, int]] = [
        ("invalid_boolean", packet([(b"flag", 2, b"\x02")]), 1),
        ("unknown_tag", packet([(b"x", 250, b"\x00")]), 1),
        ("duplicate_names", packet([(b"flag", 2, b"\x01"), (b"flag", 2, b"\x00")]), 2),
        ("oversized_bytes", packet([(b"raw", 8, u32(16 * 1024 * 1024 + 1))]), 1),
        ("oversized_i32_list", packet([(b"items", 9, u32(1_048_577))]), 1),
        ("duplicate_map_keys", packet([(b"map", 11, u32(2) + blob(b"a") + blob(b"x") + blob(b"a") + blob(b"y"))]), 1),
        ("invalid_utf8_name", packet([(b"\xff", 1, b"\x00")]), 1),
        ("nul_name", packet([(b"bad\x00name", 1, b"\x00")]), 1),
        ("truncated_boolean", packet([(b"flag", 2, b"")]), 1),
        ("truncated_string", packet([(b"name", 7, u32(99) + b"x")]), 1),
        ("impossible_field_count", packet([], count=0xFFFFFFFF), 0),
        ("field_count_exceeds_body", packet([(b"flag", 2, b"\x01")], count=2), 1),
        ("trailing_data", packet([(b"flag", 2, b"\x01")], tail=b"\xa5"), 1),
        ("empty_field_name", packet([(b"", 1, b"\x00")]), 1),
        ("oversized_field_name_skip", packet([(b"x" * 129, 1, b"\x00")]), 1),
        ("oversized_field_name_read", packet([(b"x" * 129, 2, b"\x01")]), -1),
        ("oversized_record_name", packet([(b"flag", 2, b"\x01")], record_name=b"R" * 129), 1),
        ("nul_record_name", packet([(b"flag", 2, b"\x01")], record_name=b"Fu\x00zz"), 1),
        ("invalid_utf8_record_name", packet([(b"flag", 2, b"\x01")], record_name=b"\xff"), 1),
    ]

    lines = [
        "import terminal.fac",
        "import deserialize.fac",
        "function int main() {",
    ]
    for index, (name, data, field_reads) in enumerate(cases):
        lines += [
            f"    list dyn int data{index} = {fac_list(data)}",
            f"    obj deserialize.BinaryReader reader{index} = new deserialize.BinaryReader(data{index})",
            f"    var boolean rejected{index} = false",
            "    try {",
            f'        reader{index}.readHeaderV2("tests.v158", 1, 1)',
            f'        reader{index}.beginRecord("Fuzz", 65535)',
        ]
        if field_reads > 0:
            lines.append(f"        for++({field_reads}) {{ reader{index}.skipField() }}")
        elif field_reads < 0:
            lines.append(f'        reader{index}.readFieldBoolean("flag")')
        lines += [
            f"        reader{index}.endRecord()",
            f"        reader{index}.requireEnd()",
            f"    }} catch (Error e) {{ rejected{index} = e.code == 13 }}",
            f'    if (!rejected{index} || !reader{index}.isFailed()) {{ throw Error("mutation case {name} was not rejected and poisoned", 4) }}',
            f"    var boolean blocked{index} = false",
            f'    try {{ reader{index}.readHeaderV2("tests.v158", 1, 1) }} catch (Error e) {{ blocked{index} = e.code == 13 }}',
            f'    if (!blocked{index}) {{ throw Error("mutation case {name} allowed a poisoned reader to be reused", 4) }}',
        ]

    valid = packet([(b"flag", 2, b"\x01")])
    lines += [
        f"    list dyn int validData = {fac_list(valid)}",
        "    obj deserialize.BinaryReader validReader = new deserialize.BinaryReader(validData)",
        '    validReader.readHeaderV2("tests.v158", 1, 1)',
        '    validReader.beginRecord("Fuzz")',
        '    if (!validReader.readFieldBoolean("flag")) { throw Error("valid control payload did not decode", 4) }',
        "    validReader.endRecord()",
        "    validReader.requireEnd()",
        "    if (validReader.isFailed()) { throw Error(\"valid payload incorrectly poisoned reader\", 4) }",
        '    terminal.out.println("binary-reader-mutation-corpus-ok")',
        "    return 0",
        "}",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--compiler", type=pathlib.Path, default=ROOT / "build" / "facc")
    ap.add_argument("--timeout", type=int, default=120)
    args = ap.parse_args()
    compiler = args.compiler.resolve()
    if not compiler.is_file():
        raise SystemExit(f"FAC compiler not found: {compiler}")

    with tempfile.TemporaryDirectory(prefix="facb-mutation-") as td:
        tmp = pathlib.Path(td)
        source = tmp / "binary_reader_mutation.fac"
        source.write_text(build_source(), encoding="utf-8")
        for opt in ("-O0", "-O2"):
            exe = tmp / ("binary_reader_" + opt[1:])
            build = subprocess.run(
                [str(compiler), str(source), "-o", str(exe), opt],
                cwd=ROOT, text=True, capture_output=True, timeout=args.timeout,
            )
            if build.returncode:
                print(build.stdout)
                print(build.stderr)
                raise SystemExit(f"FAC mutation harness compile failed at {opt}")
            run = subprocess.run([str(exe)], cwd=ROOT, text=True, capture_output=True, timeout=args.timeout)
            if run.returncode or run.stdout.strip() != "binary-reader-mutation-corpus-ok":
                print(run.stdout)
                print(run.stderr)
                raise SystemExit(f"FAC mutation corpus failed at {opt}")
            print(f"binary reader mutation corpus: PASS ({opt}) — {MALFORMED_CASE_COUNT} malformed cases + valid control")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
