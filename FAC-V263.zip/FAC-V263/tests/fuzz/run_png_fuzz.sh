#!/bin/sh
# fuzz ตัวถอดรหัส PNG: กลายพันธุ์ไฟล์ (แก้ CRC ให้ถูก) แล้วโหลดทีละไฟล์ภายใต้ ASan+UBSan; ต้องไม่มี crash/UB/heap error
# หมายเหตุ: ปิด leak check เพราะตัวโปรแกรม Fac เองมี leak ของสตริงชั่วคราวเมื่อเกิด throw (ข้อจำกัดของ codegen ใน docs/STATUS.md);
#           leak ภายใน runtime ของ graphic.load ถูกตรวจแยกแล้ว (รันด้วย detect_leaks=1 แล้วดูว่าไม่มี frame fac_gfx_load/decodePng)
set -eu
cd "$(dirname "$0")/../.."
N=${1:-1500}; D=/tmp/fac-png-fuzz-build; mkdir -p "$D"
# The fallback path compiles emitted LLVM IR, so default to Clang rather than GCC.
CXX_BIN=${CXX:-clang++}
# Allow constrained CI/dev hosts to lower compile cost while keeping sanitizers enabled.
FUZZ_CXXFLAGS=${FUZZ_CXXFLAGS:--O1 -g}
python3 tests/fuzz/gen_mutants.py /tmp/fac_png_fuzz "$N" "${2:-7}"
./build/facc tests/fuzz/png_fuzz.fac --emit-ll -o "$D/pf.ll"
if [ -x build/llcheck ]; then ./build/llcheck "$D/pf.ll" "$D/pf.o" O1; OBJ="$D/pf.o"; IR=""; else OBJ=""; IR="-x ir $D/pf.ll -x none"; fi
$CXX_BIN -std=c++17 $FUZZ_CXXFLAGS -fsanitize=address,undefined -fno-omit-frame-pointer -fcf-protection=none -pthread $IR $OBJ runtime/fac_rt.cpp -lm -ldl -o "$D/pf"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 "$D/pf"
