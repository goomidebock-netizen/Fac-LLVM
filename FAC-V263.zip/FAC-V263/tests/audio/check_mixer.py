#!/usr/bin/env python3
"""ตรวจเอาต์พุตของ SDL disk audio driver (S16 stereo 44100) จาก tests/audio/mixer.fac -- ใช้ Goertzel ล้วนๆ ไม่ต้องมี numpy"""
import math, struct, sys
raw = open(sys.argv[1], 'rb').read()
n = len(raw) // 4
L = [struct.unpack_from('<h', raw, i * 4)[0] for i in range(n)]
R = 44100
def power(seg, f):
    w = 2 * math.pi * f / R; c = 2 * math.cos(w); s1 = s2 = 0.0
    for x in seg: s0 = x + c * s1 - s2; s2 = s1; s1 = s0
    return (s1 * s1 + s2 * s2 - c * s1 * s2) / (len(seg) ** 2)
def rms(seg): return math.sqrt(sum(x * x for x in seg) / max(1, len(seg)))
def has(seg, f): return power(seg, f) > 2000 and power(seg, f) > 20 * max(power(seg, f * 1.37), power(seg, f * 0.71), 1e-9)
t0 = next((i for i, x in enumerate(L) if abs(x) > 100), None)
fail = []
def check(c, msg):
    if not c: fail.append(msg)
check(t0 is not None, "ไม่มีเสียงเลย")
if t0 is not None:
    seg = lambda a, b: L[t0 + int(a * R): t0 + int(b * R)]
    s = seg(0.02, 0.08);  check(has(s, 440) and not has(s, 660), "ช่วงแรกควรมีเฉพาะ 440 Hz")
    s = seg(0.15, 0.35);  check(has(s, 440) and has(s, 660), "ช่วงซ้อนควรมีทั้ง 440 และ 660 Hz")
    peak = max(abs(x) for x in seg(0.15, 0.35)); check(0.5 * 32767 < peak <= 32767, "ยอดคลื่นรวมผิดปกติ: %d" % peak)
    s = seg(0.47, 0.52);  check(has(s, 660) and not has(s, 440), "หลัง 440 จบควรเหลือ 660 Hz")
    # หาช่วงเงียบ แล้วช่วง loop 880
    i = t0 + int(0.6 * R)
    while i < n and rms(L[i:i + 441]) > 100: i += 441
    while i < n and rms(L[i:i + 441]) <= 100: i += 441
    check(i < n - R, "ไม่พบช่วง loop")
    if i < n - R:
        check(has(L[i + 2205:i + 4410], 880), "loop ควรเป็น 880 Hz")
        j = i + 4410
        while j < n and rms(L[j:j + 441]) > 100: j += 441
        check((j - i) / R > 0.3, "loop ควรเล่นนานกว่า clip (0.1 วิ): %.2f" % ((j - i) / R))
        check(rms(L[max(j + 4410, 0):]) < 100, "หลัง stop()/volume(0) ต้องเงียบ")
if fail: print("audio test FAIL:", *fail, sep="\n  "); sys.exit(1)
print("audio test ok")
