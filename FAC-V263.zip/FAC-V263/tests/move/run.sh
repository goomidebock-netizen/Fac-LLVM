#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-move.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
# move() is gated: legacy mode must reject it unless --strict-move is enabled.
if "$FAC_COMPILER" tests/move/good_string_move.fac --emit-ll -o "$TMP/disabled.ll" >"$TMP/out" 2>"$TMP/err"; then
  echo "FAIL move() unexpectedly enabled without --strict-move"; fail=$((fail+1))
elif grep -Fq -- "--strict-move" "$TMP/err"; then pass=$((pass+1))
else echo "FAIL disabled move produced wrong diagnostic"; cat "$TMP/err"; fail=$((fail+1))
fi
for f in tests/move/good_*.fac; do
  name=$(basename "${f%.fac}")
  if "$FAC_COMPILER" "$f" --strict-move -O0 -o "$TMP/$name" >"$TMP/out" 2>"$TMP/err"; then
    "$TMP/$name" >"$TMP/run.out" 2>"$TMP/run.err"
    case "$name" in
      good_string_move) printf 'owned once\nreinitialized\n' >"$TMP/expected" ;;
      good_struct_move) printf 'payload\nreused\n' >"$TMP/expected" ;;
      good_list_move) printf 'left|right\n' >"$TMP/expected" ;;
      good_ds_move) printf 'value|old\n' >"$TMP/expected" ;;
      good_object_move) printf '42\n9\n' >"$TMP/expected" ;;
      good_loop_reinitialize) printf 'first\nreused\nreused\n' >"$TMP/expected" ;;
      good_shadowed_move) printf 'inner\nouter\n' >"$TMP/expected" ;;
      good_unreachable_move) printf 'still-owned\n' >"$TMP/expected" ;;
      good_finally_reinitialize) printf 'reinitialized\n' >"$TMP/expected" ;;
    esac
    if diff -q "$TMP/expected" "$TMP/run.out" >/dev/null; then pass=$((pass+1)); else
      echo "FAIL $name runtime output"; diff "$TMP/expected" "$TMP/run.out" || true; fail=$((fail+1))
    fi
  else
    echo "FAIL $name compilation"; cat "$TMP/err"; fail=$((fail+1))
  fi
done
for f in tests/move/bad_*.fac; do
  name=$(basename "${f%.fac}")
  if "$FAC_COMPILER" "$f" --strict-move --emit-ll -o "$TMP/$name.ll" >"$TMP/out" 2>"$TMP/err"; then
    echo "FAIL $name unexpectedly compiled"; fail=$((fail+1))
  elif grep -Fq 'strict-move:' "$TMP/err" || grep -Fq 'move():' "$TMP/err"; then pass=$((pass+1))
  else echo "FAIL $name wrong diagnostic"; cat "$TMP/err"; fail=$((fail+1))
  fi
done
echo "move tests: pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
sh ./tests/move/partial/run.sh
