#!/bin/sh
set -eu
cd "$(dirname "$0")/../../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-partial-move.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
for f in tests/move/partial/good_*.fac; do
  name=$(basename "${f%.fac}")
  if "$FAC_COMPILER" "$f" --strict-move -O0 -o "$TMP/$name" >"$TMP/out" 2>"$TMP/err"; then
    "$TMP/$name" >"$TMP/run.out" 2>"$TMP/run.err"
    case "$name" in
      good_partial_field) printf 'alpha\nbeta\nrestored\nbeta\n' >"$TMP/expected" ;;
      good_partial_multiple_fields) printf 'left|right\nnew-left|new-right\n' >"$TMP/expected" ;;
      good_partial_field_reinit_whole) printf 'before\nafter:stable\n' >"$TMP/expected" ;;
      good_partial_loop_reinitialize) printf 'initial\nagain\nagain\n' >"$TMP/expected" ;;
      good_partial_reinit_after_branch) printf 'left\nrestored|right\n' >"$TMP/expected" ;;
      good_nested_partial_leaf) printf 'nested-left\nnested-right\ntail\nrestored-left|nested-right\n' >"$TMP/expected" ;;
      good_nested_partial_aggregate) printf 'left|right\ntail\nrestored-left|restored-right\n' >"$TMP/expected" ;;
      good_nested_sibling_moves) printf 'left|tail|right\nagain-left|again-tail\n' >"$TMP/expected" ;;
      good_nested_exception_cleanup) printf 'caught:91\n' >"$TMP/expected" ;;
      good_nested_parent_reinitialize) printf 'old-left\nnew-left|new-right\n' >"$TMP/expected" ;;
      good_nested_loop_reinitialize) printf 'initial\nagain\nagain\n' >"$TMP/expected" ;;
      good_nested_payload_enum) printf 'payload\nkept:42\nrestored\nnone\n' >"$TMP/expected" ;;
    esac
    if diff -q "$TMP/expected" "$TMP/run.out" >/dev/null; then pass=$((pass+1)); else
      echo "FAIL $name runtime output"; diff "$TMP/expected" "$TMP/run.out" || true; fail=$((fail+1))
    fi
  else
    echo "FAIL $name compilation"; cat "$TMP/err"; fail=$((fail+1))
  fi
done
for f in tests/move/partial/bad_*.fac; do
  name=$(basename "${f%.fac}")
  if "$FAC_COMPILER" "$f" --strict-move --emit-ll -o "$TMP/$name.ll" >"$TMP/out" 2>"$TMP/err"; then
    echo "FAIL $name unexpectedly compiled"; fail=$((fail+1))
  elif grep -Fq 'strict-move:' "$TMP/err" || grep -Fq 'move():' "$TMP/err" || grep -Fq 'partial move' "$TMP/err"; then pass=$((pass+1))
  else echo "FAIL $name wrong diagnostic"; cat "$TMP/err"; fail=$((fail+1))
  fi
done
# The new managed-enum field path must also remain accepted by the secure profile.
if "$FAC_COMPILER" tests/move/partial/good_nested_payload_enum.fac --secure --emit-ll -o "$TMP/secure-payload-enum.ll" >"$TMP/out" 2>"$TMP/err"; then
  pass=$((pass+1))
else
  echo "FAIL secure profile rejected managed payload-enum partial move"; cat "$TMP/err"; fail=$((fail+1))
fi
echo "partial move tests: pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
