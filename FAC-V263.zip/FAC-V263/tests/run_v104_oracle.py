#!/usr/bin/env python3
"""Deterministic independent-oracle tests for V104 polygon SAT and SpatialHash."""
from __future__ import annotations

import os
import random
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMPILER = Path(os.environ.get("FAC_COMPILER", ROOT / "build" / "facc"))
OPT = sys.argv[1] if len(sys.argv) > 1 else "-O2"
RNG = random.Random(1042026)


def run_fac(source: str, name: str) -> str:
    with tempfile.TemporaryDirectory(prefix=f"fac-{name}-") as td:
        src = Path(td) / f"{name}.fac"
        exe = Path(td) / name
        src.write_text(source, encoding="utf-8")
        built = subprocess.run(
            [str(COMPILER), str(src), "-o", str(exe), OPT],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if built.returncode:
            raise RuntimeError(f"{name} compile failed:\n{built.stderr}")
        result = subprocess.run(
            [str(exe)], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        if result.returncode:
            raise RuntimeError(f"{name} run failed:\n{result.stderr}")
        return result.stdout


def cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def convex_hull(points):
    points = sorted(set(points))
    lower = []
    for p in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 1e-8:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 1e-8:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def random_hull():
    while True:
        pts = [
            (round(RNG.uniform(-15, 15), 4), round(RNG.uniform(-15, 15), 4))
            for _ in range(20)
        ]
        hull = convex_hull(pts)
        if 3 <= len(hull) <= 12:
            return hull


def sat_oracle(a, b):
    for polygon in (a, b):
        for i, p in enumerate(polygon):
            q = polygon[(i + 1) % len(polygon)]
            axis = (-(q[1] - p[1]), q[0] - p[0])
            pa = [x * axis[0] + y * axis[1] for x, y in a]
            pb = [x * axis[0] + y * axis[1] for x, y in b]
            if max(pa) <= min(pb) or max(pb) <= min(pa):
                return False
    return True


def fac_array(name, polygon):
    values = []
    for x, y in polygon:
        values.extend((f"{x:.4f}", f"{y:.4f}"))
    return (
        f"    array var double {name}[{len(values)}] = "
        f"{{{', '.join(values)}}}"
    )


def polygon_oracle_test():
    lines = ["import terminal.fac", "import collide.fac", "public function void main() {"]
    expected = []
    for i in range(60):
        a, b = random_hull(), random_hull()
        if i % 3 == 0:
            dx, dy = RNG.uniform(-5, 5), RNG.uniform(-5, 5)
            b = [(x + dx, y + dy) for x, y in b]
        if i % 2:
            b.reverse()
        lines.extend((fac_array(f"a{i}", a), fac_array(f"b{i}", b)))
        lines.append(f"    terminal.out.println(collide.overlapConvexPolygons(a{i}, b{i}))")
        expected.append(sat_oracle(a, b))
    lines.append("}")
    actual_text = run_fac("\n".join(lines) + "\n", "v104-polygon")
    actual = [line.strip() == "true" for line in actual_text.splitlines()]
    if actual != expected:
        mismatches = [
            (i, expected[i], actual[i] if i < len(actual) else "missing")
            for i in range(len(expected))
            if i >= len(actual) or expected[i] != actual[i]
        ]
        raise AssertionError(f"polygon SAT oracle mismatch: {mismatches[:10]}")
    print(f"polygon SAT oracle: {len(actual)}/{len(expected)} passed ({OPT})")


def rect_overlaps(a, b):
    _, ax, ay, aw, ah = a
    bx, by, bw, bh = b
    return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah


def spatial_hash_oracle_test():
    objects = []
    for i in range(80):
        objects.append(
            (
                1000 + i,
                round(RNG.uniform(-100, 100), 3),
                round(RNG.uniform(-100, 100), 3),
                round(RNG.uniform(0.1, 45), 3),
                round(RNG.uniform(0.1, 45), 3),
            )
        )
    queries = [
        (
            round(RNG.uniform(-100, 100), 3),
            round(RNG.uniform(-100, 100), 3),
            round(RNG.uniform(0.1, 30), 3),
            round(RNG.uniform(0.1, 30), 3),
        )
        for _ in range(70)
    ]

    lines = [
        "import terminal.fac",
        "import collide.fac",
        "public function void main() {",
        "    obj collide.SpatialHash grid = new collide.SpatialHash(10.0)",
    ]
    for object_id, x, y, w, h in objects:
        lines.append(f"    grid.insert({object_id}, {x}, {y}, {w}, {h})")
    for qi, (x, y, w, h) in enumerate(queries):
        lines.extend(
            (
                f"    list var int hits{qi} = grid.query({x}, {y}, {w}, {h})",
                f'    terminal.out.println("Q{qi}")',
                f"    var int j{qi} = 0",
                f"    while (j{qi} < sizeof(hits{qi})) {{ terminal.out.println(hits{qi}[j{qi}]); j{qi}++ }}",
            )
        )
    lines.append("}")
    output = run_fac("\n".join(lines) + "\n", "v104-spatial-hash")

    candidates = {}
    current = None
    for raw in output.splitlines():
        line = raw.strip()
        if line.startswith("Q") and line[1:].isdigit():
            current = int(line[1:])
            candidates[current] = []
        elif current is not None and line:
            candidates[current].append(int(line))

    missing = []
    duplicates = []
    for qi, (qx, qy, qw, qh) in enumerate(queries):
        got = candidates.get(qi, [])
        if len(got) != len(set(got)):
            duplicates.append(qi)
        query_box = (qx, qy, qw, qh)
        exact = {obj[0] for obj in objects if rect_overlaps(obj, query_box)}
        absent = exact - set(got)
        if absent:
            missing.append((qi, sorted(absent)))
    if len(candidates) != len(queries) or missing or duplicates:
        raise AssertionError(
            f"spatial hash oracle failed: query blocks={len(candidates)}, "
            f"missing overlaps={missing[:10]}, duplicate IDs={duplicates[:10]}"
        )
    print(
        f"SpatialHash oracle: {len(queries)} queries / {len(objects)} objects; "
        f"no missed overlaps or duplicate IDs ({OPT})"
    )


if __name__ == "__main__":
    if not COMPILER.is_file():
        raise SystemExit(f"FAC compiler not found: {COMPILER}")
    polygon_oracle_test()
    spatial_hash_oracle_test()
