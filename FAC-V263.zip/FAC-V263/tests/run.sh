#!/bin/sh
# ใช้: tests/run.sh [-O2]  รันทุก tests/cases/*.fac เทียบ .out (stdin จาก .in ถ้ามี)
set -u
cd "$(dirname "$0")/.." || exit 1
OPT=${1:--O2}; FILTER=${2:-}; FAC_COMPILER=${FAC_COMPILER:-./build/facc}; pass=0; fail=0
# Keep concurrent invocations isolated; the previous fixed /tmp/fac_t_out path
# allowed parallel GCC/Clang or -O0/-O2 suites to overwrite each other's output.
TEST_TMPDIR=$(mktemp -d "${TMPDIR:-/tmp}/fac-tests.XXXXXXXX")
trap 'rm -rf "$TEST_TMPDIR"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
for f in tests/cases/*.fac; do
  b=${f%.fac}; name=$(basename "$b")
  [ -f "$b.out" ] || continue
  if [ -n "$FILTER" ]; then case "$name" in $FILTER) ;; *) continue ;; esac; fi
  printf '[test %s] %s\n' "$OPT" "$name"
  FL=""; [ -f "$b.flags" ] && FL=$(cat "$b.flags")
  exe="$TEST_TMPDIR/$name"
  out="$TEST_TMPDIR/out"
  err="$TEST_TMPDIR/err"
  "$FAC_COMPILER" "$f" -o "$exe" $OPT $FL 2>"$err" || { echo "FAIL(compile) $name"; head -3 "$err"; fail=$((fail+1)); continue; }
  if [ -f "$b.in" ]; then "$exe" < "$b.in" > "$out" 2>"$TEST_TMPDIR/runtime.err"; else "$exe" > "$out" 2>"$TEST_TMPDIR/runtime.err" </dev/null; fi
  if [ -f "$b.err" ]; then cat "$TEST_TMPDIR/runtime.err" >> "$out"; fi
  if diff -q "$b.out" "$out" >/dev/null; then pass=$((pass+1)); else echo "FAIL $name"; diff "$b.out" "$out" | head -8; fail=$((fail+1)); fi
done
echo "pass=$pass fail=$fail ($OPT)"
[ "$fail" -eq 0 ]
