#!/bin/sh
# ทดสอบ: คอมไพล์ Fac เป็น library แล้วให้โปรแกรม C เรียก (ต้องมี gcc/clang)
cd "$(dirname "$0")/lib" || exit 1
F=../../build/facc
$F mylib.fac --lib --shared --emit-header mylib.h -o libmylib.so || exit 1
${CC:-gcc} main.c -L. -lmylib -Wl,-rpath,. -o /tmp/fac_cmain || exit 1
/tmp/fac_cmain > /tmp/fac_lib_out; rm -f libmylib.so mylib.h
printf 'add=5 dist=5.0 fib=6765\nhello from Fac, n = 7\ncalls=2\n' | diff - /tmp/fac_lib_out && echo "lib test ok"
