#!/bin/sh
# รัน tests/cases ทั้งชุดภายใต้ ASan+UBSan โดยไม่ต้องมี clang (ใช้ FAC_BACKEND=llcheck + g++ ลิงก์ runtime ที่ instrument แล้ว)
#   LEAKS=1  เปิด leak check (ค่าเริ่มต้นปิด เพราะยังมีข้อจำกัดที่บันทึกไว้ใน docs/STATUS.md) ; FAC_TMP_CHECK=1 เปิดเสมอ
# ตรวจ: ไม่มี heap error/UB/double free และ output ตรง .out; โค้ดที่ Fac สร้างเองไม่ถูก instrument (เฉพาะ runtime)
cd "$(dirname "$0")/../.." || exit 1
[ -x build/llcheck ] && export FAC_BACKEND=${FAC_BACKEND:-llcheck}   # เครื่องที่ไม่มี clang ใช้ llcheck; มี clang ใช้ backend ปกติ
export FAC_TMP_CHECK=1
D=/tmp/fac-san-cases; mkdir -p "$D"; pass=0; fail=0; skip=0
# คอมไพล์ runtime ที่ instrument ครั้งเดียว (ช้า) แล้วลิงก์ซ้ำกับแต่ละเทสต์
SANF="-fsanitize=address,undefined -fno-omit-frame-pointer -fcf-protection=none"
[ "$D/rt.o" -nt runtime/fac_rt.cpp ] && [ "$D/rt.o" -nt runtime/fac_lib.inc ] && [ "$D/rt.o" -nt runtime/fac_image.inc ] && [ "$D/rt.o" -nt runtime/fac_pal_sdl.inc ] || \
  ${CXX:-g++} -std=c++17 -O1 -g $SANF -pthread -c runtime/fac_rt.cpp -o "$D/rt.o" || exit 1
for f in tests/cases/*.fac; do
  b=${f%.fac}; name=$(basename "$b"); [ -f "$b.out" ] || continue
  [ -z "${CASE_FILTER:-}" ] || echo "$name" | grep -Eq "$CASE_FILTER" || continue   # CASE_FILTER=regex: รันเฉพาะเคสที่ชื่อตรง (แบ่งรันให้ไม่เกินเวลา)
  if [ -f "$b.flags" ]; then skip=$((skip+1)); continue; fi
  ./build/facc "$f" --emit-ll -o "$D/$name.ll" 2>"$D/err" || { echo "FAIL(compile) $name"; fail=$((fail+1)); continue; }
  if [ -x build/llcheck ]; then ./build/llcheck "$D/$name.ll" "$D/$name.o" O1 || { echo "FAIL(llcheck) $name"; fail=$((fail+1)); continue; }; OBJ="$D/$name.o"; IR=""
  else OBJ=""; IR="-x ir $D/$name.ll -x none"; fi
  ${CXX:-g++} -std=c++17 -O1 -g $SANF -pthread $IR $OBJ "$D/rt.o" -lm -ldl -o "$D/$name" 2>"$D/err" || { echo "FAIL(link) $name"; head -3 "$D/err"; fail=$((fail+1)); continue; }
  export ASAN_OPTIONS=detect_leaks=${LEAKS:-0} UBSAN_OPTIONS=halt_on_error=1
  if [ -f "$b.in" ]; then "$D/$name" < "$b.in" > "$D/out" 2>"$D/err2"; else "$D/$name" > "$D/out" 2>"$D/err2" </dev/null; fi
  if [ -f "$b.err" ]; then grep -v "^==\|^SUMMARY" "$D/err2" >> "$D/out"; fi
  if grep -q "AddressSanitizer\|runtime error\|temp stack" "$D/err2"; then echo "SANITIZER $name"; grep -m3 "ERROR\|runtime error\|temp stack" "$D/err2"; fail=$((fail+1)); continue; fi
  if diff -q "$b.out" "$D/out" >/dev/null; then pass=$((pass+1)); else echo "FAIL(output) $name"; diff "$b.out" "$D/out" | head -4; fail=$((fail+1)); fi
done
echo "asan cases: pass=$pass fail=$fail skipped=$skip"
[ $fail -eq 0 ]
