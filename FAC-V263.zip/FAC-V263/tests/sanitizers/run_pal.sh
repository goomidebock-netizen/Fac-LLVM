#!/bin/sh
# ASan/UBSan สำหรับ backend หน้าต่าง/เสียง (runtime ถูก instrument; โค้ดที่ Fac สร้างไม่ถูก instrument เมื่อใช้ FAC_BACKEND=llcheck)
# ต้องมี g++ และ libSDL2 runtime; ไม่ต้องมีจอ/การ์ดเสียง (ใช้ SDL dummy video + disk audio)
set -eu
cd "$(dirname "$0")/../.."
D=${SAN_DIR:-/tmp/fac-san-pal}; mkdir -p "$D"
run() { # name src [extra-c]
  ./build/facc "$2" --emit-ll -o "$D/$1.ll"
  if [ -x build/llcheck ]; then ./build/llcheck "$D/$1.ll" "$D/$1.o" O1; OBJ="$D/$1.o"; IR=""; else OBJ=""; IR="-x ir $D/$1.ll -x none"; fi
  X=""; [ -n "${3:-}" ] && { gcc -c "$3" -o "$D/$1_x.o"; X="$D/$1_x.o"; }
  ${CXX:-g++} -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -fcf-protection=none -pthread $IR $OBJ $X runtime/fac_rt.cpp -lm -ldl -o "$D/$1"
}
run window_events tests/gui/window_events.fac tests/gui/inject.c
run mixer tests/audio/mixer.fac
export ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1
SDL_VIDEODRIVER=dummy "$D/window_events" >/dev/null
SDL_AUDIODRIVER=disk SDL_DISKAUDIOFILE="$D/a.raw" "$D/mixer" >/dev/null 2>&1
echo "pal sanitizer ok"
