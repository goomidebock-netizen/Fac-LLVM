#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
CXX=${CXX:-clang++}
mkdir -p build
SAN_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer -fno-sanitize-recover=all'
SAN_OPT=${SAN_OPT:--O0} # keep instrumented Runtime builds practical on CI; override with SAN_OPT=-O1 when desired
# Compile an isolated instrumented Runtime object; do not mix sanitizer and normal objects.
$CXX -std=c++17 $SAN_OPT -g0 $SAN_FLAGS -fPIC -pthread -fcf-protection=none \
  -c runtime/fac_rt.cpp -o build/fac_rt_graph_san.o
$CXX -std=c++17 $SAN_OPT -g0 $SAN_FLAGS -pthread \
  tests/runtime/graph_scalability.cpp build/fac_rt_graph_san.o -lm -ldl \
  -o build/test_graph_scalability_san
ASAN_OPTIONS=detect_leaks=1:strict_string_checks=1 \
UBSAN_OPTIONS=halt_on_error=1 build/test_graph_scalability_san
