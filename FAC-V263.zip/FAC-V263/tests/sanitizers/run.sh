#!/bin/sh
# ASan/UBSan audit for managed cleanup and closure cases.
# Usage: tests/sanitizers/run.sh [case-name ...]
set -eu
cd "$(dirname "$0")/../.."
CXX=${CXX:-clang++}
REFCOUNT_CXX=${REFCOUNT_CXX:-g++}
REFCOUNT_SAN_FLAGS=${REFCOUNT_SAN_FLAGS:--O0 -g0}
SAN_DIR=${SAN_DIR:-/tmp/fac-sanitizers}
mkdir -p "$SAN_DIR"
if [ "$#" -gt 0 ]; then cases="$*"; else cases="t25_throw_cleanup t26_lambda_managed_capture t27_closure_refcount t28_lambda_struct_capture t29_nested_struct_closure t30_class_object t32_constructor_throw_cleanup t33_object_overwrite_cleanup t80_destructor t81_cycle_collector t82_weak_reference t83_weak_cycle t84_weak_import_just"; fi
pass=0; fail=0
# Instrument the Runtime itself, not only generated FAC LLVM IR, while stressing
# concurrent final releases and weak-handle promotion.
if "$REFCOUNT_CXX" -std=c++17 $REFCOUNT_SAN_FLAGS -fsanitize=address,undefined -fno-omit-frame-pointer -pthread \
    tests/runtime/refcount_concurrency.cpp runtime/fac_rt.cpp -lm -ldl -o "$SAN_DIR/refcount_concurrency"; then
  if ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=1:halt_on_error=1}" UBSAN_OPTIONS="${UBSAN_OPTIONS:-halt_on_error=1}" "$SAN_DIR/refcount_concurrency"; then
    echo 'PASS runtime refcount concurrency (ASan+UBSan)'; pass=$((pass+1))
  else
    echo 'FAIL runtime refcount concurrency (ASan+UBSan)'; fail=$((fail+1))
  fi
else
  echo 'FAIL build runtime refcount concurrency (ASan+UBSan)'; fail=$((fail+1))
fi
for name in $cases; do
  src="tests/cases/$name.fac"
  [ -f "$src" ] || { echo "SKIP missing case: $name"; continue; }
  ll="$SAN_DIR/$name.ll"; exe="$SAN_DIR/$name"; out="$SAN_DIR/$name.out"; err="$SAN_DIR/$name.err"
  flags=""; [ -f "tests/cases/$name.flags" ] && flags=$(cat "tests/cases/$name.flags")
  if ! ./build/facc "$src" --emit-ll -o "$ll" $flags; then echo "FAIL emit $name"; fail=$((fail+1)); continue; fi
  if ! "$CXX" -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -Wno-override-module -x ir "$ll" -x c++ runtime/fac_rt.cpp -lm -pthread -o "$exe"; then echo "FAIL build $name"; fail=$((fail+1)); continue; fi
  if ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=1:halt_on_error=1}" UBSAN_OPTIONS="${UBSAN_OPTIONS:-halt_on_error=1}" "$exe" >"$out" 2>"$err"; then
    if diff -q "tests/cases/$name.out" "$out" >/dev/null; then echo "PASS $name"; pass=$((pass+1)); else echo "FAIL output $name"; diff -u "tests/cases/$name.out" "$out" | head -20; fail=$((fail+1)); fi
  else
    echo "FAIL sanitizer $name (details: $err)"; head -24 "$err"; fail=$((fail+1))
  fi
done
echo "sanitizer pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
