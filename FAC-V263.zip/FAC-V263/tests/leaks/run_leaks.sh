#!/bin/sh
# ตรวจว่าโปรแกรมใน tests/leaks ไม่รั่ว memory เมื่อ throw ข้าม expression ที่มี temp ค้าง (ASan+LeakSanitizer; ไม่ต้องมี clang)
# แต่ละโปรแกรมต้องพิมพ์ "caught=N" ตรงกับ .out และ LeakSanitizer ต้องไม่รายงานอะไร; รันทั้ง -O0 และ -O2 ของ IR
cd "$(dirname "$0")/../.." || exit 1
[ -x build/llcheck ] && export FAC_BACKEND=${FAC_BACKEND:-llcheck}   # เครื่องที่ไม่มี clang ใช้ llcheck; มี clang ใช้ backend ปกติ
export FAC_TMP_CHECK=1
D=/tmp/fac-leaks; mkdir -p "$D"; fail=0
SANF="-fsanitize=address,undefined -fno-omit-frame-pointer -fcf-protection=none"
${CXX:-g++} -std=c++17 -O1 -g $SANF -pthread -c runtime/fac_rt.cpp -o "$D/rt.o" || exit 1
for f in tests/leaks/*.fac; do
  b=${f%.fac}; name=$(basename "$b")
  for lvl in O0 O2; do
    ./build/facc "$f" --emit-ll -o "$D/$name.ll" || { fail=1; continue; }
    if [ -x build/llcheck ]; then ./build/llcheck "$D/$name.ll" "$D/$name.$lvl.o" $lvl || { fail=1; continue; }; OBJ="$D/$name.$lvl.o"; IR=""
    else OBJ=""; IR="-x ir $D/$name.ll -x none"; fi
    ${CXX:-g++} -std=c++17 $SANF -pthread $IR $OBJ "$D/rt.o" -lm -ldl -o "$D/$name.$lvl" || { fail=1; continue; }
    ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 "$D/$name.$lvl" > "$D/out" 2> "$D/err"; rc=$?
    if [ $rc -ne 0 ] || grep -q "Sanitizer\|SUMMARY\|runtime error\|temp stack" "$D/err" || ! diff -q "$b.out" "$D/out" >/dev/null; then
      echo "FAIL $name ($lvl) rc=$rc"; diff "$b.out" "$D/out" | head -3; grep -m4 "SUMMARY\|ERROR\|runtime error\|temp stack" "$D/err"; fail=1
    else echo "ok   $name ($lvl)"; fi
  done
done
exit $fail
