#!/bin/sh
# ใช้: tests/run_neg.sh  ทุกไฟล์ tests/neg/*.fac ต้อง compile ไม่ผ่านและข้อความ error ต้องตรงกับ .expect
set -u
cd "$(dirname "$0")/.." || exit 1
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
NEG_TMPDIR=$(mktemp -d "${TMPDIR:-/tmp}/fac-neg.XXXXXXXX")
trap 'rm -rf "$NEG_TMPDIR"' EXIT
pass=0; fail=0
for f in tests/neg/*.fac; do
  b=${f%.fac}; [ -f "$b.expect" ] || continue
  out=$("$FAC_COMPILER" "$f" --emit-ll -o "$NEG_TMPDIR/out.ll" 2>&1)
  if echo "$out" | grep -Fq "$(cat "$b.expect")"; then pass=$((pass+1)); else echo "FAIL $(basename "$b"): $out"; fail=$((fail+1)); fi
done
echo "neg pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
