#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-sqlite.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
FIXTURE=tests/api/a28_v151_sqlite_database.fac
EXPECTED=tests/api/a28_v151_sqlite_database.out
for OPT in -O0 -O2; do
  echo "[sqlite] $OPT"
  "$FAC_COMPILER" "$FIXTURE" -o "$TMP/sqlite-test" "$OPT"
  "$TMP/sqlite-test" > "$TMP/out"
  diff -u "$EXPECTED" "$TMP/out"
done
for PROFILE in --strict-safe --secure; do
  echo "[sqlite] $PROFILE --no-trust-stdlib"
  "$FAC_COMPILER" "$FIXTURE" "$PROFILE" --no-trust-stdlib --emit-ll -o "$TMP/check.ll"
done
echo "SQLite integration: passed at -O0/-O2 and strict-safe/secure compile profiles"
