#!/bin/sh
set -eu
FAC_COMPILER=${FAC_COMPILER:-build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-function-effects.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0; fail=0
for name in good_effect_function_value good_readonly_lambda good_stronger_contract good_selected_noescape_overload good_selected_readonly_overload good_selected_noescape_method; do
  if "$FAC_COMPILER" "tests/ownership/function_effects/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then pass=$((pass+1)); echo "PASS $name"; else fail=$((fail+1)); echo "FAIL $name"; cat "$TMP/$name.err"; fi
done
for item in "bad_weaken_noescape:function value ไม่ตรงกับ function type" "bad_weaken_readonly:function value ไม่ตรงกับ function type" "bad_pointer_signature:function value ไม่ตรงกับ function type"; do
  file=${item%%:*}; want=${item#*:}
  if "$FAC_COMPILER" "tests/ownership/function_effects/$file.fac" --strict-ownership --emit-ll -o "$TMP/$file.ll" >"$TMP/$file.out" 2>"$TMP/$file.err"; then fail=$((fail+1)); echo "FAIL $file (accepted)"; elif grep -Fq "$want" "$TMP/$file.err"; then pass=$((pass+1)); echo "PASS $file"; else fail=$((fail+1)); echo "FAIL $file (wrong diagnostic)"; cat "$TMP/$file.err"; fi
done
if "$FAC_COMPILER" tests/ownership/function_effects/bad_callback_argument.fac --strict-ownership --emit-ll -o "$TMP/callback-arg.ll" >"$TMP/callback-arg.out" 2>"$TMP/callback-arg.err"; then fail=$((fail+1)); echo 'FAIL weakened callback argument was accepted'; elif grep -Fq 'function value ไม่ตรงกับ function type' "$TMP/callback-arg.err"; then pass=$((pass+1)); echo 'PASS weakened callback argument'; else fail=$((fail+1)); echo 'FAIL callback argument wrong diagnostic'; cat "$TMP/callback-arg.err"; fi
if "$FAC_COMPILER" tests/ownership/function_effects/bad_indirect_unverified_escape.fac --strict-ownership --emit-ll -o "$TMP/indirect.ll" >"$TMP/indirect.out" 2>"$TMP/indirect.err"; then fail=$((fail+1)); echo 'FAIL indirect escape was accepted'; elif grep -Fq 'without a verified noescape' "$TMP/indirect.err"; then pass=$((pass+1)); echo 'PASS indirect escape remains fail-closed'; else fail=$((fail+1)); echo 'FAIL indirect escape wrong diagnostic'; cat "$TMP/indirect.err"; fi
if "$FAC_COMPILER" tests/ownership/function_effects/bad_selected_retaining_overload.fac --strict-ownership --emit-ll -o "$TMP/selected-retaining.ll" >"$TMP/selected-retaining.out" 2>"$TMP/selected-retaining.err"; then fail=$((fail+1)); echo 'FAIL selected retaining overload was accepted'; elif grep -Fq 'without a verified noescape' "$TMP/selected-retaining.err"; then pass=$((pass+1)); echo 'PASS selected retaining overload rejected'; else fail=$((fail+1)); echo 'FAIL selected retaining overload wrong diagnostic'; cat "$TMP/selected-retaining.err"; fi
if "$FAC_COMPILER" tests/ownership/function_effects/bad_selected_writable_overload.fac --strict-ownership --emit-ll -o "$TMP/selected-writable.ll" >"$TMP/selected-writable.out" 2>"$TMP/selected-writable.err"; then fail=$((fail+1)); echo 'FAIL selected writable overload was accepted'; elif grep -Fq 'without a verified readonly contract' "$TMP/selected-writable.err"; then pass=$((pass+1)); echo 'PASS selected writable overload rejected'; else fail=$((fail+1)); echo 'FAIL selected writable overload wrong diagnostic'; cat "$TMP/selected-writable.err"; fi
echo "function-effect tests: $pass passed, $fail failed"
test "$fail" -eq 0
