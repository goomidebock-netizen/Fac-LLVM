#!/bin/sh
set -eu
cd "$(dirname "$0")/../../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-noescape.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
for name in good_noescape_local good_noescape_local_copy good_noescape_extern good_noescape_struct_field; do
  if "$FAC_COMPILER" "tests/ownership/noescape/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name unexpectedly rejected"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
done
if "$FAC_COMPILER" tests/ownership/noescape/good_noescape_struct_field.fac --strict-ownership -O2 -o "$TMP/struct-noescape-runtime" >"$TMP/struct-runtime-build.out" 2>"$TMP/struct-runtime-build.err"; then
  "$TMP/struct-noescape-runtime" >"$TMP/struct-runtime.out" 2>"$TMP/struct-runtime.err"
  if printf '41\n' | diff -u - "$TMP/struct-runtime.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL struct pointer field noescape forwarding returned wrong value'; cat "$TMP/struct-runtime.out"; fail=$((fail+1)); fi
else echo 'FAIL struct pointer field noescape forwarding was not accepted'; cat "$TMP/struct-runtime-build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/noescape/good_noescape_local.fac --strict-ownership -O2 -o "$TMP/noescape-runtime" >"$TMP/runtime-build.out" 2>"$TMP/runtime-build.err"; then
  "$TMP/noescape-runtime" >"$TMP/runtime.out" 2>"$TMP/runtime.err"
  if printf '41\n' | diff -u - "$TMP/runtime.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL noescape pointer did not address caller storage'; cat "$TMP/runtime.out"; fail=$((fail+1)); fi
else echo 'FAIL could not build noescape runtime test'; cat "$TMP/runtime-build.err"; fail=$((fail+1)); fi
for name in bad_noescape_return bad_noescape_return_alias bad_noescape_global_store bad_noescape_forward bad_noescape_capture bad_call_non_noescape bad_noescape_store_field bad_noescape_container_store; do
  if "$FAC_COMPILER" "tests/ownership/noescape/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name unexpectedly accepted"; fail=$((fail+1));
  elif grep -Fq 'strict-ownership:' "$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
done
if "$FAC_COMPILER" tests/ownership/noescape/bad_noescape_struct_retaining_helper.fac --strict-ownership --emit-ll -o "$TMP/struct-retaining.ll" >"$TMP/struct-retaining.out" 2>"$TMP/struct-retaining.err"; then
  echo 'FAIL pointer-bearing struct passed to a retaining helper unexpectedly'; fail=$((fail+1));
elif grep -Fq 'strict-ownership:' "$TMP/struct-retaining.err"; then pass=$((pass+1));
else echo 'FAIL retaining struct helper produced wrong diagnostic'; cat "$TMP/struct-retaining.err"; fail=$((fail+1)); fi
for name in bad_noescape_non_pointer bad_noescape_lambda bad_noescape_default; do
  if "$FAC_COMPILER" "tests/ownership/noescape/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name unexpectedly accepted"; fail=$((fail+1));
  elif grep -Fq 'noescape' "$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
done
if "$FAC_COMPILER" tests/ownership/noescape/bad_noescape_requires_strict.fac --emit-ll -o "$TMP/legacy.ll" >"$TMP/legacy.out" 2>"$TMP/legacy.err"; then
  echo 'FAIL noescape accepted without strict ownership'; fail=$((fail+1));
elif grep -Fq 'ownership effect contracts' "$TMP/legacy.err"; then pass=$((pass+1));
else echo 'FAIL noescape strict-mode diagnostic mismatch'; cat "$TMP/legacy.err"; fail=$((fail+1)); fi
# Secure profile must verify and accept a valid noescape contract.
if "$FAC_COMPILER" tests/ownership/noescape/good_noescape_secure.fac --secure --emit-ll -o "$TMP/secure.ll" >"$TMP/secure.out" 2>"$TMP/secure.err"; then pass=$((pass+1));
else echo 'FAIL secure did not accept valid noescape contract'; cat "$TMP/secure.err"; fail=$((fail+1)); fi
printf 'noescape tests: pass=%s fail=%s\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
