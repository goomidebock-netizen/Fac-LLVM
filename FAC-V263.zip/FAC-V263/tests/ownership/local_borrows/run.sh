#!/bin/sh
set -eu
cd "$(dirname "$0")/../../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-local-borrow.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
for name in good_shared_read good_mutable_update good_two_shared good_nested_scope_end good_field_mutable good_array_element good_shared_const_field good_method_const good_parameter_borrow good_receiver_borrow good_capture_shared_scalar good_ref_parameter_reborrow good_reborrow_mutable good_reborrow_mutable_child good_reborrow_chain good_reborrow_chain_nll_resume good_reborrow_shared good_reborrow_parameter good_branch_disjoint_loan good_branch_sequential_reborrow good_shadowed_value_name good_shadowed_borrow_name good_shadowed_root_write good_shadowed_root_separate_loan good_shadowed_foreach_name good_shadowed_lambda_parameter good_same_name_reborrow good_nll_shared_last_use good_nll_mutable_last_use good_nll_branch_last_use good_nll_loop_last_use good_nll_unused_borrow good_nll_sequential_borrows good_shadowed_catch_name good_shadowed_match_name good_exception_cfg_lifetime good_call_exception_cfg_lifetime good_nested_lifetime_region good_pointer_same_region good_pointer_outer_owner good_pointer_immediate_call good_pointer_nested_chain good_selected_by_value_overload good_array_disjoint_indices good_array_constant_expression_indices good_array_const_identifier_indices good_array_const_shadowing good_array_const_narrow_integer_indices good_array_const_unsigned_integer_indices good_array_bitwise_constant_indices good_array_ifv_constant_indices good_array_const_boolean_predicates good_array_const_boolean_shadowing good_array_cast_constant_indices good_array_const_character_indices good_array_const_character_shadowing good_array_const_floating_cast_indices good_array_const_floating_shadowing good_array_const_floating_arithmetic_indices good_cfg_constant_branch_pruning good_match_payload_pointer_same_region good_match_expression_pointer_same_region good_pointer_store_field good_pointer_aggregate_initializer good_pointer_nonescaping_closure_capture; do
  if "$FAC_COMPILER" "tests/ownership/local_borrows/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $name unexpectedly rejected"; cat "$TMP/$name.err"; fail=$((fail+1))
  fi
done
# CFG reachability prunes impossible literal/comparison/short-circuit branches
# before backwards loan liveness. Runtime-dependent predicates remain may-branches.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_cfg_constant_branch_pruning.fac --strict-ownership -O2 -o "$TMP/cfg-constant-branches" >"$TMP/cfg-constant-build.out" 2>"$TMP/cfg-constant-build.err"; then
  "$TMP/cfg-constant-branches" >"$TMP/cfg-constant.out" 2>"$TMP/cfg-constant.err"
  if printf '5\n15\n' | diff -u - "$TMP/cfg-constant.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL constant CFG branch pruning changed runtime behavior'; cat "$TMP/cfg-constant.out"; fail=$((fail+1)); fi
else echo 'FAIL constant CFG branch pruning fixture was unexpectedly rejected'; cat "$TMP/cfg-constant-build.err"; fail=$((fail+1)); fi

# Owner-access diagnostics identify the exact local borrow that blocks access.
if "$FAC_COMPILER" tests/ownership/local_borrows/bad_mutable_owner_write.fac --strict-ownership --emit-ll -o "$TMP/diagnostic-origin.ll" >"$TMP/diagnostic-origin.out" 2>"$TMP/diagnostic-origin.err"; then
  echo 'FAIL owner write with a live mutable borrow unexpectedly accepted'; fail=$((fail+1))
elif grep -Fq "conflicting mutable local borrow 'view' declared at line 3" "$TMP/diagnostic-origin.err"; then
  pass=$((pass+1))
else
  echo 'FAIL owner-write diagnostic did not identify the blocking borrow declaration'; cat "$TMP/diagnostic-origin.err"; fail=$((fail+1))
fi

if "$FAC_COMPILER" tests/ownership/local_borrows/bad_reborrow_parent_write.fac --strict-ownership --emit-ll -o "$TMP/diagnostic-child.ll" >"$TMP/diagnostic-child.out" 2>"$TMP/diagnostic-child.err"; then
  echo 'FAIL parent write with a live child reborrow unexpectedly accepted'; fail=$((fail+1))
elif grep -Fq "conflicting shared local borrow 'child' declared at line 4" "$TMP/diagnostic-child.err"; then
  pass=$((pass+1))
else
  echo 'FAIL parent-reborrow diagnostic did not identify the child borrow declaration'; cat "$TMP/diagnostic-child.err"; fail=$((fail+1))
fi
# In a multi-level chain, diagnostics should name the deepest retained loan,
# not merely the immediate ancestor that NLL keeps alive for ancestry.
if "$FAC_COMPILER" tests/ownership/local_borrows/bad_reborrow_ancestor_write.fac --strict-ownership --emit-ll -o "$TMP/diagnostic-descendant.ll" >"$TMP/diagnostic-descendant.out" 2>"$TMP/diagnostic-descendant.err"; then
  echo 'FAIL ancestor write with a live grandchild unexpectedly accepted'; fail=$((fail+1))
elif grep -Fq "conflicting shared local borrow 'grandchild' declared at line 5" "$TMP/diagnostic-descendant.err"; then
  pass=$((pass+1))
else
  echo 'FAIL transitive reborrow diagnostic did not identify the deepest live descendant'; cat "$TMP/diagnostic-descendant.err"; fail=$((fail+1))
fi

for name in bad_reborrow_ancestor_write bad_reborrow_intermediate_write bad_shared_write bad_shared_owner_write bad_mutable_owner_read bad_mutable_owner_write bad_const_owner_mut_borrow bad_conflicting_borrows bad_mutable_ref_pass_shared bad_address_escape bad_mutable_const_field bad_global_borrow bad_reborrow_parent_write bad_reborrow_parent_read bad_shared_to_mut_reborrow bad_branch_loan_live_after bad_shared_method_mutation bad_owner_method_mutable_borrow bad_move_owner bad_addr_owner bad_capture_object_alias bad_capture_mut_owner bad_pass_object_alias_by_value bad_nll_owner_before_last_use bad_nll_shared_owner_before_last_use bad_nll_defer_holds_loan bad_nll_branch_before_last_use bad_shadowed_outer_still_live bad_shadowed_root_outer_still_borrowed bad_shadowed_catch_outer_still_live bad_shadowed_match_outer_still_live bad_exception_cfg_owner_write bad_call_exception_cfg_owner_write bad_finally_owner_write bad_return_local_addr bad_return_pointer_alias bad_return_branch_pointer_alias bad_pointer_store_outer bad_pointer_chain_escape bad_pointer_store_global bad_return_pointer_arithmetic bad_return_pointer_after_inner_assignment bad_pointer_container_add bad_array_same_index bad_array_dynamic_index bad_array_constant_expression_same_index bad_array_constant_expression_overflow bad_array_const_identifier_same_index bad_array_mutable_shadowing_const_index bad_array_const_narrow_integer_same_index bad_array_const_unsigned_same_index bad_array_const_unsigned_negative bad_array_bitwise_constant_same_index bad_array_bitwise_constant_complement_same_index bad_array_shift_count_mask_same_index bad_array_ifv_constant_same_index bad_array_ifv_dynamic_condition bad_array_const_boolean_same_index bad_array_const_boolean_shadowed_mutable bad_array_cast_constant_same_index bad_array_cast_dynamic_index bad_array_const_character_same_index bad_array_mutable_character_shadowing_const bad_array_float_cast_same_index bad_array_mutable_float_cast_index bad_array_mutable_float_shadowing_const bad_array_const_float_arithmetic_same_index bad_array_const_float_power_unfolded bad_array_const_float_zero_division_unfolded bad_array_const_float_nonfinite_unfolded bad_cfg_dynamic_branch_remains_possible bad_cfg_dynamic_defer_still_pins bad_match_payload_pointer_escape bad_match_expression_pointer_escape; do
  if "$FAC_COMPILER" "tests/ownership/local_borrows/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name unexpectedly accepted"; fail=$((fail+1))
  elif grep -Fq 'strict-ownership:' "$TMP/$name.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $name wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1))
  fi
done
if "$FAC_COMPILER" tests/ownership/local_borrows/good_shared_read.fac --emit-ll -o "$TMP/legacy.ll" >"$TMP/legacy.out" 2>"$TMP/legacy.err"; then
  echo 'FAIL local borrow accepted without --strict-ownership'; fail=$((fail+1))
elif grep -Fq -- '--strict-ownership' "$TMP/legacy.err"; then pass=$((pass+1))
else echo 'FAIL wrong legacy-mode diagnostic'; cat "$TMP/legacy.err"; fail=$((fail+1)); fi
# Secure profile must enable the same local-borrow checker.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_shared_read.fac --secure --emit-ll -o "$TMP/secure.ll" >"$TMP/secure.out" 2>"$TMP/secure.err"; then pass=$((pass+1));
else echo 'FAIL --secure did not enable local borrows'; cat "$TMP/secure.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/bad_shared_write.fac --secure --emit-ll -o "$TMP/secure-bad.ll" >"$TMP/secure-bad.out" 2>"$TMP/secure-bad.err"; then
  echo 'FAIL --secure accepted a write through shared borrow'; fail=$((fail+1))
elif grep -Fq 'strict-ownership:' "$TMP/secure-bad.err"; then pass=$((pass+1));
else echo 'FAIL --secure wrong local-borrow diagnostic'; cat "$TMP/secure-bad.err"; fail=$((fail+1)); fi
# Validate that a borrow aliases the original storage at runtime (not a copy).
if "$FAC_COMPILER" tests/ownership/local_borrows/good_mutable_update.fac --strict-ownership -O2 -o "$TMP/alias-runtime" >"$TMP/runtime-build.out" 2>"$TMP/runtime-build.err"; then
  "$TMP/alias-runtime" >"$TMP/runtime.out" 2>"$TMP/runtime.err"
  if printf '21\n21\n' | diff -u - "$TMP/runtime.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL runtime alias did not update the owner'; cat "$TMP/runtime.out"; fail=$((fail+1)); fi
else echo 'FAIL could not build runtime alias test'; cat "$TMP/runtime-build.err"; fail=$((fail+1)); fi
# Exact non-negative array indices are disjoint; dynamic indices remain conservative.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_disjoint_indices.fac --strict-ownership -O2 -o "$TMP/array-index-disjoint" >"$TMP/array-index-build.out" 2>"$TMP/array-index-build.err"; then
  "$TMP/array-index-disjoint" >"$TMP/array-index.out" 2>"$TMP/array-index.err"
  if printf '21\n210\n22\n' | diff -u - "$TMP/array-index.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL disjoint constant array-index borrows did not preserve the expected storage'; cat "$TMP/array-index.out"; fail=$((fail+1)); fi
else echo 'FAIL disjoint constant array-index borrows were unexpectedly rejected'; cat "$TMP/array-index-build.err"; fail=$((fail+1)); fi
# Pure constant arithmetic indexes are normalized to the same exact projection.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_constant_expression_indices.fac --strict-ownership -O2 -o "$TMP/array-constant-expression" >"$TMP/array-constant-build.out" 2>"$TMP/array-constant-build.err"; then
  "$TMP/array-constant-expression" >"$TMP/array-constant.out" 2>"$TMP/array-constant.err"
  if printf '22\n66\n44\n55\n77\n88\n99\n100\n' | diff -u - "$TMP/array-constant.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL constant-expression array borrows did not preserve expected storage'; cat "$TMP/array-constant.out"; fail=$((fail+1)); fi
else echo 'FAIL disjoint constant-expression array borrows were unexpectedly rejected'; cat "$TMP/array-constant-build.err"; fail=$((fail+1)); fi
# Parent/child/grandchild reborrows are suspended transitively while a
# descendant remains live, then NLL releases the chain after its final use.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_reborrow_chain_nll_resume.fac --strict-ownership -O2 -o "$TMP/reborrow-chain-nll" >"$TMP/reborrow-chain-nll-build.out" 2>"$TMP/reborrow-chain-nll-build.err"; then
  "$TMP/reborrow-chain-nll" >"$TMP/reborrow-chain-nll.out" 2>"$TMP/reborrow-chain-nll.err"
  if printf '10\n30\n' | diff -u - "$TMP/reborrow-chain-nll.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL NLL did not release a reborrow chain after its final descendant use'; cat "$TMP/reborrow-chain-nll.out"; fail=$((fail+1)); fi
else echo 'FAIL NLL reborrow-chain fixture was unexpectedly rejected'; cat "$TMP/reborrow-chain-nll-build.err"; fail=$((fail+1)); fi

# A mutable child must write through the same slot, then release its parent.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_reborrow_mutable_child.fac --strict-ownership -O2 -o "$TMP/reborrow-runtime" >"$TMP/reborrow-build.out" 2>"$TMP/reborrow-build.err"; then
  "$TMP/reborrow-runtime" >"$TMP/reborrow.out" 2>"$TMP/reborrow.err"
  if printf '22\n' | diff -u - "$TMP/reborrow.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL mutable child reborrow did not update original storage'; cat "$TMP/reborrow.out"; fail=$((fail+1)); fi
else echo 'FAIL could not build mutable child reborrow runtime test'; cat "$TMP/reborrow-build.err"; fail=$((fail+1)); fi
# Exceptional edges and finally cleanup retain the borrow through the last use,
# then release it before the owner is mutated after the try statement.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_exception_cfg_lifetime.fac --strict-ownership -O2 -o "$TMP/exception-lifetime" >"$TMP/exception-build.out" 2>"$TMP/exception-build.err"; then
  "$TMP/exception-lifetime" >"$TMP/exception.out" 2>"$TMP/exception.err"
  if printf '10\n10\n20\n' | diff -u - "$TMP/exception.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL exceptional/finally loan lifetime mismatch'; cat "$TMP/exception.out"; fail=$((fail+1)); fi
else echo 'FAIL could not build exceptional lifetime test'; cat "$TMP/exception-build.err"; fail=$((fail+1)); fi
# Calls within a try block receive conservative exceptional CFG edges.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_call_exception_cfg_lifetime.fac --strict-ownership -O2 -o "$TMP/call-exception-lifetime" >"$TMP/call-exception-build.out" 2>"$TMP/call-exception-build.err"; then
  "$TMP/call-exception-lifetime" >"$TMP/call-exception.out" 2>"$TMP/call-exception.err"
  if printf '5\n5\n9\n' | diff -u - "$TMP/call-exception.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL call exceptional/finally loan lifetime mismatch'; cat "$TMP/call-exception.out"; fail=$((fail+1)); fi
else echo 'FAIL could not build call exceptional lifetime test'; cat "$TMP/call-exception-build.err"; fail=$((fail+1)); fi
# Visible initialized local const int/long identifiers are folded only when
# the current declaration identity matches the recorded constant binding.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_identifier_indices.fac --strict-ownership -O2 -o "$TMP/array-const-identifiers" >"$TMP/array-const-identifiers-build.out" 2>"$TMP/array-const-identifiers-build.err"; then
  "$TMP/array-const-identifiers" >"$TMP/array-const-identifiers.out" 2>"$TMP/array-const-identifiers.err"
  if printf '11\n22\n66\n' | diff -u - "$TMP/array-const-identifiers.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL const identifier array borrows did not resolve to original elements'; cat "$TMP/array-const-identifiers.out"; fail=$((fail+1)); fi
else echo 'FAIL const identifier array borrows were unexpectedly rejected'; cat "$TMP/array-const-identifiers-build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_shadowing.fac --strict-ownership -O2 -o "$TMP/array-const-shadowing" >"$TMP/array-const-shadowing-build.out" 2>"$TMP/array-const-shadowing-build.err"; then
  "$TMP/array-const-shadowing" >"$TMP/array-const-shadowing.out" 2>"$TMP/array-const-shadowing.err"
  if printf '11\n22\n' | diff -u - "$TMP/array-const-shadowing.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL shadowed const index resolved to the wrong storage'; cat "$TMP/array-const-shadowing.out"; fail=$((fail+1)); fi
else echo 'FAIL shadowed const index was unexpectedly rejected'; cat "$TMP/array-const-shadowing-build.err"; fail=$((fail+1)); fi
# Narrow signed integer constants (byte/short) are folded only within their
# declared width; runtime writes must still alias the original fixed-array slots.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_narrow_integer_indices.fac --strict-ownership -O2 -o "$TMP/array-const-narrow" >"$TMP/array-const-narrow-build.out" 2>"$TMP/array-const-narrow-build.err"; then
  "$TMP/array-const-narrow" >"$TMP/array-const-narrow.out" 2>"$TMP/array-const-narrow.err"
  if printf '11\n22\n44\n' | diff -u - "$TMP/array-const-narrow.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL narrow const integer indexes did not preserve expected storage'; cat "$TMP/array-const-narrow.out"; fail=$((fail+1)); fi
else echo 'FAIL narrow const integer array indexes were unexpectedly rejected'; cat "$TMP/array-const-narrow-build.err"; fail=$((fail+1)); fi
# Bitwise operators, shifts and promoted unary complement are normalized to
# the same exact fixed-array projections used by generated runtime expressions.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_bitwise_constant_indices.fac --strict-ownership -O2 -o "$TMP/array-bitwise-constant" >"$TMP/array-bitwise-build.out" 2>"$TMP/array-bitwise-build.err"; then
  "$TMP/array-bitwise-constant" >"$TMP/array-bitwise.out" 2>"$TMP/array-bitwise.err"
  if printf '33\n55\n1010\n88\n99\n1111\n44\n11\n1212\n22\n77\n' | diff -u - "$TMP/array-bitwise.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL bitwise/shift constant array borrows did not preserve expected storage'; cat "$TMP/array-bitwise.out"; fail=$((fail+1)); fi
else echo 'FAIL bitwise/shift constant array borrows were unexpectedly rejected'; cat "$TMP/array-bitwise-build.err"; fail=$((fail+1)); fi
# Constant ifv/eiv/elv expressions resolve to an exact array projection only
# when every result arm has the same integer representation and predicates are
# provably constant. Runtime writes verify that the borrow still aliases storage.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_ifv_constant_indices.fac --strict-ownership -O2 -o "$TMP/array-ifv-constant" >"$TMP/array-ifv-build.out" 2>"$TMP/array-ifv-build.err"; then
  "$TMP/array-ifv-constant" >"$TMP/array-ifv.out" 2>"$TMP/array-ifv.err"
  if printf '101\n202\n303\n404\n505\n606\n' | diff -u - "$TMP/array-ifv.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL constant ifv array borrows did not preserve expected storage'; cat "$TMP/array-ifv.out"; fail=$((fail+1)); fi
else echo 'FAIL constant ifv array borrows were unexpectedly rejected'; cat "$TMP/array-ifv-build.err"; fail=$((fail+1)); fi
# Unsigned local const integer types (ubyte/ushort/uint/ulong) are folded only
# for non-negative values within their declared width; runtime writes must alias
# the original fixed-array slots, and equal values must still conflict.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_unsigned_integer_indices.fac --strict-ownership -O2 -o "$TMP/array-const-unsigned" >"$TMP/array-const-unsigned-build.out" 2>"$TMP/array-const-unsigned-build.err"; then
  "$TMP/array-const-unsigned" >"$TMP/array-const-unsigned.out" 2>"$TMP/array-const-unsigned.err"
  if printf '11\n22\n44\n66\n' | diff -u - "$TMP/array-const-unsigned.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL unsigned const integer indexes did not preserve expected storage'; cat "$TMP/array-const-unsigned.out"; fail=$((fail+1)); fi
else echo 'FAIL unsigned const integer array indexes were unexpectedly rejected'; cat "$TMP/array-const-unsigned-build.err"; fail=$((fail+1)); fi
# Initialized local const boolean bindings are resolved by declaration identity
# when they control an ifv/eiv/elv array index. Chained boolean constants work,
# while equal selected indexes must still conflict (negative case above).
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_boolean_predicates.fac --strict-ownership -O2 -o "$TMP/array-const-bool" >"$TMP/array-const-bool-build.out" 2>"$TMP/array-const-bool-build.err"; then
  "$TMP/array-const-bool" >"$TMP/array-const-bool.out" 2>"$TMP/array-const-bool.err"
  if printf '11\n22\n33\n44\n' | diff -u - "$TMP/array-const-bool.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL const boolean predicates selected the wrong array storage'; cat "$TMP/array-const-bool.out"; fail=$((fail+1)); fi
else echo 'FAIL const boolean predicate array borrows were unexpectedly rejected'; cat "$TMP/array-const-bool-build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_boolean_shadowing.fac --strict-ownership -O2 -o "$TMP/array-const-bool-shadow" >"$TMP/array-const-bool-shadow-build.out" 2>"$TMP/array-const-bool-shadow-build.err"; then
  "$TMP/array-const-bool-shadow" >"$TMP/array-const-bool-shadow.out" 2>"$TMP/array-const-bool-shadow.err"
  if printf '11\n44\n' | diff -u - "$TMP/array-const-bool-shadow.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL shadowed const boolean predicate used the wrong declaration'; cat "$TMP/array-const-bool-shadow.out"; fail=$((fail+1)); fi
else echo 'FAIL shadowed const boolean array borrow was unexpectedly rejected'; cat "$TMP/array-const-bool-shadow-build.err"; fail=$((fail+1)); fi
# Explicit primitive casts are folded using FAC truncation/extension and boolean semantics.
# Runtime writes prove the normalized projections still alias the exact array slots.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_cast_constant_indices.fac --strict-ownership -O2 -o "$TMP/array-cast-constant" >"$TMP/array-cast-build.out" 2>"$TMP/array-cast-build.err"; then
  "$TMP/array-cast-constant" >"$TMP/array-cast.out" 2>"$TMP/array-cast.err"
  if printf '11\n22\n33\n44\n55\n66\n77\n88\n' | diff -u - "$TMP/array-cast.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL cast constant array borrows did not preserve expected storage'; cat "$TMP/array-cast.out"; fail=$((fail+1)); fi
else echo 'FAIL explicit integer-cast array projections were unexpectedly rejected'; cat "$TMP/array-cast-build.err"; fail=$((fail+1)); fi
# Local const char/unichar identifiers preserve their FAC scalar widths and
# unsigned character representation. Runtime writes verify exact aliasing.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_character_indices.fac --strict-ownership -O2 -o "$TMP/array-const-character" >"$TMP/array-const-character-build.out" 2>"$TMP/array-const-character-build.err"; then
  "$TMP/array-const-character" >"$TMP/array-const-character.out" 2>"$TMP/array-const-character.err"
  if printf '11\n22\n33\n44\n55\n' | diff -u - "$TMP/array-const-character.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL const char/unichar array indexes did not preserve expected storage'; cat "$TMP/array-const-character.out"; fail=$((fail+1)); fi
else echo 'FAIL const char/unichar array indexes were unexpectedly rejected'; cat "$TMP/array-const-character-build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_character_shadowing.fac --strict-ownership -O2 -o "$TMP/array-const-character-shadow" >"$TMP/array-const-character-shadow-build.out" 2>"$TMP/array-const-character-shadow-build.err"; then
  "$TMP/array-const-character-shadow" >"$TMP/array-const-character-shadow.out" 2>"$TMP/array-const-character-shadow.err"
  if printf '22\n33\n11\n' | diff -u - "$TMP/array-const-character-shadow.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL shadowed const character index used the wrong declaration'; cat "$TMP/array-const-character-shadow.out"; fail=$((fail+1)); fi
else echo 'FAIL shadowed const character index was unexpectedly rejected'; cat "$TMP/array-const-character-shadow-build.err"; fail=$((fail+1)); fi
# Explicit floating-to-integer casts mirror FAC's saturating LLVM conversion
# semantics. Const float/double declarations are tied to declaration identity;
# runtime writes verify each folded projection addresses the expected slot.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_floating_cast_indices.fac --strict-ownership -O2 -o "$TMP/array-float-cast" >"$TMP/array-float-cast-build.out" 2>"$TMP/array-float-cast-build.err"; then
  "$TMP/array-float-cast" >"$TMP/array-float-cast.out" 2>"$TMP/array-float-cast.err"
  if printf '11\n22\n33\n44\n55\n66\n77\n88\n99\n' | diff -u - "$TMP/array-float-cast.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL floating-cast constant array borrows did not preserve expected storage'; cat "$TMP/array-float-cast.out"; fail=$((fail+1)); fi
else echo 'FAIL constant floating-cast array projections were unexpectedly rejected'; cat "$TMP/array-float-cast-build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_floating_shadowing.fac --strict-ownership -O2 -o "$TMP/array-float-shadow" >"$TMP/array-float-shadow-build.out" 2>"$TMP/array-float-shadow-build.err"; then
  "$TMP/array-float-shadow" >"$TMP/array-float-shadow.out" 2>"$TMP/array-float-shadow.err"
  if printf '22\n44\n11\n' | diff -u - "$TMP/array-float-shadow.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL shadowed const floating index used the wrong declaration'; cat "$TMP/array-float-shadow.out"; fail=$((fail+1)); fi
else echo 'FAIL shadowed const floating array projection was unexpectedly rejected'; cat "$TMP/array-float-shadow-build.err"; fail=$((fail+1)); fi
# Floating arithmetic constants are folded with FAC float32/double common-type
# rules. The float32 case deliberately rounds to 2.0f, unlike a host-double sum.
if "$FAC_COMPILER" tests/ownership/local_borrows/good_array_const_floating_arithmetic_indices.fac --strict-ownership -O2 -o "$TMP/array-float-arithmetic" >"$TMP/array-float-arithmetic-build.out" 2>"$TMP/array-float-arithmetic-build.err"; then
  "$TMP/array-float-arithmetic" >"$TMP/array-float-arithmetic.out" 2>"$TMP/array-float-arithmetic.err"
  if printf '22\n11\n44\n55\n66\n88\n99\n1212\n' | diff -u - "$TMP/array-float-arithmetic.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL floating arithmetic constants selected the wrong array storage'; cat "$TMP/array-float-arithmetic.out"; fail=$((fail+1)); fi
else echo 'FAIL supported floating arithmetic constant projections were unexpectedly rejected'; cat "$TMP/array-float-arithmetic-build.err"; fail=$((fail+1)); fi
printf 'local borrow tests: pass=%s fail=%s\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
