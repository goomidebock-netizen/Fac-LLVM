#!/bin/sh
set -eu
cd "$(dirname "$0")/../../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-field-borrow.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
for name in good_distinct_local_fields good_nested_disjoint_fields good_nested_vs_sibling good_shared_mutable_disjoint good_owner_other_field_access good_ref_call_distinct_fields good_distinct_fields_ref_legacy good_disjoint_sibling_reborrows good_three_level_reborrow_graph good_three_level_reborrow_nll_parent_retention; do
  if "$FAC_COMPILER" "tests/ownership/field_sensitive/$name.fac" --strict-ownership --strict-move --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $name unexpectedly rejected"; cat "$TMP/$name.err"; fail=$((fail+1))
  fi
done
for name in bad_same_field_local_borrows bad_nested_prefix_overlap bad_whole_and_field_borrow bad_owner_same_field_read bad_same_field_call bad_same_field_sibling_reborrows bad_partial_move_borrowed_field bad_three_level_reborrow_same_leaf bad_three_level_parent_access_while_grandchild_live; do
  if "$FAC_COMPILER" "tests/ownership/field_sensitive/$name.fac" --strict-ownership --strict-move --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name unexpectedly accepted"; fail=$((fail+1))
  elif grep -Fq 'strict-ownership:' "$TMP/$name.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $name wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1))
  fi
done
run_expected() {
  name=$1; expected=$2
  if "$FAC_COMPILER" "tests/ownership/field_sensitive/$name.fac" --strict-ownership --strict-move -O2 -o "$TMP/$name.bin" >"$TMP/$name.build.out" 2>"$TMP/$name.build.err"; then
    "$TMP/$name.bin" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"
    if printf '%s' "$expected" | diff -u - "$TMP/$name.run.out" >/dev/null; then pass=$((pass+1));
    else echo "FAIL $name runtime output"; cat "$TMP/$name.run.out"; fail=$((fail+1)); fi
  else echo "FAIL $name runtime build"; cat "$TMP/$name.build.err"; fail=$((fail+1)); fi
}
run_expected good_distinct_local_fields '11 22
11 22
'
run_expected good_shared_mutable_disjoint '3
3 40
'
run_expected good_owner_other_field_access '60
50 60
'
run_expected good_ref_call_distinct_fields '8 7
'
run_expected good_three_level_reborrow_graph '11 22
11 22
'
run_expected good_three_level_reborrow_nll_parent_retention '33
33
'
printf 'field-sensitive borrow tests: pass=%s fail=%s\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
