#!/bin/sh
set -eu
cd "$(dirname "$0")/../../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-effects.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
for name in good_readonly_local good_readonly_forward good_readonly_extern good_readonly_modifier_order good_readonly_deref_value_call good_effect_interface; do
  if "$FAC_COMPILER" "tests/ownership/effects/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name unexpectedly rejected"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
done
if "$FAC_COMPILER" tests/ownership/effects/good_effect_interface.fac --strict-ownership -O2 -o "$TMP/interface-runtime" >"$TMP/interface.build.out" 2>"$TMP/interface.build.err"; then
  "$TMP/interface-runtime" >"$TMP/interface.runtime.out" 2>"$TMP/interface.runtime.err"
  if printf '41\n' | diff -u - "$TMP/interface.runtime.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL effect interface dispatch output'; cat "$TMP/interface.runtime.out"; fail=$((fail+1)); fi
else echo 'FAIL effect interface runtime build'; cat "$TMP/interface.build.err"; fail=$((fail+1)); fi
for name in bad_readonly_write bad_readonly_increment bad_readonly_forward_mutable bad_readonly_pointer_alias bad_readonly_method_receiver bad_readonly_pointer_arithmetic_write bad_readonly_non_pointer bad_readonly_default bad_effect_interface_weaken_noescape bad_effect_override_weaken_readonly; do
  if "$FAC_COMPILER" "tests/ownership/effects/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name unexpectedly accepted"; fail=$((fail+1));
  elif grep -Eiq 'readonly|noescape|weakens' "$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
done
if "$FAC_COMPILER" tests/ownership/effects/good_readonly_noescape_runtime.fac --strict-ownership -O2 -o "$TMP/read-only-runtime" >"$TMP/runtime.build.out" 2>"$TMP/runtime.build.err"; then
  "$TMP/read-only-runtime" >"$TMP/runtime.out" 2>"$TMP/runtime.err"
  if printf '41\n' | diff -u - "$TMP/runtime.out" >/dev/null; then pass=$((pass+1));
  else echo 'FAIL readonly/noescape runtime output'; cat "$TMP/runtime.out"; fail=$((fail+1)); fi
else echo 'FAIL readonly/noescape runtime build'; cat "$TMP/runtime.build.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/effects/bad_readonly_requires_strict.fac --emit-ll -o "$TMP/legacy.ll" >"$TMP/legacy.out" 2>"$TMP/legacy.err"; then
  echo 'FAIL readonly contract accepted without strict ownership'; fail=$((fail+1));
elif grep -Fq 'ownership effect contracts' "$TMP/legacy.err"; then pass=$((pass+1));
else echo 'FAIL readonly strict-mode diagnostic mismatch'; cat "$TMP/legacy.err"; fail=$((fail+1)); fi
printf 'effect contract tests: pass=%s fail=%s\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
