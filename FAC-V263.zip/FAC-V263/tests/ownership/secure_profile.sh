#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
T=$(mktemp -d "${TMPDIR:-/tmp}/fac-secure.XXXXXXXX")
trap 'rm -rf "$T"' EXIT
pass=0
fail=0
if "$FAC_COMPILER" tests/ownership/bad_same_variable.fac --secure --emit-ll -o "$T/a.ll" >"$T/out" 2>"$T/err"; then
  echo 'FAIL --secure did not enable strict ownership'; fail=$((fail+1))
elif grep -Fq 'strict-ownership: mutable borrow conflict' "$T/err"; then pass=$((pass+1))
else echo 'FAIL --secure ownership diagnostic'; cat "$T/err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/move/good_string_move.fac --secure --emit-ll -o "$T/move.ll" >/dev/null 2>"$T/move.err"; then pass=$((pass+1))
else echo 'FAIL --secure did not enable strict move'; cat "$T/move.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/safe/strict_bad/thread_indirect_function_local.fac --secure --emit-ll -o "$T/strict.ll" >/dev/null 2>"$T/strict.err"; then
  echo 'FAIL --secure did not enable strict-safe'; fail=$((fail+1))
elif grep -Fq 'ไม่สามารถตรวจ call target' "$T/strict.err"; then pass=$((pass+1))
else echo 'FAIL --secure strict-safe diagnostic'; cat "$T/strict.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/bad_return_local_addr.fac --secure --emit-ll -o "$T/escape-return.ll" >"$T/escape-return.out" 2>"$T/escape-return.err"; then
  echo 'FAIL --secure accepted returning the address of a local'; fail=$((fail+1))
elif grep -Fq 'dangling-pointer risk:' "$T/escape-return.err"; then pass=$((pass+1))
else echo 'FAIL --secure dangling return diagnostic'; cat "$T/escape-return.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/bad_pointer_store_outer.fac --secure --emit-ll -o "$T/escape-store.ll" >"$T/escape-store.out" 2>"$T/escape-store.err"; then
  echo 'FAIL --secure accepted storing an inner local address into an outer pointer'; fail=$((fail+1))
elif grep -Fq 'dangling-pointer risk:' "$T/escape-store.err"; then pass=$((pass+1))
else echo 'FAIL --secure dangling store diagnostic'; cat "$T/escape-store.err"; fail=$((fail+1)); fi
if "$FAC_COMPILER" tests/ownership/local_borrows/bad_pointer_container_add.fac --secure --emit-ll -o "$T/escape-container.ll" >"$T/escape-container.out" 2>"$T/escape-container.err"; then
  echo 'FAIL --secure accepted storing a frame pointer through list.add'; fail=$((fail+1))
elif grep -Fq 'dangling-pointer risk:' "$T/escape-container.err"; then pass=$((pass+1))
else echo 'FAIL --secure dangling container diagnostic'; cat "$T/escape-container.err"; fail=$((fail+1)); fi
printf 'secure profile tests: pass=%s fail=%s\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
