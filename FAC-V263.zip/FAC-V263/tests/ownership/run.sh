#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-own.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
# The opt-in checker must not change legacy compilation by default.
if "$FAC_COMPILER" tests/ownership/bad_same_variable.fac --emit-ll -o "$TMP/legacy.ll" >/dev/null 2>"$TMP/legacy.err"; then
  pass=$((pass+1))
else
  echo "FAIL legacy mode rejected code without --strict-ownership"; cat "$TMP/legacy.err"; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/ownership/good_distinct.fac --strict-ownership --emit-ll -o "$TMP/good.ll" >/dev/null 2>"$TMP/good.err"; then
  pass=$((pass+1))
else
  echo "FAIL distinct ref arguments unexpectedly rejected"; cat "$TMP/good.err"; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/ownership/good_shared_borrow.fac --strict-ownership --emit-ll -o "$TMP/shared.ll" >/dev/null 2>"$TMP/shared.err"; then
  pass=$((pass+1))
else
  echo "FAIL two immutable borrows unexpectedly rejected"; cat "$TMP/shared.err"; fail=$((fail+1))
fi
for f in tests/ownership/bad_same_variable.fac tests/ownership/bad_method_same_variable.fac tests/ownership/bad_shared_mutable_alias.fac; do
  if "$FAC_COMPILER" "$f" --strict-ownership --emit-ll -o "$TMP/bad.ll" >"$TMP/out" 2>"$TMP/err"; then
    echo "FAIL $(basename "$f") unexpectedly accepted"; fail=$((fail+1))
  elif grep -Fq "strict-ownership: mutable borrow conflict" "$TMP/err"; then
    pass=$((pass+1))
  else
    echo "FAIL $(basename "$f") wrong diagnostic"; cat "$TMP/err"; fail=$((fail+1))
  fi
done
for item in "bad_ref_default:ref parameter cannot have a default value" "bad_ref_variadic:ref parameter cannot be variadic"; do
  file=${item%%:*}; want=${item#*:}
  if "$FAC_COMPILER" "tests/ownership/$file.fac" --strict-ownership --emit-ll -o "$TMP/$file.ll" >"$TMP/$file.out" 2>"$TMP/$file.err"; then
    echo "FAIL $file unexpectedly accepted with --strict-ownership"; fail=$((fail+1))
  elif grep -Fq "$want" "$TMP/$file.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $file produced wrong diagnostic"; cat "$TMP/$file.err"; fail=$((fail+1))
  fi
done
if "$FAC_COMPILER" tests/ownership/good_immutable_read.fac --strict-ownership --emit-ll -o "$TMP/read.ll" >/dev/null 2>"$TMP/read.err"; then
  pass=$((pass+1))
else
  echo "FAIL read-only scalar use through ref const unexpectedly rejected"; cat "$TMP/read.err"; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/ownership/bad_immutable_method.fac --strict-ownership --emit-ll -o "$TMP/method.ll" >"$TMP/method.out" 2>"$TMP/method.err"; then
  echo "FAIL member call through ref const unexpectedly accepted"; fail=$((fail+1))
elif grep -Fq "cannot call member 'increment' through immutable borrow 'counter'" "$TMP/method.err"; then
  pass=$((pass+1))
else
  echo "FAIL immutable receiver method call produced wrong diagnostic"; cat "$TMP/method.err"; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/ownership/bad_immutable_write.fac --strict-ownership --emit-ll -o "$TMP/immutable.ll" >"$TMP/immutable.out" 2>"$TMP/immutable.err"; then
  echo "FAIL write through ref const unexpectedly accepted"; fail=$((fail+1))
elif grep -Fq "cannot modify 'value' through an immutable borrow" "$TMP/immutable.err"; then
  pass=$((pass+1))
else
  echo "FAIL ref const write produced wrong diagnostic"; cat "$TMP/immutable.err"; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/ownership/bad_weak_object_field_borrow.fac --strict-ownership --emit-ll -o "$TMP/weak-object.ll" >"$TMP/weak-object.out" 2>"$TMP/weak-object.err"; then
  echo "FAIL borrow through a weak object handle unexpectedly accepted"; fail=$((fail+1))
elif grep -Fq "local borrow cannot cross a nested/weak managed-object reference boundary" "$TMP/weak-object.err"; then
  pass=$((pass+1))
else
  echo "FAIL weak-object borrow did not fail closed"; cat "$TMP/weak-object.err"; fail=$((fail+1))
fi
echo "ownership tests: pass=$pass fail=$fail"
[ "$fail" -eq 0 ]

sh ./tests/ownership/const_methods/run.sh

sh ./tests/ownership/local_borrows/run.sh

sh ./tests/ownership/noescape/run.sh

sh ./tests/ownership/field_sensitive/run.sh

sh ./tests/ownership/effects/run.sh

sh ./tests/ownership/function_effects/run.sh
