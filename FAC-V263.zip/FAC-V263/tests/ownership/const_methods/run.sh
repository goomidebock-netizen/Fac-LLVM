#!/bin/sh
set -eu
cd "$(dirname "$0")/../../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-const-methods.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0

run_ok() {
  name=$1; expected=$2
  if ! "$FAC_COMPILER" "tests/ownership/const_methods/$name.fac" --secure -o "$TMP/$name" -O2 >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name: compile failed"; cat "$TMP/$name.err"; fail=$((fail+1)); return
  fi
  if ! "$TMP/$name" >"$TMP/$name.actual" 2>"$TMP/$name.runtime.err"; then
    echo "FAIL $name: runtime failed"; cat "$TMP/$name.runtime.err"; fail=$((fail+1)); return
  fi
  printf '%b' "$expected" >"$TMP/$name.expected"
  if diff -u "$TMP/$name.expected" "$TMP/$name.actual" >/dev/null; then pass=$((pass+1));
  else echo "FAIL $name: output mismatch"; diff -u "$TMP/$name.expected" "$TMP/$name.actual"; fail=$((fail+1)); fi
}

run_bad() {
  name=$1; expected=$2
  if "$FAC_COMPILER" "tests/ownership/const_methods/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name: invalid const contract accepted"; fail=$((fail+1));
  elif grep -Fq "$expected" "$TMP/$name.err"; then pass=$((pass+1));
  else echo "FAIL $name: wrong diagnostic"; cat "$TMP/$name.err"; fail=$((fail+1)); fi
}

run_ok good_const_receiver '1\n'
run_ok good_interface_const '0\n'
run_bad bad_const_write "cannot modify 'self' through an immutable borrow"
run_bad bad_const_calls_mutable "cannot call member 'increment' through immutable borrow 'self'"
run_bad bad_immutable_receiver_mutable "cannot call member 'increment' through immutable borrow 'counter'"
run_bad bad_const_capture_self "cannot modify 'self (captured by closure)' through an immutable borrow"
run_bad bad_const_static 'const method ใช้ได้เฉพาะ instance method'
run_bad bad_interface_const_mismatch 'ไม่ตรงกับ interface IReadOnly'

echo "const-method ownership tests: pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
