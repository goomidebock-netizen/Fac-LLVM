#!/bin/sh
# API-contract regression tests (V44): tests/api/*.fac against .out.  Same conventions as tests/run.sh.
# usage: tests/run_api.sh [-O2]      (needs build/facc + clang++ like the main suite)
set -u
cd "$(dirname "$0")/.." || exit 1
OPT=${1:--O2}; FAC_COMPILER=${FAC_COMPILER:-./build/facc}; pass=0; fail=0
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-api-tests.XXXXXXXX"); trap 'rm -rf "$TMP"' EXIT
for f in tests/api/*.fac; do
  b=${f%.fac}; name=$(basename "$b"); [ -f "$b.out" ] || continue
  printf '[api %s] %s\n' "$OPT" "$name"
  "$FAC_COMPILER" "$f" -o "$TMP/$name" $OPT 2>"$TMP/err" || { echo "FAIL(compile) $name"; head -3 "$TMP/err"; fail=$((fail+1)); continue; }
  if [ -f "$b.in" ]; then "$TMP/$name" < "$b.in" > "$TMP/out" 2>/dev/null; else "$TMP/$name" > "$TMP/out" 2>/dev/null </dev/null; fi
  if diff -q "$b.out" "$TMP/out" >/dev/null; then pass=$((pass+1)); else echo "FAIL $name"; diff "$b.out" "$TMP/out" | head -8; fail=$((fail+1)); fi
done
echo "pass=$pass fail=$fail ($OPT)"
[ "$fail" -eq 0 ]
