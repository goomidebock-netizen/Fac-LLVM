#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
FAC_COMPILER=${FAC_COMPILER:-$ROOT/build-cmake/debug/facc}
TMP=${TMPDIR:-/tmp}/fac-lifetime-test-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v202_transitive_outlives.fac" --strict-ownership --emit-ll -o "$TMP/transitive.ll" >"$TMP/transitive.out" 2>"$TMP/transitive.err" && test -s "$TMP/transitive.ll"; then
  echo 'PASS transitive outlives signature compiles'
else
  echo 'FAIL transitive outlives signature did not compile'
  cat "$TMP/transitive.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v202_reverse_outlives.fac" --emit-ll -o "$TMP/reverse.ll" >"$TMP/reverse.out" 2>"$TMP/reverse.err"; then
  echo 'FAIL reverse outlives direction was accepted'
  exit 1
elif grep -Fq 'มี lifetime ยาวพอ (outlives)' "$TMP/reverse.err"; then
  echo 'PASS reverse outlives direction rejected'
else
  echo 'FAIL reverse outlives direction produced an unexpected diagnostic'
  cat "$TMP/reverse.err"
  exit 1
fi

# V222 applies a deliberately narrow implicit return lifetime to verified
# direct functions with one non-noescape pointer input and a pointer result.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v222_elided_identity.fac" --strict-ownership -O0 -o "$TMP/v222_elided_identity" >"$TMP/v222_elided_identity.out" 2>"$TMP/v222_elided_identity.err" && "$TMP/v222_elided_identity" >"$TMP/v222_elided_identity.run.out" 2>"$TMP/v222_elided_identity.run.err"; then
  echo 'PASS V222 single-pointer return lifetime elision accepted and executed'
else
  echo 'FAIL V222 single-pointer return lifetime elision should be safe'
  cat "$TMP/v222_elided_identity.err" "$TMP/v222_elided_identity.run.err"
  exit 1
fi

for name in v222_elided_short_scope_escape v222_elided_local_return; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name should be rejected as a dangling-pointer escape"
    exit 1
  elif grep -Fq 'dangling-pointer risk' "$TMP/$name.err"; then
    echo "PASS $name rejected by inferred/checked lifetime analysis"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v222_elided_noescape_return.fac" --strict-ownership --emit-ll -o "$TMP/v222_noescape.ll" >"$TMP/v222_noescape.out" 2>"$TMP/v222_noescape.err"; then
  echo 'FAIL V222 inferred a return lifetime from a noescape parameter'
  exit 1
elif grep -Fq 'noescape contract violation' "$TMP/v222_noescape.err"; then
  echo 'PASS V222 noescape remains incompatible with returned pointer provenance'
else
  echo 'FAIL V222 noescape return produced an unexpected diagnostic'
  cat "$TMP/v222_noescape.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v222_multiple_pointer_return_ambiguous.fac" --strict-ownership --emit-ll -o "$TMP/v222_ambiguous.ll" >"$TMP/v222_ambiguous.out" 2>"$TMP/v222_ambiguous.err"; then
  echo 'FAIL V222 inferred a unique return lifetime from multiple pointer parameters'
  exit 1
elif grep -Fq 'without a verified noescape or named-lifetime contract' "$TMP/v222_ambiguous.err"; then
  echo 'PASS V222 multiple pointer inputs remain ambiguous without explicit lifetimes'
else
  echo 'FAIL V222 ambiguous pointer return produced an unexpected diagnostic'
  cat "$TMP/v222_ambiguous.err"
  exit 1
fi


# V224 extends pointer-return lifetime elision to multiple pointer inputs only
# when one parameter is the direct return source and every other pointer input
# has a body-verified noescape contract.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v224_multi_pointer_elision_verified.fac" --strict-ownership -O0 -o "$TMP/v224_multi_pointer_elision_verified" >"$TMP/v224_multi_pointer_elision_verified.out" 2>"$TMP/v224_multi_pointer_elision_verified.err" && "$TMP/v224_multi_pointer_elision_verified" >"$TMP/v224_multi_pointer_elision_verified.run.out" 2>"$TMP/v224_multi_pointer_elision_verified.run.err"; then
  if grep -Fxq '224' "$TMP/v224_multi_pointer_elision_verified.run.out"; then
    echo 'PASS V224 infers the unique direct return source among multiple pointer inputs'
  else
    echo 'FAIL V224 multi-pointer elision produced unexpected output'
    cat "$TMP/v224_multi_pointer_elision_verified.run.out"
    exit 1
  fi
else
  echo 'FAIL V224 verified multi-pointer return should compile and execute'
  cat "$TMP/v224_multi_pointer_elision_verified.err" "$TMP/v224_multi_pointer_elision_verified.run.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v224_multi_pointer_elision_ambiguous.fac" --strict-ownership --emit-ll -o "$TMP/v224_multi_pointer_elision_ambiguous.ll" >"$TMP/v224_multi_pointer_elision_ambiguous.out" 2>"$TMP/v224_multi_pointer_elision_ambiguous.err"; then
  echo 'FAIL V224 inferred a return source when multiple pointer parameters can be returned'
  exit 1
elif grep -Fq 'without a verified noescape or named-lifetime contract' "$TMP/v224_multi_pointer_elision_ambiguous.err"; then
  echo 'PASS V224 keeps multiple possible pointer return sources ambiguous'
else
  echo 'FAIL V224 ambiguous multi-pointer return produced an unexpected diagnostic'
  cat "$TMP/v224_multi_pointer_elision_ambiguous.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v224_multi_pointer_elision_bad_noescape.fac" --strict-ownership --emit-ll -o "$TMP/v224_multi_pointer_elision_bad_noescape.ll" >"$TMP/v224_multi_pointer_elision_bad_noescape.out" 2>"$TMP/v224_multi_pointer_elision_bad_noescape.err"; then
  echo 'FAIL V224 trusted a noescape parameter that is passed to a retaining call'
  exit 1
elif grep -Fq 'without a verified noescape or named-lifetime contract' "$TMP/v224_multi_pointer_elision_bad_noescape.err"; then
  echo 'PASS V224 verifies non-return pointer inputs remain noescape'
else
  echo 'FAIL V224 invalid noescape body produced an unexpected diagnostic'
  cat "$TMP/v224_multi_pointer_elision_bad_noescape.err"
  exit 1
fi

# V231 treats missing pointer provenance as Unknown (not as proof of safety)
# when a pointer or pointer-bearing value aggregate is captured by a closure.
# Verified-null aggregate fields and aggregates with no pointer fields remain
# eligible for capture because their closure payload carries no borrowed pointer.
for name in v231_known_null_aggregate_closure_capture v231_plain_aggregate_closure_capture; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
    echo "PASS $name captures an aggregate with complete safe pointer-field facts"
  else
    echo "FAIL $name should permit a verified-null/plain aggregate closure capture"
    cat "$TMP/$name.err"
    exit 1
  fi
done

for name in v231_unknown_pointer_parameter_closure_capture v231_unknown_aggregate_parameter_closure_capture; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name captured a pointer whose closure lifetime/provenance is unknown"
    exit 1
  elif grep -Fq 'cannot capture' "$TMP/$name.err"; then
    echo "PASS $name rejects closure capture with unknown pointer provenance"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V230 permits a bounded set of immutable-in-practice top-level local pointer
# aliases as the unique return source. The alias must be declared once, directly
# from the selected parameter (or an earlier verified alias), and never assigned.
for name in v230_multi_pointer_local_alias_return v230_multi_pointer_alias_chain_return; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    case "$name" in
      v230_multi_pointer_local_alias_return) expected=230 ;;
      v230_multi_pointer_alias_chain_return) expected=231 ;;
    esac
    if grep -Fxq "$expected" "$TMP/$name.run.out"; then
      echo "PASS $name verified local alias retains the selected input lifetime"
    else
      echo "FAIL $name produced unexpected runtime output"
      cat "$TMP/$name.run.out"
      exit 1
    fi
  else
    echo "FAIL $name should satisfy verified local-alias return inference"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v230_multi_pointer_alias_reassigned_rejected v230_multi_pointer_alias_shadowed_rejected v230_multi_pointer_alias_source_parameter_reassigned_rejected v230_multi_pointer_alias_exposed_to_call_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name inferred a return lifetime through an assigned or shadowed alias"
    exit 1
  elif grep -Fq 'without a verified noescape or named-lifetime contract' "$TMP/$name.err"; then
    echo "PASS $name keeps reassigned/shadowed aliases fail-closed"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v230_multi_pointer_alias_noescape_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v230_noescape_alias.ll" >"$TMP/v230_noescape_alias.out" 2>"$TMP/v230_noescape_alias.err"; then
  echo 'FAIL V230 allowed a noescape parameter to escape through a local alias'
  exit 1
elif grep -Fq 'noescape contract violation' "$TMP/v230_noescape_alias.err"; then
  echo 'PASS V230 rejects noescape escape through a local pointer alias'
else
  echo 'FAIL V230 noescape alias produced an unexpected diagnostic'
  cat "$TMP/v230_noescape_alias.err"
  exit 1
fi

# V231 permits returnable local pointer aliases declared in nested lexical
# blocks when their initializer resolves to the unique source parameter.
# Child-block aliases inherit visible parent aliases but do not escape outward.
for name in v231_multi_pointer_nested_alias_return v231_multi_pointer_nested_alias_chain_return; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    expected=231
    case "$name" in
      *chain*) expected=232 ;;
    esac
    if grep -Fxq "$expected" "$TMP/$name.run.out"; then
      echo "PASS V231 $name nested lexical alias lifetime inferred and executed"
    else
      echo "FAIL V231 $name produced unexpected output"
      cat "$TMP/$name.run.out"
      exit 1
    fi
  else
    echo "FAIL V231 $name should satisfy nested local-alias return inference"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v231_multi_pointer_nested_alias_reassigned_rejected v231_multi_pointer_nested_alias_exposed_call_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL V231 $name inferred a return lifetime through an unsafe nested alias"
    exit 1
  elif grep -Fq 'without a verified noescape or named-lifetime contract' "$TMP/$name.err"; then
    echo "PASS V231 $name remains fail-closed"
  else
    echo "FAIL V231 $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v231_nested_alias_not_visible_in_sibling_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v231_sibling_scope.ll" >"$TMP/v231_sibling_scope.out" 2>"$TMP/v231_sibling_scope.err"; then
  echo 'FAIL V231 allowed a child-block alias to leak into a sibling block'
  exit 1
elif grep -Fq 'ไม่รู้จักตัวแปร' "$TMP/v231_sibling_scope.err"; then
  echo 'PASS V231 child-block aliases remain unavailable in sibling scopes'
else
  echo 'FAIL V231 sibling-scope alias produced an unexpected diagnostic'
  cat "$TMP/v231_sibling_scope.err"
  exit 1
fi

# V203 infers abstract input lifetime regions and validates the actual pointer
# provenance reaching an annotated return, including local aliases.
for name in v203_identity_return v203_local_alias_return v203_transitive_local_return; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
    echo "PASS $name accepted"
  else
    echo "FAIL $name should satisfy the declared return lifetime"
    cat "$TMP/$name.err"
    exit 1
  fi
done

for name in v203_wrong_origin_return v203_branch_origin_return v203_local_stack_return; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name returned a pointer whose origin does not outlive the declared return lifetime"
    exit 1
  elif grep -Fq 'dangling-pointer risk' "$TMP/$name.err"; then
    echo "PASS $name rejected unsafe return provenance"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V204 substitutes declared lifetime parameters at call sites, validates
# concrete `where` relationships, and propagates only arguments that can
# satisfy the selected function's annotated return lifetime.
for name in v204_callsite_valid_outlives v204_callsite_return_source v204_callsite_same_lifetime_unification v204_callsite_nested_wrapper; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    echo "PASS $name call-site lifetime accepted and executed"
  else
    echo "FAIL $name should satisfy call-site lifetime substitution"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v204_callsite_invalid_outlives v204_callsite_untracked_argument; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name should be rejected by call-site lifetime checking"
    exit 1
  elif grep -Eq 'lifetime contract violation at call site|cannot infer the actual lifetime' "$TMP/$name.err"; then
    echo "PASS $name rejected by call-site lifetime checking"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V205 permits trusted FFI declarations to expose the same named lifetime
# contracts as FAC bodies. The caller is checked, but foreign code is not.
for name in v205_extern_identity v205_extern_where_valid; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
    echo "PASS $name extern lifetime contract accepted"
  else
    echo "FAIL $name extern lifetime contract should be accepted"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v205_extern_where_invalid.fac" --strict-ownership --emit-ll -o "$TMP/v205_extern_where_invalid.ll" >"$TMP/v205_extern_where_invalid.out" 2>"$TMP/v205_extern_where_invalid.err"; then
  echo 'FAIL extern where constraint accepted reversed caller lifetimes'
  exit 1
elif grep -Fq 'lifetime contract violation at call site' "$TMP/v205_extern_where_invalid.err"; then
  echo 'PASS extern where constraint rejects reversed caller lifetimes'
else
  echo 'FAIL extern where constraint produced an unexpected diagnostic'
  cat "$TMP/v205_extern_where_invalid.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v205_extern_return_escape.fac" --strict-ownership --emit-ll -o "$TMP/v205_extern_return_escape.ll" >"$TMP/v205_extern_return_escape.out" 2>"$TMP/v205_extern_return_escape.err"; then
  echo 'FAIL extern pointer return escaped its caller-side owner region'
  exit 1
elif grep -Fq 'dangling-pointer risk' "$TMP/v205_extern_return_escape.err"; then
  echo 'PASS extern pointer return provenance prevents local escape'
else
  echo 'FAIL extern pointer return produced an unexpected diagnostic'
  cat "$TMP/v205_extern_return_escape.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v205_extern_bad_return.fac" --emit-ll -o "$TMP/v205_extern_bad_return.ll" >"$TMP/v205_extern_bad_return.out" 2>"$TMP/v205_extern_bad_return.err"; then
  echo 'FAIL extern return lifetime without a sufficiently long parameter was accepted'
  exit 1
elif grep -Fq 'มี lifetime ยาวพอ (outlives)' "$TMP/v205_extern_bad_return.err"; then
  echo 'PASS extern return lifetime must be backed by a parameter'
else
  echo 'FAIL extern return lifetime produced an unexpected diagnostic'
  cat "$TMP/v205_extern_bad_return.err"
  exit 1
fi

# V208 carries named lifetime contracts through statically typed function values.
# These cases exercise indirect-call argument substitution, return provenance,
# where constraints, and assignment compatibility of the callback contract.
for name in v208_indirect_identity v208_local_function_value v208_indirect_where_valid v208_indirect_where_value; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    case "$name" in
      v208_indirect_identity|v208_local_function_value|v208_indirect_where_value)
        if grep -Fxq '208' "$TMP/$name.run.out"; then echo "PASS $name indirect lifetime contract accepted and executed";
        else echo "FAIL $name produced unexpected output"; cat "$TMP/$name.run.out"; exit 1; fi ;;
      *) echo "PASS $name indirect where contract accepted" ;;
    esac
  else
    echo "FAIL $name should satisfy the function-value lifetime contract"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v208_indirect_where_invalid v208_indirect_untracked v208_indirect_return_escape; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name should be rejected by indirect-call lifetime checking"
    exit 1
  elif grep -Eq 'lifetime contract violation at call site|cannot infer the actual lifetime|dangling-pointer risk' "$TMP/$name.err"; then
    echo "PASS $name rejected by indirect-call lifetime checking"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v208_indirect_bad_target.fac" --strict-ownership --emit-ll -o "$TMP/v208_indirect_bad_target.ll" >"$TMP/v208_indirect_bad_target.out" 2>"$TMP/v208_indirect_bad_target.err"; then
  echo 'FAIL an unannotated function value satisfied a named-lifetime callback type'
  exit 1
elif grep -Fq 'function value ไม่ตรงกับ function type' "$TMP/v208_indirect_bad_target.err"; then
  echo 'PASS unannotated target rejected for a named-lifetime callback type'
else
  echo 'FAIL callback target mismatch produced an unexpected diagnostic'
  cat "$TMP/v208_indirect_bad_target.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v208_indirect_bad_shape_target.fac" --strict-ownership --emit-ll -o "$TMP/v208_indirect_bad_shape_target.ll" >"$TMP/v208_indirect_bad_shape_target.out" 2>"$TMP/v208_indirect_bad_shape_target.err"; then
  echo 'FAIL a callback with a reversed outlives graph satisfied the required function type'
  exit 1
elif grep -Fq 'function value ไม่ตรงกับ function type' "$TMP/v208_indirect_bad_shape_target.err"; then
  echo 'PASS callback assignment rejects a mismatched outlives graph'
else
  echo 'FAIL callback lifetime-shape mismatch produced an unexpected diagnostic'
  cat "$TMP/v208_indirect_bad_shape_target.err"
  exit 1
fi

# V209 carries the declared callback lifetime contract through aggregate fields,
# including nested value-struct paths. Function-type noescape remains separate:
# an unverified callback target cannot use that annotation as a body proof.
for name in v209_aggregate_callback_identity v209_aggregate_callback_nested v209_aggregate_callback_class v209_aggregate_callback_where_valid; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    case "$name" in
      v209_aggregate_callback_identity)
        if grep -Fxq '209' "$TMP/$name.run.out"; then echo "PASS $name aggregate callback lifetime accepted and executed";
        else echo "FAIL $name produced unexpected output"; cat "$TMP/$name.run.out"; exit 1; fi ;;
      v209_aggregate_callback_nested)
        if grep -Fxq '211' "$TMP/$name.run.out"; then echo "PASS $name nested aggregate callback lifetime accepted and executed";
        else echo "FAIL $name produced unexpected output"; cat "$TMP/$name.run.out"; exit 1; fi ;;
      v209_aggregate_callback_class)
        if grep -Fxq '210' "$TMP/$name.run.out"; then echo "PASS $name class callback lifetime accepted and executed";
        else echo "FAIL $name produced unexpected output"; cat "$TMP/$name.run.out"; exit 1; fi ;;
      *) echo "PASS $name aggregate callback lifetime accepted" ;;
    esac
  else
    echo "FAIL $name should satisfy the aggregate callback lifetime contract"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v209_aggregate_callback_where_invalid v209_aggregate_callback_untracked; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name should be rejected by aggregate callback lifetime checking"
    exit 1
  elif grep -Eq 'lifetime contract violation at call site|cannot infer the actual lifetime' "$TMP/$name.err"; then
    echo "PASS $name rejected by aggregate callback lifetime checking"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v209_aggregate_callback_noescape_fail_closed.fac" --strict-ownership --emit-ll -o "$TMP/v209_aggregate_callback_noescape.ll" >"$TMP/v209_aggregate_callback_noescape.out" 2>"$TMP/v209_aggregate_callback_noescape.err"; then
  echo 'FAIL aggregate callback trusted an unverified noescape function-type annotation'
  exit 1
elif grep -Fq 'without a verified noescape or named-lifetime contract' "$TMP/v209_aggregate_callback_noescape.err"; then
  echo 'PASS aggregate callback keeps indirect noescape fail-closed'
else
  echo 'FAIL aggregate callback noescape case produced an unexpected diagnostic'
  cat "$TMP/v209_aggregate_callback_noescape.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v209_aggregate_callback_bad_target.fac" --strict-ownership --emit-ll -o "$TMP/v209_aggregate_callback_bad_target.ll" >"$TMP/v209_aggregate_callback_bad_target.out" 2>"$TMP/v209_aggregate_callback_bad_target.err"; then
  echo 'FAIL aggregate callback field accepted a target with a mismatched lifetime graph'
  exit 1
elif grep -Fq 'function value ไม่ตรงกับ function type' "$TMP/v209_aggregate_callback_bad_target.err"; then
  echo 'PASS aggregate callback field rejects a mismatched target lifetime graph'
else
  echo 'FAIL aggregate callback field target mismatch produced an unexpected diagnostic'
  cat "$TMP/v209_aggregate_callback_bad_target.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v209_aggregate_callback_bad_assignment.fac" --strict-ownership --emit-ll -o "$TMP/v209_aggregate_callback_bad_assignment.ll" >"$TMP/v209_aggregate_callback_bad_assignment.out" 2>"$TMP/v209_aggregate_callback_bad_assignment.err"; then
  echo 'FAIL aggregate callback field assignment accepted a mismatched lifetime graph'
  exit 1
elif grep -Fq 'function value ไม่ตรงกับ function type' "$TMP/v209_aggregate_callback_bad_assignment.err"; then
  echo 'PASS aggregate callback field assignment rejects a mismatched target lifetime graph'
else
  echo 'FAIL aggregate callback field assignment mismatch produced an unexpected diagnostic'
  cat "$TMP/v209_aggregate_callback_bad_assignment.err"
  exit 1
fi

# V225 allows pointer-bearing local value structs only when every stored
# origin outlives the struct's lexical storage. Value-struct constructors are
# transfers into a checked local destination, not arbitrary retaining calls.
for name in v225_local_struct_pointer_fields v225_struct_pointer_field_named_input_lifetime; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    case "$name" in
      v225_local_struct_pointer_fields)
        printf '41\n7\n52\n52\n' | diff -u - "$TMP/$name.run.out" >/dev/null || {
          echo 'FAIL nested value-struct pointer field runtime output'; cat "$TMP/$name.run.out"; exit 1;
        }
        echo 'PASS V225 nested local value-struct pointer fields retain checked origins' ;;
      v225_struct_pointer_field_named_input_lifetime)
        grep -Fxq '63' "$TMP/$name.run.out" || {
          echo 'FAIL V225 named-lifetime input aggregate runtime output'; cat "$TMP/$name.run.out"; exit 1;
        }
        echo 'PASS V225 named-lifetime input may be stored in a local aggregate' ;;
    esac
  else
    echo "FAIL $name should satisfy local aggregate pointer lifetime rules"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v225_struct_pointer_field_short_owner v225_struct_pointer_field_return_escape v225_struct_pointer_field_unverified_call v225_heap_object_pointer_field; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name escaped the V225 local value-struct pointer lifetime boundary"
    exit 1
  elif grep -Fq 'dangling-pointer risk' "$TMP/$name.err"; then
    echo "PASS $name rejected by V225 aggregate pointer lifetime checking"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

for name in v225_struct_pointer_field_untracked_constructor v225_struct_pointer_field_untracked_assignment; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name accepted a pointer with unknown provenance"
    exit 1
  elif grep -Fq 'cannot store an untracked pointer' "$TMP/$name.err"; then
    echo "PASS $name rejects untracked pointer provenance in a local value struct"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v225_struct_pointer_field_closure_capture.fac" --strict-ownership --emit-ll -o "$TMP/v225_struct_pointer_field_closure_capture.ll" >"$TMP/v225_struct_pointer_field_closure_capture.out" 2>"$TMP/v225_struct_pointer_field_closure_capture.err" && test -s "$TMP/v225_struct_pointer_field_closure_capture.ll"; then
  echo 'PASS V233 permits a local aggregate capture whose closure remains inside the source scope'
else
  echo 'FAIL V233 should permit the bounded local aggregate closure capture'
  cat "$TMP/v225_struct_pointer_field_closure_capture.err"
  exit 1
fi

# V226 tracks value-struct pointer provenance per exact field path. Sibling
# fields can carry independent lifetimes, while copying preserves those paths
# and overwrite/null assignments kill the previous origin for that field.
for name in v226_field_sensitive_sibling_return v226_nested_field_sensitive_return v226_overwrite_kills_old_origin v226_null_overwrite_kills_old_origin v226_copy_preserves_field_origins; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    grep -Fxq '226' "$TMP/$name.run.out" || {
      echo "FAIL $name produced unexpected output"; cat "$TMP/$name.run.out"; exit 1;
    }
    echo "PASS $name exact aggregate field provenance accepted and executed"
  else
    echo "FAIL $name should satisfy V226 field-sensitive provenance"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v226_field_sensitive_reject_wrong_sibling.fac" --strict-ownership --emit-ll -o "$TMP/v226_wrong_sibling.ll" >"$TMP/v226_wrong_sibling.out" 2>"$TMP/v226_wrong_sibling.err"; then
  echo 'FAIL V226 accepted a sibling field whose lifetime does not satisfy the declared return lifetime'
  exit 1
elif grep -Fq 'dangling-pointer risk' "$TMP/v226_wrong_sibling.err"; then
  echo 'PASS V226 rejects a wrong-lifetime sibling field return'
else
  echo 'FAIL V226 wrong-sibling field produced an unexpected diagnostic'
  cat "$TMP/v226_wrong_sibling.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v226_unknown_aggregate_field_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v226_unknown_aggregate_field_rejected.ll" >"$TMP/v226_unknown_aggregate_field_rejected.out" 2>"$TMP/v226_unknown_aggregate_field_rejected.err"; then
  echo 'FAIL V226 accepted a pointer field read from an aggregate parameter without field provenance'
  exit 1
elif grep -Fq 'no verified field provenance' "$TMP/v226_unknown_aggregate_field_rejected.err"; then
  echo 'PASS V226 rejects pointer-field reads from aggregates with unknown provenance'
else
  echo 'FAIL V226 unknown aggregate field produced an unexpected diagnostic'
  cat "$TMP/v226_unknown_aggregate_field_rejected.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v226_unknown_aggregate_copy_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v226_unknown_aggregate_copy_rejected.ll" >"$TMP/v226_unknown_aggregate_copy_rejected.out" 2>"$TMP/v226_unknown_aggregate_copy_rejected.err"; then
  echo 'FAIL V226 copied an aggregate whose pointer-field provenance is unknown'
  exit 1
elif grep -Fq 'pointer-field provenance is not fully verified' "$TMP/v226_unknown_aggregate_copy_rejected.err"; then
  echo 'PASS V226 rejects aggregate copies with incomplete pointer-field provenance'
else
  echo 'FAIL V226 unknown aggregate copy produced an unexpected diagnostic'
  cat "$TMP/v226_unknown_aggregate_copy_rejected.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v226_null_constructor_field_known.fac" --strict-ownership -O0 -o "$TMP/v226_null_constructor_field_known" >"$TMP/v226_null_constructor_field_known.out" 2>"$TMP/v226_null_constructor_field_known.err" && "$TMP/v226_null_constructor_field_known" >"$TMP/v226_null_constructor_field_known.run.out" 2>"$TMP/v226_null_constructor_field_known.run.err"; then
  grep -Fxq '226' "$TMP/v226_null_constructor_field_known.run.out" || {
    echo 'FAIL V226 known-null field produced unexpected runtime output'; cat "$TMP/v226_null_constructor_field_known.run.out"; exit 1;
  }
  echo 'PASS V226 distinguishes a verified null field from missing provenance'
else
  echo 'FAIL V226 verified-null field should compile and execute'
  cat "$TMP/v226_null_constructor_field_known.err" "$TMP/v226_null_constructor_field_known.run.err"
  exit 1
fi

# V226: assigning an all-null nested aggregate must kill the old subtree and
# retain explicit known-null facts for every pointer leaf.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v226_nested_aggregate_null_overwrite.fac" --strict-ownership -O0 -o "$TMP/v226_nested_aggregate_null_overwrite" >"$TMP/v226_nested_aggregate_null_overwrite.out" 2>"$TMP/v226_nested_aggregate_null_overwrite.err" && "$TMP/v226_nested_aggregate_null_overwrite" >"$TMP/v226_nested_aggregate_null_overwrite.run.out" 2>"$TMP/v226_nested_aggregate_null_overwrite.run.err"; then
  if grep -Fxq '226' "$TMP/v226_nested_aggregate_null_overwrite.run.out"; then
    echo 'PASS V226 nested aggregate null overwrite kills old field provenance'
  else
    echo 'FAIL V226 nested aggregate null overwrite produced unexpected output'
    cat "$TMP/v226_nested_aggregate_null_overwrite.run.out"
    exit 1
  fi
else
  echo 'FAIL V226 nested aggregate null overwrite should compile and execute'
  cat "$TMP/v226_nested_aggregate_null_overwrite.err" "$TMP/v226_nested_aggregate_null_overwrite.run.err"
  exit 1
fi

# V228 propagates aggregate pointer-field provenance through lexical blocks and
# control-flow joins. Origins are unioned across possible paths; a missing fact
# remains unknown (not null), and every possible origin must satisfy a return
# lifetime contract. Explicit where edges can still justify a longer source.
for name in v228_aggregate_if_join_wrong_lifetime v228_aggregate_nested_block_wrong_lifetime v228_aggregate_switch_join_wrong_lifetime v228_aggregate_try_join_wrong_lifetime v228_pointer_local_block_origin_wrong_lifetime v228_aggregate_loop_write_wrong_lifetime; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name accepted an aggregate pointer origin from a shorter branch lifetime"
    exit 1
  elif grep -Eq 'dangling-pointer risk|no verified field provenance' "$TMP/$name.err"; then
    echo "PASS $name rejected by aggregate lifetime/escape analysis"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

for name in v228_aggregate_same_lifetime_branch v228_aggregate_null_branch v228_aggregate_outlives_join; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    expected=228
    case "$name" in
      v228_aggregate_same_lifetime_branch) expected=99 ;;
      v228_aggregate_outlives_join) expected=99 ;;
    esac
    grep -Fxq "$expected" "$TMP/$name.run.out" || {
      echo "FAIL $name produced unexpected runtime output (expected $expected)"
      cat "$TMP/$name.run.out"
      exit 1
    }
    echo "PASS $name aggregate origins survive join and satisfy their declared lifetime"
  else
    echo "FAIL $name should satisfy aggregate lifetime join rules"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

# V229 computes a bounded may-origin fixed point for loops without explicit
# break exits. Sources from every possible iteration must satisfy the same
# return-lifetime contract; a safe overwrite after the loop kills prior origins.
for name in v229_loop_same_lifetime_while v229_loop_same_lifetime_do_while v229_loop_outlives_for v229_loop_field_overwrite_after_loop v229_loop_forpp_same_lifetime; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    case "$name" in
      v229_loop_same_lifetime_while|v229_loop_same_lifetime_do_while|v229_loop_outlives_for|v229_loop_forpp_same_lifetime) expected=99 ;;
      v229_loop_field_overwrite_after_loop) expected=229 ;;
    esac
    grep -Fxq "$expected" "$TMP/$name.run.out" || {
      echo "FAIL $name produced unexpected runtime output (expected $expected)"
      cat "$TMP/$name.run.out"
      exit 1
    }
    echo "PASS $name converged loop origins satisfy the verified lifetime"
  else
    echo "FAIL $name should satisfy loop fixed-point lifetime analysis"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v229_loop_mixed_lifetime_while v229_loop_pointer_local_while v229_loop_mixed_lifetime_do_while v229_loop_mixed_lifetime_for; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name accepted a shorter or incomparable source from a possible loop iteration"
    exit 1
  elif grep -Fq 'dangling-pointer risk' "$TMP/$name.err"; then
    echo "PASS $name rejected a loop-carried pointer origin that cannot satisfy the return lifetime"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V232: a pointer-local fact with an explicitly empty provenance set is
# Verified Null, not Unknown. A null overwrite must kill the declaration's
# historical may-origin summary; any later unknown write removes that proof.
for name in v232_null_pointer_closure_capture v232_null_overwrite_closure_capture v232_null_pointer_branch_join_capture v232_null_pointer_alias_capture v232_null_pointer_field_copy_capture; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
    echo "PASS $name permits closure capture of a verified-null pointer"
  else
    echo "FAIL $name should permit a verified-null pointer closure capture"
    cat "$TMP/$name.err"
    exit 1
  fi
done

for name in v232_unknown_pointer_after_null_rejected v232_unknown_pointer_branch_join_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name treated a pointer with an unknown possible value as verified null"
    exit 1
  elif grep -Fq 'cannot capture pointer' "$TMP/$name.err"; then
    echo "PASS $name rejects closure capture after an unknown pointer write"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V233 permits pointer-bearing captures only when the captured source is proven
# to outlive the local closure binding and the function value is used exclusively
# as a direct call in the same function. Copies, argument passing, noescape
# inputs, and shorter-lived pointees remain rejected.
for name in v233_local_pointer_nonescaping_closure v233_named_lifetime_nonescaping_closure v233_aggregate_pointer_nonescaping_closure; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership -O0 -o "$TMP/$name" >"$TMP/$name.out" 2>"$TMP/$name.err" && "$TMP/$name" >"$TMP/$name.run.out" 2>"$TMP/$name.run.err"; then
    grep -Fxq '233' "$TMP/$name.run.out" || {
      echo "FAIL $name produced unexpected output"
      cat "$TMP/$name.run.out"
      exit 1
    }
    echo "PASS $name safely captures an origin that outlives its local direct-call closure"
  else
    echo "FAIL $name should compile and execute with a bounded local closure capture"
    cat "$TMP/$name.err" "$TMP/$name.run.err"
    exit 1
  fi
done

for name in v233_closure_capture_escape_copy_rejected v233_closure_capture_escape_argument_rejected v233_shorter_scope_pointer_capture_rejected v233_noescape_parameter_capture_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL $name allowed a closure pointer capture to escape or outlive its source"
    exit 1
  elif grep -Fq 'cannot capture' "$TMP/$name.err"; then
    echo "PASS $name rejects an escaping, shorter-lived, or noescape closure capture"
  else
    echo "FAIL $name produced an unexpected diagnostic"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V234 permits nested local closures to capture a verified pointer only when
# each closure in the parent chain is itself local and used by direct calls.
# Copying or passing a nested closure remains an escape and must be rejected.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v234_nested_local_closure_capture.fac" --strict-ownership -O0 -o "$TMP/v234_nested_local_closure_capture" >"$TMP/v234_nested_local_closure_capture.out" 2>"$TMP/v234_nested_local_closure_capture.err" && "$TMP/v234_nested_local_closure_capture" >"$TMP/v234_nested_local_closure_capture.run.out" 2>"$TMP/v234_nested_local_closure_capture.run.err"; then
  grep -Fxq '234' "$TMP/v234_nested_local_closure_capture.run.out" || {
    echo 'FAIL V234 nested local closures produced unexpected output'
    cat "$TMP/v234_nested_local_closure_capture.run.out"
    exit 1
  }
  echo 'PASS V234 nested local closures remain inside verified parent closure lifetimes'
else
  echo 'FAIL V234 should permit directly invoked nested closures with valid pointer origins'
  cat "$TMP/v234_nested_local_closure_capture.err" "$TMP/v234_nested_local_closure_capture.run.err"
  exit 1
fi

for name in v234_nested_closure_escape_copy_rejected v234_nested_closure_escape_argument_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL V234 allowed a nested closure to escape its verified parent scope: $name"
    exit 1
  elif grep -Fq 'cannot capture' "$TMP/$name.err"; then
    echo "PASS V234 rejects nested closure escape: $name"
  else
    echo "FAIL V234 nested closure escape produced an unexpected diagnostic: $name"
    cat "$TMP/$name.err"
    exit 1
  fi
done

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v234_nested_parent_closure_escape_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v234_nested_parent_closure_escape_rejected.ll" >"$TMP/v234_nested_parent_closure_escape_rejected.out" 2>"$TMP/v234_nested_parent_closure_escape_rejected.err"; then
  echo 'FAIL V234 allowed a nested pointer capture when its parent closure escapes by copy'
  exit 1
elif grep -Fq 'cannot capture' "$TMP/v234_nested_parent_closure_escape_rejected.err"; then
  echo 'PASS V234 rejects nested pointer capture when its parent closure escapes'
else
  echo 'FAIL V234 parent closure escape produced an unexpected diagnostic'
  cat "$TMP/v234_nested_parent_closure_escape_rejected.err"
  exit 1
fi

# V235 handles ifv/eiv/elv result arms using a single verified pointer source.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v235_ifv_pointer_return_verified.fac" --strict-ownership -O0 -o "$TMP/v235_ifv_pointer_return_verified" >"$TMP/v235_ifv_pointer_return_verified.out" 2>"$TMP/v235_ifv_pointer_return_verified.err" && "$TMP/v235_ifv_pointer_return_verified" >"$TMP/v235_ifv_pointer_return_verified.run.out" 2>"$TMP/v235_ifv_pointer_return_verified.run.err"; then
  grep -Fxq '235' "$TMP/v235_ifv_pointer_return_verified.run.out" || {
    echo 'FAIL V235 ifv pointer return produced unexpected output'
    cat "$TMP/v235_ifv_pointer_return_verified.run.out"
    exit 1
  }
  echo 'PASS V235 ifv result arms retain the unique verified pointer source'
else
  echo 'FAIL V235 should accept same-source ifv/eiv/elv pointer returns'
  cat "$TMP/v235_ifv_pointer_return_verified.err" "$TMP/v235_ifv_pointer_return_verified.run.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v235_ifv_mixed_pointer_sources_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v235_ifv_mixed_pointer_sources_rejected.ll" >"$TMP/v235_ifv_mixed_pointer_sources_rejected.out" 2>"$TMP/v235_ifv_mixed_pointer_sources_rejected.err"; then
  echo 'FAIL V235 allowed ifv result arms with different possible pointer sources'
  exit 1
elif grep -Fq 'dangling-pointer risk' "$TMP/v235_ifv_mixed_pointer_sources_rejected.err"; then
  echo 'PASS V235 rejects ifv returns with mixed pointer source lifetimes'
else
  echo 'FAIL V235 mixed-source ifv return produced an unexpected diagnostic'
  cat "$TMP/v235_ifv_mixed_pointer_sources_rejected.err"
  exit 1
fi

# V235 adds branch-aware pointer return analysis for conditional and match
# expressions. Only result arms contribute origins; scrutinees, patterns and
# guards select a value but are not themselves returned pointer sources.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v235_match_pointer_return_verified.fac" --strict-ownership -O0 -o "$TMP/v235_match_pointer_return_verified" >"$TMP/v235_match_pointer_return_verified.out" 2>"$TMP/v235_match_pointer_return_verified.err" && "$TMP/v235_match_pointer_return_verified" >"$TMP/v235_match_pointer_return_verified.run.out" 2>"$TMP/v235_match_pointer_return_verified.run.err"; then
  grep -Fxq '235' "$TMP/v235_match_pointer_return_verified.run.out" || {
    echo 'FAIL V235 verified match pointer return produced unexpected output'
    cat "$TMP/v235_match_pointer_return_verified.run.out"
    exit 1
  }
  echo 'PASS V235 match return tracks value arms and ignores noescape guard provenance'
else
  echo 'FAIL V235 should accept a match return whose value arms share one verified source'
  cat "$TMP/v235_match_pointer_return_verified.err" "$TMP/v235_match_pointer_return_verified.run.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v235_match_mixed_pointer_sources_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v235_match_mixed_pointer_sources_rejected.ll" >"$TMP/v235_match_mixed_pointer_sources_rejected.out" 2>"$TMP/v235_match_mixed_pointer_sources_rejected.err"; then
  echo 'FAIL V235 allowed a match return with multiple possible pointer sources to escape'
  exit 1
elif grep -Fq 'dangling-pointer risk' "$TMP/v235_match_mixed_pointer_sources_rejected.err"; then
  echo 'PASS V235 rejects match returns with mixed pointer source lifetimes'
else
  echo 'FAIL V235 mixed-source match return produced an unexpected diagnostic'
  cat "$TMP/v235_match_mixed_pointer_sources_rejected.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v235_match_payload_pointer_return_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v235_match_payload_pointer_return_rejected.ll" >"$TMP/v235_match_payload_pointer_return_rejected.out" 2>"$TMP/v235_match_payload_pointer_return_rejected.err"; then
  echo 'FAIL V235 returned a match payload pointer without verified lifetime provenance'
  exit 1
elif grep -Fq 'cannot return pointer from match payload binding' "$TMP/v235_match_payload_pointer_return_rejected.err"; then
  echo 'PASS V235 rejects pointer returns from untracked enum payload bindings'
else
  echo 'FAIL V235 payload-pointer return produced an unexpected diagnostic'
  cat "$TMP/v235_match_payload_pointer_return_rejected.err"
  exit 1
fi


# V256 closes a fail-closed gap: match payload bindings must be rejected even
# when the match expression is nested inside an ifv/eiv/elv result arm.
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v256_nested_match_payload_pointer_return_rejected.fac" --strict-ownership --emit-ll -o "$TMP/v256_nested_match_payload_pointer_return_rejected.ll" >"$TMP/v256_nested_match_payload_pointer_return_rejected.out" 2>"$TMP/v256_nested_match_payload_pointer_return_rejected.err"; then
  echo 'FAIL V256 allowed a nested match payload pointer to bypass return provenance checks'
  exit 1
elif grep -Fq 'cannot return pointer from match payload binding' "$TMP/v256_nested_match_payload_pointer_return_rejected.err"; then
  echo 'PASS V256 rejects untracked match payload pointers nested in conditional result expressions'
else
  echo 'FAIL V256 nested payload-pointer return produced an unexpected diagnostic'
  cat "$TMP/v256_nested_match_payload_pointer_return_rejected.err"
  exit 1
fi

if "$FAC_COMPILER" "$ROOT/tests/lifetimes/v256_match_condition_not_returned_pointer.fac" --strict-ownership --emit-ll -o "$TMP/v256_match_condition_not_returned_pointer.ll" >"$TMP/v256_match_condition_not_returned_pointer.out" 2>"$TMP/v256_match_condition_not_returned_pointer.err" && test -s "$TMP/v256_match_condition_not_returned_pointer.ll"; then
  echo 'PASS V256 ignores match payloads used only by an ifv condition'
else
  echo 'FAIL V256 incorrectly treated a match condition as a returned pointer source'
  cat "$TMP/v256_match_condition_not_returned_pointer.err"
  exit 1
fi

# V257 also checks pointer payloads returned from `auto` functions. The parsed
# function TypeSpec still says `auto`, so a guard based only on an explicit
# `ptr` return type would miss this escape. Only direct pointer result arms are
# rejected; scalar payload returns and pointer comparisons remain valid.
for name in v257_auto_match_payload_pointer_return_rejected v257_auto_nested_match_payload_pointer_return_rejected v257_auto_generic_enum_pointer_payload_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL V257 allowed raw pointer payload to escape from auto return ($name)"
    exit 1
  elif grep -Fq 'cannot return pointer from match payload binding' "$TMP/$name.err"; then
    echo "PASS V257 rejects raw pointer payload returned from auto result expression ($name)"
  else
    echo "FAIL V257 auto pointer payload produced an unexpected diagnostic ($name)"
    cat "$TMP/$name.err"
    exit 1
  fi
done

for name in v257_auto_match_scalar_payload_return_allowed v257_auto_match_pointer_condition_return_allowed; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
    echo "PASS V257 keeps scalar returns and pointer-only conditions valid ($name)"
  else
    echo "FAIL V257 incorrectly rejected a non-pointer auto return ($name)"
    cat "$TMP/$name.err"
    exit 1
  fi
done

# V258 respects lexical shadowing between nested match pattern bindings.
# A known scalar inner binding must replace an outer pointer-capable fact,
# while a pointer inner binding must still be rejected even when it shadows
# an outer scalar binding with the same identifier.
name=v258_nested_scalar_payload_shadows_pointer_binding_allowed
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
  echo 'PASS V258 allows a scalar inner match binding to shadow an outer pointer binding'
else
  echo 'FAIL V258 incorrectly retained the outer pointer fact after scalar binding shadowing'
  cat "$TMP/$name.err"
  exit 1
fi

name=v258_nested_pointer_payload_shadows_scalar_binding_rejected
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
  echo 'FAIL V258 allowed a pointer inner match binding to escape after scalar binding shadowing'
  exit 1
elif grep -Fq 'cannot return pointer from match payload binding' "$TMP/$name.err"; then
  echo 'PASS V258 still rejects a pointer inner match binding after scalar binding shadowing'
else
  echo 'FAIL V258 pointer-shadowing regression produced an unexpected diagnostic'
  cat "$TMP/$name.err"
  exit 1
fi

# V259 rejects both pointer-preserving addition directions and pointer-minus-integer
# results derived from untracked enum payloads in inferred (`auto`) returns.
for name in \
  v259_auto_match_pointer_arithmetic_return_rejected \
  v259_auto_match_pointer_reverse_add_return_rejected \
  v259_auto_match_pointer_subtract_scalar_return_rejected \
  v259_auto_match_pointer_assignment_return_rejected \
  v259_auto_match_pointer_compound_assignment_return_rejected \
  v259_auto_match_pointer_compound_subtract_return_rejected \
  v259_auto_match_pointer_post_increment_return_rejected \
  v259_auto_match_pointer_pre_increment_return_rejected \
  v259_auto_match_pointer_post_decrement_return_rejected \
  v259_auto_match_pointer_pre_decrement_return_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL V259 allowed enum payload pointer arithmetic to escape ($name)"
    exit 1
  elif grep -Fq 'cannot return pointer from match payload binding' "$TMP/$name.err"; then
    echo "PASS V259 rejects enum payload pointer arithmetic ($name)"
  else
    echo "FAIL V259 pointer-arithmetic payload return produced an unexpected diagnostic ($name)"
    cat "$TMP/$name.err"
    exit 1
  fi
done

name=v259_auto_match_pointer_difference_scalar_allowed
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
  echo 'PASS V259 preserves scalar pointer-difference returns from enum payloads'
else
  echo 'FAIL V259 incorrectly treated pointer subtraction as a pointer return'
  cat "$TMP/$name.err"
  exit 1
fi

# V260 rejects pointer-valued struct fields loaded through an untracked enum
# pointer payload. Field metadata keeps scalar member returns accepted, while
# nested struct projections remain fail-closed for pointer fields.
for name in \
  v260_auto_match_pointer_field_return_rejected \
  v260_auto_match_nested_pointer_field_return_rejected; do
  if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
    echo "FAIL V260 allowed a pointer field derived from an untracked enum payload ($name)"
    exit 1
  elif grep -Fq 'cannot return pointer from match payload binding' "$TMP/$name.err"; then
    echo "PASS V260 rejects pointer fields derived from an untracked enum payload ($name)"
  else
    echo "FAIL V260 pointer field payload return produced an unexpected diagnostic ($name)"
    cat "$TMP/$name.err"
    exit 1
  fi
done

name=v260_auto_match_scalar_field_return_allowed
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
  echo 'PASS V260 allows scalar fields read through an untracked enum pointer payload'
else
  echo 'FAIL V260 incorrectly treated a scalar member field as a pointer return'
  cat "$TMP/$name.err"
  exit 1
fi

# V261 models the owned handle returned by thread.start as an independently
# allocated resource. Its provenance can be stored in nested value-struct
# fields and carried through explicit managed-struct move; only thread.join
# consumes this specific owned-handle origin. Arbitrary incoming ptr values
# remain untracked and must not become storable merely by sharing the type.
name=v261_thread_owned_handle_struct_move_allowed
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-move --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
  echo 'PASS V261 tracks owned thread.start handles through nested struct moves and thread.join'
else
  echo 'FAIL V261 rejected an owned thread handle transferred through nested value structs'
  cat "$TMP/$name.err"
  exit 1
fi

name=v261_untracked_thread_pointer_field_rejected
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err"; then
  echo 'FAIL V261 allowed an untracked ptr thread parameter to be stored in a value-struct field'
  exit 1
elif grep -Fq 'cannot store an untracked pointer in a value-struct field' "$TMP/$name.err"; then
  echo 'PASS V261 keeps arbitrary incoming thread pointers fail-closed'
else
  echo 'FAIL V261 untracked thread-pointer field produced an unexpected diagnostic'
  cat "$TMP/$name.err"
  exit 1
fi

name=v261_thread_handle_parameter_consumed_allowed
if "$FAC_COMPILER" "$ROOT/tests/lifetimes/$name.fac" --strict-ownership --emit-ll -o "$TMP/$name.ll" >"$TMP/$name.out" 2>"$TMP/$name.err" && test -s "$TMP/$name.ll"; then
  echo 'PASS V261 allows thread.join to consume a typed handle field from a by-value struct parameter'
else
  echo 'FAIL V261 rejected the consuming thread.join use of a typed handle field parameter'
  cat "$TMP/$name.err"
  exit 1
fi
