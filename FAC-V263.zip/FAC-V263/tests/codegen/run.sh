#!/bin/sh
set -eu
cd "$(dirname "$0")/../.." || exit 1
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-codegen.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

for OPT in -O0 -O2; do
  "$FAC_COMPILER" tests/codegen/constant_fold.fac -o "$TMP/constant-fold" "$OPT"
  "$TMP/constant-fold" > "$TMP/out"
  diff -u tests/codegen/constant_fold.out "$TMP/out"
done

# Pure constant trees should produce literals, while overflow and runtime guards
# must remain in IR when the expression cannot be safely folded.
"$FAC_COMPILER" tests/codegen/constant_fold.fac --emit-ll -o "$TMP/plain.ll"
python3 - "$TMP/plain.ll" <<'PYIR'
import re, sys
ir = open(sys.argv[1], encoding="utf-8").read()
for name in ("folded", "unaryFolded", "compareFolded"):
    match = re.search(r"define internal i32 @fac\.constant_fold\." + name + r"\([^\n]*\).*?\n}\n", ir, re.S)
    if not match:
        raise SystemExit("missing constant-folding function " + name)
    # The V129 recursion guard intentionally uses one TLS increment/decrement;
    # ignore only those two generated counter operations when checking the body.
    body = re.sub(r"(?m)^\s*%t\d+ = (?:add|sub) i32 %t\d+, 1\n", "", match.group(0))
    if re.search(r" = (?:add|sub|mul) i32 ", body):
        raise SystemExit("constant-folding did not remove arithmetic from " + name)
if not re.search(r" = add i32 2147483647, 1", ir):
    raise SystemExit("wrapping arithmetic must remain explicit in IR")
PYIR
grep -q 'call void @fac_div0()' "$TMP/plain.ll"
grep -q 'add i32 2147483647, 1' "$TMP/plain.ll"

"$FAC_COMPILER" tests/codegen/constant_fold.fac --check-overflow --emit-ll -o "$TMP/checked.ll"
grep -q 'llvm.sadd.with.overflow.i32' "$TMP/checked.ll"

echo "codegen constant-fold: PASS (-O0/-O2, overflow/division guards preserved)"

# Recursion/stack guards stay active, with the common path emitted inline.
"$FAC_COMPILER" tests/cases/t23_recursion_guard.fac --emit-ll -o "$TMP/recursion.ll"
grep -q '@fac_recursion_depth = external thread_local global i32' "$TMP/recursion.ll"
grep -q '@fac_recursion_stack_anchor = external thread_local global i64' "$TMP/recursion.ll"
grep -q 'call void @fac_recursion_fail(i32 1)' "$TMP/recursion.ll"
grep -q 'call void @fac_recursion_fail(i32 2)' "$TMP/recursion.ll"
grep -q 'store i64 0, ptr @fac_recursion_stack_anchor' "$TMP/recursion.ll"
if grep -Eq 'call void @fac_recursion_(enter|leave)\(' "$TMP/recursion.ll"; then
  echo "recursion guard hot path unexpectedly calls the Runtime" >&2
  exit 1
fi
"$FAC_COMPILER" tests/cases/t23_recursion_guard.fac -o "$TMP/recursion-guard" -O2
"$TMP/recursion-guard" > "$TMP/recursion.out"
diff -u tests/cases/t23_recursion_guard.out "$TMP/recursion.out"
echo "codegen recursion guard: PASS (inline TLS guard, stack/depth failure paths retained)"
