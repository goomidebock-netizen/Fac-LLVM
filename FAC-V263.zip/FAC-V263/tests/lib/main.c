#include <stdio.h>
#include "mylib.h"
int main(void) {
    fac_lib_init();
    printf("add=%d dist=%.1f fib=%d\n", fac_add(2, 3), fac_dist(3.0, 4.0), fac_fib(20));
    fac_hello(7);
    printf("calls=%d\n", fac_calls());
    fac_lib_shutdown();
    return 0;
}
