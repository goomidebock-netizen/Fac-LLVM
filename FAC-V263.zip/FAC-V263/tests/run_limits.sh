#!/bin/sh
# ใช้: tests/run_limits.sh  โค้ดที่ซ้อน/ต่อกันลึกผิดปกติต้องได้ compile error ปกติ (ไม่ crash/ไม่ค้าง) และนิพจน์ยาวต้อง compile ได้เร็ว
set -u
cd "$(dirname "$0")/.." || exit 1
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
D=$(mktemp -d "${TMPDIR:-/tmp}/fac-limits.XXXXXXXX"); trap 'rm -rf "$D"' EXIT
pass=0; fail=0
gen() { python3 - "$1" "$2" > "$D/$1.fac" <<'PY'
import sys
k, n = sys.argv[1], int(sys.argv[2])
body = {
  "blocks":  "{" * n + "}" * n,
  "ifs":     "if (true) {" * n + "}" * n,
  "while":   "while (false) {" * n + "}" * n,
  "paren":   "var int x = " + "(" * n + "1" + ")" * n,
  "unary":   "var int x = " + "-" * n + "1",
  "elif":    "if (false) {}\n" + "else if (false) {}\n" * n,
  "chain":   "var int x = " + "+".join(["1"] * n),
  "chainv":  "var int a = 1\nvar int x = " + "+".join(["a"] * n),
}[k]
print("public function void main() {\n" + body + "\n}")
PY
}
# FAC_LIMITS_VERBOSE=1 พิมพ์ชื่อเคสก่อนรันแต่ละอัน (ถ้าค้าง จะเห็นว่าค้างที่เคสไหน)
# deep: ต้อง exit 1 พร้อมข้อความ (ไม่ใช่ signal)
for spec in blocks:100000 ifs:100000 while:100000 paren:100000 unary:100000 elif:100000 chain:100000; do
  k=${spec%%:*}; gen "$k" "${spec#*:}"
  [ -n "${FAC_LIMITS_VERBOSE:-}" ] && echo "deep-$k ..."
  out=$(timeout 60 "$FAC_COMPILER" "$D/$k.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
  if [ $rc -eq 1 ] && echo "$out" | grep -Eq 'ซ้อนลึกเกินไป|ต่อเนื่องยาวเกินไป'; then pass=$((pass+1)); else echo "FAIL deep-$k rc=$rc"; fail=$((fail+1)); fi
done
# ok: ขนาดสมเหตุสมผลต้อง compile ผ่านภายในเวลาจำกัด (เดิม a+a+... 24 ตัวใช้เกิน 10 วินาที)
for spec in blocks:100 ifs:50 paren:50 chain:300 chainv:300 elif:200; do
  k=${spec%%:*}; gen "$k" "${spec#*:}"
  [ -n "${FAC_LIMITS_VERBOSE:-}" ] && echo "ok-$k ..."
  timeout 20 "$FAC_COMPILER" "$D/$k.fac" --emit-ll -o "$D/o.ll" >/dev/null 2>&1; rc=$?
  if [ $rc -eq 0 ]; then pass=$((pass+1)); else echo "FAIL ok-$k rc=$rc (timeout=124)"; fail=$((fail+1)); fi
done
# ไฟล์ซอร์สที่ไม่ใช่ไฟล์ปกติ (device/pipe) หรือใหญ่เกิน 64 MiB ต้องถูกปฏิเสธ ไม่ใช่อ่านจนความจำหมด
printf 'import terminal.fac\nimport zero.fac\npublic function void main() { terminal.out.println(1) }\n' > "$D/special_main.fac"
ln -s /dev/zero "$D/zero.fac" 2>/dev/null
if [ -L "$D/zero.fac" ]; then
  out=$(timeout 30 "$FAC_COMPILER" "$D/special_main.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
  if [ $rc -eq 1 ] && echo "$out" | grep -q "ไม่ใช่ไฟล์ปกติ"; then pass=$((pass+1)); else echo "FAIL special-file import rc=$rc"; fail=$((fail+1)); fi
fi
python3 - "$D/huge_src.fac" <<'PY'
import sys
with open(sys.argv[1], "w") as f:
    f.write("import terminal.fac\npublic function void main() { terminal.out.println(1) }\n# ")
    f.write("x" * (65 << 20)); f.write("\n")
PY
out=$(timeout 60 "$FAC_COMPILER" "$D/huge_src.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
if [ $rc -eq 1 ] && echo "$out" | grep -q "ไฟล์ใหญ่เกิน 64 MiB"; then pass=$((pass+1)); else echo "FAIL oversized source rc=$rc"; fail=$((fail+1)); fi
rm -f "$D/huge_src.fac"
# A source may be below the byte cap yet contain an excessive number of tiny
# tokens. The lexer must reject it deterministically before building an
# unbounded token vector or entering the parser.
python3 - "$D/many_tokens.fac" <<'PYTOK'
import sys
with open(sys.argv[1], "w", encoding="ascii") as f:
    f.write("x " * 1000000)
PYTOK
out=$(timeout 60 "$FAC_COMPILER" "$D/many_tokens.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
if [ $rc -eq 1 ] && ! echo "$out" | grep -q "จำนวน token เกิน 1,000,000 ต่อไฟล์"; then pass=$((pass+1)); else echo "FAIL token-budget boundary rc=$rc"; echo "$out" | head -4; fail=$((fail+1)); fi
python3 - "$D/many_tokens.fac" <<'PYTOK'
import sys
with open(sys.argv[1], "w", encoding="ascii") as f:
    f.write("x " * 1000001)
PYTOK
out=$(timeout 60 "$FAC_COMPILER" "$D/many_tokens.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
if [ $rc -eq 1 ] && echo "$out" | grep -q "จำนวน token เกิน 1,000,000 ต่อไฟล์"; then pass=$((pass+1)); else echo "FAIL excessive token count rc=$rc"; echo "$out" | head -4; fail=$((fail+1)); fi
rm -f "$D/many_tokens.fac"

# The per-file ceiling must not be bypassable by splitting source across files.
# Exercise the shared Lexer budget without constructing a giant AST.
${CXX:-c++} -std=c++17 -O0 -Isrc tests/lexer_total_budget.cpp src/lexer.cpp -o "$D/lexer_total_budget" || exit 1
if "$D/lexer_total_budget" | grep -q "aggregate-token-budget pass"; then pass=$((pass+1)); else echo "FAIL aggregate token budget"; fail=$((fail+1)); fi
# An import chain must fail with a source diagnostic before exhausting the C++ call stack.
python3 - "$D" <<'PYDEPTH'
import pathlib, sys
root = pathlib.Path(sys.argv[1])
(root / "depth_main.fac").write_text("import depth001.fac\npublic function void main() {}\n")
for i in range(1, 130):
    text = f"import depth{i+1:03}.fac\n" if i < 129 else ""
    (root / f"depth{i:03}.fac").write_text(text)
PYDEPTH
out=$(timeout 30 "$FAC_COMPILER" "$D/depth_main.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
if [ $rc -eq 1 ] && echo "$out" | grep -q "import ซ้อนลึกเกิน 128 ระดับ"; then pass=$((pass+1)); else echo "FAIL import depth budget rc=$rc"; echo "$out" | head -4; fail=$((fail+1)); fi
# Count the root file toward the compilation-wide module ceiling (4,096 source units).
python3 - "$D" <<'PYCOUNT'
import pathlib, sys
root = pathlib.Path(sys.argv[1])
lines = [f"import mod{i:04}.fac" for i in range(4096)]
(root / "count_main.fac").write_text("\n".join(lines) + "\npublic function void main() {}\n")
for i in range(4096):
    (root / f"mod{i:04}.fac").write_text("# intentionally empty module\n")
PYCOUNT
out=$(timeout 30 "$FAC_COMPILER" "$D/count_main.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
if [ $rc -eq 1 ] && echo "$out" | grep -q "จำนวน source modules เกิน 4,096 ต่อ compilation"; then pass=$((pass+1)); else echo "FAIL source-unit budget rc=$rc"; echo "$out" | head -4; fail=$((fail+1)); fi
# Aggregate source bytes are bounded across imports. Sparse comment-only sources
# make this boundary test cheap on disk while exercising the real Loader/stat path.
python3 - "$D" <<'PYSOURCE'
import pathlib, sys
root = pathlib.Path(sys.argv[1])
limit = 64 << 20

def sparse(path, prefix, size):
    with path.open("wb") as f:
        f.write(prefix.encode("ascii"))
        f.truncate(size)

sparse(root / "source_main.fac", "import source_child.fac\npublic function void main() {}\n#", limit)
sparse(root / "source_child.fac", "import source_tail.fac\n#", limit)
(root / "source_tail.fac").write_text("#\n")
PYSOURCE
out=$(timeout 60 "$FAC_COMPILER" "$D/source_main.fac" --emit-ll -o "$D/o.ll" 2>&1); rc=$?
if [ $rc -eq 1 ] && echo "$out" | grep -q "ขนาด source รวมเกิน 128 MiB ต่อ compilation"; then pass=$((pass+1)); else echo "FAIL aggregate source-byte budget rc=$rc"; echo "$out" | head -4; fail=$((fail+1)); fi
echo "limits pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
