#include "../src/parser.hpp"
#include <iostream>

static bool scan(size_t count, size_t &total) {
  std::string source;
  source.reserve(count * 2);
  for (size_t i = 0; i < count; ++i) source += "x ";
  try {
    auto tokens = lex(source, &total);
    return tokens.size() == count + 1; // the EOF marker is not charged
  } catch (...) {
    return false;
  }
}

int main() {
  size_t total = 0;
  if (!scan(700000, total) || total != 700000) return 1;
  if (!scan(700000, total) || total != 1400000) return 2;
  if (!scan(600000, total) || total != kMaxTokensPerCompilation) return 3;
  try {
    (void)lex(std::string("x"), &total);
  } catch (const CompileError &e) {
    if (std::string(e.what()).find("จำนวน token รวมเกิน 2,000,000") != std::string::npos) {
      std::cout << "aggregate-token-budget pass\n";
      return 0;
    }
  }
  return 4;
}
