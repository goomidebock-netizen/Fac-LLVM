#!/bin/sh
# Generic specialization cache regressions: cache hits do not consume the
# distinct-instantiation budget, while distinct specializations remain bounded.
set -eu
cd "$(dirname "$0")/../.." || exit 1
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
D=$(mktemp -d "${TMPDIR:-/tmp}/fac-generic.XXXXXXXX")
trap 'rm -rf "$D"' EXIT
pass=0

# Reusing one closed generic type 5,001 times must materialize it only once.
python3 - "$D/repeated.fac" <<'PY'
import sys
with open(sys.argv[1], "w", encoding="utf-8") as f:
    f.write("public struct Box<T> { public T value }\n")
    f.write("public struct Many {\n")
    for i in range(5001):
        f.write(f"  public struct Box<int> item{i}\n")
    f.write("}\npublic function void main() {}\n")
PY
if ! timeout 30 "$FAC_COMPILER" "$D/repeated.fac" --emit-ll -o "$D/repeated.ll"; then
    echo "FAIL repeated-specialization-cache (same specialization referenced 5,001 times)"
    exit 1
fi
[ -s "$D/repeated.ll" ] || { echo "FAIL repeated-specialization-cache (empty IR)"; exit 1; }
pass=$((pass + 1))

# The ceiling still applies to 5,001 distinct concrete specializations.
python3 - "$D/distinct.fac" <<'PY'
import sys
with open(sys.argv[1], "w", encoding="utf-8") as f:
    f.write("public struct Box<T> { public T value }\n")
    for i in range(5001):
        f.write(f"public struct Item{i} {{ public int value }}\n")
    f.write("public struct Many {\n")
    for i in range(5001):
        f.write(f"  public struct Box<Item{i}> item{i}\n")
    f.write("}\npublic function void main() {}\n")
PY
set +e
out=$(timeout 60 "$FAC_COMPILER" "$D/distinct.fac" --emit-ll -o "$D/distinct.ll" 2>&1)
rc=$?
set -e
if [ "$rc" -eq 1 ] && printf '%s\n' "$out" | grep -q 'instantiate เกิน 5000 แบบ'; then
    pass=$((pass + 1))
else
    echo "FAIL distinct-specialization-budget rc=$rc"
    printf '%s\n' "$out" | tail -8
    exit 1
fi

# Repeated calls with one explicit method type must share one emitted body.
if ! "$FAC_COMPILER" tests/generic/repeated_method.fac --emit-ll -o "$D/method.ll" >/dev/null; then
    echo "FAIL generic-method-cache (compile)"
    exit 1
fi
method_defs=$(grep -Ec '^define internal i32 @fac\.m\.Utility\.identity\$g[0-9]+' "$D/method.ll" || true)
if [ "$method_defs" -ne 1 ]; then
    echo "FAIL generic-method-cache (expected one specialization, found $method_defs)"
    exit 1
fi
pass=$((pass + 1))

echo "generic specialization tests: $pass/3 passed"
