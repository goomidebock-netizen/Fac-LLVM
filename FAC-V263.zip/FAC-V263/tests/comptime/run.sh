#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
TMP=$(mktemp -d "${TMPDIR:-/tmp}/fac-ctm.XXXXXXXX")
trap 'rm -rf "$TMP"' EXIT
pass=0
fail=0
if "$FAC_COMPILER" tests/comptime/static_assert_good.fac -O2 -o "$TMP/good" >"$TMP/good.out" 2>"$TMP/good.err" && "$TMP/good" >"$TMP/run.out" && grep -Fq "static assertions passed" "$TMP/run.out"; then
  pass=$((pass+1))
else
  echo "FAIL valid static_assert program"; cat "$TMP/good.err" "$TMP/run.out" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/typed_constant_values.fac -O2 -o "$TMP/typed-constant-values" >"$TMP/typed-constant-values.out" 2>"$TMP/typed-constant-values.err" && \
   "$TMP/typed-constant-values" >"$TMP/typed-constant-values.run" && grep -Fxq "4 4 16 8 8 true 4 2 true" "$TMP/typed-constant-values.run"; then
  pass=$((pass+1))
else
  echo "FAIL typed constant values (typeOf/sizeof/alignof, struct layout and consteval integration)"; cat "$TMP/typed-constant-values.err" "$TMP/typed-constant-values.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/structural_reflection.fac -O2 -o "$TMP/structural-reflection" >"$TMP/structural-reflection.out" 2>"$TMP/structural-reflection.err" && \
   "$TMP/structural-reflection" >"$TMP/structural-reflection.run" && grep -Fxq "4 id payload 8 2 enabled baseId 8" "$TMP/structural-reflection.run"; then
  pass=$((pass+1))
else
  echo "FAIL structural reflection (public fields, names, categories, offsets and class handles)"; cat "$TMP/structural-reflection.err" "$TMP/structural-reflection.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/const_generic_array.fac -O2 -o "$TMP/const-generic" >"$TMP/const-generic.out" 2>"$TMP/const-generic.err" && \
   "$TMP/const-generic" >"$TMP/const-generic.run" && grep -Fq "11 44 88 160 33 4" "$TMP/const-generic.run"; then
  pass=$((pass+1))
else
  echo "FAIL const generic fixed-array specialization"; cat "$TMP/const-generic.err" "$TMP/const-generic.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/consteval_functions.fac -O2 -o "$TMP/consteval" >"$TMP/consteval.out" 2>"$TMP/consteval.err" && \
   "$TMP/consteval" >"$TMP/consteval.run" && grep -Fxq "5040 55 15 8 5" "$TMP/consteval.run"; then
  pass=$((pass+1))
else
  echo "FAIL bounded consteval interpreter (recursion, branches, locals, globals and generic values)"; cat "$TMP/consteval.err" "$TMP/consteval.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/consteval_import.fac -O2 -o "$TMP/consteval-import" >"$TMP/consteval-import.out" 2>"$TMP/consteval-import.err" && \
   "$TMP/consteval-import" >"$TMP/consteval-import.run" && grep -Fxq "24 81" "$TMP/consteval-import.run"; then
  pass=$((pass+1))
else
  echo "FAIL imported consteval function with module alias and provider const global"; cat "$TMP/consteval-import.err" "$TMP/consteval-import.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/const_generic_function.fac -O2 -o "$TMP/const-generic-function" >"$TMP/const-generic-function.out" 2>"$TMP/const-generic-function.err" && \
   "$TMP/const-generic-function" >"$TMP/const-generic-function.run" && grep -Fq "12 42 12" "$TMP/const-generic-function.run"; then
  pass=$((pass+1))
else
  echo "FAIL const generic free-function specialization"; cat "$TMP/const-generic-function.err" "$TMP/const-generic-function.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/const_generic_function_dependent_type.fac -O2 -o "$TMP/const-generic-dependent" >"$TMP/const-generic-dependent.out" 2>"$TMP/const-generic-dependent.err" && \
   "$TMP/const-generic-dependent" >"$TMP/const-generic-dependent.run" && grep -Fxq "4" "$TMP/const-generic-dependent.run"; then
  pass=$((pass+1))
else
  echo "FAIL const generic dependent type specialization"; cat "$TMP/const-generic-dependent.err" "$TMP/const-generic-dependent.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/const_generic_method.fac -O2 -o "$TMP/const-generic-method" >"$TMP/const-generic-method.out" 2>"$TMP/const-generic-method.err" && \
   "$TMP/const-generic-method" >"$TMP/const-generic-method.run" && grep -Fxq "9" "$TMP/const-generic-method.run"; then
  pass=$((pass+1))
else
  echo "FAIL const generic method specialization"; cat "$TMP/const-generic-method.err" "$TMP/const-generic-method.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/const_generic_constraints.fac -O2 -o "$TMP/const-generic-constraints" >"$TMP/const-generic-constraints.out" 2>"$TMP/const-generic-constraints.err" && \
   "$TMP/const-generic-constraints" >"$TMP/const-generic-constraints.run" && grep -Fxq "6 42 5 0 -1 -2 0" "$TMP/const-generic-constraints.run"; then
  pass=$((pass+1))
else
  echo "FAIL const generic value constraints"; cat "$TMP/const-generic-constraints.err" "$TMP/const-generic-constraints.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/named_generic_arguments.fac -O2 -o "$TMP/named-generic" >"$TMP/named-generic.out" 2>"$TMP/named-generic.err" && \
   "$TMP/named-generic" >"$TMP/named-generic.run" && grep -Fxq "8 4 42 9" "$TMP/named-generic.run"; then
  pass=$((pass+1))
else
  echo "FAIL named generic arguments for types/functions/methods"; cat "$TMP/named-generic.err" "$TMP/named-generic.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/const_generic_inference.fac -O2 -o "$TMP/const-generic-inference" >"$TMP/const-generic-inference.out" 2>"$TMP/const-generic-inference.err" && \
   "$TMP/const-generic-inference" >"$TMP/const-generic-inference.run" && grep -Fxq "33 17 1.5" "$TMP/const-generic-inference.run"; then
  pass=$((pass+1))
else
  echo "FAIL const generic value inference from fixed-array extents"; cat "$TMP/const-generic-inference.err" "$TMP/const-generic-inference.run" 2>/dev/null || true; fail=$((fail+1))
fi
if "$FAC_COMPILER" tests/comptime/generic_default_arguments.fac -O2 -o "$TMP/generic-defaults" >"$TMP/generic-defaults.out" 2>"$TMP/generic-defaults.err" && \
   "$TMP/generic-defaults" >"$TMP/generic-defaults.run" && grep -Fxq "16 4 6 0 0 42 2.5 1.5 11 12 0 9 4 17 2.5 23 55 8 12 24 8 3" "$TMP/generic-defaults.run"; then
  pass=$((pass+1))
else
  echo "FAIL generic default arguments for struct/class/function/method"; cat "$TMP/generic-defaults.err" "$TMP/generic-defaults.run" 2>/dev/null || true; fail=$((fail+1))
fi
for item in "sizeof_unsized_array_bad:sizeof<array T>() ต้องระบุ fixed extent" \
            "sizeof_void_bad:sizeof ไม่รองรับ type void" \
            "type_of_runtime_argument_bad:typeOf/sizeof/alignof ต้องรับ type argument เดียว" \
            "structural_reflection_wrong_type:fieldCount ต้องรับ type argument ของ struct/class ที่ resolve แล้ว" \
            "structural_reflection_wrong_enum:fieldCount ต้องรับ type argument ของ struct/class ที่ resolve แล้ว" \
            "structural_reflection_out_of_range:fieldName index 1 อยู่นอกช่วง public instance fields" \
            "structural_reflection_runtime_arg:fieldCount ต้องรับ type argument ของ struct/class ที่ resolve แล้ว" \
            "structural_reflection_nonconstant_index:fieldOffset ต้องรับ type argument ของ struct/class ที่ resolve แล้ว"; do
  file=${item%%:*}; want=${item#*:}
  if "$FAC_COMPILER" "tests/comptime/$file.fac" --emit-ll -o "$TMP/$file.ll" >"$TMP/$file.out" 2>"$TMP/$file.err"; then
    echo "FAIL $file unexpectedly compiled"; fail=$((fail+1))
  elif grep -Fq "$want" "$TMP/$file.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $file emitted unexpected diagnostic"; cat "$TMP/$file.err"; fail=$((fail+1))
  fi
done
for item in "static_assert_bad:static_assert failed: page size must be a multiple of 4096" \
            "static_assert_nonconstant:static_assert expression ต้องเป็น integer/bool constant expression" \
            "static_assert_overflow:static_assert expression ต้องเป็น integer/bool constant expression" \
            "static_assert_divzero:static_assert expression ต้องเป็น integer/bool constant expression" \
            "static_assert_bad_shift:static_assert expression ต้องเป็น integer/bool constant expression" \
            "static_assert_call:static_assert expression ต้องเป็น integer/bool constant expression"; do
  file=${item%%:*}; want=${item#*:}
  if "$FAC_COMPILER" "tests/comptime/$file.fac" --emit-ll -o "$TMP/$file.ll" >"$TMP/$file.out" 2>"$TMP/$file.err"; then
    echo "FAIL $file unexpectedly compiled"; fail=$((fail+1))
  elif grep -Fq "$want" "$TMP/$file.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $file emitted unexpected diagnostic"; cat "$TMP/$file.err"; fail=$((fail+1))
  fi
done
for item in "consteval_runtime_argument_bad:consteval function 'square' ต้องรับ compile-time scalar arguments" \
            "consteval_method_bad:consteval รุ่น V220 รองรับเฉพาะ free function ไม่รองรับ method" \
            "consteval_non_scalar_bad:consteval return type ต้องเป็น integer/boolean/char/unichar/enum แบบ scalar" \
            "consteval_recursion_limit_bad:static_assert expression ต้องเป็น integer/bool constant expression" \
            "consteval_just_violation_bad:ถูกจำกัดด้วย just/without ใน import" \
            "consteval_side_effect_bad:static_assert expression ต้องเป็น integer/bool constant expression"; do
  file=${item%%:*}; want=${item#*:}
  if "$FAC_COMPILER" "tests/comptime/$file.fac" --emit-ll -o "$TMP/$file.ll" >"$TMP/$file.out" 2>"$TMP/$file.err"; then
    echo "FAIL $file unexpectedly compiled"; fail=$((fail+1))
  elif grep -Fq "$want" "$TMP/$file.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $file emitted unexpected diagnostic"; cat "$TMP/$file.err"; fail=$((fail+1))
  fi
done
for item in "const_generic_zero:field array ต้องมีขนาดคงที่" \
            "const_generic_wrong_kind:ต้องเป็น type argument ไม่ใช่ const value" \
            "const_generic_wrong_arity:ไม่ได้ระบุ generic parameter 'N' และไม่มีค่า default" \
            "const_generic_too_large:array ใหญ่เกินไป" \
            "const_generic_function_missing_args:cannot infer const generic parameter 'N'" \
            "const_generic_function_nonconstant:ต้องเป็น integer constant expression ที่ประเมินได้" \
            "const_generic_function_overflow:ต้องเป็น integer constant expression ที่ประเมินได้" \
            "const_generic_function_wrong_kind:ต้องเป็น const int value argument" \
            "const_generic_constraint_function_bad:const generic constraint N: positive ไม่ผ่านสำหรับค่า 0" \
            "const_generic_constraint_struct_bad:const generic constraint N: power_of_two ไม่ผ่านสำหรับค่า 6" \
            "const_generic_constraint_struct_zero:const generic constraint N: positive ไม่ผ่านสำหรับค่า 0" \
            "const_generic_constraint_unknown:const generic constraint ไม่รู้จัก 'prime'" \
            "named_generic_unknown:ไม่พบ generic parameter ชื่อ 'U'" \
            "named_generic_duplicate:ระบุ generic parameter 'N' ซ้ำ" \
            "named_generic_missing:ไม่ได้ระบุ generic parameter 'N'" \
            "named_generic_positional_after_named:ห้ามวาง positional generic argument หลัง named argument" \
            "const_generic_inference_conflict:inferred as conflicting values 2 and 3" \
            "const_generic_inference_missing:cannot infer const generic parameter 'N'" \
            "const_generic_inference_dynamic:cannot infer const generic parameter 'N' from argument 1" \
            "generic_default_missing_required:ต้องระบุ type argument หรือประกาศ default ให้ครบ" \
            "generic_default_not_trailing:generic parameters ที่มี default ต้องอยู่ท้าย declaration" \
            "generic_default_forward_reference:อ้างถึง parameter ภายหลัง 'T'" \
            "generic_default_wrong_kind:ไม่พบ generic parameter ชื่อ 'N'" \
            "generic_default_constraint_bad:const generic constraint N: positive ไม่ผ่านสำหรับค่า 0"; do
  file=${item%%:*}; want=${item#*:}
  if "$FAC_COMPILER" "tests/comptime/$file.fac" --emit-ll -o "$TMP/$file.ll" >"$TMP/$file.out" 2>"$TMP/$file.err"; then
    echo "FAIL $file unexpectedly compiled"; fail=$((fail+1))
  elif grep -Fq "$want" "$TMP/$file.err"; then
    pass=$((pass+1))
  else
    echo "FAIL $file emitted unexpected diagnostic"; cat "$TMP/$file.err"; fail=$((fail+1))
  fi
done
echo "compile-time and const-generic tests: pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
