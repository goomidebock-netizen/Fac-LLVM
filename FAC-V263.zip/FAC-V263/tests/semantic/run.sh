#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
CXX=${CXX:-c++}
SEMANTIC_CXXFLAGS=${SEMANTIC_CXXFLAGS:-"-std=c++17 -O0 -g0"}
TMP=${TMPDIR:-/tmp}/fac-semantic-test-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/ancestry_fast_path.cpp" -o "$TMP/ancestry_fast_path"
"$TMP/ancestry_fast_path"

"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/hir_model.cpp" -o "$TMP/hir_model"
"$TMP/hir_model"
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/typed_expr_hir.cpp" -o "$TMP/typed_expr_hir"
"$TMP/typed_expr_hir"

"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/scope_overload_hir.cpp" -o "$TMP/scope_overload_hir"
"$TMP/scope_overload_hir"
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/generic_inference_hir.cpp" -o "$TMP/generic_inference_hir"
"$TMP/generic_inference_hir"
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/generic_free_function_hir.cpp" -o "$TMP/generic_free_function_hir"
"$TMP/generic_free_function_hir"
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/typed_decl_builder.cpp" -o "$TMP/typed_decl_builder"
"$TMP/typed_decl_builder"
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/generated_declaration_codegen.cpp" -o "$TMP/generated_declaration_codegen"
"$TMP/generated_declaration_codegen" "$TMP/generated_declaration_codegen.ll"
if command -v clang >/dev/null 2>&1; then
  clang -Wno-override-module -x ir -c "$TMP/generated_declaration_codegen.ll" -o "$TMP/generated_declaration_codegen.o"
fi
"$CXX" $SEMANTIC_CXXFLAGS -I"$ROOT" "$ROOT/tests/semantic/generated_function_body.cpp" -o "$TMP/generated_function_body"
"$TMP/generated_function_body" "$TMP/generated_function_body.ll"
if command -v clang >/dev/null 2>&1; then
  clang -Wno-override-module -x ir -c "$TMP/generated_function_body.ll" -o "$TMP/generated_function_body.o"
fi
