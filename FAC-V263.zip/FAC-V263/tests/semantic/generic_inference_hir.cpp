#include "src/hir.hpp"

#include <cassert>
#include <string>
#include <utility>
#include <vector>

namespace {
NP node(NK kind, int line, const std::string &name = {}) {
  NP value = std::make_unique<Node>(kind, line);
  value->s = name;
  return value;
}

TypeSpec scalar(const std::string &base) {
  TypeSpec value;
  value.base = base;
  return value;
}

NP function(const std::string &name, TypeSpec result,
            const std::vector<std::pair<std::string, std::string>> &parameters,
            int line, bool isStatic = false) {
  NP value = node(NK::Func, line, name);
  value->ts = std::move(result);
  value->isPublic = true;
  value->isStatic = isStatic;
  for (const auto &parameter : parameters) {
    Param item;
    item.name = parameter.first;
    item.ts = scalar(parameter.second);
    value->params.push_back(std::move(item));
  }
  value->c.push_back(node(NK::Block, line));
  return value;
}

NP integer(int line, int64_t value) {
  NP result = node(NK::IntLit, line);
  result->iv = value;
  return result;
}

NP stringLiteral(int line, const std::string &value) {
  return node(NK::StrLit, line, value);
}

NP identifier(int line, const std::string &name) {
  return node(NK::Ident, line, name);
}

NP memberCall(int line, const std::string &receiver, const std::string &method,
              NP argument = nullptr) {
  NP member = node(NK::Member, line, method);
  member->c.push_back(identifier(line, receiver));
  NP result = node(NK::Call, line);
  result->c.push_back(std::move(member));
  if (argument) result->c.push_back(std::move(argument));
  return result;
}

NP statement(NP expression, int line) {
  NP result = node(NK::ExprStmt, line);
  result->c.push_back(std::move(expression));
  return result;
}

const fac_hir::Expression &expression(const fac_hir::SemanticModel &model,
                                      const Node *source) {
  const auto found = model.expressionIds.find(source);
  assert(found != model.expressionIds.end());
  return model.expressions.at(found->second);
}

void addLocal(Node &body, const std::string &name, TypeSpec type, int line) {
  NP declaration = node(NK::VarDecl, line, name);
  declaration->ts = std::move(type);
  body.c.push_back(std::move(declaration));
}
}  // namespace

int main() {
  Program app;
  app.module = "generic_app";
  app.file = "generic_app.fac";

  NP readable = node(NK::StructDef, 1, "IReadable");
  readable->isInterface = true;
  app.structs.push_back(std::move(readable));

  NP reader = node(NK::StructDef, 1, "Reader");
  reader->isClass = true;
  reader->implTypeSpecs.push_back(scalar("IReadable"));
  app.structs.push_back(std::move(reader));

  NP writer = node(NK::StructDef, 1, "Writer");
  writer->isClass = true;
  app.structs.push_back(std::move(writer));

  NP maybeReader = node(NK::StructDef, 1, "MaybeReader");
  maybeReader->isClass = true;
  maybeReader->implTypeSpecs.push_back(scalar("UnknownInterface"));
  app.structs.push_back(std::move(maybeReader));

  NP utility = node(NK::StructDef, 1, "Utility");
  utility->isClass = true;

  NP identity = function("identity", scalar("T"), {{"value", "T"}}, 2);
  identity->typeParams = {"T"};
  utility->methods.push_back(std::move(identity));

  NP inferred = function("inferred", scalar("auto"),
                         {{"value", "auto"}}, 3);
  utility->methods.push_back(std::move(inferred));

  NP staticIdentity = function("staticIdentity", scalar("T"),
                               {{"value", "T"}}, 4, true);
  staticIdentity->typeParams = {"T"};
  utility->methods.push_back(std::move(staticIdentity));

  NP numericIdentity = function("numericIdentity", scalar("T"),
                                {{"value", "T"}}, 5);
  numericIdentity->typeParams = {"T"};
  GenericBound numeric;
  numeric.param = "T";
  numeric.bound = scalar("numeric");
  numericIdentity->genericBounds.push_back(std::move(numeric));
  utility->methods.push_back(std::move(numericIdentity));

  NP readableIdentity = function("readableIdentity", scalar("T"), {{"value", "T"}}, 5);
  readableIdentity->typeParams = {"T"};
  GenericBound readableBound;
  readableBound.param = "T";
  readableBound.bound = scalar("IReadable");
  readableIdentity->genericBounds.push_back(std::move(readableBound));
  utility->methods.push_back(std::move(readableIdentity));

  NP first = function("first", scalar("T"), {{"values", "T"}}, 6);
  first->params[0].ts.cat = "list";
  first->params[0].ts.base = "T";
  first->typeParams = {"T"};
  utility->methods.push_back(std::move(first));

  NP choose = function("choose", scalar("auto"), {{"values", "auto"}}, 7);
  choose->params[0].ts.cat = "list";
  choose->params[0].ts.base = "auto";
  utility->methods.push_back(std::move(choose));

  NP arrayFirst = function("arrayFirst", scalar("T"), {{"values", "T"}}, 8);
  arrayFirst->params[0].ts.cat = "array";
  arrayFirst->params[0].ts.base = "T";
  arrayFirst->typeParams = {"T"};
  utility->methods.push_back(std::move(arrayFirst));

  NP autoArrayChoose = function("autoArrayChoose", scalar("auto"), {{"values", "auto"}}, 9);
  autoArrayChoose->params[0].ts.cat = "array";
  autoArrayChoose->params[0].ts.base = "auto";
  utility->methods.push_back(std::move(autoArrayChoose));

  TypeSpec optionT;
  optionT.cat = "enum";
  optionT.base = "Option";
  optionT.genericArgs.push_back(scalar("T"));
  NP wrap = function("wrap", std::move(optionT), {{"value", "T"}}, 6);
  wrap->typeParams = {"T"};
  utility->methods.push_back(std::move(wrap));

  utility->methods.push_back(function("select", scalar("int"), {{"value", "int"}}, 21));
  utility->methods.push_back(function("select", scalar("double"), {{"value", "double"}}, 22));
  app.structs.push_back(std::move(utility));

  NP box = node(NK::StructDef, 7, "Box");
  box->isClass = true;
  box->typeParams = {"U"};
  box->methods.push_back(function("get", scalar("U"), {}, 8));
  app.structs.push_back(std::move(box));

  NP option = node(NK::EnumDef, 9, "Option");
  option->typeParams = {"E"};
  app.enums.push_back(std::move(option));

  NP mainFunction = node(NK::Func, 10, "main");
  mainFunction->ts = scalar("void");
  NP body = node(NK::Block, 11);
  TypeSpec utilityType;
  utilityType.cat = "obj";
  utilityType.base = "Utility";
  addLocal(*body, "utility", std::move(utilityType), 12);

  TypeSpec boxType;
  boxType.cat = "obj";
  boxType.base = "Box";
  TypeSpec namedBoxType = scalar("int");
  namedBoxType.genericArgName = "U";
  boxType.genericArgs.push_back(std::move(namedBoxType));
  addLocal(*body, "box", std::move(boxType), 13);
  TypeSpec boxReaderType;
  boxReaderType.cat = "obj";
  boxReaderType.base = "Box";
  boxReaderType.genericArgs.push_back(scalar("Reader"));
  addLocal(*body, "boxReader", std::move(boxReaderType), 13);
  TypeSpec readerType;
  readerType.cat = "obj";
  readerType.base = "Reader";
  addLocal(*body, "reader", std::move(readerType), 13);
  TypeSpec writerType;
  writerType.cat = "obj";
  writerType.base = "Writer";
  addLocal(*body, "writer", std::move(writerType), 13);
  TypeSpec mysteryType;
  mysteryType.cat = "obj";
  mysteryType.base = "Mystery";
  addLocal(*body, "mystery", std::move(mysteryType), 13);
  TypeSpec maybeReaderType;
  maybeReaderType.cat = "obj";
  maybeReaderType.base = "MaybeReader";
  addLocal(*body, "maybeReader", std::move(maybeReaderType), 13);

  TypeSpec integerList;
  integerList.cat = "list";
  integerList.kind = "var";
  integerList.base = "int";
  addLocal(*body, "numbers", std::move(integerList), 13);
  TypeSpec integerArray;
  integerArray.cat = "array";
  integerArray.kind = "var";
  integerArray.base = "int";
  addLocal(*body, "numbersArray", std::move(integerArray), 13);

  NP explicitCall = memberCall(14, "utility", "identity", integer(14, 7));
  Node *explicitCallee = explicitCall->c[0].get();
  TypeSpec namedIdentityType = scalar("int");
  namedIdentityType.genericArgName = "T";
  explicitCallee->explicitTypeArgs.push_back(std::move(namedIdentityType));
  const Node *explicitCallSource = explicitCall.get();
  body->c.push_back(statement(std::move(explicitCall), 14));

  NP inferredCall = memberCall(15, "utility", "inferred", integer(15, 9));
  const Node *inferredCallSource = inferredCall.get();
  body->c.push_back(statement(std::move(inferredCall), 15));

  NP staticCall = memberCall(16, "Utility", "staticIdentity", integer(16, 11));
  staticCall->c[0]->explicitTypeArgs.push_back(scalar("long"));
  const Node *staticCallSource = staticCall.get();
  body->c.push_back(statement(std::move(staticCall), 16));

  NP numericCall = memberCall(17, "utility", "numericIdentity", integer(17, 13));
  numericCall->c[0]->explicitTypeArgs.push_back(scalar("int"));
  const Node *numericCallSource = numericCall.get();
  body->c.push_back(statement(std::move(numericCall), 17));

  NP interfaceCall = memberCall(17, "utility", "readableIdentity", identifier(17, "reader"));
  interfaceCall->c[0]->explicitTypeArgs.push_back(scalar("Reader"));
  const Node *interfaceCallSource = interfaceCall.get();
  body->c.push_back(statement(std::move(interfaceCall), 17));

  NP failedInterfaceCall = memberCall(17, "utility", "readableIdentity", identifier(17, "writer"));
  failedInterfaceCall->c[0]->explicitTypeArgs.push_back(scalar("Writer"));
  const Node *failedInterfaceCallSource = failedInterfaceCall.get();
  body->c.push_back(statement(std::move(failedInterfaceCall), 17));

  NP unresolvedInterfaceCall = memberCall(17, "utility", "readableIdentity", identifier(17, "mystery"));
  unresolvedInterfaceCall->c[0]->explicitTypeArgs.push_back(scalar("Mystery"));
  const Node *unresolvedInterfaceCallSource = unresolvedInterfaceCall.get();
  body->c.push_back(statement(std::move(unresolvedInterfaceCall), 17));

  NP unresolvedInheritanceCall = memberCall(17, "utility", "readableIdentity", identifier(17, "maybeReader"));
  unresolvedInheritanceCall->c[0]->explicitTypeArgs.push_back(scalar("MaybeReader"));
  const Node *unresolvedInheritanceCallSource = unresolvedInheritanceCall.get();
  body->c.push_back(statement(std::move(unresolvedInheritanceCall), 17));

  NP rejectedConstraint = memberCall(18, "utility", "numericIdentity",
                                     stringLiteral(18, "not numeric"));
  TypeSpec dynamicString = scalar("string");
  dynamicString.kind = "dyn";
  rejectedConstraint->c[0]->explicitTypeArgs.push_back(std::move(dynamicString));
  const Node *rejectedConstraintSource = rejectedConstraint.get();
  body->c.push_back(statement(std::move(rejectedConstraint), 18));

  NP wrappedCall = memberCall(19, "utility", "wrap", integer(19, 17));
  wrappedCall->c[0]->explicitTypeArgs.push_back(scalar("int"));
  const Node *wrappedCallSource = wrappedCall.get();
  body->c.push_back(statement(std::move(wrappedCall), 19));

  NP boxGet = memberCall(20, "box", "get");
  const Node *boxGetSource = boxGet.get();
  body->c.push_back(statement(std::move(boxGet), 20));

  NP boxReaderGet = memberCall(20, "boxReader", "get");
  const Node *boxReaderGetSource = boxReaderGet.get();
  body->c.push_back(statement(std::move(boxReaderGet), 20));

  NP genericListCall = memberCall(22, "utility", "first", identifier(22, "numbers"));
  genericListCall->c[0]->explicitTypeArgs.push_back(scalar("int"));
  const Node *genericListCallSource = genericListCall.get();
  body->c.push_back(statement(std::move(genericListCall), 22));

  NP autoListCall = memberCall(22, "utility", "choose", identifier(22, "numbers"));
  const Node *autoListCallSource = autoListCall.get();
  body->c.push_back(statement(std::move(autoListCall), 22));

  NP genericArrayCall = memberCall(22, "utility", "arrayFirst", identifier(22, "numbersArray"));
  genericArrayCall->c[0]->explicitTypeArgs.push_back(scalar("int"));
  const Node *genericArrayCallSource = genericArrayCall.get();
  body->c.push_back(statement(std::move(genericArrayCall), 22));

  NP autoArrayCall = memberCall(22, "utility", "autoArrayChoose", identifier(22, "numbersArray"));
  const Node *autoArrayCallSource = autoArrayCall.get();
  body->c.push_back(statement(std::move(autoArrayCall), 22));

  NP overloadCall = memberCall(23, "utility", "select", integer(23, 19));
  const Node *overloadCallSource = overloadCall.get();
  body->c.push_back(statement(std::move(overloadCall), 23));

  NP missingExplicit = memberCall(24, "utility", "identity", integer(24, 19));
  const Node *missingExplicitSource = missingExplicit.get();
  body->c.push_back(statement(std::move(missingExplicit), 24));

  mainFunction->c.push_back(std::move(body));
  app.funcs.push_back(std::move(mainFunction));

  const fac_hir::SemanticModel model = fac_hir::analyze({&app});
  assert(model.validate());

  const auto &explicitResult = expression(model, explicitCallSource);
  assert(explicitResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(explicitResult.call.genericState == fac_hir::GenericInferenceState::ExplicitArguments);
  assert(explicitResult.call.explicitTypeArguments.size() == 1);
  assert(model.types.get(explicitResult.type).base == "int");
  assert(explicitResult.call.substitutions.at("T") == explicitResult.type);

  const auto &inferredResult = expression(model, inferredCallSource);
  assert(inferredResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(inferredResult.call.genericState == fac_hir::GenericInferenceState::InferredFromArguments);
  assert(model.types.get(inferredResult.type).base == "int");
  assert(inferredResult.call.substitutions.at("@auto") == inferredResult.type);

  const auto &staticResult = expression(model, staticCallSource);
  assert(staticResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(staticResult.call.isMethodCall);
  assert(model.types.get(staticResult.type).base == "long");

  const auto &numericResult = expression(model, numericCallSource);
  assert(numericResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(numericResult.type).base == "int");

  const auto &interfaceResult = expression(model, interfaceCallSource);
  assert(interfaceResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(interfaceResult.type).base == "Reader");

  const auto &failedInterfaceResult = expression(model, failedInterfaceCallSource);
  assert(failedInterfaceResult.call.state == fac_hir::CallResolutionState::NoViableCandidate);
  assert(failedInterfaceResult.call.genericState == fac_hir::GenericInferenceState::ConstraintFailure);

  const auto &unresolvedInterfaceResult = expression(model, unresolvedInterfaceCallSource);
  assert(unresolvedInterfaceResult.call.state == fac_hir::CallResolutionState::Deferred);
  assert(unresolvedInterfaceResult.call.genericState == fac_hir::GenericInferenceState::Deferred);

  const auto &unresolvedInheritanceResult = expression(model, unresolvedInheritanceCallSource);
  assert(unresolvedInheritanceResult.call.state == fac_hir::CallResolutionState::Deferred);
  assert(unresolvedInheritanceResult.call.genericState == fac_hir::GenericInferenceState::Deferred);

  const auto &constraintResult = expression(model, rejectedConstraintSource);
  assert(constraintResult.call.state == fac_hir::CallResolutionState::NoViableCandidate);
  assert(constraintResult.call.genericState == fac_hir::GenericInferenceState::ConstraintFailure);

  const auto &wrappedResult = expression(model, wrappedCallSource);
  assert(wrappedResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(wrappedResult.type).cat == "enum");
  assert(model.types.get(wrappedResult.type).base == "Option");
  assert(model.types.get(model.types.get(wrappedResult.type).genericArguments.at(0)).base == "int");

  const auto &boxResult = expression(model, boxGetSource);
  assert(boxResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(boxResult.call.genericState == fac_hir::GenericInferenceState::ExplicitArguments);
  assert(model.types.get(boxResult.type).base == "int");

  const auto &boxReaderResult = expression(model, boxReaderGetSource);
  assert(boxReaderResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(boxReaderResult.type).category == fac_hir::TypeCategory::Named);
  assert(model.types.get(boxReaderResult.type).base == "Reader");

  const auto &genericListResult = expression(model, genericListCallSource);
  assert(genericListResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(genericListResult.call.substitutions.at("T") != fac_hir::kInvalidType);
  assert(model.types.get(genericListResult.type).base == "int");

  const auto &autoListResult = expression(model, autoListCallSource);
  assert(autoListResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(autoListResult.call.genericState == fac_hir::GenericInferenceState::InferredFromArguments);
  assert(model.types.get(autoListResult.type).base == "int");
  assert(model.types.get(autoListResult.call.substitutions.at("@auto")).base == "int");

  const auto &genericArrayResult = expression(model, genericArrayCallSource);
  assert(genericArrayResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(genericArrayResult.type).base == "int");

  const auto &autoArrayResult = expression(model, autoArrayCallSource);
  assert(autoArrayResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(autoArrayResult.call.genericState == fac_hir::GenericInferenceState::InferredFromArguments);
  assert(model.types.get(autoArrayResult.type).base == "int");

  const auto &overloadResult = expression(model, overloadCallSource);
  assert(overloadResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(model.symbol(overloadResult.call.selected).parameters[0].type.type).base == "int");

  const auto &missingExplicitResult = expression(model, missingExplicitSource);
  assert(missingExplicitResult.call.state == fac_hir::CallResolutionState::Deferred);
  assert(missingExplicitResult.call.genericState == fac_hir::GenericInferenceState::Deferred);

  TypeSpec expectedOption;
  expectedOption.cat = "enum";
  expectedOption.base = "Option";
  expectedOption.genericArgs.push_back(scalar("int"));
  assert(const_cast<fac_hir::TypeArena &>(model.types).intern(expectedOption) == wrappedResult.type);
  return 0;
}
