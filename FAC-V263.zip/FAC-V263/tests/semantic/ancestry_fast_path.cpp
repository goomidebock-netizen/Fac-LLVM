#include "../../src/codegen.hpp"
#include <iostream>
#include <string>

static int failures = 0;
static void check(bool ok, const char *label) {
  if (!ok) { std::cerr << "FAIL: " << label << '\n'; ++failures; }
}

static StructInfo &record(Gen &g, const std::string &name, bool isClass = false, bool isInterface = false) {
  StructInfo &info = g.structs[name];
  info.name = name;
  info.isClass = isClass;
  info.isInterface = isInterface;
  return info;
}

int main() {
  Gen g;

  record(g, "IRoot", false, true);
  record(g, "ILeft", false, true).impls = {"IRoot"};
  record(g, "IRight", false, true).impls = {"IRoot"};
  record(g, "IDiamond", false, true).impls = {"ILeft", "IRight"};
  record(g, "RootClass", true);
  record(g, "BaseClass", true).parent = "RootClass";
  record(g, "BaseClass", true).impls = {"IDiamond"};
  record(g, "ChildClass", true).parent = "BaseClass";
  record(g, "GrandChild", true).parent = "ChildClass";
  record(g, "OtherClass", true);
  record(g, "PlainStruct");

  check(g.isSubclass("ChildClass", "BaseClass"), "direct class parent");
  check(g.isSubclass("GrandChild", "RootClass"), "transitive class parent");
  check(g.isSubclass("GrandChild", "GrandChild"), "same-type relation");
  check(!g.isSubclass("OtherClass", "BaseClass"), "unrelated classes");
  check(!g.isSubclass("PlainStruct", "BaseClass"), "non-class has no class ancestry");
  check(!g.isSubclass("ChildClass", "MissingClass"), "unknown class target");

  check(g.isSubclass("ChildClass", "IRoot"), "class inherits implemented interface transitively");
  check(g.isSubclass("GrandChild", "ILeft"), "class parent preserves interface implementation");
  check(g.isSubclass("IDiamond", "IRoot"), "diamond interface inheritance");
  check(!g.isSubclass("OtherClass", "IRoot"), "unrelated class does not implement interface");

  check(g.isSubclassOf("GrandChild", "RootClass"), "protected access follows transitive class ancestry");
  check(!g.isSubclassOf("ChildClass", "IRoot"), "protected access ignores interfaces");
  check(!g.isSubclassOf("OtherClass", "RootClass"), "protected access rejects unrelated class");
  check(!g.isSubclassOf("MissingClass", "MissingClass"), "unknown protected-access class is not accepted");

  // Malformed cycles are rejected by semantic registration, but these helpers must still terminate defensively.
  record(g, "CycleA", true).parent = "CycleB";
  record(g, "CycleB", true).parent = "CycleA";
  check(!g.isSubclass("CycleA", "OtherClass"), "class-cycle traversal is bounded");
  check(!g.isSubclassOf("CycleA", "OtherClass"), "protected parent-cycle traversal is bounded");
  record(g, "CycleIA", false, true).impls = {"CycleIB"};
  record(g, "CycleIB", false, true).impls = {"CycleIA"};
  check(!g.isSubclass("CycleIA", "NeverInterface"), "interface-cycle traversal terminates");

  if (failures) return 1;
  std::cout << "semantic ancestry: 17 checks passed\n";
  return 0;
}
