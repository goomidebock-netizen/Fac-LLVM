#include "src/codegen.hpp"

#include <cassert>
#include <fstream>
#include <string>
#include <vector>

namespace {
NP node(NK kind, int line, const std::string &name = {}) {
  NP result = std::make_unique<Node>(kind, line);
  result->s = name;
  return result;
}

NP integer(int line, int64_t value) {
  NP result = node(NK::IntLit, line);
  result->iv = value;
  return result;
}

fac_hir::TypeId builtin(fac_hir::SemanticModel &model, const std::string &name) {
  TypeSpec spec;
  spec.base = name;
  return model.types.intern(spec);
}

void appendMainCall(Program &program) {
  NP mainFunction = node(NK::Func, 1, "main");
  mainFunction->ts.base = "void";
  NP body = node(NK::Block, 1);
  NP call = node(NK::Call, 2);
  call->c.push_back(node(NK::Ident, 2, "generatedAdd"));
  call->c.push_back(integer(2, 20));
  call->c.push_back(integer(2, 1));
  NP expression = node(NK::ExprStmt, 2);
  expression->c.push_back(std::move(call));
  body->c.push_back(std::move(expression));
  NP clampCall = node(NK::Call, 3);
  clampCall->c.push_back(node(NK::Ident, 3, "generatedSelect"));
  clampCall->c.push_back(integer(3, 7));
  NP clampExpression = node(NK::ExprStmt, 3);
  clampExpression->c.push_back(std::move(clampCall));
  body->c.push_back(std::move(clampExpression));
  mainFunction->c.push_back(std::move(body));
  program.funcs.push_back(std::move(mainFunction));
}
}  // namespace

int main(int argc, char **argv) {
  Program program;
  program.module = "generated_body_app";
  program.file = "generated_body_app.fac";
  appendMainCall(program);

  std::vector<Program *> programs{&program};
  fac_hir::SemanticModel model = fac_hir::analyze(programs);
  assert(model.validate());
  const fac_hir::TypeId intType = builtin(model, "int");

  fac_hir::TypedDeclarationBuilder declarations(model);
  fac_hir::GeneratedParameterSpec value;
  value.name = "value";
  value.type = intType;
  const auto doubleFunction = declarations.addFunction(
      "generated_body_app", "generatedDouble", intType, {value});

  fac_hir::TypedAstFactory expressions(model);
  fac_hir::TypedFunctionBodyBuilder doubleBody(model, expressions, doubleFunction.symbol);
  auto parameter = doubleBody.parameter(0);
  auto two = expressions.integerLiteral(2, intType);
  auto product = expressions.binary("*", parameter, two, intType);
  doubleBody.addLocal("twice", intType, product);
  doubleBody.returnValue(doubleBody.localReference("twice"));
  doubleBody.commit();
  assert(model.validate());

  fac_hir::GeneratedParameterSpec left;
  left.name = "left";
  left.type = intType;
  fac_hir::GeneratedParameterSpec right;
  right.name = "right";
  right.type = intType;
  const auto addFunction = declarations.addFunction(
      "generated_body_app", "generatedAdd", intType, {left, right});

  fac_hir::TypedFunctionBodyBuilder addBody(model, expressions, addFunction.symbol);
  auto lhs = addBody.parameter(0);
  auto rhs = addBody.parameter(1);
  auto sum = expressions.binary("+", lhs, rhs, intType);
  auto doubled = expressions.call(doubleFunction.symbol, {sum});
  addBody.addLocal("result", intType, doubled);
  addBody.returnValue(addBody.localReference("result"));
  addBody.commit();
  assert(model.validate());

  // Generated structured control flow: mutable local + assignment in both
  // branches. The body still has one terminal return after the if/else.
  fac_hir::GeneratedParameterSpec selectValue;
  selectValue.name = "value";
  selectValue.type = intType;
  const auto selectFunction = declarations.addFunction(
      "generated_body_app", "generatedSelect", intType, {selectValue});
  const fac_hir::TypeId boolType = builtin(model, "bool");
  fac_hir::TypedFunctionBodyBuilder selectBody(model, expressions, selectFunction.symbol);
  auto selectParameter = selectBody.parameter(0);
  selectBody.addMutableLocal("result", intType, selectParameter);
  auto zero = expressions.integerLiteral(0, intType);
  auto isNegative = expressions.binary("<", selectParameter, zero, boolType);
  selectBody.beginIf(isNegative);
  selectBody.assignLocal("result", zero);
  selectBody.beginElse();
  auto isZero = expressions.binary("==", selectParameter, zero, boolType);
  auto one = expressions.integerLiteral(1, intType);
  selectBody.beginIf(isZero);
  selectBody.assignLocal("result", one);
  selectBody.beginElse();
  selectBody.assignLocal("result", selectParameter);
  selectBody.endIf();
  selectBody.endIf();
  selectBody.returnValue(selectBody.localReference("result"));
  selectBody.commit();
  assert(model.validate());

  // The body builder rejects mismatched return types and use-before-declare.
  fac_hir::GeneratedParameterSpec boolParameter;
  boolParameter.name = "flag";
  boolParameter.type = builtin(model, "bool");
  const auto invalidFunction = declarations.addFunction(
      "generated_body_app", "invalidReturn", intType, {boolParameter});
  fac_hir::TypedFunctionBodyBuilder invalidBody(model, expressions, invalidFunction.symbol);
  bool rejectedReturn = false;
  try { invalidBody.returnValue(invalidBody.parameter(0)); }
  catch (const std::invalid_argument &) { rejectedReturn = true; }
  assert(rejectedReturn);
  bool rejectedForwardLocal = false;
  try { (void)invalidBody.localReference("later"); }
  catch (const std::invalid_argument &) { rejectedForwardLocal = true; }
  assert(rejectedForwardLocal);
  invalidBody.returnValue(expressions.integerLiteral(0, intType));
  invalidBody.commit();
  assert(model.validate());

  // Immutable locals cannot be assigned and if conditions must be bool.
  const auto invalidMutationFunction = declarations.addFunction(
      "generated_body_app", "invalidMutation", intType, {value});
  fac_hir::TypedFunctionBodyBuilder invalidMutation(model, expressions, invalidMutationFunction.symbol);
  invalidMutation.addLocal("fixed", intType, invalidMutation.parameter(0));
  bool rejectedImmutableAssignment = false;
  try { invalidMutation.assignLocal("fixed", expressions.integerLiteral(1, intType)); }
  catch (const std::invalid_argument &) { rejectedImmutableAssignment = true; }
  assert(rejectedImmutableAssignment);
  invalidMutation.returnValue(invalidMutation.localReference("fixed"));
  invalidMutation.commit();
  assert(model.validate());

  const auto invalidConditionFunction = declarations.addFunction(
      "generated_body_app", "invalidCondition", intType, {value});
  fac_hir::TypedFunctionBodyBuilder invalidCondition(model, expressions, invalidConditionFunction.symbol);
  bool rejectedIntegerCondition = false;
  try { invalidCondition.beginIf(invalidCondition.parameter(0)); }
  catch (const std::invalid_argument &) { rejectedIntegerCondition = true; }
  assert(rejectedIntegerCondition);
  invalidCondition.returnValue(invalidCondition.parameter(0));
  invalidCondition.commit();
  assert(model.validate());

  const auto invalidAssignmentFunction = declarations.addFunction(
      "generated_body_app", "invalidAssignment", intType, {value});
  fac_hir::TypedFunctionBodyBuilder invalidAssignment(model, expressions, invalidAssignmentFunction.symbol);
  invalidAssignment.addMutableLocal("mutableValue", intType, invalidAssignment.parameter(0));
  bool rejectedAssignmentType = false;
  try { invalidAssignment.assignLocal("mutableValue", expressions.booleanLiteral(true, boolType)); }
  catch (const std::invalid_argument &) { rejectedAssignmentType = true; }
  assert(rejectedAssignmentType);
  invalidAssignment.returnValue(invalidAssignment.localReference("mutableValue"));
  invalidAssignment.commit();
  assert(model.validate());

  fac_hir::GeneratedParameterSpec flagParameter;
  flagParameter.name = "flag";
  flagParameter.type = boolType;
  const auto incompleteIfFunction = declarations.addFunction(
      "generated_body_app", "incompleteIf", intType, {flagParameter});
  fac_hir::TypedFunctionBodyBuilder incompleteIf(model, expressions, incompleteIfFunction.symbol);
  incompleteIf.beginIf(expressions.booleanLiteral(true, boolType));
  bool rejectedMissingElse = false;
  try { incompleteIf.endIf(); }
  catch (const std::logic_error &) { rejectedMissingElse = true; }
  assert(rejectedMissingElse);
  bool rejectedReturnWithOpenIf = false;
  try { incompleteIf.returnValue(expressions.integerLiteral(0, intType)); }
  catch (const std::logic_error &) { rejectedReturnWithOpenIf = true; }
  assert(rejectedReturnWithOpenIf);

  Gen generator;
  bool hasMain = false;
  const std::string ir = generator.generate(programs, "generated_body_app", &hasMain, &model);
  assert(hasMain);
  assert(ir.find("define internal i32 @fac.generated_body_app.generatedDouble(i32 %p0)") != std::string::npos);
  assert(ir.find("define internal i32 @fac.generated_body_app.generatedAdd(i32 %p0, i32 %p1)") != std::string::npos);
  assert(ir.find("define internal i32 @fac.generated_body_app.generatedSelect(i32 %p0)") != std::string::npos);
  assert(ir.find("mul i32") != std::string::npos);
  assert(ir.find("add i32") != std::string::npos);
  assert(ir.find("call i32 @fac.generated_body_app.generatedDouble") != std::string::npos);
  assert(ir.find("call i32 @fac.generated_body_app.generatedAdd(i32 20, i32 1)") != std::string::npos);
  assert(ir.find("icmp slt i32") != std::string::npos);
  assert(ir.find("icmp eq i32") != std::string::npos);
  assert(ir.find("br i1") != std::string::npos);
  assert(ir.find("store i32 0") != std::string::npos);
  assert(ir.find("store i32 1") != std::string::npos);
  assert(ir.find("store i32 %p0") != std::string::npos);
  assert(generator.generatedFunctionSymbols.count(doubleFunction.symbol) == 0);
  assert(generator.generatedFunctionSymbols.count(addFunction.symbol) == 0);
  assert(program.funcs.size() == 1); // source AST remains unchanged

  if (argc > 1) {
    std::ofstream output(argv[1], std::ios::binary);
    assert(output.good());
    output << ir;
    assert(output.good());
  }
}
