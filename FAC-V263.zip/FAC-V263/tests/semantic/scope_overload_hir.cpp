#include "src/hir.hpp"

#include <cassert>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace {
NP makeNode(NK kind, int line, const std::string &name = {}) {
  NP value = std::make_unique<Node>(kind, line);
  value->s = name;
  return value;
}

TypeSpec type(const std::string &base) {
  TypeSpec value;
  value.base = base;
  return value;
}

NP integer(int line, int64_t value) {
  NP result = makeNode(NK::IntLit, line);
  result->iv = value;
  return result;
}

NP floating(int line, double value) {
  NP result = makeNode(NK::FloatLit, line);
  result->dv = value;
  return result;
}

NP identifier(int line, const std::string &name) {
  return makeNode(NK::Ident, line, name);
}

NP expressionStatement(NP expression, int line) {
  NP result = makeNode(NK::ExprStmt, line);
  result->c.push_back(std::move(expression));
  return result;
}

NP call(int line, const std::string &name) {
  NP result = makeNode(NK::Call, line);
  result->c.push_back(identifier(line, name));
  return result;
}

NP call(int line, const std::string &name, NP argument) {
  NP result = makeNode(NK::Call, line);
  result->c.push_back(identifier(line, name));
  result->c.push_back(std::move(argument));
  return result;
}

NP memberCall(int line, const std::string &moduleAlias,
              const std::string &name, NP argument) {
  NP member = makeNode(NK::Member, line, name);
  member->c.push_back(identifier(line, moduleAlias));
  NP result = makeNode(NK::Call, line);
  result->c.push_back(std::move(member));
  result->c.push_back(std::move(argument));
  return result;
}

NP function(const std::string &name, const std::string &resultType,
            const std::vector<std::pair<std::string, std::string>> &parameters,
            int line) {
  NP result = makeNode(NK::Func, line, name);
  result->isPublic = true;
  result->ts = type(resultType);
  for (const auto &parameter : parameters) {
    Param value;
    value.name = parameter.first;
    value.ts = type(parameter.second);
    result->params.push_back(std::move(value));
  }
  result->c.push_back(makeNode(NK::Block, line));
  return result;
}

const fac_hir::Expression &expr(const fac_hir::SemanticModel &model,
                                const Node *node) {
  const auto found = model.expressionIds.find(node);
  assert(found != model.expressionIds.end());
  return model.expressions.at(found->second);
}

const fac_hir::LocalSymbol &local(const fac_hir::SemanticModel &model,
                                  fac_hir::LocalSymbolId id) {
  assert(id != fac_hir::kInvalidLocal);
  return model.locals.at(id);
}

std::string baseType(const fac_hir::SemanticModel &model,
                     const fac_hir::Expression &expression) {
  assert(expression.typeState == fac_hir::ExprTypeState::Known);
  return model.types.get(expression.type).base;
}
}  // namespace

int main() {
  Program app;
  app.module = "app";
  app.file = "app.fac";
  ImportSpec libraryImport;
  libraryImport.module = "lib";
  libraryImport.alias = "L";
  libraryImport.line = 1;
  libraryImport.selection = 1;
  libraryImport.names.insert("remote");
  app.importSpecs.push_back(std::move(libraryImport));

  app.funcs.push_back(function("select", "int", {{"value", "int"}}, 1));
  app.funcs.push_back(function("select", "double", {{"value", "double"}}, 2));
  app.funcs.push_back(function("widen", "long", {{"value", "long"}}, 3));
  app.funcs.push_back(function("choose", "int", {{"value", "int"}}, 4));
  app.funcs.push_back(function("choose", "long", {{"value", "int"}}, 5));
  app.funcs.push_back(function("make", "int", {}, 6));
  NP defaulted = function("defaulted", "int", {{"value", "int"}}, 6);
  defaulted->params[0].def = integer(6, 1);
  app.funcs.push_back(std::move(defaulted));

  app.funcs.push_back(function("identity", "int", {{"value", "int"}}, 7));
  NP generic = makeNode(NK::Func, 7, "identity");
  generic->typeParams = {"T"};
  generic->ts = type("auto");
  Param genericParameter;
  genericParameter.name = "value";
  genericParameter.ts = type("auto");
  generic->params.push_back(std::move(genericParameter));
  generic->c.push_back(makeNode(NK::Block, 7));
  app.funcs.push_back(std::move(generic));

  NP mainFunction = makeNode(NK::Func, 10, "main");
  mainFunction->ts = type("void");
  Param input;
  input.name = "input";
  input.ts = type("int");
  mainFunction->params.push_back(std::move(input));
  NP body = makeNode(NK::Block, 11);

  NP valueDeclaration = makeNode(NK::VarDecl, 12, "value");
  valueDeclaration->ts = type("int");
  valueDeclaration->ts.kind = "var";
  valueDeclaration->c.push_back(integer(12, 9));
  body->c.push_back(std::move(valueDeclaration));

  NP outerValueUse = identifier(13, "value");
  const Node *outerValueUsePtr = outerValueUse.get();
  body->c.push_back(expressionStatement(std::move(outerValueUse), 13));

  NP outerCall = call(14, "select", identifier(14, "value"));
  const Node *outerCallPtr = outerCall.get();
  body->c.push_back(expressionStatement(std::move(outerCall), 14));

  NP nested = makeNode(NK::Block, 15);
  NP shadowDeclaration = makeNode(NK::VarDecl, 16, "value");
  shadowDeclaration->ts = type("double");
  shadowDeclaration->c.push_back(floating(16, 2.5));
  nested->c.push_back(std::move(shadowDeclaration));

  NP innerValueUse = identifier(17, "value");
  const Node *innerValueUsePtr = innerValueUse.get();
  nested->c.push_back(expressionStatement(std::move(innerValueUse), 17));
  NP innerCall = call(18, "select", identifier(18, "value"));
  const Node *innerCallPtr = innerCall.get();
  nested->c.push_back(expressionStatement(std::move(innerCall), 18));
  body->c.push_back(std::move(nested));

  NP afterNested = identifier(19, "value");
  const Node *afterNestedPtr = afterNested.get();
  body->c.push_back(expressionStatement(std::move(afterNested), 19));

  NP parameterUse = identifier(20, "input");
  const Node *parameterUsePtr = parameterUse.get();
  body->c.push_back(expressionStatement(std::move(parameterUse), 20));

  NP inferredDeclaration = makeNode(NK::VarDecl, 20, "inferred");
  inferredDeclaration->ts = type("auto");
  NP inferredInitializer = call(20, "make");
  const Node *inferredInitializerPtr = inferredInitializer.get();
  inferredDeclaration->c.push_back(std::move(inferredInitializer));
  body->c.push_back(std::move(inferredDeclaration));
  NP inferredUse = identifier(20, "inferred");
  const Node *inferredUsePtr = inferredUse.get();
  body->c.push_back(expressionStatement(std::move(inferredUse), 20));
  NP inferredCall = call(20, "select", identifier(20, "inferred"));
  const Node *inferredCallPtr = inferredCall.get();
  body->c.push_back(expressionStatement(std::move(inferredCall), 20));

  NP defaultCall = call(20, "defaulted");
  const Node *defaultCallPtr = defaultCall.get();
  body->c.push_back(expressionStatement(std::move(defaultCall), 20));

  NP widenCall = call(21, "widen", integer(21, 1));
  const Node *widenCallPtr = widenCall.get();
  body->c.push_back(expressionStatement(std::move(widenCall), 21));

  NP ambiguousCall = call(22, "choose", integer(22, 1));
  const Node *ambiguousCallPtr = ambiguousCall.get();
  body->c.push_back(expressionStatement(std::move(ambiguousCall), 22));

  NP noViableCall = call(23, "select", makeNode(NK::StrLit, 23, "text"));
  const Node *noViableCallPtr = noViableCall.get();
  body->c.push_back(expressionStatement(std::move(noViableCall), 23));

  NP importedCall = memberCall(24, "L", "remote", integer(24, 2));
  const Node *importedCallPtr = importedCall.get();
  body->c.push_back(expressionStatement(std::move(importedCall), 24));

  NP localCallable = makeNode(NK::VarDecl, 25, "select");
  localCallable->ts = type("auto");
  body->c.push_back(std::move(localCallable));
  NP shadowedCall = call(26, "select", integer(26, 3));
  const Node *shadowedCallPtr = shadowedCall.get();
  body->c.push_back(expressionStatement(std::move(shadowedCall), 26));

  NP genericCall = call(27, "identity", integer(27, 4));
  const Node *genericCallPtr = genericCall.get();
  body->c.push_back(expressionStatement(std::move(genericCall), 27));

  NP forEach = makeNode(NK::ForEach, 28, "item");
  forEach->ts = type("int");
  forEach->c.push_back(makeNode(NK::InitList, 28));
  NP forEachBody = makeNode(NK::Block, 28);
  NP itemUse = identifier(29, "item");
  const Node *itemUsePtr = itemUse.get();
  forEachBody->c.push_back(expressionStatement(std::move(itemUse), 29));
  forEach->c.push_back(std::move(forEachBody));
  body->c.push_back(std::move(forEach));

  NP tryNode = makeNode(NK::Try, 30, "errorValue");
  tryNode->ts = type("string");
  tryNode->c.push_back(makeNode(NK::Block, 30));
  NP catchBody = makeNode(NK::Block, 31);
  NP catchUse = identifier(31, "errorValue");
  const Node *catchUsePtr = catchUse.get();
  catchBody->c.push_back(expressionStatement(std::move(catchUse), 31));
  tryNode->c.push_back(std::move(catchBody));
  body->c.push_back(std::move(tryNode));

  NP matchNode = makeNode(NK::Match, 32);
  matchNode->c.push_back(integer(32, 1));
  Case matchCase;
  matchCase.bindings = {"payload"};
  matchCase.body = makeNode(NK::Block, 33);
  NP payloadUse = identifier(33, "payload");
  const Node *payloadUsePtr = payloadUse.get();
  matchCase.body->c.push_back(expressionStatement(std::move(payloadUse), 33));
  matchNode->cases.push_back(std::move(matchCase));
  body->c.push_back(std::move(matchNode));

  mainFunction->c.push_back(std::move(body));
  app.funcs.push_back(std::move(mainFunction));

  Program library;
  library.module = "lib";
  library.file = "lib.fac";
  library.funcs.push_back(function("remote", "int", {{"value", "int"}}, 1));

  std::vector<Program *> programs{&app, &library};
  const fac_hir::SemanticModel model = fac_hir::analyze(programs);
  assert(model.validate());

  const auto &outerUse = expr(model, outerValueUsePtr);
  const auto &innerUse = expr(model, innerValueUsePtr);
  const auto &afterUse = expr(model, afterNestedPtr);
  assert(outerUse.localBinding != fac_hir::kInvalidLocal);
  assert(innerUse.localBinding != fac_hir::kInvalidLocal);
  assert(afterUse.localBinding == outerUse.localBinding);
  assert(innerUse.localBinding != outerUse.localBinding);
  assert(local(model, outerUse.localBinding).scope != local(model, innerUse.localBinding).scope);
  assert(baseType(model, outerUse) == "int");
  assert(baseType(model, innerUse) == "double");
  assert(baseType(model, afterUse) == "int");

  const auto &paramUse = expr(model, parameterUsePtr);
  assert(paramUse.localBinding != fac_hir::kInvalidLocal);
  assert(local(model, paramUse.localBinding).isParameter);
  assert(baseType(model, paramUse) == "int");
  assert(expr(model, inferredInitializerPtr).call.state == fac_hir::CallResolutionState::Resolved);
  assert(local(model, expr(model, inferredUsePtr).localBinding).type != fac_hir::kInvalidType);
  assert(baseType(model, expr(model, inferredUsePtr)) == "int");
  assert(expr(model, inferredCallPtr).call.state == fac_hir::CallResolutionState::Resolved);
  assert(baseType(model, expr(model, inferredCallPtr)) == "int");
  assert(expr(model, defaultCallPtr).call.state == fac_hir::CallResolutionState::Resolved);

  const auto &outerSelection = expr(model, outerCallPtr);
  const auto &innerSelection = expr(model, innerCallPtr);
  assert(outerSelection.call.state == fac_hir::CallResolutionState::Resolved);
  assert(innerSelection.call.state == fac_hir::CallResolutionState::Resolved);
  assert(outerSelection.call.conversionCost == 0);
  assert(innerSelection.call.conversionCost == 0);
  assert(baseType(model, outerSelection) == "int");
  assert(baseType(model, innerSelection) == "double");

  const auto &widenSelection = expr(model, widenCallPtr);
  assert(widenSelection.call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.types.get(model.symbol(widenSelection.call.selected).parameters[0].type.type).base == "long");
  assert(widenSelection.call.conversionCost > 0);

  assert(expr(model, ambiguousCallPtr).call.state == fac_hir::CallResolutionState::Ambiguous);
  assert(expr(model, noViableCallPtr).call.state == fac_hir::CallResolutionState::NoViableCandidate);
  assert(expr(model, importedCallPtr).call.state == fac_hir::CallResolutionState::Resolved);
  assert(model.symbol(expr(model, importedCallPtr).call.selected).module == "lib");
  assert(expr(model, shadowedCallPtr).call.state == fac_hir::CallResolutionState::LocalCallable);
  assert(expr(model, genericCallPtr).call.state == fac_hir::CallResolutionState::Deferred);
  assert(expr(model, genericCallPtr).call.selected == fac_hir::kInvalidSymbol);

  const auto &item = expr(model, itemUsePtr);
  assert(item.localBinding != fac_hir::kInvalidLocal);
  assert(local(model, item.localBinding).scope < model.scopes.size());
  assert(baseType(model, item) == "int");
  const auto &caught = expr(model, catchUsePtr);
  assert(caught.localBinding != fac_hir::kInvalidLocal);
  assert(local(model, caught.localBinding).type != fac_hir::kInvalidType);
  const auto &payload = expr(model, payloadUsePtr);
  assert(payload.localBinding != fac_hir::kInvalidLocal);

  // A zero-parameter function call is resolved and its return type is visible
  // to the rest of the typed expression graph.
  NP makeCall = call(40, "make");
  const Node *makeCallPtr = makeCall.get();
  NP finalFunction = makeNode(NK::Func, 40, "finalCheck");
  finalFunction->ts = type("void");
  NP finalBody = makeNode(NK::Block, 40);
  finalBody->c.push_back(expressionStatement(std::move(makeCall), 40));
  finalFunction->c.push_back(std::move(finalBody));
  app.funcs.push_back(std::move(finalFunction));
  // Analysis above intentionally owns an immutable, completed snapshot.
  // A second run exercises the newly appended declaration independently.
  const fac_hir::SemanticModel second = fac_hir::analyze(programs);
  assert(second.validate());
  assert(expr(second, makeCallPtr).call.state == fac_hir::CallResolutionState::Resolved);
  assert(baseType(second, expr(second, makeCallPtr)) == "int");

  return 0;
}
