#include "src/hir.hpp"

#include <cassert>
#include <cstdint>
#include <string>
#include <type_traits>
#include <vector>

namespace {
NP node(NK kind, int line, const std::string &name = {}) {
  NP result = std::make_unique<Node>(kind, line);
  result->s = name;
  return result;
}

NP scalarLiteral(NK kind, int line, int64_t value = 0) {
  NP result = node(kind, line);
  result->iv = value;
  if (kind == NK::BoolLit) result->b = value != 0;
  return result;
}

NP statement(NP expression, int line) {
  NP result = node(NK::ExprStmt, line);
  result->c.push_back(std::move(expression));
  return result;
}

const fac_hir::Expression &expressionFor(const fac_hir::SemanticModel &model,
                                         const Node *source) {
  auto found = model.expressionIds.find(source);
  assert(found != model.expressionIds.end());
  assert(found->second < model.expressions.size());
  return model.expressions[found->second];
}

const fac_hir::TypeDescriptor &typeOf(const fac_hir::SemanticModel &model,
                                      const Node *source) {
  const auto &expression = expressionFor(model, source);
  assert(expression.typeState == fac_hir::ExprTypeState::Known);
  return model.types.get(expression.type);
}
}  // namespace

int main() {
  Program program;
  program.module = "expr";
  program.file = "expr.fac";

  NP person = node(NK::StructDef, 1, "Person");
  person->isClass = true;
  person->isPublic = true;
  program.structs.push_back(std::move(person));

  NP make = node(NK::Func, 3, "make");
  make->ts.base = "int";
  make->c.push_back(node(NK::Block, 3));
  program.funcs.push_back(std::move(make));

  NP function = node(NK::Func, 5, "main");
  function->ts.base = "void";
  NP body = node(NK::Block, 5);

  NP integer = scalarLiteral(NK::IntLit, 6, 42);
  const Node *integerPtr = integer.get();
  body->c.push_back(statement(std::move(integer), 6));

  NP wideInteger = scalarLiteral(NK::IntLit, 7, INT64_C(1) << 40);
  const Node *wideIntegerPtr = wideInteger.get();
  body->c.push_back(statement(std::move(wideInteger), 7));

  NP floating = node(NK::FloatLit, 8);
  floating->dv = 2.5;
  const Node *floatingPtr = floating.get();
  body->c.push_back(statement(std::move(floating), 8));

  NP asciiChar = scalarLiteral(NK::CharLit, 9, 65);
  const Node *asciiCharPtr = asciiChar.get();
  body->c.push_back(statement(std::move(asciiChar), 9));

  NP unicodeChar = scalarLiteral(NK::CharLit, 10, 200);
  const Node *unicodeCharPtr = unicodeChar.get();
  body->c.push_back(statement(std::move(unicodeChar), 10));

  NP string = node(NK::StrLit, 11, "hello");
  const Node *stringPtr = string.get();
  body->c.push_back(statement(std::move(string), 11));

  NP boolean = scalarLiteral(NK::BoolLit, 12, 1);
  const Node *booleanPtr = boolean.get();
  body->c.push_back(statement(std::move(boolean), 12));

  NP nullValue = node(NK::NullLit, 13);
  const Node *nullPtr = nullValue.get();
  body->c.push_back(statement(std::move(nullValue), 13));

  NP notExpr = node(NK::Unary, 14, "!");
  notExpr->c.push_back(scalarLiteral(NK::BoolLit, 14, 0));
  const Node *notPtr = notExpr.get();
  body->c.push_back(statement(std::move(notExpr), 14));

  NP sum = node(NK::Binary, 15, "+");
  sum->c.push_back(scalarLiteral(NK::IntLit, 15, 10));
  sum->c.push_back(scalarLiteral(NK::IntLit, 15, 20));
  const Node *sumPtr = sum.get();
  body->c.push_back(statement(std::move(sum), 15));

  NP equality = node(NK::Binary, 16, "==");
  equality->c.push_back(scalarLiteral(NK::IntLit, 16, 1));
  equality->c.push_back(scalarLiteral(NK::IntLit, 16, 1));
  const Node *equalityPtr = equality.get();
  body->c.push_back(statement(std::move(equality), 16));

  NP power = node(NK::Binary, 16, "**");
  power->c.push_back(scalarLiteral(NK::IntLit, 16, 2));
  power->c.push_back(scalarLiteral(NK::IntLit, 16, 3));
  const Node *powerPtr = power.get();
  body->c.push_back(statement(std::move(power), 16));

  NP shift = node(NK::Binary, 16, "<<");
  shift->c.push_back(scalarLiteral(NK::IntLit, 16, 1));
  shift->c.push_back(scalarLiteral(NK::IntLit, 16, INT64_C(1) << 40));
  const Node *shiftPtr = shift.get();
  body->c.push_back(statement(std::move(shift), 16));

  NP negated = node(NK::Unary, 16, "-");
  negated->c.push_back(scalarLiteral(NK::CharLit, 16, 65));
  const Node *negatedPtr = negated.get();
  body->c.push_back(statement(std::move(negated), 16));

  NP tuple = node(NK::TupleLit, 17);
  tuple->c.push_back(scalarLiteral(NK::IntLit, 17, 1));
  tuple->c.push_back(scalarLiteral(NK::StrLit, 17));
  const Node *tuplePtr = tuple.get();
  body->c.push_back(statement(std::move(tuple), 17));

  NP strCall = node(NK::Call, 18);
  strCall->c.push_back(node(NK::Ident, 18, "str"));
  strCall->c.push_back(scalarLiteral(NK::IntLit, 18, 7));
  const Node *strCallPtr = strCall.get();
  body->c.push_back(statement(std::move(strCall), 18));

  NP sizeCall = node(NK::Call, 19);
  sizeCall->c.push_back(node(NK::Ident, 19, "size"));
  sizeCall->c.push_back(node(NK::StrLit, 19, "abc"));
  const Node *sizeCallPtr = sizeCall.get();
  body->c.push_back(statement(std::move(sizeCall), 19));

  auto reflectionCall = [](int line, const std::string &name, bool withIndex) {
    NP call = node(NK::Call, line);
    NP callee = node(NK::Ident, line, name);
    TypeSpec target;
    target.cat = "struct";
    target.base = "Person";
    callee->ts.genericArgs.push_back(std::move(target));
    if (withIndex) {
      TypeSpec index;
      index.isConstValue = true;
      index.constValue = 0;
      callee->ts.genericArgs.push_back(std::move(index));
    }
    call->c.push_back(std::move(callee));
    return call;
  };
  NP fieldCountCall = reflectionCall(19, "fieldCount", false);
  const Node *fieldCountCallPtr = fieldCountCall.get();
  body->c.push_back(statement(std::move(fieldCountCall), 19));
  NP fieldNameCall = reflectionCall(19, "fieldName", true);
  const Node *fieldNameCallPtr = fieldNameCall.get();
  body->c.push_back(statement(std::move(fieldNameCall), 19));
  NP fieldTypeCall = reflectionCall(19, "fieldType", true);
  const Node *fieldTypeCallPtr = fieldTypeCall.get();
  body->c.push_back(statement(std::move(fieldTypeCall), 19));
  NP fieldOffsetCall = reflectionCall(19, "fieldOffset", true);
  const Node *fieldOffsetCallPtr = fieldOffsetCall.get();
  body->c.push_back(statement(std::move(fieldOffsetCall), 19));

  NP userCall = node(NK::Call, 20);
  userCall->c.push_back(node(NK::Ident, 20, "make"));
  const Node *userCallPtr = userCall.get();
  body->c.push_back(statement(std::move(userCall), 20));

  NP newPerson = node(NK::New, 21, "Person");
  const Node *newPersonPtr = newPerson.get();
  body->c.push_back(statement(std::move(newPerson), 21));

  NP tupleUnknown = node(NK::TupleLit, 22);
  tupleUnknown->c.push_back(node(NK::Ident, 22, "localValue"));
  const Node *tupleUnknownPtr = tupleUnknown.get();
  body->c.push_back(statement(std::move(tupleUnknown), 22));

  NP lambda = node(NK::Lambda, 23);
  lambda->ts.base = "int";
  Param lambdaParam;
  lambdaParam.name = "value";
  lambdaParam.ts.base = "double";
  lambda->params.push_back(std::move(lambdaParam));
  lambda->c.push_back(node(NK::Block, 23));
  const Node *lambdaPtr = lambda.get();
  body->c.push_back(statement(std::move(lambda), 23));

  NP localDeclaration = node(NK::VarDecl, 24, "localCount");
  localDeclaration->ts.base = "int";
  localDeclaration->ts.kind = "var";
  localDeclaration->c.push_back(scalarLiteral(NK::IntLit, 24, 9));
  body->c.push_back(std::move(localDeclaration));
  NP localIdentifier = node(NK::Ident, 25, "localCount");
  const Node *localIdentifierPtr = localIdentifier.get();
  body->c.push_back(statement(std::move(localIdentifier), 25));

  function->c.push_back(std::move(body));
  program.funcs.push_back(std::move(function));

  const fac_hir::SemanticModel model = fac_hir::analyze({&program});
  assert(model.validate());
  assert(model.expressionSummary.expressions == model.expressions.size());
  assert(model.expressionSummary.typed >= 14);
  assert(model.expressionSummary.unresolved >= 3);

  assert(typeOf(model, integerPtr).base == "int");
  assert(typeOf(model, wideIntegerPtr).base == "long");
  assert(typeOf(model, floatingPtr).base == "double");
  assert(typeOf(model, asciiCharPtr).base == "char");
  assert(typeOf(model, unicodeCharPtr).base == "unichar");
  assert(typeOf(model, stringPtr).base == "string");
  assert(typeOf(model, stringPtr).category == fac_hir::TypeCategory::Dynamic);
  assert(typeOf(model, booleanPtr).base == "bool");
  assert(typeOf(model, nullPtr).base == "null");
  assert(typeOf(model, notPtr).base == "bool");
  assert(typeOf(model, sumPtr).base == "int");
  assert(typeOf(model, equalityPtr).base == "bool");
  assert(typeOf(model, powerPtr).base == "int");
  assert(typeOf(model, shiftPtr).base == "long");
  assert(typeOf(model, negatedPtr).base == "int");
  assert(expressionFor(model, sumPtr).file == "expr.fac");
  assert(typeOf(model, tuplePtr).category == fac_hir::TypeCategory::Tuple);
  assert(model.types.get(typeOf(model, tuplePtr).genericArguments[1]).base == "string");
  assert(typeOf(model, strCallPtr).base == "string");
  assert(typeOf(model, sizeCallPtr).base == "int");
  assert(typeOf(model, fieldCountCallPtr).base == "int");
  assert(typeOf(model, fieldNameCallPtr).base == "string");
  assert(typeOf(model, fieldNameCallPtr).category == fac_hir::TypeCategory::Builtin);
  assert(typeOf(model, fieldTypeCallPtr).cat == "enum");
  assert(typeOf(model, fieldTypeCallPtr).base == "Type");
  assert(typeOf(model, fieldOffsetCallPtr).base == "int");
  assert(expressionFor(model, fieldCountCallPtr).typeOrigin == fac_hir::ExprTypeOrigin::BuiltinContract);
  assert(expressionFor(model, fieldNameCallPtr).typeOrigin == fac_hir::ExprTypeOrigin::BuiltinContract);
  assert(typeOf(model, newPersonPtr).category == fac_hir::TypeCategory::Named);
  assert(typeOf(model, newPersonPtr).base == "Person");

  const auto &sumExpr = expressionFor(model, sumPtr);
  assert(sumExpr.children.size() == 2);
  assert(sumExpr.children[0] < model.expressions.size());
  assert(model.expressions[sumExpr.children[0]].parent == sumExpr.id);
  assert(sumExpr.hasSideEffects == false);
  assert(expressionFor(model, strCallPtr).hasSideEffects);
  assert(expressionFor(model, newPersonPtr).hasSideEffects);
  assert(expressionFor(model, userCallPtr).typeState == fac_hir::ExprTypeState::Known);
  assert(expressionFor(model, userCallPtr).call.state == fac_hir::CallResolutionState::Resolved);
  assert(expressionFor(model, tupleUnknownPtr).typeState == fac_hir::ExprTypeState::Unresolved);
  assert(expressionFor(model, lambdaPtr).typeState == fac_hir::ExprTypeState::Known);
  assert(typeOf(model, lambdaPtr).category == fac_hir::TypeCategory::Function);

  // The typed AST is an immutable, source-mapped projection of the known HIR.
  static_assert(std::is_const<decltype(fac_hir::TypedAstNode::type)>::value,
                "typed AST node TypeId must be immutable");
  static_assert(std::is_const<decltype(fac_hir::TypedAstNode::children)>::value,
                "typed AST child edges must be immutable");
  static_assert(std::is_const<decltype(fac_hir::TypedAstNode::origin)>::value,
                "typed AST origin must be immutable");
  static_assert(std::is_const<decltype(fac_hir::TypedAstNode::resolvedCallee)>::value,
                "typed AST call target must be immutable");
  assert(model.typedAst.validate(model.types, model.expressions.size()));
  assert(model.typedAst.summary.nodes == model.typedAst.nodes.size());
  assert(model.typedAst.summary.roots == model.typedAst.roots.size());
  auto typedFor = [&](const Node *source) -> fac_hir::TypedAstRef {
    const auto &hirExpression = expressionFor(model, source);
    auto found = model.typedAst.expressions.find(hirExpression.id);
    return found == model.typedAst.expressions.end() ? fac_hir::TypedAstRef{} : found->second;
  };
  const auto typedInteger = typedFor(integerPtr);
  const auto typedSum = typedFor(sumPtr);
  const auto typedTuple = typedFor(tuplePtr);
  const auto typedCall = typedFor(userCallPtr);
  const auto typedFieldCount = typedFor(fieldCountCallPtr);
  const auto typedFieldName = typedFor(fieldNameCallPtr);
  const auto typedFieldType = typedFor(fieldTypeCallPtr);
  const auto typedFieldOffset = typedFor(fieldOffsetCallPtr);
  assert(typedInteger && typedInteger->kind == fac_hir::TypedAstKind::IntLiteral);
  assert(typedInteger->spelling == "42" && typedInteger->location.file == "expr.fac");
  assert(typedSum && typedSum->kind == fac_hir::TypedAstKind::Binary);
  assert(typedSum->spelling == "+" && typedSum->children.size() == 2);
  assert(typedSum->children[0]->kind == fac_hir::TypedAstKind::IntLiteral);
  assert(typedSum->children[1]->kind == fac_hir::TypedAstKind::IntLiteral);
  assert(typedTuple && typedTuple->kind == fac_hir::TypedAstKind::Tuple);
  assert(typedTuple->children.size() == 2);
  assert(typedCall && typedCall->kind == fac_hir::TypedAstKind::Call);
  assert(typedCall->resolvedCallee == expressionFor(model, userCallPtr).call.selected);
  assert(typedFieldCount && typedFieldCount->kind == fac_hir::TypedAstKind::Call);
  assert(typedFieldName && typedFieldName->kind == fac_hir::TypedAstKind::Call);
  assert(typedFieldType && typedFieldType->kind == fac_hir::TypedAstKind::Call);
  assert(typedFieldOffset && typedFieldOffset->kind == fac_hir::TypedAstKind::Call);
  const auto typedLocal = typedFor(localIdentifierPtr);
  assert(typedLocal && typedLocal->kind == fac_hir::TypedAstKind::Identifier);
  assert(typedLocal->spelling == "localCount" &&
         model.types.get(typedLocal->type).base == "int");
  assert(typedFor(tupleUnknownPtr) == nullptr); // unresolved expressions are not promoted
  assert(model.typedAst.summary.calls >= 3);
  assert(model.typedAst.summary.operators >= 5);

  // Generated nodes are immutable, type-checked and source-independent. They
  // extend a copy of the semantic model so the source projection above remains
  // unchanged and can still be compared with the original parser tree.
  fac_hir::SemanticModel generatedModel = model;
  fac_hir::TypedAstFactory factory(generatedModel);
  const fac_hir::TypeId intType = expressionFor(model, integerPtr).type;
  const fac_hir::TypeId boolType = expressionFor(model, booleanPtr).type;
  auto generatedLeft = factory.integerLiteral(19, intType, {"generated.fac", "expr", 100});
  auto generatedRight = factory.integerLiteral(23, intType, {"generated.fac", "expr", 100});
  auto generatedSum = factory.binary("+", generatedLeft, generatedRight, intType,
                                     {"generated.fac", "expr", 100});
  assert(generatedSum->origin == fac_hir::TypedAstOrigin::Generated);
  assert(generatedSum->sourceExpression == fac_hir::kInvalidExpr);
  assert(generatedSum->spelling == "+" && generatedSum->children.size() == 2);
  assert(generatedSum->hasSideEffects == false);
  assert(generatedSum->location.file == "generated.fac" && generatedSum->location.line == 100);
  assert(generatedModel.typedAst.summary.generatedNodes == 3);
  assert(generatedModel.typedAst.roots.back().get() == generatedSum.get());

  auto generatedCondition = factory.booleanLiteral(true, boolType);
  auto generatedNot = factory.unary("!", generatedCondition, boolType);
  assert(generatedNot->kind == fac_hir::TypedAstKind::Unary);
  assert(generatedNot->children[0].get() == generatedCondition.get());

  auto generatedFloat = factory.floatingLiteral(3.125, expressionFor(model, floatingPtr).type);
  auto generatedChar = factory.characterLiteral(90, expressionFor(model, asciiCharPtr).type);
  auto generatedNull = factory.nullLiteral(expressionFor(model, nullPtr).type);
  assert(generatedFloat->kind == fac_hir::TypedAstKind::FloatLiteral);
  assert(generatedFloat->spelling == "3.125");
  assert(generatedChar->kind == fac_hir::TypedAstKind::CharLiteral && generatedChar->spelling == "90");
  assert(generatedNull->kind == fac_hir::TypedAstKind::NullLiteral);

  auto generatedText = factory.stringLiteral("typed", expressionFor(model, stringPtr).type);
  assert(generatedText->kind == fac_hir::TypedAstKind::StringLiteral);
  assert(generatedText->spelling == "typed");
  auto generatedText2 = factory.stringLiteral(" AST", expressionFor(model, stringPtr).type);
  auto generatedConcat = factory.binary("+", generatedText, generatedText2,
                                        expressionFor(model, stringPtr).type);
  auto generatedEqual = factory.binary("==", generatedLeft, generatedRight, boolType);
  assert(generatedConcat->kind == fac_hir::TypedAstKind::Binary);
  assert(generatedConcat->hasSideEffects == false);
  assert(generatedEqual->kind == fac_hir::TypedAstKind::Binary);

  auto generatedTuple = factory.tuple({generatedLeft, generatedCondition});
  assert(generatedTuple->kind == fac_hir::TypedAstKind::Tuple);
  assert(generatedModel.types.get(generatedTuple->type).genericArguments.size() == 2);

  auto makeSymbols = generatedModel.find("expr.make");
  assert(makeSymbols.size() == 1);
  auto generatedCall = factory.call(makeSymbols.front(), {});
  assert(generatedCall->kind == fac_hir::TypedAstKind::Call);
  assert(generatedCall->resolvedCallee == makeSymbols.front());
  assert(generatedCall->hasSideEffects); // calls are conservatively effectful
  assert(generatedModel.validate());

  bool rejectedTypeMismatch = false;
  try {
    factory.binary("+", generatedLeft, generatedCondition, intType);
  } catch (const std::invalid_argument &) {
    rejectedTypeMismatch = true;
  }
  assert(rejectedTypeMismatch);

  bool rejectedUnsupportedOperator = false;
  try {
    factory.binary("instanceof", generatedLeft, generatedRight, boolType);
  } catch (const std::invalid_argument &) {
    rejectedUnsupportedOperator = true;
  }
  assert(rejectedUnsupportedOperator);

  bool rejectedWrongLiteralType = false;
  try {
    factory.booleanLiteral(true, intType);
  } catch (const std::invalid_argument &) {
    rejectedWrongLiteralType = true;
  }
  assert(rejectedWrongLiteralType);

  bool rejectedOutOfRangeLiteral = false;
  try {
    factory.integerLiteral(128, expressionFor(model, asciiCharPtr).type);
  } catch (const std::invalid_argument &) {
    rejectedOutOfRangeLiteral = true;
  }
  assert(rejectedOutOfRangeLiteral);

  bool rejectedCallArity = false;
  try {
    auto makeSymbols = generatedModel.find("expr.make");
    factory.call(makeSymbols.front(), {generatedLeft});
  } catch (const std::invalid_argument &) {
    rejectedCallArity = true;
  }
  assert(rejectedCallArity);

  bool rejectedForeignChild = false;
  try {
    fac_hir::SemanticModel otherModel = model;
    fac_hir::TypedAstFactory otherFactory(otherModel);
    auto foreignLiteral = otherFactory.integerLiteral(7, intType);
    (void)factory.unary("-", foreignLiteral, intType);
  } catch (const std::invalid_argument &) {
    rejectedForeignChild = true;
  }
  assert(rejectedForeignChild);
  assert(generatedModel.typedAst.validate(generatedModel.types, generatedModel.expressions.size()));

  return 0;
}
