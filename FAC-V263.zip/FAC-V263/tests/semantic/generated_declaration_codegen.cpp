#include "src/codegen.hpp"

#include <cassert>
#include <fstream>
#include <string>
#include <vector>

namespace {
NP node(NK kind, int line, const std::string &name = {}) {
  NP result = std::make_unique<Node>(kind, line);
  result->s = name;
  return result;
}

NP integer(int line, int64_t value) {
  NP result = node(NK::IntLit, line);
  result->iv = value;
  return result;
}

fac_hir::TypeId builtin(fac_hir::SemanticModel &model, const std::string &name) {
  TypeSpec spec;
  spec.base = name;
  return model.types.intern(spec);
}
}  // namespace

int main(int argc, char **argv) {
  Program program;
  program.module = "generated_codegen_app";
  program.file = "generated_codegen_app.fac";

  NP mainFunction = node(NK::Func, 1, "main");
  mainFunction->ts.base = "void";
  NP body = node(NK::Block, 1);
  NP call = node(NK::Call, 2);
  call->c.push_back(node(NK::Ident, 2, "generatedValue"));
  call->c.push_back(integer(2, 41));
  NP expression = node(NK::ExprStmt, 2);
  expression->c.push_back(std::move(call));
  body->c.push_back(std::move(expression));
  mainFunction->c.push_back(std::move(body));
  program.funcs.push_back(std::move(mainFunction));

  std::vector<Program *> programs{&program};
  fac_hir::SemanticModel model = fac_hir::analyze(programs);
  assert(model.validate());

  const fac_hir::TypeId intType = builtin(model, "int");
  const fac_hir::TypeId doubleType = builtin(model, "double");
  fac_hir::TypedDeclarationBuilder builder(model);

  fac_hir::GeneratedFieldSpec id;
  id.name = "id";
  id.type = intType;
  id.visibility = fac_hir::GeneratedVisibility::Public;
  fac_hir::GeneratedFieldSpec score;
  score.name = "score";
  score.type = doubleType;
  score.visibility = fac_hir::GeneratedVisibility::Private;
  const auto record = builder.addStruct("generated_codegen_app", "Record", {id, score});
  fac_hir::GeneratedFieldSpec nestedRecord;
  nestedRecord.name = "record";
  nestedRecord.type = record.declaredType;
  nestedRecord.visibility = fac_hir::GeneratedVisibility::Public;
  const auto wrapper = builder.addStruct("generated_codegen_app", "Wrapper", {nestedRecord});

  fac_hir::GeneratedParameterSpec value;
  value.name = "value";
  value.type = intType;
  const auto function = builder.addFunction("generated_codegen_app", "generatedValue",
      intType, {value}, fac_hir::GeneratedVisibility::Public);
  assert(record.symbol != fac_hir::kInvalidSymbol);
  assert(wrapper.symbol != fac_hir::kInvalidSymbol);
  assert(function.symbol != fac_hir::kInvalidSymbol);
  assert(model.validate());

  Gen generator;
  bool hasMain = false;
  const std::string ir = generator.generate(programs, "generated_codegen_app", &hasMain, &model);
  assert(hasMain);
  assert(ir.find("%S.Record = type { i32, double }") != std::string::npos);
  assert(ir.find("%S.Wrapper = type { %S.Record }") != std::string::npos);
  assert(generator.generatedStructNames.size() == 2);
  assert(generator.generatedStructNames[0] == "Record");
  assert(generator.generatedStructNames[1] == "Wrapper");
  assert(generator.generatedFunctionSymbols.count(function.symbol) == 1);

  const std::string externalSymbol = generator.generatedFunctionSymbols.at(function.symbol);
  assert(ir.find("declare i32 " + externalSymbol + "(i32)") != std::string::npos);
  assert(ir.find("call i32 " + externalSymbol + "(i32 41)") != std::string::npos);
  assert(ir.find("@drop.Record") != std::string::npos);

  // A fresh Codegen instance must derive the same external name from the same
  // generated HIR signature; this keeps native linker integration reproducible.
  Gen secondGenerator;
  bool secondHasMain = false;
  const std::string secondIr = secondGenerator.generate(
      programs, "generated_codegen_app", &secondHasMain, &model);
  assert(secondHasMain);
  assert(secondGenerator.generatedFunctionSymbols.at(function.symbol) == externalSymbol);
  assert(secondIr.find("declare i32 " + externalSymbol + "(i32)") != std::string::npos);

  // The input Program remains source-only; generated nodes are owned by the
  // temporary Codegen projection and do not mutate the parser AST.
  assert(program.structs.empty());
  assert(program.funcs.size() == 1);

  // Unsupported generated layouts/signatures must fail at the lowering
  // boundary rather than silently producing an incomplete LLVM declaration.
  Program invalidFieldProgram;
  invalidFieldProgram.module = "invalid_generated_field_app";
  invalidFieldProgram.file = "invalid_generated_field_app.fac";
  std::vector<Program *> invalidFieldPrograms{&invalidFieldProgram};
  fac_hir::SemanticModel invalidFieldModel = fac_hir::analyze(invalidFieldPrograms);
  assert(invalidFieldModel.validate());
  fac_hir::GeneratedFieldSpec staticField;
  staticField.name = "count";
  staticField.type = builtin(invalidFieldModel, "int");
  staticField.isStatic = true;
  fac_hir::TypedDeclarationBuilder invalidFieldBuilder(invalidFieldModel);
  invalidFieldBuilder.addStruct("invalid_generated_field_app", "InvalidRecord", {staticField});
  bool rejectedStaticField = false;
  try {
    Gen invalidGenerator;
    bool invalidHasMain = false;
    (void)invalidGenerator.generate(invalidFieldPrograms, "invalid_generated_field_app",
                                    &invalidHasMain, &invalidFieldModel);
  } catch (const CompileError &error) {
    rejectedStaticField = std::string(error.what()).find("static fields") != std::string::npos;
  }
  assert(rejectedStaticField);

  Program invalidFunctionProgram;
  invalidFunctionProgram.module = "invalid_generated_function_app";
  invalidFunctionProgram.file = "invalid_generated_function_app.fac";
  std::vector<Program *> invalidFunctionPrograms{&invalidFunctionProgram};
  fac_hir::SemanticModel invalidFunctionModel = fac_hir::analyze(invalidFunctionPrograms);
  assert(invalidFunctionModel.validate());
  fac_hir::GeneratedParameterSpec referenceParameter;
  referenceParameter.name = "value";
  referenceParameter.type = builtin(invalidFunctionModel, "int");
  referenceParameter.ref = true;
  fac_hir::TypedDeclarationBuilder invalidFunctionBuilder(invalidFunctionModel);
  invalidFunctionBuilder.addFunction("invalid_generated_function_app", "invalidReference",
      builtin(invalidFunctionModel, "int"), {referenceParameter});
  bool rejectedReferenceParameter = false;
  try {
    Gen invalidGenerator;
    bool invalidHasMain = false;
    (void)invalidGenerator.generate(invalidFunctionPrograms, "invalid_generated_function_app",
                                    &invalidHasMain, &invalidFunctionModel);
  } catch (const CompileError &error) {
    rejectedReferenceParameter = std::string(error.what()).find("plain value arguments") != std::string::npos;
  }
  assert(rejectedReferenceParameter);

  if (argc > 1) {
    std::ofstream output(argv[1], std::ios::binary);
    assert(output.good());
    output << ir;
    assert(output.good());
  }
}
