#include "src/hir.hpp"
#include <cassert>
#include <memory>
#include <string>
#include <vector>

static TypeSpec scalar(const std::string &name) {
  TypeSpec type;
  type.base = name;
  return type;
}

static NP node(NK kind, int line, const std::string &name = {}) {
  NP value = std::make_unique<Node>(kind, line);
  value->s = name;
  return value;
}

int main() {
  // Structural interning is stable and keeps qualifiers/lifetime/effect
  // contracts that affect the source-level type distinct.
  fac_hir::TypeArena arena;
  TypeSpec integer = scalar("int");
  const fac_hir::TypeId intId = arena.intern(integer);
  assert(intId != fac_hir::kInvalidType);
  assert(arena.intern(scalar("int")) == intId);
  assert(arena.get(intId).category == fac_hir::TypeCategory::Builtin);
  TypeSpec mapType;
  mapType.cat = "hashmap";
  mapType.base = "string";
  mapType.base2 = "int";
  assert(arena.get(arena.intern(mapType)).category == fac_hir::TypeCategory::Map);
  TypeSpec sequenceType;
  sequenceType.cat = "arraylist";
  sequenceType.base = "int";
  assert(arena.get(arena.intern(sequenceType)).category == fac_hir::TypeCategory::Container);
  TypeSpec matrixType;
  matrixType.cat = "matrix";
  matrixType.base = "double";
  assert(arena.get(arena.intern(matrixType)).category == fac_hir::TypeCategory::Matrix);
  TypeSpec manualHeap = scalar("int");
  manualHeap.kind = "heap";
  assert(arena.get(arena.intern(manualHeap)).category == fac_hir::TypeCategory::Heap);
  TypeSpec objectType;
  objectType.cat = "obj";
  objectType.base = "Point";
  assert(arena.get(arena.intern(objectType)).category == fac_hir::TypeCategory::Named);

  TypeSpec pointer = scalar("int");
  pointer.kind = "ptr";
  const fac_hir::TypeId pointerId = arena.intern(pointer);
  assert(pointerId != intId);
  TypeSpec volatilePointer = cloneTypeSpec(pointer);
  volatilePointer.isVolatile = true;
  assert(arena.intern(volatilePointer) != pointerId);
  TypeSpec lifetimePointer = cloneTypeSpec(pointer);
  lifetimePointer.lifetime = "a";
  lifetimePointer.lifetimeParamIndex = 0;
  const fac_hir::TypeId lifetimeId = arena.intern(lifetimePointer);
  assert(lifetimeId != pointerId);
  assert(arena.get(lifetimeId).lifetime == "a");
  assert(arena.get(lifetimeId).lifetimeParamIndex == 0);
  TypeSpec fixedArray;
  fixedArray.cat = "array";
  fixedArray.base = "int";
  fixedArray.hasSize = true;
  fixedArray.size = node(NK::IntLit, 9);
  const fac_hir::TypeUse fixedArrayUse = arena.use(fixedArray);
  assert(fixedArrayUse.type != fac_hir::kInvalidType);
  assert(fixedArrayUse.hasSize && fixedArrayUse.sizeExpression == fixedArray.size.get());

  TypeSpec functionType;
  functionType.cat = "func";
  functionType.hasSig = true;
  functionType.sig.push_back(cloneTypeSpec(integer));
  functionType.sigNoescape.push_back(true);
  functionType.sigReadonly.push_back(false);
  functionType.sigReturnType = std::make_shared<TypeSpec>(scalar("string"));
  functionType.sigLifetimeParams.push_back("a");
  functionType.sigLifetimeOutlives.push_back({0, 0});
  const fac_hir::TypeId functionId = arena.intern(functionType);
  const auto &functionDescriptor = arena.get(functionId);
  assert(functionDescriptor.category == fac_hir::TypeCategory::Function);
  assert(functionDescriptor.parameters.size() == 1);
  assert(functionDescriptor.returnType != fac_hir::kInvalidType);
  assert(functionDescriptor.noescape.size() == 1 && functionDescriptor.noescape[0]);
  assert(functionDescriptor.lifetimeParameters.size() == 1);

  // Build a representative multi-module declaration graph without invoking
  // Codegen: records, fields, methods, enum payloads, overloads and globals.
  Program app;
  app.module = "app";
  app.file = "app.fac";
  app.imports = {"math", "io"};
  ImportSpec mathImport;
  mathImport.module = "math";
  mathImport.alias = "m";
  mathImport.line = 1;
  mathImport.selection = 1;
  mathImport.names.insert("sqrt");
  app.importSpecs.push_back(std::move(mathImport));
  app.aliases.push_back({"Count", "long"});
  app.aliases.push_back({"LoopA", "LoopB"});
  app.aliases.push_back({"LoopB", "LoopA"});
  app.links.push_back("m");
  StaticAssertion staticAssertion;
  staticAssertion.expr = node(NK::BoolLit, 2);
  staticAssertion.message = "compile-time contract";
  staticAssertion.line = 2;
  app.staticAssertions.push_back(std::move(staticAssertion));

  NP point = node(NK::StructDef, 3, "Point");
  point->isPublic = true;
  NP x = node(NK::VarDecl, 4, "x");
  x->ts = scalar("double");
  x->isPublic = true;
  point->c.push_back(std::move(x));
  NP translate = node(NK::Func, 6, "translate");
  translate->isPublic = true;
  translate->ts = scalar("void");
  Param dx;
  dx.name = "dx";
  dx.ts = scalar("double");
  dx.noescape = true;
  translate->params.push_back(std::move(dx));
  point->methods.push_back(std::move(translate));
  app.structs.push_back(std::move(point));

  NP secretType = node(NK::StructDef, 8, "Secret");
  secretType->isPublic = false;
  app.structs.push_back(std::move(secretType));
  NP publicClass = node(NK::StructDef, 9, "PublicClass");
  publicClass->isPublic = true;
  publicClass->isClass = true;
  app.structs.push_back(std::move(publicClass));
  NP publicInterface = node(NK::StructDef, 10, "PublicInterface");
  publicInterface->isPublic = true;
  publicInterface->isInterface = true;
  app.structs.push_back(std::move(publicInterface));

  NP maybe = node(NK::EnumDef, 10, "MaybeText");
  maybe->isPublic = true;
  EnumMember none;
  none.name = "None";
  none.val = 0;
  maybe->members.push_back(std::move(none));
  EnumMember some;
  some.name = "Some";
  some.val = 1;
  some.payloadTypes.push_back(scalar("string"));
  maybe->members.push_back(std::move(some));
  app.enums.push_back(std::move(maybe));
  NP colorType = node(NK::EnumDef, 12, "Color");
  colorType->isPublic = true;
  EnumMember red;
  red.name = "Red";
  red.val = 0;
  colorType->members.push_back(std::move(red));
  app.enums.push_back(std::move(colorType));

  NP sumInt = node(NK::Func, 15, "sum");
  sumInt->isPublic = true;
  sumInt->ts = scalar("int");
  Param lhs;
  lhs.name = "lhs";
  lhs.ts = scalar("int");
  sumInt->params.push_back(std::move(lhs));
  app.funcs.push_back(std::move(sumInt));

  NP sumDouble = node(NK::Func, 20, "sum");
  sumDouble->isPublic = true;
  sumDouble->ts = scalar("double");
  Param rhs;
  rhs.name = "rhs";
  rhs.ts = scalar("double");
  rhs.readonly = true;
  sumDouble->params.push_back(std::move(rhs));
  app.funcs.push_back(std::move(sumDouble));

  NP identity = node(NK::Func, 25, "identity");
  identity->typeParams = {"T"};
  GenericBound identityBound;
  identityBound.param = "T";
  identityBound.bound = scalar("numeric");
  identity->genericBounds.push_back(std::move(identityBound));
  identity->ts = scalar("auto");
  Param value;
  value.name = "value";
  value.ts = scalar("auto");
  identity->params.push_back(std::move(value));
  app.funcs.push_back(std::move(identity));

  NP alignedBuffer = node(NK::StructDef, 26, "AlignedBuffer");
  alignedBuffer->isPublic = true;
  alignedBuffer->typeParams = {"N"};
  alignedBuffer->constGenericParams = {"N"};
  GenericBound powerOfTwo;
  powerOfTwo.param = "N";
  powerOfTwo.bound = scalar("power_of_two");
  alignedBuffer->genericBounds.push_back(std::move(powerOfTwo));
  assert(alignedBuffer->genericBounds.size() == 1);
  assert(alignedBuffer->genericBounds[0].param == "N");
  app.structs.push_back(std::move(alignedBuffer));

  NP positiveCapacity = node(NK::Func, 27, "positiveCapacity");
  positiveCapacity->isPublic = true;
  positiveCapacity->typeParams = {"N"};
  positiveCapacity->constGenericParams = {"N"};
  positiveCapacity->genericBounds.push_back({"N", scalar("positive")});
  positiveCapacity->ts = scalar("int");
  positiveCapacity->c.push_back(node(NK::Block, 27));
  app.funcs.push_back(std::move(positiveCapacity));

  NP global = node(NK::VarDecl, 31, "answer");
  global->ts = scalar("long");
  global->isPublic = true;
  app.globals.push_back(std::move(global));

  Program utility;
  utility.module = "util";
  utility.file = "util.fac";
  utility.imports = {"app"};
  ImportSpec appImport;
  appImport.module = "app";
  appImport.alias = "A";
  appImport.line = 1;
  appImport.selection = 1;
  appImport.names = {"Point", "Color", "Secret", "PublicClass", "PublicInterface"};
  utility.importSpecs.push_back(std::move(appImport));
  NP consumePoint = node(NK::Func, 2, "consumePoint");
  consumePoint->ts = scalar("void");
  Param importedPoint;
  importedPoint.name = "point";
  importedPoint.ts = scalar("A.Point");
  consumePoint->params.push_back(std::move(importedPoint));
  utility.funcs.push_back(std::move(consumePoint));
  NP useFiltered = node(NK::Func, 3, "useFiltered");
  useFiltered->ts = scalar("void");
  Param filteredColor;
  filteredColor.name = "color";
  filteredColor.ts = scalar("A.MaybeText");
  useFiltered->params.push_back(std::move(filteredColor));
  utility.funcs.push_back(std::move(useFiltered));
  NP useEnum = node(NK::Func, 4, "useEnum");
  useEnum->ts = scalar("void");
  Param enumParam;
  enumParam.name = "color";
  enumParam.ts = scalar("A.Color");
  useEnum->params.push_back(std::move(enumParam));
  utility.funcs.push_back(std::move(useEnum));
  NP useClass = node(NK::Func, 5, "useClass");
  useClass->ts = scalar("void");
  Param classParam;
  classParam.name = "value";
  classParam.ts = scalar("A.PublicClass");
  useClass->params.push_back(std::move(classParam));
  utility.funcs.push_back(std::move(useClass));
  NP useInterface = node(NK::Func, 6, "useInterface");
  useInterface->ts = scalar("void");
  Param interfaceParam;
  interfaceParam.name = "value";
  interfaceParam.ts = scalar("A.PublicInterface");
  useInterface->params.push_back(std::move(interfaceParam));
  utility.funcs.push_back(std::move(useInterface));
  NP usePrivate = node(NK::Func, 7, "usePrivate");
  usePrivate->ts = scalar("void");
  Param privateSecret;
  privateSecret.name = "secret";
  privateSecret.ts = scalar("A.Secret");
  usePrivate->params.push_back(std::move(privateSecret));
  utility.funcs.push_back(std::move(usePrivate));
  NP useAlias = node(NK::Func, 5, "useAlias");
  useAlias->ts = scalar("void");
  Param aliasParam;
  aliasParam.name = "count";
  aliasParam.ts = scalar("Count");
  useAlias->params.push_back(std::move(aliasParam));
  utility.funcs.push_back(std::move(useAlias));
  NP genericUse = node(NK::Func, 6, "genericUse");
  genericUse->typeParams = {"T"};
  genericUse->ts = scalar("void");
  Param genericParam;
  genericParam.name = "value";
  genericParam.ts = scalar("T");
  genericUse->params.push_back(std::move(genericParam));
  utility.funcs.push_back(std::move(genericUse));
  NP useTwin = node(NK::Func, 8, "useTwin");
  useTwin->ts = scalar("void");
  Param twinParam;
  twinParam.name = "twin";
  twinParam.ts = scalar("Twin");
  useTwin->params.push_back(std::move(twinParam));
  utility.funcs.push_back(std::move(useTwin));
  NP useNotImported = node(NK::Func, 9, "useNotImported");
  useNotImported->ts = scalar("void");
  Param remoteParam;
  remoteParam.name = "remote";
  remoteParam.ts = scalar("Remote");
  useNotImported->params.push_back(std::move(remoteParam));
  utility.funcs.push_back(std::move(useNotImported));
  NP useMissing = node(NK::Func, 10, "useMissing");
  useMissing->ts = scalar("void");
  Param missingParam;
  missingParam.name = "missing";
  missingParam.ts = scalar("NoSuchType");
  useMissing->params.push_back(std::move(missingParam));
  utility.funcs.push_back(std::move(useMissing));
  NP useAliasCycle = node(NK::Func, 11, "useAliasCycle");
  useAliasCycle->ts = scalar("void");
  Param aliasCycleParam;
  aliasCycleParam.name = "value";
  aliasCycleParam.ts = scalar("LoopA");
  useAliasCycle->params.push_back(std::move(aliasCycleParam));
  utility.funcs.push_back(std::move(useAliasCycle));
  NP helper = node(NK::Func, 12, "helper");
  helper->ts = scalar("bool");
  utility.funcs.push_back(std::move(helper));

  Program extra;
  extra.module = "extra";
  extra.file = "extra.fac";
  NP remoteType = node(NK::StructDef, 1, "Remote");
  remoteType->isPublic = true;
  extra.structs.push_back(std::move(remoteType));
  NP twinApp = node(NK::StructDef, 2, "Twin");
  twinApp->isPublic = true;
  app.structs.push_back(std::move(twinApp));
  NP twinExtra = node(NK::StructDef, 2, "Twin");
  twinExtra->isPublic = true;
  extra.structs.push_back(std::move(twinExtra));

  Program exclude;
  exclude.module = "exclude";
  exclude.file = "exclude.fac";
  exclude.imports = {"app"};
  ImportSpec withoutPoint;
  withoutPoint.module = "app";
  withoutPoint.selection = 2;
  withoutPoint.names = {"Point"};
  exclude.importSpecs.push_back(std::move(withoutPoint));
  NP filteredByWithout = node(NK::Func, 1, "filteredByWithout");
  filteredByWithout->ts = scalar("void");
  Param excludedPoint;
  excludedPoint.name = "point";
  excludedPoint.ts = scalar("Point");
  filteredByWithout->params.push_back(std::move(excludedPoint));
  exclude.funcs.push_back(std::move(filteredByWithout));

  const fac_hir::SemanticModel model = fac_hir::analyze({&app, &utility, &extra, &exclude});
  assert(model.validate());
  assert(model.modules.size() == 4);
  assert(model.modules[0].name == "app");
  assert(model.modules[0].imports.size() == 2);
  assert(model.modules[0].importBindings.size() == 1);
  assert(model.modules[0].importBindings[0].alias == "m");
  assert(model.modules[0].importBindings[0].selection == 1);
  assert(model.modules[0].importBindings[0].names[0] == "sqrt");
  assert(model.modules[0].aliases.size() == 3);
  assert(model.modules[0].aliases[0].first == "Count");
  assert(model.modules[0].links[0] == "m");
  assert(model.modules[0].staticAssertions.size() == 1);
  assert(model.modules[0].staticAssertions[0].expression != nullptr);
  assert(model.modules[1].imports[0] == "app");

  const auto overloads = model.find("app.sum");
  assert(overloads.size() == 2);
  assert(model.symbol(overloads[0]).parameters[0].type.type !=
         model.symbol(overloads[1]).parameters[0].type.type);
  assert(model.symbol(overloads[0]).location.file == "app.fac");
  assert(model.symbol(overloads[0]).location.line == 15);

  const auto record = model.find("app.Point");
  assert(record.size() == 1);
  const auto &pointDecl = model.symbol(record[0]);
  assert(pointDecl.kind == fac_hir::SymbolKind::Struct);
  assert(pointDecl.fields.size() == 1);
  assert(pointDecl.fields[0].name == "x");
  assert(pointDecl.methods.size() == 1);
  const auto &method = model.symbol(pointDecl.methods[0]);
  assert(method.qualifiedName == "app.Point::translate");
  assert(method.parameters.size() == 1 && method.parameters[0].noescape);

  const auto enumeration = model.find("app.MaybeText");
  assert(enumeration.size() == 1);
  const auto &enumDecl = model.symbol(enumeration[0]);
  assert(enumDecl.kind == fac_hir::SymbolKind::Enum);
  assert(enumDecl.variants.size() == 2);
  assert(enumDecl.variants[1].name == "Some");
  assert(enumDecl.variants[1].payload.size() == 1);

  const auto identities = model.find("app.identity");
  assert(identities.size() == 1);
  assert(model.symbol(identities[0]).isGeneric);
  assert(model.symbol(identities[0]).typeParameters[0] == "T");
  assert(model.symbol(identities[0]).genericBounds.size() == 1);
  assert(model.symbol(identities[0]).genericBounds[0].parameter == "T");

  const auto constrainedBuffer = model.find("app.AlignedBuffer");
  assert(constrainedBuffer.size() == 1);
  const auto &bufferDecl = model.symbol(constrainedBuffer[0]);
  assert(bufferDecl.constTypeParameters.size() == 1);
  assert(bufferDecl.genericBounds.size() == 1);
  assert(bufferDecl.genericBounds[0].isConstValuePredicate);
  assert(bufferDecl.genericBounds[0].valuePredicate == "power_of_two");
  assert(bufferDecl.genericBounds[0].bound.type == fac_hir::kInvalidType);

  const auto constrainedFunction = model.find("app.positiveCapacity");
  assert(constrainedFunction.size() == 1);
  const auto &capacityDecl = model.symbol(constrainedFunction[0]);
  assert(capacityDecl.genericBounds.size() == 1);
  assert(capacityDecl.genericBounds[0].isConstValuePredicate);
  assert(capacityDecl.genericBounds[0].valuePredicate == "positive");

  const auto globals = model.find("app.answer");
  assert(globals.size() == 1);
  assert(model.symbol(globals[0]).kind == fac_hir::SymbolKind::Global);
  assert(model.find("util.helper").size() == 1);

  auto firstName = [](const fac_hir::TypeUse &use, const std::string &spelling) -> const fac_hir::ResolvedName * {
    for (const fac_hir::ResolvedName &name : use.names)
      if (name.spelling == spelling) return &name;
    return nullptr;
  };
  const auto pointConsumer = model.find("util.consumePoint");
  assert(pointConsumer.size() == 1);
  const fac_hir::ResolvedName *resolvedPoint =
    firstName(model.symbol(pointConsumer[0]).parameters[0].type, "A.Point");
  assert(resolvedPoint && resolvedPoint->kind == fac_hir::NameResolutionKind::Resolved);
  assert(resolvedPoint->canonicalName == "app.Point");
  assert(resolvedPoint->symbol == record[0]);
  assert(resolvedPoint->typeKind == fac_hir::TypeResolutionKind::Struct);

  const auto filteredConsumer = model.find("util.useFiltered");
  assert(filteredConsumer.size() == 1);
  const fac_hir::ResolvedName *filteredColorName =
    firstName(model.symbol(filteredConsumer[0]).parameters[0].type, "A.MaybeText");
  assert(filteredColorName && filteredColorName->kind == fac_hir::NameResolutionKind::Filtered);

  const auto enumConsumer = model.find("util.useEnum");
  assert(enumConsumer.size() == 1);
  const fac_hir::ResolvedName *resolvedEnum =
    firstName(model.symbol(enumConsumer[0]).parameters[0].type, "A.Color");
  assert(resolvedEnum && resolvedEnum->kind == fac_hir::NameResolutionKind::Resolved);
  assert(resolvedEnum->typeKind == fac_hir::TypeResolutionKind::Enum);

  const auto classConsumer = model.find("util.useClass");
  assert(classConsumer.size() == 1);
  const fac_hir::ResolvedName *resolvedClass =
    firstName(model.symbol(classConsumer[0]).parameters[0].type, "A.PublicClass");
  assert(resolvedClass && resolvedClass->typeKind == fac_hir::TypeResolutionKind::Class);
  const auto interfaceConsumer = model.find("util.useInterface");
  assert(interfaceConsumer.size() == 1);
  const fac_hir::ResolvedName *resolvedInterface =
    firstName(model.symbol(interfaceConsumer[0]).parameters[0].type, "A.PublicInterface");
  assert(resolvedInterface && resolvedInterface->typeKind == fac_hir::TypeResolutionKind::Interface);

  const auto privateConsumer = model.find("util.usePrivate");
  assert(privateConsumer.size() == 1);
  const fac_hir::ResolvedName *privateSecretName =
    firstName(model.symbol(privateConsumer[0]).parameters[0].type, "A.Secret");
  assert(privateSecretName && privateSecretName->kind == fac_hir::NameResolutionKind::Private);

  const auto aliasConsumer = model.find("util.useAlias");
  assert(aliasConsumer.size() == 1);
  const fac_hir::ResolvedName *aliasName =
    firstName(model.symbol(aliasConsumer[0]).parameters[0].type, "Count");
  assert(aliasName && aliasName->kind == fac_hir::NameResolutionKind::Builtin);
  assert(aliasName->canonicalName == "long");
  assert(aliasName->typeKind == fac_hir::TypeResolutionKind::Builtin);

  const auto genericConsumer = model.find("util.genericUse");
  assert(genericConsumer.size() == 1);
  const fac_hir::ResolvedName *genericName =
    firstName(model.symbol(genericConsumer[0]).parameters[0].type, "T");
  assert(genericName && genericName->kind == fac_hir::NameResolutionKind::GenericParameter);
  assert(genericName->typeKind == fac_hir::TypeResolutionKind::GenericParameter);

  const auto notImportedConsumer = model.find("util.useNotImported");
  assert(notImportedConsumer.size() == 1);
  const fac_hir::ResolvedName *notImported =
    firstName(model.symbol(notImportedConsumer[0]).parameters[0].type, "Remote");
  assert(notImported && notImported->kind == fac_hir::NameResolutionKind::NotImported);

  const auto missingConsumer = model.find("util.useMissing");
  assert(missingConsumer.size() == 1);
  const fac_hir::ResolvedName *missing =
    firstName(model.symbol(missingConsumer[0]).parameters[0].type, "NoSuchType");
  assert(missing && missing->kind == fac_hir::NameResolutionKind::NotFound);

  const auto cycleConsumer = model.find("util.useAliasCycle");
  assert(cycleConsumer.size() == 1);
  const fac_hir::ResolvedName *aliasCycle =
    firstName(model.symbol(cycleConsumer[0]).parameters[0].type, "LoopA");
  assert(aliasCycle && aliasCycle->kind == fac_hir::NameResolutionKind::AliasCycle);

  const auto ambiguousConsumer = model.find("util.useTwin");
  assert(ambiguousConsumer.size() == 1);
  const fac_hir::ResolvedName *ambiguous =
    firstName(model.symbol(ambiguousConsumer[0]).parameters[0].type, "Twin");
  assert(ambiguous && ambiguous->kind == fac_hir::NameResolutionKind::Ambiguous);
  const auto excludeConsumer = model.find("exclude.filteredByWithout");
  assert(excludeConsumer.size() == 1);
  const fac_hir::ResolvedName *withoutFiltered =
    firstName(model.symbol(excludeConsumer[0]).parameters[0].type, "Point");
  assert(withoutFiltered && withoutFiltered->kind == fac_hir::NameResolutionKind::Filtered);

  assert(model.typeResolution.structs >= 1);
  assert(model.typeResolution.classes >= 1);
  assert(model.typeResolution.interfaces >= 1);
  assert(model.typeResolution.enums >= 1);
  assert(model.nameResolution.resolved >= 1);
  assert(model.nameResolution.accessDenied >= 3);
  assert(model.nameResolution.genericParameters >= 1);
  assert(model.nameResolution.notFound >= 1);
  assert(model.nameResolution.ambiguous >= 1);
  assert(model.nameResolution.aliasCycles >= 1);
  assert(model.types.size() >= 5);

  Program defaultsProgram;
  defaultsProgram.module = "generic_defaults";
  defaultsProgram.file = "generic_defaults.fac";
  NP defaultBoxNode = node(NK::StructDef, 1, "DefaultBox");
  defaultBoxNode->typeParams = {"T", "N"};
  defaultBoxNode->constGenericParams = {"N"};
  defaultBoxNode->genericHasDefault = {true, true};
  defaultBoxNode->genericDefaults.push_back(scalar("int"));
  TypeSpec constDefault; constDefault.isConstValue = true; constDefault.constValue = 16;
  defaultBoxNode->genericDefaults.push_back(std::move(constDefault));
  defaultsProgram.structs.push_back(std::move(defaultBoxNode));
  NP defaultFunctionNode = node(NK::Func, 2, "defaultFunction");
  defaultFunctionNode->ts = scalar("double");
  defaultFunctionNode->typeParams = {"U", "M"};
  defaultFunctionNode->constGenericParams = {"M"};
  defaultFunctionNode->genericHasDefault = {true, true};
  defaultFunctionNode->genericDefaults.push_back(scalar("double"));
  TypeSpec functionConstDefault; functionConstDefault.isConstValue = true; functionConstDefault.constValue = 8;
  defaultFunctionNode->genericDefaults.push_back(std::move(functionConstDefault));
  defaultsProgram.funcs.push_back(std::move(defaultFunctionNode));
  const fac_hir::SemanticModel defaultsModel = fac_hir::analyze({&defaultsProgram});
  const auto defaultBox = defaultsModel.find("generic_defaults.DefaultBox");
  assert(defaultBox.size() == 1);
  const auto &defaultBoxDecl = defaultsModel.symbol(defaultBox[0]);
  assert(defaultBoxDecl.genericHasDefault.size() == 2);
  assert(defaultBoxDecl.genericHasDefault[0] && defaultBoxDecl.genericHasDefault[1]);
  assert(defaultBoxDecl.sourceNode && defaultBoxDecl.sourceNode->genericDefaults.size() == 2);
  assert(defaultBoxDecl.sourceNode->genericDefaults[0].base == "int");
  assert(defaultBoxDecl.sourceNode->genericDefaults[1].isConstValue);
  const auto defaultFunction = defaultsModel.find("generic_defaults.defaultFunction");
  assert(defaultFunction.size() == 1);
  const auto &defaultFunctionDecl = defaultsModel.symbol(defaultFunction[0]);
  assert(defaultFunctionDecl.genericHasDefault.size() == 2);
  assert(defaultFunctionDecl.genericHasDefault[0] && defaultFunctionDecl.genericHasDefault[1]);
  return 0;
}
