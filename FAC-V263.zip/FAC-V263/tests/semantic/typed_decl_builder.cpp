#include "src/hir.hpp"

#include <cassert>
#include <functional>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
fac_hir::TypeId builtin(fac_hir::SemanticModel &model, const std::string &name) {
  TypeSpec spec;
  spec.base = name;
  return model.types.intern(spec);
}

NP node(NK kind, int line, const std::string &name = {}) {
  NP result = std::make_unique<Node>(kind, line);
  result->s = name;
  return result;
}

bool throwsInvalid(const std::function<void()> &action) {
  try { action(); }
  catch (const std::invalid_argument &) { return true; }
  return false;
}
}  // namespace

int main() {
  Program program;
  program.module = "generated_app";
  program.file = "generated_app.fac";
  NP mainFunction = node(NK::Func, 1, "main");
  mainFunction->ts.base = "void";
  mainFunction->c.push_back(node(NK::Block, 1));
  program.funcs.push_back(std::move(mainFunction));

  std::vector<Program *> programs{&program};
  fac_hir::SemanticModel model = fac_hir::analyze(programs);
  assert(model.validate());

  const fac_hir::TypeId intType = builtin(model, "int");
  const fac_hir::TypeId doubleType = builtin(model, "double");
  const fac_hir::TypeId voidType = builtin(model, "void");
  fac_hir::TypedDeclarationBuilder builder(model);

  fac_hir::GeneratedFieldSpec idField;
  idField.name = "id";
  idField.type = intType;
  idField.visibility = fac_hir::GeneratedVisibility::Public;

  fac_hir::GeneratedFieldSpec scoreField;
  scoreField.name = "score";
  scoreField.type = doubleType;
  scoreField.visibility = fac_hir::GeneratedVisibility::Private;

  const auto record = builder.addStruct("generated_app", "Record",
      {idField, scoreField}, fac_hir::GeneratedVisibility::Public,
      {"generated.fac", "generated_app", 10});
  assert(record.symbol != fac_hir::kInvalidSymbol);
  assert(record.declaredType != fac_hir::kInvalidType);
  assert(model.symbol(record.symbol).origin == fac_hir::DeclarationOrigin::Generated);
  assert(model.symbol(record.symbol).kind == fac_hir::SymbolKind::Struct);
  assert(model.symbol(record.symbol).fields.size() == 2);
  assert(model.symbol(record.symbol).declaredType.type == record.declaredType);
  assert(model.symbol(record.symbol).declaredType.resolvedSymbol == record.symbol);
  assert(model.find("generated_app.Record").size() == 1);
  assert(model.validate());

  fac_hir::GeneratedFieldSpec nestedRecord;
  nestedRecord.name = "record";
  nestedRecord.type = record.declaredType;
  nestedRecord.visibility = fac_hir::GeneratedVisibility::Public;
  const auto wrapper = builder.addStruct("generated_app", "Wrapper", {nestedRecord});
  assert(model.symbol(wrapper.symbol).fields[0].type.resolvedSymbol == record.symbol);
  assert(model.validate());

  fac_hir::GeneratedParameterSpec parameter;
  parameter.name = "record";
  parameter.type = record.declaredType;
  const auto function = builder.addFunction("generated_app", "consume",
      intType, {parameter}, fac_hir::GeneratedVisibility::Public,
      {"generated.fac", "generated_app", 20});
  assert(function.symbol != fac_hir::kInvalidSymbol);
  assert(function.declaredType == fac_hir::kInvalidType);
  assert(model.symbol(function.symbol).origin == fac_hir::DeclarationOrigin::Generated);
  assert(model.symbol(function.symbol).parameters.size() == 1);
  assert(model.symbol(function.symbol).parameters[0].type.type == record.declaredType);
  assert(model.symbol(function.symbol).parameters[0].type.resolvedSymbol == record.symbol);
  assert(model.find("generated_app.consume").size() == 1);
  assert(model.validate());

  // A distinct parameter signature is a valid overload.
  fac_hir::GeneratedParameterSpec integerParameter;
  integerParameter.name = "value";
  integerParameter.type = intType;
  const auto overload = builder.addFunction("generated_app", "consume",
      voidType, {integerParameter});
  assert(overload.symbol != function.symbol);
  assert(model.find("generated_app.consume").size() == 2);
  assert(model.validate());

  // Reject duplicate structs, duplicate fields, malformed identifiers,
  // unresolved/void field types, invalid function signatures and duplicates.
  assert(throwsInvalid([&] {
    builder.addStruct("generated_app", "Record", {});
  }));
  assert(throwsInvalid([&] {
    builder.addStruct("generated_app", "BadFields", {idField, idField});
  }));
  assert(throwsInvalid([&] {
    builder.addStruct("generated_app", "bad-name", {});
  }));
  assert(throwsInvalid([&] {
    fac_hir::GeneratedFieldSpec bad;
    bad.name = "missing";
    bad.type = fac_hir::kInvalidType;
    builder.addStruct("generated_app", "BadType", {bad});
  }));
  assert(throwsInvalid([&] {
    fac_hir::GeneratedFieldSpec bad;
    bad.name = "nothing";
    bad.type = voidType;
    builder.addStruct("generated_app", "VoidField", {bad});
  }));
  assert(throwsInvalid([&] {
    fac_hir::GeneratedParameterSpec a;
    a.name = "same"; a.type = intType;
    fac_hir::GeneratedParameterSpec b;
    b.name = "same"; b.type = doubleType;
    builder.addFunction("generated_app", "badParams", intType, {a, b});
  }));
  assert(throwsInvalid([&] {
    builder.addFunction("missing_module", "notRegistered", intType, {});
  }));
  assert(throwsInvalid([&] {
    builder.addFunction("generated_app", "consume", intType, {parameter});
  }));

  // A failed build does not register a declaration or corrupt model indexes.
  assert(model.find("generated_app.BadType").empty());
  assert(model.find("generated_app.VoidField").empty());
  assert(model.validate());
}
