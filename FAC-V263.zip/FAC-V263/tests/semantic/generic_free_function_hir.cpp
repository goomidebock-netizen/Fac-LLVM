#include "src/hir.hpp"

#include <cassert>
#include <string>
#include <utility>
#include <vector>

namespace {
NP node(NK kind, int line, const std::string &name = {}) {
  NP value = std::make_unique<Node>(kind, line);
  value->s = name;
  return value;
}

TypeSpec scalar(const std::string &base) {
  TypeSpec value;
  value.base = base;
  return value;
}

NP function(const std::string &name, TypeSpec result,
            std::initializer_list<std::pair<const char *, const char *>> parameters,
            int line) {
  NP value = node(NK::Func, line, name);
  value->ts = std::move(result);
  value->isPublic = true;
  for (const auto &parameter : parameters) {
    Param item;
    item.name = parameter.first;
    item.ts = scalar(parameter.second);
    value->params.push_back(std::move(item));
  }
  value->c.push_back(node(NK::Block, line));
  return value;
}

NP integer(int line, int64_t value) {
  NP result = node(NK::IntLit, line);
  result->iv = value;
  return result;
}

NP floating(int line, double value) {
  NP result = node(NK::FloatLit, line);
  result->dv = value;
  return result;
}

NP stringLiteral(int line, const std::string &value) {
  return node(NK::StrLit, line, value);
}

NP identifier(int line, const std::string &name) {
  return node(NK::Ident, line, name);
}

NP call(int line, const std::string &name, NP first) {
  NP result = node(NK::Call, line);
  result->c.push_back(identifier(line, name));
  result->c.push_back(std::move(first));
  return result;
}

NP call(int line, const std::string &name, NP first, NP second) {
  NP result = node(NK::Call, line);
  result->c.push_back(identifier(line, name));
  result->c.push_back(std::move(first));
  result->c.push_back(std::move(second));
  return result;
}

NP statement(NP expression, int line) {
  NP result = node(NK::ExprStmt, line);
  result->c.push_back(std::move(expression));
  return result;
}

void addLocal(Node &body, const std::string &name, TypeSpec type, int line) {
  NP declaration = node(NK::VarDecl, line, name);
  declaration->ts = std::move(type);
  body.c.push_back(std::move(declaration));
}

const fac_hir::Expression &expression(const fac_hir::SemanticModel &model,
                                      const Node *source) {
  const auto found = model.expressionIds.find(source);
  assert(found != model.expressionIds.end());
  return model.expressions.at(found->second);
}

std::string baseType(const fac_hir::SemanticModel &model,
                     const fac_hir::Expression &value) {
  assert(value.typeState == fac_hir::ExprTypeState::Known);
  return model.types.get(value.type).base;
}
}  // namespace

int main() {
  Program app;
  app.module = "generic_free_app";
  app.file = "generic_free_app.fac";

  NP identity = function("identity", scalar("T"), {{"value", "T"}}, 1);
  identity->typeParams = {"T"};
  app.funcs.push_back(std::move(identity));

  NP pairFirst = function("pairFirst", scalar("T"),
      {{"first", "T"}, {"second", "U"}}, 2);
  pairFirst->typeParams = {"T", "U"};
  app.funcs.push_back(std::move(pairFirst));

  TypeSpec listOfT;
  listOfT.cat = "list";
  listOfT.base = "T";
  NP listFirst = node(NK::Func, 3, "listFirst");
  listFirst->ts = scalar("T");
  listFirst->isPublic = true;
  Param listParameter;
  listParameter.name = "values";
  listParameter.ts = std::move(listOfT);
  listFirst->params.push_back(std::move(listParameter));
  listFirst->c.push_back(node(NK::Block, 3));
  listFirst->typeParams = {"T"};
  app.funcs.push_back(std::move(listFirst));

  NP numericIdentity = function("numericIdentity", scalar("T"),
      {{"value", "T"}}, 4);
  numericIdentity->typeParams = {"T"};
  GenericBound numeric;
  numeric.param = "T";
  numeric.bound = scalar("numeric");
  numericIdentity->genericBounds.push_back(std::move(numeric));
  app.funcs.push_back(std::move(numericIdentity));

  NP capacity = function("capacity", scalar("int"), {}, 5);
  capacity->typeParams = {"N"};
  capacity->constGenericParams = {"N"};
  app.funcs.push_back(std::move(capacity));

  NP inferredSize = node(NK::Func, 5, "inferredSize");
  inferredSize->ts = scalar("int");
  inferredSize->isPublic = true;
  Param inferredArray;
  inferredArray.name = "values";
  inferredArray.ts.cat = "array";
  inferredArray.ts.kind = "var";
  inferredArray.ts.base = "int";
  inferredArray.ts.hasSize = true;
  inferredArray.ts.size = identifier(5, "N");
  inferredSize->params.push_back(std::move(inferredArray));
  inferredSize->typeParams = {"N"};
  inferredSize->constGenericParams = {"N"};
  GenericBound positiveN;
  positiveN.param = "N";
  positiveN.bound.base = "positive";
  inferredSize->genericBounds.push_back(std::move(positiveN));
  inferredSize->c.push_back(node(NK::Block, 5));
  app.funcs.push_back(std::move(inferredSize));

  NP sameExtent = node(NK::Func, 5, "sameExtent");
  sameExtent->ts = scalar("int");
  sameExtent->isPublic = true;
  for (const char *name : {"left", "right"}) {
    Param item;
    item.name = name;
    item.ts.cat = "array";
    item.ts.kind = "var";
    item.ts.base = "int";
    item.ts.hasSize = true;
    item.ts.size = identifier(5, "N");
    sameExtent->params.push_back(std::move(item));
  }
  sameExtent->typeParams = {"N"};
  sameExtent->constGenericParams = {"N"};
  sameExtent->c.push_back(node(NK::Block, 5));
  app.funcs.push_back(std::move(sameExtent));

  // A concrete overload wins over an otherwise exact generic candidate.
  app.funcs.push_back(function("prefer", scalar("int"), {{"value", "int"}}, 5));
  NP genericPrefer = function("prefer", scalar("T"), {{"value", "T"}}, 6);
  genericPrefer->typeParams = {"T"};
  app.funcs.push_back(std::move(genericPrefer));

  NP ambiguousA = function("ambiguous", scalar("T"), {{"value", "T"}}, 7);
  ambiguousA->typeParams = {"T"};
  app.funcs.push_back(std::move(ambiguousA));
  NP ambiguousB = function("ambiguous", scalar("U"), {{"value", "U"}}, 8);
  ambiguousB->typeParams = {"U"};
  app.funcs.push_back(std::move(ambiguousB));

  NP mismatch = function("mismatch", scalar("T"),
      {{"first", "T"}, {"second", "T"}}, 9);
  mismatch->typeParams = {"T"};
  app.funcs.push_back(std::move(mismatch));

  NP strictMismatch = function("strictMismatch", scalar("T"),
      {{"first", "T"}, {"second", "T"}}, 10);
  strictMismatch->typeParams = {"T"};
  app.funcs.push_back(std::move(strictMismatch));

  NP mainFunction = node(NK::Func, 11, "main");
  mainFunction->ts = scalar("void");
  Param unknownParameter;
  unknownParameter.name = "unknown";
  unknownParameter.ts = scalar("UnknownType");
  mainFunction->params.push_back(std::move(unknownParameter));
  Param narrowParameter;
  narrowParameter.name = "narrowValue";
  narrowParameter.ts = scalar("int");
  mainFunction->params.push_back(std::move(narrowParameter));
  Param wideParameter;
  wideParameter.name = "wideValue";
  wideParameter.ts = scalar("long");
  mainFunction->params.push_back(std::move(wideParameter));
  NP body = node(NK::Block, 12);

  TypeSpec intList;
  intList.cat = "list";
  intList.kind = "var";
  intList.base = "int";
  addLocal(*body, "numbers", std::move(intList), 12);

  TypeSpec fixedArray;
  fixedArray.cat = "array";
  fixedArray.kind = "var";
  fixedArray.base = "int";
  fixedArray.hasSize = true;
  fixedArray.size = integer(12, 4);
  addLocal(*body, "fixedValues", std::move(fixedArray), 12);

  TypeSpec otherFixedArray;
  otherFixedArray.cat = "array";
  otherFixedArray.kind = "var";
  otherFixedArray.base = "int";
  otherFixedArray.hasSize = true;
  otherFixedArray.size = integer(12, 3);
  addLocal(*body, "otherFixedValues", std::move(otherFixedArray), 12);

  NP identityCall = call(13, "identity", integer(13, 7));
  const Node *identitySource = identityCall.get();
  body->c.push_back(statement(std::move(identityCall), 13));

  NP pairCall = call(14, "pairFirst", integer(14, 8), stringLiteral(14, "x"));
  const Node *pairSource = pairCall.get();
  body->c.push_back(statement(std::move(pairCall), 14));

  NP namedPairCall = call(14, "pairFirst", integer(14, 9), floating(14, 1.5));
  TypeSpec namedU = scalar("double"); namedU.genericArgName = "U";
  TypeSpec namedT = scalar("int"); namedT.genericArgName = "T";
  namedPairCall->c[0]->ts.genericArgs.push_back(std::move(namedU));
  namedPairCall->c[0]->ts.genericArgs.push_back(std::move(namedT));
  const Node *namedPairSource = namedPairCall.get();
  body->c.push_back(statement(std::move(namedPairCall), 14));

  NP listCall = call(15, "listFirst", identifier(15, "numbers"));
  const Node *listSource = listCall.get();
  body->c.push_back(statement(std::move(listCall), 15));

  NP numericCall = call(16, "numericIdentity", integer(16, 9));
  const Node *numericSource = numericCall.get();
  body->c.push_back(statement(std::move(numericCall), 16));

  NP inferredConstCall = call(16, "inferredSize", identifier(16, "fixedValues"));
  const Node *inferredConstSource = inferredConstCall.get();
  body->c.push_back(statement(std::move(inferredConstCall), 16));

  NP conflictingConstCall = call(16, "sameExtent",
      identifier(16, "fixedValues"), identifier(16, "otherFixedValues"));
  const Node *conflictingConstSource = conflictingConstCall.get();
  body->c.push_back(statement(std::move(conflictingConstCall), 16));

  NP constCallee = identifier(16, "capacity");
  TypeSpec constExpressionArgument;
  constExpressionArgument.constExpr = std::make_shared<Node>(NK::Binary, 16);
  constExpressionArgument.constExpr->s = "*";
  constExpressionArgument.constExpr->c.push_back(integer(16, 3));
  constExpressionArgument.constExpr->c.push_back(integer(16, 4));
  constCallee->ts.genericArgs.push_back(std::move(constExpressionArgument));
  NP constCall = node(NK::Call, 16);
  constCall->c.push_back(std::move(constCallee));
  const Node *constSource = constCall.get();
  body->c.push_back(statement(std::move(constCall), 16));

  NP rejectedCall = call(17, "numericIdentity", stringLiteral(17, "no"));
  const Node *rejectedSource = rejectedCall.get();
  body->c.push_back(statement(std::move(rejectedCall), 17));

  NP preferCall = call(18, "prefer", integer(18, 10));
  const Node *preferSource = preferCall.get();
  body->c.push_back(statement(std::move(preferCall), 18));

  NP ambiguousCall = call(19, "ambiguous", integer(19, 11));
  const Node *ambiguousSource = ambiguousCall.get();
  body->c.push_back(statement(std::move(ambiguousCall), 19));

  NP mismatchCall = call(20, "mismatch", integer(20, 12), stringLiteral(20, "x"));
  const Node *mismatchSource = mismatchCall.get();
  body->c.push_back(statement(std::move(mismatchCall), 20));

  NP deferredCall = call(21, "identity", identifier(21, "notDefined"));
  const Node *deferredSource = deferredCall.get();
  body->c.push_back(statement(std::move(deferredCall), 21));

  NP strictMismatchCall = call(22, "strictMismatch",
      identifier(22, "narrowValue"), identifier(22, "wideValue"));
  const Node *strictMismatchSource = strictMismatchCall.get();
  body->c.push_back(statement(std::move(strictMismatchCall), 22));

  mainFunction->c.push_back(std::move(body));
  app.funcs.push_back(std::move(mainFunction));

  const fac_hir::SemanticModel model = fac_hir::analyze({&app});
  assert(model.validate());

  const auto &identityResult = expression(model, identitySource);
  assert(identityResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(identityResult.call.genericState == fac_hir::GenericInferenceState::InferredFromArguments);
  assert(identityResult.call.substitutions.count("T") == 1);
  assert(baseType(model, identityResult) == "int");

  const auto &pairResult = expression(model, pairSource);
  assert(pairResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(pairResult.call.substitutions.count("T") == 1);
  assert(pairResult.call.substitutions.count("U") == 1);
  assert(baseType(model, pairResult) == "int");
  assert(model.types.get(pairResult.call.substitutions.at("U")).base == "string");

  const auto &namedPairResult = expression(model, namedPairSource);
  assert(namedPairResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(namedPairResult.call.substitutions.count("T") == 1);
  assert(namedPairResult.call.substitutions.count("U") == 1);
  assert(model.types.get(namedPairResult.call.substitutions.at("T")).base == "int");
  assert(model.types.get(namedPairResult.call.substitutions.at("U")).base == "double");

  const auto &listResult = expression(model, listSource);
  assert(listResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(baseType(model, listResult) == "int");

  const auto &numericResult = expression(model, numericSource);
  assert(numericResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(baseType(model, numericResult) == "int");

  const auto &inferredConstResult = expression(model, inferredConstSource);
  assert(inferredConstResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(inferredConstResult.call.genericState == fac_hir::GenericInferenceState::InferredFromArguments);
  assert(inferredConstResult.call.substitutions.count("N") == 1);
  const auto &inferredConstValue = model.types.get(inferredConstResult.call.substitutions.at("N"));
  assert(inferredConstValue.isConstValue && inferredConstValue.constValue == 4);
  assert(baseType(model, inferredConstResult) == "int");

  const auto &conflictingConstResult = expression(model, conflictingConstSource);
  assert(conflictingConstResult.call.state == fac_hir::CallResolutionState::NoViableCandidate);
  assert(conflictingConstResult.call.genericState == fac_hir::GenericInferenceState::ConstraintFailure);

  const auto &constResult = expression(model, constSource);
  assert(constResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(constResult.call.genericState == fac_hir::GenericInferenceState::ExplicitArguments);
  assert(constResult.call.explicitTypeArguments.size() == 1);
  const auto &constArgument = model.types.get(constResult.call.explicitTypeArguments.front());
  assert(constArgument.isConstExpression);
  assert(!constArgument.isConstValue);
  assert(constResult.call.substitutions.count("N") == 1);

  const auto &rejectedResult = expression(model, rejectedSource);
  assert(rejectedResult.call.state == fac_hir::CallResolutionState::NoViableCandidate);
  assert(rejectedResult.call.genericState == fac_hir::GenericInferenceState::ConstraintFailure);

  const auto &preferResult = expression(model, preferSource);
  assert(preferResult.call.state == fac_hir::CallResolutionState::Resolved);
  assert(!model.symbol(preferResult.call.selected).isGeneric);
  assert(baseType(model, preferResult) == "int");

  const auto &ambiguousResult = expression(model, ambiguousSource);
  assert(ambiguousResult.call.state == fac_hir::CallResolutionState::Ambiguous);

  const auto &mismatchResult = expression(model, mismatchSource);
  assert(mismatchResult.call.state == fac_hir::CallResolutionState::NoViableCandidate);

  const auto &deferredResult = expression(model, deferredSource);
  assert(deferredResult.call.state == fac_hir::CallResolutionState::Deferred);

  const auto &strictMismatchResult = expression(model, strictMismatchSource);
  assert(strictMismatchResult.call.state == fac_hir::CallResolutionState::NoViableCandidate);

  size_t inferredNotes = 0, deferredNotes = 0, errors = 0;
  size_t ambiguousErrors = 0, constraintErrors = 0, noViableErrors = 0;
  for (const fac_hir::SemanticDiagnostic &diagnostic : model.diagnostics) {
    assert(diagnostic.location.file == app.file);
    assert(diagnostic.location.line > 0);
    assert(diagnostic.expression < model.expressions.size());
    if (diagnostic.code == "FAC-HIR-GEN-INFO-001") ++inferredNotes;
    if (diagnostic.code == "FAC-HIR-GEN-INFO-002") ++deferredNotes;
    if (diagnostic.code == "FAC-HIR-SEM-ERROR-001") ++ambiguousErrors;
    if (diagnostic.code == "FAC-HIR-GEN-ERROR-001") ++constraintErrors;
    if (diagnostic.code == "FAC-HIR-SEM-ERROR-002") ++noViableErrors;
    if (diagnostic.severity == fac_hir::SemanticDiagnosticSeverity::Error) ++errors;
  }
  assert(inferredNotes >= 4);
  assert(deferredNotes >= 1);
  assert(ambiguousErrors == 1);
  assert(constraintErrors == 2);
  assert(noViableErrors >= 2);
  assert(errors == ambiguousErrors + constraintErrors + noViableErrors);
  assert(model.diagnosticSummary.notes == inferredNotes + deferredNotes);
  assert(model.diagnosticSummary.errors == errors);
  return 0;
}
