#!/bin/sh
# เทสต์หน้าต่าง/input จริงผ่าน SDL2 backend (Linux/macOS)  ต้องมี libSDL2 runtime; ไม่มีจอ -> ใช้ SDL_VIDEODRIVER=dummy
cd "$(dirname "$0")/.." || exit 1
export SDL_VIDEODRIVER=${SDL_VIDEODRIVER:-dummy}
./build/facc tests/gui/window_events.fac tests/gui/inject.c -o /tmp/fac_gui_ev ${1:--O2} || exit 1
/tmp/fac_gui_ev > /tmp/fac_gui_out || exit 1
cat > /tmp/fac_gui_exp <<'EXP'
open alive=true
left before=false
alive=true
left=true a=true space=false
mouse=33,44 down=true left=true right=false
left after=false mdown=false right=true
alive after quit=false
done
EXP
diff /tmp/fac_gui_exp /tmp/fac_gui_out && echo "gui test ok"

# Pong ตัวอย่างเกม: จำลอง headless กับรันในหน้าต่างจริงต้องได้ผลจบเกมเหมือนกันทุกตัวเลข (game.fac ใช้ fixed timestep -> ลำดับ update กำหนดผลได้)
./build/facc examples/pong.fac -o /tmp/fac_pong ${1:--O2} || exit 1
FAC_PONG=sim /tmp/fac_pong > /tmp/fac_pong_sim || exit 1
FAC_PONG=window /tmp/fac_pong > /tmp/fac_pong_win || exit 1
diff tests/gui/pong_expected.txt /tmp/fac_pong_sim && diff tests/gui/pong_expected.txt /tmp/fac_pong_win && echo "pong test ok"

# Explorer: tilemap + camera + anim + input; headless กับหน้าต่างจริงต้องได้ผลเหมือนกัน, ภาพทั้งเฟรมต้องตรงกับ oracle ใน Python, ตัวละครต้องไม่เคยซ้อนกำแพง
./build/facc examples/explorer.fac -o /tmp/fac_explorer ${1:--O2} || exit 1
FAC_EXPLORER=sim /tmp/fac_explorer > /tmp/fac_explorer_sim || exit 1
FAC_EXPLORER=window /tmp/fac_explorer > /tmp/fac_explorer_win || exit 1
cmp /tmp/fac_explorer_sim /tmp/fac_explorer_win || exit 1
python3 tests/gui/explorer_check.py /tmp/fac_explorer_sim && python3 tests/gui/explorer_check.py /tmp/fac_explorer_win && echo "explorer test ok"

# UI kit: mouse press must fire once (not repeat while held); checkbox returns its toggled value.
./build/facc tests/gui/ui_interaction.fac tests/gui/inject.c -o /tmp/fac_ui_ev ${1:--O2} || exit 1
/tmp/fac_ui_ev > /tmp/fac_ui_out || exit 1
cat > /tmp/fac_ui_exp <<'EXP'
initial=false click=true held=false release=false checkbox=true tabs=1 slider=100
EXP
diff /tmp/fac_ui_exp /tmp/fac_ui_out && echo "ui interaction test ok"

# Extended UI controls: dropdown mouse/keyboard handling, radio selection and grid geometry.
./build/facc tests/gui/ui_controls.fac tests/gui/inject.c -o /tmp/fac_ui_controls ${1:--O2} || exit 1
/tmp/fac_ui_controls > /tmp/fac_ui_controls_out || exit 1
diff tests/gui/ui_controls.expected /tmp/fac_ui_controls_out && echo "ui controls test ok"

# Editable UTF-8 text field: committed text events, cursor insertion, selection, Tab and backspace.
./build/facc tests/gui/ui_text_field.fac tests/gui/inject.c -o /tmp/fac_ui_text_field ${1:--O2} || exit 1
/tmp/fac_ui_text_field > /tmp/fac_ui_text_field_out || exit 1
diff tests/gui/ui_text_field.expected /tmp/fac_ui_text_field_out && echo "ui text field test ok"


# Text-field undo/redo, programmatic focus and redo-branch invalidation.
./build/facc tests/gui/ui_text_undo.fac tests/gui/inject.c -o /tmp/fac_ui_text_undo ${1:--O2} || exit 1
/tmp/fac_ui_text_undo > /tmp/fac_ui_text_undo_out || exit 1
diff tests/gui/ui_text_undo.expected /tmp/fac_ui_text_undo_out && echo "ui text undo test ok"

# Multiline TextArea: Enter, UTF-8 text, vertical cursor movement, selection replacement, undo and line joining.
./build/facc tests/gui/ui_text_area.fac tests/gui/inject.c -o /tmp/fac_ui_text_area ${1:--O2} || exit 1
/tmp/fac_ui_text_area > /tmp/fac_ui_text_area_out || exit 1
diff tests/gui/ui_text_area.expected /tmp/fac_ui_text_area_out && echo "ui text area test ok"

# Animated UI: hover/press tween progression, retarget on release and Reduce Motion snap.
./build/facc tests/gui/ui_motion.fac tests/gui/inject.c -o /tmp/fac_ui_motion ${1:--O2} || exit 1
/tmp/fac_ui_motion > /tmp/fac_ui_motion_out || exit 1
cat > /tmp/fac_ui_motion_exp <<'EXP'
click=true firstMotion=true
hoverAdvanced=true reduceMotionSnap=true
EXP
diff /tmp/fac_ui_motion_exp /tmp/fac_ui_motion_out && echo "ui motion test ok"
