#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

struct FacStr;
struct JV;
struct FacList { void *data; int64_t len, cap; int32_t esz, ek; void (*dropFn)(void *); void (*copyFn)(void *, const void *); };

extern "C" {
void fac_init(int32_t, char **);
void fac_mem_start_tracking();
uint64_t fac_mem_used();
uint64_t fac_mem_blocks();
void fac_try_enter(void *);
void fac_try_leave();
int32_t fac_err_code();
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
JV *fac_json_array();
JV *fac_json_newint(int64_t);
JV *fac_json_newstr(FacStr *);
void fac_json_push(JV *, JV *);
void fac_jd_free(JV *);
FacList *fac_jd_list(JV *, int32_t, int32_t);
FacList *fac_args();
void fac_list_free(FacList *);
}

static int try_json_list(JV *value, int32_t code, int32_t elemSize) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    FacList *result = fac_jd_list(value, code, elemSize);
    fac_try_leave();
    fac_list_free(result);
    return 0;
  }
  return fac_err_code();
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  // Make all allocations created by the conversion visible to the FAC
  // allocator counters; the input JSON tree itself is allocated beforehand.
  FacStr *text = fac_str_from_chars("owned", 5);

  JV *badIntegerArray = fac_json_array();
  fac_json_push(badIntegerArray, fac_json_newint(17));
  fac_json_push(badIntegerArray, fac_json_newstr(text));

  JV *badStringArray = fac_json_array();
  fac_json_push(badStringArray, fac_json_newstr(text));
  fac_json_push(badStringArray, fac_json_newint(23));

  fac_mem_start_tracking();
  const uint64_t usedBefore = fac_mem_used();
  const uint64_t blocksBefore = fac_mem_blocks();

  if (try_json_list(badIntegerArray, 3, (int32_t)sizeof(int32_t)) != 10)
    return fail("invalid numeric element did not raise the expected JSON type error");
  if (fac_mem_used() != usedBefore || fac_mem_blocks() != blocksBefore)
    return fail("partial numeric result list leaked after a JSON type error");

  if (try_json_list(badStringArray, 14, (int32_t)sizeof(FacStr *)) != 10)
    return fail("invalid string element did not raise the expected JSON type error");
  if (fac_mem_used() != usedBefore || fac_mem_blocks() != blocksBefore)
    return fail("partial string result list or converted string leaked after a JSON type error");

  // Empty and successful conversions must pop the cleanup entry without
  // changing ownership semantics for their caller.
  JV *good = fac_json_array();
  fac_json_push(good, fac_json_newint(1));
  fac_json_push(good, fac_json_newint(2));
  if (try_json_list(good, 3, (int32_t)sizeof(int32_t)) != 0)
    return fail("valid JSON list conversion unexpectedly failed");
  if (fac_mem_used() != usedBefore || fac_mem_blocks() != blocksBefore)
    return fail("successful list conversion did not release caller-owned result in test");

  char arg0[] = "fac-test";
  char arg1[] = "alpha";
  char arg2[] = "beta";
  char *argv[] = {arg0, arg1, arg2};
  fac_init(3, argv);
  FacList *args = fac_args();
  if (!args || args->len != 2 || args->ek != 1)
    return fail("sys.args returned an invalid string list");
  fac_list_free(args);
  if (fac_mem_used() != usedBefore || fac_mem_blocks() != blocksBefore)
    return fail("sys.args result did not release all tracked allocations");

  fac_jd_free(badIntegerArray);
  fac_jd_free(badStringArray);
  fac_jd_free(good);
  fac_str_free(text);
  std::puts("PASS Runtime partial-list cleanup on JSON conversion errors and sys.args success");
  return 0;
}
