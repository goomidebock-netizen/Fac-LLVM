// HTTP client hardening: response status/header/framing and chunked-body validation; memory.zero and random.shuffle
// must reject invalid sizes. Modes are run as subprocesses by run.sh.
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <clocale>
#include <string>
#include <thread>

struct FacStr;
extern "C" {
FacStr *fac_str_from_chars(const char *, int64_t);
FacStr *fac_net_httpget(FacStr *);
FacStr *fac_net_urlencode(FacStr *);
void fac_memzero(void *, int64_t);
void fac_shuffle(void *, int64_t, int32_t);
int64_t fac_str_len_bytes(FacStr *) __attribute__((weak));
}
struct FacStrView { char *data; int64_t len; };

static int serve(const std::string &resp, std::thread &th, std::string *requestLine = nullptr) {
  int ls = socket(AF_INET, SOCK_STREAM, 0); int one = 1; setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = 0;
  if (bind(ls, (sockaddr *)&a, sizeof a) != 0 || listen(ls, 1) != 0) return -1;
  socklen_t l = sizeof a; getsockname(ls, (sockaddr *)&a, &l);
  th = std::thread([ls, resp, requestLine] {
    int c = accept(ls, nullptr, nullptr); char ch; std::string line;
    while (read(c, &ch, 1) == 1) { if (ch == '\n') break; if (line.size() < 4096) line += ch; }
    if (requestLine) *requestLine = line;
    std::string headers; char hch;
    while (headers.size() < 65536 && read(c, &hch, 1) == 1) {
      headers += hch;
      size_t n = headers.size();
      if (n >= 4 && headers.compare(n - 4, 4, "\r\n\r\n") == 0) break;
    }
    size_t o = 0; while (o < resp.size()) { ssize_t n = write(c, resp.data() + o, resp.size() - o); if (n <= 0) break; o += (size_t)n; }
    close(c); close(ls);
  });
  return ntohs(a.sin_port);
}

static int serve6(const std::string &resp, std::thread &th, std::string *requestLine) {
  int ls = socket(AF_INET6, SOCK_STREAM, 0); if (ls < 0) return -1;
  int one = 1; setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
  sockaddr_in6 a{}; a.sin6_family = AF_INET6; a.sin6_addr = in6addr_loopback; a.sin6_port = 0;
  if (bind(ls, (sockaddr *)&a, sizeof a) != 0 || listen(ls, 1) != 0) { close(ls); return -1; }
  socklen_t l = sizeof a; if (getsockname(ls, (sockaddr *)&a, &l) != 0) { close(ls); return -1; }
  th = std::thread([ls, resp, requestLine] {
    int c = accept(ls, nullptr, nullptr); char ch; std::string line;
    while (read(c, &ch, 1) == 1) { if (ch == '\n') break; if (line.size() < 4096) line += ch; }
    if (requestLine) *requestLine = line;
    std::string headers; char hch;
    while (headers.size() < 65536 && read(c, &hch, 1) == 1) {
      headers += hch; size_t n = headers.size();
      if (n >= 4 && headers.compare(n - 4, 4, "\r\n\r\n") == 0) break;
    }
    size_t o = 0; while (o < resp.size()) { ssize_t n = write(c, resp.data() + o, resp.size() - o); if (n <= 0) break; o += (size_t)n; }
    close(c); close(ls);
  });
  return ntohs(a.sin6_port);
}
static int http6() {
  std::thread th; std::string requestLine;
  int port = serve6("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok", th, &requestLine);
  if (port < 0) return 77; // IPv6 loopback is disabled in this host environment.
  std::string url = "http://[::1]:" + std::to_string(port) + "/";
  FacStr *u = fac_str_from_chars(url.c_str(), (int64_t)url.size());
  FacStr *r = fac_net_httpget(u);
  th.join(); auto *v = (FacStrView *)r;
  return std::string(v->data, (size_t)v->len) == "ok" && requestLine == "GET / HTTP/1.1\r" ? 0 : 5;
}

static int http(const std::string &resp, const char *expect, const std::string &suffix = "/", const char *expectedRequest = nullptr) {
  std::thread th; std::string requestLine; int port = serve(resp, th, &requestLine); if (port < 0) return 90;
  std::string url = "http://127.0.0.1:" + std::to_string(port) + suffix;
  FacStr *u = fac_str_from_chars(url.c_str(), (int64_t)url.size());
  FacStr *r = fac_net_httpget(u);   // hostile cases throw (process exits non-zero with a FAC error)
  th.join();
  auto *v = (FacStrView *)r;
  if (!expect || std::string(v->data, (size_t)v->len) != expect) return 2;
  if (expectedRequest && requestLine != expectedRequest) return 3;
  return 0;
}

int main(int argc, char **argv) {
  std::string m = argc > 1 ? argv[1] : "";
  const std::string H = "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n";
  if (m == "ok") return http(H + "5\r\nhello\r\n6;ext=1\r\n world\r\n0\r\n\r\n", "hello world");
  if (m == "chunk-trailer") return http(H + "2\r\nok\r\n0\r\nX-Checksum: yes\r\n\r\n", "ok");
  if (m == "content-length") return http("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok", "ok");
  if (m == "informational-response") return http("HTTP/1.1 103 Early Hints\r\nLink: </app.css>; rel=preload\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok", "ok");
  if (m == "same-content-length") return http("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok", "ok");
  if (m == "query-only") return http("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok", "ok", "?q=1#client-only", "GET /?q=1 HTTP/1.1\r");
  if (m == "ipv6") return http6();
  if (m == "invalid-port") {
    const char *url = "http://127.0.0.1:999999999999999999999999999999/";
    FacStr *u = fac_str_from_chars(url, (int64_t)std::strlen(url));
    fac_net_httpget(u); return 99;
  }
  if (m == "url-encode-locale") {
    setlocale(LC_CTYPE, "C.UTF-8");
    const char *utf8 = "é"; FacStr *in = fac_str_from_chars(utf8, 2); FacStr *out = fac_net_urlencode(in);
    auto *v = (FacStrView *)out; return std::string(v->data, (size_t)v->len) == "%C3%A9" ? 0 : 4;
  }
  if (m == "huge-chunk") return http(H + "FFFFFFFFFFFFFFFF\r\nabc\r\n0\r\n\r\n", "");
  if (m == "bad-hex") return http(H + "zz\r\nabc\r\n0\r\n\r\n", "");
  if (m == "bad-terminator") return http(H + "3\r\nabcXX0\r\n\r\n", "");
  if (m == "missing-zero-chunk") return http(H + "3\r\nabc\r\n", "");
  if (m == "missing-trailer-end") return http(H + "0\r\n", "");
  if (m == "bad-content-length") return http("HTTP/1.1 200 OK\r\nContent-Length: 2x\r\n\r\nok", "");
  if (m == "short-content-length") return http("HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nok", "");
  if (m == "extra-content-length") return http("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nokx", "");
  if (m == "conflicting-content-length") return http("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nContent-Length: 3\r\n\r\nok", "");
  if (m == "te-and-length") return http("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Length: 2\r\n\r\n0\r\n\r\n", "");
  if (m == "bad-status") return http("HTTP/1.1 2x0 OK\r\nContent-Length: 2\r\n\r\nok", "");
  if (m == "protocol-upgrade") return http("HTTP/1.1 101 Switching Protocols\r\nConnection: Upgrade\r\n\r\n", "");
  if (m == "bad-header") return http("HTTP/1.1 200 OK\r\nBad Header: x\r\nContent-Length: 2\r\n\r\nok", "");
  if (m == "memzero-neg") { char b[4]; fac_memzero(b, -1); return 99; }
  if (m == "shuffle-neg") { int32_t v[2] = {1, 2}; fac_shuffle(v, -3, 4); return 99; }
  if (m == "shuffle-overflow") { int32_t v[2] = {1, 2}; fac_shuffle(v, INT64_MAX / 2, 4); return 99; }
  if (m == "memzero-ok") { char b[4] = {1, 2, 3, 4}; fac_memzero(b, 4); fac_memzero(nullptr, 0); return b[0] | b[3]; }
  return 91;
}
