#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct Canvas;
Canvas *fac_gfx_create(int32_t, int32_t);
void fac_gfx_free(Canvas *);
void fac_gfx_clear(Canvas *, int32_t);
uint32_t fac_gfx_get(Canvas *, int32_t, int32_t);
void fac_gfx_system_text(Canvas *, int32_t, int32_t, FacStr *, int32_t, int32_t);
int32_t fac_gfx_system_textwidth(FacStr *, int32_t);
int32_t fac_gfx_system_text_available();
void fac_gfx_text(Canvas *, int32_t, int32_t, FacStr *, int32_t, int32_t);
int32_t fac_gfx_textwidth(FacStr *, int32_t);
void fac_gfx_bitmap_text(Canvas *, int32_t, int32_t, FacStr *, int32_t, int32_t);
int32_t fac_gfx_bitmap_textwidth(FacStr *, int32_t);
}

static FacStr view(const char *s) {
  auto *p = const_cast<char *>(s);
  int64_t n = (int64_t)std::strlen(s);
  return FacStr{p,n,n,n,1};
}

int main() {
  FacStr latin = view("Settings and Appearance 123");
  FacStr thai = view(u8"ภาษาไทย สวัสดี FAC");
  if (!fac_gfx_system_text_available()) {
    std::puts("SKIP native system font renderer unavailable; bitmap fallback remains active");
    return 0;
  }
  Canvas *canvas = fac_gfx_create(420, 100);
  if (!canvas) return 1;
  fac_gfx_clear(canvas, 0x101820);
  int width = fac_gfx_system_textwidth(&latin, 2);
  int widthTitle = fac_gfx_system_textwidth(&latin, 3);
  if (width <= 0 || widthTitle <= width) {
    std::fprintf(stderr, "system font metrics invalid: %d / %d\n", width, widthTitle);
    fac_gfx_free(canvas); return 1;
  }
  fac_gfx_system_text(canvas, 8, 6, &latin, 0xF3F6FC, 2);
  fac_gfx_system_text(canvas, 8, 36, &thai, 0x6EA8FE, 2);
  // The public graphic.text API now follows system typography too.
  fac_gfx_text(canvas, 8, 66, &latin, 0xD9E2F2, 2);
  if (fac_gfx_textwidth(&latin, 2) != width) {
    std::fprintf(stderr, "graphic.textWidth must match graphic.text metrics\n");
    fac_gfx_free(canvas); return 1;
  }
  // Explicit bitmap APIs retain the legacy pixel font for games and pixel art.
  FacStr pixelLabel = view("PIXEL");
  fac_gfx_bitmap_text(canvas, 300, 6, &pixelLabel, 0xFFFFFF, 2);
  int changed = 0, antialiased = 0;
  for (int y=0; y<100; ++y) for (int x=0; x<420; ++x) {
    uint32_t px = fac_gfx_get(canvas,x,y);
    if (px != 0x101820) ++changed;
    unsigned r=(px>>16)&255, g=(px>>8)&255, b=px&255;
    if (px != 0x101820 && ((r>5 && r<240)||(g>5 && g<240)||(b>5 && b<240))) ++antialiased;
  }
  if (changed < 100 || antialiased < 5) {
    std::fprintf(stderr, "system font rasterization looks wrong: changed=%d antialiased=%d\n", changed, antialiased);
    fac_gfx_free(canvas); return 1;
  }
  // The low-level API remains intentionally pixel/bitmap based for games and pixel art.
  if (fac_gfx_bitmap_textwidth(&latin, 2) != (int)std::strlen("Settings and Appearance 123") * 8) {
    std::fprintf(stderr, "legacy bitmap text metrics changed unexpectedly\n");
    fac_gfx_free(canvas); return 1;
  }
  std::printf("PASS system-font available width=%d titleWidth=%d changed=%d antialiased=%d\n",
              width,widthTitle,changed,antialiased);
  fac_gfx_free(canvas);
  return 0;
}
