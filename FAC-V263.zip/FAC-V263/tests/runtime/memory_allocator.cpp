#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <numeric>
#include <random>
#include <vector>

extern "C" {
void *fac_alloc(int64_t);
void *fac_realloc(void *, int64_t);
void fac_free(void *);
void fac_set_debug(int32_t);
void fac_mem_start_tracking();
uint64_t fac_mem_used();
uint64_t fac_mem_peak();
uint64_t fac_mem_blocks();
uint64_t fac_mem_reserved();
uint64_t fac_mem_allocs();
uint64_t fac_mem_reallocs();
uint64_t fac_runtime_stack_bytes();
uint64_t fac_runtime_stack_peak_bytes();
int32_t fac_runtime_trim_thread();
void fac_mem_reset_peak();
void fac_tmp_push(void *, int32_t);
void fac_tmp_pop(void *);
void fac_cleanup_push(void *, int32_t, void *);
void fac_cleanup_pop();
struct FacStr;
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
struct FacList;
FacList *fac_list_new(int32_t, int32_t);
void fac_list_free(FacList *);
}

static int fail(const char *message) { std::fprintf(stderr, "FAIL: %s\n", message); return 1; }
int main() {
  // Allocations made before opt-in tracking stay untracked even if later resized/freed.
  void *preTracking = fac_alloc(24);
  fac_mem_start_tracking();
  const uint64_t preUsed = fac_mem_used(), preBlocks = fac_mem_blocks(), preAllocs = fac_mem_allocs();
  preTracking = fac_realloc(preTracking, 96);
  if (fac_mem_used() != preUsed || fac_mem_blocks() != preBlocks || fac_mem_allocs() != preAllocs)
    return fail("pre-tracking realloc changed tracked counters");
  fac_free(preTracking);
  if (fac_mem_used() != preUsed || fac_mem_blocks() != preBlocks) return fail("pre-tracking free changed tracked counters");

  const uint64_t used0 = fac_mem_used(), blocks0 = fac_mem_blocks(), peak0 = fac_mem_peak();
  const uint64_t reserved0 = fac_mem_reserved(), allocs0 = fac_mem_allocs(), reallocs0 = fac_mem_reallocs();
  void *p = fac_alloc(128);
  if (fac_mem_used() != used0 + 128 || fac_mem_blocks() != blocks0 + 1) return fail("alloc accounting");
  if (fac_mem_reserved() <= reserved0 + 128 || fac_mem_allocs() != allocs0 + 1) return fail("reserved/alloc counters");
  std::memset(p, 0x5A, 128);
  p = fac_realloc(p, 512);
  if (fac_mem_used() != used0 + 512 || fac_mem_blocks() != blocks0 + 1) return fail("realloc grow accounting");
  if (fac_mem_reallocs() != reallocs0 + 1) return fail("realloc counter");
  for (int i = 0; i < 128; ++i) if (((unsigned char *)p)[i] != 0x5A) return fail("realloc preserves bytes");
  p = fac_realloc(p, 64);
  if (fac_mem_used() != used0 + 64 || fac_mem_blocks() != blocks0 + 1) return fail("realloc shrink accounting");
  fac_free(p);
  if (fac_mem_used() != used0 || fac_mem_blocks() != blocks0) return fail("free accounting");
  if (fac_mem_peak() < peak0 || fac_mem_peak() < used0 + 512) return fail("peak accounting");

  const char text[] = "FAC memory tracking";
  FacStr *s = fac_str_from_chars(text, (int64_t)sizeof(text) - 1);
  if (fac_mem_used() <= used0 || fac_mem_blocks() != blocks0 + 1) return fail("string allocation tracked");
  fac_str_free(s);
  if (fac_mem_used() != used0 || fac_mem_blocks() != blocks0) return fail("string free tracked");

  FacList *l = fac_list_new(4, 0);
  if (fac_mem_blocks() != blocks0 + 1) return fail("list header tracked");
  fac_list_free(l);
  if (fac_mem_used() != used0 || fac_mem_blocks() != blocks0) return fail("list free tracked");

  // Exercise tracking-table growth, node transfer during realloc and concurrent
  // allocation/free accounting. Every worker must return to the shared baseline.
  const uint64_t concurrentUsed = fac_mem_used(), concurrentBlocks = fac_mem_blocks();
  std::vector<std::thread> allocationWorkers;
  allocationWorkers.reserve(6);
  for (int t = 0; t < 6; ++t) allocationWorkers.emplace_back([] {
    for (int i = 0; i < 1500; ++i) {
      void *block = fac_alloc(24 + (i % 8));
      block = fac_realloc(block, 80 + (i % 16));
      fac_free(block);
    }
  });
  for (auto &worker : allocationWorkers) worker.join();
  if (fac_mem_used() != concurrentUsed || fac_mem_blocks() != concurrentBlocks)
    return fail("concurrent tracked allocation accounting");

  // Grow the flat tracking index, force reallocation-key updates, create many
  // tombstones, reuse them, and finally free blocks in a deterministic random
  // order. This checks that diagnostics stay exact across table compaction.
  constexpr size_t mapCount = 16384;
  std::vector<void *> mapBlocks(mapCount, nullptr);
  std::vector<size_t> mapSizes(mapCount, 32);
  uint64_t mapBytes = 0;
  const uint64_t mapUsedBase = fac_mem_used(), mapBlocksBase = fac_mem_blocks();
  for (size_t i = 0; i < mapCount; ++i) {
    mapBlocks[i] = fac_alloc((int64_t)mapSizes[i]);
    mapBytes += mapSizes[i];
    std::memset(mapBlocks[i], (int)(i & 0xFF), 16);
  }
  if (fac_mem_used() != mapUsedBase + mapBytes || fac_mem_blocks() != mapBlocksBase + mapCount)
    return fail("flat tracking table growth accounting");
  for (size_t i = 0; i < mapCount; i += 2) {
    const size_t nextSize = 512 + (i & 31);
    mapBlocks[i] = fac_realloc(mapBlocks[i], (int64_t)nextSize);
    for (size_t b = 0; b < 16; ++b)
      if (((unsigned char *)mapBlocks[i])[b] != (unsigned char)(i & 0xFF))
        return fail("flat tracking table realloc key update preserves payload");
    mapBytes += nextSize - mapSizes[i];
    mapSizes[i] = nextSize;
  }
  if (fac_mem_used() != mapUsedBase + mapBytes || fac_mem_blocks() != mapBlocksBase + mapCount)
    return fail("flat tracking table realloc accounting");
  std::vector<size_t> mapOrder(mapCount);
  std::iota(mapOrder.begin(), mapOrder.end(), size_t(0));
  std::mt19937 mapRng(0xFAC180u);
  std::shuffle(mapOrder.begin(), mapOrder.end(), mapRng);
  for (size_t index : mapOrder) {
    if ((index & 1u) == 1u) {
      fac_free(mapBlocks[index]); mapBlocks[index] = nullptr; mapBytes -= mapSizes[index];
    }
  }
  if (fac_mem_used() != mapUsedBase + mapBytes || fac_mem_blocks() != mapBlocksBase + mapCount / 2)
    return fail("flat tracking table tombstone erase accounting");
  std::vector<void *> replacements;
  replacements.reserve(mapCount / 2);
  for (size_t i = 0; i < mapCount / 2; ++i) {
    const size_t bytes = 40 + (i & 15);
    replacements.push_back(fac_alloc((int64_t)bytes));
    mapBytes += bytes;
  }
  if (fac_mem_used() != mapUsedBase + mapBytes || fac_mem_blocks() != mapBlocksBase + mapCount)
    return fail("flat tracking table tombstone reuse accounting");
  std::shuffle(mapOrder.begin(), mapOrder.end(), mapRng);
  for (size_t index : mapOrder) {
    if (mapBlocks[index]) { fac_free(mapBlocks[index]); mapBytes -= mapSizes[index]; mapBlocks[index] = nullptr; }
  }
  std::shuffle(replacements.begin(), replacements.end(), mapRng);
  for (void *block : replacements) fac_free(block);
  if (fac_mem_used() != mapUsedBase || fac_mem_blocks() != mapBlocksBase)
    return fail("flat tracking table randomized free returns to baseline");

  // Thread-local ownership stacks now allocate only as needed, instead of
  // reserving two 16K-entry arrays for every worker thread.
  const uint64_t stack0 = fac_runtime_stack_bytes();
  if (stack0 > 2048) return fail("small per-thread inline ownership stacks");
  int values[256]{};
  for (int i = 0; i < 256; ++i) fac_tmp_push(&values[i], 0);
  const uint64_t tmpBytes = fac_runtime_stack_bytes();
  if (tmpBytes <= stack0) return fail("temporary stack grows on demand");
  for (int i = 255; i >= 0; --i) fac_tmp_pop(&values[i]);
  const uint64_t beforeCleanupGrowth = fac_runtime_stack_bytes();
  void *slots[256]{};
  for (int i = 0; i < 256; ++i) fac_cleanup_push(&slots[i], 0, nullptr);
  const uint64_t cleanupBytes = fac_runtime_stack_bytes();
  if (cleanupBytes <= beforeCleanupGrowth) return fail("cleanup stack grows on demand");
  for (int i = 0; i < 256; ++i) fac_cleanup_pop();

  // Peak reset lets benchmarks isolate one phase without resetting live usage.
  fac_mem_reset_peak();
  if (fac_mem_peak() != fac_mem_used()) return fail("peak reset to current usage");
  void *peakBlock = fac_alloc(48);
  if (fac_mem_peak() < fac_mem_used()) return fail("peak tracks new allocations");
  fac_free(peakBlock);

  // Debug tracking is a per-allocation property; toggling it must not create
  // false invalid-free reports or leave stale pointers in the live set.
  void *createdWithoutDebug = fac_alloc(16);
  fac_set_debug(1); fac_free(createdWithoutDebug);
  void *createdWithDebug = fac_alloc(16);
  fac_set_debug(0); createdWithDebug = fac_realloc(createdWithDebug, 4096);
  fac_free(createdWithDebug);

  const uint64_t stackPeakBeforeTrim = fac_runtime_stack_peak_bytes();
  int activeEntry = 0;
  fac_tmp_push(&activeEntry, 0);
  if (fac_runtime_trim_thread()) return fail("trim refuses active ownership entries");
  fac_tmp_pop(&activeEntry);
  if (!fac_runtime_trim_thread()) return fail("trim succeeds only when ownership stacks are idle");
  if (fac_runtime_stack_bytes() != stack0) return fail("trim releases per-thread spill capacity");
  int afterTrim = 0; fac_tmp_push(&afterTrim, 0);
  if (fac_runtime_stack_bytes() != stack0) return fail("thread stacks can reuse inline capacity after trim");
  if (fac_runtime_stack_peak_bytes() < stackPeakBeforeTrim) return fail("stack peak remains a high-water mark");
  fac_tmp_pop(&afterTrim);
  if (!fac_runtime_trim_thread()) return fail("second trim succeeds after pop");

  std::puts("PASS FAC allocator accounting / concurrent map / peak reset / lazy TLS stacks / trim / debug toggles");
  return 0;
}
