#include <cstdint>
#include <cstdio>
#include <new>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void fac_cycle_visit(void *object);
int64_t fac_obj_collect_cycles();
uint64_t fac_obj_live_count();
void fac_mem_start_tracking();
uint64_t fac_mem_blocks();
}

namespace {
struct Node {
  std::vector<void *> edges;
};

void trace_node(void *opaque) {
  const auto *node = static_cast<const Node *>(opaque);
  for (void *child : node->edges) fac_cycle_visit(child);
}

void drop_node(void *opaque) {
  auto *node = static_cast<Node *>(opaque);
  for (void *child : node->edges) fac_obj_release(child);
  node->edges.clear();
  node->edges.~vector<void *>();
}

Node *make_node() {
  void *storage = fac_obj_new(static_cast<int64_t>(sizeof(Node)),
      reinterpret_cast<void *>(drop_node), nullptr,
      reinterpret_cast<void *>(trace_node), nullptr);
  if (!storage) return nullptr;
  return new (storage) Node();
}

bool run_case(const char *name, int count, int degree, bool externalRoot) {
  const uint64_t liveBefore = fac_obj_live_count();
  const uint64_t blocksBefore = fac_mem_blocks();
  std::vector<Node *> nodes;
  nodes.reserve(static_cast<size_t>(count));
  for (int i = 0; i < count; ++i) {
    Node *node = make_node();
    if (!node) {
      std::fprintf(stderr, "FAIL %s: allocation failed at node %d\n", name, i);
      return false;
    }
    nodes.push_back(node);
  }

  // Every case is strongly connected by the first successor edge. Remaining
  // offsets increase edge density without changing the reachable component.
  for (int i = 0; i < count; ++i) {
    Node *from = nodes[static_cast<size_t>(i)];
    from->edges.reserve(static_cast<size_t>(degree));
    for (int offset = 1; offset <= degree; ++offset) {
      Node *to = nodes[static_cast<size_t>((i + offset) % count)];
      from->edges.push_back(to);
      fac_obj_retain(to);
    }
  }

  Node *root = externalRoot ? nodes[static_cast<size_t>(count / 2)] : nullptr;
  if (root) fac_obj_retain(root);
  for (Node *node : nodes) fac_obj_release(node);
  nodes.clear();

  const int64_t collected = fac_obj_collect_cycles();
  const int64_t expected = externalRoot ? 0 : count;
  if (collected != expected) {
    std::fprintf(stderr, "FAIL %s: expected %lld collected, got %lld\n", name,
        static_cast<long long>(expected), static_cast<long long>(collected));
    return false;
  }
  if (fac_obj_live_count() != liveBefore + (externalRoot ? count : 0)) {
    std::fprintf(stderr, "FAIL %s: live-object count changed unexpectedly\n", name);
    return false;
  }

  if (root) {
    fac_obj_release(root);
    if (fac_obj_collect_cycles() != count) {
      std::fprintf(stderr, "FAIL %s: component was not collectible after root release\n", name);
      return false;
    }
  }

  if (fac_obj_live_count() != liveBefore || fac_mem_blocks() != blocksBefore) {
    std::fprintf(stderr, "FAIL %s: liveness/allocation counters did not return to baseline\n", name);
    return false;
  }
  return true;
}
} // namespace

int main() {
  fac_mem_start_tracking();
  if (!run_case("small-sparse", 64, 2, false) ||
      !run_case("medium-sparse", 2048, 2, false) ||
      !run_case("large-sparse", 8192, 2, false) ||
      !run_case("medium-dense", 128, 127, false) ||
      !run_case("rooted-sparse", 4096, 2, true) ||
      !run_case("rooted-dense", 96, 95, true))
    return 1;

  if (fac_obj_collect_cycles() != 0 || fac_obj_live_count() != 0 || fac_mem_blocks() != 0) {
    std::fprintf(stderr, "FAIL final empty-collector invariant\n");
    return 1;
  }
  std::puts("PASS cycle collector scalability: sparse/dense and rooted/unrooted graphs reclaimed or preserved correctly");
  return 0;
}
