// JSON builder hardening: self-insertion / cycles, null children, set() aliasing, NaN, serializer depth.
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
struct FacStr; struct JV;
struct FacStrView { char *data; int64_t len; };
extern "C" {
FacStr *fac_str_from_chars(const char *, int64_t);
JV *fac_json_object(); JV *fac_json_array(); JV *fac_json_newfloat(double); JV *fac_json_newint(int64_t);
void fac_json_set(JV *, FacStr *, JV *); void fac_json_push(JV *, JV *);
FacStr *fac_json_stringify(JV *); JV *fac_jd_get(JV *, FacStr *);
void fac_jd_free(JV *);
}
static FacStr *S(const char *s) { return fac_str_from_chars(s, (int64_t)strlen(s)); }
static std::string V(FacStr *s) { auto *v = (FacStrView *)s; return std::string(v->data, (size_t)v->len); }
int main(int argc, char **argv) {
  std::string m = argc > 1 ? argv[1] : "";
  if (m == "ok") {
    JV *o = fac_json_object(); JV *a = fac_json_array();
    fac_json_push(a, fac_json_newint(1)); fac_json_push(a, nullptr); fac_json_push(a, fac_json_newfloat(NAN));
    fac_json_set(o, S("k"), a);
    fac_json_set(o, S("k"), a);                       // same node again: used to free it and then use the freed node
    if (V(fac_json_stringify(o)) != "{\"k\":[1,null,null]}") return 1;
    fac_jd_free(o); return 0;
  }
  if (m == "self-push") { JV *a = fac_json_array(); fac_json_push(a, a); return 99; }
  if (m == "self-set") { JV *o = fac_json_object(); fac_json_set(o, S("x"), o); return 99; }
  if (m == "indirect-cycle") { JV *a = fac_json_array(), *b = fac_json_array(); fac_json_push(a, b); fac_json_push(b, a); return 99; }
  if (m == "deep") {   // built programmatically, deeper than the serializer limit -> error, not a stack overflow
    JV *root = fac_json_array(), *cur = root;
    for (int i = 0; i < 100000; i++) { JV *n = fac_json_array(); fac_json_push(cur, n); cur = n; }
    fac_json_stringify(root); return 99;
  }
  return 91;
}
