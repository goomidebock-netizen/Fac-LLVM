#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

extern "C" {
struct FacStr;
struct FacList { void *data; int64_t len, cap; int32_t esz, ek; void (*dropFn)(void *); void (*copyFn)(void *, const void *); };
void *fac_hm_new(int32_t, int32_t, int32_t, int32_t);
void fac_hm_set(void *, const void *, const void *);
void fac_hm_remove(void *, const void *);
int32_t fac_hm_has(void *, const void *);
void fac_hm_get(void *, const void *, void *);
void *fac_ti_new();
void fac_ti_insert(void *, const void *);
void *fac_g_new(int32_t, int32_t);
void fac_g_addnode(void *, const void *);
void fac_g_addedge2(void *, const void *, const void *);
int32_t fac_g_hasedge(void *, const void *, const void *);
void fac_g_removenode(void *, const void *);
int32_t fac_ti_has(void *, const void *);
FacList *fac_ti_words(void *, const void *);
void fac_ti_remove(void *, const void *);
void fac_ds_free(void *);
int64_t fac_ds_len(void *);
void *fac_ds_copy(void *);
void fac_ds_clear(void *);
void fac_list_free(FacList *);
FacStr *fac_str_from_chars(const char *, int64_t);
int32_t fac_str_cmp(FacStr *, FacStr *);
void fac_str_free(FacStr *);
}

static FacStr *str(const char *s) { return fac_str_from_chars(s, (int64_t)std::strlen(s)); }
static int fail(const char *s) { std::fprintf(stderr, "FAIL: %s\n", s); return 1; }
int main() {
  // Trigger repeated HMap compaction and flat-index rebuilds while item storage
  // grows, shrinks and moves; slot indices must keep targeting the right keys.
  void *map = fac_hm_new(4, 8, 4, 8);
  for (int64_t i = 0; i < 2000; ++i) { int64_t v = i * 3; fac_hm_set(map, &i, &v); }
  for (int64_t i = 0; i < 1500; ++i) fac_hm_remove(map, &i);
  for (int64_t i = 1500; i < 2000; ++i) {
    int64_t out = -1, expected = i * 3;
    if (!fac_hm_has(map, &i)) return fail("numeric key missing after compaction");
    fac_hm_get(map, &i, &out);
    if (out != expected) return fail("numeric value mismatch after compaction");
  }
  fac_ds_free(map);

  // Verify that string key/value ownership survives caller release and updates.
  map = fac_hm_new(14, 8, 14, 8);
  FacStr *k = str("persistent-key"), *v = str("first-value");
  fac_hm_set(map, &k, &v); fac_str_free(k); fac_str_free(v);
  k = str("persistent-key"); v = str("updated-value"); fac_hm_set(map, &k, &v);
  fac_str_free(k); fac_str_free(v);
  k = str("persistent-key"); FacStr *out = nullptr; fac_hm_get(map, &k, &out);
  FacStr *expected = str("updated-value");
  if (fac_str_cmp(out, expected) != 0) return fail("string key/value ownership");
  fac_str_free(expected); fac_str_free(k); fac_ds_free(map);

  // The compact trie representation must preserve byte-lexicographic word order.
  void *trie = fac_ti_new();
  const char *words[] = {"app", "apple", "ant", "ape"};
  for (const char *w : words) { FacStr *x = str(w); fac_ti_insert(trie, &x); fac_str_free(x); }
  FacStr *prefix = str("ap"); FacList *list = fac_ti_words(trie, &prefix);
  const char *expectedWords[] = {"ape", "app", "apple"};
  if (!list || list->len != 3) return fail("trie prefix result length");
  auto **got = static_cast<FacStr **>(list->data);
  for (int i = 0; i < 3; ++i) { FacStr *e = str(expectedWords[i]); if (fac_str_cmp(got[i], e) != 0) return fail("trie words ordering"); fac_str_free(e); }
  fac_list_free(list); fac_str_free(prefix); fac_ds_free(trie);

  // Trie depth is input-controlled (one node per UTF-8 byte). Enumeration,
  // removal and destruction must not recurse once per byte or overflow the
  // C++ runtime stack on a long but otherwise valid key.
  std::string deepWord(100000, 'x');
  FacStr *deepValue = fac_str_from_chars(deepWord.data(), (int64_t)deepWord.size());
  FacStr *emptyPrefix = fac_str_from_chars("", 0);
  trie = fac_ti_new();
  fac_ti_insert(trie, &deepValue);
  if (!fac_ti_has(trie, &deepValue)) return fail("deep trie key lookup");
  list = fac_ti_words(trie, &emptyPrefix);
  if (!list || list->len != 1) return fail("deep trie enumeration");
  got = static_cast<FacStr **>(list->data);
  if (fac_str_cmp(got[0], deepValue) != 0) return fail("deep trie word content");
  fac_list_free(list);
  void *trieCopy = fac_ds_copy(trie); // clone uses the same iterative enumeration path
  if (!trieCopy || !fac_ti_has(trieCopy, &deepValue)) return fail("deep trie clone");
  fac_ds_free(trieCopy);
  fac_ti_remove(trie, &deepValue);
  if (fac_ti_has(trie, &deepValue)) return fail("deep trie removal");
  fac_ti_insert(trie, &deepValue);
  fac_ds_clear(trie); // exercises iterative subtree cleanup
  if (fac_ti_has(trie, &deepValue)) return fail("deep trie clear");
  fac_ti_insert(trie, &deepValue);
  fac_ds_free(trie); // exercises iterative destructor of a 100,000-byte path
  fac_str_free(deepValue); fac_str_free(emptyPrefix);

  // Graph's string_view index must remain valid while the stable deque grows,
  // and must drop views before releasing keys. Exercise tombstone/reinsert and
  // clone paths after enough additions to cross several deque block boundaries.
  void *graph = fac_g_new(4, (int32_t)sizeof(int64_t));
  constexpr int64_t graphNodes = 4096;
  for (int64_t i = 0; i + 1 < graphNodes; ++i) {
    const int64_t nextNode = i + 1;
    fac_g_addedge2(graph, &i, &nextNode);
  }
  for (int64_t i = 0; i + 1 < graphNodes; ++i) {
    const int64_t next = i + 1;
    if (!fac_g_hasedge(graph, &i, &next) || !fac_g_hasedge(graph, &next, &i))
      return fail("Graph key views became invalid while deque storage grew");
  }
  const int64_t removed = 2048;
  fac_g_removenode(graph, &removed);
  const int64_t next = removed + 1;
  if (fac_g_hasedge(graph, &removed, &next)) return fail("Graph removed node remained in the index");
  fac_g_addedge2(graph, &removed, &next); // reinsert same key with a fresh stable view
  if (!fac_g_hasedge(graph, &removed, &next)) return fail("Graph failed to reinsert a removed key");
  void *graphCopy = fac_ds_copy(graph);
  if (!graphCopy || fac_ds_len(graphCopy) != graphNodes)
    return fail("Graph clone lost nodes after stable-view indexing");
  if (!fac_g_hasedge(graphCopy, &removed, &next)) return fail("Graph clone index views are invalid");
  fac_ds_free(graphCopy); fac_ds_free(graph);

  // Managed-string keys must stay alive through the node-owned blob and their
  // non-owning index views must compare by string contents, not handle address.
  graph = fac_g_new(14, 8);
  FacStr *ga = str("graph-node-alpha"), *gb = str("graph-node-beta");
  fac_g_addedge2(graph, &ga, &gb);
  fac_str_free(ga); fac_str_free(gb);
  ga = str("graph-node-alpha"); gb = str("graph-node-beta");
  if (!fac_g_hasedge(graph, &ga, &gb)) return fail("Graph managed string-key lookup");
  fac_g_removenode(graph, &ga);
  if (fac_g_hasedge(graph, &ga, &gb)) return fail("Graph managed string-key removal");
  fac_str_free(ga); fac_str_free(gb); fac_ds_free(graph);

  std::puts("PASS HMap compaction/views, Graph stable key views, string ownership, Trie order and 100k-depth safety");
  return 0;
}
