#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>
#include <string>

static std::atomic<long long> g_fail_after{-1};
static bool should_fail_allocation() noexcept {
  long long current = g_fail_after.load(std::memory_order_relaxed);
  while (current >= 0) {
    if (current == 0) {
      if (g_fail_after.compare_exchange_weak(current, -1, std::memory_order_relaxed)) return true;
    } else if (g_fail_after.compare_exchange_weak(current, current - 1, std::memory_order_relaxed)) return false;
  }
  return false;
}
static void *test_new(std::size_t size) {
  if (should_fail_allocation()) throw std::bad_alloc();
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new(std::size_t size) { return test_new(size); }
void *operator new[](std::size_t size) { return test_new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

extern "C" {
struct FacStr;
void *fac_ll_new(int32_t, int32_t); void fac_ll_addlast(void *, const void *);
void *fac_st_new(int32_t, int32_t); void fac_st_push(void *, const void *);
void *fac_q_new(int32_t, int32_t); void fac_q_enqueue(void *, const void *);
void *fac_hp_new(int32_t, int32_t); void fac_hp_push(void *, const void *);
void *fac_tr_new(int32_t, int32_t); void fac_tr_add(void *, const void *); void fac_tr_remove(void *, const void *); int32_t fac_tr_has(void *, const void *);
void *fac_ti_new(); void fac_ti_insert(void *, const void *); int32_t fac_ti_prefix(void *, const void *);
void *fac_g_new(int32_t, int32_t); void fac_g_addnode(void *, const void *); void fac_g_addedge2(void *, const void *, const void *);
void *fac_g_neighbors(void *, const void *); void *fac_g_bfs(void *, const void *); void *fac_g_dfs(void *, const void *); void *fac_g_shortest(void *, const void *, const void *);
int32_t fac_g_hasedge(void *, const void *, const void *); void fac_list_free(void *);
void *fac_mx_new(int64_t, int64_t, int32_t, int32_t); void fac_mx_set(void *, int64_t, int64_t, const void *);
void *fac_ds_copy(void *); void fac_ds_free(void *); int64_t fac_ds_len(void *);
FacStr *fac_str_from_chars(const char *, int64_t); void fac_str_free(FacStr *);
void fac_try_enter(void *); void fac_try_leave(); int32_t fac_err_code();
void fac_mem_start_tracking(); uint64_t fac_mem_blocks();
}

using Op = void (*)(void *, const void *);
static int fail(const char *message) { std::fprintf(stderr, "FAIL: %s\n", message); return 1; }
static int try_op(Op op, void *object, const void *value) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { op(object, value); fac_try_leave(); return 0; }
  return fac_err_code();
}
static int try_copy(void *source, void **copy) {
  void *jumpBuffer[5]{}; *copy = nullptr;
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { *copy = fac_ds_copy(source); fac_try_leave(); return 0; }
  return fac_err_code();
}
using GraphWalk = void *(*)(void *, const void *);
using GraphShortest = void *(*)(void *, const void *, const void *);
static int try_graph_walk(GraphWalk walk, void *graph, const void *start, void **result) {
  void *jumpBuffer[5]{}; *result = nullptr;
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { *result = walk(graph, start); fac_try_leave(); return 0; }
  return fac_err_code();
}
static int try_graph_shortest(GraphShortest walk, void *graph, const void *start, const void *finish, void **result) {
  void *jumpBuffer[5]{}; *result = nullptr;
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { *result = walk(graph, start, finish); fac_try_leave(); return 0; }
  return fac_err_code();
}
static FacStr *str(const std::string &s) { return fac_str_from_chars(s.data(), (int64_t)s.size()); }
static bool clone_fault_sweep(void *source, int64_t expectedSize, const char *label) {
  int failures = 0; bool succeeded = false;
  for (long long failAt = 0; failAt < 512; ++failAt) {
    g_fail_after.store(failAt, std::memory_order_relaxed);
    void *copy = nullptr;
    const int error = try_copy(source, &copy);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++failures;
      if (copy) return false;
      if (fac_ds_len(source) != expectedSize) return false;
    } else if (error == 0) {
      succeeded = true;
      if (!copy || fac_ds_len(copy) != expectedSize) return false;
      fac_ds_free(copy);
      break;
    } else return false;
  }
  if (!succeeded || failures == 0) {
    std::fprintf(stderr, "FAIL: %s clone fault points (%d failures, success=%d)\n", label, failures, succeeded ? 1 : 0);
    return false;
  }
  return true;
}
static bool insertion_failure(Op op, void *object, FacStr *value, const char *label) {
  g_fail_after.store(0, std::memory_order_relaxed);
  const int error = try_op(op, object, &value);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (error != 5 || fac_ds_len(object) != 0) {
    std::fprintf(stderr, "FAIL: %s must report Resource and remain empty (error=%d size=%lld)\n", label, error, (long long)fac_ds_len(object));
    return false;
  }
  if (try_op(op, object, &value) != 0 || fac_ds_len(object) != 1) {
    std::fprintf(stderr, "FAIL: %s retry after OOM\n", label); return false;
  }
  return true;
}
static bool queue_growth_failure(void *queue, FacStr *value) {
  // std::deque owns an initial block; keep adding until the next enqueue must
  // request another block, then fail that allocation deterministically.
  bool observed = false;
  for (int attempt = 0; attempt < 512; ++attempt) {
    const int64_t before = fac_ds_len(queue);
    g_fail_after.store(0, std::memory_order_relaxed);
    const int error = try_op(fac_q_enqueue, queue, &value);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      observed = true;
      if (fac_ds_len(queue) != before) return false;
      if (try_op(fac_q_enqueue, queue, &value) != 0 || fac_ds_len(queue) != before + 1) return false;
      break;
    }
    if (error != 0 || fac_ds_len(queue) != before + 1) return false;
  }
  if (!observed) std::fprintf(stderr, "FAIL: Queue did not hit an allocation boundary\n");
  return observed;
}

int main() {
  fac_mem_start_tracking();
  const uint64_t baseline = fac_mem_blocks();
  FacStr *value = str("managed-runtime-value");

  // A failed STL node/buffer allocation must release the managed FacStr ref
  // prepared immediately before container insertion.
  void *ll = fac_ll_new(14, 8), *st = fac_st_new(14, 8), *q = fac_q_new(14, 8), *hp = fac_hp_new(14, 8), *treeInsert = fac_tr_new(14, 8);
  if (!insertion_failure(fac_ll_addlast, ll, value, "LinkedList addLast")) return 1;
  if (!insertion_failure(fac_st_push, st, value, "Stack push")) return 1;
  if (!queue_growth_failure(q, value)) return fail("Queue enqueue OOM rollback/retry");
  if (!insertion_failure(fac_hp_push, hp, value, "Heap push")) return 1;
  if (!insertion_failure(fac_tr_add, treeInsert, value, "AVL Tree add")) return 1;
  fac_ds_free(ll); fac_ds_free(st); fac_ds_free(q); fac_ds_free(hp); fac_ds_free(treeInsert);

  // Two-child AVL deletion transfers the successor's managed key reference;
  // the removed root key and the successor key must each have one owner.
  void *deleteTree = fac_tr_new(14, 8);
  FacStr *treeB = str("tree-b"), *treeA = str("tree-a"), *treeC = str("tree-c");
  fac_tr_add(deleteTree, &treeB); fac_tr_add(deleteTree, &treeA); fac_tr_add(deleteTree, &treeC);
  fac_tr_remove(deleteTree, &treeB);
  if (fac_ds_len(deleteTree) != 2 || fac_tr_has(deleteTree, &treeB) || !fac_tr_has(deleteTree, &treeA) || !fac_tr_has(deleteTree, &treeC))
    return fail("AVL two-child deletion lost or duplicated a managed key");
  fac_str_free(treeA); fac_str_free(treeB); fac_str_free(treeC); fac_ds_free(deleteTree);

  // Trie insertion is transactional: failing after a few successful path
  // allocations must not leave a ghost prefix or retain a partial suffix.
  std::string longWord(2048, 't');
  FacStr *longValue = str(longWord);
  void *trie = fac_ti_new();
  g_fail_after.store(12, std::memory_order_relaxed);
  const int trieError = try_op(fac_ti_insert, trie, &longValue);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (trieError != 5 || fac_ds_len(trie) != 0 || fac_ti_prefix(trie, &longValue))
    return fail("Trie insertion did not roll back its partial path after OOM");
  if (try_op(fac_ti_insert, trie, &longValue) != 0 || fac_ds_len(trie) != 1)
    return fail("Trie insertion retry after OOM");
  fac_ds_free(trie); fac_str_free(longValue);

  // Graph read/traversal APIs allocate STL work buffers inside the C ABI.
  // Inject a failure at the first allocation and require Resource error + retry.
  void *graph = fac_g_new(3, (int32_t)sizeof(int32_t));
  int32_t graphA = 11, graphB = 22;
  fac_g_addnode(graph, &graphA); fac_g_addnode(graph, &graphB); fac_g_addedge2(graph, &graphA, &graphB);
  GraphWalk graphWalks[] = {fac_g_neighbors, fac_g_bfs, fac_g_dfs};
  const char *graphWalkNames[] = {"Graph neighbors", "Graph BFS", "Graph DFS"};
  for (size_t i = 0; i < sizeof(graphWalks) / sizeof(graphWalks[0]); ++i) {
    void *result = nullptr;
    g_fail_after.store(0, std::memory_order_relaxed);
    const int error = try_graph_walk(graphWalks[i], graph, &graphA, &result);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error != 5 || result != nullptr || !fac_g_hasedge(graph, &graphA, &graphB)) {
      std::fprintf(stderr, "FAIL: %s allocation failure escaped or changed graph (error=%d)\n", graphWalkNames[i], error);
      return 1;
    }
    if (try_graph_walk(graphWalks[i], graph, &graphA, &result) != 0 || !result)
      return fail("Graph traversal retry after OOM");
    fac_list_free(result);
  }
  void *shortest = nullptr;
  g_fail_after.store(0, std::memory_order_relaxed);
  const int shortestError = try_graph_shortest(fac_g_shortest, graph, &graphA, &graphB, &shortest);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (shortestError != 5 || shortest || !fac_g_hasedge(graph, &graphA, &graphB))
    return fail("Graph shortest-path OOM must become Resource without mutation");
  if (try_graph_shortest(fac_g_shortest, graph, &graphA, &graphB, &shortest) != 0 || !shortest)
    return fail("Graph shortest-path retry after OOM");
  fac_list_free(shortest); fac_ds_free(graph);

  // Build managed-string containers and force failure at every clone allocation
  // point. A failed copy must destroy every already-copied managed reference.
  ll = fac_ll_new(14, 8); st = fac_st_new(14, 8); q = fac_q_new(14, 8); hp = fac_hp_new(14, 8);
  void *tree = fac_tr_new(14, 8); void *matrix = fac_mx_new(8, 8, 14, 8);
  for (int i = 0; i < 48; ++i) {
    if (try_op(fac_ll_addlast, ll, &value) != 0 || try_op(fac_st_push, st, &value) != 0 ||
        try_op(fac_q_enqueue, q, &value) != 0 || try_op(fac_hp_push, hp, &value) != 0)
      return fail("building managed-string collection sources");
    std::string keyText = "tree-key-" + std::to_string(i);
    FacStr *key = str(keyText);
    if (try_op(fac_tr_add, tree, &key) != 0) return fail("building AVL source");
    fac_str_free(key);
  }
  // Fill all cells with a managed value using explicit coordinates.
  for (int r = 0; r < 8; ++r) for (int c = 0; c < 8; ++c) fac_mx_set(matrix, r, c, &value);

  void *trieSource = fac_ti_new();
  for (int i = 0; i < 48; ++i) {
    FacStr *word = str("word-" + std::to_string(i));
    fac_ti_insert(trieSource, &word); fac_str_free(word);
  }
  fac_str_free(value); value = nullptr;

  if (!clone_fault_sweep(ll, 48, "LinkedList") || !clone_fault_sweep(st, 48, "Stack") ||
      !clone_fault_sweep(q, 48, "Queue") || !clone_fault_sweep(hp, 48, "Heap") ||
      !clone_fault_sweep(tree, 48, "AVL Tree") || !clone_fault_sweep(matrix, 64, "Matrix") ||
      !clone_fault_sweep(trieSource, 48, "Trie")) return 1;

  fac_ds_free(ll); fac_ds_free(st); fac_ds_free(q); fac_ds_free(hp);
  fac_ds_free(tree); fac_ds_free(matrix); fac_ds_free(trieSource);
  if (fac_mem_blocks() != baseline) {
    std::fprintf(stderr, "FAIL: managed string allocation leak after clone fault sweeps (baseline=%llu now=%llu)\n",
                 (unsigned long long)baseline, (unsigned long long)fac_mem_blocks());
    return 1;
  }
  std::puts("PASS runtime collection insertion rollback / Graph traversal OOM conversion / Trie atomic insert / managed-string clone fault injection");
  return 0;
}
