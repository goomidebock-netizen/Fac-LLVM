#include <atomic>
#include <cstdint>
#include <cstdio>
#include <thread>
#include <vector>

extern "C" {
void fac_tmp_push(void *, int32_t);
void fac_tmp_pop(void *);
void fac_cleanup_push(void *, int32_t, void *);
void fac_cleanup_pop();
uint64_t fac_runtime_stack_bytes();
}

int main() {
  constexpr int threads = 24;
  constexpr int entries = 384;
  std::atomic<int> failures{0};
  std::vector<std::thread> workers;
  workers.reserve(threads);
  for (int t = 0; t < threads; ++t) {
    workers.emplace_back([&] {
      int values[entries]{};
      for (int i = 0; i < entries; ++i) fac_tmp_push(&values[i], 0);
      if (fac_runtime_stack_bytes() < (uint64_t)entries * 24u) ++failures;
      for (int i = entries - 1; i >= 0; --i) fac_tmp_pop(&values[i]);
      void *slots[entries]{};
      for (int i = 0; i < entries; ++i) fac_cleanup_push(&slots[i], 0, nullptr);
      for (int i = 0; i < entries; ++i) fac_cleanup_pop();
    });
  }
  for (auto &worker : workers) worker.join();
  if (failures.load()) return 1;
  std::puts("PASS lazy per-thread ownership stacks under concurrent thread creation");
  return 0;
}
