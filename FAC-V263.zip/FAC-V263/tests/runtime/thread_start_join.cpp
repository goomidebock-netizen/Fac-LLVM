#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>

extern "C" void *fac_thread_start(void *closure);
extern "C" void fac_thread_join(void *handle);
extern "C" void fac_try_enter(void *jumpBuffer);
extern "C" void fac_try_leave();
extern "C" int32_t fac_err_code();
extern "C" [[noreturn]] void fac_throw(void *message, int32_t code);
extern "C" void fac_cleanup_push(void *slot, int32_t kind, void *drop);
extern "C" void fac_tmp_push_drop(void *value, void *drop);

struct ClosureHeader {
  void *entry;
  int64_t refs;
  void (*drop)(void *);
};

struct CountClosure {
  ClosureHeader header;
  std::atomic<int> *count;
  static void run(void *opaque) {
    auto *self = static_cast<CountClosure *>(opaque);
    self->count->fetch_add(1, std::memory_order_relaxed);
  }
  explicit CountClosure(std::atomic<int> *out)
      : header{reinterpret_cast<void *>(run), -1, nullptr}, count(out) {}
};

struct CppThrowClosure {
  ClosureHeader header;
  std::atomic<int> *cleanupCount;
  std::atomic<int> *temporaryDropCount;
  static void cleanup(void *slot) {
    auto *count = static_cast<std::atomic<int> **>(slot);
    (*count)->fetch_add(1, std::memory_order_relaxed);
  }
  static void dropTemporary(void *value) {
    static_cast<std::atomic<int> *>(value)->fetch_add(1, std::memory_order_relaxed);
  }
  static void run(void *opaque) {
    auto *self = static_cast<CppThrowClosure *>(opaque);
    fac_cleanup_push(&self->cleanupCount, 4, reinterpret_cast<void *>(cleanup));
    fac_tmp_push_drop(self->temporaryDropCount, reinterpret_cast<void *>(dropTemporary));
    throw std::runtime_error("expected thread callback failure");
  }
  CppThrowClosure(std::atomic<int> *cleanupOut, std::atomic<int> *temporaryDropOut)
      : header{reinterpret_cast<void *>(run), -1, nullptr},
        cleanupCount(cleanupOut), temporaryDropCount(temporaryDropOut) {}
};

struct FacThrowClosure {
  ClosureHeader header;
  std::atomic<int> *cleaned;
  static void cleanup(void *slot) {
    auto *out = static_cast<std::atomic<int> **>(slot);
    (*out)->fetch_add(1, std::memory_order_relaxed);
  }
  static void run(void *opaque) {
    auto *self = static_cast<FacThrowClosure *>(opaque);
    fac_cleanup_push(&self->cleaned, 4, reinterpret_cast<void *>(cleanup));
    fac_throw(nullptr, 17);
  }
  explicit FacThrowClosure(std::atomic<int> *out)
      : header{reinterpret_cast<void *>(run), -1, nullptr}, cleaned(out) {}
};

static int join_catching_error(void *handle) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fac_thread_join(handle);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static int start_catching_error(void *closure) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    void *handle = fac_thread_start(closure);
    fac_thread_join(handle);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

int main() {
  std::atomic<int> count{0};
  CountClosure normal(&count);
  void *normalHandle = fac_thread_start(&normal);
  fac_thread_join(normalHandle);
  if (count.load(std::memory_order_relaxed) != 1) {
    std::fprintf(stderr, "FAIL: normal thread callback did not execute exactly once\n");
    return 1;
  }

  std::atomic<int> cppCleanupCount{0};
  std::atomic<int> cppTemporaryDropCount{0};
  CppThrowClosure cppThrow(&cppCleanupCount, &cppTemporaryDropCount);
  void *cppHandle = fac_thread_start(&cppThrow);
  if (join_catching_error(cppHandle) != 8) {
    std::fprintf(stderr, "FAIL: C++ exception was not propagated as Resource error by join\n");
    return 1;
  }
  if (cppCleanupCount.load(std::memory_order_relaxed) != 1 ||
      cppTemporaryDropCount.load(std::memory_order_relaxed) != 1) {
    std::fprintf(stderr, "FAIL: C++ exception skipped worker cleanup/temporary drops\n");
    return 1;
  }

  std::atomic<int> workerCleaned{0};
  FacThrowClosure facThrow(&workerCleaned);
  void *facHandle = fac_thread_start(&facThrow);
  if (join_catching_error(facHandle) != 17) {
    std::fprintf(stderr, "FAIL: FAC error was not propagated by join with its original code\n");
    return 1;
  }
  if (workerCleaned.load(std::memory_order_relaxed) != 1) {
    std::fprintf(stderr, "FAIL: worker FAC cleanup stack did not unwind exactly once\n");
    return 1;
  }

  ClosureHeader noEntry{nullptr, -1, nullptr};
  if (start_catching_error(&noEntry) != 6 || start_catching_error(nullptr) != 6) {
    std::fprintf(stderr, "FAIL: invalid thread closure did not report NullPointer\n");
    return 1;
  }

  std::puts("PASS thread.start/join normal completion, C++ exception, FAC error and worker cleanup propagation");
  return 0;
}
