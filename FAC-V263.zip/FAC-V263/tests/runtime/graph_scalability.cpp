#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <vector>

extern "C" {
struct FacList {
  void *data;
  int64_t len, cap;
  int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};
void *fac_g_new(int32_t, int32_t);
void fac_g_addnode(void *, const void *);
void fac_g_addedge2(void *, const void *, const void *);
void fac_g_addedge3(void *, const void *, const void *, double);
void fac_g_addarc2(void *, const void *, const void *);
void fac_g_addarc3(void *, const void *, const void *, double);
int32_t fac_g_hasedge(void *, const void *, const void *);
void fac_g_removeedge(void *, const void *, const void *);
void fac_g_removearc(void *, const void *, const void *);
void fac_g_removenode(void *, const void *);
void *fac_g_shortest(void *, const void *, const void *);
void *fac_ds_copy(void *);
void fac_ds_free(void *);
void fac_list_free(FacList *);
void fac_try_enter(void *);
void fac_try_leave();
int32_t fac_err_code();
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

template <typename F>
static int catch_fac(F fn) {
  void *jb[5]{};
  fac_try_enter(jb);
  if (__builtin_setjmp(jb) == 0) {
    fn();
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static bool path_is(FacList *path, const std::vector<int32_t> &expected) {
  if (!path || path->esz != (int32_t)sizeof(int32_t) || path->len != (int64_t)expected.size()) return false;
  const auto *items = static_cast<const int32_t *>(path->data);
  for (size_t i = 0; i < expected.size(); ++i) if (items[i] != expected[i]) return false;
  return true;
}

int main() {
  // Geometric growth and hybrid high-degree index, including clone/remove/reinsert.
  void *star = fac_g_new(3, (int32_t)sizeof(int32_t));
  const int32_t center = -1;
  fac_g_addnode(star, &center);
  constexpr int LEAVES = 6000;
  for (int32_t i = 0; i < LEAVES; ++i) fac_g_addarc2(star, &center, &i);
  for (int32_t i = 0; i < LEAVES; ++i)
    if (!fac_g_hasedge(star, &center, &i)) return fail("high-degree index lost a Star edge");
  const int32_t removed = LEAVES / 2;
  fac_g_removearc(star, &center, &removed);
  if (fac_g_hasedge(star, &center, &removed)) return fail("removeArc left a stale high-degree index entry");
  fac_g_addarc2(star, &center, &removed);
  if (!fac_g_hasedge(star, &center, &removed)) return fail("high-degree index failed after reinsertion");
  void *starCopy = fac_ds_copy(star);
  if (!starCopy || !fac_g_hasedge(starCopy, &center, &removed)) return fail("Graph clone lost high-degree index entries");
  fac_g_removenode(star, &removed);
  if (fac_g_hasedge(star, &center, &removed)) return fail("removeNode left a stale high-degree index entry");
  const int32_t replacement = LEAVES + 1;
  fac_g_addarc2(star, &center, &replacement);
  if (!fac_g_hasedge(star, &center, &replacement)) return fail("high-degree index failed after node replacement");
  fac_ds_free(starCopy);
  fac_ds_free(star);

  // removeArc is directional; removeEdge removes both directions.
  void *directed = fac_g_new(3, (int32_t)sizeof(int32_t));
  const int32_t a = 70001, b = 70002;
  fac_g_addedge2(directed, &a, &b);
  fac_g_removearc(directed, &a, &b);
  if (fac_g_hasedge(directed, &a, &b) || !fac_g_hasedge(directed, &b, &a))
    return fail("removeArc must remove only the requested direction");
  fac_g_removeedge(directed, &b, &a);
  if (fac_g_hasedge(directed, &b, &a)) return fail("removeEdge must remove both directions");
  fac_ds_free(directed);

  // Dijkstra's documented contract: weights must be finite and non-negative.
  void *weighted = fac_g_new(3, (int32_t)sizeof(int32_t));
  const int32_t p0 = 10, p1 = 11, p2 = 12;
  fac_g_addarc3(weighted, &p0, &p1, 2.0);
  fac_g_addarc3(weighted, &p1, &p2, 3.0);
  fac_g_addarc3(weighted, &p0, &p2, 20.0);
  FacList *shortest = static_cast<FacList *>(fac_g_shortest(weighted, &p0, &p2));
  if (!path_is(shortest, {p0, p1, p2})) return fail("Dijkstra returned the wrong non-negative shortest path");
  fac_list_free(shortest);
  const int32_t p3 = 13, p4 = 14;
  fac_g_addarc3(weighted, &p3, &p4, 1.2e299);
  shortest = static_cast<FacList *>(fac_g_shortest(weighted, &p3, &p4));
  if (!path_is(shortest, {p3, p4})) return fail("large finite path was mistaken for unreachable");
  fac_list_free(shortest);

  const int32_t badA = 100, badB = 101;
  int err = catch_fac([&] { fac_g_addarc3(weighted, &badA, &badB, -1.0); });
  if (err != 8) return fail("negative edge weight was not rejected as an Argument error");
  err = catch_fac([&] { fac_g_addarc3(weighted, &badA, &badB, std::numeric_limits<double>::quiet_NaN()); });
  if (err != 8) return fail("NaN edge weight was not rejected");
  err = catch_fac([&] { fac_g_addarc3(weighted, &badA, &badB, std::numeric_limits<double>::infinity()); });
  if (err != 8) return fail("infinite edge weight was not rejected");
  fac_ds_free(weighted);

  std::puts("PASS Graph geometric growth / hybrid high-degree index / directional mutation / Dijkstra weight contract");
  return 0;
}
