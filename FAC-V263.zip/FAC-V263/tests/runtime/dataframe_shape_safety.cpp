#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <string>
#include <vector>

static std::atomic<long long> g_fail_after{-1};
static bool should_fail_allocation() noexcept {
  long long current = g_fail_after.load(std::memory_order_relaxed);
  while (current >= 0) {
    if (current == 0) {
      if (g_fail_after.compare_exchange_weak(current, -1, std::memory_order_relaxed)) return true;
    } else if (g_fail_after.compare_exchange_weak(current, current - 1, std::memory_order_relaxed)) {
      return false;
    }
  }
  return false;
}
static void *test_new(std::size_t size) {
  if (should_fail_allocation()) throw std::bad_alloc();
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new(std::size_t size) { return test_new(size); }
void *operator new[](std::size_t size) { return test_new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

struct FacStr { char *data; int64_t len, cap, ncp, flags; };
// White-box mirror of the Runtime-owned opaque DataFrame layout, used only to
// inject inconsistent internal states into the central handle validator.
struct FacDataFrame {
  int64_t rows = 0, cols = 0;
  std::vector<double> values;
  std::vector<std::string> names;
  double at(int64_t r, int64_t c) const { return values[(size_t)(r * cols + c)]; }
};

extern "C" {
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
int64_t fac_dataframe_rows(void *);
int64_t fac_dataframe_cols(void *);
double fac_dataframe_get(void *, int32_t, FacStr *);
void *fac_dataframe_group_mean(void *, FacStr *, FacStr *);
void *fac_dataframe_group_sum(void *, FacStr *, FacStr *);
void *fac_dataframe_group_min(void *, FacStr *, FacStr *);
void *fac_dataframe_group_max(void *, FacStr *, FacStr *);
void *fac_dataframe_group_count(void *, FacStr *);
void fac_dataframe_free(void *);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL dataframe safety: %s\n", message);
  return 1;
}
static int checked_rows(void *frame) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    (void)fac_dataframe_rows(frame);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int checked_group(void *frame, FacStr *key, FacStr *value,
                         void *(*groupFn)(void *, FacStr *, FacStr *), void **out) {
  void *jumpBuffer[5]{};
  *out = nullptr;
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    *out = groupFn(frame, key, value);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static bool close_to(double actual, double expected) {
  return actual == expected;
}

int main() {
  // A valid empty frame is allowed; a non-empty frame must have exact storage.
  FacDataFrame empty;
  empty.rows = 0; empty.cols = 2; empty.names = {"x", "y"};
  if (fac_dataframe_rows(&empty) != 0 || fac_dataframe_cols(&empty) != 2)
    return fail("valid empty frame was rejected");

  FacDataFrame negative;
  negative.rows = -1; negative.cols = 1; negative.names = {"x"};
  if (checked_rows(&negative) != 18) return fail("negative row count was not rejected");

  FacDataFrame overflow;
  overflow.rows = 8'388'609; overflow.cols = 2; overflow.names = {"x", "y"};
  if (checked_rows(&overflow) != 8) return fail("element-count limit was not checked before storage access");

  FacDataFrame mismatch;
  mismatch.rows = 2; mismatch.cols = 2; mismatch.names = {"x", "y"};
  mismatch.values = {1.0, 2.0, 3.0};
  if (checked_rows(&mismatch) != 18) return fail("mismatched backing storage was not rejected");

  FacDataFrame tooManyColumns;
  tooManyColumns.rows = 0; tooManyColumns.cols = 16'777'217;
  if (checked_rows(&tooManyColumns) != 18) return fail("oversized zero-row schema was not rejected");

  FacDataFrame frame;
  frame.rows = 3; frame.cols = 2;
  frame.names = {"group", "value"};
  frame.values = {1.0, 10.0, 1.0, 20.0, 2.0, 30.0};
  FacStr *key = fac_str_from_chars("group", 5);
  FacStr *value = fac_str_from_chars("value", 5);
  if (!key || !value) return fail("create column names");

  void *mean = nullptr, *sum = nullptr, *minimum = nullptr, *maximum = nullptr, *count = nullptr;
  if (checked_group(&frame, key, value, fac_dataframe_group_mean, &mean) != 0 ||
      checked_group(&frame, key, value, fac_dataframe_group_sum, &sum) != 0 ||
      checked_group(&frame, key, value, fac_dataframe_group_min, &minimum) != 0 ||
      checked_group(&frame, key, value, fac_dataframe_group_max, &maximum) != 0) {
    fac_str_free(value); fac_str_free(key);
    return fail("group aggregation failed on valid input");
  }
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    count = fac_dataframe_group_count(&frame, key);
    fac_try_leave();
  } else {
    fac_str_free(value); fac_str_free(key);
    return fail("group count failed on valid input");
  }

  // The new accumulator implementation must preserve sorted group order and
  // exact mean/sum/min/max/count results.
  FacStr *meanName = fac_str_from_chars("mean_value", 10);
  FacStr *sumName = fac_str_from_chars("sum_value", 9);
  FacStr *minName = fac_str_from_chars("min_value", 9);
  FacStr *maxName = fac_str_from_chars("max_value", 9);
  FacStr *countName = fac_str_from_chars("count", 5);
  if (!meanName || !sumName || !minName || !maxName || !countName) return fail("create result names");
  if (fac_dataframe_rows(mean) != 2 || fac_dataframe_rows(count) != 2 ||
      !close_to(fac_dataframe_get(mean, 0, meanName), 15.0) ||
      !close_to(fac_dataframe_get(mean, 1, meanName), 30.0) ||
      !close_to(fac_dataframe_get(sum, 0, sumName), 30.0) ||
      !close_to(fac_dataframe_get(sum, 1, sumName), 30.0) ||
      !close_to(fac_dataframe_get(minimum, 0, minName), 10.0) ||
      !close_to(fac_dataframe_get(maximum, 1, maxName), 30.0) ||
      !close_to(fac_dataframe_get(count, 0, countName), 2.0) ||
      !close_to(fac_dataframe_get(count, 1, countName), 1.0))
    return fail("group aggregate values or sorted keys changed");

  fac_dataframe_free(count); fac_dataframe_free(maximum); fac_dataframe_free(minimum);
  fac_dataframe_free(sum); fac_dataframe_free(mean);
  fac_str_free(countName); fac_str_free(maxName); fac_str_free(minName);
  fac_str_free(sumName); fac_str_free(meanName);

  // Allocation failures during map growth and result construction must become
  // FAC Resource errors; no C++ exception may escape the C Runtime entry point.
  int injectedFailures = 0;
  for (long long failAt = 0; failAt < 24; ++failAt) {
    void *result = nullptr;
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = checked_group(&frame, key, value, fac_dataframe_group_mean, &result);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 0) fac_dataframe_free(result);
    else if (error == 5) ++injectedFailures;
    else return fail("allocation failure did not become a FAC Resource error");
    if (fac_dataframe_rows(&frame) != 3) return fail("allocation failure damaged source frame");
  }
  fac_str_free(value); fac_str_free(key);
  if (injectedFailures == 0) return fail("allocation-failure injection did not reach group allocations");
  std::puts("PASS DataFrame shape validation / bounded group storage / aggregate results / OOM translation");
  return 0;
}
