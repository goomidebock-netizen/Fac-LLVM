#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct Canvas;
struct FacFont;
int32_t fac_font_backend_available();
FacFont *fac_font_load(FacStr *, int32_t);
void fac_font_free(FacFont *);
void fac_str_free(FacStr *);
void fac_font_setsize(FacFont *, int32_t);
int32_t fac_font_size(FacFont *);
int32_t fac_font_isvector(FacFont *);
FacStr *fac_font_family(FacFont *);
int32_t fac_font_measure(FacFont *, FacStr *);
int32_t fac_font_height(FacFont *);
void fac_font_draw(Canvas *, FacFont *, int32_t, int32_t, FacStr *, int32_t);
Canvas *fac_gfx_create(int32_t, int32_t);
void fac_gfx_free(Canvas *);
void fac_gfx_clear(Canvas *, int32_t);
uint32_t fac_gfx_get(Canvas *, int32_t, int32_t);
}

static FacStr view(const char *s) {
  auto *p = const_cast<char *>(s);
  int64_t n = (int64_t)std::strlen(s);
  return FacStr{p,n,n,n,1};
}

int main(int argc, char **argv) {
  if (!fac_font_backend_available()) {
    std::puts("SKIP vector font backend unavailable");
    return 0;
  }
  if (argc < 2) {
    std::puts("SKIP no test font installed");
    return 0;
  }
  FacStr path = view(argv[1]);
  FacStr latin = view("FAC Typography 123");
  FacStr thai = view(u8"สวัสดี FAC ภาษาไทย และวรรณยุกต์");
  char invalidBytes[] = {char(0xC0), char(0xAF), 0};
  FacStr invalid = FacStr{invalidBytes,2,2,2,1};
  FacFont *font = fac_font_load(&path, 22);
  if (!font || !fac_font_isvector(font) || fac_font_size(font) != 22) {
    std::fprintf(stderr, "vector font creation/size failed\n");
    if (font) fac_font_free(font);
    return 1;
  }
  FacStr *family = fac_font_family(font);
  if (!family || !family->data || family->len <= 0) {
    std::fprintf(stderr, "font family lookup failed\n");
    fac_font_free(font);
    return 1;
  }
  int width22 = fac_font_measure(font, &latin);
  if (fac_font_measure(font, &invalid) != 0) {
    std::fprintf(stderr, "invalid UTF-8 measurement should return zero\n");
    fac_font_free(font); return 1;
  }
  int height22 = fac_font_height(font);
  if (width22 <= 0 || height22 <= 0) {
    std::fprintf(stderr, "font metrics are empty: %d x %d\n", width22, height22);
    fac_font_free(font);
    return 1;
  }
  fac_font_setsize(font, 36);
  int width36 = fac_font_measure(font, &latin);
  int height36 = fac_font_height(font);
  if (fac_font_size(font) != 36 || width36 <= width22 || height36 <= height22) {
    std::fprintf(stderr, "font resize metrics failed: %d/%d x %d/%d\n", width22,width36,height22,height36);
    fac_font_free(font);
    return 1;
  }

  Canvas *canvas = fac_gfx_create(420, 120);
  fac_gfx_clear(canvas, 0x101820);
  fac_font_draw(canvas, font, 8, 4, &thai, 0xF3F6FC);
  // Also render partly outside the upper-left edge to exercise clipped blending.
  fac_font_draw(canvas, font, -12, -8, &latin, 0x6EA8FE);
  int painted = 0;
  for (int y=0;y<120;y++) for (int x=0;x<420;x++)
    if (fac_gfx_get(canvas,x,y) != 0x101820) ++painted;
  if (painted < 100) {
    std::fprintf(stderr, "rasterization produced too few pixels: %d\n", painted);
    fac_gfx_free(canvas); fac_font_free(font); return 1;
  }

  // Repeated registration/loading must be safe and release both Pango objects.
  FacFont *second = fac_font_load(&path, 18);
  if (!second || fac_font_measure(second, &thai) <= 0) {
    std::fprintf(stderr, "repeated font load failed\n");
    if(second)fac_font_free(second);
    fac_gfx_free(canvas); fac_font_free(font); return 1;
  }
  fac_font_free(second);
  fac_gfx_free(canvas);
  std::printf("PASS vector font family=%.*s width=%d->%d height=%d->%d painted=%d\n",
              (int)family->len, family->data, width22,width36,height22,height36,painted);
  fac_str_free(family);
  fac_font_free(font);
  return 0;
}
