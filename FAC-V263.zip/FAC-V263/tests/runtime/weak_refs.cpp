#include <atomic>
#include <cassert>
#include <cstdint>
#include <thread>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *p);
void fac_obj_release(void *p);
void *fac_obj_weak(void *p);
void fac_obj_weak_retain(void *p);
void fac_obj_weak_release(void *p);
int32_t fac_obj_weak_alive(void *p);
void *fac_obj_weak_lock(void *p);
}

static std::atomic<int> finalized{0};
static std::atomic<int> dropped{0};
static void finalize_object(void *) { finalized.fetch_add(1, std::memory_order_relaxed); }
static void drop_object(void *) { dropped.fetch_add(1, std::memory_order_relaxed); }

static void *make_object() {
  return fac_obj_new(8, reinterpret_cast<void *>(drop_object), nullptr,
                     nullptr, reinterpret_cast<void *>(finalize_object));
}

int main() {
  void *object = make_object();
  assert(object);
  void *weak = fac_obj_weak(object);
  assert(weak && fac_obj_weak_alive(weak) == 1);

  // A weak lock creates a strong reference that keeps the object alive.
  void *locked = fac_obj_weak_lock(weak);
  assert(locked == object);
  fac_obj_release(object);
  assert(fac_obj_weak_alive(weak) == 1);
  assert(finalized.load() == 0 && dropped.load() == 0);

  // The last strong release expires all weak handles before finalization.
  fac_obj_release(locked);
  assert(fac_obj_weak_alive(weak) == 0);
  assert(fac_obj_weak_lock(weak) == nullptr);
  assert(finalized.load() == 1 && dropped.load() == 1);

  // Weak handles have independent reference counts and can be copied.
  fac_obj_weak_retain(weak);
  fac_obj_weak_release(weak);
  assert(fac_obj_weak_alive(weak) == 0);
  fac_obj_weak_release(weak);

  // A concurrent lock/release race must either obtain a strong reference or
  // observe expiration; it must never return an object after finalization.
  void *racing = make_object();
  void *racingWeak = fac_obj_weak(racing);
  std::atomic<bool> run{true};
  std::atomic<int> ready{0};
  std::vector<std::thread> workers;
  for (int i = 0; i < 4; ++i) {
    workers.emplace_back([&] {
      ready.fetch_add(1, std::memory_order_release);
      while (run.load(std::memory_order_acquire)) {
        if (void *p = fac_obj_weak_lock(racingWeak)) fac_obj_release(p);
      }
    });
  }
  while (ready.load(std::memory_order_acquire) != 4) std::this_thread::yield();
  for (int i = 0; i < 1000; ++i) std::this_thread::yield();
  fac_obj_release(racing);
  run.store(false, std::memory_order_release);
  for (auto &worker : workers) worker.join();
  assert(fac_obj_weak_alive(racingWeak) == 0);
  assert(fac_obj_weak_lock(racingWeak) == nullptr);
  assert(finalized.load() == 2 && dropped.load() == 2);
  fac_obj_weak_release(racingWeak);

  // Grow the lazy slot directory across several blocks, then force reuse of
  // thousands of slots. Generation-tagged old tokens must not alias new ones.
  constexpr int kSlotStress = 5000;
  std::vector<void *> slotObjects;
  std::vector<void *> oldTokens;
  slotObjects.reserve(kSlotStress);
  oldTokens.reserve(kSlotStress);
  for (int i = 0; i < kSlotStress; ++i) {
    void *o = make_object();
    void *w = fac_obj_weak(o);
    assert(o && w && fac_obj_weak_alive(w) == 1);
    slotObjects.push_back(o);
    oldTokens.push_back(w);
  }
  for (void *o : slotObjects) fac_obj_release(o);
  for (void *w : oldTokens) {
    assert(fac_obj_weak_alive(w) == 0);
    assert(fac_obj_weak_lock(w) == nullptr);
    fac_obj_weak_release(w);
  }
  for (int i = 0; i < kSlotStress; ++i) {
    void *o = make_object();
    void *w = fac_obj_weak(o);
    assert(o && w && fac_obj_weak_alive(w) == 1);
    assert(fac_obj_weak_alive(oldTokens[static_cast<size_t>(i)]) == 0);
    fac_obj_release(o);
    assert(fac_obj_weak_alive(w) == 0);
    fac_obj_weak_release(w);
  }

  // A live object with no weak handles still follows ordinary release.
  void *plain = make_object();
  fac_obj_release(plain);
  assert(finalized.load() == 3 + 2 * kSlotStress && dropped.load() == 3 + 2 * kSlotStress);
}
