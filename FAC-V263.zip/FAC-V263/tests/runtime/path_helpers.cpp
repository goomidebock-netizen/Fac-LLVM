// Cross-platform path helper contracts: lexical replacement is separator-aware, and symlink
// detection follows the link-status API (including dangling links) rather than target existence.
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

struct FacStr;
extern "C" {
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
FacStr *fac_path_change_extension(FacStr *, FacStr *);
FacStr *fac_path_with_name(FacStr *, FacStr *);
int32_t fac_path_component_count(FacStr *);
int32_t fac_path_is_symlink(FacStr *);
}
struct FacStrView { char *data; int64_t len; };

static FacStr *s(const std::string &v) { return fac_str_from_chars(v.data(), (int64_t)v.size()); }
static std::string value(FacStr *p) {
  auto *v = reinterpret_cast<FacStrView *>(p);
  std::string out(v->data, (size_t)v->len);
  fac_str_free(p);
  return out;
}
static bool eq(FacStr *p, const char *want) { return value(p) == want; }

int main() {
  FacStr *path = s("src/main.tar.gz"), *ext = s("cpp");
  bool ok = eq(fac_path_change_extension(path, ext), "src/main.tar.cpp");
  fac_str_free(path); fac_str_free(ext);
  path = s(".config"); ext = s("json");
  ok = ok && eq(fac_path_change_extension(path, ext), ".config.json");
  fac_str_free(path); fac_str_free(ext);
  path = s("folder/"); ext = s("txt");
  ok = ok && eq(fac_path_change_extension(path, ext), "folder/");
  fac_str_free(path); fac_str_free(ext);
  path = s("C:\\work\\main.fac"); FacStr *name = s("app.cpp");
  ok = ok && eq(fac_path_with_name(path, name), "C:\\work\\app.cpp");
  fac_str_free(path); fac_str_free(name);
  path = s("folder/"); name = s("item.txt");
  ok = ok && eq(fac_path_with_name(path, name), "folder/item.txt");
  fac_str_free(path); fac_str_free(name);
  path = s("/usr//local/../bin"); ok = ok && fac_path_component_count(path) == 4; fac_str_free(path);
  path = s(""); ok = ok && fac_path_component_count(path) == 0 && !fac_path_is_symlink(path); fac_str_free(path);

  char dir[] = "/tmp/fac-path-test-XXXXXX";
  if (!mkdtemp(dir)) return 10;
  std::string target = std::string(dir) + "/target", link = std::string(dir) + "/dangling";
  FILE *f = fopen(target.c_str(), "wb"); if (!f) return 11; fclose(f);
  if (symlink(target.c_str(), link.c_str()) != 0) return 12;
  path = s(link); ok = ok && fac_path_is_symlink(path); fac_str_free(path);
  path = s(target); ok = ok && !fac_path_is_symlink(path); fac_str_free(path);
  unlink(link.c_str()); unlink(target.c_str()); rmdir(dir);
  if (!ok) { std::fprintf(stderr, "path helper contract failed\n"); return 1; }
  std::puts("PASS path helpers: extension, name, components, symlink status");
  return 0;
}
