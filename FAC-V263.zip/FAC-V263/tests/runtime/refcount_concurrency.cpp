#include <atomic>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <thread>
#include <vector>

extern "C" {
struct FacStr;
FacStr *fac_str_from_chars(const char *p, int64_t n);
FacStr *fac_str_dup(FacStr *s);
void fac_str_free(FacStr *s);
void *fac_alloc(int64_t n);
void fac_obj_retain(void *p);
void fac_obj_release(void *p);
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
uint64_t fac_obj_live_count();
void fac_obj_weak_retain(void *p);
void fac_obj_weak_release(void *p);
void *fac_obj_weak(void *p);
void *fac_obj_weak_lock(void *p);
void fac_closure_retain(void *p);
void fac_closure_release(void *p);
}

struct ClosureHeader { void *fn; int64_t refs; void (*drop)(void *); };
static std::atomic<int> g_closure_drops{0};
static void closure_drop(void *) { g_closure_drops.fetch_add(1, std::memory_order_relaxed); }

int main() {
  constexpr int kThreads = 24;
  constexpr int kRounds = 400;

  // Atomic immutable-string refcounts: each worker owns a distinct duplicated
  // reference; concurrent final releases must free the shared string once.
  FacStr *s = fac_str_from_chars("concurrent managed string", 25);
  assert(s);
  std::vector<FacStr *> stringRefs;
  for (int i = 0; i < kThreads; ++i) stringRefs.push_back(fac_str_dup(s));
  std::vector<std::thread> workers;
  std::atomic<bool> releaseStrings{false};
  for (FacStr *owned : stringRefs) workers.emplace_back([owned, &releaseStrings] {
    while (!releaseStrings.load(std::memory_order_acquire)) std::this_thread::yield();
    fac_str_free(owned);
  });
  releaseStrings.store(true, std::memory_order_release);
  for (auto &t : workers) t.join();
  fac_str_free(s);

  // Managed object references serialize registry and refcount transitions.
  const uint64_t before = fac_obj_live_count();
  void *obj = fac_obj_new(16, nullptr, nullptr, nullptr, nullptr);
  assert(obj && fac_obj_live_count() == before + 1);
  for (int i = 0; i < kThreads; ++i) fac_obj_retain(obj);
  workers.clear();
  std::atomic<bool> releaseObjects{false};
  for (int i = 0; i < kThreads; ++i) workers.emplace_back([obj, &releaseObjects] {
    while (!releaseObjects.load(std::memory_order_acquire)) std::this_thread::yield();
    fac_obj_release(obj);
  });
  releaseObjects.store(true, std::memory_order_release);
  for (auto &t : workers) t.join();
  assert(fac_obj_live_count() == before + 1);
  fac_obj_release(obj);
  assert(fac_obj_live_count() == before);

  // Weak-lock races against object destruction: every successful lock creates
  // a strong reference which the worker releases before exiting.
  obj = fac_obj_new(8, nullptr, nullptr, nullptr, nullptr);
  void *weak = fac_obj_weak(obj);
  assert(weak);
  for (int i = 0; i < kThreads; ++i) fac_obj_weak_retain(weak);
  std::atomic<bool> start{false};
  workers.clear();
  for (int i = 0; i < kThreads; ++i) {
    workers.emplace_back([weak, &start] {
      while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
      for (int j = 0; j < kRounds; ++j) {
        void *locked = fac_obj_weak_lock(weak);
        if (locked) fac_obj_release(locked);
      }
      fac_obj_weak_release(weak);
    });
  }
  start.store(true, std::memory_order_release);
  fac_obj_release(obj);
  for (auto &t : workers) t.join();
  fac_obj_weak_release(weak);
  assert(fac_obj_live_count() == before);

  // Closure refs use atomic CAS independently of the object registry.
  auto *cl = static_cast<ClosureHeader *>(fac_alloc(sizeof(ClosureHeader)));
  assert(cl);
  cl->fn = nullptr; cl->refs = 1; cl->drop = closure_drop;
  for (int i = 0; i < kThreads; ++i) fac_closure_retain(cl);
  workers.clear();
  std::atomic<bool> releaseClosures{false};
  for (int i = 0; i < kThreads; ++i) workers.emplace_back([cl, &releaseClosures] {
    while (!releaseClosures.load(std::memory_order_acquire)) std::this_thread::yield();
    fac_closure_release(cl);
  });
  releaseClosures.store(true, std::memory_order_release);
  for (auto &t : workers) t.join();
  fac_closure_release(cl);
  assert(g_closure_drops.load(std::memory_order_relaxed) == 1);

  return 0;
}
