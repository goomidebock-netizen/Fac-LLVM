#include <cstdint>
#include <cstdio>
#include <new>
#include <stdexcept>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void *fac_obj_weak(void *object);
int32_t fac_obj_weak_alive(void *weak);
void fac_obj_weak_release(void *weak);
void fac_cycle_visit(void *object);
int64_t fac_obj_collect_cycles();
uint64_t fac_obj_live_count();
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
[[noreturn]] void fac_throw(void *message, int32_t code);
}

struct GraphNode {
  std::vector<void *> edges;
  int id = 0;
};

static std::vector<void *> g_weakHandles;
static int g_finalized = 0;
static int g_dropped = 0;
static int g_traceCalls = 0;
static int g_weakCheckFailures = 0;
static int g_reentrantFailures = 0;
static int g_reenterFromFinalizer = 0;
static int g_checkAllWeakExpired = 0;
static int g_throwTraceOnce = 0;
static int g_throwTraceFacOnce = 0;

static void traceNode(void *opaque) {
  ++g_traceCalls;
  if (g_throwTraceOnce) {
    g_throwTraceOnce = 0;
    throw std::runtime_error("injected cycle trace failure");
  }
  if (g_throwTraceFacOnce) {
    g_throwTraceFacOnce = 0;
    fac_throw(nullptr, 31);
  }
  auto *node = static_cast<GraphNode *>(opaque);
  for (void *child : node->edges) fac_cycle_visit(child);
}

static void dropNode(void *opaque) {
  auto *node = static_cast<GraphNode *>(opaque);
  for (void *child : node->edges) fac_obj_release(child);
  node->edges.clear();
  node->~GraphNode();
  ++g_dropped;
}

static void finalizeNode(void *) {
  ++g_finalized;
  if (g_checkAllWeakExpired) {
    for (void *weak : g_weakHandles)
      if (fac_obj_weak_alive(weak) != 0) ++g_weakCheckFailures;
  }
  if (g_reenterFromFinalizer && fac_obj_collect_cycles() != 0)
    ++g_reentrantFailures;
}

static GraphNode *makeNode(int id) {
  void *storage = fac_obj_new(static_cast<int64_t>(sizeof(GraphNode)),
      reinterpret_cast<void *>(dropNode), nullptr,
      reinterpret_cast<void *>(traceNode), reinterpret_cast<void *>(finalizeNode));
  if (!storage) return nullptr;
  auto *node = new (storage) GraphNode;
  node->id = id;
  void *weak = fac_obj_weak(node);
  if (!weak) return nullptr;
  g_weakHandles.push_back(weak);
  return node;
}

static void linkNode(GraphNode *from, GraphNode *to) {
  from->edges.push_back(to);
  fac_obj_retain(to);
}

static void resetObservations() {
  g_finalized = 0;
  g_dropped = 0;
  g_traceCalls = 0;
  g_weakCheckFailures = 0;
  g_reentrantFailures = 0;
  g_reenterFromFinalizer = 0;
  g_checkAllWeakExpired = 0;
  g_throwTraceOnce = 0;
  g_throwTraceFacOnce = 0;
}

static void releaseWeakHandles() {
  for (void *weak : g_weakHandles) fac_obj_weak_release(weak);
  g_weakHandles.clear();
}

static int catchCollect(int &code, int64_t &result) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    result = fac_obj_collect_cycles();
    fac_try_leave();
    code = 0;
    return 0;
  }
  code = fac_err_code();
  return 1;
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  const uint64_t initialLive = fac_obj_live_count();

  // A trace callback exception must leave the graph untouched and release the
  // collector's reentrancy flag so a second collection can recover normally.
  resetObservations();
  GraphNode *self = makeNode(1);
  if (!self) return fail("self-cycle allocation failed");
  linkNode(self, self);
  void *selfWeak = g_weakHandles.front();
  fac_obj_release(self); // leave only the self-edge
  g_throwTraceOnce = 1;
  int errorCode = 0;
  int64_t collected = -1;
  if (!catchCollect(errorCode, collected) || errorCode != 7)
    return fail("C++ trace exception was not translated into a Runtime error");
  if (fac_obj_live_count() != initialLive + 1 || fac_obj_weak_alive(selfWeak) != 1 ||
      g_finalized != 0 || g_dropped != 0)
    return fail("failed graph snapshot modified object liveness or ran finalizers");
  g_checkAllWeakExpired = 1;
  g_reenterFromFinalizer = 1;
  if (fac_obj_collect_cycles() != 1)
    return fail("collector did not recover after a trace callback exception");
  if (g_finalized != 1 || g_dropped != 1 || g_weakCheckFailures != 0 || g_reentrantFailures != 0)
    return fail("self-cycle finalizer, weak expiry or reentrant-collection invariant failed");
  if (fac_obj_live_count() != initialLive || fac_obj_weak_alive(selfWeak) != 0)
    return fail("self-cycle was not fully reclaimed");
  releaseWeakHandles();

  // A FAC longjmp from a trace callback must be caught locally. Otherwise it
  // skips the collector lock/state cleanup, and every subsequent collection
  // silently returns zero because the global in-progress flag stays set.
  resetObservations();
  self = makeNode(2);
  if (!self) return fail("FAC trace-failure self-cycle allocation failed");
  linkNode(self, self);
  selfWeak = g_weakHandles.front();
  fac_obj_release(self);
  g_throwTraceFacOnce = 1;
  if (!catchCollect(errorCode, collected) || errorCode != 31)
    return fail("FAC trace error was not preserved by the local collector boundary");
  if (fac_obj_weak_alive(selfWeak) != 1 || g_finalized != 0 || g_dropped != 0)
    return fail("FAC trace failure changed the graph before the snapshot completed");
  g_checkAllWeakExpired = 1;
  g_reenterFromFinalizer = 1;
  if (fac_obj_collect_cycles() != 1)
    return fail("collector did not recover after a FAC longjmp from a trace callback");
  if (g_finalized != 1 || g_dropped != 1 || g_weakCheckFailures != 0 || g_reentrantFailures != 0)
    return fail("FAC trace-failure recovery violated finalizer/drop or reentrancy rules");
  if (fac_obj_live_count() != initialLive || fac_obj_weak_alive(selfWeak) != 0)
    return fail("FAC trace-failure recovery did not reclaim the self-cycle");
  releaseWeakHandles();

  // Two disconnected strongly-connected components with duplicates and
  // self-edges: all peers must be unlinked before any finalizer runs.
  resetObservations();
  std::vector<GraphNode *> graph;
  constexpr int COMPONENTS = 4;
  constexpr int NODES_PER_COMPONENT = 7;
  for (int c = 0; c < COMPONENTS; ++c)
    for (int i = 0; i < NODES_PER_COMPONENT; ++i) {
      GraphNode *node = makeNode(c * NODES_PER_COMPONENT + i);
      if (!node) return fail("multi-component graph allocation failed");
      graph.push_back(node);
    }
  for (int c = 0; c < COMPONENTS; ++c) {
    const int start = c * NODES_PER_COMPONENT;
    for (int i = 0; i < NODES_PER_COMPONENT; ++i) {
      linkNode(graph[start + i], graph[start + ((i + 1) % NODES_PER_COMPONENT)]);
      // Add a second edge to a varying peer, including duplicates and self-edges.
      linkNode(graph[start + i], graph[start + ((i * 3 + 2) % NODES_PER_COMPONENT)]);
      if ((i % 2) == 0) linkNode(graph[start + i], graph[start + i]);
    }
  }
  for (GraphNode *node : graph) fac_obj_release(node); // only graph edges remain
  g_checkAllWeakExpired = 1;
  g_reenterFromFinalizer = 1;
  collected = fac_obj_collect_cycles();
  if (collected != COMPONENTS * NODES_PER_COMPONENT)
    return fail("collector did not reclaim every node in disconnected cyclic components");
  if (g_finalized != COMPONENTS * NODES_PER_COMPONENT ||
      g_dropped != COMPONENTS * NODES_PER_COMPONENT ||
      g_weakCheckFailures != 0 || g_reentrantFailures != 0)
    return fail("multi-component graph violated exactly-once, weak-expiry or reentrancy rules");
  if (fac_obj_live_count() != initialLive)
    return fail("multi-component graph left live objects behind");
  for (void *weak : g_weakHandles)
    if (fac_obj_weak_alive(weak) != 0) return fail("collected graph weak handle remained alive");
  releaseWeakHandles();

  // A genuine external root keeps a cycle and every object it reaches alive.
  // Releasing that root makes the remaining cycle collectible.
  resetObservations();
  GraphNode *root = makeNode(100);
  GraphNode *a = makeNode(101);
  GraphNode *b = makeNode(102);
  if (!root || !a || !b) return fail("rooted-cycle allocation failed");
  linkNode(a, b);
  linkNode(b, a);
  linkNode(root, a);
  void *rootWeak = g_weakHandles[0];
  fac_obj_release(a);
  fac_obj_release(b);
  if (fac_obj_collect_cycles() != 0)
    return fail("collector reclaimed a cycle reachable from an external root");
  if (fac_obj_live_count() != initialLive + 3 || g_finalized != 0 || g_dropped != 0)
    return fail("rooted graph was modified during conservative marking");
  fac_obj_release(root); // immediate root destruction removes the final external edge
  if (fac_obj_live_count() != initialLive + 2 || fac_obj_weak_alive(rootWeak) != 0)
    return fail("releasing the external root did not destroy it cleanly");
  g_checkAllWeakExpired = 1;
  g_reenterFromFinalizer = 1;
  if (fac_obj_collect_cycles() != 2)
    return fail("cycle was not reclaimed after its external root was released");
  if (g_finalized != 3 || g_dropped != 3 || g_weakCheckFailures != 0 || g_reentrantFailures != 0)
    return fail("rooted-cycle recovery violated finalizer/drop or weak-handle rules");
  if (fac_obj_live_count() != initialLive)
    return fail("rooted-cycle recovery left live objects behind");
  releaseWeakHandles();

  std::puts("PASS cycle graph topology, conservative roots, trace-failure recovery, weak expiry and reentrant collection");
  return 0;
}
