#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

// Deterministic C++ allocation-failure injection for Runtime STL containers.
// The failure is one-shot so FAC error reporting and post-failure assertions
// can allocate normally.
static std::atomic<long long> g_fail_after{-1};
static bool should_fail_allocation() noexcept {
  long long current = g_fail_after.load(std::memory_order_relaxed);
  while (current >= 0) {
    if (current == 0) {
      if (g_fail_after.compare_exchange_weak(current, -1, std::memory_order_relaxed)) return true;
    } else if (g_fail_after.compare_exchange_weak(current, current - 1, std::memory_order_relaxed)) {
      return false;
    }
  }
  return false;
}
static void *test_new(std::size_t size) {
  if (should_fail_allocation()) throw std::bad_alloc();
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new(std::size_t size) { return test_new(size); }
void *operator new[](std::size_t size) { return test_new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

extern "C" {
void *fac_hm_new(int32_t, int32_t, int32_t, int32_t);
void fac_hm_set(void *, const void *, const void *);
void fac_hm_remove(void *, const void *);
void fac_hm_get(void *, const void *, void *);
int32_t fac_hm_has(void *, const void *);
void *fac_g_new(int32_t, int32_t);
void fac_g_addnode(void *, const void *);
void fac_g_addedge2(void *, const void *, const void *);
void fac_g_addarc2(void *, const void *, const void *);
int32_t fac_g_hasedge(void *, const void *, const void *);
struct FacStr;
FacStr *fac_str_from_chars(const char *, int64_t);
int32_t fac_str_cmp(FacStr *, FacStr *);
void fac_str_free(FacStr *);
void fac_ds_free(void *);
int64_t fac_ds_len(void *);
void *fac_ds_copy(void *);
void fac_try_enter(void *);
void fac_try_leave();
int32_t fac_err_code();
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}
static int try_hm_set(void *map, const void *key, const void *value) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fac_hm_set(map, key, value);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int try_graph_addnode(void *graph, const void *key) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fac_g_addnode(graph, key);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int try_graph_addedge(void *graph, const void *a, const void *b) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fac_g_addedge2(graph, a, b);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int try_graph_addarc(void *graph, const void *a, const void *b) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fac_g_addarc2(graph, a, b);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int try_ds_copy(void *source, void **result) {
  void *jumpBuffer[5]{};
  *result = nullptr;
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    *result = fac_ds_copy(source);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

int main() {
  const int32_t key = 17, value = 91;
  int insertFailures = 0;
  bool insertEventuallySucceeded = false;
  for (long long failAt = 0; failAt < 16; ++failAt) {
    void *map = fac_hm_new(3, (int32_t)sizeof(key), 3, (int32_t)sizeof(value));
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = try_hm_set(map, &key, &value);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++insertFailures;
      if (fac_hm_has(map, &key)) return fail("HashMap published an entry after failed index allocation");
      // A failed insertion must leave the same map usable for a retry.
      fac_hm_set(map, &key, &value);
    } else if (error == 0) {
      insertEventuallySucceeded = true;
    } else return fail("HashMap insertion returned a non-Resource error");
    if (!fac_hm_has(map, &key)) return fail("HashMap retry/success lost its key");
    int32_t got = 0;
    fac_hm_get(map, &key, &got);
    if (got != value) return fail("HashMap retry/success stored the wrong value");
    fac_ds_free(map);
    if (insertEventuallySucceeded) break;
  }
  if (!insertEventuallySucceeded || insertFailures < 1)
    return fail("HashMap insertion fault points were not exercised");

  // Replacing an existing managed blob must allocate the new value first;
  // an OOM must preserve the old bytes rather than free them prematurely.
  const int64_t wideKey = 0x12345678;
  unsigned char oldValue[64], newValue[64], readBack[64];
  std::memset(oldValue, 0x31, sizeof oldValue);
  std::memset(newValue, 0x72, sizeof newValue);
  void *wideMap = fac_hm_new(4, (int32_t)sizeof(wideKey), 4, (int32_t)sizeof(oldValue));
  fac_hm_set(wideMap, &wideKey, oldValue);
  g_fail_after.store(0, std::memory_order_relaxed);
  const int updateError = try_hm_set(wideMap, &wideKey, newValue);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (updateError != 5) return fail("HashMap replacement did not translate OOM to FAC Resource error");
  std::memset(readBack, 0, sizeof readBack);
  fac_hm_get(wideMap, &wideKey, readBack);
  if (std::memcmp(readBack, oldValue, sizeof oldValue) != 0)
    return fail("HashMap replacement lost the previous value after OOM");
  fac_ds_free(wideMap);

  // Fail after the flat index allocation but before item publication, so the
  // pending managed key/value references must be released during rollback.
  void *stringMap = fac_hm_new(14, 8, 14, 8);
  FacStr *stringKey = fac_str_from_chars("fault-key", 9);
  FacStr *stringValue = fac_str_from_chars("owned-value", 11);
  g_fail_after.store(1, std::memory_order_relaxed);
  const int stringInsertError = try_hm_set(stringMap, &stringKey, &stringValue);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (stringInsertError != 5 || fac_hm_has(stringMap, &stringKey))
    return fail("HashMap managed-key insertion did not roll back after OOM");
  fac_hm_set(stringMap, &stringKey, &stringValue);
  fac_str_free(stringKey); fac_str_free(stringValue);
  stringKey = fac_str_from_chars("fault-key", 9);
  FacStr *stringResult = nullptr;
  fac_hm_get(stringMap, &stringKey, &stringResult);
  FacStr *stringExpected = fac_str_from_chars("owned-value", 11);
  if (!stringResult || fac_str_cmp(stringResult, stringExpected) != 0)
    return fail("HashMap managed-key retry lost its string value");
  fac_str_free(stringExpected); fac_str_free(stringKey);
  fac_ds_free(stringMap);

  // HashMap tombstone compaction is optional: allocation failure must leave
  // the old flat index and all remaining entries intact.
  void *compactMap = fac_hm_new(3, (int32_t)sizeof(int32_t), 3, (int32_t)sizeof(int32_t));
  constexpr int COMPACT_COUNT = 40;
  for (int32_t i = 0; i < COMPACT_COUNT; ++i) { int32_t v = i + 100; fac_hm_set(compactMap, &i, &v); }
  for (int32_t i = 0; i < 20; ++i) fac_hm_remove(compactMap, &i);
  int32_t triggerCompact = 20;
  g_fail_after.store(0, std::memory_order_relaxed);
  fac_hm_remove(compactMap, &triggerCompact); // force replacement-index allocation to fail
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (fac_ds_len(compactMap) != 19) return fail("HashMap erase failed to complete when optional compaction ran out of memory");
  for (int32_t i = 0; i <= 20; ++i)
    if (fac_hm_has(compactMap, &i)) return fail("HashMap failed compaction resurrected a removed key");
  for (int32_t i = 21; i < COMPACT_COUNT; ++i) {
    if (!fac_hm_has(compactMap, &i)) return fail("HashMap failed compaction damaged a live index view");
    int32_t actual = 0, expected = i + 100;
    fac_hm_get(compactMap, &i, &actual);
    if (actual != expected) return fail("HashMap failed compaction damaged a live value");
  }
  int32_t secondRemove = 21;
  fac_hm_remove(compactMap, &secondRemove); // successful compaction path
  if (fac_ds_len(compactMap) != 18) return fail("HashMap successful compaction has an incorrect size");
  for (int32_t i = 22; i < COMPACT_COUNT; ++i)
    if (!fac_hm_has(compactMap, &i)) return fail("HashMap successful compaction lost a live key");
  fac_ds_free(compactMap);

  // Each failed Graph node publication must leave nodes/alive/adj/index aligned.
  int graphInsertFailures = 0;
  bool graphInsertSucceeded = false;
  const int32_t nodeKey = 23;
  for (long long failAt = 0; failAt < 16; ++failAt) {
    void *graph = fac_g_new(3, (int32_t)sizeof(nodeKey));
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = try_graph_addnode(graph, &nodeKey);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++graphInsertFailures;
      if (fac_ds_len(graph) != 0) return fail("Graph exposed a partial node after allocation failure");
      fac_g_addnode(graph, &nodeKey);
    } else if (error == 0) {
      graphInsertSucceeded = true;
    } else return fail("Graph node insertion returned a non-Resource error");
    if (fac_ds_len(graph) != 1) return fail("Graph retry/success produced an invalid node count");
    fac_ds_free(graph);
    if (graphInsertSucceeded) break;
  }
  if (!graphInsertSucceeded || graphInsertFailures < 2)
    return fail("Graph node insertion fault points were not exercised");

  // An edge request that creates endpoints is one transaction: failures while
  // preparing the second endpoint or either adjacency must remove new nodes.
  int edgeTransactionFailures = 0;
  bool edgeTransactionSucceeded = false;
  const int32_t a = 1, b = 2;
  for (long long failAt = 0; failAt < 128; ++failAt) {
    void *candidate = fac_g_new(3, (int32_t)sizeof(int32_t));
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = try_graph_addedge(candidate, &a, &b);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++edgeTransactionFailures;
      if (fac_ds_len(candidate) != 0)
        return fail("failed Graph edge left a newly-created endpoint behind");
      fac_g_addedge2(candidate, &a, &b);
    } else if (error == 0) {
      edgeTransactionSucceeded = true;
    } else return fail("Graph edge transaction returned a non-Resource error");
    if (fac_ds_len(candidate) != 2 || !fac_g_hasedge(candidate, &a, &b) ||
        !fac_g_hasedge(candidate, &b, &a))
      return fail("Graph edge retry/success did not create two endpoints and symmetric edges");
    fac_ds_free(candidate);
    if (edgeTransactionSucceeded) break;
  }
  if (!edgeTransactionSucceeded || edgeTransactionFailures < 3)
    return fail("Graph edge transaction fault points were not exercised");

  // Force the second adjacency reserve to fail. No half-undirected edge may
  // become visible, and a later retry must add both directions.
  void *graph = fac_g_new(3, (int32_t)sizeof(int32_t));
  fac_g_addnode(graph, &a);
  fac_g_addnode(graph, &b);
  g_fail_after.store(1, std::memory_order_relaxed);
  const int edgeError = try_graph_addedge(graph, &a, &b);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (edgeError != 5) return fail("Graph edge reserve did not report injected OOM");
  if (fac_g_hasedge(graph, &a, &b) || fac_g_hasedge(graph, &b, &a))
    return fail("Graph published only one side of a failed undirected edge");
  fac_g_addedge2(graph, &a, &b);
  if (!fac_g_hasedge(graph, &a, &b) || !fac_g_hasedge(graph, &b, &a))
    return fail("Graph retry did not create a symmetric undirected edge");
  fac_ds_free(graph);

  // Crossing the high-degree threshold builds a secondary neighbor index.
  // Inject failure into that construction and into subsequent hash inserts;
  // failed calls must not publish either the adjacency or a stale index entry.
  int highDegreeFailures = 0;
  bool highDegreeSucceeded = false;
  const int32_t hub = -1000, target = 1000, baseCount = 47;
  for (long long failAt = 0; failAt < 128; ++failAt) {
    void *candidate = fac_g_new(3, (int32_t)sizeof(int32_t));
    fac_g_addnode(candidate, &hub);
    for (int32_t i = 0; i < baseCount; ++i) {
      fac_g_addarc2(candidate, &hub, &i);
    }
    fac_g_addnode(candidate, &target);
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = try_graph_addarc(candidate, &hub, &target);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++highDegreeFailures;
      if (fac_g_hasedge(candidate, &hub, &target))
        return fail("failed high-degree index construction published an edge");
      for (int32_t i = 0; i < baseCount; ++i)
        if (!fac_g_hasedge(candidate, &hub, &i))
          return fail("failed high-degree index construction damaged an existing edge");
      fac_g_addarc2(candidate, &hub, &target);
    } else if (error == 0) {
      highDegreeSucceeded = true;
    } else return fail("high-degree index insertion returned a non-Resource error");
    if (!fac_g_hasedge(candidate, &hub, &target))
      return fail("high-degree index retry/success lost its edge");
    fac_ds_free(candidate);
    if (highDegreeSucceeded) break;
  }
  if (!highDegreeSucceeded || highDegreeFailures < 2)
    return fail("high-degree index allocation failure points were not exercised");

  // A failed string-key node insertion must release its retained FacStr handle.
  graph = fac_g_new(14, 8);
  FacStr *graphKey = fac_str_from_chars("graph-key", 9);
  g_fail_after.store(3, std::memory_order_relaxed);
  const int graphStringError = try_graph_addnode(graph, &graphKey);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (graphStringError != 5 || fac_ds_len(graph) != 0)
    return fail("Graph string-key insertion did not roll back its managed handle");
  fac_g_addnode(graph, &graphKey);
  fac_str_free(graphKey);
  fac_ds_free(graph);

  // Clone allocation failures must clean a partially built copy while leaving
  // the original graph untouched. The copy succeeds once the injected point
  // moves past all clone allocations.
  graph = fac_g_new(3, (int32_t)sizeof(int32_t));
  constexpr int NODE_COUNT = 48;
  for (int32_t i = 0; i < NODE_COUNT; ++i) fac_g_addnode(graph, &i);
  for (int32_t i = 1; i < NODE_COUNT; ++i) {
    int32_t prev = i - 1;
    fac_g_addedge2(graph, &prev, &i);
  }
  int cloneFailures = 0;
  bool cloneSucceeded = false;
  for (long long failAt = 0; failAt < 128; ++failAt) {
    void *copy = nullptr;
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = try_ds_copy(graph, &copy);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++cloneFailures;
      if (copy != nullptr) return fail("failed Graph clone returned a partial object");
      if (fac_ds_len(graph) != NODE_COUNT) return fail("failed Graph clone modified its source");
    } else if (error == 0) {
      cloneSucceeded = true;
      if (!copy || fac_ds_len(copy) != NODE_COUNT) return fail("successful Graph clone has wrong node count");
      int32_t first = 0, second = 1;
      if (!fac_g_hasedge(copy, &first, &second) || !fac_g_hasedge(copy, &second, &first))
        return fail("successful Graph clone lost its edge data");
      fac_ds_free(copy);
      break;
    } else return fail("Graph clone returned a non-Resource error");
  }
  if (!cloneSucceeded || cloneFailures < 2) return fail("Graph clone fault points were not exercised");
  fac_ds_free(graph);

  // HashMap clone uses the same transactional insertion path.
  void *largeMap = fac_hm_new(3, (int32_t)sizeof(int32_t), 3, (int32_t)sizeof(int32_t));
  for (int32_t i = 0; i < NODE_COUNT; ++i) { int32_t v = i * 7; fac_hm_set(largeMap, &i, &v); }
  int mapCloneFailures = 0;
  bool mapCloneSucceeded = false;
  for (long long failAt = 0; failAt < 128; ++failAt) {
    void *copy = nullptr;
    g_fail_after.store(failAt, std::memory_order_relaxed);
    const int error = try_ds_copy(largeMap, &copy);
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 5) {
      ++mapCloneFailures;
      if (copy != nullptr || fac_ds_len(largeMap) != NODE_COUNT)
        return fail("failed HashMap clone damaged its source or returned a partial object");
    } else if (error == 0) {
      mapCloneSucceeded = true;
      if (!copy || fac_ds_len(copy) != NODE_COUNT) return fail("successful HashMap clone has wrong size");
      fac_ds_free(copy);
      break;
    } else return fail("HashMap clone returned a non-Resource error");
  }
  if (!mapCloneSucceeded || mapCloneFailures < 2) return fail("HashMap clone fault points were not exercised");
  fac_ds_free(largeMap);

  std::puts("PASS allocation-failure rollback: HashMap insert/update/clone and Graph node/edge/clone");
  return 0;
}
