// Verify sync.Channel recv keeps a queued message when its result-buffer allocation fails.
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>

extern "C" void *__real_malloc(std::size_t);
extern "C" void *__wrap_malloc(std::size_t size);
extern "C" void *fac_sync_chan_new(int32_t);
extern "C" int32_t fac_sync_chan_send(void *, const char *, int32_t);
extern "C" char *fac_sync_chan_recv(void *, int32_t);
extern "C" void fac_sync_str_free(char *);
extern "C" int32_t fac_sync_chan_len(void *);
extern "C" void fac_sync_chan_free(void *);

static std::atomic<bool> failNextAllocation{false};
extern "C" void *__wrap_malloc(std::size_t size) {
  if (failNextAllocation.exchange(false, std::memory_order_relaxed)) return nullptr;
  return __real_malloc(size);
}

int main() {
  void *channel = fac_sync_chan_new(2);
  if (!channel || fac_sync_chan_send(channel, "preserve-me", 0) != 1) {
    std::fprintf(stderr, "FAIL: could not prepare channel message\n");
    return 1;
  }

  failNextAllocation.store(true, std::memory_order_relaxed);
  char *failed = fac_sync_chan_recv(channel, 0);
  if (failed != nullptr) {
    std::fprintf(stderr, "FAIL: injected result allocation unexpectedly succeeded\n");
    fac_sync_str_free(failed);
    fac_sync_chan_free(channel);
    return 1;
  }
  if (fac_sync_chan_len(channel) != 1) {
    std::fprintf(stderr, "FAIL: queued message was removed after allocation failure\n");
    fac_sync_chan_free(channel);
    return 1;
  }

  char *retried = fac_sync_chan_recv(channel, 0);
  const bool ok = retried && std::strcmp(retried, "preserve-me") == 0 && fac_sync_chan_len(channel) == 0;
  if (retried) fac_sync_str_free(retried);
  fac_sync_chan_free(channel);
  if (!ok) {
    std::fprintf(stderr, "FAIL: preserved message could not be received on retry\n");
    return 1;
  }
  std::puts("PASS sync.Channel preserves queued message when recv allocation fails");
  return 0;
}
