#include <cstdint>
#include <cstdio>
#include <cstring>
#include <climits>
#include <string>

extern "C" {
void fac_oob(int64_t, int64_t);
void fac_sort(void *, int64_t, int32_t);
void fac_sort_cmp(void *, int64_t, int64_t, void *, int32_t (*)(void *, const void *, const void *));
void fac_reverse(void *, int64_t, int32_t);
void fac_fill(void *, int64_t, int32_t, const void *);
int32_t fac_find(void *, int64_t, int32_t, int32_t, const void *);
}

static int32_t cmp_throw(void *, const void *, const void *) { fac_oob(7, 3); return 0; }

static int32_t cmp_i32_desc(void *, const void *a, const void *b) {
  const int32_t x = *static_cast<const int32_t *>(a);
  const int32_t y = *static_cast<const int32_t *>(b);
  return x > y ? -1 : x < y ? 1 : 0;
}

int main(int argc, char **argv) {
  if (argc > 1 && std::strcmp(argv[1], "overflow") == 0) {
    int32_t one = 1;
    fac_sort_cmp(&one, INT64_MAX, 8, nullptr, cmp_i32_desc);
    return 99;
  }
  if (argc > 1 && std::strcmp(argv[1], "negative") == 0) {
    int32_t one = 1;
    fac_reverse(&one, -1, 4);
    return 99;
  }
  if (argc > 1 && std::strcmp(argv[1], "throw-sort") == 0) {
    int32_t values[] = {3, 2, 1};
    fac_sort_cmp(values, 3, 4, nullptr, cmp_throw);
    return 99;
  }

  int32_t values[] = {5, 1, 4, 2, 3};
  fac_sort(values, 5, 3);
  for (int i = 0; i < 5; ++i) if (values[i] != i + 1) return 1;
  fac_reverse(values, 5, 4);
  for (int i = 0; i < 5; ++i) if (values[i] != 5 - i) return 2;

  // Fill must snapshot the source because it aliases the destination array.
  fac_fill(values, 5, 4, &values[2]);
  for (int32_t v : values) if (v != 3) return 3;

  int32_t custom[] = {2, 5, 1, 4, 3};
  fac_sort_cmp(custom, 5, 4, nullptr, cmp_i32_desc);
  const int32_t desc[] = {5, 4, 3, 2, 1};
  if (std::memcmp(custom, desc, sizeof(desc)) != 0) return 4;
  int32_t key = 3;
  if (fac_find(custom, 5, 4, 3, &key) != 2) return 5;
  int32_t missing = 42;
  if (fac_find(custom, 5, 4, 3, &missing) != -1) return 6;

  std::puts("PASS array sort/reverse/fill/find");
  return 0;
}
