#include <atomic>
#include <cstdint>
#include <cstdio>
#include <string>
#include <thread>
#include <vector>
#include <unistd.h>

extern "C" {
struct FacStr;
void *fac_gfx_create(int32_t w, int32_t h);
void fac_gfx_free(void *canvas);
int32_t fac_gfx_width(void *canvas);
int32_t fac_gfx_height(void *canvas);
void fac_gfx_clear(void *canvas, int32_t color);
void fac_gfx_pixel(void *canvas, int32_t x, int32_t y, int32_t color);
uint32_t fac_gfx_get(void *canvas, int32_t x, int32_t y);
void fac_gfx_fillrect(void *canvas, int32_t x, int32_t y, int32_t w, int32_t h, int32_t color);
void fac_gfx_line(void *canvas, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t color);
void fac_gfx_blend(void *canvas, int32_t x, int32_t y, int32_t color, int32_t alpha);
void fac_gfx_blit(void *dst, void *src, int32_t x, int32_t y);
void fac_gfx_blitkey(void *dst, void *src, int32_t x, int32_t y, int32_t key);
void fac_gfx_blitalpha(void *dst, void *src, int32_t x, int32_t y);
void fac_gfx_blitregion(void *dst, void *src, int32_t x, int32_t y,
                        int32_t sx, int32_t sy, int32_t sw, int32_t sh);
void fac_gfx_blitregionex(void *dst, void *src, int32_t x, int32_t y,
                          int32_t sx, int32_t sy, int32_t sw, int32_t sh, int32_t flags);
void fac_gfx_blitscaled(void *dst, void *src, int32_t x, int32_t y, int32_t w, int32_t h);
int32_t fac_gfx_hasalpha(void *canvas);
int32_t fac_gfx_alphaat(void *canvas, int32_t x, int32_t y);
void fac_gfx_bitmap_text(void *canvas, int32_t x, int32_t y, FacStr *text, int32_t color, int32_t scale);
FacStr *fac_str_from_chars(const char *data, int64_t size);
void fac_str_free(FacStr *value);
void fac_gfx_save(void *canvas, FacStr *path);
void fac_3d_begin(void *canvas, void *camera);
void fac_3d_point(void *canvas, void *camera, double x, double y, double z, int32_t color, int32_t size);
void *fac_3d_camera(double x, double y, double z, double yaw, double pitch, double fov);
void fac_3d_free(void *camera);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL canvas concurrency: %s\n", message);
  return 1;
}

int main() {
  void *a = fac_gfx_create(96, 96);
  void *b = fac_gfx_create(96, 96);
  if (!a || !b) return fail("canvas creation failed");
  if (fac_gfx_width(a) != 96 || fac_gfx_height(b) != 96)
    return fail("canvas dimension access failed");

  fac_gfx_clear(a, 0x102030);
  fac_gfx_clear(b, 0x405060);
  auto *text = fac_str_from_chars("FAC V216", 8);
  auto *path = fac_str_from_chars("/tmp/fac-v216-canvas-concurrency.ppm", 36);
  if (!text || !path) return fail("test string allocation failed");

  std::atomic<bool> start{false};
  std::atomic<bool> failed{false};
  std::vector<std::thread> workers;
  for (int worker = 0; worker < 8; ++worker) {
    workers.emplace_back([&, worker] {
      while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
      const int tx = (worker % 4) * 24;
      const int ty = (worker / 4) * 48;
      const int color = 0x102030 + (worker + 1) * 0x010101;
      for (int i = 0; i < 2500; ++i) {
        fac_gfx_fillrect(a, tx, ty, 24, 48, color);
        fac_gfx_pixel(a, tx + (i % 24), ty + (i % 48), color);
        fac_gfx_line(a, tx, ty + (i % 48), tx + 23, ty + (i % 48), color);
        fac_gfx_blend(a, tx + 12, ty + 24, 0xFFFFFF, 32);
        uint32_t pixel = fac_gfx_get(a, tx + 12, ty + 24);
        if (pixel > 0xFFFFFFu) failed.store(true, std::memory_order_relaxed);
      }
    });
  }

  // Reverse-direction blits deliberately contend for the same two handles.
  // A consistent lock order is not assumed; the runtime must use deadlock-safe
  // pair acquisition for every read-source/write-destination operation.
  workers.emplace_back([&] {
    while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
    for (int i = 0; i < 2500; ++i) {
      fac_gfx_blit(a, b, 0, 0);
      fac_gfx_blitregion(a, b, 8, 8, 0, 0, 64, 64);
      fac_gfx_blitregionex(a, b, 12, 12, 0, 0, 48, 48, i & 3);
      fac_gfx_blitkey(a, b, 16, 16, 0x405060);
    }
  });
  workers.emplace_back([&] {
    while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
    for (int i = 0; i < 2500; ++i) {
      fac_gfx_blit(b, a, 0, 0);
      fac_gfx_blitalpha(b, a, 4, 4);
      fac_gfx_blitscaled(b, a, 0, 0, 96, 96);
    }
  });

  // Same-handle overlap and 3D depth/pixel storage also share the Canvas lock.
  void *camera = fac_3d_camera(0, 0, 0, 0, 0, 70);
  workers.emplace_back([&] {
    while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
    for (int i = 0; i < 2000; ++i) {
      fac_gfx_blitregion(a, a, 1, 1, 0, 0, 64, 64);
      fac_3d_begin(a, camera);
      fac_3d_point(a, camera, (i % 20 - 10) * 0.1, 0, 5, 0xABCDEF, 3);
    }
  });
  workers.emplace_back([&] {
    while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
    for (int i = 0; i < 500; ++i) {
      fac_gfx_bitmap_text(a, 1, 1, text, 0xFFFFFF, 1);
      fac_gfx_save(a, path); // snapshot reads must not race with drawing/blit/depth updates
    }
  });

  start.store(true, std::memory_order_release);
  for (auto &worker : workers) worker.join();
  fac_3d_free(camera);

  if (failed.load(std::memory_order_relaxed)) return fail("pixel read returned an invalid value");
  if (fac_gfx_get(a, 0, 0) > 0xFFFFFFu || fac_gfx_get(b, 0, 0) > 0xFFFFFFu)
    return fail("final pixel value exceeded RGB range");
  if (fac_gfx_hasalpha(a) != 0 || fac_gfx_alphaat(a, 0, 0) != 255)
    return fail("opaque Canvas alpha metadata changed unexpectedly");

  fac_str_free(text);
  fac_str_free(path);
  fac_gfx_free(a);
  fac_gfx_free(b);
  std::remove("/tmp/fac-v216-canvas-concurrency.ppm");
  std::puts("PASS per-canvas drawing/read/save/depth synchronization and deadlock-safe cross-canvas blits");
  return 0;
}
