#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <thread>
#include <vector>

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct Canvas;
struct FacFont;
int32_t fac_font_backend_available();
FacFont *fac_font_load(FacStr *, int32_t);
void fac_font_free(FacFont *);
void fac_font_setsize(FacFont *, int32_t);
int32_t fac_font_size(FacFont *);
int32_t fac_font_isvector(FacFont *);
int32_t fac_font_measure(FacFont *, FacStr *);
int32_t fac_font_height(FacFont *);
void fac_font_draw(Canvas *, FacFont *, int32_t, int32_t, FacStr *, int32_t);
Canvas *fac_gfx_create(int32_t, int32_t);
void fac_gfx_free(Canvas *);
uint32_t fac_gfx_get(Canvas *, int32_t, int32_t);
void fac_gfx_system_text(Canvas *, int32_t, int32_t, FacStr *, int32_t, int32_t);
void fac_str_free(FacStr *);
}

static FacStr view(const char *s) {
  auto *p = const_cast<char *>(s);
  const int64_t n = (int64_t)std::strlen(s);
  return FacStr{p, n, n, n, 1};
}

int main(int argc, char **argv) {
  if (!fac_font_backend_available()) {
    std::puts("SKIP vector font backend unavailable");
    return 0;
  }
  if (argc < 2) {
    std::puts("SKIP no test font installed");
    return 0;
  }

  FacStr path = view(argv[1]);
  FacStr latin = view("Shared Pango Layout concurrency 0123456789");
  FacStr thai = view(u8"การทดสอบฟอนต์หลายเธรด FAC ภาษาไทย");
  FacFont *shared = fac_font_load(&path, 22);
  if (!shared || !fac_font_isvector(shared)) {
    std::fprintf(stderr, "FAIL shared vector font creation\n");
    if (shared) fac_font_free(shared);
    return 1;
  }

  constexpr int kThreads = 8;
  constexpr int kIterations = 180;
  std::atomic<int> ready{0};
  std::atomic<bool> start{false};
  std::atomic<int> failures{0};
  std::vector<std::thread> workers;
  workers.reserve(kThreads);

  for (int worker = 0; worker < kThreads; ++worker) {
    workers.emplace_back([&, worker] {
      // Concurrent first-use/font registration and creation exercise the
      // process-wide Fontconfig registry and Pango default font map.
      FacFont *local = fac_font_load(&path, 16 + (worker % 3) * 4);
      if (!local || fac_font_measure(local, &latin) <= 0) {
        failures.fetch_add(1, std::memory_order_relaxed);
        if (local) fac_font_free(local);
        return;
      }
      fac_font_free(local);

      Canvas *canvas = fac_gfx_create(360, 64);
      if (!canvas) {
        failures.fetch_add(1, std::memory_order_relaxed);
        return;
      }
      ready.fetch_add(1, std::memory_order_release);
      while (!start.load(std::memory_order_acquire)) std::this_thread::yield();

      for (int i = 0; i < kIterations; ++i) {
        // Mutating and reading the same opaque font handle is serialized by
        // the runtime; each operation is individually linearizable.
        if ((i + worker) % 29 == 0)
          fac_font_setsize(shared, ((i / 29 + worker) & 1) ? 20 : 30);
        const int width = fac_font_measure(shared, (i & 1) ? &latin : &thai);
        const int height = fac_font_height(shared);
        if (width <= 0 || height <= 0 || (fac_font_size(shared) < 1))
          failures.fetch_add(1, std::memory_order_relaxed);
        fac_font_draw(canvas, shared, 2, 2, (i & 1) ? &latin : &thai, 0xE8F0FF);
      }

      // Per-thread system text uses a TLS cache over the same process-wide
      // Pango backend. Its independent cached handles must coexist safely.
      fac_gfx_system_text(canvas, 2, 36, &latin, 0x80C0FF, 2);
      bool painted = false;
      for (int y = 0; y < 64 && !painted; ++y)
        for (int x = 0; x < 360; ++x)
          if (fac_gfx_get(canvas, x, y) != 0) { painted = true; break; }
      if (!painted) failures.fetch_add(1, std::memory_order_relaxed);
      fac_gfx_free(canvas);
    });
  }

  while (ready.load(std::memory_order_acquire) != kThreads &&
         failures.load(std::memory_order_relaxed) == 0)
    std::this_thread::yield();
  start.store(true, std::memory_order_release);
  for (auto &worker : workers) worker.join();

  fac_font_setsize(shared, 22);
  const int finalWidth = fac_font_measure(shared, &latin);
  const int finalHeight = fac_font_height(shared);
  fac_font_free(shared);
  if (failures.load(std::memory_order_relaxed) != 0 || finalWidth <= 0 || finalHeight <= 0) {
    std::fprintf(stderr, "FAIL vector font concurrency: failures=%d metrics=%d x %d\n",
                 failures.load(), finalWidth, finalHeight);
    return 1;
  }
  std::printf("PASS vector font shared-handle concurrency threads=%d iterations=%d\n",
              kThreads, kIterations);
  return 0;
}
