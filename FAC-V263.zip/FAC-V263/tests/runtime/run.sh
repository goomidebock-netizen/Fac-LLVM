#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
CXX=${CXX:-clang++}
mkdir -p build
# ทุกไฟล์ที่เทสต์สร้าง (binary, .out, .err) อยู่ในโฟลเดอร์ชั่วคราวของการรันนี้ ไม่เขียนทับไฟล์ค้างจากการรันครั้งก่อน
# (ไฟล์เก่าที่เจ้าของเป็นคนอื่น/อ่านอย่างเดียว เคยทำให้เกิด "Permission denied")
T=$(mktemp -d "build/rt-tests.XXXXXX")
trap 'rm -rf "$T"' EXIT
"$CXX" -std=c++17 -O2 -pthread tests/runtime/list_insert_alias.cpp build/fac_rt.o -lm -ldl -o $T/test_list_insert_alias
$T/test_list_insert_alias
# Partial list construction must release prior elements on FAC longjmp errors.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/list_error_cleanup.cpp build/fac_rt.o -lm -ldl -o $T/test_list_error_cleanup
$T/test_list_error_cleanup
"$CXX" -std=c++17 -O2 -pthread tests/runtime/finalizer_error_cleanup.cpp build/fac_rt.o -lm -ldl -o "$T/test_finalizer_error_cleanup"
"$T/test_finalizer_error_cleanup"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/object_registry_safety.cpp build/fac_rt.o -lm -ldl -o "$T/test_object_registry_safety"
"$T/test_object_registry_safety"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/array_ops.cpp build/fac_rt.o -lm -ldl -o $T/test_array_ops
$T/test_array_ops
"$CXX" -std=c++17 -O2 -pthread tests/runtime/rng_threads.cpp build/fac_rt.o -lm -ldl -o $T/test_rng_threads
$T/test_rng_threads
# TCP handles are stable opaque tokens; close waits for in-flight I/O and stale aliases never revive.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/socket_handle_concurrency.cpp build/fac_rt.o -lm -ldl -o "$T/test_socket_handle_concurrency"
"$T/test_socket_handle_concurrency"
# Opaque file tokens remain tombstones after close; per-handle locks serialize I/O/close.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/file_handle_lifetime.cpp build/fac_rt.o -lm -ldl -o "$T/test_file_handle_lifetime"
"$T/test_file_handle_lifetime"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/crypto_rng.cpp build/fac_rt.o -lm -ldl -o $T/test_crypto_rng
$T/test_crypto_rng
"$CXX" -std=c++17 -O2 -pthread tests/runtime/image_threads.cpp -o $T/test_image_threads
$T/test_image_threads
# Per-Canvas synchronization, cross-Canvas lock ordering, depth-buffer access and coherent save snapshots.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/canvas_concurrency.cpp build/fac_rt.o -lm -ldl -o "$T/test_canvas_concurrency"
"$T/test_canvas_concurrency"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/audio_threads.cpp build/fac_rt.o -lm -ldl -o $T/test_audio_threads
SDL_AUDIODRIVER=dummy $T/test_audio_threads
for mode in overflow negative throw-sort; do
  if $T/test_array_ops "$mode" >"$T/test_array_ops_$mode.out" 2>"$T/test_array_ops_$mode.err"; then
    echo "FAIL array_ops $mode should reject invalid dimensions"
    exit 1
  fi
  grep -Eq 'size overflow|cannot be negative|index out of range' "$T/test_array_ops_$mode.err" || {
    echo "FAIL array_ops $mode returned unexpected error"
    cat "$T/test_array_ops_$mode.err"
    exit 1
  }
done
# Flat HashMap index growth, collisions, tombstones, compaction and clone correctness.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/hashmap_flat.cpp build/fac_rt.o -lm -ldl -o $T/test_hashmap_flat
$T/test_hashmap_flat
# Graph zero-copy key views, stable Graph storage and compact Trie child storage regressions.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/ds_memory.cpp build/fac_rt.o -lm -ldl -o $T/test_ds_memory
# Graph geometric growth, hybrid high-degree index and weighted shortest-path validation.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/graph_scalability.cpp build/fac_rt.o -lm -ldl -o $T/test_graph_scalability
$T/test_graph_scalability
$T/test_ds_memory
# Deterministic STL allocation-failure injection: compound data structures must roll back.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/ds_exception.cpp build/fac_rt.o -lm -ldl -o $T/test_ds_exception
$T/test_ds_exception
# Clone rollback, managed-string ownership and C-ABI OOM translation for runtime containers.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/ds_clone_exception.cpp build/fac_rt.o -lm -ldl -o $T/test_ds_clone_exception
$T/test_ds_clone_exception

# FAC allocator counters, flat tracking-index growth/reallocations, and managed runtime blocks.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/memory_allocator.cpp build/fac_rt.o -lm -ldl -o $T/test_memory_allocator
$T/test_memory_allocator
# The opt-in flat tracking index must roll back cleanly when its first growth fails.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/memory_tracking_oom.cpp build/fac_rt.o -lm -ldl -o "$T/test_memory_tracking_oom"
"$T/test_memory_tracking_oom"
# Bounded per-thread scratch reuse, FAC/C++ exception cleanup, and trim behavior.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/temporary_scratch_pool.cpp build/fac_rt.o -lm -ldl -o "$T/test_temporary_scratch_pool"
"$T/test_temporary_scratch_pool"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/tls_stack_threads.cpp build/fac_rt.o -lm -ldl -o $T/test_tls_stack_threads
$T/test_tls_stack_threads
# Concurrent immutable string, managed object, weak-handle and closure refcounts.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/refcount_concurrency.cpp build/fac_rt.o -lm -ldl -o $T/test_refcount_concurrency
$T/test_refcount_concurrency
# parallelFor must execute each index exactly once and must join workers before reporting a callback exception.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/thread_start_join.cpp build/fac_rt.o -lm -ldl -o $T/test_thread_start_join
$T/test_thread_start_join
# Every cleanup and temporary drop must be attempted even when an individual drop throws.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/cleanup_exception_safety.cpp build/fac_rt.o -lm -ldl -o "$T/test_cleanup_exception_safety"
"$T/test_cleanup_exception_safety"
# Nested object releases must aggregate child errors until every owned sibling is dropped.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/nested_ownership_recovery.cpp build/fac_rt.o -lm -ldl -o "$T/test_nested_ownership_recovery"
"$T/test_nested_ownership_recovery"
# Trial-deletion cycle collection: topology, conservative roots, failed-trace recovery,
# weak-handle detachment before finalizers and reentrant collection behavior.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/cycle_collector_graph_safety.cpp build/fac_rt.o -lm -ldl -o "$T/test_cycle_collector_graph_safety"
"$T/test_cycle_collector_graph_safety"
# Repeated deterministic cycle-collector stress: graph roots, trace/finalizer failures,
# exact-once callbacks and live-object/allocation counters across 80 batches.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/cycle_collector_stress.cpp build/fac_rt.o -lm -ldl -o "$T/test_cycle_collector_stress"
"$T/test_cycle_collector_stress"
# Sparse/dense cycle-collector scalability and conservative external-root marking.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/cycle_collector_scalability.cpp build/fac_rt.o -lm -ldl -o "$T/test_cycle_collector_scalability"
"$T/test_cycle_collector_scalability"
# Explicit task lifecycle and cooperative cancellation semantics for thread.start handles.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/task_lifecycle.cpp build/fac_rt.o -lm -ldl -o $T/test_task_lifecycle
$T/test_task_lifecycle
echo "PASS task lifecycle / cooperative cancellation / failure precedence"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/parallel_for.cpp build/fac_rt.o -lm -ldl -o $T/test_parallel_for
$T/test_parallel_for
# Persistent worker-pool lifecycle, nested parallelFor and simultaneous callers.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/parallel_pool.cpp build/fac_rt.o -lm -ldl -o $T/test_parallel_pool
$T/test_parallel_pool
echo "PASS reusable parallelFor worker pool / nested scheduling / concurrent submissions"
if $T/test_parallel_for throw >"$T/test_parallel_for_throw.out" 2>"$T/test_parallel_for_throw.err"; then
  echo "FAIL parallelFor callback exception should be reported"; exit 1
fi
grep -q 'callback raised a C++ exception' "$T/test_parallel_for_throw.err" || {
  echo "FAIL parallelFor callback exception returned an unexpected error"; cat "$T/test_parallel_for_throw.err"; exit 1;
}
for mode in null no-entry; do
  if $T/test_parallel_for "$mode" >"$T/test_parallel_for_$mode.out" 2>"$T/test_parallel_for_$mode.err"; then
    echo "FAIL parallelFor $mode should be rejected"; exit 1
  fi
done
grep -q 'null closure' "$T/test_parallel_for_null.err"
grep -q 'closure has no entry function' "$T/test_parallel_for_no-entry.err"
$T/test_parallel_for negative
echo "PASS parallelFor invalid closure guards"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/weak_refs.cpp build/fac_rt.o -lm -ldl -o $T/test_weak_refs
$T/test_weak_refs

# Portable block decode/encode for the software-reference f64 compute path.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/gpu_simd.cpp build/fac_rt.o -lm -ldl -o "$T/test_gpu_simd"
"$T/test_gpu_simd"

# Public FAC two-lane SIMD API: arithmetic, aliases, lane-count and rollback contracts.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/simd_language.cpp build/fac_rt.o -lm -ldl -o "$T/test_simd_language"
"$T/test_simd_language"
"$CXX" -std=c++17 -O2 -pthread tests/runtime/buffer_bounds.cpp build/fac_rt.o -lm -ldl -o "$T/test_buffer_bounds"
"$T/test_buffer_bounds"

echo "PASS array-op invalid input guards"

# SQLite connection/statement registry tokens, per-connection serialization and close/free races.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/sqlite_handle_concurrency.cpp build/fac_rt.o -lm -ldl -o "$T/test_sqlite_handle_concurrency"
if "$T/test_sqlite_handle_concurrency"; then :; else rc=$?; [ "$rc" -eq 77 ] || exit "$rc"; fi

# Path helpers: extension/name changes, component counting and dangling-symlink status.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/path_helpers.cpp build/fac_rt.o -lm -ldl -o $T/test_path_helpers
$T/test_path_helpers

# HTTP client hardening (hostile chunked responses) and memory.zero / random.shuffle size validation.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/net_http.cpp build/fac_rt.o -lm -ldl -o $T/test_net_http
$T/test_net_http ok
$T/test_net_http chunk-trailer
$T/test_net_http content-length
$T/test_net_http informational-response
$T/test_net_http same-content-length
$T/test_net_http query-only
$T/test_net_http url-encode-locale
if $T/test_net_http ipv6; then :; else rc=$?; [ "$rc" -eq 77 ] || exit "$rc"; echo "SKIP IPv6 loopback: unavailable"; fi
$T/test_net_http memzero-ok
for mode in huge-chunk:'truncated chunked' bad-hex:'malformed chunk size' bad-terminator:'malformed chunk terminator' \
            missing-zero-chunk:'truncated chunked response' missing-trailer-end:'truncated chunked response trailers' \
            bad-content-length:'invalid Content-Length' short-content-length:'truncated HTTP body' \
            extra-content-length:'unexpected bytes after HTTP body' conflicting-content-length:'conflicting Content-Length' \
            te-and-length:'both Transfer-Encoding and Content-Length' bad-status:'malformed HTTP status line' \
            bad-header:'malformed HTTP header' protocol-upgrade:'protocol upgrades are not supported' invalid-port:'invalid port in url' memzero-neg:'cannot be negative' \
            shuffle-neg:'invalid count' shuffle-overflow:'size overflow'; do
  name=${mode%%:*}; want=${mode#*:}
  if $T/test_net_http "$name" >"$T/test_net_http_$name.out" 2>"$T/test_net_http_$name.err"; then
    echo "FAIL net_http $name should be rejected"; exit 1
  fi
  grep -q "$want" "$T/test_net_http_$name.err" || { echo "FAIL net_http $name unexpected error"; cat "$T/test_net_http_$name.err"; exit 1; }
done
echo "PASS HTTP framing/status/header/chunk validation / query-only URL / IPv6 authority / locale-independent URL encoding / invalid-port guard / memory.zero / random.shuffle guards"

# regex: large subjects must not overflow the stack; oversize input / pattern must be a FAC error
"$CXX" -std=c++17 -O2 -pthread tests/runtime/regex_guard.cpp build/fac_rt.o -lm -ldl -o $T/test_regex_guard
$T/test_regex_guard small
$T/test_regex_guard big-ok
for mode in too-big:'input too large' long-pattern:'pattern too long' bad-pattern:'invalid regex'; do
  name=${mode%%:*}; want=${mode#*:}
  if $T/test_regex_guard "$name" >/dev/null 2>"$T/test_regex_guard_$name.err"; then echo "FAIL regex $name should be rejected"; exit 1; fi
  grep -q "$want" "$T/test_regex_guard_$name.err" || { echo "FAIL regex $name unexpected error"; cat "$T/test_regex_guard_$name.err"; exit 1; }
done
echo "PASS regex large-input / size-limit guards"

# json builder: cycles, null children, set() aliasing, serializer depth
"$CXX" -std=c++17 -O2 -pthread tests/runtime/json_guard.cpp build/fac_rt.o -lm -ldl -o $T/test_json_guard
$T/test_json_guard ok
for mode in self-push:'into itself' self-set:'into itself' indirect-cycle:'into itself' deep:'nesting too deep'; do
  name=${mode%%:*}; want=${mode#*:}
  if $T/test_json_guard "$name" >/dev/null 2>"$T/test_json_guard_$name.err"; then echo "FAIL json $name should be rejected"; exit 1; fi
  grep -q "$want" "$T/test_json_guard_$name.err" || { echo "FAIL json $name unexpected error"; cat "$T/test_json_guard_$name.err"; exit 1; }
done
echo "PASS json builder cycle / depth guards"

# sync.Channel runtime: FIFO, bounded back-pressure, timeouts, close/drain, concurrent producers/consumers
"$CXX" -std=c++17 -O2 -pthread tests/runtime/sync_chan.cpp build/fac_rt.o -lm -ldl -o $T/test_sync_chan
$T/test_sync_chan
echo "PASS sync.Channel runtime"
# Result-buffer allocation failure must leave the queued message available for retry.
# GNU-compatible --wrap=malloc is available on the Linux test host; skip this
# linker-specific fault-injection case on platforms using a different linker.
case "$(uname -s 2>/dev/null || echo unknown)" in
  Linux*)
    "$CXX" -std=c++17 -O2 -pthread tests/runtime/sync_chan_oom.cpp build/fac_rt.o -Wl,--wrap=malloc -lm -ldl -o $T/test_sync_chan_oom
    $T/test_sync_chan_oom
    echo "PASS sync.Channel allocation-failure preservation"
    ;;
  *) echo "SKIP sync.Channel malloc fault injection (GNU linker --wrap unavailable)" ;;
esac

# sync.Cell runtime: get/set/swap/cas, no lost updates, token never duplicated
"$CXX" -std=c++17 -O2 -pthread tests/runtime/sync_cell.cpp build/fac_rt.o -lm -ldl -o $T/test_sync_cell
$T/test_sync_cell
echo "PASS sync.Cell runtime"

# DataFrame opaque-handle shape validation, bounded grouped output and allocation-failure translation.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/dataframe_shape_safety.cpp build/fac_rt.o -lm -ldl -o "$T/test_dataframe_shape_safety"
"$T/test_dataframe_shape_safety"
# Tensor opaque-handle shape/backing checks, embedded state validation and OOM translation.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/tensor_shape_safety.cpp build/fac_rt.o -lm -ldl -o "$T/test_tensor_shape_safety"
"$T/test_tensor_shape_safety"
# ML model/workspace, KNN vote-map and scalar/tensor autograd allocation rollback.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/ml_autograd_exception_safety.cpp build/fac_rt.o -lm -ldl -o "$T/test_ml_autograd_exception_safety"
"$T/test_ml_autograd_exception_safety"
# Cross-thread Autograd handles fail closed; immutable fitted ML models support concurrent inference.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/ml_autograd_concurrency.cpp build/fac_rt.o -lm -ldl -o "$T/test_ml_autograd_concurrency"
"$T/test_ml_autograd_concurrency"

# strict UTF-8: overlong / surrogate / out-of-range sequences never decode to a character; encoder never emits invalid UTF-8
"$CXX" -std=c++17 -O2 -pthread tests/runtime/utf8_strict.cpp build/fac_rt.o -lm -ldl -o $T/test_utf8_strict
$T/test_utf8_strict
echo "PASS strict UTF-8 decode/encode"

# Compiler-driver arguments must remain literal; special paths must not execute shell text.
marker=/tmp/FAC_DRIVER_INJECTION_MARKER
rm -f "$marker"
weird_dir='/tmp/fac source ; touch FAC_DRIVER_INJECTION_MARKER'
weird_src="$weird_dir/safe.fac"
weird_out='/tmp/fac output ; touch FAC_DRIVER_INJECTION_MARKER'
mkdir -p "$weird_dir"
cp tests/cases/t01_ops.fac "$weird_src"
./build/facc "$weird_src" -o "$weird_out"
[ -x "$weird_out" ] && [ ! -e "$marker" ]
"$weird_out" > $T/driver_special_path.out
cmp tests/cases/t01_ops.out $T/driver_special_path.out
rm -rf "$weird_dir" "$weird_out" "$weird_out.ll" $T/driver_special_path.out
if ./build/facc tests/cases/t01_ops.fac --pkg 'foo;touch /tmp/FAC_DRIVER_INJECTION_MARKER' -o /tmp/fac_pkg_should_fail >$T/driver_pkg.out 2>$T/driver_pkg.err; then
  echo 'FAIL malicious --pkg was accepted'; exit 1
fi
[ ! -e "$marker" ]
grep -q 'ชื่อ package' $T/driver_pkg.err
echo "PASS compiler driver argv and --pkg validation"

# Optional vector font backend: uses Pango/Cairo/Fontconfig when present, otherwise skips.
"$CXX" -std=c++17 -O2 -pthread tests/runtime/font_vector.cpp build/fac_rt.o -lm -ldl -o $T/test_font_vector
FONT_TEST=""
for f in /usr/share/fonts/opentype/tlwg/Waree.otf /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf /usr/share/fonts/opentype/inter/InterDisplay-Medium.otf; do
  if [ -f "$f" ]; then FONT_TEST="$f"; break; fi
done
if [ -n "$FONT_TEST" ]; then $T/test_font_vector "$FONT_TEST"; else $T/test_font_vector; fi
"$CXX" -std=c++17 -O2 -pthread tests/runtime/font_vector_threads.cpp build/fac_rt.o -lm -ldl -o "$T/test_font_vector_threads"
if [ -n "$FONT_TEST" ]; then
  # Separate processes also exercise Pango/Fontconfig static teardown and
  # process-lifetime library pinning, not only in-process worker synchronization.
  for run in 1 2 3; do
    echo "vector font process lifecycle run $run/3"
    "$T/test_font_vector_threads" "$FONT_TEST"
  done
else
  "$T/test_font_vector_threads"
fi
