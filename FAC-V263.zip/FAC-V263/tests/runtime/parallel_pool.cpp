#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <set>
#include <thread>
#include <vector>

extern "C" void fac_parallel_for(int32_t, void *);
extern "C" int64_t fac_thread_id();
extern "C" void fac_try_enter(void *);
extern "C" void fac_try_leave();
extern "C" int32_t fac_err_code();
extern "C" [[noreturn]] void fac_throw(void *, int32_t);

struct IdState {
  void *entry;
  std::mutex mutex;
  std::set<int64_t> ids;
  std::atomic<int> entered{0};
  const int expectedWorkers;
  static void run(void *opaque, int32_t) {
    auto *self = static_cast<IdState *>(opaque);
    const int64_t id = fac_thread_id();
    bool firstVisit = false;
    {
      std::lock_guard<std::mutex> lock(self->mutex);
      firstVisit = self->ids.insert(id).second;
    }
    // fac_parallel_for uses a shared atomic work index. Without this small
    // rendezvous, one fast worker may consume every tiny task before its peers
    // enter the callback, making a worker-identity reuse assertion flaky.
    if (firstVisit) {
      self->entered.fetch_add(1, std::memory_order_acq_rel);
      while (self->entered.load(std::memory_order_acquire) < self->expectedWorkers)
        std::this_thread::yield();
    }
  }
  explicit IdState(int workers)
      : entry(reinterpret_cast<void *>(run)), expectedWorkers(workers) {}
};

struct CountState {
  void *entry;
  std::atomic<int> count{0};
  static void run(void *opaque, int32_t) {
    static_cast<CountState *>(opaque)->count.fetch_add(1, std::memory_order_relaxed);
  }
  CountState() : entry(reinterpret_cast<void *>(run)) {}
};

struct SlowCountState {
  void *entry;
  std::atomic<int> count{0};
  static void run(void *opaque, int32_t index) {
    auto *self = static_cast<SlowCountState *>(opaque);
    self->count.fetch_add(1, std::memory_order_relaxed);
    // Keep enough work in flight to exercise bounded per-worker queues when
    // many external callers submit at once.
    if ((index & 7) == 0) std::this_thread::sleep_for(std::chrono::microseconds(100));
  }
  SlowCountState() : entry(reinterpret_cast<void *>(run)) {}
};

struct InnerThrowState {
  void *entry;
  static void run(void *, int32_t index) {
    if (index == 0) fac_throw(nullptr, 73);
  }
  InnerThrowState() : entry(reinterpret_cast<void *>(run)) {}
};

struct NestedCatchState {
  void *entry;
  InnerThrowState *inner;
  std::atomic<int> caught{0};
  static void run(void *opaque, int32_t index) {
    if (index != 0) return;
    auto *self = static_cast<NestedCatchState *>(opaque);
    void *handler[5]{};
    fac_try_enter(handler);
    if (__builtin_setjmp(handler) == 0) {
      fac_parallel_for(16, self->inner);
      fac_try_leave();
    } else {
      self->caught.store(fac_err_code(), std::memory_order_relaxed);
    }
  }
  explicit NestedCatchState(InnerThrowState *state)
      : entry(reinterpret_cast<void *>(run)), inner(state) {}
};

struct NestedWorkState {
  void *entry;
  CountState *inner;
  std::atomic<int> outer{0};
  static void run(void *opaque, int32_t index) {
    auto *self = static_cast<NestedWorkState *>(opaque);
    self->outer.fetch_add(1, std::memory_order_relaxed);
    if (index == 0) fac_parallel_for(257, self->inner);
  }
  explicit NestedWorkState(CountState *state)
      : entry(reinterpret_cast<void *>(run)), inner(state) {}
};

int main() {
  // Race several first-time callers with different requested sizes. This
  // exercises simultaneous lazy pool growth before any worker exists.
  constexpr int coldCallers = 6;
  CountState cold[coldCallers];
  std::atomic<int> ready{0};
  std::atomic<bool> start{false};
  std::thread coldSubmitters[coldCallers];
  for (int i = 0; i < coldCallers; ++i) {
    coldSubmitters[i] = std::thread([&, i] {
      ready.fetch_add(1, std::memory_order_release);
      while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
      fac_parallel_for(1 + i * 7, &cold[i]);
    });
  }
  while (ready.load(std::memory_order_acquire) != coldCallers) std::this_thread::yield();
  start.store(true, std::memory_order_release);
  for (auto &thread : coldSubmitters) thread.join();
  for (int i = 0; i < coldCallers; ++i) {
    if (cold[i].count.load(std::memory_order_relaxed) != 1 + i * 7) {
      std::fprintf(stderr, "FAIL concurrent cold-start caller %d completed %d/%d\n", i,
                   cold[i].count.load(), 1 + i * 7);
      return 1;
    }
  }

  // The pool grows on demand and reuses its workers across separate calls.
  const int expectedWorkers = (int)std::min(32u, std::max(1u, std::thread::hardware_concurrency()));
  IdState first(expectedWorkers);
  fac_parallel_for(1024, &first);
  if ((int)first.ids.size() != expectedWorkers) {
    std::fprintf(stderr, "FAIL unexpected first worker count: %zu (expected %d)\n",
                 first.ids.size(), expectedWorkers);
    return 1;
  }
  IdState second(expectedWorkers);
  fac_parallel_for(1024, &second);
  if ((int)second.ids.size() != expectedWorkers) {
    std::fprintf(stderr, "FAIL unexpected second worker count: %zu (expected %d)\n",
                 second.ids.size(), expectedWorkers);
    return 1;
  }
  size_t reused = 0;
  for (int64_t id : second.ids) if (first.ids.count(id)) ++reused;
  if (reused == 0) {
    std::fprintf(stderr, "FAIL parallelFor did not reuse any worker thread\n");
    return 1;
  }

  // Nested jobs execute inline on the current worker instead of waiting for
  // workers occupied by the parent, and the nested FAC boundary remains catchable.
  CountState inner;
  NestedWorkState nested(&inner);
  fac_parallel_for(16, &nested);
  if (nested.outer.load(std::memory_order_relaxed) != 16 ||
      inner.count.load(std::memory_order_relaxed) != 257) {
    std::fprintf(stderr, "FAIL nested parallelFor counts outer=%d inner=%d\n",
                 nested.outer.load(), inner.count.load());
    return 1;
  }
  InnerThrowState throwing;
  NestedCatchState nestedCatch(&throwing);
  fac_parallel_for(16, &nestedCatch);
  if (nestedCatch.caught.load(std::memory_order_relaxed) != 73) {
    std::fprintf(stderr, "FAIL nested FAC error was not catchable (code=%d)\n",
                 nestedCatch.caught.load());
    return 1;
  }

  // Concurrent callers must be able to submit independent batches safely.
  constexpr int callers = 6;
  constexpr int work = 1200;
  CountState states[callers];
  std::vector<std::thread> submitters;
  for (int i = 0; i < callers; ++i) {
    submitters.emplace_back([&, i] { fac_parallel_for(work, &states[i]); });
  }
  for (auto &thread : submitters) thread.join();
  for (int i = 0; i < callers; ++i) {
    if (states[i].count.load(std::memory_order_relaxed) != work) {
      std::fprintf(stderr, "FAIL concurrent caller %d completed %d/%d\n", i,
                   states[i].count.load(), work);
      return 1;
    }
  }

  // Deliberately exceed the per-worker queue bound with simultaneous callers.
  // Submission must apply back-pressure rather than growing queue memory
  // without limit, and each synchronous call must still complete exactly once.
  constexpr int pressureCallers = 80;
  constexpr int pressureWork = 96;
  SlowCountState pressure[pressureCallers];
  std::atomic<int> pressureReady{0};
  std::atomic<bool> pressureStart{false};
  std::vector<std::thread> pressureSubmitters;
  pressureSubmitters.reserve(pressureCallers);
  for (int i = 0; i < pressureCallers; ++i) {
    pressureSubmitters.emplace_back([&, i] {
      pressureReady.fetch_add(1, std::memory_order_release);
      while (!pressureStart.load(std::memory_order_acquire)) std::this_thread::yield();
      fac_parallel_for(pressureWork, &pressure[i]);
    });
  }
  while (pressureReady.load(std::memory_order_acquire) != pressureCallers)
    std::this_thread::yield();
  pressureStart.store(true, std::memory_order_release);
  for (auto &thread : pressureSubmitters) thread.join();
  for (int i = 0; i < pressureCallers; ++i) {
    if (pressure[i].count.load(std::memory_order_relaxed) != pressureWork) {
      std::fprintf(stderr, "FAIL bounded-queue caller %d completed %d/%d\n", i,
                   pressure[i].count.load(), pressureWork);
      return 1;
    }
  }

  std::puts("PASS reusable pool worker identity, nested scheduling/error boundary, concurrent callers and bounded-queue back-pressure");
  return 0;
}
