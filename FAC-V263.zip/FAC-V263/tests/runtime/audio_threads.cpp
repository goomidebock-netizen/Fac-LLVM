#include <atomic>
#include <cstdint>
#include <cstdio>
#include <thread>
#include <vector>
#include <string>
#include <unistd.h>

struct FacAudioClip;
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
extern "C" {
FacAudioClip *fac_audio_create(int32_t rate, int32_t channels, int64_t frames);
FacAudioClip *fac_audio_load(struct FacStr *path);
void fac_audio_savewav(FacAudioClip *clip, struct FacStr *path);
int64_t fac_audio_frames(FacAudioClip *clip);
int32_t fac_audio_rate(FacAudioClip *clip);
int32_t fac_audio_channels(FacAudioClip *clip);
void fac_audio_volume(double volume);
int32_t fac_audio_play(FacAudioClip *clip);
int32_t fac_audio_playloop(FacAudioClip *clip);
void fac_audio_stop();
void fac_audio_free(FacAudioClip *clip);
}

int main() {
  FacAudioClip *clip = fac_audio_create(44100, 1, 256);
  std::string wavPath = "/tmp/fac_audio_thread_test_" + std::to_string((long long)getpid()) + ".wav";
  FacStr path{wavPath.data(), (int64_t)wavPath.size(), (int64_t)wavPath.size(), (int64_t)wavPath.size(), 2};
  fac_audio_savewav(clip, &path);
  FacAudioClip *loaded = fac_audio_load(&path);
  if (!loaded || fac_audio_frames(loaded) != 256 || fac_audio_rate(loaded) != 44100 || fac_audio_channels(loaded) != 1) return 2;
  fac_audio_free(loaded);
  unlink(wavPath.c_str());
  std::atomic<bool> failed{false};
  std::vector<std::thread> workers;
  for (int t = 0; t < 8; ++t) workers.emplace_back([&, t] {
    for (int i = 0; i < 200; ++i) {
      fac_audio_volume((double)((i + t) % 101) / 100.0);
      (void)fac_audio_play(clip);
      if ((i % 7) == 0) (void)fac_audio_playloop(clip);
      if ((i % 3) == 0) fac_audio_stop();
    }
  });
  for (auto &w : workers) w.join();
  fac_audio_stop();
  fac_audio_free(clip);
  if (failed.load()) return 1;
  std::puts("PASS concurrent audio controls");
  return 0;
}
