#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <vector>

#if defined(FAC_SQLITE_STANDALONE_TEST)
// Compile the exact SQLite backend directly for focused sanitizer runs, avoiding
// the much larger fac_rt.cpp translation unit while preserving the tested code.
#include <string>
#include <mutex>
#include <memory>
#include <unordered_map>
#ifndef _WIN32
#include <dlfcn.h>
#endif
#include "../../runtime/fac_sqlite.inc"
#else
extern "C" {
int32_t fac_sqlite_available();
void *fac_sqlite_open(const char *, int32_t, int32_t, int32_t);
int32_t fac_sqlite_close(void *);
void fac_sqlite_connection_free(void *);
char *fac_sqlite_error(void *);
void *fac_sqlite_prepare(void *, const char *);
int32_t fac_sqlite_statement_finalize(void *);
void fac_sqlite_statement_free(void *);
char *fac_sqlite_statement_error(void *);
int32_t fac_sqlite_exec(void *, const char *);
int32_t fac_sqlite_step(void *);
int32_t fac_sqlite_reset(void *);
int32_t fac_sqlite_clear_bindings(void *);
int32_t fac_sqlite_bind_int64(void *, int32_t, int64_t);
int32_t fac_sqlite_column_count(void *);
int32_t fac_sqlite_column_int64(void *, int32_t);
const char *fac_sqlite_column_text(void *, int32_t);
const char *fac_sqlite_column_name(void *, int32_t);
void fac_sqlite_string_free(char *);
}
#endif

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  if (!fac_sqlite_available()) {
    std::puts("SKIP SQLite handle concurrency: SQLite shared library unavailable");
    return 77;
  }

  void *db = fac_sqlite_open(":memory:", 0, 1, 5000);
  if (!db) return fail("open in-memory database failed");
  if (fac_sqlite_exec(db, "CREATE TABLE events(worker INTEGER NOT NULL, seq INTEGER NOT NULL)") != 0)
    return fail("create table failed");

  constexpr int THREADS = 8;
  constexpr int INSERTS = 180;
  std::atomic<bool> failed{false};
  std::vector<std::thread> workers;
  for (int t = 0; t < THREADS; ++t) {
    workers.emplace_back([&, t] {
      void *stmt = fac_sqlite_prepare(db, "INSERT INTO events(worker, seq) VALUES(?1, ?2)");
      if (!stmt) { failed.store(true, std::memory_order_relaxed); return; }
      for (int i = 0; i < INSERTS; ++i) {
        if (fac_sqlite_bind_int64(stmt, 1, t) != 0 ||
            fac_sqlite_bind_int64(stmt, 2, i) != 0 ||
            fac_sqlite_step(stmt) != 101 ||
            fac_sqlite_reset(stmt) != 0 ||
            fac_sqlite_clear_bindings(stmt) != 0) {
          failed.store(true, std::memory_order_relaxed);
          break;
        }
      }
      fac_sqlite_statement_free(stmt);
    });
  }
  for (auto &worker : workers) worker.join();
  if (failed.load(std::memory_order_relaxed)) return fail("concurrent independent statement inserts failed");

  void *count = fac_sqlite_prepare(db, "SELECT count(*) FROM events");
  if (!count || fac_sqlite_step(count) != 100 ||
      fac_sqlite_column_count(count) != 1 ||
      fac_sqlite_column_int64(count, 0) != (int64_t)THREADS * INSERTS)
    return fail("serialized concurrent inserts lost or duplicated rows");
  if (fac_sqlite_statement_finalize(count) != 0) return fail("statement finalize failed");
  if (fac_sqlite_step(count) != -1) return fail("finalized statement remained usable");
  fac_sqlite_statement_free(count);
  if (fac_sqlite_step(count) != -1 || fac_sqlite_statement_finalize(count) != -1)
    return fail("stale statement token was not rejected");

  // Column strings are copied into per-thread storage while the connection lock
  // is held, so another operation cannot invalidate the returned bytes.
  void *textStmt = fac_sqlite_prepare(db, "SELECT 'stable-value' AS label");
  if (!textStmt || fac_sqlite_step(textStmt) != 100) return fail("text statement setup failed");
  const char *text = fac_sqlite_column_text(textStmt, 0);
  const char *name = fac_sqlite_column_name(textStmt, 0);
  if (!text || std::strcmp(text, "stable-value") != 0 || !name || std::strcmp(name, "label") != 0)
    return fail("column text/name copy mismatch");
  fac_sqlite_statement_free(textStmt);

  // sqlite3_close_v2 defers native destruction for a live statement. Removing
  // the connection token must not invalidate that statement's retained state.
  void *dbWithStmt = fac_sqlite_open(":memory:", 0, 1, 5000);
  if (!dbWithStmt) return fail("second database open failed");
  void *survivor = fac_sqlite_prepare(dbWithStmt, "SELECT 42");
  if (!survivor) return fail("prepare survivor statement failed");
  fac_sqlite_connection_free(dbWithStmt);
  if (fac_sqlite_step(survivor) != 100 || fac_sqlite_column_int64(survivor, 0) != 42)
    return fail("statement did not retain native connection through close_v2");
  fac_sqlite_statement_free(survivor);
  if (fac_sqlite_step(survivor) != -1) return fail("freed survivor statement accepted a stale token");

  // Race statement-token removal/finalization against calls that already have
  // or are attempting to acquire the same statement record.
  void *racingStmt = fac_sqlite_prepare(db, "SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4");
  if (!racingStmt) return fail("statement-free race setup failed");
  std::atomic<bool> statementStart{false};
  workers.clear();
  for (int t = 0; t < 6; ++t) workers.emplace_back([&] {
    while (!statementStart.load(std::memory_order_acquire)) std::this_thread::yield();
    for (int i = 0; i < 100000; ++i) {
      int rc = fac_sqlite_step(racingStmt);
      if (rc == -1) break;
      if (rc != 100 && rc != 101) { failed.store(true, std::memory_order_relaxed); break; }
    }
  });
  statementStart.store(true, std::memory_order_release);
  std::this_thread::sleep_for(std::chrono::milliseconds(2));
  fac_sqlite_statement_free(racingStmt);
  for (auto &worker : workers) worker.join();
  if (failed.load(std::memory_order_relaxed) || fac_sqlite_step(racingStmt) != -1)
    return fail("statement free did not serialize with in-flight step calls");

  // Race a connection token removal against active operations. Every call is
  // serialized by the connection state; after free returns the token is stale.
  void *racingDb = fac_sqlite_open(":memory:", 0, 1, 5000);
  if (!racingDb || fac_sqlite_exec(racingDb, "CREATE TABLE race(v INTEGER)") != 0)
    return fail("race database setup failed");
  std::atomic<bool> start{false};
  workers.clear();
  for (int t = 0; t < 6; ++t) workers.emplace_back([&, t] {
    while (!start.load(std::memory_order_acquire)) std::this_thread::yield();
    for (int i = 0; i < 300; ++i) {
      int rc = fac_sqlite_exec(racingDb, "INSERT INTO race(v) VALUES(1)");
      if (rc != 0) break; // Close/free may linearize before this operation.
    }
  });
  start.store(true, std::memory_order_release);
  std::this_thread::sleep_for(std::chrono::milliseconds(2));
  fac_sqlite_connection_free(racingDb);
  for (auto &worker : workers) worker.join();
  if (fac_sqlite_exec(racingDb, "SELECT 1") != -1 || fac_sqlite_close(racingDb) != -1)
    return fail("freed connection token remained usable");

  // Tokens monotonically advance and are never recycled, even when native
  // records and database objects have been destroyed.
  void *oldDb = fac_sqlite_open(":memory:", 0, 1, 5000);
  if (!oldDb) return fail("token baseline open failed");
  fac_sqlite_connection_free(oldDb);
  for (int i = 0; i < 512; ++i) {
    void *nextDb = fac_sqlite_open(":memory:", 0, 1, 5000);
    if (!nextDb || nextDb == oldDb) return fail("SQLite connection token was reused");
    fac_sqlite_connection_free(nextDb);
  }
  if (fac_sqlite_exec(oldDb, "SELECT 1") != -1) return fail("expired token aliased a new connection");

  fac_sqlite_connection_free(db);
  if (fac_sqlite_exec(db, "SELECT 1") != -1) return fail("freed database token remained usable");
  std::puts("PASS SQLite per-connection serialization, statement lifetime, stale-token rejection and close/free races");
  return 0;
}
