#include <cstdint>
#include <cstdio>
#include <new>
#include <stdexcept>
#include <vector>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void fac_cycle_visit(void *object);
int64_t fac_obj_collect_cycles();
uint64_t fac_obj_live_count();
void fac_mem_start_tracking();
uint64_t fac_mem_blocks();
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
[[noreturn]] void fac_throw(void *message, int32_t code);
}

namespace {
constexpr int kNodesPerBatch = 96;
constexpr int kBatches = 80;
constexpr int kTraceCppError = 31;
constexpr int kTraceFacError = 32;
constexpr int kFinalizerFacError = 41;
constexpr int kFinalizerCppError = 42;

struct StressNode {
  void *edges[3]{};
  uint32_t id = 0;
  uint8_t edgeCount = 0;
};

int g_finalized = 0;
int g_dropped = 0;
int g_traceCalls = 0;
int g_reentrantCalls = 0;
int g_reentrantFailures = 0;
int g_traceFailureId = -1;
int g_traceFailureKind = 0; // 1 = C++ exception, 2 = FAC throw
int g_finalizerFailureId = -1;
int g_finalizerFailureKind = 0; // 1 = C++ exception, 2 = FAC throw

void traceStressNode(void *opaque) {
  auto *node = static_cast<StressNode *>(opaque);
  ++g_traceCalls;
  if (static_cast<int>(node->id) == g_traceFailureId) {
    const int kind = g_traceFailureKind;
    g_traceFailureId = -1;
    g_traceFailureKind = 0;
    if (kind == 1) throw std::runtime_error("stress trace exception");
    if (kind == 2) fac_throw(nullptr, kTraceFacError);
  }
  for (uint8_t i = 0; i < node->edgeCount; ++i) fac_cycle_visit(node->edges[i]);
}

void dropStressNode(void *opaque) {
  auto *node = static_cast<StressNode *>(opaque);
  for (uint8_t i = 0; i < node->edgeCount; ++i) {
    void *child = node->edges[i];
    node->edges[i] = nullptr;
    fac_obj_release(child);
  }
  node->edgeCount = 0;
  ++g_dropped;
}

void finalizeStressNode(void *opaque) {
  auto *node = static_cast<StressNode *>(opaque);
  ++g_finalized;
  if ((node->id % 23u) == 0u) {
    ++g_reentrantCalls;
    if (fac_obj_collect_cycles() != 0) ++g_reentrantFailures;
  }
  if (static_cast<int>(node->id) == g_finalizerFailureId) {
    const int kind = g_finalizerFailureKind;
    g_finalizerFailureId = -1;
    g_finalizerFailureKind = 0;
    if (kind == 1) throw std::runtime_error("stress finalizer exception");
    if (kind == 2) fac_throw(nullptr, kFinalizerFacError);
  }
}

StressNode *makeNode(uint32_t id) {
  void *storage = fac_obj_new(static_cast<int64_t>(sizeof(StressNode)),
      reinterpret_cast<void *>(dropStressNode), nullptr,
      reinterpret_cast<void *>(traceStressNode),
      reinterpret_cast<void *>(finalizeStressNode));
  if (!storage) return nullptr;
  auto *node = new (storage) StressNode;
  node->id = id;
  return node;
}

void linkNode(StressNode *from, StressNode *to) {
  if (from->edgeCount >= 3) return;
  from->edges[from->edgeCount++] = to;
  fac_obj_retain(to);
}

void resetObservations() {
  g_finalized = 0;
  g_dropped = 0;
  g_traceCalls = 0;
  g_reentrantCalls = 0;
  g_reentrantFailures = 0;
  g_traceFailureId = -1;
  g_traceFailureKind = 0;
  g_finalizerFailureId = -1;
  g_finalizerFailureKind = 0;
}

int catchCollect(int &code, int64_t &result) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    result = fac_obj_collect_cycles();
    fac_try_leave();
    code = 0;
    return 0;
  }
  code = fac_err_code();
  return 1;
}

int fail(int batch, const char *message) {
  std::fprintf(stderr, "FAIL batch %d: %s\n", batch, message);
  return 1;
}
} // namespace

int main() {
  fac_mem_start_tracking();
  const uint64_t initialLive = fac_obj_live_count();
  const uint64_t initialBlocks = fac_mem_blocks();
  uint64_t totalCreated = 0;
  uint64_t totalCollected = 0;
  uint64_t totalTraceRecoveries = 0;
  uint64_t totalFinalizerErrors = 0;

  for (int batch = 0; batch < kBatches; ++batch) {
    resetObservations();
    const uint32_t idBase = static_cast<uint32_t>(batch * kNodesPerBatch);
    std::vector<StressNode *> nodes;
    nodes.reserve(kNodesPerBatch);
    for (int i = 0; i < kNodesPerBatch; ++i) {
      StressNode *node = makeNode(idBase + static_cast<uint32_t>(i));
      if (!node) return fail(batch, "object allocation failed");
      nodes.push_back(node);
    }
    totalCreated += nodes.size();

    // Every batch is a single strongly-connected component with a ring edge,
    // a deterministic long chord and occasional self-edges. The topology is
    // repeatable, but differs in its chord offsets between batches.
    const int chord = 5 + (batch % 17);
    for (int i = 0; i < kNodesPerBatch; ++i) {
      linkNode(nodes[i], nodes[(i + 1) % kNodesPerBatch]);
      linkNode(nodes[i], nodes[(i + chord) % kNodesPerBatch]);
      if ((i % 13) == 0) linkNode(nodes[i], nodes[i]);
    }

    // Alternate batches with and without a genuine external root. A rooted
    // graph must survive collection unchanged; after releasing the root, the
    // same graph must become collectible.
    const bool keepExternalRoot = (batch % 2) == 0;
    const int rootIndex = (batch * 7) % kNodesPerBatch;
    for (int i = 0; i < kNodesPerBatch; ++i)
      if (!keepExternalRoot || i != rootIndex) fac_obj_release(nodes[i]);

    // Inject a trace failure every fifth batch, alternating native C++ and
    // FAC non-local errors. A failed snapshot must not mutate object liveness
    // or prevent a later pass from collecting this graph.
    const bool injectTraceFailure = (batch % 5) == 0;
    if (injectTraceFailure) {
      const int failureIndex = (batch * 11 + 3) % kNodesPerBatch;
      g_traceFailureId = static_cast<int>(idBase) + failureIndex;
      g_traceFailureKind = ((batch / 5) % 2) == 0 ? 1 : 2;
      int errorCode = 0;
      int64_t ignored = -1;
      if (!catchCollect(errorCode, ignored))
        return fail(batch, "injected trace failure was not propagated");
      // The callback clears its injection mode before throwing, so use the
      // deterministic batch parity to assert the translated error code.
      const int expectedCode = ((batch / 5) % 2) == 0 ? 7 : kTraceFacError;
      if (errorCode != expectedCode)
        return fail(batch, "trace failure returned the wrong FAC error code");
      if (fac_obj_live_count() != initialLive + kNodesPerBatch ||
          fac_mem_blocks() != initialBlocks + kNodesPerBatch)
        return fail(batch, "failed trace snapshot changed live-object or allocation counts");
      ++totalTraceRecoveries;
    }

    if (keepExternalRoot) {
      int errorCode = 0;
      int64_t rootedResult = -1;
      if (catchCollect(errorCode, rootedResult) || rootedResult != 0)
        return fail(batch, "collector reclaimed an externally rooted component");
      if (fac_obj_live_count() != initialLive + kNodesPerBatch)
        return fail(batch, "rooted component changed live-object count");
      fac_obj_release(nodes[rootIndex]);
    }

    // Inject a finalizer error in selected batches. The collector must finish
    // every finalizer/drop, free all storage, restore its gate and then report
    // the first error to the caller.
    const bool injectFinalizerError = (batch % 10) == 3;
    int expectedFinalizerError = 0;
    if (injectFinalizerError) {
      g_finalizerFailureId = static_cast<int>(idBase) + ((batch * 13 + 9) % kNodesPerBatch);
      g_finalizerFailureKind = ((batch / 10) % 2) == 0 ? 1 : 2;
      expectedFinalizerError = g_finalizerFailureKind == 1 ? 7 : kFinalizerFacError;
    }

    int errorCode = 0;
    int64_t collected = -1;
    const int didThrow = catchCollect(errorCode, collected);
    if (injectFinalizerError) {
      if (!didThrow || errorCode != expectedFinalizerError)
        return fail(batch, "finalizer failure was not reported after collection");
      ++totalFinalizerErrors;
    } else if (didThrow || collected != kNodesPerBatch) {
      return fail(batch, "collector did not reclaim the complete unrooted component");
    }

    if (g_finalized != kNodesPerBatch || g_dropped != kNodesPerBatch)
      return fail(batch, "finalizers or drops did not run exactly once for every node");
    if (g_reentrantCalls == 0 || g_reentrantFailures != 0)
      return fail(batch, "reentrant collection did not return safely from finalizers");
    if (fac_obj_live_count() != initialLive || fac_mem_blocks() != initialBlocks)
      return fail(batch, "live-object or allocation counters did not return to baseline");

    // A clean no-op pass after every batch proves the process-wide collector
    // exclusion state was restored even when a trace/finalizer failed.
    if (fac_obj_collect_cycles() != 0)
      return fail(batch, "post-batch empty collection was not a no-op");
    totalCollected += kNodesPerBatch;
  }

  if (totalCreated != static_cast<uint64_t>(kBatches * kNodesPerBatch) ||
      totalCollected != totalCreated || totalTraceRecoveries != 16 || totalFinalizerErrors != 8)
    return fail(kBatches, "stress run totals did not match the deterministic plan");
  if (fac_obj_live_count() != initialLive || fac_mem_blocks() != initialBlocks)
    return fail(kBatches, "final object/allocation counters differ from initial baseline");

  std::printf("PASS cycle collector stress: %llu nodes in %d batches, %llu trace recoveries, %llu finalizer errors; live objects and allocations returned to baseline\n",
      static_cast<unsigned long long>(totalCreated), kBatches,
      static_cast<unsigned long long>(totalTraceRecoveries),
      static_cast<unsigned long long>(totalFinalizerErrors));
  return 0;
}
