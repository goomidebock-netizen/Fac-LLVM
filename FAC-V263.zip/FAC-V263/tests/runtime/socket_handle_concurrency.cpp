#include <atomic>
#include <chrono>
#include <cstdio>
#include <thread>

extern "C" {
struct FacStr { char *data; long long len, cap, ncp, flags; };
struct Sock;
void fac_init(int, char **);
FacStr *fac_cstr_new(const char *);
void fac_str_free(FacStr *);
Sock *fac_net_listen(int);
int fac_net_localport(Sock *);
Sock *fac_net_accept(Sock *);
Sock *fac_net_connect(FacStr *, int);
void fac_net_settimeout(Sock *, int);
FacStr *fac_net_recv(Sock *, int);
int32_t fac_net_send(Sock *, FacStr *);
FacStr *fac_net_recvexact(Sock *, int);
void fac_net_close(Sock *);
void fac_try_enter(void *);
void fac_try_leave();
int fac_err_code();
}

static int try_recv_exact_timeout(Sock *s) {
  void *jb[5]{}; fac_try_enter(jb);
  if (__builtin_setjmp(jb) == 0) {
    FacStr *value = fac_net_recvexact(s, 1);
    if (value) fac_str_free(value);
    fac_try_leave(); return 0;
  }
  return fac_err_code();
}
static int try_set_timeout(Sock *s) {
  void *jb[5]{}; fac_try_enter(jb);
  if (__builtin_setjmp(jb) == 0) { fac_net_settimeout(s, 100); fac_try_leave(); return 0; }
  return fac_err_code();
}

int main(int argc, char **argv) {
  fac_init(argc, argv);
  FacStr *host = fac_cstr_new("127.0.0.1");
  Sock *listener = fac_net_listen(0);
  const int port = fac_net_localport(listener);
  if (port <= 0) { std::fprintf(stderr, "FAIL invalid listener port=%d\n", port); return 1; }
  std::atomic<bool> acceptedReady{false};
  std::atomic<int> recvStatus{0};
  Sock *accepted = nullptr;
  std::thread server([&] {
    accepted = fac_net_accept(listener);
    fac_net_settimeout(accepted, 420);
    acceptedReady.store(true, std::memory_order_release);
    recvStatus.store(try_recv_exact_timeout(accepted), std::memory_order_release);
  });
  Sock *client = fac_net_connect(host, port);
  while (!acceptedReady.load(std::memory_order_acquire)) std::this_thread::yield();
  std::this_thread::sleep_for(std::chrono::milliseconds(60));
  const auto begin = std::chrono::steady_clock::now();
  fac_net_close(accepted); // Must wait for the in-flight timed receive to release its lease.
  const auto elapsed = std::chrono::steady_clock::now() - begin;
  server.join();
  if (recvStatus.load() != 11 || elapsed < std::chrono::milliseconds(120)) {
    std::fprintf(stderr, "FAIL socket close did not serialize behind in-flight recv (status=%d, wait=%lldms)\n",
      recvStatus.load(), (long long)std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count());
    return 1;
  }
  if (try_set_timeout(accepted) != 11 || fac_net_localport(accepted) != -1) {
    std::fprintf(stderr, "FAIL closed socket token was not rejected\n"); return 1;
  }
  fac_net_close(accepted); // Repeated close is a harmless no-op.
  fac_net_close(client);
  fac_net_close(listener);

  // Tombstones keep old token addresses from being recycled by later sockets.
  for (int i = 0; i < 256; ++i) {
    Sock *fresh = fac_net_listen(0);
    if (!fresh || fac_net_localport(fresh) <= 0 || try_set_timeout(accepted) != 11) {
      std::fprintf(stderr, "FAIL stale socket token changed after churn iteration %d\n", i); return 1;
    }
    fac_net_close(fresh);
  }
  // A blocked read must not prevent an independent write on the same TCP handle.
  Sock *duplexListener = fac_net_listen(0);
  const int duplexPort = fac_net_localport(duplexListener);
  Sock *duplexPeer = nullptr;
  std::atomic<bool> duplexReady{false};
  std::atomic<int> duplexReadError{0};
  std::thread duplexServer([&] {
    duplexPeer = fac_net_accept(duplexListener);
    fac_net_settimeout(duplexPeer, 520);
    duplexReady.store(true, std::memory_order_release);
    duplexReadError.store(try_recv_exact_timeout(duplexPeer), std::memory_order_release);
  });
  Sock *duplexClient = fac_net_connect(host, duplexPort);
  while (!duplexReady.load(std::memory_order_acquire)) std::this_thread::yield();
  std::this_thread::sleep_for(std::chrono::milliseconds(55));
  FacStr *reply = fac_cstr_new("ok");
  const auto sendBegin = std::chrono::steady_clock::now();
  if (fac_net_send(duplexPeer, reply) != 2) return 1;
  const auto sendElapsed = std::chrono::steady_clock::now() - sendBegin;
  fac_str_free(reply);
  FacStr *received = fac_net_recvexact(duplexClient, 2);
  const bool receivedReply = received && received->len == 2 && received->data[0] == 'o' && received->data[1] == 'k';
  if (received) fac_str_free(received);
  duplexServer.join();
  if (!receivedReply || sendElapsed > std::chrono::milliseconds(250) || duplexReadError.load() != 11) {
    std::fprintf(stderr, "FAIL full-duplex socket read/write (send=%lldms, readError=%d)\n",
      (long long)std::chrono::duration_cast<std::chrono::milliseconds>(sendElapsed).count(), duplexReadError.load());
    return 1;
  }
  fac_net_close(duplexPeer); fac_net_close(duplexClient); fac_net_close(duplexListener);

  fac_str_free(host);
  std::puts("PASS socket stale-token rejection, 256 handle churn cycles, close-vs-I/O serialization, and full-duplex read/write");
  return 0;
}
