#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <vector>

static std::atomic<long long> g_fail_after{-1};
static bool should_fail_allocation() noexcept {
  long long current = g_fail_after.load(std::memory_order_relaxed);
  while (current >= 0) {
    if (current == 0) {
      if (g_fail_after.compare_exchange_weak(current, -1, std::memory_order_relaxed)) return true;
    } else if (g_fail_after.compare_exchange_weak(current, current - 1, std::memory_order_relaxed)) {
      return false;
    }
  }
  return false;
}
static void *test_new(std::size_t size) {
  if (should_fail_allocation()) throw std::bad_alloc();
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new(std::size_t size) { return test_new(size); }
void *operator new[](std::size_t size) { return test_new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

// Runtime-private white-box tape layout; it is intentionally not part of the C ABI.
struct FacGradNode { double value = 0.0, grad = 0.0, exponent = 0.0; int32_t a = -1, b = -1, op = 0; };
struct FacGradTape { std::vector<FacGradNode> nodes; uint64_t owner_token; };
struct FacTensor { int64_t rows = 0, cols = 0; std::vector<double> values; };
struct FacTensorGradNode {
  FacTensor value;
  std::vector<double> grad;
  int32_t a = -1, b = -1, op = 0;
  double scalar = 0.0;
};
struct FacTensorGradTape { std::vector<FacTensorGradNode> nodes; uint64_t stored_elements = 0; uint64_t owner_token; };

extern "C" {
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
int32_t fac_runtime_trim_thread();
void *fac_tensor_create(int32_t rows, int32_t cols);
void fac_tensor_set(void *tensor, int32_t row, int32_t col, double value);
int64_t fac_tensor_rows(void *tensor);
int64_t fac_tensor_size(void *tensor);
double fac_tensor_get(void *tensor, int32_t row, int32_t col);
void fac_tensor_free(void *tensor);
void *fac_ml_linear_fit(void *, void *, double, int32_t);
void *fac_ml_ridge_fit(void *, void *, double, int32_t, double);
void *fac_ml_logistic_fit(void *, void *, double, int32_t);
void fac_ml_free_model(void *);
void *fac_ml_kmeans(void *, int32_t, int32_t, int64_t);
void fac_ml_free_kmeans(void *);
void *fac_ml_knn_fit(void *, void *, int32_t);
void *fac_ml_knn_predict(void *, void *);
void fac_ml_free_knn(void *);
void *fac_autograd_create();
void fac_autograd_free(void *);
int32_t fac_autograd_variable(void *, double);
int32_t fac_autograd_add(void *, int32_t, int32_t);
void fac_autograd_backward(void *, int32_t);
double fac_autograd_grad(void *, int32_t);
void *fac_autograd_tensor_create();
void fac_autograd_tensor_free(void *);
int32_t fac_autograd_tensor_variable(void *, void *);
int32_t fac_autograd_tensor_sum(void *, int32_t);
void fac_autograd_tensor_backward(void *, int32_t);
void *fac_autograd_tensor_grad(void *, int32_t);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL ML/autograd exception safety: %s\n", message);
  return 1;
}
template <typename Fn> static int capture_error(Fn fn) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fn();
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static bool cleanup_stack_is_empty() { return fac_runtime_trim_thread() == 1; }

template <typename Call, typename Drop>
static bool exercise_fail_points(const char *label, long long limit, Call call, Drop drop) {
  int failures = 0, successes = 0;
  for (long long failAt = 0; failAt < limit; ++failAt) {
    void *result = nullptr;
    const int error = capture_error([&] {
      g_fail_after.store(failAt, std::memory_order_relaxed);
      result = call();
      g_fail_after.store(-1, std::memory_order_relaxed);
    });
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 0) {
      if (!result) return false;
      drop(result);
      ++successes;
    } else if (error == 5 || error == 14) {
      ++failures;
    } else {
      std::fprintf(stderr, "%s returned unexpected FAC error %d at allocation %lld\n", label, error, failAt);
      return false;
    }
    if (!cleanup_stack_is_empty()) {
      std::fprintf(stderr, "%s left cleanup registrations after allocation %lld\n", label, failAt);
      return false;
    }
  }
  if (!failures || !successes) {
    std::fprintf(stderr, "%s did not cover both failure and successful construction (fail=%d, ok=%d)\n",
                 label, failures, successes);
    return false;
  }
  return true;
}

int main() {
  void *x = fac_tensor_create(3, 2);
  void *y = fac_tensor_create(3, 1);
  void *ylog = fac_tensor_create(3, 1);
  if (!x || !y || !ylog) return fail("create linear model inputs");
  const double xv[6] = {0.0, 1.0, 1.0, 0.0, 1.0, 1.0};
  const double yv[3] = {1.0, 2.0, 3.0};
  const double ylogv[3] = {0.0, 1.0, 1.0};
  for (int r = 0; r < 3; ++r) {
    fac_tensor_set(y, r, 0, yv[r]);
    fac_tensor_set(ylog, r, 0, ylogv[r]);
    for (int c = 0; c < 2; ++c) fac_tensor_set(x, r, c, xv[r * 2 + c]);
  }

  if (!exercise_fail_points("linearFit", 14,
      [&] { return fac_ml_linear_fit(x, y, 0.01, 2); }, fac_ml_free_model))
    return fail("linearFit allocation rollback");
  if (!exercise_fail_points("ridgeFit", 14,
      [&] { return fac_ml_ridge_fit(x, y, 0.01, 2, 0.1); }, fac_ml_free_model))
    return fail("ridgeFit allocation rollback");
  if (!exercise_fail_points("logisticFit", 14,
      [&] { return fac_ml_logistic_fit(x, ylog, 0.01, 2); }, fac_ml_free_model))
    return fail("logisticFit allocation rollback");
  if (!exercise_fail_points("kmeans", 30,
      [&] { return fac_ml_kmeans(x, 2, 2, 7); }, fac_ml_free_kmeans))
    return fail("kmeans workspace rollback");
  if (!exercise_fail_points("knnFit", 14,
      [&] { return fac_ml_knn_fit(x, y, 1); }, fac_ml_free_knn))
    return fail("knnFit model-copy rollback");

  void *knn = fac_ml_knn_fit(x, y, 1);
  if (!knn) return fail("create KNN prediction model");
  if (!exercise_fail_points("knnPredict", 24,
      [&] { return fac_ml_knn_predict(knn, x); }, fac_tensor_free))
    return fail("knnPredict output/vote workspace rollback");
  fac_ml_free_knn(knn);

  // Scalar autograd append must either commit exactly one node or leave the tape unchanged.
  int scalarFailures = 0, scalarSuccesses = 0;
  for (long long failAt = 0; failAt < 4; ++failAt) {
    auto *tape = static_cast<FacGradTape *>(fac_autograd_create());
    if (!tape) return fail("create scalar tape");
    const int error = capture_error([&] {
      g_fail_after.store(failAt, std::memory_order_relaxed);
      (void)fac_autograd_variable(tape, 2.0);
      g_fail_after.store(-1, std::memory_order_relaxed);
    });
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 0) ++scalarSuccesses;
    else if (error == 5 || error == 14) {
      ++scalarFailures;
      if (!tape->nodes.empty()) return fail("scalar tape changed after failed node append");
    } else return fail("scalar autograd returned an unexpected allocation error");
    if (!cleanup_stack_is_empty()) return fail("scalar autograd left cleanup registrations");
    fac_autograd_free(tape);
  }
  if (!scalarFailures || !scalarSuccesses) return fail("scalar autograd fail points were not exercised");

  // Tensor autograd stages each node and commits stored_elements only after push_back succeeds.
  int tensorFailures = 0, tensorSuccesses = 0;
  for (long long failAt = 0; failAt < 12; ++failAt) {
    auto *tape = static_cast<FacTensorGradTape *>(fac_autograd_tensor_create());
    if (!tape) return fail("create tensor tape");
    const int error = capture_error([&] {
      g_fail_after.store(failAt, std::memory_order_relaxed);
      (void)fac_autograd_tensor_variable(tape, x);
      g_fail_after.store(-1, std::memory_order_relaxed);
    });
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 0) ++tensorSuccesses;
    else if (error == 5 || error == 14) {
      ++tensorFailures;
      if (!tape->nodes.empty() || tape->stored_elements != 0)
        return fail("tensor tape committed a partial node after failed append");
    } else return fail("tensor autograd returned an unexpected allocation error");
    if (!cleanup_stack_is_empty()) return fail("tensor autograd node append left cleanup registrations");
    fac_autograd_tensor_free(tape);
  }
  if (!tensorFailures || !tensorSuccesses) return fail("tensor autograd fail points were not exercised");

  // Backward computes into detached buffers; injected OOM must preserve old gradients.
  int backwardFailures = 0, backwardSuccesses = 0;
  for (long long failAt = 0; failAt < 16; ++failAt) {
    auto *tape = static_cast<FacTensorGradTape *>(fac_autograd_tensor_create());
    if (!tape) return fail("create backward tape");
    const int32_t variable = fac_autograd_tensor_variable(tape, x);
    const int32_t output = fac_autograd_tensor_sum(tape, variable);
    const int error = capture_error([&] {
      g_fail_after.store(failAt, std::memory_order_relaxed);
      fac_autograd_tensor_backward(tape, output);
      g_fail_after.store(-1, std::memory_order_relaxed);
    });
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 0) ++backwardSuccesses;
    else if (error == 5 || error == 14) {
      ++backwardFailures;
      for (double g : tape->nodes[(size_t)variable].grad)
        if (g != 0.0) return fail("failed tensor backward partially committed gradients");
      if (capture_error([&] { fac_autograd_tensor_backward(tape, output); }) != 0)
        return fail("tensor backward could not retry after allocation failure");
    } else return fail("tensor backward returned an unexpected allocation error");
    if (!cleanup_stack_is_empty()) return fail("tensor backward left temporary gradients registered");
    void *gradient = fac_autograd_tensor_grad(tape, variable);
    if (!gradient || fac_tensor_rows(gradient) != 3 || fac_tensor_size(gradient) != 6 ||
        fac_tensor_get(gradient, 2, 1) != 1.0)
      return fail("tensor backward committed an incorrect gradient");
    fac_tensor_free(gradient);
    fac_autograd_tensor_free(tape);
  }
  if (!backwardFailures || !backwardSuccesses)
    return fail("tensor backward fail points were not exercised");

  // Scalar backward's one-vector workspace has the same retry/commit guarantee.
  auto *scalar = static_cast<FacGradTape *>(fac_autograd_create());
  if (!scalar) return fail("create scalar backward tape");
  const int32_t a = fac_autograd_variable(scalar, 2.0);
  const int32_t b = fac_autograd_add(scalar, a, a);
  const int scalarBackwardError = capture_error([&] {
    g_fail_after.store(0, std::memory_order_relaxed);
    fac_autograd_backward(scalar, b);
    g_fail_after.store(-1, std::memory_order_relaxed);
  });
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (scalarBackwardError != 5 && scalarBackwardError != 14)
    return fail("scalar backward first allocation was not injected");
  if (fac_autograd_grad(scalar, a) != 0.0)
    return fail("scalar backward partially committed gradient after OOM");
  if (capture_error([&] { fac_autograd_backward(scalar, b); }) != 0 ||
      fac_autograd_grad(scalar, a) != 2.0)
    return fail("scalar backward could not retry after allocation failure");
  fac_autograd_free(scalar);
  if (!cleanup_stack_is_empty()) return fail("final cleanup stack is not empty");

  fac_tensor_free(ylog);
  fac_tensor_free(y);
  fac_tensor_free(x);
  std::puts("PASS ML model/workspace rollback / KNN vote OOM / scalar+tensor autograd atomic append and backward retry");
  return 0;
}
