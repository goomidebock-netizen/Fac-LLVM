#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <vector>

extern "C" void fac_parallel_for(int32_t, void *);
extern "C" void fac_try_enter(void *);
extern "C" void fac_try_leave();
extern "C" int32_t fac_err_code();
extern "C" [[noreturn]] void fac_throw(void *, int32_t);
extern "C" void fac_cleanup_push(void *, int32_t, void *);

struct State {
  void *entry;
  std::vector<std::atomic<int>> visits;
  std::atomic<int> completed{0};
  explicit State(int n) : entry(reinterpret_cast<void *>(run)), visits((size_t)n) {
    for (auto &v : visits) v.store(0, std::memory_order_relaxed);
  }
  static void run(void *opaque, int32_t index) {
    auto *state = static_cast<State *>(opaque);
    if (index < 0 || (size_t)index >= state->visits.size()) return;
    state->visits[(size_t)index].fetch_add(1, std::memory_order_relaxed);
    state->completed.fetch_add(1, std::memory_order_relaxed);
  }
};

struct ThrowState {
  void *entry;
  static void run(void *, int32_t) { throw std::runtime_error("expected callback failure"); }
  ThrowState() : entry(reinterpret_cast<void *>(run)) {}
};

struct FacThrowState {
  void *entry;
  std::atomic<int> *cleaned;
  static void cleanup(void *slot) {
    auto *out = static_cast<std::atomic<int> **>(slot);
    (*out)->fetch_add(1, std::memory_order_relaxed);
  }
  static void run(void *opaque, int32_t index) {
    if (index != 0) return;
    auto *state = static_cast<FacThrowState *>(opaque);
    fac_cleanup_push(&state->cleaned, 4, reinterpret_cast<void *>(cleanup));
    fac_throw(nullptr, 17);
  }
  explicit FacThrowState(std::atomic<int> *out)
      : entry(reinterpret_cast<void *>(run)), cleaned(out) {}
};

static int run_fac_throwing(FacThrowState *state) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_parallel_for(64, state);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

int main(int argc, char **argv) {
  if (argc > 1) {
    const char *mode = argv[1];
    if (std::strcmp(mode, "throw") == 0) {
      ThrowState throwing;
      fac_parallel_for(64, &throwing);
      std::fprintf(stderr, "FAIL: callback exception was not propagated\n");
      return 1;
    }
    if (std::strcmp(mode, "null") == 0) {
      fac_parallel_for(1, nullptr);
      std::fprintf(stderr, "FAIL: null closure was accepted\n");
      return 1;
    }
    if (std::strcmp(mode, "no-entry") == 0) {
      void *emptyClosure = nullptr;
      fac_parallel_for(1, &emptyClosure);
      std::fprintf(stderr, "FAIL: null closure entry was accepted\n");
      return 1;
    }
    if (std::strcmp(mode, "negative") == 0) {
      fac_parallel_for(-1, nullptr);
      return 0;
    }
  }

  // Empty/non-positive work must not inspect or invoke the closure.
  fac_parallel_for(0, nullptr);
  fac_parallel_for(-1, nullptr);

  State one(1);
  fac_parallel_for(1, &one);
  if (one.completed.load(std::memory_order_relaxed) != 1 ||
      one.visits[0].load(std::memory_order_relaxed) != 1) {
    std::fprintf(stderr, "FAIL: single-item parallel loop\n");
    return 1;
  }

  constexpr int count = 10000;
  State many(count);
  fac_parallel_for(count, &many);
  if (many.completed.load(std::memory_order_relaxed) != count) {
    std::fprintf(stderr, "FAIL: expected %d callbacks, got %d\n", count,
                 many.completed.load(std::memory_order_relaxed));
    return 1;
  }
  for (int i = 0; i < count; ++i) {
    if (many.visits[(size_t)i].load(std::memory_order_relaxed) != 1) {
      std::fprintf(stderr, "FAIL: work index %d was not executed exactly once\n", i);
      return 1;
    }
  }

  std::atomic<int> cleaned{0};
  FacThrowState facThrow(&cleaned);
  constexpr int facErrorRounds = 8;
  for (int i = 0; i < facErrorRounds; ++i) {
    if (run_fac_throwing(&facThrow) != 17) {
      std::fprintf(stderr, "FAIL: FAC callback error code was not propagated by parallelFor at round %d\n", i);
      return 1;
    }
  }
  if (cleaned.load(std::memory_order_relaxed) != facErrorRounds) {
    std::fprintf(stderr, "FAIL: worker FAC cleanup count mismatch (%d != %d)\n",
                 cleaned.load(std::memory_order_relaxed), facErrorRounds);
    return 1;
  }

  std::puts("PASS parallelFor exact-once scheduling, empty input, C++/FAC error propagation, repeated worker cleanup and joining");
  return 0;
}
