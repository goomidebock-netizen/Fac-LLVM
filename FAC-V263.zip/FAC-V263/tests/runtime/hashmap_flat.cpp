#include <cstdint>
#include <cstdio>
#include <vector>

extern "C" {
struct FacList { void *data; int64_t len, cap; int32_t esz, ek; void (*dropFn)(void *); void (*copyFn)(void *, const void *); };
void *fac_hm_new(int32_t, int32_t, int32_t, int32_t);
void fac_hm_set(void *, const void *, const void *);
void fac_hm_get(void *, const void *, void *);
int32_t fac_hm_has(void *, const void *);
void fac_hm_remove(void *, const void *);
void *fac_ds_copy(void *);
int64_t fac_ds_len(void *);
void fac_ds_free(void *);
FacList *fac_hm_keys(void *);
FacList *fac_hm_values(void *);
void fac_list_free(FacList *);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  constexpr int32_t COUNT = 100000;
  void *map = fac_hm_new(3, sizeof(int32_t), 3, sizeof(int32_t));
  std::vector<int32_t> keys;
  keys.reserve(COUNT);

  // Multiplicative permutation exercises keys with varied high/low bits.
  for (int32_t i = 0; i < COUNT; ++i) {
    const int32_t key = i * 2654435761u;
    const int32_t value = key ^ 0x5a5a5a5a;
    keys.push_back(key);
    fac_hm_set(map, &key, &value);
  }
  if (fac_ds_len(map) != COUNT) return fail("wrong count after bulk insertion/rehash");

  for (int32_t i = 0; i < COUNT; ++i) {
    const int32_t key = keys[(size_t)i];
    const int32_t expected = key ^ 0x5a5a5a5a;
    int32_t actual = 0;
    if (!fac_hm_has(map, &key)) return fail("missing key after bulk insertion");
    fac_hm_get(map, &key, &actual);
    if (actual != expected) return fail("incorrect value after bulk insertion");
  }

  // Delete a large fraction, forcing table tombstones and item compaction.
  for (int32_t i = 0; i < COUNT; i += 3) fac_hm_remove(map, &keys[(size_t)i]);
  if (fac_ds_len(map) != COUNT - (COUNT + 2) / 3)
    return fail("wrong count after bulk removals");
  for (int32_t i = 0; i < COUNT; ++i) {
    const bool shouldExist = i % 3 != 0;
    const int32_t key = keys[(size_t)i];
    if ((fac_hm_has(map, &key) != 0) != shouldExist)
      return fail("lookup failed after tombstone compaction");
  }

  // Reinsert removed keys and update existing keys after a second growth cycle.
  for (int32_t i = 0; i < COUNT; i += 3) {
    const int32_t key = keys[(size_t)i];
    const int32_t value = -key;
    fac_hm_set(map, &key, &value);
  }
  for (int32_t i = 1; i < COUNT; i += 5) {
    const int32_t key = keys[(size_t)i];
    const int32_t value = key + 123;
    fac_hm_set(map, &key, &value);
  }
  if (fac_ds_len(map) != COUNT) return fail("wrong count after delete/reinsert/update");

  void *copy = fac_ds_copy(map);
  if (!copy || fac_ds_len(copy) != COUNT) return fail("clone lost entries");
  for (int32_t i = 0; i < COUNT; ++i) {
    const int32_t key = keys[(size_t)i];
    int32_t actual = 0;
    fac_hm_get(copy, &key, &actual);
    int32_t expected = (i % 3 == 0) ? -key : key ^ 0x5a5a5a5a;
    if (i % 5 == 1) expected = key + 123;
    if (actual != expected) return fail("clone mismatch after mixed updates");
  }

  fac_ds_free(copy);
  fac_ds_free(map);

  // Keep the language's insertion-order iteration contract across removal and
  // reinsertion, including when an earlier item slot has become a tombstone.
  void *ordered = fac_hm_new(3, sizeof(int32_t), 3, sizeof(int32_t));
  const int32_t initialKeys[] = {7, 2, 9};
  for (int32_t key : initialKeys) { const int32_t value = key * 10; fac_hm_set(ordered, &key, &value); }
  const int32_t removedKey = 2;
  fac_hm_remove(ordered, &removedKey);
  const int32_t replacementValue = 22;
  fac_hm_set(ordered, &removedKey, &replacementValue);
  const int32_t expectedKeys[] = {7, 9, 2};
  const int32_t expectedValues[] = {70, 90, 22};
  FacList *keyList = fac_hm_keys(ordered);
  FacList *valueList = fac_hm_values(ordered);
  if (!keyList || !valueList || keyList->len != 3 || valueList->len != 3)
    return fail("ordered key/value iteration length changed");
  const auto *actualKeys = static_cast<const int32_t *>(keyList->data);
  const auto *actualValues = static_cast<const int32_t *>(valueList->data);
  for (int i = 0; i < 3; ++i) {
    if (actualKeys[i] != expectedKeys[i] || actualValues[i] != expectedValues[i])
      return fail("key/value iteration no longer preserves insertion order");
  }
  fac_list_free(keyList); fac_list_free(valueList); fac_ds_free(ordered);
  std::puts("PASS HashMap flat index growth/collisions/tombstones/compaction/clone/order");
  return 0;
}
