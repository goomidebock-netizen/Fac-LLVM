// sync.Channel runtime: FIFO order, bounded back-pressure, timeouts, close/drain semantics, many producers/consumers.
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>
#include <thread>
#include <vector>
extern "C" {
void *fac_sync_chan_new(int32_t); int32_t fac_sync_chan_send(void *, const char *, int32_t);
char *fac_sync_chan_recv(void *, int32_t); void fac_sync_str_free(char *); void fac_sync_chan_close(void *);
int32_t fac_sync_chan_done(void *); int32_t fac_sync_chan_len(void *); void fac_sync_chan_free(void *);
}
#define CHECK(c) do { if (!(c)) { std::fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #c); return 1; } } while (0)
static std::string take(void *ch, int t) { char *p = fac_sync_chan_recv(ch, t); if (!p) return "<null>"; std::string s(p); fac_sync_str_free(p); return s; }

int main() {
  { // FIFO, capacity clamp, timeouts on empty / full
    void *c = fac_sync_chan_new(2);
    CHECK(take(c, 10) == "<null>");                       // empty: timeout
    CHECK(fac_sync_chan_send(c, "a", 0) == 1); CHECK(fac_sync_chan_send(c, "b", 0) == 1);
    CHECK(fac_sync_chan_send(c, "c", 20) == 0);            // full: timeout, nothing queued
    CHECK(fac_sync_chan_len(c) == 2);
    CHECK(take(c, 0) == "a"); CHECK(take(c, 0) == "b"); CHECK(fac_sync_chan_len(c) == 0);
    CHECK(fac_sync_chan_send(c, nullptr, 0) == 0); CHECK(fac_sync_chan_send(nullptr, "x", 0) == 0);
    CHECK(fac_sync_chan_recv(nullptr, 0) == nullptr);
    fac_sync_chan_free(c);
    void *z = fac_sync_chan_new(-5);                       // clamped to 1
    CHECK(fac_sync_chan_send(z, "only", 0) == 1); CHECK(fac_sync_chan_send(z, "no", 0) == 0);
    fac_sync_chan_free(z);
  }
  { // close: queued messages drain, then done; send fails; blocked waiters are released
    void *c = fac_sync_chan_new(4);
    CHECK(fac_sync_chan_send(c, "x", 0) == 1);
    CHECK(fac_sync_chan_done(c) == 0);
    fac_sync_chan_close(c);
    CHECK(fac_sync_chan_done(c) == 0);                     // closed but not yet drained
    CHECK(fac_sync_chan_send(c, "y", 0) == 0);
    CHECK(take(c, -1) == "x");
    CHECK(fac_sync_chan_done(c) == 1);
    CHECK(take(c, -1) == "<null>");                        // would block forever if close did not wake
    fac_sync_chan_free(c);
    void *w = fac_sync_chan_new(1); std::string got;
    std::thread t([&] { got = take(w, -1); });
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    fac_sync_chan_close(w); t.join();
    CHECK(got == "<null>");
    fac_sync_chan_free(w);
  }
  { // 4 producers x 5000 messages, 3 consumers, capacity 8: nothing lost, nothing duplicated, per-producer order kept
    void *c = fac_sync_chan_new(8);
    const int P = 4, N = 5000, C = 3;
    std::vector<std::thread> ps, cs; std::vector<std::vector<std::string>> out(C);
    for (int i = 0; i < C; i++) cs.emplace_back([&, i] { for (;;) { char *p = fac_sync_chan_recv(c, -1); if (!p) break; out[i].push_back(p); fac_sync_str_free(p); } });
    for (int p = 0; p < P; p++) ps.emplace_back([&, p] { for (int n = 0; n < N; n++) { std::string m = std::to_string(p) + ":" + std::to_string(n); while (!fac_sync_chan_send(c, m.c_str(), -1)) {} } });
    for (auto &t : ps) t.join();
    fac_sync_chan_close(c);
    for (auto &t : cs) t.join();
    std::set<std::string> all; size_t total = 0; std::vector<int> last(P, -1);
    for (auto &v : out) { int lastSeen[P]; for (int i = 0; i < P; i++) lastSeen[i] = -1;
      for (auto &m : v) { total++; all.insert(m); int p = std::atoi(m.c_str()); int n = std::atoi(m.c_str() + m.find(':') + 1); CHECK(n > lastSeen[p]); lastSeen[p] = n; } }
    CHECK(total == (size_t)P * N); CHECK(all.size() == total); CHECK(fac_sync_chan_done(c) == 1);
    fac_sync_chan_free(c);
  }
  std::puts("sync_chan ok");
  return 0;
}
