#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <thread>

extern "C" void *fac_thread_start(void *closure);
extern "C" void fac_thread_join(void *handle);
extern "C" void fac_try_enter(void *jumpBuffer);
extern "C" void fac_try_leave();
extern "C" int32_t fac_err_code();
extern "C" int32_t fac_thread_cancel(void *handle);
extern "C" int32_t fac_thread_cancelled();
extern "C" int32_t fac_thread_is_done(void *handle);
extern "C" int32_t fac_thread_is_cancelled(void *handle);
extern "C" [[noreturn]] void fac_throw(void *message, int32_t code);

struct ClosureHeader { void *entry; int64_t refs; void (*drop)(void *); };

struct CooperativeClosure {
  ClosureHeader header;
  std::atomic<bool> started{false};
  std::atomic<int> polls{0};
  std::atomic<bool> observed{false};
  static void run(void *opaque) {
    auto *self = static_cast<CooperativeClosure *>(opaque);
    self->started.store(true, std::memory_order_release);
    while (!fac_thread_cancelled()) {
      self->polls.fetch_add(1, std::memory_order_relaxed);
      std::this_thread::yield();
    }
    self->observed.store(true, std::memory_order_release);
  }
  CooperativeClosure() : header{reinterpret_cast<void *>(run), -1, nullptr} {}
};

struct NonPollingClosure {
  ClosureHeader header;
  std::atomic<bool> started{false};
  std::atomic<bool> release{false};
  static void run(void *opaque) {
    auto *self = static_cast<NonPollingClosure *>(opaque);
    self->started.store(true, std::memory_order_release);
    while (!self->release.load(std::memory_order_acquire)) std::this_thread::yield();
  }
  NonPollingClosure() : header{reinterpret_cast<void *>(run), -1, nullptr} {}
};

struct ThrowAfterCancelClosure {
  ClosureHeader header;
  std::atomic<bool> started{false};
  static void run(void *opaque) {
    auto *self = static_cast<ThrowAfterCancelClosure *>(opaque);
    self->started.store(true, std::memory_order_release);
    while (!fac_thread_cancelled()) std::this_thread::yield();
    fac_throw(nullptr, 77);
  }
  ThrowAfterCancelClosure() : header{reinterpret_cast<void *>(run), -1, nullptr} {}
};

static bool wait_true(const std::atomic<bool> &value) {
  const auto end = std::chrono::steady_clock::now() + std::chrono::seconds(5);
  while (!value.load(std::memory_order_acquire)) {
    if (std::chrono::steady_clock::now() >= end) return false;
    std::this_thread::yield();
  }
  return true;
}
static bool wait_done(void *handle) {
  const auto end = std::chrono::steady_clock::now() + std::chrono::seconds(5);
  while (!fac_thread_is_done(handle)) {
    if (std::chrono::steady_clock::now() >= end) return false;
    std::this_thread::yield();
  }
  return true;
}

int main() {
  if (fac_thread_cancelled() || fac_thread_cancel(nullptr) ||
      fac_thread_is_done(nullptr) || fac_thread_is_cancelled(nullptr)) {
    std::fprintf(stderr, "FAIL null/outside-task cancellation query semantics\n");
    return 1;
  }

  // Cooperative task: cancellation is requested from the owner, observed by
  // the worker, and reflected in the terminal task state before join.
  CooperativeClosure cooperative;
  void *a = fac_thread_start(&cooperative);
  if (!wait_true(cooperative.started) || fac_thread_is_done(a)) {
    std::fprintf(stderr, "FAIL task did not enter Running state\n");
    return 1;
  }
  if (!fac_thread_cancel(a) || !fac_thread_cancel(a)) {
    std::fprintf(stderr, "FAIL active task did not accept cancellation request\n");
    return 1;
  }
  if (!wait_done(a) || !wait_true(cooperative.observed) || !fac_thread_is_cancelled(a)) {
    std::fprintf(stderr, "FAIL cooperative cancellation was not observed\n");
    return 1;
  }
  if (fac_thread_cancel(a)) {
    std::fprintf(stderr, "FAIL completed task accepted cancellation\n");
    return 1;
  }
  fac_thread_join(a);

  // Cancellation is not forced: a callback that never polls completes normally.
  NonPollingClosure nonPolling;
  void *b = fac_thread_start(&nonPolling);
  if (!wait_true(nonPolling.started) || !fac_thread_cancel(b)) {
    std::fprintf(stderr, "FAIL non-polling task did not accept request\n");
    return 1;
  }
  nonPolling.release.store(true, std::memory_order_release);
  if (!wait_done(b) || fac_thread_is_cancelled(b)) {
    std::fprintf(stderr, "FAIL non-cooperative callback was incorrectly marked cancelled\n");
    return 1;
  }
  fac_thread_join(b);

  // A worker error remains Failed even when it first observed cancellation.
  ThrowAfterCancelClosure throwing;
  void *c = fac_thread_start(&throwing);
  if (!wait_true(throwing.started) || !fac_thread_cancel(c)) {
    std::fprintf(stderr, "FAIL error-precedence cancellation request failed\n");
    return 1;
  }
  if (!wait_done(c) || fac_thread_is_cancelled(c)) {
    std::fprintf(stderr, "FAIL failed task was reported as cancelled\n");
    return 1;
  }
  int32_t errorCode = 0;
  // Catch the FAC error from join at a worker-independent boundary.
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_thread_join(c);
    fac_try_leave();
    std::fprintf(stderr, "FAIL join did not propagate worker error\n");
    return 1;
  } else {
    errorCode = fac_err_code();
  }
  if (errorCode != 77) {
    std::fprintf(stderr, "FAIL worker error code changed: %d\n", errorCode);
    return 1;
  }

  std::puts("PASS task lifecycle, cooperative cancellation, non-cooperative completion and error precedence");
  return 0;
}
