// V218: stable opaque file tokens prevent stale aliases from becoming valid
// after close/reopen, while per-handle locking serializes I/O and close.
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_set>
#include <vector>

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
void fac_try_enter(void *);
void fac_try_leave();
int32_t fac_err_code();
void *fac_file_open(FacStr *, FacStr *);
FacStr *fac_file_readline(void *);
FacStr *fac_file_readall(void *);
void fac_file_write(void *, FacStr *);
void fac_file_writeline(void *, FacStr *);
void fac_file_flush(void *);
int32_t fac_file_eof(void *);
void fac_file_close(void *);
uint64_t fac_file_live_handles();
}

template <typename F>
static int32_t capture_fac(F fn) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fn();
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static FacStr *str(const std::string &s) {
  return fac_str_from_chars(s.data(), (int64_t)s.size());
}
static void *open_file(const std::filesystem::path &path, const char *mode) {
  const std::string pathText = path.string();
  FacStr *p = str(pathText);
  FacStr *m = str(std::string(mode));
  void *handle = fac_file_open(p, m);
  fac_str_free(p);
  fac_str_free(m);
  return handle;
}
static int fail(const char *message) {
  std::fprintf(stderr, "FAIL file handle lifetime: %s\n", message);
  return 1;
}

int main() {
  const auto nonce = std::chrono::steady_clock::now().time_since_epoch().count();
  const auto base = std::filesystem::temp_directory_path() /
      ("fac-file-handle-v218-" + std::to_string((long long)nonce));
  const auto concurrentPath = base.string() + "-concurrent.txt";
  const auto racePath = base.string() + "-race.txt";
  const auto firstPath = base.string() + "-first.txt";
  const auto secondPath = base.string() + "-second.txt";
  const uint64_t baselineLive = fac_file_live_handles();

  // Multiple threads write whole lines through one opaque handle. Each
  // writeLine call must be atomic with respect to all other file operations.
  void *shared = open_file(concurrentPath, "wb");
  if (!shared || fac_file_live_handles() != baselineLive + 1) return fail("open increments live handle count");
  constexpr int kThreads = 8;
  constexpr int kLines = 180;
  std::atomic<int> writeErrors{0};
  std::vector<std::thread> writers;
  for (int t = 0; t < kThreads; ++t) {
    writers.emplace_back([&, t] {
      for (int i = 0; i < kLines; ++i) {
        const std::string line = std::to_string(t) + ":" + std::to_string(i);
        FacStr *value = str(line);
        const int32_t error = capture_fac([&] { fac_file_writeline(shared, value); });
        fac_str_free(value);
        if (error != 0) writeErrors.fetch_add(1, std::memory_order_relaxed);
      }
    });
  }
  for (auto &writer : writers) writer.join();
  if (writeErrors.load() != 0) return fail("concurrent writes on one handle returned errors");
  if (capture_fac([&] { fac_file_flush(shared); }) != 0) return fail("flush after concurrent writes");
  fac_file_close(shared);
  if (fac_file_live_handles() != baselineLive) return fail("close decrements live handle count exactly once");

  // Concurrent readers also share one cursor: records are serialized and each
  // complete line is delivered to exactly one reader.
  void *reader = open_file(concurrentPath, "rb");
  if (!reader) return fail("open concurrent output for reading");
  std::mutex linesMutex;
  std::vector<std::string> lines;
  lines.reserve(kThreads * kLines);
  std::atomic<int> readErrors{0};
  std::vector<std::thread> readers;
  for (int t = 0; t < kThreads; ++t) {
    readers.emplace_back([&] {
      for (;;) {
        FacStr *value = nullptr;
        const int32_t error = capture_fac([&] { value = fac_file_readline(reader); });
        if (error != 0) { readErrors.fetch_add(1, std::memory_order_relaxed); break; }
        if (!value) { readErrors.fetch_add(1, std::memory_order_relaxed); break; }
        if (value->len == 0) { fac_str_free(value); break; }
        std::string line(value->data, (size_t)value->len);
        fac_str_free(value);
        std::lock_guard<std::mutex> lock(linesMutex);
        lines.push_back(std::move(line));
      }
    });
  }
  for (auto &readerThread : readers) readerThread.join();
  if (readErrors.load() != 0) return fail("concurrent readers on one handle returned errors");
  if (lines.size() != (size_t)kThreads * kLines) return fail("concurrent readers lost or duplicated lines");
  std::unordered_set<std::string> unique(lines.begin(), lines.end());
  if (unique.size() != lines.size()) return fail("concurrent readers returned duplicate lines");
  if (fac_file_eof(reader) != 1) return fail("EOF reports true after all shared reads");
  fac_file_close(reader);

  // Close races with readLine. The operation that acquires the per-handle
  // mutex first may complete; later operations must receive Io (7), never UAF.
  {
    FILE *native = std::fopen(racePath.c_str(), "wb");
    if (!native) return fail("create close-race input");
    for (int i = 0; i < 20000; ++i) std::fputs("payload-line-for-close-race\n", native);
    std::fclose(native);
  }
  void *racing = open_file(racePath, "rb");
  if (!racing) return fail("open close-race input");
  std::atomic<int> raceUnexpected{0};
  std::thread racingReader([&] {
    for (int i = 0; i < 50000; ++i) {
      FacStr *value = nullptr;
      const int32_t error = capture_fac([&] { value = fac_file_readline(racing); });
      if (error == 7) break;
      if (error != 0 || !value) { raceUnexpected.fetch_add(1); break; }
      fac_str_free(value);
    }
  });
  std::vector<std::thread> racingClosers;
  for (int i = 0; i < 8; ++i) {
    racingClosers.emplace_back([&, i] {
      if (i == 0) std::this_thread::sleep_for(std::chrono::milliseconds(1));
      fac_file_close(racing);
    });
  }
  racingReader.join();
  for (auto &closer : racingClosers) closer.join();
  if (raceUnexpected.load() != 0) return fail("close race produced an unexpected failure");
  if (fac_file_live_handles() != baselineLive) return fail("concurrent close decremented live count exactly once");

  // A closed token remains a tombstone. Reopening a file must produce a new
  // token, and stale read/write/flush/eof/close calls must not touch it.
  void *stale = open_file(firstPath, "wb");
  if (!stale) return fail("open first token");
  fac_file_close(stale);
  void *fresh = open_file(secondPath, "wb");
  if (!fresh || fresh == stale) return fail("reopened stream reuses a stale opaque token");
  const uint64_t liveWithFresh = fac_file_live_handles();
  FacStr *payload = str("fresh-token");
  if (capture_fac([&] { fac_file_write(stale, payload); }) != 7) return fail("stale write is rejected with Io (7)");
  if (capture_fac([&] { fac_file_writeline(stale, payload); }) != 7) return fail("stale writeLine is rejected with Io (7)");
  if (capture_fac([&] { (void)fac_file_readline(stale); }) != 7) return fail("stale readLine is rejected with Io (7)");
  if (capture_fac([&] { (void)fac_file_readall(stale); }) != 7) return fail("stale readAll is rejected with Io (7)");
  if (capture_fac([&] { fac_file_flush(stale); }) != 7) return fail("stale flush is rejected with Io (7)");
  if (capture_fac([&] { (void)fac_file_eof(stale); }) != 7) return fail("stale eof is rejected with Io (7)");
  fac_file_close(stale); // repeated stale close is harmless and isolated
  if (fac_file_live_handles() != liveWithFresh) return fail("stale close does not change live count");
  if (capture_fac([&] { fac_file_write(fresh, payload); }) != 0) return fail("fresh token remains usable after stale calls");
  fac_str_free(payload);
  fac_file_close(fresh);
  fac_file_close(fresh);
  if (fac_file_live_handles() != baselineLive) return fail("repeated close is idempotent");

  // Open/close cycles must never recycle an opaque token while any stale alias
  // could still be held by native or FAC code.
  std::unordered_set<void *> issuedTokens;
  for (int i = 0; i < 256; ++i) {
    const auto path = base.string() + "-cycle-" + std::to_string(i);
    void *token = open_file(path, "wb");
    if (!token || !issuedTokens.insert(token).second) return fail("opaque token address was reused");
    fac_file_close(token);
    std::error_code removeError;
    std::filesystem::remove(path, removeError);
  }
  if (fac_file_live_handles() != baselineLive) return fail("open/close cycle leaked active handles");

  std::error_code ec;
  std::filesystem::remove(concurrentPath, ec);
  std::filesystem::remove(racePath, ec);
  std::filesystem::remove(firstPath, ec);
  std::filesystem::remove(secondPath, ec);
  std::puts("PASS file handle lifetime / per-handle I/O serialization / stale token rejection");
  return 0;
}
