#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <string>
#include <vector>
#include <fstream>
#include <filesystem>
#include <limits>
#ifndef _WIN32
#include <fcntl.h>
#include <unistd.h>
#endif

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct JV;
struct Canvas;
struct FacAudioClip;
struct Sock;
FacStr *fac_cstr_new(const char *);
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
int32_t fac_err_code();
void fac_try_enter(void *);
void fac_try_leave();

int64_t fac_gcd(int64_t, int64_t);
int64_t fac_lcm(int64_t, int64_t);
int64_t fac_pmod(int64_t, int64_t);
double fac_rand_gauss(double, double);
FacStr *fac_time_iso(int64_t);

JV *fac_jd_parse(FacStr *);
void fac_jd_free(JV *);
int32_t fac_json_valid(FacStr *);
JV *fac_json_array();
JV *fac_json_object();
JV *fac_json_newint(int64_t);
void fac_json_push(JV *, JV *);
void fac_json_set(JV *, FacStr *, JV *);
void *fac_tensor_create(int32_t, int32_t);
void fac_tensor_set(void *, int32_t, int32_t, double);
void fac_tensor_free(void *);
void *fac_ml_linear_fit(void *, void *, double, int32_t);
void *fac_ml_kmeans(void *, int32_t, int32_t, int64_t);
void fac_ml_free_model(void *);
void fac_ml_free_kmeans(void *);

Canvas *fac_gfx_load(FacStr *);
void fac_gfx_free(Canvas *);
int32_t fac_gfx_width(Canvas *);
int32_t fac_gfx_height(Canvas *);
uint32_t fac_gfx_get(Canvas *, int32_t, int32_t);
void fac_gfx_rect(Canvas *, int32_t, int32_t, int32_t, int32_t, int32_t);
void fac_gfx_circle(Canvas *, int32_t, int32_t, int32_t, int32_t);
void fac_gfx_fillcircle(Canvas *, int32_t, int32_t, int32_t, int32_t);
void fac_gfx_filltri(Canvas *, int32_t, int32_t, int32_t, int32_t, int32_t, int32_t, int32_t);
uint32_t fac_gfx_hsv(double, double, double);
void fac_gfx_clear(Canvas *, int32_t);
void fac_gfx_pixel(Canvas *, int32_t, int32_t, int32_t);
uint32_t fac_gfx_get(Canvas *, int32_t, int32_t);
int32_t fac_gfx_width(Canvas *);
int32_t fac_gfx_height(Canvas *);
void fac_gfx_fillrect(Canvas *, int32_t, int32_t, int32_t, int32_t, int32_t);
void fac_gfx_blit(Canvas *, Canvas *, int32_t, int32_t);
void fac_gfx_blitkey(Canvas *, Canvas *, int32_t, int32_t, int32_t);
void fac_gfx_blitscaled(Canvas *, Canvas *, int32_t, int32_t, int32_t, int32_t);
void fac_gfx_blend(Canvas *, int32_t, int32_t, int32_t, int32_t);

void fac_file_writeall(FacStr *, FacStr *);
void *fac_file_open(FacStr *, FacStr *);
void fac_file_close(void *);
FacStr *fac_file_readall(void *);
FacStr *fac_sys_output(FacStr *);
Sock *fac_net_connect(FacStr *, int32_t);
Canvas *fac_gfx_create(int32_t, int32_t);
void fac_audio_savewav(FacAudioClip *, FacStr *);
FacAudioClip *fac_audio_create(int32_t, int32_t, int64_t);
void fac_audio_free(FacAudioClip *);
FacStr *fac_crypto_sha256file(FacStr *);
FacStr *fac_crypto_pbkdf2(FacStr *, FacStr *, int32_t, int32_t);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

template <typename F>
static int32_t catch_fac(F fn) {
  void *jb[5]{};
  fac_try_enter(jb);
  if (__builtin_setjmp(jb) == 0) {
    fn();
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static FacStr *fs(const std::string &s) { return fac_str_from_chars(s.data(), (int64_t)s.size()); }
static bool parse_throws(const std::string &text, int32_t expected) {
  FacStr *s = fs(text);
  const int32_t code = catch_fac([&] { JV *v = fac_jd_parse(s); fac_jd_free(v); });
  fac_str_free(s);
  return code == expected;
}
static bool image_throws(const std::filesystem::path &path, int32_t expected) {
  FacStr *s = fac_cstr_new(path.string().c_str());
  const int32_t code = catch_fac([&] { Canvas *c = fac_gfx_load(s); fac_gfx_free(c); });
  fac_str_free(s);
  return code == expected;
}
static void put16(std::vector<uint8_t> &v, size_t at, uint16_t x) {
  v[at] = (uint8_t)x; v[at + 1] = (uint8_t)(x >> 8);
}
static void put32(std::vector<uint8_t> &v, size_t at, uint32_t x) {
  for (int i = 0; i < 4; ++i) v[at + (size_t)i] = (uint8_t)(x >> (8 * i));
}
static std::vector<uint8_t> bmp1x1(uint32_t heightBits, bool includePixel) {
  std::vector<uint8_t> v(includePixel ? 58 : 54, 0);
  v[0] = 'B'; v[1] = 'M'; put32(v, 2, (uint32_t)v.size()); put32(v, 10, 54); put32(v, 14, 40);
  put32(v, 18, 1); put32(v, 22, heightBits); put16(v, 26, 1); put16(v, 28, 24); put32(v, 30, 0);
  if (includePixel) { v[54] = 0x33; v[55] = 0x22; v[56] = 0x11; v[57] = 0; }
  return v;
}
static bool write_bytes(const std::filesystem::path &p, const std::vector<uint8_t> &v) {
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  if (!f) return false;
  f.write((const char *)v.data(), (std::streamsize)v.size());
  return f.good();
}

int main() {
  // Integer edge cases: no signed negation/modulo overflow at INT64_MIN.
  if (fac_pmod(-5, INT64_MIN) != INT64_C(9223372036854775803)) return fail("pmod(-5, INT64_MIN) is incorrect");
  if (fac_pmod(INT64_MIN, -3) != 1) return fail("pmod(INT64_MIN, -3) is incorrect");
  if (fac_pmod(INT64_MIN, -1) != 0) return fail("pmod(INT64_MIN, -1) is incorrect");
  if (fac_gcd(54, -24) != 6 || fac_lcm(-21, 6) != 42) return fail("ordinary gcd/lcm regression");
  if (catch_fac([] { (void)fac_gcd(INT64_MIN, 0); }) != 8) return fail("gcd must report an unrepresentable INT64_MIN result");
  if (catch_fac([] { (void)fac_lcm(INT64_MIN, 1); }) != 8) return fail("lcm must detect signed result overflow");
  // std::normal_distribution requires a positive standard deviation.
  if (fac_rand_gauss(3.25, 0.0) != 3.25) return fail("gauss with zero deviation should return the mean");
  if (catch_fac([] { (void)fac_rand_gauss(0.0, -1.0); }) != 8) return fail("gauss must reject a negative deviation");
  if (catch_fac([] { (void)fac_rand_gauss(std::numeric_limits<double>::infinity(), 1.0); }) != 8)
    return fail("gauss must reject non-finite parameters");
  FacStr *extremeTime = nullptr;
  const int32_t timeCode = catch_fac([&] { extremeTime = fac_time_iso(INT64_MIN); });
  if (timeCode != 0 && timeCode != 12) return fail("extreme timestamp returned an unexpected FAC error");
  if (extremeTime) fac_str_free(extremeTime);
  // Strict JSON grammar, exact escapes, and safe ownership on parser errors.
  const std::string good = R"({"n":-12.5e+2,"z":0,"s":"a\tb","emoji":"\uD83D\uDE00"})";
  FacStr *goodS = fs(good);
  if (!fac_json_valid(goodS)) return fail("valid JSON rejected");
  JV *goodTree = fac_jd_parse(goodS);
  fac_jd_free(goodTree); fac_str_free(goodS);
  // Explicit malformed cases: fac_json_valid must return false and parse must throw Error(10).
  const std::vector<std::string> malformed = {"01", "+1", ".5", "1.", "1e", "1e+", "1+2", "--1", "\"x\\q\"", "\"\\uD800\"", "\"\\uDC00\""};
  for (const auto &text : malformed) {
    FacStr *s = fs(text);
    const bool valid = fac_json_valid(s) != 0;
    fac_str_free(s);
    if (valid || !parse_throws(text, 10)) return fail((std::string("invalid JSON accepted: ") + text).c_str());
  }
  std::string control = "\"a"; control.push_back('\x01'); control += "b\"";
  FacStr *controlS = fs(control);
  const bool controlOk = fac_json_valid(controlS) != 0; fac_str_free(controlS);
  if (controlOk || !parse_throws(control, 10)) return fail("JSON unescaped control character accepted");
  // JSON builder enforces single-parent ownership and rejects cycles.
  JV *rootArray = fac_json_array();
  JV *childArray = fac_json_array();
  fac_json_push(rootArray, childArray);
  if (catch_fac([&] { fac_json_push(rootArray, childArray); }) != 10)
    return fail("JSON builder allowed one child node to have multiple owners");
  if (catch_fac([&] { fac_json_push(childArray, rootArray); }) != 10)
    return fail("JSON builder allowed a parent/descendant cycle");
  fac_jd_free(rootArray);
  JV *rootObject = fac_json_object();
  JV *valueNode = fac_json_newint(7);
  FacStr *jsonKey = fac_cstr_new("value");
  fac_json_set(rootObject, jsonKey, valueNode);
  if (catch_fac([&] { fac_json_set(rootObject, jsonKey, valueNode); }) != 0)
    return fail("JSON builder same-key idempotent set unexpectedly failed");
  fac_jd_free(rootObject); fac_str_free(jsonKey);
  // ML workloads are bounded before entering long-running CPU loops.
  void *xTensor = fac_tensor_create(2, 2), *yTensor = fac_tensor_create(2, 1);
  fac_tensor_set(xTensor, 0, 0, 1.0); fac_tensor_set(xTensor, 0, 1, 2.0);
  fac_tensor_set(xTensor, 1, 0, 3.0); fac_tensor_set(xTensor, 1, 1, 4.0);
  fac_tensor_set(yTensor, 0, 0, 1.0); fac_tensor_set(yTensor, 1, 0, 0.0);
  if (catch_fac([&] { (void)fac_ml_linear_fit(xTensor, yTensor, 0.01, INT32_MAX); }) != 18)
    return fail("ML linear fit did not enforce work budget");
  if (catch_fac([&] { (void)fac_ml_kmeans(xTensor, 2, INT32_MAX, 1); }) != 18)
    return fail("ML k-means did not enforce work budget");
  fac_tensor_free(xTensor); fac_tensor_free(yTensor);
  if (catch_fac([] { (void)fac_tensor_create(5000, 5000); }) != 8)
    return fail("tensor allocation limits must reject dimensions above the element cap");
  // Bounded PBKDF2 work factor.
  FacStr *pw = fac_cstr_new("password"), *salt = fac_cstr_new("salt");
  if (catch_fac([&] { FacStr *r = fac_crypto_pbkdf2(pw, salt, 10000001, 16); fac_str_free(r); }) != 13)
    return fail("PBKDF2 must reject excessive iteration counts");
  fac_str_free(pw); fac_str_free(salt);
  const auto dir = std::filesystem::temp_directory_path() / ("fac-v133-security-" + std::to_string(
#ifndef _WIN32
    (long long)getpid()
#else
    1LL
#endif
  ));
  std::filesystem::create_directories(dir);

  // Generic file reads must have a hard cap even for sparse/untrusted files.
  const auto oversizedPath = dir / "oversized-read.bin";
  FILE *oversized = std::fopen(oversizedPath.string().c_str(), "wb");
  if (oversized) {
    const bool wroteLargeFile = std::fseek(oversized, (long)((size_t)64 * 1024 * 1024), SEEK_SET) == 0 &&
                                std::fputc('x', oversized) != EOF;
    std::fclose(oversized);
    if (wroteLargeFile) {
      const std::string oversizedPathText = oversizedPath.string();
      FacStr *pathValue = fac_str_from_chars(oversizedPathText.data(), (int64_t)oversizedPathText.size());
      FacStr *modeValue = fac_cstr_new("rb");
      void *oversizedHandle = fac_file_open(pathValue, modeValue);
      const int32_t readCode = catch_fac([&] { FacStr *r = fac_file_readall(oversizedHandle); fac_str_free(r); });
      fac_file_close(oversizedHandle);
      fac_str_free(pathValue); fac_str_free(modeValue);
      if (readCode != 7) return fail("file.readAll did not enforce its 64 MiB resource limit");
    }
  }
  FacStr *emptyCommand = nullptr;
  if (catch_fac([&] { (void)fac_sys_output(emptyCommand); }) != 15)
    return fail("sys.output must reject a null command safely");
  if (catch_fac([] { (void)fac_net_connect(nullptr, 443); }) != 11)
    return fail("net.connect must reject a null host safely");
  if (catch_fac([] { (void)fac_gfx_create(5000, 5000); }) != 14)
    return fail("graphic.create must enforce the 16M pixel cap");

  // BMP signed-height overflow and truncated pixel payload must be rejected.
  const auto bmpMin = dir / "height-min.bmp";
  if (!write_bytes(bmpMin, bmp1x1(UINT32_C(0x80000000), false))) return fail("cannot create BMP fixture");
  if (!image_throws(bmpMin, 14)) return fail("BMP INT32_MIN height was not rejected");
  const auto bmpTruncated = dir / "truncated.bmp";
  if (!write_bytes(bmpTruncated, bmp1x1(1, false))) return fail("cannot create truncated BMP fixture");
  if (!image_throws(bmpTruncated, 14)) return fail("truncated BMP pixel data was accepted");
  // Valid BMP and PPM remain readable after hardening.
  const auto bmpValid = dir / "valid.bmp";
  if (!write_bytes(bmpValid, bmp1x1(1, true))) return fail("cannot create valid BMP fixture");
  FacStr *bmpPath = fac_cstr_new(bmpValid.string().c_str());
  Canvas *bmp = fac_gfx_load(bmpPath);
  if (!bmp || fac_gfx_width(bmp) != 1 || fac_gfx_height(bmp) != 1 || fac_gfx_get(bmp, 0, 0) != 0x112233)
    return fail("valid BMP pixel decode changed");
  fac_gfx_free(bmp); fac_str_free(bmpPath);

  const auto ppmValid = dir / "valid.ppm";
  std::vector<uint8_t> ppm = {'P','6','\n','1',' ','1','\n','2','5','5','\r','\n',0x10,0x20,0x30};
  if (!write_bytes(ppmValid, ppm)) return fail("cannot create valid PPM fixture");
  FacStr *ppmPath = fac_cstr_new(ppmValid.string().c_str());
  Canvas *pc = fac_gfx_load(ppmPath);
  if (!pc || fac_gfx_width(pc) != 1 || fac_gfx_height(pc) != 1 || fac_gfx_get(pc, 0, 0) != 0x102030)
    return fail("valid PPM pixel decode changed");
  fac_gfx_free(pc); fac_str_free(ppmPath);
  const auto ppmOverflow = dir / "overflow.ppm";
  const std::string ppmBad = "P6\n4294967296 1\n255\n";
  { std::ofstream f(ppmOverflow, std::ios::binary); f.write(ppmBad.data(), (std::streamsize)ppmBad.size()); }
  if (!image_throws(ppmOverflow, 14)) return fail("overflowing PPM dimensions were accepted");
  const auto ppmShort = dir / "short.ppm";
  const std::vector<uint8_t> ppmTrunc = {'P','6','\n','1',' ','1','\n','2','5','5','\n',0};
  if (!write_bytes(ppmShort, ppmTrunc)) return fail("cannot create short PPM fixture");
  if (!image_throws(ppmShort, 14)) return fail("truncated PPM raster was accepted");
  // Extreme coordinates must not trigger signed-overflow UB in raster primitives.
  Canvas *tiny = nullptr;
  FacStr *tinyPath = fac_cstr_new(ppmValid.string().c_str());
  tiny = fac_gfx_load(tinyPath); fac_str_free(tinyPath);
  fac_gfx_rect(tiny, INT32_MAX, INT32_MIN, INT32_MAX, INT32_MAX, 0xFFFFFF);
  fac_gfx_circle(tiny, INT32_MIN, INT32_MAX, 100, 0xFFFFFF);
  fac_gfx_fillcircle(tiny, INT32_MAX, INT32_MIN, 100, 0xFFFFFF);
  fac_gfx_filltri(tiny, INT32_MIN, INT32_MIN, INT32_MAX, INT32_MIN, 0, INT32_MAX, 0xFFFFFF);
  fac_gfx_filltri(nullptr, 0, 0, 1, 0, 0, 1, 0xFFFFFF);
  fac_gfx_clear(nullptr, 0); fac_gfx_pixel(nullptr, 0, 0, 0); fac_gfx_fillrect(nullptr, 0, 0, 1, 1, 0);
  fac_gfx_blend(nullptr, 0, 0, 0, 255); fac_gfx_blit(nullptr, tiny, 0, 0); fac_gfx_blitkey(tiny, nullptr, 0, 0, 0);
  fac_gfx_blitscaled(tiny, tiny, INT32_MIN, INT32_MIN, INT32_MIN, INT32_MIN);
  if (fac_gfx_width(nullptr) != 0 || fac_gfx_height(nullptr) != 0 || fac_gfx_get(nullptr, 0, 0) != 0)
    return fail("graphics null-handle queries were not safe");
  if (catch_fac([] { (void)fac_gfx_hsv(0.0, std::numeric_limits<double>::quiet_NaN(), 1.0); }) != 14)
    return fail("graphic.hsv must reject non-finite input");
  fac_gfx_free(tiny);

#ifndef _WIN32
  // /dev/full exposes buffered-write failures only at flush/close on many libc implementations.
  if (access("/dev/full", W_OK) == 0) {
    FacStr *full = fac_cstr_new("/dev/full"), *payload = fac_cstr_new("flush failure regression");
    const int32_t writeCode = catch_fac([&] { fac_file_writeall(full, payload); });
    if (writeCode != 7) return fail("file.writeAll did not report a delayed write/flush error");
    FacAudioClip *clip = fac_audio_create(8000, 1, 1);
    const int32_t audioCode = catch_fac([&] { fac_audio_savewav(clip, full); });
    if (audioCode != 7) return fail("audio.saveWav did not report a delayed write/flush error");
    fac_audio_free(clip); fac_str_free(payload); fac_str_free(full);
  }

  // Sparse file prevents allocating disk blocks while verifying the hash input cap.
  const auto hugeHash = dir / "hash-over-limit.bin";
  int fd = open(hugeHash.c_str(), O_CREAT | O_RDWR, 0600);
  if (fd >= 0) {
    const bool sized = ftruncate(fd, (off_t)((size_t)64 * 1024 * 1024 + 1)) == 0;
    close(fd);
    if (sized) {
      FacStr *hp = fac_cstr_new(hugeHash.string().c_str());
      const int32_t hashCode = catch_fac([&] { FacStr *r = fac_crypto_sha256file(hp); fac_str_free(r); });
      fac_str_free(hp);
      if (hashCode != 7) return fail("SHA-256 file reader did not enforce its 64 MiB cap");
    }
  }
#endif
  std::error_code ec; std::filesystem::remove_all(dir, ec);
  std::puts("security regression: OK");
  return 0;
}
