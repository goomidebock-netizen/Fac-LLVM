#include <cstdint>
#include <cstdio>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void *fac_obj_weak(void *object);
int32_t fac_obj_weak_alive(void *weak);
void *fac_obj_weak_lock(void *weak);
void fac_obj_weak_release(void *weak);
void fac_obj_weak_retain(void *weak);
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
}

static int catchRetain(void *object) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_obj_retain(object);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static int catchRelease(void *object) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_obj_release(object);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static int catchWeakRetain(void *weak) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_obj_weak_retain(weak);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static int catchWeakRelease(void *weak) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_obj_weak_release(weak);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  void *object = fac_obj_new(8, nullptr, nullptr, nullptr, nullptr);
  if (!object) return fail("object allocation failed");
  void *weak = fac_obj_weak(object);
  if (!weak || fac_obj_weak_alive(weak) != 1)
    return fail("live object's weak handle was not created correctly");

  fac_obj_release(object);
  if (fac_obj_weak_alive(weak) != 0 || fac_obj_weak_lock(weak) != nullptr)
    return fail("weak handle still exposed a destroyed object");

  // The address is stale now. Runtime entry points must consult the live
  // registry before reading the object header, rather than dereferencing it.
  if (catchRetain(object) != 7)
    return fail("retain of stale object did not return a FAC Runtime error");
  if (catchRelease(object) != 7)
    return fail("release of stale object did not return a FAC Runtime error");
  if (fac_obj_weak(object) != nullptr)
    return fail("weak request for stale object did not return null");
  fac_obj_weak_release(weak);
  if (fac_obj_weak_alive(weak) != 0 || fac_obj_weak_lock(weak) != nullptr)
    return fail("expired weak control block remained observable after its final release");
  if (catchWeakRetain(weak) != 7 || catchWeakRelease(weak) != 7)
    return fail("stale weak handle was dereferenced instead of rejected");

  void *invalid = reinterpret_cast<void *>(static_cast<uintptr_t>(0x12340));
  if (catchRetain(invalid) != 7 || catchRelease(invalid) != 7)
    return fail("invalid native object handle was dereferenced instead of rejected");
  if (fac_obj_weak(invalid) != nullptr)
    return fail("weak request for invalid native handle did not return null");
  if (fac_obj_weak_alive(invalid) != 0 || fac_obj_weak_lock(invalid) != nullptr)
    return fail("invalid weak handle was dereferenced instead of rejected");
  if (catchWeakRetain(invalid) != 7 || catchWeakRelease(invalid) != 7)
    return fail("invalid weak handle retain/release did not return a FAC Runtime error");

  // Force weak-slot reuse. The new handle may use the same slot index, but
  // its generation-tagged token must differ from the expired token (ABA).
  void *firstObject = fac_obj_new(8, nullptr, nullptr, nullptr, nullptr);
  if (!firstObject) return fail("first ABA object allocation failed");
  void *oldToken = fac_obj_weak(firstObject);
  if (!oldToken) return fail("first ABA weak token allocation failed");
  fac_obj_release(firstObject);
  fac_obj_weak_release(oldToken);

  void *secondObject = fac_obj_new(8, nullptr, nullptr, nullptr, nullptr);
  if (!secondObject) return fail("second ABA object allocation failed");
  void *newToken = fac_obj_weak(secondObject);
  if (!newToken) return fail("second ABA weak token allocation failed");
  if (oldToken == newToken)
    return fail("weak token was reused without changing its generation");
#if UINTPTR_MAX > UINT32_MAX
  constexpr uint32_t weakSlotBits = 23;
#else
  constexpr uint32_t weakSlotBits = 12;
#endif
  constexpr uintptr_t weakSlotMask = (uintptr_t(1) << weakSlotBits) - 1u;
  const uintptr_t oldValue = reinterpret_cast<uintptr_t>(oldToken);
  const uintptr_t newValue = reinterpret_cast<uintptr_t>(newToken);
  if ((oldValue & weakSlotMask) != (newValue & weakSlotMask))
    return fail("ABA regression did not reuse the released weak slot");
  if ((oldValue >> weakSlotBits) == (newValue >> weakSlotBits))
    return fail("reused weak slot did not advance its generation");
  if (fac_obj_weak_alive(oldToken) != 0 || fac_obj_weak_lock(oldToken) != nullptr)
    return fail("expired generation token aliased a newly allocated weak handle");
  if (catchWeakRetain(oldToken) != 7 || catchWeakRelease(oldToken) != 7)
    return fail("expired generation token was accepted after slot reuse");
  if (fac_obj_weak_alive(newToken) != 1)
    return fail("new generation token was not live after slot reuse");
  void *secondLock = fac_obj_weak_lock(newToken);
  if (secondLock != secondObject)
    return fail("new generation token failed to lock its object");
  fac_obj_release(secondLock);
  fac_obj_release(secondObject);
  if (fac_obj_weak_alive(newToken) != 0)
    return fail("new generation token remained alive after object destruction");
  fac_obj_weak_release(newToken);

  std::puts("PASS stale/invalid handles rejected and weak-slot ABA blocked by generation tokens");
  return 0;
}
