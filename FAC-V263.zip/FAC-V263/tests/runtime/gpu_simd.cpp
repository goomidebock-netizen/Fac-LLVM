#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <vector>

struct FacStr { char *data; int64_t len, cap, ncp, flags; };
extern "C" {
FacStr *fac_gpu_backend();
FacStr *fac_gpu_backend_capabilities();
FacStr *fac_gpu_opencl_status();
int32_t fac_gpu_hardware();
void fac_str_free(FacStr *);
void *fac_gpu_buffer_create(int64_t);
void fac_gpu_buffer_free(void *);
int32_t fac_gpu_write_f64(void *, int64_t, double);
double fac_gpu_read_f64(void *, int64_t);
int32_t fac_gpu_add_f64(void *, void *, void *, int64_t);
int32_t fac_gpu_sub_f64(void *, void *, void *, int64_t);
int32_t fac_gpu_mul_f64(void *, void *, void *, int64_t);
int32_t fac_gpu_scale_f64(void *, void *, int64_t, double);
int32_t fac_gpu_matmul_f64(void *, void *, void *, int64_t, int64_t, int64_t);
int32_t fac_simd_div_f64x2(void *, void *, void *, int64_t);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL gpu SIMD foundation: %s\n", message);
  return 1;
}

static bool textIs(FacStr *value, const char *expected) {
  const size_t n = std::strlen(expected);
  const bool equal = value && value->len == (int64_t)n && std::memcmp(value->data, expected, n) == 0;
  if (value) fac_str_free(value);
  return equal;
}

static bool closeEnough(double a, double b) {
  const double scale = std::max(1.0, std::max(std::fabs(a), std::fabs(b)));
  return std::fabs(a - b) <= scale * 1e-13;
}

int main() {
  // The V170 runtime is intentionally CPU-only. Keep the legacy diagnostic API
  // deterministic so old callers cannot accidentally infer hardware readiness.
  if (fac_gpu_hardware() != 0) return fail("CPU-only backend reported hardware acceleration");
  if (!textIs(fac_gpu_backend(), "software-reference")) return fail("backend name is not deterministic");
  if (!textIs(fac_gpu_opencl_status(), "disabled")) return fail("legacy device status is not disabled");
  if (!textIs(fac_gpu_backend_capabilities(),
      "buffer,f64-add,f64-sub,f64-mul,f64-scale,f64-matmul;software-reference;no-hardware-acceleration"))
    return fail("CPU-only capability description");

  constexpr int64_t maxCount = 1025; // spans two full 512-element blocks plus a tail
  void *left = fac_gpu_buffer_create(maxCount * 8);
  void *right = fac_gpu_buffer_create(maxCount * 8);
  void *out = fac_gpu_buffer_create(maxCount * 8);
  if (!left || !right || !out) return fail("buffer allocation");

  const int64_t counts[] = {0, 1, 511, 512, 513, 1025};
  for (int64_t count : counts) {
    for (int64_t i = 0; i < count; ++i) {
      const double a = (double)(i - 300) * 0.25;
      const double b = (double)(i + 7) * -0.125;
      if (!fac_gpu_write_f64(left, i, a) || !fac_gpu_write_f64(right, i, b))
        return fail("write test input");
    }
    if (!fac_gpu_add_f64(out, left, right, count)) return fail("block add rejected valid input");
    for (int64_t i = 0; i < count; ++i) {
      const double a = (double)(i - 300) * 0.25, b = (double)(i + 7) * -0.125;
      if (!closeEnough(fac_gpu_read_f64(out, i), a + b)) return fail("block add mismatch");
    }
    if (!fac_gpu_sub_f64(out, left, right, count)) return fail("block sub rejected valid input");
    for (int64_t i = 0; i < count; ++i) {
      const double a = (double)(i - 300) * 0.25, b = (double)(i + 7) * -0.125;
      if (!closeEnough(fac_gpu_read_f64(out, i), a - b)) return fail("block sub mismatch");
    }
    if (!fac_gpu_mul_f64(out, left, right, count)) return fail("block mul rejected valid input");
    for (int64_t i = 0; i < count; ++i) {
      const double a = (double)(i - 300) * 0.25, b = (double)(i + 7) * -0.125;
      if (!closeEnough(fac_gpu_read_f64(out, i), a * b)) return fail("block mul mismatch");
    }
    if (!fac_gpu_scale_f64(out, left, count, 1.75)) return fail("block scale rejected valid input");
    for (int64_t i = 0; i < count; ++i) {
      const double expected = (double)(i - 300) * 0.25 * 1.75;
      if (!closeEnough(fac_gpu_read_f64(out, i), expected)) return fail("block scale mismatch");
    }
  }

  // Destination/source aliasing remains supported by the transactional block path.
  for (int64_t i = 0; i < maxCount; ++i) {
    fac_gpu_write_f64(left, i, (double)i);
    fac_gpu_write_f64(right, i, 2.0 * (double)i);
  }
  if (!fac_gpu_add_f64(left, left, right, maxCount)) return fail("in-place add failed");
  for (int64_t i = 0; i < maxCount; ++i)
    if (fac_gpu_read_f64(left, i) != 3.0 * (double)i) return fail("in-place add mismatch");
  if (!fac_gpu_sub_f64(left, left, right, maxCount)) return fail("in-place sub failed");
  for (int64_t i = 0; i < maxCount; ++i)
    if (fac_gpu_read_f64(left, i) != (double)i) return fail("in-place sub mismatch");
  if (!fac_gpu_mul_f64(left, left, right, maxCount)) return fail("in-place mul failed");
  for (int64_t i = 0; i < maxCount; ++i)
    if (fac_gpu_read_f64(left, i) != 2.0 * (double)i * (double)i) return fail("in-place mul mismatch");
  if (!fac_gpu_scale_f64(left, left, maxCount, 0.5)) return fail("in-place scale failed");
  for (int64_t i = 0; i < maxCount; ++i)
    if (fac_gpu_read_f64(left, i) != (double)i * (double)i) return fail("in-place scale mismatch");

  // Matrix multiplication uses a staged result and must preserve destination
  // bytes on overflow or invalid dimensions.
  void *ma = fac_gpu_buffer_create(3 * 8);
  void *mb = fac_gpu_buffer_create(3 * 8);
  void *mc = fac_gpu_buffer_create(4 * 8);
  if (!ma || !mb || !mc) return fail("matrix buffer allocation");
  const double av[] = {1.0, 2.0, 3.0}, bv[] = {4.0, 5.0, 6.0};
  for (int64_t i = 0; i < 3; ++i) {
    if (!fac_gpu_write_f64(ma, i, av[i]) || !fac_gpu_write_f64(mb, i, bv[i]))
      return fail("matrix input write");
  }
  for (int64_t i = 0; i < 4; ++i) fac_gpu_write_f64(mc, i, -9.0);
  // [1 2 3] x [4; 5; 6] = 32 (1x3 times 3x1).
  if (!fac_gpu_matmul_f64(mc, ma, mb, 1, 3, 1) || fac_gpu_read_f64(mc, 0) != 32.0)
    return fail("CPU matrix multiplication result");
  fac_gpu_write_f64(ma, 0, std::numeric_limits<double>::max());
  fac_gpu_write_f64(mb, 0, 2.0);
  fac_gpu_write_f64(mc, 0, -9.0);
  if (fac_gpu_matmul_f64(mc, ma, mb, 1, 3, 1)) return fail("overflowing matrix multiplication was accepted");
  if (fac_gpu_read_f64(mc, 0) != -9.0) return fail("failed matrix multiplication partially modified output");
  if (fac_gpu_matmul_f64(mc, ma, mb, 0, 3, 1)) return fail("invalid matrix dimensions were accepted");
  if (fac_gpu_read_f64(mc, 0) != -9.0) return fail("invalid matrix dimensions modified output");

  // SIMD division by zero and odd lane counts must fail transactionally.
  fac_gpu_write_f64(left, 0, 10.0); fac_gpu_write_f64(left, 1, 20.0);
  fac_gpu_write_f64(right, 0, 2.0); fac_gpu_write_f64(right, 1, 0.0);
  fac_gpu_write_f64(out, 0, -321.0); fac_gpu_write_f64(out, 1, -321.0);
  if (fac_simd_div_f64x2(out, left, right, 2)) return fail("SIMD division by zero was accepted");
  if (fac_gpu_read_f64(out, 0) != -321.0 || fac_gpu_read_f64(out, 1) != -321.0)
    return fail("failed SIMD division partially modified output");
  if (fac_simd_div_f64x2(out, left, right, 1)) return fail("odd SIMD lane count was accepted");

  fac_gpu_buffer_free(mc); fac_gpu_buffer_free(mb); fac_gpu_buffer_free(ma);

  // Non-finite arithmetic and invalid ranges must not partially overwrite output.
  for (int64_t i = 0; i < maxCount; ++i) {
    fac_gpu_write_f64(left, i, (double)i + 1.0);
    fac_gpu_write_f64(right, i, (double)i + 2.0);
    fac_gpu_write_f64(out, i, -123.0);
  }
  fac_gpu_write_f64(left, 512, std::numeric_limits<double>::max());
  if (fac_gpu_scale_f64(out, left, maxCount, 2.0)) return fail("overflowing scale was accepted");
  if (fac_gpu_read_f64(out, 0) != -123.0 || fac_gpu_read_f64(out, 512) != -123.0 ||
      fac_gpu_read_f64(out, maxCount - 1) != -123.0)
    return fail("failed scale partially modified destination");

  fac_gpu_write_f64(left, 512, std::numeric_limits<double>::max());
  fac_gpu_write_f64(right, 512, std::numeric_limits<double>::max());
  if (fac_gpu_add_f64(out, left, right, maxCount)) return fail("overflowing add was accepted");
  if (fac_gpu_read_f64(out, 0) != -123.0 || fac_gpu_read_f64(out, 512) != -123.0 ||
      fac_gpu_read_f64(out, maxCount - 1) != -123.0)
    return fail("failed add partially modified destination");
  if (fac_gpu_mul_f64(out, left, right, maxCount)) return fail("overflowing multiply was accepted");
  if (fac_gpu_read_f64(out, 0) != -123.0 || fac_gpu_read_f64(out, 512) != -123.0 ||
      fac_gpu_read_f64(out, maxCount - 1) != -123.0)
    return fail("failed multiply partially modified destination");

  if (fac_gpu_add_f64(out, left, right, maxCount + 1)) return fail("out-of-range add was accepted");
  if (fac_gpu_read_f64(out, 0) != -123.0 || fac_gpu_read_f64(out, maxCount - 1) != -123.0)
    return fail("invalid-range add modified destination");

  fac_gpu_buffer_free(out);
  fac_gpu_buffer_free(right);
  fac_gpu_buffer_free(left);
  std::puts("PASS CPU-only numeric backend / f64 add-sub-mul-scale-matmul / SIMD rollback / aliasing / transactional errors");
  return 0;
}
