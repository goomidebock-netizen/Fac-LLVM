#include <cstdint>
#include <climits>
#include <cstdio>
#include <cstring>
#include <string>

struct FacStr { char *data; int64_t len, cap, ncp, flags; };
extern "C" {
int64_t fac_crypto_randint(int64_t lo, int64_t hi);
FacStr *fac_crypto_randbytes(int32_t n);
FacStr *fac_crypto_randhex(int32_t n);
FacStr *fac_crypto_uuid();
void fac_str_free(FacStr *s);
}

int main() {
  for (int i = 0; i < 256; ++i) {
    const int64_t a = fac_crypto_randint(INT64_MIN, INT64_MIN + 127);
    const int64_t b = fac_crypto_randint(INT64_MAX - 127, INT64_MAX);
    const int64_t c = fac_crypto_randint(-19, 23);
    const int64_t d = fac_crypto_randint(23, -19);
    const int64_t e = fac_crypto_randint(7, 7);
    (void)fac_crypto_randint(INT64_MIN, INT64_MAX);
    if (a < INT64_MIN || a > INT64_MIN + 127 ||
        b < INT64_MAX - 127 || b > INT64_MAX ||
        c < -19 || c > 23 || d < -19 || d > 23 || e != 7) {
      std::fprintf(stderr, "FAIL crypto.randomInt bounds\n"); return 1;
    }
  }
  FacStr *bytes = fac_crypto_randbytes(64);
  if (!bytes || bytes->len != 64 || !bytes->data) return 2;
  bool nonzero = false, varied = false;
  for (int i = 0; i < 64; ++i) nonzero |= bytes->data[i] != 0;
  for (int i = 1; i < 64; ++i) varied |= bytes->data[i] != bytes->data[0];
  if (!nonzero || !varied) return 3;
  fac_str_free(bytes);

  FacStr *hex = fac_crypto_randhex(32);
  if (!hex || hex->len != 64) return 4;
  for (int64_t i = 0; i < hex->len; ++i) {
    const char c = hex->data[i];
    if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return 5;
  }
  fac_str_free(hex);

  FacStr *uuid = fac_crypto_uuid();
  if (!uuid || uuid->len != 36 || uuid->data[14] != '4' ||
      (uuid->data[19] != '8' && uuid->data[19] != '9' && uuid->data[19] != 'a' && uuid->data[19] != 'b')) return 6;
  fac_str_free(uuid);
  std::puts("PASS OS CSPRNG, crypto.randomInt extreme ranges, randomHex and UUID");
  return 0;
}
