#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <new>

// Fail exactly one C++ allocation so the tracking index's first growth can be
// forced to fail deterministically. The FAC allocation itself still reaches
// calloc; only the side-table storage request is rejected.
static std::atomic<long long> g_fail_after{-1};
static bool should_fail_allocation() noexcept {
  long long current = g_fail_after.load(std::memory_order_relaxed);
  while (current >= 0) {
    if (current == 0) {
      if (g_fail_after.compare_exchange_weak(current, -1, std::memory_order_relaxed)) return true;
    } else if (g_fail_after.compare_exchange_weak(current, current - 1, std::memory_order_relaxed)) {
      return false;
    }
  }
  return false;
}
static void *test_new(std::size_t size) {
  if (should_fail_allocation()) throw std::bad_alloc();
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new(std::size_t size) { return test_new(size); }
void *operator new[](std::size_t size) { return test_new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

extern "C" {
void *fac_alloc(int64_t);
void fac_free(void *);
void fac_mem_start_tracking();
uint64_t fac_mem_used();
uint64_t fac_mem_blocks();
void fac_try_enter(void *);
void fac_try_leave();
int32_t fac_err_code();
}

static int try_alloc(void **out) {
  void *jumpBuffer[5]{};
  *out = nullptr;
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    *out = fac_alloc(96);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  fac_mem_start_tracking();
  void *blocks[48]{};
  for (int i = 0; i < 47; ++i) {
    blocks[i] = fac_alloc(24);
    if (!blocks[i]) return fail("initial tracked allocation");
  }
  if (fac_mem_used() != 47u * 24u || fac_mem_blocks() != 47)
    return fail("initial tracking table accounting");

  // 48th insertion crosses the initial 64-slot table's 75% growth boundary.
  // Failing vector allocation must free the raw payload and leave all prior
  // pointer/size records intact, then permit a successful retry.
  g_fail_after.store(0, std::memory_order_relaxed);
  const int error = try_alloc(&blocks[47]);
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (error != 5 || blocks[47] != nullptr)
    return fail("tracking table growth reports Resource without publishing allocation");
  if (fac_mem_used() != 47u * 24u || fac_mem_blocks() != 47)
    return fail("tracking table OOM preserves prior counters");

  if (try_alloc(&blocks[47]) != 0 || !blocks[47])
    return fail("tracking table retry succeeds after OOM");
  if (fac_mem_used() != 47u * 24u + 96u || fac_mem_blocks() != 48)
    return fail("tracking table retry accounting");
  for (void *block : blocks) fac_free(block);
  if (fac_mem_used() != 0 || fac_mem_blocks() != 0)
    return fail("tracking table OOM recovery frees every block");
  std::puts("PASS FAC flat tracking index growth OOM rollback and retry");
  return 0;
}
