#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
CXX=${CXX:-clang++}
D=build/runtime-sanitizers
mkdir -p "$D"
SAN='-fsanitize=address,undefined -fno-omit-frame-pointer'
"$CXX" -std=c++17 -O1 -g $SAN -pthread -c runtime/fac_rt.cpp -o "$D/fac_rt.o"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/array_ops.cpp "$D/fac_rt.o" -lm -ldl -o "$D/array_ops"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/list_insert_alias.cpp "$D/fac_rt.o" -lm -ldl -o "$D/list_insert_alias"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/rng_threads.cpp "$D/fac_rt.o" -lm -ldl -o "$D/rng_threads"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/crypto_rng.cpp "$D/fac_rt.o" -lm -ldl -o "$D/crypto_rng"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/audio_threads.cpp "$D/fac_rt.o" -lm -ldl -o "$D/audio_threads"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/image_threads.cpp -o "$D/image_threads"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/memory_allocator.cpp "$D/fac_rt.o" -lm -ldl -o "$D/memory_allocator"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/temporary_scratch_pool.cpp "$D/fac_rt.o" -lm -ldl -o "$D/temporary_scratch_pool"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/ds_clone_exception.cpp "$D/fac_rt.o" -lm -ldl -o "$D/ds_clone_exception"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/finalizer_error_cleanup.cpp "$D/fac_rt.o" -lm -ldl -o "$D/finalizer_error_cleanup"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/object_registry_safety.cpp "$D/fac_rt.o" -lm -ldl -o "$D/object_registry_safety"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/file_handle_lifetime.cpp "$D/fac_rt.o" -lm -ldl -o "$D/file_handle_lifetime"
"$CXX" -std=c++17 -O1 -g0 $SAN -pthread tests/runtime/socket_handle_concurrency.cpp "$D/fac_rt.o" -lm -ldl -o "$D/socket_handle_concurrency"
"$CXX" -std=c++17 -O1 -g $SAN -pthread -DFAC_SQLITE_STANDALONE_TEST tests/runtime/sqlite_handle_concurrency.cpp -ldl -o "$D/sqlite_handle_concurrency"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/weak_refs.cpp "$D/fac_rt.o" -lm -ldl -o "$D/weak_refs"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/tls_stack_threads.cpp "$D/fac_rt.o" -lm -ldl -o "$D/tls_stack_threads"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/parallel_for.cpp "$D/fac_rt.o" -lm -ldl -o "$D/parallel_for"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/parallel_pool.cpp "$D/fac_rt.o" -lm -ldl -o "$D/parallel_pool"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/task_lifecycle.cpp "$D/fac_rt.o" -lm -ldl -o "$D/task_lifecycle"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/cleanup_exception_safety.cpp "$D/fac_rt.o" -lm -ldl -o "$D/cleanup_exception_safety"
"$CXX" -std=c++17 -O1 -g $SAN -pthread tests/runtime/nested_ownership_recovery.cpp "$D/fac_rt.o" -lm -ldl -o "$D/nested_ownership_recovery"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/array_ops"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/list_insert_alias"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/rng_threads"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/crypto_rng"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/image_threads"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/memory_allocator"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/temporary_scratch_pool"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/ds_clone_exception"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/finalizer_error_cleanup"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/object_registry_safety"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/file_handle_lifetime"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/socket_handle_concurrency"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/sqlite_handle_concurrency"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/weak_refs"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/tls_stack_threads"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/parallel_for"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/parallel_pool"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/task_lifecycle"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/cleanup_exception_safety"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/nested_ownership_recovery"
if ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/parallel_for" throw >"$D/parallel_for_throw.out" 2>"$D/parallel_for_throw.err"; then
  echo 'FAIL sanitizer parallelFor callback exception should be reported'; exit 1
fi
grep -q 'callback raised a C++ exception' "$D/parallel_for_throw.err"
# SDL2 retains a small process-global cache in this environment (128 bytes reported
# inside libSDL2 even after SDL_Quit); keep ASan/UBSan enabled but let the normal
# non-SDL runtime cases above remain the LeakSanitizer gate.
SDL_AUDIODRIVER=dummy ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/audio_threads"
for mode in overflow negative throw-sort; do
  if ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 FAC_TMP_CHECK=1 "$D/array_ops" "$mode" >"$D/$mode.out" 2>"$D/$mode.err"; then
    echo "FAIL sanitizer expected rejection: $mode"; exit 1
  fi
  if grep -Eq 'AddressSanitizer|LeakSanitizer|runtime error|temp stack not empty' "$D/$mode.err"; then
    echo "FAIL sanitizer issue in rejection case: $mode"; cat "$D/$mode.err"; exit 1
  fi
  grep -Eq 'size overflow|cannot be negative|index out of range' "$D/$mode.err"
done
echo 'PASS runtime ASan/UBSan/LSan hardening tests (including throwing sort comparator)'
