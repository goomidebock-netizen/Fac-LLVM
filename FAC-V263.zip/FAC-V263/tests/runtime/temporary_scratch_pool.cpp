#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <thread>
#include <vector>

extern "C" {
void *fac_runtime_scratch_alloc(size_t);
void fac_runtime_scratch_free(void *);
uint64_t fac_runtime_scratch_cached_bytes();
uint64_t fac_runtime_scratch_hits();
uint64_t fac_runtime_scratch_upstream_allocations();
int32_t fac_runtime_trim_thread();
void fac_tmp_push_drop(void *, void *);
void fac_tmp_pop(void *);
void fac_try_enter(void *);
void fac_try_leave();
void fac_null_deref();
int32_t fac_err_code();
void fac_sort_cmp(void *, int64_t, int64_t, void *, int32_t (*)(void *, const void *, const void *));
void fac_reverse(void *, int64_t, int32_t);
struct FacList {
  void *data; int64_t len, cap; int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};
FacList *fac_list_new(int32_t, int32_t);
void fac_list_grow(FacList *);
void fac_list_insert(FacList *, int64_t, const void *);
void fac_list_free(FacList *);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

static int32_t compare_i32(void *, const void *a, const void *b) {
  const int32_t x = *static_cast<const int32_t *>(a);
  const int32_t y = *static_cast<const int32_t *>(b);
  return (x > y) - (x < y);
}

static int32_t compare_throw(void *, const void *, const void *) {
  throw std::runtime_error("comparator failure");
}

static int test_fac_throw_releases_scratch_to_pool() {
  const uint64_t cachedBefore = fac_runtime_scratch_cached_bytes();
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    void *temporary = fac_runtime_scratch_alloc(40);
    fac_tmp_push_drop(temporary, reinterpret_cast<void *>(&fac_runtime_scratch_free));
    fac_null_deref();
    fac_try_leave();
    return fail("FAC throw should not return");
  }
  if (fac_err_code() != 6) return fail("FAC error code survives scratch cleanup");
  if (fac_runtime_scratch_cached_bytes() != cachedBefore)
    return fail("FAC throw returns a short-lived block to the matching pool class");
  return 0;
}

int main() {
  if (fac_runtime_scratch_cached_bytes() != 0) return fail("fresh thread starts with empty scratch cache");

  const uint64_t allocations0 = fac_runtime_scratch_upstream_allocations();
  const uint64_t hits0 = fac_runtime_scratch_hits();
  void *small = fac_runtime_scratch_alloc(24);
  if (((uintptr_t)small % alignof(std::max_align_t)) != 0)
    return fail("scratch payload preserves max_align_t alignment");
  fac_runtime_scratch_free(small);
  if (fac_runtime_scratch_cached_bytes() != 80)
    return fail("first short allocation caches one 64-byte class block including header");

  void *reuse = fac_runtime_scratch_alloc(48);
  if (fac_runtime_scratch_upstream_allocations() != allocations0 + 1 ||
      fac_runtime_scratch_hits() != hits0 + 1)
    return fail("same class reuses cached block without upstream allocation");
  fac_runtime_scratch_free(reuse);

  // One retained block per class, with a strict total bound (< 11 KiB/thread).
  const size_t requests[] = {65, 257, 1025};
  void *classBlocks[3]{};
  for (size_t i = 0; i < 3; ++i) classBlocks[i] = fac_runtime_scratch_alloc(requests[i]);
  for (void *p : classBlocks) fac_runtime_scratch_free(p);
  if (fac_runtime_scratch_cached_bytes() != 1392)
    return fail("three size classes retain one bounded block each");

  // Oversized workspaces bypass the cache and are returned directly upstream.
  const uint64_t cachedBeforeLarge = fac_runtime_scratch_cached_bytes();
  void *large = fac_runtime_scratch_alloc(16385);
  fac_runtime_scratch_free(large);
  if (fac_runtime_scratch_cached_bytes() != cachedBeforeLarge)
    return fail("oversized allocation does not expand the per-thread cache");

  // Concurrent same-class requests may temporarily exceed one slot, but only
  // one block per class is retained; every extra block is immediately freed.
  void *sameClass[5]{};
  for (void *&p : sameClass) p = fac_runtime_scratch_alloc(48);
  for (void *p : sameClass) fac_runtime_scratch_free(p);
  if (fac_runtime_scratch_cached_bytes() != 1392)
    return fail("cache remains bounded after same-class bursts");

  if (test_fac_throw_releases_scratch_to_pool()) return 1;
  // Overflow in a direct scratch request reports Resource without disturbing
  // any cached classes or outstanding ownership entries.
  const uint64_t cachedBeforeOverflow = fac_runtime_scratch_cached_bytes();
  void *overflowJump[5]{};
  fac_try_enter(overflowJump);
  if (__builtin_setjmp(overflowJump) == 0) {
    (void)fac_runtime_scratch_alloc(SIZE_MAX);
    fac_try_leave();
    return fail("oversized scratch request should fail");
  }
  if (fac_err_code() != 5 || fac_runtime_scratch_cached_bytes() != cachedBeforeOverflow)
    return fail("scratch allocation overflow preserves cache and reports Resource");

  const uint64_t hitsBeforeReuse = fac_runtime_scratch_hits();
  void *afterThrow = fac_runtime_scratch_alloc(40);
  fac_runtime_scratch_free(afterThrow);
  if (fac_runtime_scratch_hits() != hitsBeforeReuse + 1)
    return fail("scratch block is reusable after FAC longjmp cleanup");

  // Exercise both Runtime call sites using the pool: stable merge-sort and
  // reverse must preserve their results while reusing the small classes.
  int32_t values[] = {7, -2, 9, 0, 4, 4, 1, -8};
  fac_sort_cmp(values, 8, (int64_t)sizeof(int32_t), nullptr, compare_i32);
  for (int i = 1; i < 8; ++i) if (values[i - 1] > values[i]) return fail("pooled stable sort result");
  fac_reverse(values, 8, (int32_t)sizeof(int32_t));
  for (int i = 1; i < 8; ++i) if (values[i - 1] < values[i]) return fail("pooled reverse result");

  // C++ exceptions unwind the C++ scope guard; FAC longjmp is handled by the
  // temporary ownership stack above. Both paths must return the same block.
  const uint64_t cachedBeforeCppThrow = fac_runtime_scratch_cached_bytes();
  int32_t throwingValues[] = {3, 1, 2};
  bool caughtCpp = false;
  try { fac_sort_cmp(throwingValues, 3, (int64_t)sizeof(int32_t), nullptr, compare_throw); }
  catch (const std::runtime_error &) { caughtCpp = true; }
  if (!caughtCpp || fac_runtime_scratch_cached_bytes() != cachedBeforeCppThrow)
    return fail("C++ exception releases and re-caches sort workspace");

  // List insertion snapshots an aliased source before growth/reallocation.
  // The snapshot must stay alive until copying is complete, then return to pool.
  FacList *list = fac_list_new((int32_t)sizeof(int32_t), 0);
  fac_list_grow(list);
  auto *listData = static_cast<int32_t *>(list->data);
  for (int i = 0; i < 8; ++i) listData[i] = i * 3;
  list->len = list->cap;
  const int32_t aliasedValue = listData[7];
  fac_list_insert(list, 0, &listData[7]);
  listData = static_cast<int32_t *>(list->data);
  if (list->len != 9 || listData[0] != aliasedValue || listData[1] != 0 || listData[8] != 21)
    return fail("list alias snapshot remains valid across growth and insertion");
  fac_list_free(list);

  // Every worker owns an independent TLS cache. A worker can trim its own
  // retained blocks without touching the calling thread's pool.
  std::atomic<int> threadFailures{0};
  std::vector<std::thread> workers;
  for (int t = 0; t < 6; ++t) workers.emplace_back([&] {
    for (int i = 0; i < 1000; ++i) {
      void *p = fac_runtime_scratch_alloc(64);
      fac_runtime_scratch_free(p);
    }
    if (fac_runtime_scratch_cached_bytes() != 80) ++threadFailures;
    if (!fac_runtime_trim_thread() || fac_runtime_scratch_cached_bytes() != 0) ++threadFailures;
  });
  for (auto &worker : workers) worker.join();
  if (threadFailures.load() != 0) return fail("thread-local scratch cache isolation and trim");
  if (fac_runtime_scratch_cached_bytes() != 1392)
    return fail("worker trim does not affect the current thread's cache");

  void *active = fac_runtime_scratch_alloc(24);
  fac_tmp_push_drop(active, reinterpret_cast<void *>(&fac_runtime_scratch_free));
  if (fac_runtime_trim_thread()) return fail("trim refuses an active scratch temporary");
  if (fac_runtime_scratch_cached_bytes() != 1312) return fail("refused trim preserves remaining scratch cache");
  // Remove the test-owned temporary in normal LIFO order and release it.
  // The entry's drop callback would otherwise return it to the existing cache.
  // (pop only unregisters; the explicit free below performs the release.)
  fac_tmp_pop(active);
  fac_runtime_scratch_free(active);

  if (!fac_runtime_trim_thread()) return fail("idle scratch pool trims successfully");
  if (fac_runtime_scratch_cached_bytes() != 0) return fail("trim releases all cached scratch bytes");
  if (fac_runtime_scratch_hits() == 0 || fac_runtime_scratch_upstream_allocations() == 0)
    return fail("scratch pool diagnostics record hits and upstream allocations");

  std::puts("PASS FAC temporary scratch pool / bounded classes / FAC throw cleanup / TLS isolation / trim");
  return 0;
}
