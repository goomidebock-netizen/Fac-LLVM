// sync.Cell runtime: get/set/swap/cas semantics and atomicity under concurrent threads.
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <thread>
#include <vector>
extern "C" {
void *fac_sync_cell_new(const char *); char *fac_sync_cell_get(void *); int32_t fac_sync_cell_set(void *, const char *);
char *fac_sync_cell_swap(void *, const char *); int32_t fac_sync_cell_cas(void *, const char *, const char *);
void fac_sync_cell_free(void *); void fac_sync_str_free(char *);
}
#define CHECK(c) do { if (!(c)) { std::fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #c); return 1; } } while (0)
static std::string get(void *c) { char *p = fac_sync_cell_get(c); if (!p) return "<null>"; std::string s(p); fac_sync_str_free(p); return s; }
static std::string swap(void *c, const char *v) { char *p = fac_sync_cell_swap(c, v); if (!p) return "<null>"; std::string s(p); fac_sync_str_free(p); return s; }
int main() {
  { void *c = fac_sync_cell_new("init");
    CHECK(get(c) == "init");
    CHECK(fac_sync_cell_set(c, "next") == 1); CHECK(get(c) == "next");
    CHECK(swap(c, "third") == "next"); CHECK(get(c) == "third");
    CHECK(fac_sync_cell_cas(c, "wrong", "x") == 0); CHECK(get(c) == "third");
    CHECK(fac_sync_cell_cas(c, "third", "fourth") == 1); CHECK(get(c) == "fourth");
    CHECK(fac_sync_cell_set(c, "") == 1); CHECK(get(c) == "");
    CHECK(fac_sync_cell_set(nullptr, "x") == 0); CHECK(fac_sync_cell_set(c, nullptr) == 0); CHECK(fac_sync_cell_get(nullptr) == nullptr);
    CHECK(fac_sync_cell_cas(c, nullptr, "x") == 0); CHECK(fac_sync_cell_swap(c, nullptr) == nullptr);
    fac_sync_cell_free(c); fac_sync_cell_free(nullptr); }
  { void *c = fac_sync_cell_new(nullptr); CHECK(get(c) == ""); fac_sync_cell_free(c); }
  { // 8 threads x 2000 increments through a cas retry loop: no lost update
    void *c = fac_sync_cell_new("0"); const int T = 8, N = 2000; std::vector<std::thread> ts;
    for (int t = 0; t < T; t++) ts.emplace_back([&] { for (int i = 0; i < N; i++) for (;;) {
      std::string cur = get(c); std::string nxt = std::to_string(std::atoi(cur.c_str()) + 1);
      if (fac_sync_cell_cas(c, cur.c_str(), nxt.c_str())) break; } });
    for (auto &t : ts) t.join();
    CHECK(get(c) == std::to_string(T * N)); fac_sync_cell_free(c); }
  { // swap hands every value to exactly one thread: a token passed around is never duplicated or lost
    void *c = fac_sync_cell_new("token"); std::atomic<int> holders{0}, maxHolders{0}; std::vector<std::thread> ts;
    for (int t = 0; t < 6; t++) ts.emplace_back([&] { for (int i = 0; i < 3000; i++) {
      std::string old = swap(c, "taken");
      if (old == "token") { int h = ++holders; int m = maxHolders.load(); while (h > m && !maxHolders.compare_exchange_weak(m, h)) {} --holders; fac_sync_cell_set(c, "token"); } } });
    for (auto &t : ts) t.join();
    CHECK(maxHolders.load() == 1);   // never two holders of the token at once
    fac_sync_cell_free(c); }
  { // long values are copied, not truncated
    std::string big(1 << 20, 'z'); void *c = fac_sync_cell_new(big.c_str()); CHECK(get(c) == big); fac_sync_cell_free(c); }
  std::puts("sync_cell ok");
  return 0;
}
