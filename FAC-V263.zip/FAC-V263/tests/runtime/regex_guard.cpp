// std::regex is recursive: large subjects used to overflow the stack (segfault). They must now work (<= 256 KiB) or fail
// with a FAC error (never crash). Modes run as subprocesses from run.sh.
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
struct FacStr;
struct FacStrView { char *data; int64_t len; };
struct FacListView { void *data; int64_t len; };
extern "C" {
FacStr *fac_str_from_chars(const char *, int64_t);
int32_t fac_regex_match(FacStr *, FacStr *);
FacStr *fac_regex_find(FacStr *, FacStr *);
FacStr *fac_regex_replace(FacStr *, FacStr *, FacStr *);
FacListView *fac_regex_groups(FacStr *, FacStr *);
FacListView *fac_regex_split(FacStr *, FacStr *);
int32_t fac_regex_count(FacStr *, FacStr *);
}
static FacStr *S(const std::string &s) { return fac_str_from_chars(s.data(), (int64_t)s.size()); }
static std::string V(FacStr *s) { auto *v = (FacStrView *)s; return std::string(v->data, (size_t)v->len); }
int main(int argc, char **argv) {
  std::string m = argc > 1 ? argv[1] : "";
  if (m == "small") {
    if (fac_regex_match(S("a+b"), S("aaab")) != 1) return 1;
    if (V(fac_regex_find(S("[0-9]+"), S("abc 123 def"))) != "123") return 2;
    if (V(fac_regex_replace(S("o"), S("foo"), S("0"))) != "f00") return 3;
    if (fac_regex_count(S("a"), S("banana")) != 3) return 4;
    if (fac_regex_groups(S("(a)(n)"), S("banana"))->len != 2) return 5;
    if (fac_regex_split(S(","), S("a,b,c"))->len != 3) return 6;
    return 0;
  }
  if (m == "big-ok") {   // 200k chars: crashed at ~50k before
    std::string t(200000, 'a');
    if (fac_regex_match(S(".*"), S(t)) != 1) return 1;
    if (fac_regex_match(S("(a|b)*"), S(t)) != 1) return 2;
    if (fac_regex_count(S("a"), S(t)) != 200000) return 3;
    if (V(fac_regex_replace(S("a"), S(t), S("b"))).size() != 200000) return 4;
    return 0;
  }
  if (m == "too-big") { std::string t(300000, 'a'); fac_regex_match(S(".*"), S(t)); return 99; }
  if (m == "long-pattern") { fac_regex_match(S(std::string(5000, 'a')), S("a")); return 99; }
  if (m == "bad-pattern") { fac_regex_match(S("(unclosed"), S("a")); return 99; }
  return 91;
}
