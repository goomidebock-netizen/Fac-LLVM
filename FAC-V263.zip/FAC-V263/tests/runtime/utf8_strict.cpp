// Strict UTF-8 decoding/encoding: overlong forms, surrogates and out-of-range values must never decode to a character
// and the encoder must never emit invalid UTF-8.
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
struct FacStr; struct FacStrView { char *data; int64_t len; };
extern "C" {
FacStr *fac_str_from_chars(const char *, int64_t); FacStr *fac_str_from_char(int32_t); int32_t fac_str_at(FacStr *, int64_t);
int32_t fac_str_len(FacStr *);
}
static int fails = 0;
#define EXPECT(cond, what) do { if (!(cond)) { std::printf("FAIL %s\n", what); fails++; } } while (0)
static int32_t first(const char *bytes) { return fac_str_at(fac_str_from_chars(bytes, (int64_t)std::strlen(bytes)), 0); }
static std::string enc(int32_t c) { auto *v = (FacStrView *)fac_str_from_char(c); return std::string(v->data, (size_t)v->len); }
int main() {
  const int32_t BAD = 0xFFFD;
  // valid boundaries
  EXPECT(first("A") == 'A', "ascii"); EXPECT(first("\xC2\x80") == 0x80, "U+0080"); EXPECT(first("\xC2\xA9") == 0xA9, "U+00A9");
  EXPECT(first("\xDF\xBF") == 0x7FF, "U+07FF"); EXPECT(first("\xE0\xA0\x80") == 0x800, "U+0800"); EXPECT(first("\xED\x9F\xBF") == 0xD7FF, "U+D7FF");
  EXPECT(first("\xEE\x80\x80") == 0xE000, "U+E000"); EXPECT(first("\xEF\xBF\xBF") == 0xFFFF, "U+FFFF");
  EXPECT(first("\xF0\x90\x80\x80") == 0x10000, "U+10000"); EXPECT(first("\xF4\x8F\xBF\xBF") == 0x10FFFF, "U+10FFFF");
  EXPECT(first("\xE0\xB8\x81") == 0x0E01, "Thai ก");
  // overlong, surrogates, out of range, stray/truncated bytes -> U+FFFD
  EXPECT(first("\xC0\xAF") == BAD, "overlong '/' (2 bytes)"); EXPECT(first("\xC1\xBF") == BAD, "overlong C1");
  EXPECT(first("\xE0\x80\xAF") == BAD, "overlong '/' (3 bytes)"); EXPECT(first("\xE0\x9F\xBF") == BAD, "overlong U+07FF (3 bytes)");
  EXPECT(first("\xF0\x80\x80\xAF") == BAD, "overlong '/' (4 bytes)"); EXPECT(first("\xF0\x8F\xBF\xBF") == BAD, "overlong U+FFFF (4 bytes)");
  EXPECT(first("\xED\xA0\x80") == BAD, "surrogate U+D800"); EXPECT(first("\xED\xBF\xBF") == BAD, "surrogate U+DFFF");
  EXPECT(first("\xF4\x90\x80\x80") == BAD, "U+110000"); EXPECT(first("\xF5\x80\x80\x80") == BAD, "F5 lead"); EXPECT(first("\xFF") == BAD, "FF");
  { FacStr *only = fac_str_from_chars("\x80", 1); EXPECT(fac_str_len(only) == 0, "lone continuation byte has no code point"); }
  { FacStr *mid = fac_str_from_chars("a\x80z", 3); EXPECT(fac_str_len(mid) == 2 && fac_str_at(mid, 1) == 'z', "stray continuation is skipped, indexing stays consistent"); } EXPECT(first("\xE2\x82") == BAD, "truncated 3-byte"); EXPECT(first("\xF0\x9F\x98") == BAD, "truncated 4-byte");
  EXPECT(first("\xC3" "a") == BAD, "lead without continuation (ncp==len fast path)");
  // encoder never emits invalid UTF-8
  EXPECT(enc(0x41) == "A", "enc A"); EXPECT(enc(0xE01) == "\xE0\xB8\x81", "enc Thai"); EXPECT(enc(0x10FFFF) == "\xF4\x8F\xBF\xBF", "enc max");
  const std::string rep = "\xEF\xBF\xBD";
  EXPECT(enc(0xD800) == rep, "enc surrogate"); EXPECT(enc(0xDFFF) == rep, "enc surrogate hi"); EXPECT(enc(0x110000) == rep, "enc > max"); EXPECT(enc(-1) == rep, "enc negative");
  if (fails == 0) std::puts("utf8_strict ok");
  return fails ? 1 : 0;
}
