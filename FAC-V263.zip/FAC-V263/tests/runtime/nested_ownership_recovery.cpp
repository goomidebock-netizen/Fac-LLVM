#include <cstdint>
#include <cstdio>
#include <stdexcept>

extern "C" {
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void fac_mem_start_tracking();
uint64_t fac_mem_blocks();
uint64_t fac_obj_live_count();
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
[[noreturn]] void fac_throw(void *message, int32_t code);
}

struct Child {
  int *finalizeCount;
  int *dropCount;
};

struct Owner {
  void *children[3]{};
  int childCount = 0;
  int *dropCount = nullptr;
};

static void dropChild(void *opaque) {
  auto *child = static_cast<Child *>(opaque);
  ++*child->dropCount;
}

static void finalizeFacError(void *opaque) {
  auto *child = static_cast<Child *>(opaque);
  ++*child->finalizeCount;
  fac_throw(nullptr, 31);
}

static void finalizeCppError(void *opaque) {
  auto *child = static_cast<Child *>(opaque);
  ++*child->finalizeCount;
  throw std::runtime_error("nested child finalizer failed");
}

static void finalizeNormally(void *opaque) {
  auto *child = static_cast<Child *>(opaque);
  ++*child->finalizeCount;
}

static void dropOwner(void *opaque) {
  auto *owner = static_cast<Owner *>(opaque);
  if (owner->dropCount) ++*owner->dropCount;
  for (int i = 0; i < owner->childCount; ++i) {
    void *child = owner->children[i];
    owner->children[i] = nullptr;
    if (child) fac_obj_release(child);
  }
}

static int catchRelease(void *object) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_obj_release(object);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static bool runNestedRecovery(int iteration) {
  int facFinalize = 0, facDrop = 0;
  int cppFinalize = 0, cppDrop = 0;
  int normalFinalize = 0, normalDrop = 0;
  int middleDrop = 0, rootDrop = 0;

  auto *facChild = static_cast<Child *>(fac_obj_new(
      static_cast<int64_t>(sizeof(Child)), reinterpret_cast<void *>(dropChild),
      nullptr, nullptr, reinterpret_cast<void *>(finalizeFacError)));
  facChild->finalizeCount = &facFinalize;
  facChild->dropCount = &facDrop;

  auto *cppChild = static_cast<Child *>(fac_obj_new(
      static_cast<int64_t>(sizeof(Child)), reinterpret_cast<void *>(dropChild),
      nullptr, nullptr, reinterpret_cast<void *>(finalizeCppError)));
  cppChild->finalizeCount = &cppFinalize;
  cppChild->dropCount = &cppDrop;

  auto *normalChild = static_cast<Child *>(fac_obj_new(
      static_cast<int64_t>(sizeof(Child)), reinterpret_cast<void *>(dropChild),
      nullptr, nullptr, reinterpret_cast<void *>(finalizeNormally)));
  normalChild->finalizeCount = &normalFinalize;
  normalChild->dropCount = &normalDrop;

  auto *middle = static_cast<Owner *>(fac_obj_new(
      static_cast<int64_t>(sizeof(Owner)), reinterpret_cast<void *>(dropOwner),
      nullptr, nullptr, nullptr));
  middle->children[0] = facChild;
  middle->children[1] = cppChild;
  middle->children[2] = normalChild;
  middle->childCount = 3;
  middle->dropCount = &middleDrop;
  fac_obj_retain(facChild);
  fac_obj_retain(cppChild);
  fac_obj_retain(normalChild);
  fac_obj_release(facChild);
  fac_obj_release(cppChild);
  fac_obj_release(normalChild);

  auto *root = static_cast<Owner *>(fac_obj_new(
      static_cast<int64_t>(sizeof(Owner)), reinterpret_cast<void *>(dropOwner),
      nullptr, nullptr, nullptr));
  root->children[0] = middle;
  root->childCount = 1;
  root->dropCount = &rootDrop;
  fac_obj_retain(middle);
  fac_obj_release(middle);

  const int32_t error = catchRelease(root);
  if (error != 31) {
    std::fprintf(stderr, "FAIL iteration %d: expected first nested FAC error 31, got %d\n", iteration, error);
    return false;
  }
  if (facFinalize != 1 || facDrop != 1 || cppFinalize != 1 || cppDrop != 1 ||
      normalFinalize != 1 || normalDrop != 1 || middleDrop != 1 || rootDrop != 1) {
    std::fprintf(stderr,
        "FAIL iteration %d: nested graph did not finish exactly once (FAC %d/%d, C++ %d/%d, normal %d/%d, owners %d/%d)\n",
        iteration, facFinalize, facDrop, cppFinalize, cppDrop,
        normalFinalize, normalDrop, middleDrop, rootDrop);
    return false;
  }
  return true;
}

int main() {
  fac_mem_start_tracking();
  const uint64_t initialBlocks = fac_mem_blocks();
  const uint64_t initialObjects = fac_obj_live_count();

  for (int iteration = 0; iteration < 2; ++iteration) {
    if (!runNestedRecovery(iteration)) return 1;
    if (fac_obj_live_count() != initialObjects || fac_mem_blocks() != initialBlocks) {
      std::fprintf(stderr, "FAIL iteration %d: nested graph leaked object storage (objects %llu, blocks %llu)\n",
          iteration,
          static_cast<unsigned long long>(fac_obj_live_count()),
          static_cast<unsigned long long>(fac_mem_blocks()));
      return 1;
    }
  }

  std::puts("PASS nested ownership graph drains all child drops, preserves first error, and recovers for repeated runs");
  return 0;
}
