#include <atomic>
#include <cstdint>
#include <iostream>
#include <thread>
#include <vector>

extern "C" {
void fac_rand_seed(int64_t seed);
int64_t fac_rand_int(int64_t lo, int64_t hi);
double fac_rand_f64();
int32_t fac_rand_bool();
}

int main() {
  fac_rand_seed(1234567);
  const int64_t first = fac_rand_int(-1000000, 1000000);
  fac_rand_seed(1234567);
  if (fac_rand_int(-1000000, 1000000) != first) {
    std::cerr << "FAIL seeded random stream is not repeatable\n";
    return 1;
  }

  std::atomic<bool> bad{false};
  std::vector<std::thread> workers;
  for (int t = 0; t < 8; ++t) {
    workers.emplace_back([&] {
      for (int i = 0; i < 50000; ++i) {
        const int64_t n = fac_rand_int(-17, 23);
        const double d = fac_rand_f64();
        const int32_t b = fac_rand_bool();
        if (n < -17 || n > 23 || d < 0.0 || d >= 1.0 || (b != 0 && b != 1))
          bad.store(true, std::memory_order_relaxed);
      }
    });
  }
  // Exercise reseeding while worker threads use their own engines.
  for (int i = 0; i < 500; ++i) fac_rand_seed(i);
  for (auto &w : workers) w.join();
  if (bad.load(std::memory_order_relaxed)) {
    std::cerr << "FAIL random output outside the requested range\n";
    return 1;
  }
  std::cout << "PASS thread-local random streams and concurrent reseeding\n";
  return 0;
}
