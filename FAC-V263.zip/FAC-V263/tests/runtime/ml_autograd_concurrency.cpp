// V214: immutable ML model inference may be shared for concurrent reads;
// each mutable Autograd tape is confined to its creating thread.
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <thread>
#include <vector>

extern "C" {
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
void *fac_tensor_create(int32_t rows, int32_t cols);
void fac_tensor_set(void *tensor, int32_t row, int32_t col, double value);
double fac_tensor_get(void *tensor, int32_t row, int32_t col);
int64_t fac_tensor_rows(void *tensor);
int64_t fac_tensor_cols(void *tensor);
void fac_tensor_free(void *tensor);
void *fac_ml_linear_fit(void *x, void *y, double learningRate, int32_t epochs);
void *fac_ml_linear_predict(void *model, void *x);
void fac_ml_free_model(void *model);
void *fac_ml_kmeans(void *x, int32_t k, int32_t epochs, int64_t seed);
void *fac_ml_kmeans_predict(void *model, void *x);
void fac_ml_free_kmeans(void *model);
void *fac_ml_knn_fit(void *x, void *y, int32_t k);
void *fac_ml_knn_predict(void *model, void *x);
void fac_ml_free_knn(void *model);
void *fac_autograd_create();
void fac_autograd_free(void *tape);
int32_t fac_autograd_variable(void *tape, double value);
int32_t fac_autograd_mul(void *tape, int32_t a, int32_t b);
void fac_autograd_backward(void *tape, int32_t output);
double fac_autograd_grad(void *tape, int32_t node);
void *fac_autograd_tensor_create();
void fac_autograd_tensor_free(void *tape);
int32_t fac_autograd_tensor_variable(void *tape, void *tensor);
int32_t fac_autograd_tensor_sum(void *tape, int32_t node);
void fac_autograd_tensor_backward(void *tape, int32_t output);
void *fac_autograd_tensor_grad(void *tape, int32_t node);
}

static int capture_error(void (*fn)(void *), void *arg) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fn(arg);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

struct ForeignUse { void *tape; bool tensor; };
static void foreign_use(void *opaque) {
  auto *state = static_cast<ForeignUse *>(opaque);
  if (state->tensor) (void)fac_autograd_tensor_variable(state->tape, nullptr);
  else (void)fac_autograd_variable(state->tape, 1.0);
}
static void foreign_free(void *opaque) {
  auto *state = static_cast<ForeignUse *>(opaque);
  if (state->tensor) fac_autograd_tensor_free(state->tape);
  else fac_autograd_free(state->tape);
}

static std::vector<double> read_column(void *tensor) {
  std::vector<double> out((size_t)fac_tensor_rows(tensor));
  for (int32_t r = 0; r < (int32_t)out.size(); ++r) out[(size_t)r] = fac_tensor_get(tensor, r, 0);
  return out;
}
static bool same_values(void *tensor, const std::vector<double> &expected) {
  if (!tensor || fac_tensor_rows(tensor) != (int64_t)expected.size() || fac_tensor_cols(tensor) != 1) return false;
  for (int32_t r = 0; r < (int32_t)expected.size(); ++r)
    if (std::fabs(fac_tensor_get(tensor, r, 0) - expected[(size_t)r]) > 1e-12) return false;
  return true;
}

int main() {
  void *x = fac_tensor_create(4, 2);
  void *y = fac_tensor_create(4, 1);
  if (!x || !y) return 1;
  const double rows[4][2] = {{0.0, 0.0}, {0.0, 1.0}, {10.0, 10.0}, {10.0, 11.0}};
  const double labels[4] = {0.0, 0.0, 1.0, 1.0};
  for (int r = 0; r < 4; ++r) {
    fac_tensor_set(y, r, 0, labels[r]);
    for (int c = 0; c < 2; ++c) fac_tensor_set(x, r, c, rows[r][c]);
  }

  void *linear = fac_ml_linear_fit(x, y, 0.01, 40);
  void *kmeans = fac_ml_kmeans(x, 2, 8, 1234);
  void *knn = fac_ml_knn_fit(x, y, 1);
  if (!linear || !kmeans || !knn) return 2;

  void *baselineLinear = fac_ml_linear_predict(linear, x);
  void *baselineKMeans = fac_ml_kmeans_predict(kmeans, x);
  void *baselineKNN = fac_ml_knn_predict(knn, x);
  const auto expectedLinear = read_column(baselineLinear);
  const auto expectedKMeans = read_column(baselineKMeans);
  const auto expectedKNN = read_column(baselineKNN);
  fac_tensor_free(baselineLinear);
  fac_tensor_free(baselineKMeans);
  fac_tensor_free(baselineKNN);

  // A tape may not be read, mutated or consumed from a non-owner thread.
  // Rejection must leave the original tape usable by its creating thread.
  void *scalarTape = fac_autograd_create();
  void *tensorTape = fac_autograd_tensor_create();
  if (!scalarTape || !tensorTape) return 3;
  ForeignUse scalarForeign{scalarTape, false};
  ForeignUse tensorForeign{tensorTape, true};
  std::atomic<int> scalarUseError{0}, scalarFreeError{0};
  std::atomic<int> tensorUseError{0}, tensorFreeError{0};
  std::thread foreign([&] {
    scalarUseError.store(capture_error(foreign_use, &scalarForeign), std::memory_order_release);
    scalarFreeError.store(capture_error(foreign_free, &scalarForeign), std::memory_order_release);
    tensorUseError.store(capture_error(foreign_use, &tensorForeign), std::memory_order_release);
    tensorFreeError.store(capture_error(foreign_free, &tensorForeign), std::memory_order_release);
  });
  foreign.join();
  if (scalarUseError.load(std::memory_order_acquire) != 16 ||
      scalarFreeError.load(std::memory_order_acquire) != 16 ||
      tensorUseError.load(std::memory_order_acquire) != 16 ||
      tensorFreeError.load(std::memory_order_acquire) != 16) {
    std::fprintf(stderr, "FAIL Autograd did not reject cross-thread use/free with Concurrency (16)\n");
    return 4;
  }
  const int32_t ownerScalar = fac_autograd_variable(scalarTape, 3.0);
  if (ownerScalar < 0) return 5;
  fac_autograd_free(scalarTape);
  const int32_t ownerTensor = fac_autograd_tensor_variable(tensorTape, x);
  if (ownerTensor < 0) return 6;
  fac_autograd_tensor_free(tensorTape);

  // Share only immutable trained models and an immutable input tensor. Each
  // inference call owns its output; each worker builds and frees private tapes.
  constexpr int kThreads = 8;
  constexpr int kRounds = 24;
  std::atomic<int> failures{0};
  std::vector<std::thread> workers;
  workers.reserve(kThreads);
  for (int t = 0; t < kThreads; ++t) {
    workers.emplace_back([&, t] {
      for (int round = 0; round < kRounds; ++round) {
        void *p1 = fac_ml_linear_predict(linear, x);
        void *p2 = fac_ml_kmeans_predict(kmeans, x);
        void *p3 = fac_ml_knn_predict(knn, x);
        const bool predictionsOk = same_values(p1, expectedLinear) &&
                                   same_values(p2, expectedKMeans) &&
                                   same_values(p3, expectedKNN);
        fac_tensor_free(p1);
        fac_tensor_free(p2);
        fac_tensor_free(p3);
        if (!predictionsOk) failures.fetch_add(1, std::memory_order_relaxed);

        void *st = fac_autograd_create();
        const double value = 1.0 + (double)t + (double)round / 10.0;
        const int32_t v = fac_autograd_variable(st, value);
        const int32_t sq = fac_autograd_mul(st, v, v);
        fac_autograd_backward(st, sq);
        if (std::fabs(fac_autograd_grad(st, v) - 2.0 * value) > 1e-12)
          failures.fetch_add(1, std::memory_order_relaxed);
        fac_autograd_free(st);

        void *tt = fac_autograd_tensor_create();
        const int32_t tv = fac_autograd_tensor_variable(tt, x);
        const int32_t sum = fac_autograd_tensor_sum(tt, tv);
        fac_autograd_tensor_backward(tt, sum);
        void *grad = fac_autograd_tensor_grad(tt, tv);
        bool gradientOk = grad && fac_tensor_rows(grad) == 4 && fac_tensor_cols(grad) == 2;
        if (gradientOk) {
          for (int r = 0; r < 4; ++r)
            for (int c = 0; c < 2; ++c)
              if (std::fabs(fac_tensor_get(grad, r, c) - 1.0) > 1e-12) gradientOk = false;
        }
        if (!gradientOk) failures.fetch_add(1, std::memory_order_relaxed);
        fac_tensor_free(grad);
        fac_autograd_tensor_free(tt);
      }
    });
  }
  for (auto &worker : workers) worker.join();

  fac_ml_free_knn(knn);
  fac_ml_free_kmeans(kmeans);
  fac_ml_free_model(linear);
  fac_tensor_free(y);
  fac_tensor_free(x);
  if (failures.load(std::memory_order_relaxed) != 0) {
    std::fprintf(stderr, "FAIL concurrent ML inference/private Autograd workloads (%d mismatches)\n",
                 failures.load(std::memory_order_relaxed));
    return 7;
  }
  std::puts("PASS V214: cross-thread Autograd tape rejection, per-thread scalar/tensor tapes and concurrent immutable ML model inference");
  return 0;
}
