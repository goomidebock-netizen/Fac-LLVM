#include <cassert>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>
#include <vector>

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct FacList {
  void *data; int64_t len, cap; int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};
struct Sock;
struct FacTlsHandle;
void fac_init(int32_t, char **);
void fac_shutdown();
void fac_try_enter(void *);
void fac_try_leave();
int32_t fac_err_code();
FacStr *fac_cstr_new(const char *);
void fac_str_free(FacStr *);
FacList *fac_list_new(int32_t, int32_t);
void fac_list_grow(FacList *);
void fac_list_free(FacList *);
Sock *fac_net_listen(int32_t);
int32_t fac_net_localport(Sock *);
Sock *fac_net_accept(Sock *);
Sock *fac_net_connect(FacStr *, int32_t);
void fac_net_settimeout(Sock *, int32_t);
void fac_net_close(Sock *);
int32_t fac_tls_available();
FacTlsHandle *fac_tls_wrapclient(Sock *, FacStr *);
FacTlsHandle *fac_tls_wrapserver(Sock *, FacStr *, FacStr *);
int32_t fac_tls_sendbytes(FacTlsHandle *, FacList *);
FacList *fac_tls_recvexactbytes(FacTlsHandle *, int32_t);
FacStr *fac_tls_version(FacTlsHandle *);
FacStr *fac_tls_cipher(FacTlsHandle *);
void fac_tls_close(FacTlsHandle *);
}

static FacList *bytes(const char *s, size_t n) {
  FacList *out = fac_list_new((int32_t)sizeof(int32_t), 0);
  while ((size_t)out->cap < n) fac_list_grow(out);
  out->len = (int64_t)n;
  int32_t *p = static_cast<int32_t *>(out->data);
  for (size_t i = 0; i < n; ++i) p[i] = (unsigned char)s[i];
  return out;
}
static std::string text(FacList *list) {
  std::string out;
  const int32_t *p = static_cast<const int32_t *>(list->data);
  for (int64_t i = 0; i < list->len; ++i) out.push_back((char)p[i]);
  return out;
}
static int try_tls_client(Sock *socket, FacStr *host) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    FacTlsHandle *handle = fac_tls_wrapclient(socket, host);
    if (handle) fac_tls_close(handle);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static FacTlsHandle *try_tls_server(Sock *socket, FacStr *cert, FacStr *key, int &error) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    FacTlsHandle *handle = fac_tls_wrapserver(socket, cert, key);
    fac_try_leave();
    error = 0;
    return handle;
  }
  error = fac_err_code();
  return nullptr;
}
static int try_net_timeout(Sock *socket) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { fac_net_settimeout(socket, 100); fac_try_leave(); return 0; }
  return fac_err_code();
}
static int try_tls_version(FacTlsHandle *handle) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { FacStr *value = fac_tls_version(handle); fac_str_free(value); fac_try_leave(); return 0; }
  return fac_err_code();
}
static int try_tls_recv(FacTlsHandle *handle) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) { FacList *value = fac_tls_recvexactbytes(handle, 1); fac_list_free(value); fac_try_leave(); return 0; }
  return fac_err_code();
}

int main(int argc, char **argv) {
  if (argc != 3) { std::fprintf(stderr, "usage: tls_loopback CERT KEY\n"); return 2; }
  fac_init(argc, argv);
  if (!fac_tls_available()) { std::puts("SKIP: optional OpenSSL TLS backend unavailable"); fac_shutdown(); return 77; }

  FacStr *cert = fac_cstr_new(argv[1]);
  FacStr *key = fac_cstr_new(argv[2]);
  FacStr *host = fac_cstr_new("localhost");
  Sock *listener = fac_net_listen(0);
  const int32_t port = fac_net_localport(listener);
  if (port <= 0) { std::fprintf(stderr, "FAIL: listener port\n"); return 1; }

  std::thread server([&] {
    Sock *accepted = fac_net_accept(listener);
    fac_net_settimeout(accepted, 5000);
    FacTlsHandle *stream = fac_tls_wrapserver(accepted, cert, key);
    FacList *request = fac_tls_recvexactbytes(stream, 5);
    if (text(request) != "hello") { std::fprintf(stderr, "FAIL: TLS server request payload\n"); std::abort(); }
    fac_list_free(request);
    FacList *reply = bytes("world", 5);
    if (fac_tls_sendbytes(stream, reply) != 5) { std::fprintf(stderr, "FAIL: TLS server write count\n"); std::abort(); }
    fac_list_free(reply);
    fac_tls_close(stream);
  });

  Sock *connected = fac_net_connect(host, port);
  fac_net_settimeout(connected, 5000);
  FacTlsHandle *client = fac_tls_wrapclient(connected, host);
  FacStr *version = fac_tls_version(client);
  FacStr *cipher = fac_tls_cipher(client);
  const std::string negotiated(version->data, (size_t)version->len);
  const std::string cipherName(cipher->data, (size_t)cipher->len);
  if (negotiated != "TLSv1.2" && negotiated != "TLSv1.3") {
    std::fprintf(stderr, "FAIL: unexpected TLS version %s\n", negotiated.c_str()); return 1;
  }
  if (cipherName.empty()) { std::fprintf(stderr, "FAIL: empty cipher name\n"); return 1; }
  FacList *request = bytes("hello", 5);
  if (fac_tls_sendbytes(client, request) != 5) { std::fprintf(stderr, "FAIL: TLS client write count\n"); return 1; }
  fac_list_free(request);
  FacList *reply = fac_tls_recvexactbytes(client, 5);
  if (text(reply) != "world") { std::fprintf(stderr, "FAIL: TLS client response payload\n"); return 1; }
  fac_list_free(reply);
  fac_tls_close(client);
  fac_tls_close(client); // Repeated close through an old alias is harmless.
  if (try_tls_version(client) != 11 || try_net_timeout(connected) != 11) {
    std::fprintf(stderr, "FAIL: closed TLS/socket aliases were not rejected\n"); return 1;
  }
  fac_net_close(connected); // The socket token was retired when TLS took ownership.
  server.join();

  fac_net_close(listener);

  // A blocking TLS read must release its per-stream lock through the FAC
  // longjmp cleanup stack so a concurrent close can finish after timeout.
  Sock *raceListener = fac_net_listen(0);
  const int32_t racePort = fac_net_localport(raceListener);
  std::thread raceServer([&] {
    Sock *accepted = fac_net_accept(raceListener);
    fac_net_settimeout(accepted, 1500);
    FacTlsHandle *peer = fac_tls_wrapserver(accepted, cert, key);
    std::this_thread::sleep_for(std::chrono::milliseconds(700));
    fac_tls_close(peer);
  });
  Sock *raceSocket = fac_net_connect(host, racePort);
  fac_net_settimeout(raceSocket, 260);
  FacTlsHandle *raceTls = fac_tls_wrapclient(raceSocket, host);
  if (try_tls_version(client) != 11) {
    std::fprintf(stderr, "FAIL: prior TLS token became valid after a later TLS handle allocation\n"); return 1;
  }
  if (try_net_timeout(raceSocket) != 11) {
    std::fprintf(stderr, "FAIL: raw socket token remained usable after TLS ownership transfer\n"); return 1;
  }
  std::atomic<int> raceReadError{0};
  std::thread raceReader([&] { raceReadError.store(try_tls_recv(raceTls), std::memory_order_release); });
  std::this_thread::sleep_for(std::chrono::milliseconds(50));
  fac_tls_close(raceTls); // Waits for SSL_read timeout; no use-after-free or stranded lock.
  raceReader.join();
  if (raceReadError.load(std::memory_order_acquire) != 11 || try_tls_version(raceTls) != 11) {
    std::fprintf(stderr, "FAIL: TLS close/read race did not reject the stale handle cleanly\n"); return 1;
  }
  fac_tls_close(raceTls);
  fac_net_close(raceSocket);
  raceServer.join();
  fac_net_close(raceListener);

  // A trusted certificate with the wrong DNS identity must not be accepted.
  Sock *verifyListener = fac_net_listen(0);
  const int32_t verifyPort = fac_net_localport(verifyListener);
  std::thread verifyServer([&] {
    Sock *accepted = fac_net_accept(verifyListener);
    fac_net_settimeout(accepted, 5000);
    int serverError = 0;
    FacTlsHandle *peer = try_tls_server(accepted, cert, key, serverError);
    if (peer) fac_tls_close(peer);
    else fac_net_close(accepted); // failed handshake does not transfer socket ownership
  });
  Sock *wrongIdentitySocket = fac_net_connect(host, verifyPort);
  fac_net_settimeout(wrongIdentitySocket, 5000);
  FacStr *wrongHost = fac_cstr_new("wrong-host.invalid");
  const int verifyError = try_tls_client(wrongIdentitySocket, wrongHost);
  if (verifyError != 11) {
    std::fprintf(stderr, "FAIL: TLS client accepted a certificate for the wrong DNS hostname (error=%d)\n", verifyError);
    return 1;
  }
  fac_net_close(wrongIdentitySocket); // socket remains caller-owned after a failed handshake
  verifyServer.join();
  fac_net_close(verifyListener);

  fac_str_free(host); fac_str_free(cert); fac_str_free(key); fac_str_free(wrongHost);
  fac_str_free(version); fac_str_free(cipher);
  fac_shutdown();
  std::printf("PASS: TLS loopback %s / %s; hostname mismatch rejected\n", negotiated.c_str(), cipherName.c_str());
  return 0;
}
