#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
case "$(uname -s 2>/dev/null || echo unknown)" in
  MINGW*|MSYS*|CYGWIN*) echo "SKIP TLS loopback: POSIX OpenSSL backend is not implemented on Windows"; exit 0 ;;
esac
OPENSSL=${OPENSSL:-openssl}
CXX=${CXX:-clang++}
if ! command -v "$OPENSSL" >/dev/null 2>&1; then
  echo "SKIP TLS loopback: openssl command is unavailable for generating a local test certificate"
  exit 0
fi
mkdir -p build/tls-test
CERT="$PWD/build/tls-test/cert.pem"
KEY="$PWD/build/tls-test/key.pem"
"$OPENSSL" req -x509 -newkey rsa:2048 -sha256 -nodes -keyout "$KEY" -out "$CERT" -days 2 \
  -subj '/CN=localhost' -addext 'subjectAltName=DNS:localhost' \
  -addext 'basicConstraints=critical,CA:TRUE' >/dev/null 2>&1
DL_LIB=""
case "$(uname -s 2>/dev/null || echo unknown)" in Linux*) DL_LIB="-ldl" ;; esac
"$CXX" -std=c++17 -O2 -pthread tests/runtime/tls_loopback.cpp build/fac_rt.o -lm $DL_LIB -o build/tls_loopback
set +e
SSL_CERT_FILE="$CERT" build/tls_loopback "$CERT" "$KEY"
status=$?
set -e
if [ "$status" -eq 77 ]; then
  echo "SKIP TLS loopback: optional OpenSSL runtime backend unavailable"
  exit 0
fi
[ "$status" -eq 0 ] || exit "$status"
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
"$FAC_COMPILER" tests/runtime/tls_websocket_loopback.fac -o build/tls_websocket_o0 -O0
SSL_CERT_FILE="$CERT" build/tls_websocket_o0
"$FAC_COMPILER" tests/runtime/tls_websocket_loopback.fac -o build/tls_websocket_o2 -O2
SSL_CERT_FILE="$CERT" build/tls_websocket_o2
