#include <array>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>

extern "C" void *fac_thread_start(void *closure);
extern "C" void fac_thread_join(void *handle);
extern "C" void fac_try_enter(void *jumpBuffer);
extern "C" int32_t fac_err_code();
extern "C" struct FacStr *fac_err_msg();
extern "C" void fac_str_free(FacStr *);
extern "C" void fac_cleanup_push(void *slot, int32_t kind, void *drop);
extern "C" void fac_tmp_push_drop(void *value, void *drop);
extern "C" [[noreturn]] void fac_throw(void *message, int32_t code);

struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct ClosureHeader { void *entry; int64_t refs; void (*drop)(void *); };

struct DropSlot {
  std::atomic<int> *count = nullptr;
  std::atomic<int> *orderIndex = nullptr;
  std::array<int, 3> *order = nullptr;
  int id = -1;
  bool shouldThrow = false;
};

static void count_drop(void *opaque) {
  auto *slot = static_cast<DropSlot *>(opaque);
  slot->count->fetch_add(1, std::memory_order_relaxed);
  const int position = slot->orderIndex->fetch_add(1, std::memory_order_relaxed);
  if (position >= 0 && position < static_cast<int>(slot->order->size()))
    (*slot->order)[static_cast<size_t>(position)] = slot->id;
  if (slot->shouldThrow) throw std::runtime_error("intentional drop failure");
}

struct UnwindClosure {
  ClosureHeader header;
  std::array<std::atomic<int>, 3> cleanupCounts{};
  std::array<std::atomic<int>, 3> temporaryCounts{};
  std::atomic<int> cleanupOrderIndex{0};
  std::atomic<int> temporaryOrderIndex{0};
  std::array<int, 3> cleanupOrder{{-1, -1, -1}};
  std::array<int, 3> temporaryOrder{{-1, -1, -1}};
  std::array<DropSlot, 3> cleanups{};
  std::array<DropSlot, 3> temporaries{};
  bool throwFacError;

  static void registerDrops(UnwindClosure *self) {
    for (size_t i = 0; i < 3; ++i) {
      self->cleanups[i] = DropSlot{&self->cleanupCounts[i], &self->cleanupOrderIndex,
                                    &self->cleanupOrder, static_cast<int>(i), i == 1};
      self->temporaries[i] = DropSlot{&self->temporaryCounts[i], &self->temporaryOrderIndex,
                                      &self->temporaryOrder, static_cast<int>(i), i == 1};
      fac_cleanup_push(&self->cleanups[i], 4, reinterpret_cast<void *>(count_drop));
      fac_tmp_push_drop(&self->temporaries[i], reinterpret_cast<void *>(count_drop));
    }
  }

  static void run(void *opaque) {
    auto *self = static_cast<UnwindClosure *>(opaque);
    registerDrops(self);
    if (self->throwFacError) fac_throw(nullptr, 17);
    throw std::runtime_error("primary callback failure");
  }

  explicit UnwindClosure(bool facError)
      : header{reinterpret_cast<void *>(run), -1, nullptr}, throwFacError(facError) {}
};

static int join_catching_error(void *handle) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fac_thread_join(handle);
    return 0;
  }
  return fac_err_code();
}

static bool all_dropped_once_in_lifo_order(const UnwindClosure &closure) {
  for (size_t i = 0; i < 3; ++i) {
    if (closure.cleanupCounts[i].load(std::memory_order_relaxed) != 1) return false;
    if (closure.temporaryCounts[i].load(std::memory_order_relaxed) != 1) return false;
    const int expected = 2 - static_cast<int>(i);
    if (closure.cleanupOrder[i] != expected || closure.temporaryOrder[i] != expected) return false;
  }
  return closure.cleanupOrderIndex.load(std::memory_order_relaxed) == 3 &&
         closure.temporaryOrderIndex.load(std::memory_order_relaxed) == 3;
}

static bool error_has_unwind_note() {
  FacStr *message = fac_err_msg();
  if (!message) return false;
  const bool hasCleanup = std::strstr(message->data, "cleanup callbacks") != nullptr;
  const bool hasTemporary = std::strstr(message->data, "temporary drops") != nullptr;
  fac_str_free(message);
  return hasCleanup && hasTemporary;
}

int main() {
  UnwindClosure nativeException(false);
  void *nativeHandle = fac_thread_start(&nativeException);
  if (join_catching_error(nativeHandle) != 8)
    return std::fprintf(stderr, "FAIL: native callback error code changed during cleanup\n"), 1;
  if (!all_dropped_once_in_lifo_order(nativeException))
    return std::fprintf(stderr, "FAIL: throwing cleanup prevented remaining LIFO cleanup/temporary drops\n"), 1;
  if (!error_has_unwind_note())
    return std::fprintf(stderr, "FAIL: contained cleanup failures were not reported by join\n"), 1;

  UnwindClosure facError(true);
  void *facHandle = fac_thread_start(&facError);
  if (join_catching_error(facHandle) != 17)
    return std::fprintf(stderr, "FAIL: cleanup exception replaced the original FAC error\n"), 1;
  if (!all_dropped_once_in_lifo_order(facError))
    return std::fprintf(stderr, "FAIL: FAC error unwind stopped or changed LIFO order after a throwing drop\n"), 1;
  if (!error_has_unwind_note())
    return std::fprintf(stderr, "FAIL: FAC error did not retain the contained cleanup diagnostic\n"), 1;

  std::puts("PASS cleanup exception containment, complete LIFO drain, temporary drops and primary error preservation");
  return 0;
}
