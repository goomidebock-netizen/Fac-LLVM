#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>

struct FacStr { char *data; int64_t len, cap, ncp, flags; };
extern "C" {
FacStr *fac_str_from_chars(const char *, int64_t);
void fac_str_free(FacStr *);
void *fac_gpu_buffer_create(int64_t);
void fac_gpu_buffer_free(void *);
int64_t fac_gpu_buffer_size(void *);
int32_t fac_gpu_buffer_write(void *, int64_t, FacStr *);
FacStr *fac_gpu_buffer_read(void *, int64_t, int64_t);
int32_t fac_gpu_buffer_copy(void *, int64_t, void *, int64_t, int64_t);
int32_t fac_gpu_write_f64(void *, int64_t, double);
double fac_gpu_read_f64(void *, int64_t);
int32_t fac_gpu_add_f64(void *, void *, void *, int64_t);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL buffer bounds: %s\n", message);
  return 1;
}

static bool bytesEqual(FacStr *value, const char *expected, int64_t length) {
  const bool equal = value && value->len == length &&
      (length == 0 || std::memcmp(value->data, expected, static_cast<size_t>(length)) == 0);
  if (value) fac_str_free(value);
  return equal;
}

static FacStr *makeString(const char *bytes, int64_t length) {
  return fac_str_from_chars(bytes, length);
}

int main() {
  void *buffer = fac_gpu_buffer_create(16);
  void *other = fac_gpu_buffer_create(16);
  if (!buffer || !other) return fail("allocate fixed-size buffers");
  if (fac_gpu_buffer_size(buffer) != 16) return fail("bufferSize reports exact byte count");

  const char initial[] = "abcdefghijklmnop";
  FacStr *input = makeString(initial, 16);
  if (!input || !fac_gpu_buffer_write(buffer, 0, input)) return fail("write complete buffer");
  fac_str_free(input);
  if (!bytesEqual(fac_gpu_buffer_read(buffer, 0, 16), initial, 16))
    return fail("read complete buffer");

  // copyBuffer must have memmove semantics when source and destination overlap.
  if (!fac_gpu_buffer_copy(buffer, 4, buffer, 0, 8)) return fail("overlapping forward copy");
  const char afterForward[] = "abcdabcdefghmnop";
  if (!bytesEqual(fac_gpu_buffer_read(buffer, 0, 16), afterForward, 16))
    return fail("forward overlap preserves source bytes");
  if (!fac_gpu_buffer_copy(buffer, 0, buffer, 4, 8)) return fail("overlapping backward copy");
  const char afterBackward[] = "abcdefghefghmnop";
  if (!bytesEqual(fac_gpu_buffer_read(buffer, 0, 16), afterBackward, 16))
    return fail("backward overlap preserves source bytes");

  // End-aligned empty ranges are valid; every non-empty out-of-bounds range fails.
  if (!fac_gpu_buffer_copy(buffer, 16, buffer, 16, 0)) return fail("empty copy at end boundary");
  if (!bytesEqual(fac_gpu_buffer_read(buffer, 16, 0), "", 0)) return fail("empty read at end boundary");
  if (fac_gpu_buffer_copy(buffer, -1, other, 0, 1)) return fail("negative destination offset");
  if (fac_gpu_buffer_copy(buffer, 0, other, -1, 1)) return fail("negative source offset");
  if (fac_gpu_buffer_copy(buffer, 15, other, 0, 2)) return fail("destination range overflow");
  if (fac_gpu_buffer_copy(buffer, 0, other, 15, 2)) return fail("source range overflow");
  if (fac_gpu_buffer_copy(buffer, INT64_MAX, other, 0, 1)) return fail("maximum signed destination offset");
  if (fac_gpu_buffer_copy(buffer, 0, other, 0, INT64_MAX)) return fail("maximum signed copy length");
  if (fac_gpu_buffer_copy(buffer, 0, other, 0, -1)) return fail("negative copy length");

  // Invalid writes are rejected without changing existing bytes.
  const char marker = 'Z';
  input = makeString(&marker, 1);
  if (!input) return fail("create marker string");
  if (fac_gpu_buffer_write(buffer, 16, input)) return fail("non-empty write at end boundary");
  if (fac_gpu_buffer_write(buffer, -1, input)) return fail("negative write offset");
  if (fac_gpu_buffer_write(buffer, INT64_MAX, input)) return fail("maximum signed write offset");
  fac_str_free(input);
  if (!bytesEqual(fac_gpu_buffer_read(buffer, 0, 16), afterBackward, 16))
    return fail("invalid writes leave buffer unchanged");

  // Zero-sized buffers allow an empty write/read but reject any byte access.
  void *empty = fac_gpu_buffer_create(0);
  if (!empty || fac_gpu_buffer_size(empty) != 0) return fail("create zero-sized buffer");
  input = makeString("", 0);
  if (!input || !fac_gpu_buffer_write(empty, 0, input)) return fail("empty write to zero-sized buffer");
  fac_str_free(input);
  if (!bytesEqual(fac_gpu_buffer_read(empty, 0, 0), "", 0)) return fail("empty read from zero-sized buffer");
  input = makeString("x", 1);
  if (!input || fac_gpu_buffer_write(empty, 0, input)) return fail("non-empty write to zero-sized buffer");
  fac_str_free(input);

  // Float64 access must reject partial trailing elements and non-finite values.
  void *partial = fac_gpu_buffer_create(15);
  if (!partial || !fac_gpu_write_f64(partial, 0, 3.5)) return fail("first full f64 slot");
  if (fac_gpu_write_f64(partial, 1, 4.5)) return fail("partial trailing f64 slot");
  if (fac_gpu_read_f64(partial, 0) != 3.5) return fail("partial-slot rejection preserves valid slot");

  void *numeric = fac_gpu_buffer_create(8);
  void *rhs = fac_gpu_buffer_create(8);
  void *result = fac_gpu_buffer_create(8);
  if (!numeric || !rhs || !result) return fail("allocate numeric buffers");
  if (!fac_gpu_write_f64(numeric, 0, 1.0) || !fac_gpu_write_f64(rhs, 0, 2.0) ||
      !fac_gpu_write_f64(result, 0, -123.0)) return fail("initialize numeric buffers");

  // Raw byte access can carry arbitrary bits. Numeric operations must validate
  // decoded values and preserve the entire destination on a NaN payload.
  // Every byte is non-zero so it can pass through the legacy string C ABI.
  const char quietNaNLE[8] = {(char)0xff, (char)0xff, (char)0xff, (char)0xff,
                             (char)0xff, (char)0xff, (char)0xff, (char)0x7f};
  input = makeString(quietNaNLE, 8);
  if (!input || input->len != 8 || !fac_gpu_buffer_write(numeric, 0, input))
    return fail("inject raw non-finite bytes");
  fac_str_free(input);
  if (fac_gpu_add_f64(result, numeric, rhs, 1)) return fail("reject NaN numeric input");
  if (fac_gpu_read_f64(result, 0) != -123.0) return fail("NaN input leaves output unchanged");
  if (fac_gpu_write_f64(result, 0, std::numeric_limits<double>::infinity()))
    return fail("reject infinite typed write");
  if (fac_gpu_read_f64(result, 0) != -123.0) return fail("rejected typed write preserves destination");

  fac_gpu_buffer_free(result);
  fac_gpu_buffer_free(rhs);
  fac_gpu_buffer_free(numeric);
  fac_gpu_buffer_free(partial);
  fac_gpu_buffer_free(empty);
  fac_gpu_buffer_free(other);
  fac_gpu_buffer_free(buffer);
  std::puts("PASS buffer bounds / zero-length edges / overlapping memmove / transactional numeric validation");
  return 0;
}
