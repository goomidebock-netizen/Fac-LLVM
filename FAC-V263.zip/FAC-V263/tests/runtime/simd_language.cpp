#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>

extern "C" {
void *fac_gpu_buffer_create(int64_t);
void fac_gpu_buffer_free(void *);
int32_t fac_gpu_write_f64(void *, int64_t, double);
double fac_gpu_read_f64(void *, int64_t);
int32_t fac_simd_width_f64();
int32_t fac_simd_native_f64x2();
int32_t fac_simd_add_f64x2(void *, void *, void *, int64_t);
int32_t fac_simd_sub_f64x2(void *, void *, void *, int64_t);
int32_t fac_simd_mul_f64x2(void *, void *, void *, int64_t);
int32_t fac_simd_div_f64x2(void *, void *, void *, int64_t);
int32_t fac_simd_scale_f64x2(void *, void *, int64_t, double);
}

static int fail(const char *what) {
  std::fprintf(stderr, "FAIL SIMD language API: %s\n", what);
  return 1;
}

static bool near(double a, double b) {
  const double s = std::fmax(1.0, std::fmax(std::fabs(a), std::fabs(b)));
  return std::fabs(a - b) <= s * 1e-13;
}

int main() {
  constexpr int64_t n = 1026; // two full blocks plus one two-lane tail
  void *a = fac_gpu_buffer_create(n * 8);
  void *b = fac_gpu_buffer_create(n * 8);
  void *out = fac_gpu_buffer_create(n * 8);
  if (!a || !b || !out) return fail("allocate buffers");
  if (fac_simd_width_f64() != 2) return fail("logical vector width must be two");
#if defined(__GNUC__) || defined(__clang__)
#if defined(__x86_64__) || defined(__amd64__) || defined(__aarch64__) || defined(__arm64__)
  if (!fac_simd_native_f64x2()) return fail("expected native x2 on baseline SIMD target");
#endif
#endif

  for (int64_t i = 0; i < n; ++i) {
    if (!fac_gpu_write_f64(a, i, (double)(i + 2)) ||
        !fac_gpu_write_f64(b, i, (double)(i + 4))) return fail("write inputs");
    if (!fac_gpu_write_f64(out, i, -99.0)) return fail("initialize output");
  }
  if (!fac_simd_add_f64x2(out, a, b, 0)) return fail("zero count should be a valid no-op");

  if (!fac_simd_add_f64x2(out, a, b, n)) return fail("add accepted inputs");
  for (int64_t i = 0; i < n; ++i)
    if (!near(fac_gpu_read_f64(out, i), (double)(2 * i + 6))) return fail("add result");

  if (!fac_simd_sub_f64x2(out, b, a, n)) return fail("sub accepted inputs");
  for (int64_t i = 0; i < n; ++i)
    if (!near(fac_gpu_read_f64(out, i), 2.0)) return fail("sub result");

  if (!fac_simd_mul_f64x2(out, a, b, n)) return fail("mul accepted inputs");
  for (int64_t i = 0; i < n; ++i)
    if (!near(fac_gpu_read_f64(out, i), (double)(i + 2) * (double)(i + 4))) return fail("mul result");

  if (!fac_simd_div_f64x2(out, a, b, n)) return fail("div accepted inputs");
  for (int64_t i = 0; i < n; ++i)
    if (!near(fac_gpu_read_f64(out, i), (double)(i + 2) / (double)(i + 4))) return fail("div result");

  if (!fac_simd_scale_f64x2(out, a, n, 0.5)) return fail("scale accepted inputs");
  for (int64_t i = 0; i < n; ++i)
    if (!near(fac_gpu_read_f64(out, i), (double)(i + 2) * 0.5)) return fail("scale result");

  // In-place aliases are supported because output is fully staged before commit.
  if (!fac_simd_add_f64x2(a, a, b, n)) return fail("in-place add rejected");
  if (!near(fac_gpu_read_f64(a, 512), 2.0 * 512.0 + 6.0)) return fail("in-place alias result");

  // Odd lane counts are rejected and do not change destination.
  if (!fac_gpu_write_f64(out, 0, -777.0)) return fail("prepare odd-count sentinel");
  if (fac_simd_add_f64x2(out, a, b, n - 1)) return fail("odd count accepted");
  if (fac_simd_add_f64x2(out, a, b, -2)) return fail("negative count accepted");
  if (fac_simd_add_f64x2(out, a, b, n + 2)) return fail("out-of-range count accepted");
  if (fac_gpu_read_f64(out, 0) != -777.0) return fail("invalid count partially wrote output");

  // Division by zero fails transactionally.
  if (!fac_gpu_write_f64(b, 700, 0.0)) return fail("write zero divisor");
  if (fac_gpu_write_f64(out, 700, -888.0) == 0) return fail("prepare div sentinel");
  if (fac_simd_div_f64x2(out, a, b, n)) return fail("division by zero accepted");
  if (fac_gpu_read_f64(out, 0) != -777.0 || fac_gpu_read_f64(out, 700) != -888.0)
    return fail("division failure partially wrote output");

  // Overflow is rejected without changing destination.
  fac_gpu_write_f64(a, 100, std::numeric_limits<double>::max());
  fac_gpu_write_f64(b, 100, 2.0);
  if (fac_simd_mul_f64x2(out, a, b, n)) return fail("overflow multiplication accepted");
  if (fac_gpu_read_f64(out, 0) != -777.0 || fac_gpu_read_f64(out, 700) != -888.0)
    return fail("overflow partially wrote output");

  fac_gpu_buffer_free(out);
  fac_gpu_buffer_free(b);
  fac_gpu_buffer_free(a);
  std::puts("PASS SIMD public x2 API / arithmetic / aliasing / even-lane guard / transactional errors");
  return 0;
}
