#include <cstdint>
#include <cstdio>
#include <cstdlib>

extern "C" {
struct FacList {
  void *data;
  int64_t len, cap;
  int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};
FacList *fac_list_new(int32_t esz, int32_t ek);
void fac_list_insert(FacList *list, int64_t index, const void *value);
void fac_list_free(FacList *list);
}

static bool equals(const FacList *list, const int *expected, int64_t count) {
  if (!list || list->len != count) return false;
  const int *values = static_cast<const int *>(list->data);
  for (int64_t i = 0; i < count; ++i) if (values[i] != expected[i]) return false;
  return true;
}

int main() {
  FacList *list = fac_list_new((int32_t)sizeof(int), 0);
  for (int value = 0; value < 8; ++value)
    fac_list_insert(list, list->len, &value);

  // Full capacity: source points into the allocation that insert must reallocate.
  const int *source = static_cast<const int *>(list->data) + 6;
  fac_list_insert(list, 1, source);
  const int afterGrow[] = {0, 6, 1, 2, 3, 4, 5, 6, 7};
  if (!equals(list, afterGrow, 9)) {
    std::fprintf(stderr, "alias insert failed across reallocation\n");
    fac_list_free(list);
    return 1;
  }

  // No growth: source still aliases the list, but memmove would overwrite it.
  source = static_cast<const int *>(list->data) + 8;
  fac_list_insert(list, 0, source);
  const int afterShift[] = {7, 0, 6, 1, 2, 3, 4, 5, 6, 7};
  if (!equals(list, afterShift, 10)) {
    std::fprintf(stderr, "alias insert failed across in-place shift\n");
    fac_list_free(list);
    return 1;
  }

  fac_list_free(list);
  std::puts("PASS list.insert alias/reallocation");
  return 0;
}
