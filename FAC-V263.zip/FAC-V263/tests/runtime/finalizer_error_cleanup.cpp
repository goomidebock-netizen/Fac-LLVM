#include <cstdint>
#include <cstdio>
#include <stdexcept>

extern "C" {
struct FacObj;
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn);
void fac_obj_retain(void *object);
void fac_obj_release(void *object);
void fac_cycle_visit(void *object);
int64_t fac_obj_collect_cycles();
uint64_t fac_obj_live_count();
void fac_mem_start_tracking();
uint64_t fac_mem_blocks();
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
[[noreturn]] void fac_throw(void *message, int32_t code);
}

struct LinkObject {
  void *next;
};

static int singleFinalizeCalls = 0;
static int singleDropCalls = 0;
static int cppFinalizeCalls = 0;
static int cppDropCalls = 0;
static int cycleFinalizeCalls = 0;
static int cycleDropCalls = 0;

static void finalizeSingle(void *) {
  ++singleFinalizeCalls;
  fac_throw(nullptr, 23);
}
static void dropSingle(void *) { ++singleDropCalls; }
static void finalizeCpp(void *) {
  ++cppFinalizeCalls;
  throw std::runtime_error("expected finalizer exception");
}
static void dropCpp(void *) { ++cppDropCalls; }

static void traceLink(void *opaque) {
  auto *object = static_cast<LinkObject *>(opaque);
  if (object->next) fac_cycle_visit(object->next);
}
static void finalizeCycle(void *) {
  ++cycleFinalizeCalls;
  fac_throw(nullptr, 29);
}
static void dropCycle(void *opaque) {
  ++cycleDropCalls;
  auto *object = static_cast<LinkObject *>(opaque);
  void *next = object->next;
  object->next = nullptr;
  if (next) fac_obj_release(next);
}

static int catchRelease(void *object) {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    fac_obj_release(object);
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}
static int catchCycleCollection() {
  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    (void)fac_obj_collect_cycles();
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL: %s\n", message);
  return 1;
}

int main() {
  fac_mem_start_tracking();
  const uint64_t liveBefore = fac_obj_live_count();
  const uint64_t blocksBefore = fac_mem_blocks();

  void *single = fac_obj_new((int64_t)sizeof(LinkObject),
                             reinterpret_cast<void *>(dropSingle), nullptr,
                             nullptr, reinterpret_cast<void *>(finalizeSingle));
  if (catchRelease(single) != 23) return fail("single-object finalizer error was not propagated");
  if (singleFinalizeCalls != 1 || singleDropCalls != 1)
    return fail("single-object drop did not run exactly once after finalizer error");
  if (fac_obj_live_count() != liveBefore || fac_mem_blocks() != blocksBefore)
    return fail("single object storage remained live after finalizer error");

  void *cppThrowing = fac_obj_new((int64_t)sizeof(LinkObject),
      reinterpret_cast<void *>(dropCpp), nullptr, nullptr,
      reinterpret_cast<void *>(finalizeCpp));
  if (catchRelease(cppThrowing) != 7)
    return fail("C++ finalizer exception was not translated to a FAC Runtime error");
  if (cppFinalizeCalls != 1 || cppDropCalls != 1 ||
      fac_obj_live_count() != liveBefore || fac_mem_blocks() != blocksBefore)
    return fail("C++ finalizer exception skipped drop or object storage release");

  auto *a = static_cast<LinkObject *>(fac_obj_new((int64_t)sizeof(LinkObject),
      reinterpret_cast<void *>(dropCycle), nullptr, reinterpret_cast<void *>(traceLink),
      reinterpret_cast<void *>(finalizeCycle)));
  auto *b = static_cast<LinkObject *>(fac_obj_new((int64_t)sizeof(LinkObject),
      reinterpret_cast<void *>(dropCycle), nullptr, reinterpret_cast<void *>(traceLink),
      reinterpret_cast<void *>(finalizeCycle)));
  a->next = b; fac_obj_retain(b);
  b->next = a; fac_obj_retain(a);
  // Drop the two caller-owned roots: only the mutual cycle remains.
  fac_obj_release(a);
  fac_obj_release(b);

  if (catchCycleCollection() != 29)
    return fail("cycle finalizer error was not propagated after collection");
  if (cycleFinalizeCalls != 2 || cycleDropCalls != 2)
    return fail("cycle collection did not finalize and drop every peer exactly once");
  if (fac_obj_live_count() != liveBefore || fac_mem_blocks() != blocksBefore)
    return fail("cycle objects remained live after finalizer error");
  if (fac_obj_collect_cycles() != 0)
    return fail("cycle collector remained disabled after a finalizer error");

  std::puts("PASS object release and cycle collection finish cleanup before propagating finalizer errors");
  return 0;
}
