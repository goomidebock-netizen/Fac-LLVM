#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <vector>

static std::atomic<long long> g_fail_after{-1};
static bool should_fail_allocation() noexcept {
  long long current = g_fail_after.load(std::memory_order_relaxed);
  while (current >= 0) {
    if (current == 0) {
      if (g_fail_after.compare_exchange_weak(current, -1, std::memory_order_relaxed)) return true;
    } else if (g_fail_after.compare_exchange_weak(current, current - 1, std::memory_order_relaxed)) {
      return false;
    }
  }
  return false;
}
static void *test_new(std::size_t size) {
  if (should_fail_allocation()) throw std::bad_alloc();
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new(std::size_t size) { return test_new(size); }
void *operator new[](std::size_t size) { return test_new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

// White-box mirrors of Runtime-private layouts. These let the regression test
// inject inconsistent opaque state without exposing any new public API.
struct FacTensor { int64_t rows = 0, cols = 0; std::vector<double> values; };
struct FacMomentumState { FacTensor velocity; };
struct FacRMSPropState { FacTensor squareAverage; };
struct FacAdamState { FacTensor first, second; uint64_t step = 0; };
struct FacDataSplit { FacTensor train, test; };
struct FacTensorGradNode {
  FacTensor value;
  std::vector<double> grad;
  int32_t a = -1, b = -1, op = 0;
  double scalar = 0.0;
};
struct FacTensorGradTape { std::vector<FacTensorGradNode> nodes; uint64_t stored_elements = 0; uint64_t owner_token; };

extern "C" {
void fac_try_enter(void *jumpBuffer);
void fac_try_leave();
int32_t fac_err_code();
void *fac_tensor_create(int32_t, int32_t);
void fac_tensor_free(void *);
void *fac_gpu_buffer_create(int64_t);
void fac_gpu_buffer_free(void *);
int64_t fac_tensor_rows(void *);
int64_t fac_tensor_size(void *);
double fac_tensor_get(void *, int32_t, int32_t);
void *fac_data_train_test_split(void *, double, int64_t);
void *fac_data_split_train(void *);
void fac_data_split_free(void *);
void *fac_autograd_tensor_create();
void fac_autograd_tensor_free(void *);
void *fac_autograd_tensor_value(void *, int32_t);
void *fac_optim_momentum_create(int32_t, int32_t);
void *fac_optim_rmsprop_create(int32_t, int32_t);
void *fac_optim_adam_create(int32_t, int32_t);
void fac_optim_momentum_free(void *);
void fac_optim_rmsprop_free(void *);
void fac_optim_adam_free(void *);
void fac_optim_momentum_step(void *, void *, void *, double, double);
void fac_optim_rmsprop_step(void *, void *, void *, double, double, double);
void fac_optim_adam_step(void *, void *, void *, double);
}

static int fail(const char *message) {
  std::fprintf(stderr, "FAIL tensor shape safety: %s\n", message);
  return 1;
}
template <typename Fn> static int capture_error(Fn fn) {
  void *jumpBuffer[5]{};
  fac_try_enter(jumpBuffer);
  if (__builtin_setjmp(jumpBuffer) == 0) {
    fn();
    fac_try_leave();
    return 0;
  }
  return fac_err_code();
}

int main() {
  FacTensor valid;
  valid.rows = 2; valid.cols = 2; valid.values = {1.0, 2.0, 3.0, 4.0};
  if (fac_tensor_rows(&valid) != 2 || fac_tensor_size(&valid) != 4 ||
      fac_tensor_get(&valid, 1, 1) != 4.0)
    return fail("valid shape and row-major access changed");

  FacTensor negative;
  negative.rows = -1; negative.cols = 2; negative.values = {1.0, 2.0};
  if (capture_error([&] { (void)fac_tensor_rows(&negative); }) != 18)
    return fail("negative rows were not rejected at the handle boundary");

  FacTensor zero;
  zero.rows = 0; zero.cols = 2;
  if (capture_error([&] { (void)fac_tensor_size(&zero); }) != 18)
    return fail("zero-sized tensor was not rejected");

  FacTensor overBudget;
  overBudget.rows = 8'388'609; overBudget.cols = 2;
  if (capture_error([&] { (void)fac_tensor_rows(&overBudget); }) != 8)
    return fail("oversized tensor was not rejected before backing-store access");

  FacTensor tooManyColumns;
  tooManyColumns.rows = 1; tooManyColumns.cols = 16'777'217;
  if (capture_error([&] { (void)fac_tensor_rows(&tooManyColumns); }) != 8)
    return fail("oversized one-row tensor was not rejected");

  FacTensor shortStorage;
  shortStorage.rows = 2; shortStorage.cols = 2; shortStorage.values = {1.0, 2.0, 3.0};
  if (capture_error([&] { (void)fac_tensor_get(&shortStorage, 1, 1); }) != 18)
    return fail("short backing storage was not rejected before indexed access");

  FacTensor longStorage;
  longStorage.rows = 1; longStorage.cols = 1; longStorage.values = {1.0, 2.0};
  if (capture_error([&] { (void)fac_tensor_size(&longStorage); }) != 18)
    return fail("excess backing storage was not rejected");

  // Embedded optimizer tensors are separate state objects, not public Tensor
  // handles. Their vectors must be validated before an optimizer indexes them.
  void *params = fac_tensor_create(1, 1);
  void *grads = fac_tensor_create(1, 1);
  if (!params || !grads) return fail("create optimizer input tensors");
  FacMomentumState momentum;
  momentum.velocity.rows = 1; momentum.velocity.cols = 1; // deliberately missing value
  if (capture_error([&] { fac_optim_momentum_step(&momentum, params, grads, 0.1, 0.9); }) != 18)
    return fail("momentum state backing mismatch was not rejected");

  FacRMSPropState rms;
  rms.squareAverage.rows = 1; rms.squareAverage.cols = 1;
  if (capture_error([&] { fac_optim_rmsprop_step(&rms, params, grads, 0.1, 0.9, 1e-8); }) != 18)
    return fail("RMSProp state backing mismatch was not rejected");

  FacAdamState adam;
  adam.first.rows = 1; adam.first.cols = 1; adam.first.values = {0.0};
  adam.second.rows = 1; adam.second.cols = 1;
  if (capture_error([&] { fac_optim_adam_step(&adam, params, grads, 0.1); }) != 18)
    return fail("Adam second-moment backing mismatch was not rejected");

  FacDataSplit split;
  split.train.rows = 1; split.train.cols = 1;
  if (capture_error([&] { (void)fac_data_split_train(&split); }) != 18)
    return fail("split tensor backing mismatch was not rejected");

  auto *tape = static_cast<FacTensorGradTape *>(fac_autograd_tensor_create());
  if (!tape) return fail("autograd tensor tape allocation failed");
  FacTensorGradNode node;
  node.value.rows = 1; node.value.cols = 1; // invalid backing and gradient storage
  tape->nodes.push_back(node);
  const int autogradError = capture_error([&] { (void)fac_autograd_tensor_value(tape, 0); });
  fac_autograd_tensor_free(tape);
  if (autogradError != 18)
    return fail("autograd node tensor invariant was not checked");

  // Tensor and optimizer-state constructors must translate allocation failure
  // into FAC Resource errors rather than leaking std::bad_alloc across the C ABI.
  int allocationError = capture_error([&] {
    g_fail_after.store(0, std::memory_order_relaxed);
    (void)fac_tensor_create(1, 1);
    g_fail_after.store(-1, std::memory_order_relaxed);
  });
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (allocationError != 5) return fail("tensor allocation failure was not translated to FAC Resource");
  allocationError = capture_error([&] {
    g_fail_after.store(0, std::memory_order_relaxed);
    (void)fac_optim_momentum_create(1, 1);
    g_fail_after.store(-1, std::memory_order_relaxed);
  });
  g_fail_after.store(-1, std::memory_order_relaxed);
  if (allocationError != 5) return fail("optimizer state allocation failure was not translated to FAC Resource");
  for (long long failAt = 0; failAt < 2; ++failAt) {
    allocationError = capture_error([&] {
      g_fail_after.store(failAt, std::memory_order_relaxed);
      (void)fac_gpu_buffer_create(16);
      g_fail_after.store(-1, std::memory_order_relaxed);
    });
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (allocationError != 5)
      return fail("byte-buffer object/backing allocation failure was not translated to FAC Resource");
  }

  // The split builder owns two Tensor allocations and an index workspace. Any
  // injected failure must unwind all registered temporaries and leave input intact.
  void *splitInput = fac_tensor_create(2, 1);
  if (!splitInput) return fail("create train/test split input");
  int splitFailures = 0, splitSuccesses = 0;
  for (long long failAt = 0; failAt < 16; ++failAt) {
    void *splitResult = nullptr;
    const int error = capture_error([&] {
      g_fail_after.store(failAt, std::memory_order_relaxed);
      splitResult = fac_data_train_test_split(splitInput, 0.5, 7);
      g_fail_after.store(-1, std::memory_order_relaxed);
    });
    g_fail_after.store(-1, std::memory_order_relaxed);
    if (error == 0) { ++splitSuccesses; fac_data_split_free(splitResult); }
    else if (error == 5) ++splitFailures;
    else return fail("split allocation failure produced a non-Resource error");
    if (fac_tensor_rows(splitInput) != 2) return fail("split allocation failure damaged its input Tensor");
  }
  fac_tensor_free(splitInput);
  if (splitFailures == 0 || splitSuccesses == 0)
    return fail("split OOM injection did not cover both rollback and successful construction");

  fac_tensor_free(grads);
  fac_tensor_free(params);
  std::puts("PASS Tensor shape/backing-store invariants / optimizer-state validation / split and autograd validation / OOM translation");
  return 0;
}
