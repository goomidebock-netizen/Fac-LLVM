#include <stdio.h>
#include <stdlib.h>
int main(void) {
    long cap = 4, len = 0; long *xs = malloc(cap * 8);
    for (int i = 0; i < 20000000; i++) { if (len == cap) { cap *= 2; xs = realloc(xs, cap * 8); } xs[len++] = i % 1000; }
    long sum = 0; for (long i = 0; i < len; i++) sum += xs[i];
    printf("%ld %ld\n", sum, len); free(xs); return 0;
}
