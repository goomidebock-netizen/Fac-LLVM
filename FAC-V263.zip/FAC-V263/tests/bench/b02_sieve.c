#include <stdio.h>
#include <stdlib.h>
int main(void) {
    int n = 20000000; unsigned char *flags = malloc(20000001);
    for (int i = 0; i <= n; i++) flags[i] = 0;
    int count = 0;
    for (int i = 2; i <= n; i++) if (flags[i] == 0) { count += 1; for (int j = i + i; j <= n; j += i) flags[j] = 1; }
    printf("%d\n", count); free(flags); return 0;
}
