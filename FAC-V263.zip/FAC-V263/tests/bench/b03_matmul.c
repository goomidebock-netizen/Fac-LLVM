#include <stdio.h>
#include <stdlib.h>
int main(void) {
    int n = 600; long *a = malloc(360000 * 8), *b = malloc(360000 * 8), *c = malloc(360000 * 8);
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) { a[i*n+j] = (i*31 + j*17) % 100; b[i*n+j] = (i*13 + j*7) % 100; c[i*n+j] = 0; }
    for (int i = 0; i < n; i++) for (int k = 0; k < n; k++) { long aik = a[i*n+k]; for (int j = 0; j < n; j++) c[i*n+j] += aik * b[k*n+j]; }
    long sum = 0; for (int i = 0; i < 360000; i++) sum = (sum + c[i]) % 1000000007;
    printf("%ld\n", sum); free(a); free(b); free(c); return 0;
}
