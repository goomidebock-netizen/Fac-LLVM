#!/usr/bin/env python3
"""FAC benchmark runner: compiles every tests/bench/bNN_*.fac with facc, compiles the C/C++ reference next to it,
checks both print the expected checksum, and reports median-of-N wall time.

  python3 tests/bench/run_bench.py                 # all benchmarks, 3 runs each
  python3 tests/bench/run_bench.py --runs 5 --only fib,sieve
  python3 tests/bench/run_bench.py --facc build/facc --cc clang

Columns: C = reference built with -O2; FAC = facc -O2 (bounds checks on); FAC-fast = facc -O2 --unsafe-fast. The runner uses
median wall time to reduce sensitivity to a single noisy sample. Checksums are validated before timings are accepted."""
import argparse, os, platform, shutil, statistics, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))

def run(cmd, **kw):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, **kw)

def median_time(binary, runs, expect):
    samples, outputs = [], []
    for _ in range(runs):
        t0 = time.perf_counter()
        p = run([binary])
        samples.append(time.perf_counter() - t0)
        outputs.append(p.stdout.strip())
        if p.returncode != 0:
            return None, "exit code %d: %s" % (p.returncode, p.stderr.strip()[:120])
    if any(out != expect for out in outputs):
        return statistics.median(samples), "MISMATCH: got %r expected %r" % (outputs[-1], expect)
    return statistics.median(samples), None

def fmt(x):
    return "%8.0f" % (x * 1000) if x is not None else "       -"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--facc", default=os.path.join(ROOT, "build", "facc"))
    ap.add_argument("--cc", default=os.environ.get("CC", "cc"))
    ap.add_argument("--cxx", default=os.environ.get("CXX", "c++"))
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    only = [s for s in a.only.split(",") if s]
    names = sorted(f[:-4] for f in os.listdir(HERE) if f.startswith("b") and f.endswith(".fac"))
    names = [n for n in names if not only or any(o in n for o in only)]
    tmp = tempfile.mkdtemp(prefix="fac-bench.")
    env = dict(os.environ, FAC_HOME=ROOT)
    print("machine : %s %s, %s CPUs" % (platform.system(), platform.machine(), os.cpu_count()))
    print("facc    : %s" % a.facc)
    print("runs    : median of %d   (times in ms)\n" % a.runs)
    print("%-14s %8s %8s %8s %8s %12s" % ("benchmark", "C", "FAC", "FAC-fast", "FAC/C", "check cost"))
    bad = 0
    try:
        for n in names:
            expect = open(os.path.join(HERE, n + ".expect"), encoding="utf-8").read().strip()
            res = {}
            notes = []
            # reference
            for ext, comp in (("c", a.cc), ("cpp", a.cxx)):
                src = os.path.join(HERE, n + "." + ext)
                if os.path.exists(src):
                    exe = os.path.join(tmp, n + "_ref")
                    cp = run([comp, "-O2", src, "-o", exe] + (["-std=c++17"] if ext == "cpp" else []))
                    if cp.returncode != 0: notes.append("ref build failed")
                    else:
                        t, err = median_time(exe, a.runs, expect); res["c"] = t
                        if err: notes.append("ref " + err); bad += 1
            # FAC, normal and --unsafe-fast
            for key, flags in (("fac", []), ("fast", ["--unsafe-fast"])):
                exe = os.path.join(tmp, n + "_" + key)
                cp = run([a.facc, os.path.join(HERE, n + ".fac"), "-O2", "-o", exe] + flags, env=env)
                if cp.returncode != 0:
                    notes.append("facc[%s] failed: %s" % (key, (cp.stderr.strip().splitlines() or ["?"])[0][:100])); bad += 1; continue
                t, err = median_time(exe, a.runs, expect); res[key] = t
                if err: notes.append("%s %s" % (key, err)); bad += 1
            c, f, ff = res.get("c"), res.get("fac"), res.get("fast")
            ratio = "%7.2fx" % (f / c) if c and f else "       -"
            cost = "%10.0f%%" % ((f / ff - 1) * 100) if f and ff else "           -"
            print("%-14s %s %s %s %s %s" % (n, fmt(c), fmt(f), fmt(ff), ratio, cost))
            for note in notes: print("    !", note)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("\nOK" if not bad else "\n%d problem(s) above" % bad)
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
