#include <cstdio>
#include <unordered_map>
int main() {
    std::unordered_map<int, int> hm;
    for (int i = 0; i < 1000000; i++) hm[i] = i * 2;
    long sum = 0; for (int i = 0; i < 1000000; i++) sum += hm[i];
    int hits = 0; for (int i = 0; i < 2000000; i += 2) if (hm.count(i)) hits += 1;
    std::printf("%ld %d\n", sum, hits); return 0;
}
