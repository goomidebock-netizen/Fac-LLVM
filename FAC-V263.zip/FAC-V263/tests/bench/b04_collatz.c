#include <stdio.h>
int main(void) {
    int bestStart = 1, bestLen = 1;
    for (int start = 1; start < 3000000; start++) { long x = start; int len = 1;
        while (x != 1) { if (x % 2 == 0) x = x / 2; else x = 3 * x + 1; len += 1; }
        if (len > bestLen) { bestLen = len; bestStart = start; } }
    printf("%d %d\n", bestStart, bestLen); return 0;
}
