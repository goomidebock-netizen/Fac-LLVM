#!/bin/sh
# ใช้: tests/run_safe.sh  ทดสอบโหมด --safe (unsafe boundary):
#   tests/safe/ok/*.fac   ต้อง compile ผ่านด้วย --safe
#   tests/safe/bad/*.fac  ต้อง compile ไม่ผ่านด้วย --safe และข้อความ error ตรงกับ .expect
#   ทุกไฟล์ใน ok/ ต้อง compile ผ่านโดยไม่ใส่ --safe ด้วย (unsafe เป็น syntax ปกติเสมอ)
set -u
cd "$(dirname "$0")/.." || exit 1
FAC_COMPILER=${FAC_COMPILER:-./build/facc}
D=$(mktemp -d "${TMPDIR:-/tmp}/fac-safe.XXXXXXXX"); trap 'rm -rf "$D"' EXIT
pass=0; fail=0
for f in tests/safe/ok/*.fac; do
  for fl in "--safe" ""; do
    if out=$("$FAC_COMPILER" "$f" $fl --emit-ll -o "$D/o.ll" 2>&1); then pass=$((pass+1)); else echo "FAIL ok $(basename "$f") [$fl]: $out"; fail=$((fail+1)); fi
  done
done
for f in tests/safe/bad/*.fac; do
  b=${f%.fac}
  out=$("$FAC_COMPILER" "$f" --safe --emit-ll -o "$D/o.ll" 2>&1); rc=$?
  if [ $rc -ne 0 ] && echo "$out" | grep -Fq "$(cat "$b.expect")"; then pass=$((pass+1)); else echo "FAIL bad $(basename "$f"): rc=$rc $out"; fail=$((fail+1)); fi
  if "$FAC_COMPILER" "$f" --emit-ll -o "$D/o.ll" >/dev/null 2>&1; then pass=$((pass+1)); else echo "FAIL bad-without-safe $(basename "$f") should compile without --safe"; fail=$((fail+1)); fi
done
# --warn-unsafe: ไม่หยุด compile, IR เหมือนไม่ใส่ flag, ok/ ต้องไม่มี warning, bad/ ต้องมี warning ตรงกับ .expect
for f in tests/safe/ok/*.fac; do
  out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/w.ll" 2>&1); rc=$?
  "$FAC_COMPILER" "$f" --emit-ll -o "$D/n.ll" >/dev/null 2>&1
  if [ $rc -eq 0 ] && ! echo "$out" | grep -q "warning:" && cmp -s "$D/w.ll" "$D/n.ll"; then pass=$((pass+1)); else echo "FAIL warn ok $(basename "$f"): rc=$rc $out"; fail=$((fail+1)); fi
done
for f in tests/safe/bad/*.fac; do
  b=${f%.fac}
  out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/w.ll" 2>&1); rc=$?
  "$FAC_COMPILER" "$f" --emit-ll -o "$D/n.ll" >/dev/null 2>&1
  if [ $rc -eq 0 ] && echo "$out" | grep -F "warning:" | grep -Fq "$(cat "$b.expect")" && cmp -s "$D/w.ll" "$D/n.ll"; then pass=$((pass+1)); else echo "FAIL warn bad $(basename "$f"): rc=$rc $out"; fail=$((fail+1)); fi
done
# stdlib hygiene: ทุก module ใน stdlib/ ต้องผ่าน --safe โดยไม่ต้องอาศัยสถานะ "trusted" (ไม่มี ptr ดิบ/FFI นอก unsafe)
for m in stdlib/*.fac; do
  name=$(basename "$m" .fac)
  printf 'import terminal.fac\nimport %s.fac\npublic function void main() {\n    terminal.out.println(1)\n}\n' "$name" > "$D/m_$name.fac"
  if out=$("$FAC_COMPILER" "$D/m_$name.fac" --safe --no-trust-stdlib --emit-ll -o "$D/o.ll" 2>&1); then pass=$((pass+1)); else echo "FAIL stdlib $name is not clean under --safe: $out"; fail=$((fail+1)); fi
done
# --strict-safe: ปิดช่อง indirect call ที่ call target ตรวจสอบไม่ได้
for f in tests/safe/strict_bad/*.fac; do
  b=${f%.fac}
  out=$("$FAC_COMPILER" "$f" --strict-safe --emit-ll -o "$D/s.ll" 2>&1); rc=$?
  if [ $rc -ne 0 ] && echo "$out" | grep -Fq "$(cat "$b.expect")"; then pass=$((pass+1)); else echo "FAIL strict-safe bad $(basename "$f"): rc=$rc $out"; fail=$((fail+1)); fi
  if "$FAC_COMPILER" "$f" --safe --emit-ll -o "$D/o.ll" >/dev/null 2>&1; then pass=$((pass+1)); else echo "FAIL strict-safe compatibility $(basename "$f"): --safe behavior changed"; fail=$((fail+1)); fi
  if "$FAC_COMPILER" "$f" --emit-ll -o "$D/o.ll" >/dev/null 2>&1; then pass=$((pass+1)); else echo "FAIL strict-safe without safe $(basename "$f") should compile"; fail=$((fail+1)); fi
done
for f in tests/safe/ok/thread_isolated.fac tests/safe/ok/thread_cell.fac tests/safe/ok/thread_channel.fac; do
  if out=$("$FAC_COMPILER" "$f" --strict-safe --emit-ll -o "$D/s.ll" 2>&1); then pass=$((pass+1)); else echo "FAIL strict-safe expected-safe $(basename "$f"): $out"; fail=$((fail+1)); fi
done
# V38 audit: stdlib modules must also pass the stricter thread-call policy when untrusted.
for m in stdlib/*.fac; do
  name=$(basename "$m" .fac)
  printf 'import terminal.fac\nimport %s.fac\npublic function void main() {\n    terminal.out.println(1)\n}\n' "$name" > "$D/strict_$name.fac"
  if out=$("$FAC_COMPILER" "$D/strict_$name.fac" --strict-safe --no-trust-stdlib --emit-ll -o "$D/strict.ll" 2>&1); then pass=$((pass+1)); else echo "FAIL strict-safe stdlib $name: $out"; fail=$((fail+1)); fi
done
# V71 whole-program registry: cross-module globals must resolve to one storage identity.
f=tests/safe/worker_graph_cross_module.fac
expect=$(cat tests/safe/worker_graph_cross_module.expect)
out=$("$FAC_COMPILER" "$f" --safe --emit-ll -o "$D/cross-safe.ll" 2>&1); rc=$?
if [ $rc -ne 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V71 cross-module --safe: rc=$rc $out"; fail=$((fail+1)); fi
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/cross-warn.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -F "warning:" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V71 cross-module --warn-unsafe: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/cross-plain.ll" >/dev/null 2>&1; then pass=$((pass+1)); else echo "FAIL V71 cross-module without --safe should compile"; fail=$((fail+1)); fi
# V72 bounded worker lifecycle: classify per-activation/loop/parallel multiplicity
# and local thread.start handles by all-path join coverage. Unknown escapes remain unknown.
f=tests/safe/worker_lifecycle.fac
expect=$(cat tests/safe/worker_lifecycle.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/lifecycle.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$(sed -n '1p' tests/safe/worker_lifecycle.expect)" && echo "$out" | grep -Fq "$(sed -n '2p' tests/safe/worker_lifecycle.expect)"; then pass=$((pass+1)); else echo "FAIL V72 worker lifecycle summary: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/lifecycle-plain.ll" >/dev/null 2>&1; then pass=$((pass+1)); else echo "FAIL V72 worker lifecycle without --warn-unsafe should compile"; fail=$((fail+1)); fi
# V73: propagate thread-handle join summaries through unique direct helper calls,
# including a module-qualified multi-hop helper and a type-disambiguated overload.
f=tests/safe/worker_join_interprocedural.fac
expect=$(cat tests/safe/worker_join_interprocedural.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-interprocedural.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-summary-functions=7"; then pass=$((pass+1)); else echo "FAIL V73 interprocedural join summaries: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-interprocedural-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-interprocedural.ll" "$D/join-interprocedural-plain.ll"; then pass=$((pass+1)); else echo "FAIL V73 interprocedural join fixture plain compile/IR equivalence"; fail=$((fail+1)); fi
# V74: track direct and nested ptr-thread fields in local value structs;
# helper calls may consume a tracked field, while copies/aliases remain unknown.
f=tests/safe/worker_join_struct_fields.fac
expect=$(cat tests/safe/worker_join_struct_fields.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-fields.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V74 struct thread-handle fields: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-fields-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-fields.ll" "$D/join-struct-fields-plain.ll"; then pass=$((pass+1)); else echo "FAIL V74 struct field plain compile/IR equivalence"; fail=$((fail+1)); fi
f=tests/safe/worker_join_struct_alias.fac
expect=$(cat tests/safe/worker_join_struct_alias.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-alias.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V74 struct field alias remains unknown: rc=$rc $out"; fail=$((fail+1)); fi

f=tests/safe/worker_join_struct_escape.fac
expect=$(cat tests/safe/worker_join_struct_escape.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-escape.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V74 struct aggregate escape remains unknown: rc=$rc $out"; fail=$((fail+1)); fi
# V75: explicit move of a managed value struct transfers nested thread-handle
# lifecycle state to the destination; source paths are no longer treated as aliases.
f=tests/safe/worker_join_struct_move.fac
expect=$(cat tests/safe/worker_join_struct_move.expect)
out=$("$FAC_COMPILER" "$f" --strict-move --warn-unsafe --emit-ll -o "$D/join-struct-move.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V75 explicit struct move transfer: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --strict-move --emit-ll -o "$D/join-struct-move-plain.ll" >/dev/null 2>&1; then pass=$((pass+1)); else echo "FAIL V75 struct move plain compile"; fail=$((fail+1)); fi
# V76: bounded interprocedural struct-parameter summaries map nested fields,
# conditional joins, explicit whole-aggregate move arguments and repeated joins.
f=tests/safe/worker_join_struct_helpers.fac
expect=$(cat tests/safe/worker_join_struct_helpers.expect)
out=$("$FAC_COMPILER" "$f" --strict-move --warn-unsafe --emit-ll -o "$D/join-struct-helpers.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=5"; then pass=$((pass+1)); else echo "FAIL V76 struct parameter summaries: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --strict-move --emit-ll -o "$D/join-struct-helpers-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-helpers.ll" "$D/join-struct-helpers-plain.ll"; then pass=$((pass+1)); else echo "FAIL V76 struct helper plain compile/IR equivalence"; fail=$((fail+1)); fi
# V262: a struct helper must not gain the join-only exception when its body
# merely observes/forwards a raw thread handle instead of consuming it.
f=tests/safe/worker_join_struct_unconsumed_helper_rejected.fac
out=$("$FAC_COMPILER" "$f" --strict-ownership --emit-ll -o "$D/join-struct-unconsumed.ll" 2>&1); rc=$?
if [ $rc -ne 0 ] && echo "$out" | grep -Fq "cannot read pointer field 'value'"; then pass=$((pass+1)); else echo "FAIL V262 unconsumed struct helper remains rejected: rc=$rc $out"; fail=$((fail+1)); fi
# Module-qualified imported struct helpers use the same uniquely-resolved field summary.
f=tests/safe/worker_join_struct_import.fac
expect=$(cat tests/safe/worker_join_struct_import.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-import.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=1"; then pass=$((pass+1)); else echo "FAIL V76 imported struct helper summary: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-import-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-import.ll" "$D/join-struct-import-plain.ll"; then pass=$((pass+1)); else echo "FAIL V76 imported struct helper plain compile/IR equivalence"; fail=$((fail+1)); fi
# Returning a tracked aggregate is not treated as a proven transfer; it remains unknown.
f=tests/safe/worker_join_struct_return_escape.fac
expect=$(cat tests/safe/worker_join_struct_return_escape.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-return-escape.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V76 struct return escape remains unknown: rc=$rc $out"; fail=$((fail+1)); fi
# V77: struct summaries converge through reverse-declared, multi-hop wrappers,
# including nested fields and imported modules; recursive forwarding stays Unknown.
f=tests/safe/worker_join_struct_forward.fac
expect=$(cat tests/safe/worker_join_struct_forward.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-forward.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=8"; then pass=$((pass+1)); else echo "FAIL V77 transitive struct summary fixed point: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-forward-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-forward.ll" "$D/join-struct-forward-plain.ll"; then pass=$((pass+1)); else echo "FAIL V77 struct forward plain compile/IR equivalence"; fail=$((fail+1)); fi
f=tests/safe/worker_join_struct_forward_recursive.fac
expect=$(cat tests/safe/worker_join_struct_forward_recursive.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-forward-recursive.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V77 recursive struct helper remains unknown: rc=$rc $out"; fail=$((fail+1)); fi
f=tests/safe/worker_join_struct_forward_nested.fac
expect=$(cat tests/safe/worker_join_struct_forward_nested.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-forward-nested.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=8"; then pass=$((pass+1)); else echo "FAIL V77 nested aggregate argument forwarding: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-forward-nested-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-forward-nested.ll" "$D/join-struct-forward-nested-plain.ll"; then pass=$((pass+1)); else echo "FAIL V77 nested forwarding plain compile/IR equivalence"; fail=$((fail+1)); fi
f=tests/safe/worker_join_struct_forward_ambiguous.fac
expect=$(cat tests/safe/worker_join_struct_forward_ambiguous.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-forward-ambiguous.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=8"; then pass=$((pass+1)); else echo "FAIL V77 ambiguous struct overload remains unknown: rc=$rc $out"; fail=$((fail+1)); fi
# V78: dependency worklist propagation is not truncated at V77's 32 rounds.
# Forty reverse-declared helpers must carry the leaf join effect to the entry caller.
f=tests/safe/worker_join_struct_long.fac
expect=$(cat tests/safe/worker_join_struct_long.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-long.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=40"; then pass=$((pass+1)); else echo "FAIL V78 long struct-helper dependency chain: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-long-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-long.ll" "$D/join-struct-long-plain.ll"; then pass=$((pass+1)); else echo "FAIL V78 long struct-helper plain compile/IR equivalence"; fail=$((fail+1)); fi

# V79: struct-helper overload resolution also checks exact literal argument types
# using the compiler's ordinary overload score; unresolved expression ties remain Unknown.
f=tests/safe/worker_join_struct_overload_types.fac
expect=$(cat tests/safe/worker_join_struct_overload_types.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-types.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=2"; then pass=$((pass+1)); else echo "FAIL V79 typed struct-helper overload summaries: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-types-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-types.ll" "$D/join-struct-overload-types-plain.ll"; then pass=$((pass+1)); else echo "FAIL V79 overload fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V80: overload selection can use a scalar identifier only when every
# declaration visible in the owning function has the same explicit primitive type.
f=tests/safe/worker_join_struct_overload_vars.fac
expect=$(cat tests/safe/worker_join_struct_overload_vars.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-vars.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=2"; then pass=$((pass+1)); else echo "FAIL V80 declared-variable overload summaries: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-vars-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-vars.ll" "$D/join-struct-overload-vars-plain.ll"; then pass=$((pass+1)); else echo "FAIL V80 overload variable fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V81 resolves the variable at the call's lexical location: distinct declarations
# in sibling branches no longer poison each other, while each branch remains scoped.
f=tests/safe/worker_join_struct_overload_branch_scopes.fac
expect=$(cat tests/safe/worker_join_struct_overload_branch_scopes.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-branches.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V81 branch-local overload resolution: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-branches-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-branches.ll" "$D/join-struct-overload-branches-plain.ll"; then pass=$((pass+1)); else echo "FAIL V81 branch-local plain compile/IR equivalence"; fail=$((fail+1)); fi

# A nested boolean shadow must not hide the outer int after its block exits.
f=tests/safe/worker_join_struct_overload_scope.fac
expect=$(cat tests/safe/worker_join_struct_overload_scope.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-scope.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=2"; then pass=$((pass+1)); else echo "FAIL V81 lexical shadow restoration: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-scope-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-scope.ll" "$D/join-struct-overload-scope-plain.ll"; then pass=$((pass+1)); else echo "FAIL V81 lexical-scope fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V82: a simple auto local is type-known only when initialized by a direct
# scalar literal. Calls/operators remain unknown even if their result type is clear.
f=tests/safe/worker_join_struct_overload_auto.fac
expect=$(cat tests/safe/worker_join_struct_overload_auto.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-auto.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V82 literal-initialized auto overload facts remain bounded: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-auto-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-auto.ll" "$D/join-struct-overload-auto-plain.ll"; then pass=$((pass+1)); else echo "FAIL V82 auto overload fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V83: auto value copies inherit only an already-proven visible scalar type.
f=tests/safe/worker_join_struct_overload_auto_copy.fac
expect=$(cat tests/safe/worker_join_struct_overload_auto_copy.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-auto-copy.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V83 auto scalar-copy overload facts remain bounded: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-auto-copy-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-auto-copy.ll" "$D/join-struct-overload-auto-copy-plain.ll"; then pass=$((pass+1)); else echo "FAIL V83 auto scalar-copy fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V87: direct fixed-result str(...) calls are resolved;
# arbitrary user-defined function calls remain unknown.
f=tests/safe/worker_join_struct_overload_unary_literal.fac
expect=$(cat tests/safe/worker_join_struct_overload_unary_literal.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-unary-literal.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V87 exact string-value overload facts remain bounded: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-unary-literal-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-unary-literal.ll" "$D/join-struct-overload-unary-literal-plain.ll"; then pass=$((pass+1)); else echo "FAIL V87 exact string-value fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V88: fixed-result parse/size/sizeof/strcmp built-ins provide exact scalar facts;
# arbitrary user-defined function results remain unknown.
f=tests/safe/worker_join_struct_overload_builtin_results.fac
expect=$(cat tests/safe/worker_join_struct_overload_builtin_results.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-builtin-results.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect"; then pass=$((pass+1)); else echo "FAIL V88 fixed-result builtin overload facts remain bounded: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-builtin-results-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-builtin-results.ll" "$D/join-struct-overload-builtin-results-plain.ll"; then pass=$((pass+1)); else echo "FAIL V88 fixed-result builtin fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# V92: fixed-result API-table entries, random.int result facts, and numeric
# math.abs/min/max promote/commonT result facts remain bounded and conservative.
f=tests/safe/worker_join_struct_overload_table_builtin_results.fac
expect=$(cat tests/safe/worker_join_struct_overload_table_builtin_results.expect)
out=$("$FAC_COMPILER" "$f" --warn-unsafe --emit-ll -o "$D/join-struct-overload-table-builtins.ll" 2>&1); rc=$?
if [ $rc -eq 0 ] && echo "$out" | grep -Fq "$expect" && echo "$out" | grep -Fq "join-struct-summary-functions=5"; then pass=$((pass+1)); else echo "FAIL V92 API-table/random.int/math numeric result facts remain bounded: rc=$rc $out"; fail=$((fail+1)); fi
if "$FAC_COMPILER" "$f" --emit-ll -o "$D/join-struct-overload-table-builtins-plain.ll" >/dev/null 2>&1 && cmp -s "$D/join-struct-overload-table-builtins.ll" "$D/join-struct-overload-table-builtins-plain.ll"; then pass=$((pass+1)); else echo "FAIL V92 numeric built-in fixture plain compile/IR equivalence"; fail=$((fail+1)); fi

# --safe ห้ามใช้ร่วมกับ flag ที่ปิดการตรวจ (bounds/div)
for fl in --no-bounds-check --no-div-check --unsafe-fast; do
  out=$("$FAC_COMPILER" tests/safe/ok/unsafe_block.fac --safe $fl --emit-ll -o "$D/o.ll" 2>&1); rc=$?
  if [ $rc -eq 2 ] && echo "$out" | grep -Fq "ใช้ร่วมกับ"; then pass=$((pass+1)); else echo "FAIL --safe $fl should be rejected (rc=$rc)"; fail=$((fail+1)); fi
done
echo "safe pass=$pass fail=$fail"
[ "$fail" -eq 0 ]
