#!/bin/sh
# ตรวจว่า asset ใน examples/assets สร้างซ้ำได้ byte-for-byte จาก tests/assets/game_assets.py (กัน asset กับ oracle ของเทสต์ไม่ตรงกัน)
cd "$(dirname "$0")/.." || exit 1
T=$(mktemp -d); python3 tests/assets/game_assets.py "$T" >/dev/null || exit 1
for f in tiles.png hero.png; do cmp "$T/$f" "examples/assets/$f" || { echo "asset $f ไม่ตรงกับสคริปต์สร้าง"; exit 1; }; done
echo "assets reproducible"
