#!/usr/bin/env python3
"""Unit/integration tests for the FAC tooling (V44).  Run: python3 tests/tools/test_tools.py

Tests that need the compiler front-end use build/facc or $FAC_COMPILER and are skipped when neither
exists (the compiler itself is covered by tests/run.sh).  No test needs clang.
"""
import copy
import glob
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]
TOOLS = ROOT / "tools"
sys.path.insert(0, str(TOOLS))
import api_audit  # noqa: E402
import api_compat  # noqa: E402
import api_contract  # noqa: E402
import api_manifest  # noqa: E402
import bump_version  # noqa: E402
import fac_diagnostics  # noqa: E402
import fac_lsp  # noqa: E402
import facdoc  # noqa: E402
import facfmt  # noqa: E402
import facpkg  # noqa: E402
import facsrc  # noqa: E402
import facserde  # noqa: E402

FACC = fac_diagnostics.find_compiler()
needs_compiler = unittest.skipUnless(FACC, "build/facc (or $FAC_COMPILER) not available")
ENV = dict(os.environ, FAC_HOME=str(ROOT))
SOURCES = sorted(glob.glob(str(ROOT / "stdlib" / "*.fac")) + glob.glob(str(ROOT / "examples" / "*.fac")) +
                 glob.glob(str(ROOT / "examples" / "api" / "*.fac")) + glob.glob(str(ROOT / "tests" / "cases" / "*.fac")) +
                 glob.glob(str(ROOT / "tests" / "api" / "*.fac")))


def run(*args, cwd=None, input=None):
    return subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True, cwd=cwd, env=ENV, input=input)


class VersionBumpTests(unittest.TestCase):
    def make_release_tree(self, root: pathlib.Path) -> None:
        (root / "include/fac").mkdir(parents=True)
        (root / "docs").mkdir()
        (root / "api").mkdir()
        (root / "VERSION.toml").write_text(
            '[release]\nlabel = "V7"\ncompiler = "0.2.0"\n\n[components]\n'
            'core = "V7"\nlib = "V7"\napi = "V7"\nlang = "V7"\nruntime = "V7"\nstdlib = "V7"\n',
            encoding="utf-8")
        macros = ["FAC_RELEASE_VERSION", "FAC_CORE_VERSION", "FAC_LIB_VERSION",
                  "FAC_API_VERSION", "FAC_LANG_VERSION", "FAC_RUNTIME_VERSION", "FAC_STDLIB_VERSION"]
        (root / "include/fac/version.h").write_text(
            "\n".join(f'#define {name} "V7"' for name in macros) + "\n", encoding="utf-8")
        (root / "README.md").write_text(
            "# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V7\n", encoding="utf-8")
        (root / "docs/STATUS.md").write_text("# FAC V7\n", encoding="utf-8")
        (root / "docs/MEMORY_MODEL.md").write_text(
            "# FAC Memory, Ownership, Borrowing and Lifetime Model — current V7\n", encoding="utf-8")
        (root / "docs/MEMORY_SAFE_PROFILE.md").write_text(
            "# FAC `--memory-safe` profile — V7\n", encoding="utf-8")
        (root / "docs/OWNERSHIP.md").write_text(
            "# FAC ownership and borrowing model\n\n## Current V7 safe-profile policy\n", encoding="utf-8")
        (root / "api/standards.json").write_text('{"release":"V7","gpu":[{"status":"paused-not-included-in-V7"}]}\n', encoding="utf-8")

    def test_increments_every_release_surface_and_can_repeat(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            self.make_release_tree(root)
            self.assertEqual(bump_version.bump(root, refresh_api=False), ("V7", "V8"))
            self.assertIn('label = "V8"', (root / "VERSION.toml").read_text(encoding="utf-8"))
            self.assertTrue((root / "include/fac/version.h").read_text(encoding="utf-8").count('"V8"') == 7)
            self.assertIn("Release V8", (root / "README.md").read_text(encoding="utf-8"))
            self.assertTrue((root / "docs/STATUS.md").read_text(encoding="utf-8").startswith("# FAC V8"))
            self.assertIn("current V8", (root / "docs/MEMORY_MODEL.md").read_text(encoding="utf-8"))
            self.assertIn("profile — V8", (root / "docs/MEMORY_SAFE_PROFILE.md").read_text(encoding="utf-8"))
            self.assertIn("Current V8", (root / "docs/OWNERSHIP.md").read_text(encoding="utf-8"))
            standards = json.loads((root / "api/standards.json").read_text(encoding="utf-8"))
            self.assertEqual(standards["release"], "V8")
            self.assertEqual(standards["gpu"][0]["status"], "paused-not-included-in-V8")
            self.assertEqual(bump_version.bump(root, refresh_api=False), ("V8", "V9"))

    def test_refuses_manifest_component_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            self.make_release_tree(root)
            manifest = (root / "VERSION.toml").read_text(encoding="utf-8").replace('api = "V7"', 'api = "V6"')
            (root / "VERSION.toml").write_text(manifest, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "components.api"):
                bump_version.bump(root, refresh_api=False)


class LexerTests(unittest.TestCase):
    def kinds(self, s):
        return [(t.kind, t.text) for t in facsrc.lex(s).tokens]

    def test_comments(self):
        t = self.kinds("a # x\n## doc\n#* b\nc *# d")
        self.assertEqual([k for k, _ in t], ["ident", "comment", "comment", "comment", "ident"])

    def test_slash_slash_is_not_a_comment(self):
        t = self.kinds("a // b")
        self.assertEqual([x for _, x in t], ["a", "/", "/", "b"])

    def test_braces_in_strings_and_chars(self):
        r = facsrc.diagnose('var string s = "{ ( [ \\" #"\nvar char c = \'{\'\n')
        self.assertEqual(r, [])

    def test_loop_tokens(self):
        t = self.kinds("for++(3) { for++.i for++.for++.i for--.for++.i for++.for--.i --for.++for.i }")
        self.assertEqual(t[0], ("loop", "for++"))
        self.assertIn(("loop", "for++.i"), t)
        self.assertIn(("loop", "for++.for++.i"), t)
        self.assertIn(("loop", "for--.for++.i"), t)
        self.assertIn(("loop", "for++.for--.i"), t)
        self.assertIn(("loop", "--for.++for.i"), t)

    def test_errors(self):
        self.assertTrue(facsrc.diagnose('x = "abc\n'))
        self.assertTrue(facsrc.diagnose("#* never closed"))
        self.assertTrue(facsrc.diagnose("x = $"))
        self.assertTrue(facsrc.diagnose("f(a"))
        self.assertTrue(facsrc.diagnose("a }"))

    def test_whole_corpus_is_clean(self):
        self.assertGreater(len(SOURCES), 150)
        for f in SOURCES:
            with self.subTest(f=f):
                self.assertEqual(facsrc.diagnose(pathlib.Path(f).read_text(encoding="utf-8")), [])

    def test_scan_declarations(self):
        src = "## doc\npublic function int f(int a) { throw Error(\"x\", 1) }\nclass A {\n    public function void g() { }\n}\n"
        d = {x.name: x for x in facsrc.scan_declarations(src)}
        self.assertTrue(d["f"].public and d["f"].body_has_throw and d["f"].doc == ["doc"])
        self.assertEqual(d["g"].parent, "A")


class FormatterTests(unittest.TestCase):
    def test_reindent_and_blank_lines(self):
        out = facfmt.format_text("function void f() {\n\tif (1) {\n  x()   \n}\n\n\n\n}\n")
        self.assertEqual(out, "function void f() {\n    if (1) {\n        x()\n    }\n\n}\n".replace("\n\n}", "\n\n}"))

    def test_continuation_lines(self):
        out = facfmt.format_text("x = f(a,\n  b,\n          c)\ny = 1\n")
        self.assertEqual(out, "x = f(a,\n    b,\n    c)\ny = 1\n")

    def test_lambda_body_not_double_indented(self):
        out = facfmt.format_text("run(function void() {\nwork()\n})\n")
        self.assertEqual(out, "run(function void() {\n    work()\n})\n")

    def test_block_comment_interior_untouched(self):
        src = "#*\n   keep   \n\t{ not code\n*#\nx()\n"
        self.assertEqual(facfmt.format_text(src), src)

    def test_braces_in_strings_do_not_indent(self):
        src = 'f("{")\ng()\n'
        self.assertEqual(facfmt.format_text(src), src)

    def test_crlf_and_bom_preserved(self):
        out = facfmt.format_text("\ufeffa()\r\n  b()\r\n")
        self.assertEqual(out, "\ufeffa()\r\n  b()\r\n".replace("  b", "b"))
        self.assertTrue(out.startswith("\ufeff") and "\r\n" in out and "\n" not in out.replace("\r\n", ""))

    def test_refuses_lexical_errors(self):
        with self.assertRaises(facfmt.FormatError):
            facfmt.format_text('x = "oops\n')

    def test_corpus_idempotent_and_token_safe(self):
        for f in SOURCES:
            with self.subTest(f=f):
                s = pathlib.Path(f).read_bytes().decode("utf-8")
                a = facfmt.format_text(s)
                self.assertEqual(facfmt.format_text(a), a)
                ta = [(t.kind, t.text.rstrip()) for t in facsrc.lex(s).tokens]
                tb = [(t.kind, t.text.rstrip()) for t in facsrc.lex(a).tokens]
                self.assertEqual(ta, tb)

    def test_cli_check(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "a.fac"
            p.write_text("f() {\nx()\n}\n", encoding="utf-8")
            self.assertEqual(run(TOOLS / "facfmt.py", "--check", p).returncode, 1)
            self.assertEqual(run(TOOLS / "facfmt.py", p).returncode, 0)
            self.assertEqual(run(TOOLS / "facfmt.py", "--check", p).returncode, 0)


class ManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = api_manifest.build()
        cls.b = {e["name"]: e for e in cls.m["builtin"]}

    def test_committed_manifest_is_fresh(self):
        self.assertEqual(run(TOOLS / "api_manifest.py", "--check").returncode, 0)

    def test_counts(self):
        self.assertGreater(self.m["counts"]["builtin"], 350)
        self.assertGreater(self.m["counts"]["source"], 200)

    def test_error_models(self):
        self.assertEqual(self.b["file.readText"]["errors"]["model"], "throws")
        self.assertIn(7, self.b["file.readText"]["errors"]["codes"])
        self.assertEqual(self.b["file.mkdir"]["errors"]["model"], "status-flag")
        self.assertEqual(self.b["path.exists"]["errors"]["model"], "predicate")
        self.assertEqual(self.b["math.sqrt"]["errors"]["model"], "ieee754")
        self.assertEqual(self.b["net.httpGet"]["errors"]["codes"], [11])

    def test_thread_task_lifecycle_api(self):
        self.assertEqual(self.b["thread.cancel"]["errors"]["model"], "predicate")
        self.assertEqual(self.b["thread.cancelled"]["errors"]["model"], "predicate")
        self.assertEqual(self.b["thread.isDone"]["errors"]["model"], "predicate")
        self.assertEqual(self.b["thread.isCancelled"]["errors"]["model"], "predicate")
        self.assertEqual(self.b["thread.cancel"]["ownership"]["params"][0], "borrowed-handle")
        self.assertEqual(self.b["thread.isDone"]["ownership"]["params"][0], "borrowed-handle")

    def test_ownership(self):
        self.assertEqual(self.b["json.get"]["ownership"]["result"], "borrowed-view")
        self.assertEqual(self.b["json.parse"]["ownership"]["release"], "json.free")
        self.assertEqual(self.b["json.set"]["ownership"]["params"][2], "consumed")
        self.assertEqual(self.b["thread.join"]["ownership"]["params"][0], "consumed")
        self.assertEqual(self.b["file.readText"]["ownership"]["result"], "owned")

    def test_aliases(self):
        self.assertEqual(self.b["terminal.out.anwser"]["alias_of"], "terminal.out.answer")
        self.assertEqual(self.b["file.readline"]["status"], "deprecated")
        self.assertIn("file.readLine", self.b)
        self.assertIn("terminal.in.readLine", self.b)

    def test_handle_results_have_release(self):
        for n, e in self.b.items():
            o = e.get("ownership")
            if o and o["result"] == "owned-handle":
                self.assertIn("release", o, n)


class AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = api_manifest.build()
        cls.meta = json.loads((ROOT / "api" / "meta.json").read_text(encoding="utf-8"))

    def test_repository_is_clean_against_baseline(self):
        self.assertEqual(run(TOOLS / "api_audit.py").returncode, 0)

    def synthetic(self, names):
        """names: list of (name, params, returns, symbol)"""
        m = copy.deepcopy(self.manifest)
        for n, params, ret, sym in names:
            m["builtin"].append({"name": n, "module": n.split(".")[0], "kind": "builtin", "status": "stable",
                                 "overloads": [{"params": params, "returns": ret, "symbol": sym}],
                                 "errors": {"model": "none-direct"}, "thread_safety": "unspecified"})
        return m

    def rules(self, m):
        return {f["rule"] for f in api_audit.audit(m, self.meta)}

    def test_detects_case_only_variant(self):
        self.assertIn("N002", self.rules(self.synthetic([("file.zzz", [], "void", "s1"), ("file.zZz", [], "void", "s2")])))

    def test_detects_transposition_and_misspelling(self):
        r = self.rules(self.synthetic([("string.reverse2", [], "void", "x1"), ("string.reevrse2", [], "void", "x2"),
                                       ("string.lenght", ["string"], "int", "x3")]))
        self.assertIn("N003", r)

    def test_detects_unrecorded_duplicate_symbol(self):
        self.assertIn("D001", self.rules(self.synthetic([("math.foo1", [], "void", "fac_same"), ("math.foo2", [], "void", "fac_same")])))

    def test_detects_bad_return_types(self):
        r = self.rules(self.synthetic([("math.isThing", ["int"], "int", "q1"), ("math.free", ["handle"], "int", "q2"),
                                       ("math.count", ["string"], "string", "q3")]))
        self.assertTrue({"R001", "R002", "R003"} <= r)

    def test_detects_naming(self):
        self.assertIn("N001", self.rules(self.synthetic([("math.Do_it", [], "void", "n1")])))

    def test_alias_missing_from_tables(self):
        meta = copy.deepcopy(self.meta)
        meta["aliases"].append({"name": "string.nothere", "canonical": "string.find", "kind": "duplicate", "status": "alias", "reason": "t"})
        self.assertIn("D002", {f["rule"] for f in api_audit.audit(self.manifest, meta)})


class ContractTests(unittest.TestCase):
    def test_all_public_source_functions_have_tags(self):
        self.assertEqual(run(TOOLS / "api_contract.py", "audit", "--strict").returncode, 0)

    def test_generated_blocks_are_current(self):
        self.assertEqual(run(TOOLS / "api_contract.py", "check").returncode, 0)

    def test_comment_only_change(self):
        # the contract blocks must not alter any token of a stdlib file: compare with a version stripped of ## lines
        for f in glob.glob(str(ROOT / "stdlib" / "*.fac")):
            src = pathlib.Path(f).read_text(encoding="utf-8")
            stripped = "\n".join(l for l in src.split("\n") if not l.lstrip().startswith("## @"))
            a = [t.text for t in facsrc.lex(src).tokens if t.kind != "comment"]
            b = [t.text for t in facsrc.lex(stripped).tokens if t.kind != "comment"]
            self.assertEqual(a, b, f)

    def test_generator_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "m.fac"
            p.write_text("module m\nvar int counter = 0\nclass C {\n    var int v\n"
                         "    public function void set(int x) { this.v = x }\n"
                         "    public function int get() { return this.v }\n}\n"
                         "public function int pure(int a) { return a + 1 }\n"
                         "public function int bump() { counter += 1\n return counter }\n"
                         "public function void boom() { throw Error(\"x\", 9) }\n", encoding="utf-8")
            api_contract.process(p, api_contract.throwing_builtins(), api_contract.safe_builtins(), api_contract.builtin_modules(), True)
            out = p.read_text(encoding="utf-8")
            self.assertIn("Not thread-safe: mutates the C receiver", out)
            self.assertIn("Read-only on the C receiver", out)
            self.assertIn("Safe: depends only on its arguments.", out)
            self.assertIn("uses module-level state (counter)", out)
            self.assertIn("explicit throw Error (code 9)", out)
            before = out
            api_contract.process(p, api_contract.throwing_builtins(), api_contract.safe_builtins(), api_contract.builtin_modules(), True)
            self.assertEqual(p.read_text(encoding="utf-8"), before)           # idempotent

    def test_hand_written_blocks_are_never_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "h.fac"
            text = "## @returns mine\n## @ownership mine\n## @errors mine\n## @thread-safety mine\npublic function int f() { return 1 }\n"
            p.write_text(text, encoding="utf-8")
            api_contract.process(p, {}, set(), set(), True)
            self.assertEqual(p.read_text(encoding="utf-8"), text)


class CompatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = api_manifest.build()
        cls.base = api_compat.snapshot(cls.manifest)

    def test_current_tree_is_compatible_with_last_release(self):
        self.assertEqual(run(TOOLS / "api_compat.py", "check").returncode, 0)

    def mutate(self, f):
        cur = copy.deepcopy(self.base)
        f(cur)
        return {(l, n) for l, n, _ in api_compat.compare(self.base, cur, "V44")}

    def test_removed_name_is_breaking(self):
        r = self.mutate(lambda c: c["builtin"].pop("string.trim"))
        self.assertIn(("BREAKING", "string.trim"), r)

    def test_changed_signature_is_breaking(self):
        def f(c):
            c["builtin"]["string.trim"]["sig"] = ["x"]
        self.assertIn(("BREAKING", "string.trim"), self.mutate(f))

    def test_changed_ownership_is_breaking(self):
        def f(c):
            c["builtin"]["json.get"]["ownership"] = {"result": "owned"}
        self.assertIn(("BREAKING", "json.get"), self.mutate(f))

    def test_new_name_is_added_and_error_change_is_warning(self):
        def f(c):
            c["builtin"]["string.newThing"] = copy.deepcopy(c["builtin"]["string.trim"])
            c["builtin"]["file.size"]["errors"] = {"model": "status-flag", "codes": []}
        r = self.mutate(f)
        self.assertIn(("ADDED", "string.newThing"), r)
        self.assertIn(("WARNING", "file.size"), r)

    def test_deprecation_window_rules(self):
        base = copy.deepcopy(self.base)
        base["builtin"]["old.name"] = {"kind": "builtin", "sig": [], "ownership": None, "errors": {"model": "x", "codes": []},
                                       "status": "deprecated", "remove_not_before": "V47", "alias_of": "new.name"}
        cur = copy.deepcopy(self.base)
        early = api_compat.compare(base, cur, "V45")
        self.assertIn(("BREAKING", "old.name"), {(l, n) for l, n, _ in early})
        late = api_compat.compare(base, cur, "V47")
        self.assertNotIn(("BREAKING", "old.name"), {(l, n) for l, n, _ in late})

    def test_versions(self):
        self.assertEqual(api_compat.release_no("V44"), 44)


class DocTests(unittest.TestCase):
    def test_generated_docs_are_fresh(self):
        self.assertEqual(run(TOOLS / "facdoc.py", "--check").returncode, 0)

    def test_audit_report_fresh(self):
        with tempfile.TemporaryDirectory() as td:
            out = pathlib.Path(td) / "a.md"
            self.assertEqual(run(TOOLS / "api_audit.py", "--markdown", "--output", out).returncode, 0)
            self.assertEqual(out.read_text(encoding="utf-8"), (ROOT / "docs" / "API_AUDIT.md").read_text(encoding="utf-8"))

    def test_conventions_do_not_teach_invalid_comments(self):
        for f in ("docs/API_CONVENTIONS.md",):
            text = (ROOT / f).read_text(encoding="utf-8")
            code = text.split("```fac")[1:]
            for block in code:
                self.assertNotIn("///", block.split("```")[0], f)

    def test_project_markdown(self):
        with tempfile.TemporaryDirectory() as td:
            root = pathlib.Path(td)
            (root / "src").mkdir()
            (root / "src" / "m.fac").write_text("# adds\n## @returns sum\npublic function int add(int a, int b) { return a + b }\n", encoding="utf-8")
            md = facdoc.project_markdown(root)
            self.assertIn("### `add`", md)
            self.assertIn("adds", md)
            self.assertIn("**returns:** sum", md)


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.td.name) / "app"
        self.root.mkdir()
        self.cwd = os.getcwd()
        os.chdir(self.root)

    def tearDown(self):
        os.chdir(self.cwd)
        self.td.cleanup()

    def mk(self, path, name, version="0.1.0", deps="", files=None, kind="lib"):
        d = self.root / path
        (d / "src").mkdir(parents=True, exist_ok=True)
        (d / "fac.toml").write_text(f'[package]\nname = "{name}"\nversion = "{version}"\nkind = "{kind}"\n\n[dependencies]\n{deps}\n', encoding="utf-8")
        for fn, text in (files or {name + ".fac": f"module {name}\npublic function int v() {{ return 1 }}\n"}).items():
            (d / "src" / fn).write_text(text, encoding="utf-8")
        return d

    def test_semver(self):
        for ver, req, ok in [("1.2.3", "^1.2", True), ("2.0.0", "^1.2", False), ("0.2.5", "^0.2.1", True), ("0.3.0", "^0.2.1", False),
                             ("1.2.9", "~1.2.3", True), ("1.3.0", "~1.2.3", False), ("0.2.0", ">=0.2.0,<0.3.0", True),
                             ("0.3.0", ">=0.2.0,<0.3.0", False), ("1.0.0", "=1.0.0", True), ("1.0.1", "=1.0.0", False)]:
            self.assertEqual(facpkg.satisfies(ver, req), ok, (ver, req))

    def test_resolve_and_stage(self):
        self.mk(".", "app", kind="bin", deps='util = { path = "vendor/util", version = "^0.1" }', files={"main.fac": "public function void main() { }\n"})
        self.mk("vendor/util", "util")
        res = facpkg.resolve(self.root)
        self.assertEqual([p.name for p in res.order], ["util", "app"])
        entry = facpkg.stage(res, self.root / "build" / "stage", ROOT / "stdlib")
        self.assertTrue((entry.parent / "util.fac").exists() and entry.name == "main.fac")

    def test_cycle(self):
        self.mk(".", "app", kind="bin", deps='a = "vendor/a"', files={"main.fac": "\n"})
        self.mk("vendor/a", "a", deps='b = "../b"')
        self.mk("vendor/b", "b", deps='a = "../a"')
        with self.assertRaisesRegex(facpkg.PkgError, "cycle"):
            facpkg.resolve(self.root)

    def test_version_mismatch(self):
        self.mk(".", "app", kind="bin", deps='u = { path = "vendor/u", version = "^2.0" }', files={"main.fac": "\n"})
        self.mk("vendor/u", "u", version="1.0.0")
        with self.assertRaisesRegex(facpkg.PkgError, "does not satisfy"):
            facpkg.resolve(self.root)

    def test_escape_and_name_mismatch(self):
        self.mk(".", "app", kind="bin", deps='u = "../outside"', files={"main.fac": "\n"})
        with self.assertRaisesRegex(facpkg.PkgError, "escapes"):
            facpkg.resolve(self.root)
        self.mk(".", "app", kind="bin", deps='u = "vendor/other"', files={"main.fac": "\n"})
        self.mk("vendor/other", "other")
        with self.assertRaisesRegex(facpkg.PkgError, "does not match"):
            facpkg.resolve(self.root)

    def test_module_collision_and_stdlib_shadow(self):
        self.mk(".", "app", kind="bin", deps='u = "vendor/u"', files={"main.fac": "\n", "dup.fac": "\n"})
        self.mk("vendor/u", "u", files={"u.fac": "\n", "dup.fac": "\n"})
        res = facpkg.resolve(self.root)
        with self.assertRaisesRegex(facpkg.PkgError, "provided by both"):
            facpkg.stage(res, self.root / "b1", ROOT / "stdlib")
        self.mk(".", "app", kind="bin", files={"main.fac": "\n", "math.fac": "\n"})
        res = facpkg.resolve(self.root)
        with self.assertRaisesRegex(facpkg.PkgError, "shadows"):
            facpkg.stage(res, self.root / "b2", ROOT / "stdlib")

    def test_lock_detects_change(self):
        self.mk(".", "app", kind="bin", deps='u = "vendor/u"', files={"main.fac": "\n"})
        d = self.mk("vendor/u", "u")
        res = facpkg.resolve(self.root)
        facpkg.write_lock(res)
        self.assertEqual(facpkg.check_lock(facpkg.resolve(self.root)), [])
        (d / "src" / "u.fac").write_text("module u\npublic function int v() { return 2 }\n", encoding="utf-8")
        self.assertTrue(any("changed" in p for p in facpkg.check_lock(facpkg.resolve(self.root))))

    def test_compat_range(self):
        self.mk(".", "app", kind="bin", files={"main.fac": "\n"})
        t = (self.root / "fac.toml").read_text(encoding="utf-8") + '\n[compat]\nfac = ">=9.0.0"\n'
        (self.root / "fac.toml").write_text(t, encoding="utf-8")
        self.assertTrue(facpkg.check_compat(facpkg.resolve(self.root)))

    def test_pack_is_deterministic(self):
        self.mk(".", "app", kind="bin", files={"main.fac": "public function void main() { }\n"})
        facpkg.main(["pack"])
        a = (self.root / "dist" / "app-0.1.0.zip.sha256").read_text()
        facpkg.main(["pack"])
        self.assertEqual(a, (self.root / "dist" / "app-0.1.0.zip.sha256").read_text())

    def test_cli_init_add_remove(self):
        os.chdir(self.root)
        self.assertEqual(facpkg.main(["init", ".", "--name", "app"]), 0)
        (self.root / "vendor").mkdir()
        self.assertEqual(facpkg.main(["init", "vendor/lib1", "--lib", "--name", "lib1"]), 0)
        self.assertEqual(facpkg.main(["add", "lib1", "vendor/lib1", "--version", "^0.1"]), 0)
        self.assertIn("lib1", facpkg.load_package(self.root).deps)
        self.assertEqual(facpkg.main(["remove", "lib1"]), 0)
        self.assertEqual(facpkg.load_package(self.root).deps, {})


class DiagnosticsTests(unittest.TestCase):
    def test_parse_compiler_output(self):
        ds = fac_diagnostics.parse_compiler_output("x.fac:3: error: boom\ny.fac:5: warning: careful\n", "x.fac")
        self.assertEqual([(d.line, d.severity, d.message) for d in ds], [(3, "error", "boom"), (5, "warning", "careful")])
        ds = fac_diagnostics.parse_compiler_output("a.fac:2: a.fac:2: bad thing\n", "a.fac")
        self.assertEqual(ds[0].message, "bad thing")

    def test_lexical_cli(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "bad.fac"
            p.write_text('function void f() {\n  var string s = "oops\n}\n', encoding="utf-8")
            r = run(TOOLS / "fac_diagnostics.py", "--no-compiler", p)
            self.assertEqual(r.returncode, 1)
            self.assertIn("not closed", r.stdout)
            p.write_text("function void f() { return }\n", encoding="utf-8")
            self.assertEqual(run(TOOLS / "fac_diagnostics.py", "--no-compiler", p).returncode, 0)

    @needs_compiler
    def test_compiler_type_error(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "t.fac"
            p.write_text('import terminal.fac\nfunction void main() {\n    var int x = "a"\n    terminal.out.println(x)\n}\n', encoding="utf-8")
            ds = fac_diagnostics.check_file(str(p))
            self.assertTrue(any(d.source == "compiler" and d.line == 3 for d in ds), ds)


def frame(obj):
    b = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode()
    return b"Content-Length: " + str(len(b)).encode() + b"\r\n\r\n" + b


def parse_frames(data: bytes):
    out = []
    while data:
        head, _, rest = data.partition(b"\r\n\r\n")
        n = int(head.split(b":")[1])
        out.append(json.loads(rest[:n].decode("utf-8")))
        data = rest[n:]
    return out


class LspTests(unittest.TestCase):
    def test_protocol_over_stdio(self):
        uri = "file:///tmp/lsp_test_doc.fac"
        text = "import terminal.fac\nimport file.fac\npublic function int f() {\n    file.rea\n    return (1\n}\n"
        payload = frame({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        payload += frame({"jsonrpc": "2.0", "method": "textDocument/didOpen", "params": {"textDocument": {"uri": uri, "text": text}}})
        payload += frame({"jsonrpc": "2.0", "id": 2, "method": "textDocument/completion", "params": {"textDocument": {"uri": uri}, "position": {"line": 3, "character": 12}}})
        payload += frame({"jsonrpc": "2.0", "id": 3, "method": "textDocument/hover", "params": {"textDocument": {"uri": uri}, "position": {"line": 3, "character": 8}}})
        payload += frame({"jsonrpc": "2.0", "id": 4, "method": "textDocument/documentSymbol", "params": {"textDocument": {"uri": uri}}})
        payload += frame({"jsonrpc": "2.0", "id": 5, "method": "nonsense/method", "params": {}})
        payload += frame({"jsonrpc": "2.0", "id": 6, "method": "shutdown", "params": {}})
        payload += frame({"jsonrpc": "2.0", "method": "exit", "params": {}})
        r = subprocess.run([sys.executable, str(TOOLS / "fac_lsp.py")], input=payload, capture_output=True, env=ENV, timeout=60)
        self.assertEqual(r.returncode, 0, r.stderr)
        msgs = parse_frames(r.stdout)
        by_id = {m["id"]: m for m in msgs if "id" in m}
        self.assertEqual(by_id[1]["result"]["serverInfo"]["name"], "FAC Language Server")
        diag = next(m for m in msgs if m.get("method") == "textDocument/publishDiagnostics")
        self.assertTrue(any("unclosed" in d["message"] for d in diag["params"]["diagnostics"]))
        labels = {i["label"] for i in by_id[2]["result"]["items"]}
        self.assertTrue({"readText", "readLine", "readLines"} <= labels)
        self.assertEqual([s["name"] for s in by_id[4]["result"]], ["f"])
        self.assertEqual(by_id[5]["error"]["code"], -32601)
        self.assertIsNone(by_id[6]["result"])

    def test_hover_and_definition(self):
        s = fac_lsp.Server()
        uri = "file:///tmp/lsp_t2.fac"
        text = "import json.fac\n## docs here\npublic function int hello(int a) { return a }\npublic function void main() {\n    ptr json j = json.parse(\"1\")\n    var int x = hello(1)\n}\n"
        s.handle({"method": "textDocument/didOpen", "params": {"textDocument": {"uri": uri, "text": text}}})
        hv = s.handle({"id": 1, "method": "textDocument/hover", "params": {"textDocument": {"uri": uri}, "position": {"line": 4, "character": 24}}})[0]["result"]
        self.assertIn("json.parse", hv["contents"]["value"])
        self.assertIn("json.free", hv["contents"]["value"])
        hv = s.handle({"id": 2, "method": "textDocument/hover", "params": {"textDocument": {"uri": uri}, "position": {"line": 5, "character": 17}}})[0]["result"]
        self.assertIn("docs here", hv["contents"]["value"])
        df = s.handle({"id": 3, "method": "textDocument/definition", "params": {"textDocument": {"uri": uri}, "position": {"line": 5, "character": 17}}})[0]["result"]
        self.assertEqual(df[0]["range"]["start"]["line"], 2)

    def test_formatting_edit(self):
        s = fac_lsp.Server()
        uri = "file:///tmp/lsp_t3.fac"
        s.handle({"method": "textDocument/didOpen", "params": {"textDocument": {"uri": uri, "text": "f() {\nx()\n}\n"}}})
        r = s.handle({"id": 1, "method": "textDocument/formatting", "params": {"textDocument": {"uri": uri}, "options": {}}})[0]["result"]
        self.assertEqual(r[0]["newText"], "f() {\n    x()\n}\n")

    def test_bad_request_does_not_kill_server(self):
        s = fac_lsp.Server()
        r = s.handle({"id": 1, "method": "textDocument/hover", "params": {}})
        self.assertIn("error", r[0])


@needs_compiler
class CompilerIntegrationTests(unittest.TestCase):
    def emit(self, path, *flags):
        with tempfile.TemporaryDirectory() as td:
            return subprocess.run([FACC, str(path), "--emit-ll", "-o", os.path.join(td, "o.ll"), *flags], capture_output=True, text=True, env=ENV)

    def test_api_examples_and_fs_compile(self):
        files = sorted(glob.glob(str(ROOT / "examples" / "api" / "*.fac")) + glob.glob(str(ROOT / "tests" / "api" / "*.fac")))
        self.assertGreaterEqual(len(files), 7)
        for f in files:
            with self.subTest(f=f):
                r = self.emit(f)
                self.assertEqual(r.returncode, 0, r.stderr)

    def test_canonical_spellings_exist(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "p.fac"
            p.write_text('import terminal.fac\nimport file.fac\nfunction void main() {\n    dyn string a = terminal.in.readLine()\n'
                         '    dyn string b = terminal.in.readline()\n    ptr file f = file.open("x", "r")\n    dyn string c = file.readLine(f)\n'
                         '    dyn string d = file.readAll(f)\n    dyn string e = file.readline(f)\n    dyn string g = file.readall(f)\n    file.close(f)\n}\n', encoding="utf-8")
            self.assertEqual(self.emit(p).returncode, 0)

    def test_manifest_matches_compiler_for_every_builtin(self):
        # every manifest entry that is a table function must be callable by name: spot-check one call per module family
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "q.fac"
            p.write_text('import terminal.fac\nimport string.fac\nimport path.fac\nfunction void main() {\n'
                         '    terminal.out.println(string.find("abc", "b"), string.indexOf("abc", "b"), path.exists("."))\n}\n', encoding="utf-8")
            self.assertEqual(self.emit(p).returncode, 0)

    def test_project_workflow(self):
        fac = TOOLS / "fac.py"
        with tempfile.TemporaryDirectory() as td:
            env = dict(ENV, FAC_COMPILER=FACC)
            r = subprocess.run([sys.executable, str(fac), "new", "demo"], cwd=td, capture_output=True, text=True, env=env)
            self.assertEqual(r.returncode, 0, r.stderr)
            proj = pathlib.Path(td) / "demo"
            for cmd in (["check"], ["fmt", "--check"], ["build", "--emit-ll"], ["pkg", "lock"], ["pkg", "verify"], ["doc"]):
                r = subprocess.run([sys.executable, str(fac), *cmd], cwd=proj, capture_output=True, text=True, env=env)
                self.assertEqual(r.returncode, 0, (cmd, r.stdout, r.stderr))
            r = subprocess.run([sys.executable, str(fac), "build", "--emit-ll"], cwd=proj, capture_output=True, text=True, env=env)
            self.assertIn("up to date", r.stdout)
            (proj / "src" / "main.fac").write_text("import terminal.fac\npublic function void main() {\n    var int x = \"s\"\n}\n", encoding="utf-8")
            r = subprocess.run([sys.executable, str(fac), "check"], cwd=proj, capture_output=True, text=True, env=env)
            self.assertEqual(r.returncode, 1)
            self.assertIn("main.fac:3", r.stdout)

    def test_debug_launcher_lists_and_validates(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td) / "d.fac"
            p.write_text("import terminal.fac\nfunction int helper(int a) { return a }\npublic function void main() { terminal.out.println(helper(1)) }\n", encoding="utf-8")
            r = run(TOOLS / "fac_debug.py", p, "--list", "--compiler", FACC)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn("d.helper", r.stdout)
            r = run(TOOLS / "fac_debug.py", p, "--break", "d.nothere", "--compiler", FACC)
            self.assertEqual(r.returncode, 1)
            self.assertIn("no function", r.stderr)


class FacSerdeGeneratorTests(unittest.TestCase):
    SOURCE = """import terminal.fac
struct Vec2 {
    var double x
    var double y
}
struct Player {
    var int id
    dyn string name
    struct Vec2 position
    list var int scores
    list dyn string aliases
    hashmap dyn string, string metadata
    var boolean active
}
"""

    def test_nested_struct_helpers_are_generated(self):
        structs = facserde.parse_structs(self.SOURCE)
        output = facserde.generate(self.SOURCE, structs, "game.save", 3)
        self.assertIn('writer.beginV2("game.save.Vec2", schemaVersion)', output)
        self.assertIn('writer.writeFieldBytes("position", fac_encode_Vec2(value.position, schemaVersion))', output)
        self.assertIn('fac_decode_Vec2(reader.readFieldBytes("position"))', output)
        self.assertIn('reader.readFieldStringMap("metadata")', output)
        self.assertIn('public function struct Player fac_decode_Player', output)

    def test_rejects_unsupported_pointer_like_fields(self):
        source = "struct Unsafe { ptr int address }\n"
        with self.assertRaises(facserde.SerdeError):
            facserde.parse_structs(source)

    def test_rejects_recursive_struct_graph(self):
        source = "struct A {\n    struct B child\n}\nstruct B {\n    struct A parent\n}\n"
        with self.assertRaisesRegex(facserde.SerdeError, "recursive struct graph"):
            facserde.parse_structs(source)

    def test_rejects_unknown_nested_type(self):
        source = "struct A {\n    struct Missing value\n}\n"
        with self.assertRaisesRegex(facserde.SerdeError, "unknown struct"):
            facserde.parse_structs(source)

    def test_schema_prefix_and_version_are_validated(self):
        source = "struct A {\n    var int x\n}\n"
        structs = facserde.parse_structs(source)
        with self.assertRaisesRegex(facserde.SerdeError, "schema prefix"):
            facserde.generate(source, structs, "bad..prefix", 1)
        with self.assertRaisesRegex(facserde.SerdeError, "schema version"):
            facserde.generate(source, structs, "app", 65536)

    def test_cli_check_mode_does_not_write_output(self):
        with tempfile.TemporaryDirectory() as td:
            source = pathlib.Path(td) / "models.fac"
            output = pathlib.Path(td) / "generated.fac"
            source.write_text(self.SOURCE, encoding="utf-8")
            r = run(TOOLS / "facserde.py", source, output, "--check")
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertFalse(output.exists())

    def test_existing_serde_imports_are_not_duplicated(self):
        source = "import serialize.fac\nimport deserialize.fac\nstruct A {\n    var int x\n}\n"
        structs = facserde.parse_structs(source)
        output = facserde.generate(source, structs, "app", 1)
        self.assertEqual(output.count("import serialize.fac"), 1)
        self.assertEqual(output.count("import deserialize.fac"), 1)

    def test_versioned_optional_fields_emit_defaults_and_version_guards(self):
        source = """struct Player {
    var int id
    # @serde since=2 default=0
    var int level
    # @serde since=3 default=\"guest\"
    dyn string title
}
"""
        structs = facserde.parse_structs(source)
        output = facserde.generate(source, structs, "game.player", 3)
        self.assertIn("int schemaVersion = 3", output)
        self.assertIn('if (schemaVersion >= 2) {', output)
        self.assertIn('writer.writeFieldI32("level", value.level)', output)
        self.assertIn('if (schemaVersion >= 3) {', output)
        self.assertIn('writer.writeFieldString("title", value.title)', output)
        self.assertIn('var int _facserde_level = 0', output)
        self.assertIn('dyn string _facserde_title = "guest"', output)
        self.assertIn('reader.readHeaderV2("game.player.Player", 1, 65535)', output)
        self.assertIn('for++(unknownFieldCount) { reader.skipField() }', output)
        self.assertIn('if (fieldCount != decodedFieldCount)', output)
        self.assertIn('writer.beginRecord("Player", fieldCount)', output)

    def test_serde_field_rename_and_numeric_wire_conversion(self):
        source = """struct Wallet {
    var int id
    # @serde since=1 default="" renameFrom=displayName renameSince=2
    dyn string name
    # @serde since=1 default=0 convertFrom=i32 convertSince=2
    var long credits
    # @serde since=1 default=0 convertFrom=i64 convertSince=2
    var int rank
}
"""
        output = facserde.generate(source, facserde.parse_structs(source), "game.wallet", 2)
        self.assertIn('_facserde_wire_name = "displayName"', output)
        self.assertIn('writer.writeFieldString(_facserde_wire_name, value.name)', output)
        self.assertIn('writer.writeFieldI32("credits", value.credits)', output)
        self.assertIn('writer.writeFieldI64("rank", value.rank)', output)
        self.assertIn('readFieldI64FromI32("credits")', output)
        self.assertIn('readFieldI32FromI64("rank")', output)

    def test_serde_user_migration_hook_is_checked_and_emitted(self):
        source = """# @serde-migrate struct=Wallet from=1 function=migrateWalletV1
struct Wallet {
    var int id
}
public function struct Wallet migrateWalletV1(struct Wallet value) {
    value.id = value.id + 1
    return value
}
"""
        output = facserde.generate(source, facserde.parse_structs(source), "game.wallet", 2)
        self.assertIn('if (schemaVersion <= 1) { value = migrateWalletV1(value) }', output)
        invalid = source.replace('function struct Wallet migrateWalletV1(struct Wallet value)', 'function int migrateWalletV1(int value)')
        with self.assertRaisesRegex(facserde.SerdeError, "must accept and return"):
            facserde.generate(invalid, facserde.parse_structs(invalid), "game.wallet", 2)

    def test_serde_rejects_alias_collision_and_unsupported_conversion(self):
        collision = """struct Wallet {
    var int oldName
    # @serde since=1 default=0 renameFrom=oldName renameSince=2
    var int name
}
"""
        with self.assertRaisesRegex(facserde.SerdeError, "collides"):
            facserde.generate(collision, facserde.parse_structs(collision), "game.wallet", 2)
        unsupported = """struct Wallet {
    # @serde since=1 default=0 convertFrom=f32 convertSince=2
    var int points
}
"""
        with self.assertRaisesRegex(facserde.SerdeError, "only checked i32<->i64"):
            facserde.generate(unsupported, facserde.parse_structs(unsupported), "game.wallet", 2)

    def test_serde_fields_must_be_appended_in_version_order(self):
        source = """struct Player {
    # @serde since=3 default=0
    var int later
    # @serde since=2 default=0
    var int earlier
}
"""
        with self.assertRaisesRegex(facserde.SerdeError, "nondecreasing"):
            facserde.parse_structs(source)

    def test_serde_optional_field_requires_supported_scalar_default(self):
        source = "struct Player {\n# @serde since=2 default=empty\nlist var int scores\n}\n"
        structs = facserde.parse_structs(source)
        with self.assertRaisesRegex(facserde.SerdeError, "optional defaults"):
            facserde.generate(source, structs, "game", 2)

    def test_serde_optional_field_rejects_missing_or_out_of_range_default(self):
        missing = "struct A {\n# @serde since=2 default=0\nvar int x\n}\n"
        self.assertEqual(len(facserde.parse_structs(missing)), 1)
        bad = "struct A {\n# @serde since=2 default=999999999999\nvar int x\n}\n"
        with self.assertRaisesRegex(facserde.SerdeError, "outside"):
            facserde.generate(bad, facserde.parse_structs(bad), "app", 2)
        no_default = "struct A {\n# @serde since=2\nvar int x\n}\n"
        with self.assertRaisesRegex(facserde.SerdeError, "malformed @serde"):
            facserde.parse_structs(no_default)

    def test_v157_field_rename_type_conversion_and_business_migration(self):
        source_path = ROOT / "tests" / "api" / "a34_v157_field_migration_source.facsrc"
        source = source_path.read_text(encoding="utf-8")
        structs = facserde.parse_structs(source)
        output = facserde.generate(source, structs, "game.wallet", 2)
        self.assertIn('writer.writeFieldString(_facserde_wire_name, value.name)', output)
        self.assertIn('_facserde_wire_name = "displayName"', output)
        self.assertIn('writer.writeFieldI32("credits", value.credits)', output)
        self.assertIn('writer.writeFieldI64("rank", value.rank)', output)
        self.assertIn('reader.readFieldI64FromI32("credits")', output)
        self.assertIn('reader.readFieldI32FromI64("rank")', output)
        self.assertIn('if (schemaVersion <= 1) { value = migrateWalletV1(value) }', output)

    def test_v157_migration_requires_matching_struct_signature(self):
        source = "# @serde-migrate struct=Wallet from=1 function=migrateWallet\n"
        source += "struct Wallet {\n    var int id\n}\n"
        source += "public function int migrateWallet(int value) { return value }\n"
        with self.assertRaisesRegex(facserde.SerdeError, "must accept and return struct Wallet"):
            facserde.generate(source, facserde.parse_structs(source), "app", 2)

    def test_v157_rejects_unsupported_numeric_conversion(self):
        source = "struct Item {\n# @serde since=1 default=0 convertFrom=f32 convertSince=2\nvar int count\n}\n"
        structs = facserde.parse_structs(source)
        with self.assertRaisesRegex(facserde.SerdeError, "only checked i32<->i64"):
            facserde.generate(source, structs, "app", 2)

    def test_v157_renamed_fields_require_default_and_noncolliding_alias(self):
        collision = "struct Item {\n# @serde since=1 default=0 renameFrom=other renameSince=2\nvar int count\nvar int other\n}\n"
        with self.assertRaisesRegex(facserde.SerdeError, "renameFrom collides"):
            facserde.generate(collision, facserde.parse_structs(collision), "app", 2)
        no_default = "struct Item {\n# @serde since=1 renameFrom=oldCount renameSince=2\nvar int count\n}\n"
        with self.assertRaisesRegex(facserde.SerdeError, "malformed @serde"):
            facserde.parse_structs(no_default)

    def test_v157_migration_must_target_an_older_schema(self):
        source = "# @serde-migrate struct=Item from=2 function=migrateItem\n"
        source += "struct Item {\n    var int id\n}\n"
        source += "public function struct Item migrateItem(struct Item value) { return value }\n"
        with self.assertRaisesRegex(facserde.SerdeError, "must be older than current"):
            facserde.generate(source, facserde.parse_structs(source), "app", 2)


class RepositoryConsistencyTests(unittest.TestCase):
    def test_versions(self):
        self.assertEqual(run(TOOLS / "check_versions.py").returncode, 0)

    def test_deprecated_names_recorded_with_window(self):
        meta = json.loads((ROOT / "api" / "meta.json").read_text(encoding="utf-8"))
        for a in meta["aliases"]:
            if a["status"] == "deprecated":
                self.assertGreaterEqual(api_compat.release_no(a["remove_not_before"]) - api_compat.release_no(a["deprecated_in"]), 3, a["name"])


if __name__ == "__main__":
    unittest.main(verbosity=1)
