#!/usr/bin/env python3
"""ตรวจภาพทั้งเฟรมของ examples/explorer.fac ด้วยการประกอบภาพใหม่เองใน Python (สร้างโลกซ้ำ + ผสม alpha + sprite) แล้วเทียบ checksum
   อ่านบรรทัด "explorer: ..." จากไฟล์ที่ระบุ (สถานะสุดท้าย: pos, facing, cell, cam, sum); แถบ HUD (24 แถวบน) ไม่นับ   ใช้: explorer_check.py FILE"""
import os, re, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets"))
from game_assets import tiles_px, hero_pixel, mix, pack
line = open(sys.argv[1]).read().strip().splitlines()[-1]
m = re.match(r"explorer: updates=(\d+) pos=(-?\d+),(-?\d+) facing=(\d) moving=(\w+) cell=(\d+) cam=(-?\d+),(-?\d+) sum=(\d+) violations=(\d+)", line)
if not m: sys.exit("ตรวจรูปแบบบรรทัดผลลัพธ์ไม่ได้: " + line)
updates, pxm, pym, facing, moving, cell, camx, camy, got, viol = m.groups(); viol = int(viol); pxm, pym, facing, cell, camx, camy, got = int(pxm), int(pym), int(facing), int(cell), int(camx), int(camy), int(got)
seed = 7
def rnd():
    global seed
    seed = (seed * 1103515245 + 12345) % 2147483648
    return (seed // 65536) % 32768
MC, MR, TS = 50, 38, 16
ground = [[1] * MC for _ in range(MR)]; objects = [[0] * MC for _ in range(MR)]
for r in range(MR):
    for c in range(MC):
        f = rnd() % 12; t = rnd() % 14
        if f == 0: ground[r][c] = 2
        river = 30 <= c <= 32; road = 17 <= r <= 19; house = 6 <= c <= 15 and 5 <= r <= 11
        if river: ground[r][c] = 5
        if road: ground[r][c] = 3
        if house: ground[r][c] = 7
        if t == 0 and not (river or road or house): objects[r][c] = 6
for k in range(6, 16):
    objects[5][k] = 4
    if k != 10: objects[11][k] = 4
for k in range(5, 12): objects[k][6] = 4; objects[k][15] = 4
atlas = [[tiles_px(x, y) for x in range(64)] for y in range(32)]
def tile(tid, wx, wy):
    cellv = tid - 1
    return atlas[(cellv // 4) * 16 + wy % TS][(cellv % 4) * 16 + wx % TS]
hx = pxm // 1000 - 3 - camx; hy = pym // 1000 - 7 - camy
s = 7
for sy in range(24, 240):
    for sx in range(320):
        wx, wy = camx + sx, camy + sy; px = (10, 20, 30)
        c, r = wx // TS, wy // TS
        if 0 <= c < MC and 0 <= r < MR:
            if ground[r][c] >= 1: px = mix(px, tile(ground[r][c], wx, wy))
            if objects[r][c] >= 1: px = mix(px, tile(objects[r][c], wx, wy))
        ux, uy = sx - hx, sy - hy
        if 0 <= ux < 16 and 0 <= uy < 16:
            px = mix(px, hero_pixel(cell // 4, cell % 4, 15 - ux if facing == 3 else ux, uy))
        s = (s * 31 + pack(px)) % 1000000007
print(f"frame oracle sum={s} program sum={got} violations={viol}")
sys.exit(0 if s == got and viol == 0 else 1)
