/* ตัวช่วยเทสต์: ยิง SDL event จริงเข้า queue ของโปรเซสเดียวกัน (โหลด SDL ผ่าน dlopen เหมือน runtime) */
#include <dlfcn.h>
#include <string.h>
#include <stdint.h>
static int (*push)(void *);
static int ensure(void) {
  if (push) return 1;
  void *h = dlopen("libSDL2-2.0.so.0", RTLD_NOW);
  if (!h) h = dlopen("libSDL2-2.0.0.dylib", RTLD_NOW);
  if (!h) return 0;
  push = (int (*)(void *))dlsym(h, "SDL_PushEvent");
  return push != 0;
}
int inject_key(int sym, int down) {
  unsigned char ev[64]; memset(ev, 0, sizeof ev);
  uint32_t t = down ? 0x300 : 0x301; int32_t s = sym;
  memcpy(ev, &t, 4); memcpy(ev + 20, &s, 4);
  return ensure() ? push(ev) : -1;
}
int inject_motion(int x, int y) {
  unsigned char ev[64]; memset(ev, 0, sizeof ev);
  uint32_t t = 0x400; memcpy(ev, &t, 4); memcpy(ev + 20, &x, 4); memcpy(ev + 24, &y, 4);
  return ensure() ? push(ev) : -1;
}
int inject_button(int button, int down, int x, int y) {
  unsigned char ev[64]; memset(ev, 0, sizeof ev);
  uint32_t t = down ? 0x401 : 0x402; memcpy(ev, &t, 4); ev[16] = (unsigned char)button; memcpy(ev + 20, &x, 4); memcpy(ev + 24, &y, 4);
  return ensure() ? push(ev) : -1;
}
int inject_quit(void) {
  unsigned char ev[64]; memset(ev, 0, sizeof ev);
  uint32_t t = 0x100; memcpy(ev, &t, 4);
  return ensure() ? push(ev) : -1;
}

int inject_text(const char *text) {
  unsigned char ev[64]; memset(ev, 0, sizeof ev);
  uint32_t t = 0x303; memcpy(ev, &t, 4);
  if (text) { size_t n = strlen(text); if (n > 31) n = 31; memcpy(ev + 12, text, n); }
  return ensure() ? push(ev) : -1;
}
