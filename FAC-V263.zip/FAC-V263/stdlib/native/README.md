# Native API namespace (V53 design contract)

`native.*` is reserved for OS-, architecture-, ABI-, SDK-, driver- and vendor-specific capabilities. Candidate families include Win32, POSIX, Linux, Cocoa, Android NDK/JNI, Vulkan, Direct3D 12, Metal and architecture intrinsics. Names and signatures may differ from cross APIs.

V53 does not ship importable `native.*` binding modules. Existing `extern function`, `link` and compiler linker flags remain the actual low-level FFI path. A native module must declare its target triple, ABI, SDK/library prerequisites, minimum OS, unsafe surface and native-handle ownership. Wrong-target imports must fail during compilation. See `docs/FFI.md`, `docs/PLATFORM_STANDARDS.md` and `docs/FAC_LANGUAGE_TARGETS.md`.
