# Cross-platform API namespace (V53 design contract)

`cross.*` is reserved for APIs whose FAC source syntax, signatures, ownership rules, errors and observable behavior are identical on every target claimed supported. A portable API may offer fewer capabilities than a native binding; capability gaps must be explicit through `Option`, `Result` or capability queries and must never silently change semantics.

V53 does not ship importable `cross.*` modules yet. Existing `stdlib/*.fac` modules and their old imports remain compatible; they are not automatically certified cross-platform. Promote a module only after shared behavior tests pass across the stated OS × architecture × ABI matrix. Keep native handles opaque in cross APIs. See `docs/API_LAYERS.md`, `docs/PLATFORM_STANDARDS.md` and `docs/FAC_LANGUAGE_TARGETS.md`.
