// FAC numerical, data-analysis, ML and neural-network runtime (V101).
// Portable CPU implementation. Handles are opaque and are released by their
// paired free functions. This module intentionally does not claim GPU execution.
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iterator>
#include <limits>
#include <map>
#include <memory>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

struct FacTensor {
  int64_t rows = 0, cols = 0;
  std::vector<double> values;
  FacTensor() = default;
  FacTensor(int64_t r, int64_t c) : rows(r), cols(c), values((size_t)(r * c), 0.0) {}
};
struct FacLinearModel {
  std::vector<double> weights;
  double bias = 0.0;
  bool logistic = false;
  FacLinearModel() = default;
  explicit FacLinearModel(size_t features) : weights(features, 0.0) {}
};
struct FacKMeansModel {
  FacTensor centers;
  int64_t clusters = 0;
  FacKMeansModel() = default;
  FacKMeansModel(int64_t k, int64_t features) : centers(k, features), clusters(k) {}
};
struct FacAdamState {
  FacTensor first, second;
  uint64_t step = 0;
  FacAdamState() = default;
  FacAdamState(int64_t rows, int64_t cols) : first(rows, cols), second(rows, cols) {}
};
struct FacDataSplit {
  FacTensor train, test;
  FacDataSplit() = default;
  FacDataSplit(int64_t trainRows, int64_t testRows, int64_t cols)
      : train(trainRows, cols), test(testRows, cols) {}
};
struct FacKNNModel {
  FacTensor features, labels;
  int32_t k = 1;
  FacKNNModel(const FacTensor &x, const FacTensor &y, int32_t neighbors)
      : features(x), labels(y), k(neighbors) {}
};
struct FacMomentumState {
  FacTensor velocity;
  FacMomentumState() = default;
  FacMomentumState(int64_t rows, int64_t cols) : velocity(rows, cols) {}
};
struct FacRMSPropState {
  FacTensor squareAverage;
  FacRMSPropState() = default;
  FacRMSPropState(int64_t rows, int64_t cols) : squareAverage(rows, cols) {}
};
struct FacDataFrame {
  int64_t rows = 0, cols = 0;
  std::vector<double> values;
  std::vector<std::string> names;
  double at(int64_t r, int64_t c) const { return values[(size_t)(r * cols + c)]; }
};
enum FacGradOp { FAC_GRAD_LEAF=0, FAC_GRAD_ADD, FAC_GRAD_SUB, FAC_GRAD_MUL, FAC_GRAD_DIV,
                 FAC_GRAD_NEG, FAC_GRAD_EXP, FAC_GRAD_LOG, FAC_GRAD_TANH,
                 FAC_GRAD_SIGMOID, FAC_GRAD_RELU, FAC_GRAD_SOFTPLUS, FAC_GRAD_POW };
struct FacGradNode { double value=0.0, grad=0.0, exponent=0.0; int32_t a=-1, b=-1, op=FAC_GRAD_LEAF; };
// Monotonic per-thread identity avoids std::thread::id reuse after a worker exits.
static std::atomic<uint64_t> g_fac_autograd_next_thread_token{1};
static uint64_t fac_autograd_current_thread_token() {
  thread_local const uint64_t token = g_fac_autograd_next_thread_token.fetch_add(1, std::memory_order_relaxed);
  return token;
}
struct FacGradTape {
  std::vector<FacGradNode> nodes;
  const uint64_t owner_token = fac_autograd_current_thread_token();
};
enum FacTensorGradOp { FAC_TGRAD_LEAF=0, FAC_TGRAD_ADD, FAC_TGRAD_SUB, FAC_TGRAD_HADAMARD,
                        FAC_TGRAD_MATMUL, FAC_TGRAD_SCALE, FAC_TGRAD_SUM, FAC_TGRAD_MEAN,
                        FAC_TGRAD_RELU, FAC_TGRAD_SIGMOID, FAC_TGRAD_TANH };
struct FacTensorGradNode {
  FacTensor value;
  std::vector<double> grad;
  int32_t a=-1, b=-1, op=FAC_TGRAD_LEAF;
  double scalar=0.0;
};
struct FacTensorGradTape {
  std::vector<FacTensorGradNode> nodes;
  uint64_t stored_elements=0;
  const uint64_t owner_token = fac_autograd_current_thread_token();
};
static constexpr int64_t FAC_TENSOR_MAX_ELEMENTS = 16LL * 1024LL * 1024LL;
static constexpr size_t FAC_ML_MAX_CSV_BYTES = (size_t)64 << 20;
static constexpr uint64_t FAC_ML_MAX_TRAIN_WORK = UINT64_C(500000000);
static void fac_ml_check_work_budget(const char *op, uint64_t rows, uint64_t features,
                                     uint64_t epochs, uint64_t clusters = 1) {
  uint64_t work = FAC_ML_MAX_TRAIN_WORK;
  const uint64_t factors[] = {rows, features, clusters, epochs};
  for (uint64_t factor : factors) {
    if (factor == 0 || factor > work) do_throw(std::string(op) + ": requested workload exceeds runtime safety budget", 18);
    work /= factor;
  }
}

// FAC exceptions use longjmp, so ordinary C++ automatic objects and unique_ptr
// destructors are skipped. Heap-backed temporaries must be registered with the
// runtime cleanup stack until they are committed or returned to FAC code.
template <typename T, typename... Args> static T *fac_ml_owned_new(Args&&... args) {
  try { return new T(std::forward<Args>(args)...); }
  catch (const std::bad_alloc &) { do_throw("ML runtime: allocation failed", 5); }
  catch (const std::length_error &) { do_throw("ML runtime: requested allocation is too large", 14); }
}
template <typename T> static void fac_ml_guard_drop(void *p) { delete static_cast<T *>(p); }
template <typename T, typename... Args> static T *fac_ml_guard_new(Args&&... args) {
  T *p = nullptr;
  try { p = new T(std::forward<Args>(args)...); } catch (...) { p = nullptr; }
  if (!p) do_throw("ML runtime: allocation failed", 5);
  fac_cleanup_push(p, 4, reinterpret_cast<void *>(&fac_ml_guard_drop<T>));
  return p;
}
template <typename T> static T *fac_ml_guard_release(T *p) {
  if (g_csp <= 0 || g_cleanups.back().slot != p)
    do_throw("ML runtime: temporary cleanup stack mismatch", 8);
  fac_cleanup_pop();
  return p;
}
template <typename T> static void fac_ml_guard_discard(T *p) {
  if (!p) return;
  fac_ml_guard_release(p);
  delete p;
}
template <typename Fn> static void fac_ml_allocation_boundary(Fn &&fn, const char *op) {
  try {
    fn();
  } catch (const std::bad_alloc &) {
    do_throw(std::string(op) + ": allocation failed", 5);
  } catch (const std::length_error &) {
    do_throw(std::string(op) + ": requested allocation is too large", 14);
  }
}
struct FacMLVectorWork { std::vector<double> a, b, c; };
struct FacMLCsvParseWork { std::vector<std::vector<double>> rows; std::vector<double> row; std::string field; bool quoted=false, fieldQuoted=false; };
struct FacMLNameWork { std::vector<std::string> out; std::map<std::string,bool> seen; std::string name; };
struct FacMLDataFrameCsvWork { std::vector<std::string> names; std::string text, header, body; };
struct FacMLDataFrameSelectWork { std::vector<std::string> wanted; std::vector<int32_t> cols; };
struct FacMLGroupAggregate {
  uint64_t count = 0;
  long double sum = 0.0L;
  double minimum = 0.0;
  double maximum = 0.0;
};
struct FacMLDataFrameGroupWork { std::string result_name; std::map<double,FacMLGroupAggregate> groups; };
struct FacMLDataFrameWork { std::vector<int64_t> rows, order; std::vector<int32_t> cols; std::vector<std::string> wanted; std::string name1, name2; };
struct FacMLStringStreamWork { std::ostringstream stream; std::string text; };
static void fac_tensor_dims(int64_t r, int64_t c) {
  if (r <= 0 || c <= 0 || r > FAC_TENSOR_MAX_ELEMENTS || c > FAC_TENSOR_MAX_ELEMENTS || r > FAC_TENSOR_MAX_ELEMENTS / c)
    do_throw("tensor: dimensions must be positive and contain at most 16,777,216 elements", 8);
}
// Opaque Tensor handles cross the C ABI as void*. Validate the complete shape
// and backing-store invariant at the single entry point so every public Tensor
// operation sees a bounded, self-consistent row-major allocation.
static void fac_tensor_validate_shape(const FacTensor *t, const char *op) {
  if (!t) do_throw(std::string(op) + ": null tensor handle", 6);
  if (t->rows <= 0 || t->cols <= 0)
    do_throw(std::string(op) + ": invalid tensor dimensions", 18);
  fac_tensor_dims(t->rows, t->cols); // division-based bound check avoids overflow.
  const uint64_t expected = (uint64_t)t->rows * (uint64_t)t->cols;
  if (expected != (uint64_t)t->values.size())
    do_throw(std::string(op) + ": tensor backing storage does not match its shape", 18);
}
static FacTensor *fac_tensor_checked(void *p) {
  if (!p) do_throw("tensor: null tensor handle", 6);
  FacTensor *t = (FacTensor *)p;
  fac_tensor_validate_shape(t, "tensor");
  return t;
}
static void fac_tensor_same(const FacTensor *a, const FacTensor *b, const char *op) {
  if (!a || !b) do_throw(std::string(op) + ": null tensor handle", 6);
  if (a->rows != b->rows || a->cols != b->cols) do_throw(std::string(op) + ": tensor shapes do not match", 18);
}
static double fac_tensor_sigmoid(double x) {
  if (x >= 0.0) { double z = std::exp(-std::min(x, 700.0)); return 1.0 / (1.0 + z); }
  double z = std::exp(std::max(x, -700.0)); return z / (1.0 + z);
}
static double fac_ml_checked_f64(long double value, const char *op) {
  if (!std::isfinite(value) || value > (long double)std::numeric_limits<double>::max() ||
      value < -(long double)std::numeric_limits<double>::max())
    do_throw(std::string(op) + ": result is outside finite float64 range", 18);
  return (double)value;
}
static void fac_ml_require_finite(const std::vector<double> &values, const char *op) {
  for (double x : values) if (!std::isfinite(x))
    do_throw(std::string(op) + ": input contains NaN or infinity", 18);
}
static double fac_tensor_mean_vec(const std::vector<double> &v) {
  if (v.empty()) do_throw("statistics: empty data", 18);
  fac_ml_require_finite(v, "statistics");
  long double sum = 0.0L;
  for (double x : v) sum += (long double)x;
  return fac_ml_checked_f64(sum / (long double)v.size(), "statistics.mean");
}
static double fac_tensor_variance_vec(const std::vector<double> &v) {
  if (v.empty()) do_throw("statistics: empty data", 18);
  fac_ml_require_finite(v, "statistics");
  // Welford's online algorithm is more stable than E[x*x] - E[x]^2.
  long double mean = 0.0L, m2 = 0.0L;
  uint64_t count = 0;
  for (double value : v) {
    ++count;
    long double delta = (long double)value - mean;
    mean += delta / (long double)count;
    long double delta2 = (long double)value - mean;
    m2 += delta * delta2;
  }
  return fac_ml_checked_f64(m2 / (long double)v.size(), "statistics.variance"); // population variance
}
static std::vector<double> fac_tensor_flat(const FacTensor *t) { return t->values; }
static void fac_tensor_validate_finite(const FacTensor *t, const char *op) {
  for (double x : t->values) if (!std::isfinite(x)) do_throw(std::string(op) + ": input contains NaN or infinity", 18);
}
static FacTensor *fac_tensor_csv_parse(FacStr *src) {
  if (!src) do_throw("data.parseCSV: null text", 6);
  const char *p = sd(src); size_t n = (size_t)sl(src), i = 0;
  if (n > FAC_ML_MAX_CSV_BYTES) do_throw("data.parseCSV: input exceeds 64 MiB limit", 18);
  FacMLCsvParseWork *work = fac_ml_guard_new<FacMLCsvParseWork>();
  auto &rows=work->rows; auto &row=work->row; auto &field=work->field;
  auto emit = [&]() {
    if (field.empty()) do_throw("data.parseCSV: empty or missing numeric field", 18);
    char *end = nullptr; errno = 0; double v = std::strtod(field.c_str(), &end);
    if (errno == ERANGE || end != field.c_str() + field.size() || !std::isfinite(v)) do_throw("data.parseCSV: invalid finite number '" + field + "'", 18);
    row.push_back(v); field.clear(); work->fieldQuoted = false;
  };
  auto finishRow = [&]() {
    if (!row.empty()) { rows.push_back(row); row.clear(); }
  };
  while (i < n) {
    char c = p[i++];
    if (work->quoted) {
      if (c == '"') {
        if (i < n && p[i] == '"') { field.push_back('"'); ++i; }
        else work->quoted = false;
      } else field.push_back(c);
      continue;
    }
    if (c == '"') {
      if (!field.empty() || work->fieldQuoted) do_throw("data.parseCSV: quote inside unquoted field", 18);
      work->quoted = true; work->fieldQuoted = true;
    } else if (c == ',') emit();
    else if (c == '\n' || c == '\r') {
      emit(); finishRow();
      if (c == '\r' && i < n && p[i] == '\n') ++i;
    } else field.push_back(c);
  }
  if (work->quoted) do_throw("data.parseCSV: unterminated quoted field", 18);
  if (!field.empty() || work->fieldQuoted || !row.empty()) { emit(); finishRow(); }
  if (rows.empty()) do_throw("data.parseCSV: no numeric rows", 18);
  const size_t cols = rows.front().size();
  if (!cols) do_throw("data.parseCSV: no columns", 18);
  for (const auto &r : rows) if (r.size() != cols) do_throw("data.parseCSV: rows have different column counts", 18);
  fac_tensor_dims((int64_t)rows.size(), (int64_t)cols);
  FacTensor *out = fac_ml_guard_new<FacTensor>((int64_t)rows.size(), (int64_t)cols);
  for (size_t r = 0; r < rows.size(); ++r) std::copy(rows[r].begin(), rows[r].end(), out->values.begin() + (ptrdiff_t)(r * cols));
  fac_ml_guard_release(out);
  fac_ml_guard_discard(work);
  return out;
}
static std::string fac_tensor_csv_string(const FacTensor *t) {
  std::ostringstream out; out << std::setprecision(17);
  for (int64_t r = 0; r < t->rows; ++r) {
    for (int64_t c = 0; c < t->cols; ++c) { if (c) out << ','; out << t->values[(size_t)(r * t->cols + c)]; }
    if (r + 1 < t->rows) out << '\n';
  }
  return out.str();
}

extern "C" {

// tensor -- row-major CPU tensors (float64 storage).
void *fac_tensor_create(int32_t r, int32_t c) { fac_tensor_dims(r, c); return fac_ml_owned_new<FacTensor>(r, c); }
void *fac_tensor_zeros(int32_t r, int32_t c) { return fac_tensor_create(r, c); }
void *fac_tensor_ones(int32_t r, int32_t c) { FacTensor *t = (FacTensor *)fac_tensor_create(r, c); std::fill(t->values.begin(), t->values.end(), 1.0); return t; }
void fac_tensor_free(void *p) { delete (FacTensor *)p; }
int64_t fac_tensor_rows(void *p) { return fac_tensor_checked(p)->rows; }
int64_t fac_tensor_cols(void *p) { return fac_tensor_checked(p)->cols; }
int64_t fac_tensor_size(void *p) { return (int64_t)fac_tensor_checked(p)->values.size(); }
double fac_tensor_get(void *p, int32_t r, int32_t c) { FacTensor *t = fac_tensor_checked(p); if (r < 0 || c < 0 || r >= t->rows || c >= t->cols) do_throw("tensor.get: index out of range", 2); return t->values[(size_t)r * (size_t)t->cols + (size_t)c]; }
void fac_tensor_set(void *p, int32_t r, int32_t c, double v) { FacTensor *t = fac_tensor_checked(p); if (r < 0 || c < 0 || r >= t->rows || c >= t->cols) do_throw("tensor.set: index out of range", 2); t->values[(size_t)r * (size_t)t->cols + (size_t)c] = v; }
void fac_tensor_fill(void *p, double v) { FacTensor *t = fac_tensor_checked(p); std::fill(t->values.begin(), t->values.end(), v); }
void *fac_tensor_clone(void *p) { FacTensor *t = fac_tensor_checked(p); return fac_ml_owned_new<FacTensor>(*t); }
void fac_tensor_reshape(void *p, int32_t r, int32_t c) { FacTensor *t = fac_tensor_checked(p); fac_tensor_dims(r, c); if ((int64_t)r * c != (int64_t)t->values.size()) do_throw("tensor.reshape: element count must remain unchanged", 18); t->rows = r; t->cols = c; }
void *fac_tensor_transpose(void *p) { FacTensor *t = fac_tensor_checked(p); FacTensor *o = fac_ml_owned_new<FacTensor>(t->cols, t->rows); for (int64_t r=0;r<t->rows;r++) for(int64_t c=0;c<t->cols;c++) o->values[(size_t)c*(size_t)o->cols+(size_t)r]=t->values[(size_t)r*(size_t)t->cols+(size_t)c]; return o; }
static void *fac_tensor_binary(void *ap, void *bp, int op) {
  FacTensor *a=fac_tensor_checked(ap), *b=fac_tensor_checked(bp); fac_tensor_same(a,b,"tensor operation");
  if(op==3)for(double y:b->values)if(y==0.0)do_throw("tensor.divide: division by zero",3);
  FacTensor *o=fac_ml_guard_new<FacTensor>(a->rows,a->cols);
  for(size_t i=0;i<a->values.size();i++) {
    long double x=a->values[i],y=b->values[i],v=op==0?x+y:op==1?x-y:op==2?x*y:x/y;
    o->values[i]=fac_ml_checked_f64(v,"tensor operation");
  }
  return fac_ml_guard_release(o);
}
void *fac_tensor_add(void *a, void *b) { return fac_tensor_binary(a,b,0); }
void *fac_tensor_sub(void *a, void *b) { return fac_tensor_binary(a,b,1); }
void *fac_tensor_hadamard(void *a, void *b) { return fac_tensor_binary(a,b,2); }
void *fac_tensor_divide(void *a, void *b) { return fac_tensor_binary(a,b,3); }
void *fac_tensor_scale(void *p, double s) {
  if(!std::isfinite(s))do_throw("tensor.scale: scalar must be finite",18);
  FacTensor *t=fac_tensor_checked(p);FacTensor *o=fac_ml_guard_new<FacTensor>(*t);
  for(double &x:o->values)x=fac_ml_checked_f64((long double)x*(long double)s,"tensor.scale");
  return fac_ml_guard_release(o);
}
void *fac_tensor_matmul(void *ap, void *bp) {
  FacTensor *a=fac_tensor_checked(ap),*b=fac_tensor_checked(bp);
  if(a->cols!=b->rows)do_throw("tensor.matmul: inner dimensions do not match",18);
  FacTensor *o=fac_ml_guard_new<FacTensor>(a->rows,b->cols);
  for(int64_t i=0;i<a->rows;i++)for(int64_t j=0;j<b->cols;j++){
    long double sum=0.0L;
    for(int64_t k=0;k<a->cols;k++)sum+=(long double)a->values[(size_t)i*(size_t)a->cols+(size_t)k]*(long double)b->values[(size_t)k*(size_t)b->cols+(size_t)j];
    o->values[(size_t)i*(size_t)o->cols+(size_t)j]=fac_ml_checked_f64(sum,"tensor.matmul");
  }
  return fac_ml_guard_release(o);
}
double fac_tensor_sum(void *p) { FacTensor *t=fac_tensor_checked(p); long double s=0; for(double x:t->values)s+=(long double)x; return fac_ml_checked_f64(s,"tensor.sum"); }
double fac_tensor_mean(void *p) { return fac_tensor_mean_vec(fac_tensor_checked(p)->values); }
double fac_tensor_min(void *p) { FacTensor *t=fac_tensor_checked(p); if(t->values.empty())do_throw("tensor.min: empty tensor",18); fac_tensor_validate_finite(t,"tensor.min"); return *std::min_element(t->values.begin(),t->values.end()); }
double fac_tensor_max(void *p) { FacTensor *t=fac_tensor_checked(p); if(t->values.empty())do_throw("tensor.max: empty tensor",18); fac_tensor_validate_finite(t,"tensor.max"); return *std::max_element(t->values.begin(),t->values.end()); }
double fac_tensor_std(void *p) { return std::sqrt(fac_tensor_variance_vec(fac_tensor_checked(p)->values)); }
int64_t fac_tensor_argmax(void *p) { FacTensor *t=fac_tensor_checked(p); if(t->values.empty())do_throw("tensor.argmax: empty tensor",18); fac_tensor_validate_finite(t,"tensor.argmax"); return (int64_t)(std::max_element(t->values.begin(),t->values.end())-t->values.begin()); }
int64_t fac_tensor_argmin(void *p) { FacTensor *t=fac_tensor_checked(p); if(t->values.empty())do_throw("tensor.argmin: empty tensor",18); fac_tensor_validate_finite(t,"tensor.argmin"); return (int64_t)(std::min_element(t->values.begin(),t->values.end())-t->values.begin()); }
void *fac_tensor_row(void *p, int32_t row) { FacTensor *t=fac_tensor_checked(p); if(row<0||row>=t->rows)do_throw("tensor.row: row out of range",2); FacTensor *o=fac_ml_owned_new<FacTensor>(1,t->cols); std::copy(t->values.begin()+(ptrdiff_t)(row*t->cols),t->values.begin()+(ptrdiff_t)((row+1)*t->cols),o->values.begin()); return o; }
void *fac_tensor_column(void *p, int32_t col) { FacTensor *t=fac_tensor_checked(p); if(col<0||col>=t->cols)do_throw("tensor.column: column out of range",2); FacTensor *o=fac_ml_owned_new<FacTensor>(t->rows,1); for(int64_t r=0;r<t->rows;r++)o->values[(size_t)r]=t->values[(size_t)(r*t->cols+col)]; return o; }
void *fac_tensor_concat_rows(void *ap, void *bp) { FacTensor *a=fac_tensor_checked(ap),*b=fac_tensor_checked(bp); if(a->cols!=b->cols)do_throw("tensor.concatRows: column counts differ",18); if(a->rows>FAC_TENSOR_MAX_ELEMENTS-b->rows)do_throw("tensor.concatRows: row count overflow",8); fac_tensor_dims(a->rows+b->rows,a->cols); FacTensor *o=fac_ml_owned_new<FacTensor>(a->rows+b->rows,a->cols); std::copy(a->values.begin(),a->values.end(),o->values.begin()); std::copy(b->values.begin(),b->values.end(),o->values.begin()+(ptrdiff_t)a->values.size()); return o; }
void *fac_tensor_concat_cols(void *ap, void *bp) { FacTensor *a=fac_tensor_checked(ap),*b=fac_tensor_checked(bp); if(a->rows!=b->rows)do_throw("tensor.concatCols: row counts differ",18); if(a->cols>FAC_TENSOR_MAX_ELEMENTS-b->cols)do_throw("tensor.concatCols: column count overflow",8); fac_tensor_dims(a->rows,a->cols+b->cols); FacTensor *o=fac_ml_owned_new<FacTensor>(a->rows,a->cols+b->cols); for(int64_t r=0;r<a->rows;r++){std::copy(a->values.begin()+(ptrdiff_t)(r*a->cols),a->values.begin()+(ptrdiff_t)((r+1)*a->cols),o->values.begin()+(ptrdiff_t)(r*o->cols));std::copy(b->values.begin()+(ptrdiff_t)(r*b->cols),b->values.begin()+(ptrdiff_t)((r+1)*b->cols),o->values.begin()+(ptrdiff_t)(r*o->cols+a->cols));} return o; }
double fac_tensor_dot(void *ap, void *bp) { FacTensor *a=fac_tensor_checked(ap),*b=fac_tensor_checked(bp); if(a->values.size()!=b->values.size())do_throw("tensor.dot: element counts differ",18); long double s=0; for(size_t i=0;i<a->values.size();i++)s+=(long double)a->values[i]*(long double)b->values[i]; return fac_ml_checked_f64(s,"tensor.dot"); }
void *fac_tensor_unary(void *p, int op) {
  FacTensor *t=fac_tensor_checked(p); fac_tensor_validate_finite(t,"tensor unary operation");
  FacTensor *o=fac_ml_guard_new<FacTensor>(*t);
  for(double &x:o->values){
    if(op==0)x=std::fabs(x);
    else if(op==1)x=fac_ml_checked_f64(std::exp((long double)x),"tensor.exp");
    else if(op==2){if(x<=0.0)do_throw("tensor.log: values must be positive",18);x=std::log(x);}
    else if(op==3){if(x<0.0)do_throw("tensor.sqrt: values must be non-negative",18);x=std::sqrt(x);}
  }
  return fac_ml_guard_release(o);
}
void *fac_tensor_abs(void *p) { return fac_tensor_unary(p,0); }
void *fac_tensor_exp(void *p) { return fac_tensor_unary(p,1); }
void *fac_tensor_log(void *p) { return fac_tensor_unary(p,2); }
void *fac_tensor_sqrt(void *p) { return fac_tensor_unary(p,3); }
void *fac_tensor_clip(void *p,double lo,double hi) { if(!std::isfinite(lo)||!std::isfinite(hi)||lo>hi)do_throw("tensor.clip: bounds must be finite and min <= max",18); FacTensor *t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"tensor.clip");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double &x:o->values)x=std::max(lo,std::min(hi,x));return fac_ml_guard_release(o); }
void *fac_tensor_reduce_axis(void *p,int32_t axis,bool mean) {
  FacTensor *t=fac_tensor_checked(p);
  if(axis!=0&&axis!=1)do_throw("tensor.reduceAxis: axis must be 0 or 1",18);
  if(axis==0){FacTensor *o=fac_ml_guard_new<FacTensor>(1,t->cols);for(int64_t c=0;c<t->cols;c++){long double sum=0;for(int64_t r=0;r<t->rows;r++)sum+=(long double)t->values[(size_t)(r*t->cols+c)];o->values[(size_t)c]=fac_ml_checked_f64(mean?sum/(long double)t->rows:sum,"tensor.reduceAxis");}return fac_ml_guard_release(o);}
  FacTensor *o=fac_ml_guard_new<FacTensor>(t->rows,1);for(int64_t r=0;r<t->rows;r++){long double sum=0;for(int64_t c=0;c<t->cols;c++)sum+=(long double)t->values[(size_t)(r*t->cols+c)];o->values[(size_t)r]=fac_ml_checked_f64(mean?sum/(long double)t->cols:sum,"tensor.reduceAxis");}return fac_ml_guard_release(o);
}
void *fac_tensor_sum_axis(void *p,int32_t axis) { return fac_tensor_reduce_axis(p,axis,false); }
void *fac_tensor_mean_axis(void *p,int32_t axis) { return fac_tensor_reduce_axis(p,axis,true); }
void *fac_tensor_add_scalar(void *p,double value) { if(!std::isfinite(value))do_throw("tensor.addScalar: scalar must be finite",18);FacTensor *t=fac_tensor_checked(p);FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double &x:o->values)x=fac_ml_checked_f64((long double)x+(long double)value,"tensor.addScalar");return fac_ml_guard_release(o); }

// data -- numeric CSV and common tabular transforms.
void *fac_data_parse_csv(FacStr *s) { return fac_tensor_csv_parse(s); }
static bool fac_ml_read_csv_limited(const char *path, std::string &out, std::string &err) {
  std::ifstream in(path, std::ios::binary);
  if (!in) { err = "data.loadCSV: cannot open file"; return false; }
  char buf[8192];
  while (in) {
    in.read(buf, sizeof buf);
    const std::streamsize got = in.gcount();
    if (got > 0) {
      const size_t n = (size_t)got;
      if (n > FAC_ML_MAX_CSV_BYTES - out.size()) { err = "data.loadCSV: input exceeds 64 MiB limit"; return false; }
      out.append(buf, n);
    }
  }
  if (in.bad()) { err = "data.loadCSV: read failed"; return false; }
  return true;
}
void *fac_data_load_csv(FacStr *path) {
  if (!path) do_throw("data.loadCSV: null path", 6);
  std::string contents, error;
  if (!fac_ml_read_csv_limited(sd(path), contents, error)) {
    std::string().swap(contents); do_throw(std::move(error), 7);
  }
  FacStr *tmp = mk(contents.data(), (int64_t)contents.size());
  std::string().swap(contents); // FAC errors use longjmp; do not leave a large C++ string live across parsing.
  fac_cleanup_push(&tmp, 1, nullptr);
  FacTensor *result = fac_tensor_csv_parse(tmp);
  fac_cleanup_pop(); fac_str_free(tmp);
  return result;
}
void fac_data_save_csv(void *p, FacStr *path) { FacTensor *t=fac_tensor_checked(p); if(!path)do_throw("data.saveCSV: null path",6); std::string s=fac_tensor_csv_string(t); std::ofstream out(sd(path),std::ios::binary|std::ios::trunc); if(!out)do_throw(std::string("data.saveCSV: cannot write ")+sd(path),7); out.write(s.data(),(std::streamsize)s.size()); if(!out)do_throw("data.saveCSV: write failed",7); }
FacStr *fac_data_to_csv(void *p) { std::string s=fac_tensor_csv_string(fac_tensor_checked(p)); return mk(s.data(),(int64_t)s.size()); }
void *fac_data_select_rows(void *p, int32_t start, int32_t count) { FacTensor *t=fac_tensor_checked(p); if(start<0||count<0||start>t->rows||count>t->rows-start)do_throw("data.selectRows: range out of bounds",2); if(count==0)do_throw("data.selectRows: count must be positive",18); FacTensor *o=fac_ml_owned_new<FacTensor>(count,t->cols); size_t off=(size_t)start*(size_t)t->cols; std::copy(t->values.begin()+(ptrdiff_t)off,t->values.begin()+(ptrdiff_t)(off+(size_t)count*(size_t)t->cols),o->values.begin()); return o; }
void *fac_data_select_columns(void *p, int32_t start, int32_t count) { FacTensor *t=fac_tensor_checked(p); if(start<0||count<=0||start>t->cols||count>t->cols-start)do_throw("data.selectColumns: range out of bounds",2); FacTensor *o=fac_ml_owned_new<FacTensor>(t->rows,count); for(int64_t r=0;r<t->rows;r++)std::copy(t->values.begin()+(ptrdiff_t)(r*t->cols+start),t->values.begin()+(ptrdiff_t)(r*t->cols+start+count),o->values.begin()+(ptrdiff_t)(r*count)); return o; }
void fac_data_shuffle_rows(void *p, int64_t seed) { FacTensor *t=fac_tensor_checked(p); std::mt19937_64 rng((uint64_t)seed); std::vector<int64_t> idx((size_t)t->rows); std::iota(idx.begin(),idx.end(),0); std::shuffle(idx.begin(),idx.end(),rng); std::vector<double> v(t->values.size()); for(int64_t r=0;r<t->rows;r++)std::copy(t->values.begin()+(ptrdiff_t)(idx[(size_t)r]*t->cols),t->values.begin()+(ptrdiff_t)((idx[(size_t)r]+1)*t->cols),v.begin()+(ptrdiff_t)(r*t->cols)); t->values.swap(v); }
void *fac_data_standardize(void *p) {
  FacTensor *t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"data.standardize");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);
  for(int64_t c=0;c<t->cols;c++){
    long double mean=0.0L,m2=0.0L;int64_t n=0;
    for(int64_t r=0;r<t->rows;r++){long double x=t->values[(size_t)(r*t->cols+c)];++n;long double d=x-mean;mean+=d/(long double)n;m2+=d*(x-mean);}
    long double sd=std::sqrt(m2/(long double)t->rows);
    for(int64_t r=0;r<t->rows;r++){size_t ix=(size_t)(r*t->cols+c);long double v=sd>0.0L?((long double)t->values[ix]-mean)/sd:0.0L;o->values[ix]=fac_ml_checked_f64(v,"data.standardize");}
  }
  return fac_ml_guard_release(o);
}
void *fac_data_normalize(void *p) {
  FacTensor *t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"data.normalize");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);
  for(int64_t c=0;c<t->cols;c++){
    double lo=t->values[(size_t)c],hi=lo;for(int64_t r=1;r<t->rows;r++){double x=t->values[(size_t)(r*t->cols+c)];lo=std::min(lo,x);hi=std::max(hi,x);}
    long double range=(long double)hi-(long double)lo;
    for(int64_t r=0;r<t->rows;r++){size_t ix=(size_t)(r*t->cols+c);long double v=range>0.0L?((long double)t->values[ix]-(long double)lo)/range:0.0L;o->values[ix]=fac_ml_checked_f64(v,"data.normalize");}
  }
  return fac_ml_guard_release(o);
}
void *fac_data_drop_column(void *p,int32_t col) { FacTensor *t=fac_tensor_checked(p); if(col<0||col>=t->cols)do_throw("data.dropColumn: column out of range",2); if(t->cols<=1)do_throw("data.dropColumn: cannot remove the only column",18); FacTensor *o=fac_ml_owned_new<FacTensor>(t->rows,t->cols-1); for(int64_t r=0;r<t->rows;r++){int64_t dst=0;for(int64_t c=0;c<t->cols;c++)if(c!=col)o->values[(size_t)(r*o->cols+dst++)]=t->values[(size_t)(r*t->cols+c)];} return o; }
void *fac_data_one_hot(void *p,int32_t classes) { FacTensor *t=fac_tensor_checked(p); if(t->cols!=1||classes<=1)do_throw("data.oneHot: labels must be [N,1] and classes >= 2",18); fac_tensor_dims(t->rows,classes); for(int64_t r=0;r<t->rows;r++){double v=t->values[(size_t)r]; if(!std::isfinite(v)||std::floor(v)!=v||v<0.0||v>=(double)classes)do_throw("data.oneHot: labels must be integer class IDs in [0, classes)",18);} FacTensor *o=fac_ml_owned_new<FacTensor>(t->rows,classes); for(int64_t r=0;r<t->rows;r++){int64_t c=(int64_t)t->values[(size_t)r];o->values[(size_t)(r*classes+c)]=1.0;} return o; }
void *fac_data_train_test_split(void *p,double train_ratio,int64_t seed) { FacTensor *t=fac_tensor_checked(p); if(t->rows<2||!(train_ratio>0.0&&train_ratio<1.0&&std::isfinite(train_ratio)))do_throw("data.trainTestSplit: requires at least 2 rows and ratio in (0,1)",18); int64_t ntrain=(int64_t)std::floor((double)t->rows*train_ratio); ntrain=std::max<int64_t>(1,std::min<int64_t>(t->rows-1,ntrain)); auto *idx=fac_ml_guard_new<std::vector<int64_t>>((size_t)t->rows);std::iota(idx->begin(),idx->end(),0);std::mt19937_64 rng((uint64_t)seed);std::shuffle(idx->begin(),idx->end(),rng);FacDataSplit *sp=fac_ml_guard_new<FacDataSplit>(ntrain,t->rows-ntrain,t->cols);for(int64_t r=0;r<t->rows;r++){FacTensor &dst=r<ntrain?sp->train:sp->test;int64_t dr=r<ntrain?r:r-ntrain;std::copy(t->values.begin()+(ptrdiff_t)((*idx)[(size_t)r]*t->cols),t->values.begin()+(ptrdiff_t)(((*idx)[(size_t)r]+1)*t->cols),dst.values.begin()+(ptrdiff_t)(dr*t->cols));}fac_ml_guard_release(sp);fac_ml_guard_discard(idx);return sp; }
void *fac_data_split_train(void *p) { if(!p)do_throw("data.splitTrain: null split handle",6);FacTensor *t=&((FacDataSplit*)p)->train;fac_tensor_validate_shape(t,"data.splitTrain");return fac_ml_owned_new<FacTensor>(*t); }
void *fac_data_split_test(void *p) { if(!p)do_throw("data.splitTest: null split handle",6);FacTensor *t=&((FacDataSplit*)p)->test;fac_tensor_validate_shape(t,"data.splitTest");return fac_ml_owned_new<FacTensor>(*t); }
void fac_data_split_free(void *p) { delete (FacDataSplit*)p; }

// stats -- flattened population statistics; paired metrics require equal shapes.
double fac_stats_median(void *p) {
  FacTensor *t = fac_tensor_checked(p);
  if (t->values.empty()) do_throw("stats.median: empty tensor", 18);
  fac_tensor_validate_finite(t, "stats.median");
  std::vector<double> *v = fac_ml_guard_new<std::vector<double>>(t->values);
  size_t m = v->size() / 2;
  std::nth_element(v->begin(), v->begin() + (ptrdiff_t)m, v->end());
  double hi = (*v)[m];
  if (v->size() % 2) { fac_ml_guard_discard(v); return hi; }
  std::nth_element(v->begin(), v->begin() + (ptrdiff_t)(m - 1), v->begin() + (ptrdiff_t)m);
  // Halving before addition avoids overflowing when both middle values are large.
  double result = fac_ml_checked_f64((long double)(*v)[m - 1] * 0.5L + (long double)hi * 0.5L, "stats.median");
  fac_ml_guard_discard(v); return result;
}
double fac_stats_variance(void *p) { FacTensor *t=fac_tensor_checked(p); fac_tensor_validate_finite(t,"stats.variance"); return fac_tensor_variance_vec(t->values); }
double fac_stats_quantile(void *p, double q) {
  FacTensor *t = fac_tensor_checked(p);
  if (t->values.empty()) do_throw("stats.quantile: empty tensor", 18);
  if (!std::isfinite(q) || q < 0.0 || q > 1.0) do_throw("stats.quantile: q must be in [0,1]", 18);
  fac_tensor_validate_finite(t, "stats.quantile");
  std::vector<double> *v = fac_ml_guard_new<std::vector<double>>(t->values);
  std::sort(v->begin(), v->end());
  long double pos = (long double)q * (long double)(v->size() - 1);
  size_t lo = (size_t)std::floor(pos), hi = (size_t)std::ceil(pos);
  long double frac = pos - (long double)lo;
  long double result = (1.0L - frac) * (long double)(*v)[lo] + frac * (long double)(*v)[hi];
  double out = fac_ml_checked_f64(result, "stats.quantile");
  fac_ml_guard_discard(v); return out;
}
double fac_stats_iqr(void *p) { return fac_ml_checked_f64((long double)fac_stats_quantile(p,0.75)-fac_stats_quantile(p,0.25),"stats.iqr"); }
double fac_stats_mad(void *p) {
  FacTensor *t = fac_tensor_checked(p); fac_tensor_validate_finite(t, "stats.mad");
  double med = fac_stats_median(p); auto *deviations = fac_ml_guard_new<std::vector<double>>(); deviations->reserve(t->values.size());
  for (double value : t->values) deviations->push_back(fac_ml_checked_f64(std::fabs((long double)value-(long double)med),"stats.mad"));
  if (deviations->empty()) do_throw("stats.mad: empty tensor",18);
  std::sort(deviations->begin(),deviations->end()); size_t m=deviations->size()/2;
  if(deviations->size()%2){double out=(*deviations)[m];fac_ml_guard_discard(deviations);return out;}
  std::nth_element(deviations->begin(),deviations->begin()+(ptrdiff_t)(m-1),deviations->begin()+(ptrdiff_t)m);
  double out=fac_ml_checked_f64((long double)(*deviations)[m-1]*0.5L+(long double)(*deviations)[m]*0.5L,"stats.mad");
  fac_ml_guard_discard(deviations);return out;
}
double fac_stats_skewness(void *p) {
  FacTensor *t=fac_tensor_checked(p); fac_tensor_validate_finite(t,"stats.skewness");
  if(t->values.empty())do_throw("stats.skewness: empty tensor",18);
  long double mean=0.0L,m2=0.0L,m3=0.0L; for(double x:t->values)mean+=(long double)x; mean/=(long double)t->values.size();
  for(double x:t->values){long double d=(long double)x-mean,d2=d*d;m2+=d2;m3+=d2*d;}
  m2/=(long double)t->values.size(); m3/=(long double)t->values.size(); if(m2==0.0L)return 0.0;
  return fac_ml_checked_f64(m3/std::pow(m2,1.5L),"stats.skewness");
}
double fac_stats_kurtosis(void *p) {
  FacTensor *t=fac_tensor_checked(p); fac_tensor_validate_finite(t,"stats.kurtosis");
  if(t->values.empty())do_throw("stats.kurtosis: empty tensor",18);
  long double mean=0.0L,m2=0.0L,m4=0.0L; for(double x:t->values)mean+=(long double)x; mean/=(long double)t->values.size();
  for(double x:t->values){long double d=(long double)x-mean,d2=d*d;m2+=d2;m4+=d2*d2;}
  m2/=(long double)t->values.size(); m4/=(long double)t->values.size(); if(m2==0.0L)return 0.0;
  return fac_ml_checked_f64(m4/(m2*m2)-3.0L,"stats.kurtosis");
}
static void fac_stats_pair(void *ap, void *bp, FacTensor *&a, FacTensor *&b) {
  a=fac_tensor_checked(ap); b=fac_tensor_checked(bp); fac_tensor_same(a,b,"stats pair");
  fac_tensor_validate_finite(a,"stats pair"); fac_tensor_validate_finite(b,"stats pair");
}
double fac_stats_covariance(void *ap, void *bp) {
  FacTensor *a,*b; fac_stats_pair(ap,bp,a,b); if(a->values.empty())do_throw("stats.covariance: empty data",18);
  long double ma=0.0L,mb=0.0L,c=0.0L; uint64_t n=0;
  for(size_t i=0;i<a->values.size();i++){++n;long double x=a->values[i],y=b->values[i];long double dx=x-ma;ma+=dx/(long double)n;long double dy=y-mb;mb+=dy/(long double)n;c+=dx*(y-mb);}
  return fac_ml_checked_f64(c/(long double)a->values.size(),"stats.covariance");
}
double fac_stats_correlation(void *ap, void *bp) {
  FacTensor *a,*b; fac_stats_pair(ap,bp,a,b); if(a->values.empty())do_throw("stats.correlation: empty data",18);
  long double scale_a=0.0L,scale_b=0.0L;
  for(double x:a->values)scale_a=std::max(scale_a,std::fabs((long double)x));
  for(double x:b->values)scale_b=std::max(scale_b,std::fabs((long double)x));
  if(scale_a==0.0L||scale_b==0.0L)return 0.0;
  long double ma=0.0L,mb=0.0L,saa=0.0L,sbb=0.0L,sab=0.0L;uint64_t n=0;
  for(size_t i=0;i<a->values.size();i++){
    ++n;long double x=(long double)a->values[i]/scale_a,y=(long double)b->values[i]/scale_b;
    long double dx=x-ma;ma+=dx/(long double)n;long double dy=y-mb;mb+=dy/(long double)n;
    long double dx2=x-ma,dy2=y-mb;saa+=dx*dx2;sbb+=dy*dy2;sab+=dx*dy2;
  }
  if(saa<=0.0L||sbb<=0.0L)return 0.0;
  long double r=sab/std::sqrt(saa)/std::sqrt(sbb);r=std::max(-1.0L,std::min(1.0L,r));
  return fac_ml_checked_f64(r,"stats.correlation");
}
FacStr *fac_stats_describe(void *p) { FacTensor *t=fac_tensor_checked(p); double mean=fac_tensor_mean(p), var=fac_tensor_variance_vec(t->values); std::ostringstream s;s<<std::setprecision(17)<<"{\"rows\":"<<t->rows<<",\"cols\":"<<t->cols<<",\"count\":"<<t->values.size()<<",\"min\":"<<fac_tensor_min(p)<<",\"max\":"<<fac_tensor_max(p)<<",\"mean\":"<<mean<<",\"variance\":"<<var<<",\"stddev\":"<<std::sqrt(var)<<"}"; std::string out=s.str(); return mk(out.data(),(int64_t)out.size()); }

// metrics -- regression plus binary classification thresholded at 0.5.
static void fac_metrics_pair(void *yp, void *pp, FacTensor *&y, FacTensor *&p) {
  y=fac_tensor_checked(yp); p=fac_tensor_checked(pp); fac_tensor_same(y,p,"metrics");
  if(y->values.empty())do_throw("metrics: empty data",18);
  fac_tensor_validate_finite(y,"metrics targets"); fac_tensor_validate_finite(p,"metrics predictions");
}
double fac_metrics_mse(void *yp, void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);long double s=0;
  for(size_t i=0;i<y->values.size();i++){long double d=(long double)y->values[i]-(long double)p->values[i];s+=d*d;}
  return fac_ml_checked_f64(s/(long double)y->values.size(),"metrics.mse");
}
double fac_metrics_mae(void *yp, void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);long double s=0;
  for(size_t i=0;i<y->values.size();i++)s+=std::fabs((long double)y->values[i]-(long double)p->values[i]);
  return fac_ml_checked_f64(s/(long double)y->values.size(),"metrics.mae");
}
double fac_metrics_rmse(void *yp, void *pp) { return std::sqrt(fac_metrics_mse(yp,pp)); }
double fac_metrics_r2(void *yp, void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);long double mean=0;for(double v:y->values)mean+=(long double)v;mean/=(long double)y->values.size();
  long double ssr=0,sst=0;for(size_t i=0;i<y->values.size();i++){long double d=(long double)y->values[i]-p->values[i],e=(long double)y->values[i]-mean;ssr+=d*d;sst+=e*e;}
  if(sst==0.0L)return ssr==0.0L?1.0:0.0;
  return fac_ml_checked_f64(1.0L-ssr/sst,"metrics.r2");
}
static void fac_metrics_counts(void *yp, void *pp, uint64_t &tp,uint64_t &fp,uint64_t &fn,uint64_t &tn) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);tp=fp=fn=tn=0;
  for(size_t i=0;i<y->values.size();i++){bool a=y->values[i]>=0.5,b=p->values[i]>=0.5;if(a&&b)tp++;else if(!a&&b)fp++;else if(a&&!b)fn++;else tn++;}
}
double fac_metrics_accuracy(void *y,void *p) { uint64_t tp,fp,fn,tn;fac_metrics_counts(y,p,tp,fp,fn,tn);return (double)(tp+tn)/(double)(tp+fp+fn+tn); }
double fac_metrics_precision(void *y,void *p) { uint64_t tp,fp,fn,tn;fac_metrics_counts(y,p,tp,fp,fn,tn);return tp+fp?(double)tp/(double)(tp+fp):0.0; }
double fac_metrics_recall(void *y,void *p) { uint64_t tp,fp,fn,tn;fac_metrics_counts(y,p,tp,fp,fn,tn);return tp+fn?(double)tp/(double)(tp+fn):0.0; }
double fac_metrics_specificity(void *y,void *p) { uint64_t tp,fp,fn,tn;fac_metrics_counts(y,p,tp,fp,fn,tn);return tn+fp?(double)tn/(double)(tn+fp):0.0; }
double fac_metrics_balanced_accuracy(void *y,void *p) { return 0.5*(fac_metrics_recall(y,p)+fac_metrics_specificity(y,p)); }
double fac_metrics_mape(void *yp,void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);long double s=0;size_t n=0;
  for(size_t i=0;i<y->values.size();i++){if(y->values[i]==0.0)continue;s+=std::fabs(((long double)y->values[i]-(long double)p->values[i])/(long double)y->values[i]);n++;}
  if(!n)do_throw("metrics.mape: all target values are zero",18);
  return fac_ml_checked_f64(100.0L*s/(long double)n,"metrics.mape");
}
double fac_metrics_max_error(void *yp,void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);long double m=0;
  for(size_t i=0;i<y->values.size();i++)m=std::max(m,std::fabs((long double)y->values[i]-(long double)p->values[i]));
  return fac_ml_checked_f64(m,"metrics.maxError");
}
double fac_metrics_median_absolute_error(void *yp,void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);auto *e=fac_ml_guard_new<std::vector<long double>>();e->reserve(y->values.size());
  for(size_t i=0;i<y->values.size();i++)e->push_back(std::fabs((long double)y->values[i]-(long double)p->values[i]));
  size_t m=e->size()/2;std::nth_element(e->begin(),e->begin()+(ptrdiff_t)m,e->end());long double hi=(*e)[m];
  if(e->size()%2){double out=fac_ml_checked_f64(hi,"metrics.medianAbsoluteError");fac_ml_guard_discard(e);return out;}
  std::nth_element(e->begin(),e->begin()+(ptrdiff_t)(m-1),e->begin()+(ptrdiff_t)m);
  double out=fac_ml_checked_f64((*e)[m-1]*0.5L+hi*0.5L,"metrics.medianAbsoluteError");fac_ml_guard_discard(e);return out;
}
double fac_metrics_log_loss(void *yp, void *pp) {
  FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);long double s=0;
  for(size_t i=0;i<y->values.size();i++){
    if(y->values[i]!=0.0&&y->values[i]!=1.0)do_throw("metrics.logLoss: binary targets must be 0 or 1",18);
    double q=std::max(1e-12,std::min(1.0-1e-12,p->values[i]));
    s-=(long double)y->values[i]*std::log(q)+(1.0L-(long double)y->values[i])*std::log(1.0-q);
  }
  return fac_ml_checked_f64(s/(long double)y->values.size(),"metrics.logLoss");
}
double fac_metrics_f1(void *y,void *p) { double pr=fac_metrics_precision(y,p),re=fac_metrics_recall(y,p);return pr+re>0?2.0*pr*re/(pr+re):0.0; }
void *fac_metrics_confusion(void *y,void *p) { uint64_t tp,fp,fn,tn;fac_metrics_counts(y,p,tp,fp,fn,tn);FacTensor *o=fac_ml_owned_new<FacTensor>(2,2);o->values={double(tn),double(fp),double(fn),double(tp)};return o; }

// ml -- deterministic CPU estimators: batch gradient descent and k-means.
static void fac_ml_xy(void *xp, void *yp, FacTensor *&x, FacTensor *&y) { x=fac_tensor_checked(xp); y=fac_tensor_checked(yp); if(x->rows!=y->rows||y->cols!=1)do_throw("ml: expected X[N,F] and y[N,1] with matching N",18);if(x->rows<1||x->cols<1)do_throw("ml: training data is empty",18);fac_tensor_validate_finite(x,"ml");fac_tensor_validate_finite(y,"ml"); }
static void *fac_ml_fit_linear_impl(void *xp, void *yp, double lr, int32_t epochs,
                                    double lambda, bool logistic, const char *op) {
  FacTensor *x, *y;
  fac_ml_xy(xp, yp, x, y);
  if (!(lr > 0.0 && std::isfinite(lr)) || epochs <= 0 ||
      !(lambda >= 0.0 && std::isfinite(lambda)))
    do_throw(std::string(op) + ": invalid learning rate, epochs or lambda", 18);
  fac_ml_check_work_budget(op, (uint64_t)x->rows, (uint64_t)x->cols, (uint64_t)epochs);
  if (logistic) {
    for (double v : y->values)
      if (v != 0.0 && v != 1.0) do_throw("ml.logisticFit: labels must be 0 or 1", 18);
  }

  // Keep both the model and its reusable gradient workspace on the Runtime
  // cleanup stack. FAC errors use longjmp and therefore do not run C++ local
  // destructors; these guards make every partially-built fit rollback-safe.
  FacLinearModel *m = fac_ml_guard_new<FacLinearModel>((size_t)x->cols);
  std::vector<long double> *gradient =
      fac_ml_guard_new<std::vector<long double>>((size_t)x->cols, 0.0L);
  m->logistic = logistic;
  double bias = 0.0;
  for (int32_t e = 0; e < epochs; ++e) {
    std::fill(gradient->begin(), gradient->end(), 0.0L);
    long double gb = 0.0L;
    for (int64_t r = 0; r < x->rows; ++r) {
      long double d = 0.0L;
      if (logistic) {
        // Keep the original logistic accumulation and intercept behavior.
        double z = 0.0;
        for (int64_t c = 0; c < x->cols; ++c)
          z += x->values[(size_t)(r * x->cols + c)] * m->weights[(size_t)c];
        d = (long double)fac_tensor_sigmoid(z) - (long double)y->values[(size_t)r];
      } else {
        long double pred = (long double)bias;
        for (int64_t c = 0; c < x->cols; ++c)
          pred += (long double)x->values[(size_t)(r * x->cols + c)] *
                  (long double)m->weights[(size_t)c];
        d = pred - (long double)y->values[(size_t)r];
      }
      gb += d;
      for (int64_t c = 0; c < x->cols; ++c)
        (*gradient)[(size_t)c] += d * (long double)x->values[(size_t)(r * x->cols + c)];
    }
    const double scale = (logistic ? 1.0 : 2.0) / (double)x->rows;
    for (int64_t c = 0; c < x->cols; ++c) {
      const double regularization = logistic ? 0.0 : 2.0 * lambda * m->weights[(size_t)c];
      m->weights[(size_t)c] -= lr * ((double)(*gradient)[(size_t)c] * scale + regularization);
    }
    bias -= lr * (double)gb * scale;
  }
  m->bias = bias;
  fac_ml_guard_discard(gradient);
  return fac_ml_guard_release(m);
}
void *fac_ml_linear_fit(void *xp, void *yp, double lr, int32_t epochs) {
  return fac_ml_fit_linear_impl(xp, yp, lr, epochs, 0.0, false, "ml.linearFit");
}
void *fac_ml_ridge_fit(void *xp, void *yp, double lr, int32_t epochs, double lambda) {
  return fac_ml_fit_linear_impl(xp, yp, lr, epochs, lambda, false, "ml.ridgeFit");
}
void *fac_ml_linear_predict(void *mp,void *xp) { if(!mp)do_throw("ml.linearPredict: null model",6);FacLinearModel*m=(FacLinearModel*)mp;FacTensor*x=fac_tensor_checked(xp);if(x->cols!=(int64_t)m->weights.size())do_throw("ml.linearPredict: feature count mismatch",18);FacTensor*o=fac_ml_owned_new<FacTensor>(x->rows,1);for(int64_t r=0;r<x->rows;r++){double z=m->bias;for(int64_t c=0;c<x->cols;c++)z+=x->values[(size_t)(r*x->cols+c)]*m->weights[(size_t)c];o->values[(size_t)r]=m->logistic?fac_tensor_sigmoid(z):z;}return o; }
double fac_ml_linear_weight(void *mp,int32_t i) { if(!mp)do_throw("ml.linearWeight: null model",6);FacLinearModel*m=(FacLinearModel*)mp;if(i<0||(size_t)i>=m->weights.size())do_throw("ml.linearWeight: index out of range",2);return m->weights[(size_t)i]; }
double fac_ml_linear_bias(void *mp) { if(!mp)do_throw("ml.linearBias: null model",6);return ((FacLinearModel*)mp)->bias; }
void *fac_ml_logistic_fit(void *xp, void *yp, double lr, int32_t epochs) {
  return fac_ml_fit_linear_impl(xp, yp, lr, epochs, 0.0, true, "ml.logisticFit");
}
void *fac_ml_logistic_classify(void *mp,void *xp,double threshold) { if(!(threshold>=0.0&&threshold<=1.0))do_throw("ml.logisticClassify: threshold must be in [0,1]",18);FacTensor*prob=(FacTensor*)fac_ml_linear_predict(mp,xp);for(double&v:prob->values)v=v>=threshold?1.0:0.0;return prob; }
void fac_ml_free_model(void *p) { delete (FacLinearModel *)p; }
void *fac_ml_kmeans(void *dp, int32_t k, int32_t epochs, int64_t seed) {
  FacTensor *d = fac_tensor_checked(dp);
  if (k <= 0 || k > d->rows || epochs <= 0)
    do_throw("ml.kmeans: k must be 1..rows and epochs positive", 18);
  fac_ml_check_work_budget("ml.kmeans", (uint64_t)d->rows, (uint64_t)d->cols,
                           (uint64_t)epochs, (uint64_t)k);
  fac_tensor_validate_finite(d, "ml.kmeans");

  FacKMeansModel *m = fac_ml_guard_new<FacKMeansModel>((int64_t)k, d->cols);
  std::vector<int64_t> *idx = fac_ml_guard_new<std::vector<int64_t>>((size_t)d->rows);
  std::vector<int32_t> *assignment =
      fac_ml_guard_new<std::vector<int32_t>>((size_t)d->rows, 0);
  const size_t centerElements = (size_t)k * (size_t)d->cols;
  std::vector<double> *sums =
      fac_ml_guard_new<std::vector<double>>(centerElements, 0.0);
  std::vector<int64_t> *counts =
      fac_ml_guard_new<std::vector<int64_t>>((size_t)k, 0);

  std::iota(idx->begin(), idx->end(), 0);
  std::mt19937_64 rng((uint64_t)seed);
  std::shuffle(idx->begin(), idx->end(), rng);
  for (int32_t c = 0; c < k; ++c) {
    std::copy(d->values.begin() + (ptrdiff_t)((*idx)[(size_t)c] * d->cols),
              d->values.begin() + (ptrdiff_t)(((*idx)[(size_t)c] + 1) * d->cols),
              m->centers.values.begin() + (ptrdiff_t)((int64_t)c * d->cols));
  }
  for (int32_t e = 0; e < epochs; ++e) {
    bool changed = false;
    for (int64_t r = 0; r < d->rows; ++r) {
      double best = std::numeric_limits<double>::infinity();
      int32_t bestIndex = 0;
      for (int32_t c = 0; c < k; ++c) {
        long double distance = 0.0L;
        for (int64_t j = 0; j < d->cols; ++j) {
          const double delta = d->values[(size_t)(r * d->cols + j)] -
              m->centers.values[(size_t)((int64_t)c * d->cols + j)];
          distance += (long double)delta * delta;
        }
        if ((double)distance < best) { best = (double)distance; bestIndex = c; }
      }
      if ((*assignment)[(size_t)r] != bestIndex) {
        (*assignment)[(size_t)r] = bestIndex;
        changed = true;
      }
    }
    std::fill(sums->begin(), sums->end(), 0.0);
    std::fill(counts->begin(), counts->end(), 0);
    for (int64_t r = 0; r < d->rows; ++r) {
      const int32_t cluster = (*assignment)[(size_t)r];
      ++(*counts)[(size_t)cluster];
      for (int64_t j = 0; j < d->cols; ++j)
        (*sums)[(size_t)cluster * (size_t)d->cols + (size_t)j] +=
            d->values[(size_t)(r * d->cols + j)];
    }
    for (int32_t c = 0; c < k; ++c) {
      if ((*counts)[(size_t)c]) {
        for (int64_t j = 0; j < d->cols; ++j) {
          const size_t at = (size_t)c * (size_t)d->cols + (size_t)j;
          m->centers.values[at] = (*sums)[at] / (double)(*counts)[(size_t)c];
        }
      }
    }
    if (!changed) break;
  }
  fac_ml_guard_discard(counts);
  fac_ml_guard_discard(sums);
  fac_ml_guard_discard(assignment);
  fac_ml_guard_discard(idx);
  return fac_ml_guard_release(m);
}
void *fac_ml_kmeans_predict(void *mp,void *dp) { if(!mp)do_throw("ml.kmeansPredict: null model",6);FacKMeansModel*m=(FacKMeansModel*)mp;FacTensor*d=fac_tensor_checked(dp);if(d->cols!=m->centers.cols)do_throw("ml.kmeansPredict: feature count mismatch",18);FacTensor*o=fac_ml_owned_new<FacTensor>(d->rows,1);for(int64_t r=0;r<d->rows;r++){double best=std::numeric_limits<double>::infinity();int32_t bi=0;for(int32_t c=0;c<m->clusters;c++){long double dist=0;for(int64_t j=0;j<d->cols;j++){double z=d->values[(size_t)(r*d->cols+j)]-m->centers.values[(size_t)(c*d->cols+j)];dist+=(long double)z*z;}if((double)dist<best){best=(double)dist;bi=c;}}o->values[(size_t)r]=(double)bi;}return o; }
void *fac_ml_kmeans_centers(void *mp) { if(!mp)do_throw("ml.kmeansCenters: null model",6);return fac_ml_owned_new<FacTensor>(((FacKMeansModel*)mp)->centers); }
void fac_ml_free_kmeans(void *p) { delete (FacKMeansModel *)p; }
void *fac_ml_knn_fit(void *xp, void *yp, int32_t k) {
  FacTensor *x = fac_tensor_checked(xp), *y = fac_tensor_checked(yp);
  if (x->rows != y->rows || y->cols != 1 || k <= 0 || k > x->rows)
    do_throw("ml.knnFit: expected X[N,F], y[N,1], and 1 <= k <= N", 18);
  fac_tensor_validate_finite(x, "ml.knnFit");
  fac_tensor_validate_finite(y, "ml.knnFit");
  return fac_ml_guard_release(fac_ml_guard_new<FacKNNModel>(*x, *y, k));
}
void *fac_ml_knn_predict(void *mp, void *xp) {
  if (!mp) do_throw("ml.knnPredict: null model", 6);
  FacKNNModel *m = (FacKNNModel *)mp;
  FacTensor *x = fac_tensor_checked(xp);
  if (x->cols != m->features.cols) do_throw("ml.knnPredict: feature count mismatch", 18);
  fac_tensor_validate_finite(x, "ml.knnPredict");
  FacTensor *out = fac_ml_guard_new<FacTensor>(x->rows, 1);
  std::vector<std::pair<long double, double>> *dist =
      fac_ml_guard_new<std::vector<std::pair<long double, double>>>((size_t)m->features.rows);
  std::map<double, int32_t> *votes = fac_ml_guard_new<std::map<double, int32_t>>();
  fac_ml_allocation_boundary([&] {
    for (int64_t r = 0; r < x->rows; ++r) {
      for (int64_t tr = 0; tr < m->features.rows; ++tr) {
        long double distance = 0.0L;
        for (int64_t c = 0; c < x->cols; ++c) {
          const long double delta = (long double)x->values[(size_t)(r * x->cols + c)] -
              (long double)m->features.values[(size_t)(tr * m->features.cols + c)];
          distance += delta * delta;
        }
        (*dist)[(size_t)tr] = {distance, m->labels.values[(size_t)tr]};
      }
      std::partial_sort(dist->begin(), dist->begin() + m->k, dist->end(),
          [](const auto &a, const auto &b) {
            return a.first < b.first || (a.first == b.first && a.second < b.second);
          });
      votes->clear();
      for (int32_t i = 0; i < m->k; ++i) ++(*votes)[(*dist)[(size_t)i].second];
      int32_t bestCount = -1;
      double label = 0.0;
      for (const auto &vote : *votes) {
        if (vote.second > bestCount) { bestCount = vote.second; label = vote.first; }
      }
      out->values[(size_t)r] = label;
    }
  }, "ml.knnPredict");
  fac_ml_guard_discard(votes);
  fac_ml_guard_discard(dist);
  return fac_ml_guard_release(out);
}
void fac_ml_free_knn(void *p) { delete (FacKNNModel*)p; }

// nn -- forward-pass primitives and common loss functions, all CPU float64.
static void fac_nn_check_result(FacTensor *t,const char *op){fac_tensor_validate_finite(t,op);}
static void fac_nn_validate_binary_probabilities(FacTensor*y,FacTensor*p,const char*op){
  for(size_t i=0;i<y->values.size();i++)if(y->values[i]<0.0||y->values[i]>1.0||p->values[i]<0.0||p->values[i]>1.0)
    do_throw(std::string(op)+": targets and probabilities must be in [0,1]",18);
}
static void fac_nn_validate_categorical_probabilities(FacTensor*y,FacTensor*p,const char*op){
  if(y->cols<2)do_throw(std::string(op)+": categorical tensors need at least two classes",18);
  const long double tolerance=1.0e-6L*(long double)std::max<int64_t>(1,y->cols);
  for(int64_t r=0;r<y->rows;r++){
    long double ys=0.0L,ps=0.0L;
    for(int64_t c=0;c<y->cols;c++){
      size_t i=(size_t)(r*y->cols+c);double a=y->values[i],b=p->values[i];
      if(a<0.0||a>1.0||b<0.0||b>1.0)do_throw(std::string(op)+": targets and probabilities must be in [0,1]",18);
      ys+=(long double)a;ps+=(long double)b;
    }
    if(std::fabs(ys-1.0L)>tolerance||std::fabs(ps-1.0L)>tolerance)
      do_throw(std::string(op)+": each target and probability row must sum to 1",18);
  }
}
void *fac_nn_relu(void *p) { FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.relu");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double&x:o->values)x=std::max(0.0,x);return fac_ml_guard_release(o); }
void *fac_nn_sigmoid(void *p) { FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.sigmoid");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double&x:o->values)x=fac_tensor_sigmoid(x);return fac_ml_guard_release(o); }
void *fac_nn_tanh(void *p) { FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.tanh");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double&x:o->values)x=std::tanh(x);return fac_ml_guard_release(o); }
void *fac_nn_leaky_relu(void *p,double alpha) { if(!(alpha>=0.0&&alpha<=1.0&&std::isfinite(alpha)))do_throw("nn.leakyRelu: alpha must be in [0,1]",18);FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.leakyRelu");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double&x:o->values)if(x<0.0)x=fac_ml_checked_f64((long double)x*alpha,"nn.leakyRelu");return fac_ml_guard_release(o); }
void *fac_nn_elu(void *p,double alpha) { if(!(alpha>0.0&&std::isfinite(alpha)))do_throw("nn.elu: alpha must be positive",18);FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.elu");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double&x:o->values)if(x<0.0)x=fac_ml_checked_f64((long double)alpha*std::expm1(x),"nn.elu");return fac_ml_guard_release(o); }
void *fac_nn_gelu(void *p) { FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.gelu");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);const long double k=std::sqrt(2.0L/3.1415926535897932384626433832795L);for(double&x:o->values){long double v=x,z=k*(v+0.044715L*v*v*v);long double y=0.5L*v*(1.0L+std::tanh(z));x=fac_ml_checked_f64(y,"nn.gelu");}return fac_ml_guard_release(o); }
void *fac_nn_softplus(void *p) { FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.softplus");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);for(double&x:o->values){if(x>30.0)continue;if(x< -30.0)x=std::exp(x);else x=std::log1p(std::exp(x));}return fac_ml_guard_release(o); }
void *fac_nn_leaky_relu_backward(void *xp,void *gp,double alpha) { if(!(alpha>=0.0&&alpha<=1.0&&std::isfinite(alpha)))do_throw("nn.leakyReluBackward: alpha must be in [0,1]",18);FacTensor*x=fac_tensor_checked(xp),*g=fac_tensor_checked(gp);fac_tensor_same(x,g,"nn.leakyReluBackward");fac_tensor_validate_finite(x,"nn.leakyReluBackward input");fac_tensor_validate_finite(g,"nn.leakyReluBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(size_t i=0;i<o->values.size();i++)if(x->values[i]<0.0)o->values[i]=fac_ml_checked_f64((long double)o->values[i]*alpha,"nn.leakyReluBackward");return fac_ml_guard_release(o); }
void *fac_nn_elu_backward(void *xp,void *gp,double alpha) { if(!(alpha>0.0&&std::isfinite(alpha)))do_throw("nn.eluBackward: alpha must be positive",18);FacTensor*x=fac_tensor_checked(xp),*g=fac_tensor_checked(gp);fac_tensor_same(x,g,"nn.eluBackward");fac_tensor_validate_finite(x,"nn.eluBackward input");fac_tensor_validate_finite(g,"nn.eluBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(size_t i=0;i<o->values.size();i++)if(x->values[i]<0.0)o->values[i]=fac_ml_checked_f64((long double)o->values[i]*(long double)alpha*std::exp(x->values[i]),"nn.eluBackward");return fac_ml_guard_release(o); }
void *fac_nn_softplus_backward(void *xp,void *gp) { FacTensor*x=fac_tensor_checked(xp),*g=fac_tensor_checked(gp);fac_tensor_same(x,g,"nn.softplusBackward");fac_tensor_validate_finite(x,"nn.softplusBackward input");fac_tensor_validate_finite(g,"nn.softplusBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(size_t i=0;i<o->values.size();i++)o->values[i]=fac_ml_checked_f64((long double)o->values[i]*fac_tensor_sigmoid(x->values[i]),"nn.softplusBackward");return fac_ml_guard_release(o); }
void *fac_nn_softmax(void *p) {
  FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.softmax");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);
  for(int64_t r=0;r<t->rows;r++){
    double mx=-std::numeric_limits<double>::infinity();for(int64_t c=0;c<t->cols;c++)mx=std::max(mx,t->values[(size_t)(r*t->cols+c)]);
    long double sum=0.0L;for(int64_t c=0;c<t->cols;c++){size_t i=(size_t)(r*t->cols+c);long double e=std::exp((long double)t->values[i]-(long double)mx);o->values[i]=fac_ml_checked_f64(e,"nn.softmax");sum+=e;}
    if(!(sum>0.0L)||!std::isfinite(sum))do_throw("nn.softmax: invalid normalization sum",18);
    for(int64_t c=0;c<t->cols;c++){size_t i=(size_t)(r*t->cols+c);o->values[i]=fac_ml_checked_f64((long double)o->values[i]/sum,"nn.softmax");}
  }
  return fac_ml_guard_release(o);
}
void *fac_nn_dense(void *xp,void *wp,void *bp) {
  FacTensor*x=fac_tensor_checked(xp),*w=fac_tensor_checked(wp),*b=fac_tensor_checked(bp);
  if(x->cols!=w->rows||b->rows!=1||b->cols!=w->cols)do_throw("nn.dense: expected X[N,I], W[I,O], bias[1,O]",18);
  fac_tensor_validate_finite(x,"nn.dense input");fac_tensor_validate_finite(w,"nn.dense weights");fac_tensor_validate_finite(b,"nn.dense bias");
  FacTensor *o=(FacTensor*)fac_tensor_matmul(xp,wp); fac_cleanup_push(o,4,reinterpret_cast<void *>(&fac_ml_guard_drop<FacTensor>));
  for(int64_t r=0;r<o->rows;r++)for(int64_t c=0;c<o->cols;c++){size_t i=(size_t)(r*o->cols+c);o->values[i]=fac_ml_checked_f64((long double)o->values[i]+b->values[(size_t)c],"nn.dense");}
  return fac_ml_guard_release(o);
}
void *fac_nn_dropout(void *p,double rate,int64_t seed) { if(!(rate>=0.0&&rate<1.0&&std::isfinite(rate)))do_throw("nn.dropout: rate must be in [0,1)",18);FacTensor*t=fac_tensor_checked(p);fac_tensor_validate_finite(t,"nn.dropout");FacTensor *o=fac_ml_guard_new<FacTensor>(*t);std::mt19937_64 rng((uint64_t)seed);std::bernoulli_distribution keep(1.0-rate);double scale=1.0/(1.0-rate);for(double&x:o->values)x=keep(rng)?fac_ml_checked_f64((long double)x*scale,"nn.dropout"):0.0;return fac_ml_guard_release(o); }
void *fac_nn_relu_backward(void *xp,void *gp) { FacTensor*x=fac_tensor_checked(xp),*g=fac_tensor_checked(gp);fac_tensor_same(x,g,"nn.reluBackward");fac_tensor_validate_finite(x,"nn.reluBackward input");fac_tensor_validate_finite(g,"nn.reluBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(size_t i=0;i<o->values.size();i++)if(x->values[i]<=0.0)o->values[i]=0.0;return fac_ml_guard_release(o); }
void *fac_nn_sigmoid_backward(void *yp,void *gp) { FacTensor*y=fac_tensor_checked(yp),*g=fac_tensor_checked(gp);fac_tensor_same(y,g,"nn.sigmoidBackward");fac_tensor_validate_finite(y,"nn.sigmoidBackward output");fac_tensor_validate_finite(g,"nn.sigmoidBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(size_t i=0;i<o->values.size();i++)o->values[i]=fac_ml_checked_f64((long double)o->values[i]*y->values[i]*(1.0L-y->values[i]),"nn.sigmoidBackward");return fac_ml_guard_release(o); }
void *fac_nn_tanh_backward(void *yp,void *gp) { FacTensor*y=fac_tensor_checked(yp),*g=fac_tensor_checked(gp);fac_tensor_same(y,g,"nn.tanhBackward");fac_tensor_validate_finite(y,"nn.tanhBackward output");fac_tensor_validate_finite(g,"nn.tanhBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(size_t i=0;i<o->values.size();i++)o->values[i]=fac_ml_checked_f64((long double)o->values[i]*(1.0L-(long double)y->values[i]*y->values[i]),"nn.tanhBackward");return fac_ml_guard_release(o); }
void *fac_nn_softmax_backward(void *yp,void *gp) { FacTensor*y=fac_tensor_checked(yp),*g=fac_tensor_checked(gp);fac_tensor_same(y,g,"nn.softmaxBackward");fac_tensor_validate_finite(y,"nn.softmaxBackward output");fac_tensor_validate_finite(g,"nn.softmaxBackward gradient");FacTensor *o=fac_ml_guard_new<FacTensor>(*g);for(int64_t r=0;r<y->rows;r++){long double dot=0;for(int64_t c=0;c<y->cols;c++){size_t i=(size_t)(r*y->cols+c);dot+=(long double)y->values[i]*g->values[i];}for(int64_t c=0;c<y->cols;c++){size_t i=(size_t)(r*y->cols+c);o->values[i]=fac_ml_checked_f64((long double)y->values[i]*((long double)g->values[i]-dot),"nn.softmaxBackward");}}return fac_ml_guard_release(o); }
void *fac_nn_dense_input_grad(void *gp,void *wp) { FacTensor*g=fac_tensor_checked(gp),*w=fac_tensor_checked(wp);if(g->cols!=w->cols)do_throw("nn.denseInputGrad: gradient/output dimension mismatch",18);fac_tensor_validate_finite(g,"nn.denseInputGrad");fac_tensor_validate_finite(w,"nn.denseInputGrad");FacTensor *o=fac_ml_guard_new<FacTensor>(g->rows,w->rows);for(int64_t n=0;n<g->rows;n++)for(int64_t i=0;i<w->rows;i++){long double sum=0;for(int64_t j=0;j<w->cols;j++)sum+=(long double)g->values[(size_t)(n*g->cols+j)]*w->values[(size_t)(i*w->cols+j)];o->values[(size_t)(n*o->cols+i)]=fac_ml_checked_f64(sum,"nn.denseInputGrad");}return fac_ml_guard_release(o); }
void *fac_nn_dense_weight_grad(void *xp,void *gp) { FacTensor*x=fac_tensor_checked(xp),*g=fac_tensor_checked(gp);if(x->rows!=g->rows)do_throw("nn.denseWeightGrad: batch dimensions do not match",18);fac_tensor_validate_finite(x,"nn.denseWeightGrad");fac_tensor_validate_finite(g,"nn.denseWeightGrad");FacTensor *o=fac_ml_guard_new<FacTensor>(x->cols,g->cols);for(int64_t i=0;i<x->cols;i++)for(int64_t j=0;j<g->cols;j++){long double sum=0;for(int64_t n=0;n<x->rows;n++)sum+=(long double)x->values[(size_t)(n*x->cols+i)]*g->values[(size_t)(n*g->cols+j)];o->values[(size_t)(i*o->cols+j)]=fac_ml_checked_f64(sum,"nn.denseWeightGrad");}return fac_ml_guard_release(o); }
void *fac_nn_dense_bias_grad(void *gp) { FacTensor*g=fac_tensor_checked(gp);fac_tensor_validate_finite(g,"nn.denseBiasGrad");FacTensor *o=fac_ml_guard_new<FacTensor>(1,g->cols);for(int64_t j=0;j<g->cols;j++){long double sum=0;for(int64_t n=0;n<g->rows;n++)sum+=(long double)g->values[(size_t)(n*g->cols+j)];o->values[(size_t)j]=fac_ml_checked_f64(sum,"nn.denseBiasGrad");}return fac_ml_guard_release(o); }
void *fac_nn_mse_grad(void *yp,void *pp) { FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);FacTensor *o=fac_ml_guard_new<FacTensor>(y->rows,y->cols);long double scale=2.0L/(long double)y->values.size();for(size_t i=0;i<o->values.size();i++)o->values[i]=fac_ml_checked_f64(((long double)p->values[i]-y->values[i])*scale,"nn.mseGrad");return fac_ml_guard_release(o); }
void *fac_nn_cross_entropy_grad(void *yp,void *pp) { FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);fac_nn_validate_categorical_probabilities(y,p,"nn.crossEntropyGrad");FacTensor *o=fac_ml_guard_new<FacTensor>(y->rows,y->cols);for(size_t i=0;i<o->values.size();i++){double q=std::max(1e-12,std::min(1.0,p->values[i]));o->values[i]=fac_ml_checked_f64(-(long double)y->values[i]/q/(long double)y->rows,"nn.crossEntropyGrad");}return fac_ml_guard_release(o); }
void *fac_nn_binary_cross_entropy_grad(void *yp,void *pp) { FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);fac_nn_validate_binary_probabilities(y,p,"nn.binaryCrossEntropyGrad");FacTensor *o=fac_ml_guard_new<FacTensor>(y->rows,y->cols);long double scale=1.0L/(long double)y->values.size();for(size_t i=0;i<o->values.size();i++){long double q=std::max(1e-12L,std::min(1.0L-1e-12L,(long double)p->values[i]));o->values[i]=fac_ml_checked_f64((q-y->values[i])/(q*(1.0L-q))*scale,"nn.binaryCrossEntropyGrad");}return fac_ml_guard_release(o); }
double fac_nn_mse_loss(void *yp,void *pp) { return fac_metrics_mse(yp,pp); }
double fac_nn_cross_entropy(void *yp,void *pp) { FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);fac_nn_validate_categorical_probabilities(y,p,"nn.crossEntropy");long double s=0;for(size_t i=0;i<y->values.size();i++){double q=std::max(1e-12,std::min(1.0,p->values[i]));s-=(long double)y->values[i]*std::log(q);}return fac_ml_checked_f64(s/(long double)y->rows,"nn.crossEntropy"); }
double fac_nn_binary_cross_entropy(void *yp,void *pp) { FacTensor*y,*p;fac_metrics_pair(yp,pp,y,p);fac_nn_validate_binary_probabilities(y,p,"nn.binaryCrossEntropy");long double s=0;for(size_t i=0;i<y->values.size();i++){long double q=std::max(1e-12L,std::min(1.0L-1e-12L,(long double)p->values[i]));s-=(long double)y->values[i]*std::log(q)+(1.0L-(long double)y->values[i])*std::log(1.0L-q);}return fac_ml_checked_f64(s/(long double)y->values.size(),"nn.binaryCrossEntropy"); }

// optim -- updates are transactional: either every parameter/state value is valid,
// or neither the parameter tensor nor optimizer state is modified.
void fac_optim_sgd_step(void *pp,void *gp,double lr) {
  FacTensor*p,*g; fac_stats_pair(pp,gp,p,g);
  if(!(lr>0.0&&std::isfinite(lr)))do_throw("optim.sgdStep: learning rate must be positive",18);
  fac_tensor_validate_finite(p,"optim.sgdStep params"); fac_tensor_validate_finite(g,"optim.sgdStep gradients");
  FacMLVectorWork *work=fac_ml_guard_new<FacMLVectorWork>(); work->a.resize(p->values.size());
  for(size_t i=0;i<p->values.size();i++) work->a[i]=fac_ml_checked_f64((long double)p->values[i]-(long double)lr*(long double)g->values[i],"optim.sgdStep");
  p->values.swap(work->a); fac_ml_guard_discard(work);
}
void *fac_optim_momentum_create(int32_t r,int32_t c) { fac_tensor_dims(r,c);return fac_ml_owned_new<FacMomentumState>(r,c); }
void fac_optim_momentum_step(void *sp,void *pp,void *gp,double lr,double momentum) {
  if(!sp)do_throw("optim.momentumStep: null state",6);
  FacMomentumState*s=(FacMomentumState*)sp; FacTensor*p,*g; fac_stats_pair(pp,gp,p,g);
  fac_tensor_validate_shape(&s->velocity,"optim.momentumStep state");
  if(s->velocity.rows!=p->rows||s->velocity.cols!=p->cols)do_throw("optim.momentumStep: state shape mismatch",18);
  if(!(lr>0.0&&std::isfinite(lr))||!(momentum>=0.0&&momentum<1.0&&std::isfinite(momentum)))do_throw("optim.momentumStep: invalid learning rate or momentum",18);
  fac_tensor_validate_finite(p,"optim.momentumStep params"); fac_tensor_validate_finite(g,"optim.momentumStep gradients");
  FacMLVectorWork *work=fac_ml_guard_new<FacMLVectorWork>(); work->a.resize(s->velocity.values.size());work->b.resize(p->values.size());
  for(size_t i=0;i<p->values.size();i++) {
    long double v=(long double)momentum*(long double)s->velocity.values[i]+(long double)g->values[i];
    work->a[i]=fac_ml_checked_f64(v,"optim.momentumStep state");
    work->b[i]=fac_ml_checked_f64((long double)p->values[i]-(long double)lr*v,"optim.momentumStep");
  }
  s->velocity.values.swap(work->a); p->values.swap(work->b); fac_ml_guard_discard(work);
}
void fac_optim_momentum_free(void *p) { delete (FacMomentumState*)p; }
void *fac_optim_rmsprop_create(int32_t r,int32_t c) { fac_tensor_dims(r,c);return fac_ml_owned_new<FacRMSPropState>(r,c); }
void fac_optim_rmsprop_step(void *sp,void *pp,void *gp,double lr,double decay,double epsilon) {
  if(!sp)do_throw("optim.rmspropStep: null state",6);
  FacRMSPropState*s=(FacRMSPropState*)sp; FacTensor*p,*g; fac_stats_pair(pp,gp,p,g);
  fac_tensor_validate_shape(&s->squareAverage,"optim.rmspropStep state");
  if(s->squareAverage.rows!=p->rows||s->squareAverage.cols!=p->cols)do_throw("optim.rmspropStep: state shape mismatch",18);
  if(!(lr>0.0&&std::isfinite(lr))||!(decay>=0.0&&decay<1.0&&std::isfinite(decay))||!(epsilon>0.0&&std::isfinite(epsilon)))do_throw("optim.rmspropStep: invalid hyperparameters",18);
  fac_tensor_validate_finite(p,"optim.rmspropStep params"); fac_tensor_validate_finite(g,"optim.rmspropStep gradients");
  FacMLVectorWork *work=fac_ml_guard_new<FacMLVectorWork>(); work->a.resize(s->squareAverage.values.size());work->b.resize(p->values.size());
  for(size_t i=0;i<p->values.size();i++) {
    long double x=g->values[i];
    long double avg=(long double)decay*(long double)s->squareAverage.values[i]+(1.0L-(long double)decay)*x*x;
    work->a[i]=fac_ml_checked_f64(avg,"optim.rmspropStep state");
    long double update=(long double)lr*x/(std::sqrt(avg)+(long double)epsilon);
    work->b[i]=fac_ml_checked_f64((long double)p->values[i]-update,"optim.rmspropStep");
  }
  s->squareAverage.values.swap(work->a); p->values.swap(work->b); fac_ml_guard_discard(work);
}
void fac_optim_rmsprop_free(void *p) { delete (FacRMSPropState*)p; }
void *fac_optim_clip_norm(void *p,double max_norm) {
  if(!(max_norm>0.0&&std::isfinite(max_norm)))do_throw("optim.clipNorm: max norm must be positive",18);
  FacTensor*o=fac_ml_guard_new<FacTensor>(*fac_tensor_checked(p));
  fac_tensor_validate_finite(o,"optim.clipNorm"); long double max_abs=0.0L;
  for(double x:o->values)max_abs=std::max(max_abs,std::fabs((long double)x));
  if(max_abs>0.0L){long double ss=0.0L;for(double x:o->values){long double q=(long double)x/max_abs;ss+=q*q;}
    long double scaled_norm=std::sqrt(ss);if(max_abs>(long double)max_norm/scaled_norm){long double scale=((long double)max_norm/max_abs)/scaled_norm;for(double&x:o->values)x=fac_ml_checked_f64((long double)x*scale,"optim.clipNorm");}}
  return fac_ml_guard_release(o);
}
void *fac_optim_clip_value(void *p,double lo,double hi) {
  if(!std::isfinite(lo)||!std::isfinite(hi)||lo>hi)do_throw("optim.clipValue: bounds must be finite and min <= max",18);
  FacTensor*o=fac_ml_guard_new<FacTensor>(*fac_tensor_checked(p));
  fac_tensor_validate_finite(o,"optim.clipValue");for(double&x:o->values)x=std::max(lo,std::min(hi,x));return fac_ml_guard_release(o);
}
void *fac_optim_adam_create(int32_t r,int32_t c) { fac_tensor_dims(r,c);return fac_ml_owned_new<FacAdamState>(r,c); }
void fac_optim_adam_step(void *sp,void *pp,void *gp,double lr) {
  if(!sp)do_throw("optim.adamStep: null optimizer state",6);
  FacAdamState*s=(FacAdamState*)sp; FacTensor*p,*g; fac_stats_pair(pp,gp,p,g);
  fac_tensor_validate_shape(&s->first,"optim.adamStep first-moment state");
  fac_tensor_validate_shape(&s->second,"optim.adamStep second-moment state");
  if(s->first.rows!=p->rows||s->first.cols!=p->cols||s->second.rows!=p->rows||s->second.cols!=p->cols)
    do_throw("optim.adamStep: state shape mismatch",18);
  if(!(lr>0.0&&std::isfinite(lr)))do_throw("optim.adamStep: learning rate must be positive",18);
  if(s->step==std::numeric_limits<uint64_t>::max())do_throw("optim.adamStep: step counter exhausted",8);
  fac_tensor_validate_finite(p,"optim.adamStep params"); fac_tensor_validate_finite(g,"optim.adamStep gradients");
  const long double b1=0.9L,b2=0.999L,eps=1.0e-8L;
  const uint64_t next_step=s->step+1;
  const long double c1=1.0L-std::pow(b1,(long double)next_step),c2=1.0L-std::pow(b2,(long double)next_step);
  FacMLVectorWork *work=fac_ml_guard_new<FacMLVectorWork>(); work->a.resize(s->first.values.size());work->b.resize(s->second.values.size());work->c.resize(p->values.size());
  for(size_t i=0;i<p->values.size();i++) {
    long double x=g->values[i];
    long double m=b1*(long double)s->first.values[i]+(1.0L-b1)*x;
    long double v=b2*(long double)s->second.values[i]+(1.0L-b2)*x*x;
    work->a[i]=fac_ml_checked_f64(m,"optim.adamStep first moment");
    work->b[i]=fac_ml_checked_f64(v,"optim.adamStep second moment");
    long double mh=m/c1,vh=v/c2;
    long double update=(long double)lr*mh/(std::sqrt(vh)+eps);
    work->c[i]=fac_ml_checked_f64((long double)p->values[i]-update,"optim.adamStep");
  }
  s->first.values.swap(work->a); s->second.values.swap(work->b); s->step=next_step; p->values.swap(work->c); fac_ml_guard_discard(work);
}
void fac_optim_adam_free(void *p) { delete (FacAdamState*)p; }


// dataframe -- named numeric columns over owned row-major storage.
static void fac_dataframe_names_into(FacStr *names, std::vector<std::string> &out) {
  if (!names) do_throw("dataframe: null column-name string", 6);
  const char *p=sd(names); size_t n=(size_t)sl(names), start=0;
  FacMLNameWork *work=fac_ml_guard_new<FacMLNameWork>();
  for (size_t i=0;i<=n;i++) if (i==n || p[i]=='|') {
    size_t a=start,b=i;
    while (a<b && std::isspace((unsigned char)p[a])) ++a;
    while (b>a && std::isspace((unsigned char)p[b-1])) --b;
    if (a==b) do_throw("dataframe: column names must not be empty",18);
    work->name.assign(p+a,b-a);
    if (work->seen.count(work->name)) do_throw("dataframe: duplicate column name '"+work->name+"'",18);
    if (work->out.size() >= (size_t)FAC_TENSOR_MAX_ELEMENTS)
      do_throw("dataframe: column count exceeds 16,777,216 limit",8);
    work->seen[work->name]=true; work->out.push_back(std::move(work->name)); start=i+1;
  }
  out=std::move(work->out);
  fac_ml_guard_discard(work);
}
static std::vector<std::string> fac_dataframe_names(FacStr *names) {
  auto *holder=fac_ml_guard_new<std::vector<std::string>>();
  fac_dataframe_names_into(names,*holder);
  std::vector<std::string> out=std::move(*holder);
  fac_ml_guard_discard(holder); return out;
}
static void fac_dataframe_validate_shape(const FacDataFrame *f) {
  if (!f || f->rows < 0 || f->cols <= 0 || f->cols > FAC_TENSOR_MAX_ELEMENTS)
    do_throw("dataframe: invalid internal dimensions",18);
  const uint64_t rows = (uint64_t)f->rows;
  const uint64_t cols = (uint64_t)f->cols;
  if (rows > (uint64_t)FAC_TENSOR_MAX_ELEMENTS / cols)
    do_throw("dataframe: element count exceeds 16,777,216 value limit",8);
  const size_t expected = (size_t)(rows * cols);
  if (f->names.size() != (size_t)f->cols || f->values.size() != expected)
    do_throw("dataframe: invalid internal shape",18);
}
static FacDataFrame *fac_dataframe_checked(void *p) {
  if (!p) do_throw("dataframe: null handle",6);
  auto *frame = (FacDataFrame*)p;
  fac_dataframe_validate_shape(frame);
  return frame;
}
static int32_t fac_dataframe_col(const FacDataFrame *f, const std::string &name) {
  for (int32_t c=0;c<f->cols;c++) if (f->names[(size_t)c]==name) return c;
  return -1;
}
static FacDataFrame *fac_dataframe_from_tensor_impl(FacTensor *t, const std::vector<std::string> &names) {
  if ((int64_t)names.size()!=t->cols) do_throw("dataframe.fromTensor: number of names must equal tensor columns",18);
  fac_tensor_validate_finite(t,"dataframe.fromTensor");
  FacDataFrame *f=fac_ml_guard_new<FacDataFrame>(); f->rows=t->rows; f->cols=t->cols; f->values=t->values; f->names=names; return fac_ml_guard_release(f);
}
static FacDataFrame *fac_dataframe_select_impl(const FacDataFrame *f, const std::vector<int32_t> &cols) {
  if (cols.empty()) do_throw("dataframe.select: at least one column is required",18);
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>(); o->rows=f->rows; o->cols=(int64_t)cols.size(); o->values.resize((size_t)(o->rows*o->cols));
  for (size_t j=0;j<cols.size();j++) { if(cols[j]<0||cols[j]>=f->cols) do_throw("dataframe.select: column index out of range",2); o->names.push_back(f->names[(size_t)cols[j]]); }
  for(int64_t r=0;r<o->rows;r++)for(size_t j=0;j<cols.size();j++)o->values[(size_t)(r*o->cols+(int64_t)j)]=f->at(r,cols[j]);
  return fac_ml_guard_release(o);
}
void *fac_dataframe_from_tensor(void *tp, FacStr *names) {
  FacMLDataFrameCsvWork *work=fac_ml_guard_new<FacMLDataFrameCsvWork>();
  fac_dataframe_names_into(names,work->names);
  FacDataFrame *out=fac_dataframe_from_tensor_impl(fac_tensor_checked(tp),work->names);
  fac_ml_guard_discard(work); return out;
}
static std::string fac_dataframe_csv_header(const std::vector<std::string> &names) {
  std::ostringstream out;
  for (size_t c=0;c<names.size();c++) {
    if(c) out << ',';
    out << '"';
    for(char ch:names[c]) { if(ch=='"') out << '"'; out << ch; }
    out << '"';
  }
  return out.str();
}
void *fac_dataframe_from_csv(FacStr *csv, FacStr *names) {
  if(!csv) do_throw("dataframe.fromCSV: null CSV text",6);
  FacMLDataFrameCsvWork *work=fac_ml_guard_new<FacMLDataFrameCsvWork>();
  fac_dataframe_names_into(names,work->names);
  work->text.assign(sd(csv),(size_t)sl(csv));
  work->header=fac_dataframe_csv_header(work->names);
  if(work->text==work->header) {
    FacDataFrame *empty=fac_ml_guard_new<FacDataFrame>();
    empty->rows=0; empty->cols=(int64_t)work->names.size(); empty->names=work->names;
    fac_ml_guard_release(empty); fac_ml_guard_discard(work); return empty;
  }
  if(work->text.size()>work->header.size() && work->text.compare(0,work->header.size(),work->header)==0 && work->text[work->header.size()]=='\n') {
    work->body=work->text.substr(work->header.size()+1);
    if(work->body.empty()) {
      FacDataFrame *empty=fac_ml_guard_new<FacDataFrame>();
      empty->rows=0; empty->cols=(int64_t)work->names.size(); empty->names=work->names;
      fac_ml_guard_release(empty); fac_ml_guard_discard(work); return empty;
    }
    FacStr *body_str=mk(work->body.data(),(int64_t)work->body.size());
    fac_tmp_push(body_str,1);
    FacTensor *tensor=fac_tensor_csv_parse(body_str);
    fac_tmp_push_drop(tensor,reinterpret_cast<void *>(&fac_ml_guard_drop<FacTensor>));
    FacDataFrame *out=fac_dataframe_from_tensor_impl(tensor,work->names);
    fac_tmp_pop(tensor); delete tensor;
    fac_tmp_pop(body_str); fac_str_free(body_str);
    fac_ml_guard_discard(work); return out;
  }
  FacTensor *tensor=fac_tensor_csv_parse(csv);
  fac_tmp_push_drop(tensor,reinterpret_cast<void *>(&fac_ml_guard_drop<FacTensor>));
  FacDataFrame *out=fac_dataframe_from_tensor_impl(tensor,work->names);
  fac_tmp_pop(tensor); delete tensor;
  fac_ml_guard_discard(work); return out;
}
void fac_dataframe_free(void *p) { delete (FacDataFrame*)p; }
int64_t fac_dataframe_rows(void *p) { return fac_dataframe_checked(p)->rows; }
int64_t fac_dataframe_cols(void *p) { return fac_dataframe_checked(p)->cols; }
int32_t fac_dataframe_column_index(void *p, FacStr *name) {
  if(!name)do_throw("dataframe.columnIndex: null name",6); FacDataFrame*f=fac_dataframe_checked(p);return fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));
}
double fac_dataframe_get(void *p,int32_t row,FacStr *name) {
  if(!name)do_throw("dataframe.get: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);
  if(row<0||row>=f->rows)do_throw("dataframe.get: row out of range",2);
  int32_t c=fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));if(c<0)do_throw("dataframe.get: unknown column",18);return f->at(row,c);
}
void *fac_dataframe_column(void *p,FacStr *name) {
  if(!name)do_throw("dataframe.column: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);
  int32_t c=fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));if(c<0)do_throw("dataframe.column: unknown column",18);
  FacTensor*o=fac_ml_owned_new<FacTensor>((int32_t)f->rows,1);for(int64_t r=0;r<f->rows;r++)o->values[(size_t)r]=f->at(r,c);return o;
}
void *fac_dataframe_select(void *p,FacStr *names) {
  FacDataFrame*f=fac_dataframe_checked(p);FacMLDataFrameWork *work=fac_ml_guard_new<FacMLDataFrameWork>();
  fac_dataframe_names_into(names,work->wanted);
  for(const std::string&n:work->wanted){int32_t c=fac_dataframe_col(f,n);if(c<0)do_throw("dataframe.select: unknown column '"+n+"'",18);work->cols.push_back(c);}
  void *out=fac_dataframe_select_impl(f,work->cols);
  fac_ml_guard_discard(work); return out;
}
void *fac_dataframe_drop(void *p,FacStr *name) {
  if(!name)do_throw("dataframe.drop: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);int32_t drop=fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));
  if(drop<0)do_throw("dataframe.drop: unknown column",18);if(f->cols==1)do_throw("dataframe.drop: cannot remove the last column",18);
  std::vector<int32_t> cols;for(int32_t c=0;c<f->cols;c++)if(c!=drop)cols.push_back(c);return fac_dataframe_select_impl(f,cols);
}
void *fac_dataframe_filter(void *p,FacStr *name,int32_t op,double value) {
  if(!name)do_throw("dataframe.filter: null column name",6);if(op<0||op>5||!std::isfinite(value))do_throw("dataframe.filter: invalid comparison or non-finite value",18);
  FacDataFrame*f=fac_dataframe_checked(p);int32_t c=fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));if(c<0)do_throw("dataframe.filter: unknown column",18);
  auto *rows=fac_ml_guard_new<std::vector<int64_t>>();for(int64_t r=0;r<f->rows;r++){double x=f->at(r,c);bool ok=op==0?x==value:op==1?x!=value:op==2?x<value:op==3?x<=value:op==4?x>value:x>=value;if(ok)rows->push_back(r);}
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>();o->rows=(int64_t)rows->size();o->cols=f->cols;o->names=f->names;o->values.reserve(rows->size()*(size_t)o->cols);
  for(int64_t r:*rows)for(int64_t j=0;j<f->cols;j++)o->values.push_back(f->at(r,j));
  fac_ml_guard_release(o);fac_ml_guard_discard(rows);return o;
}
void *fac_dataframe_sort(void *p,FacStr *name,int32_t ascending) {
  if(!name)do_throw("dataframe.sort: null column name",6);if(ascending!=0&&ascending!=1)do_throw("dataframe.sort: ascending must be 0 or 1",18);FacDataFrame*f=fac_dataframe_checked(p);int32_t c=fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));if(c<0)do_throw("dataframe.sort: unknown column",18);
  auto *order=fac_ml_guard_new<std::vector<int64_t>>((size_t)f->rows);std::iota(order->begin(),order->end(),0);
  std::stable_sort(order->begin(),order->end(),[&](int64_t a,int64_t b){double x=f->at(a,c),y=f->at(b,c);return ascending?x<y:x>y;});
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>();o->rows=f->rows;o->cols=f->cols;o->names=f->names;o->values.reserve(f->values.size());for(int64_t r:*order)for(int64_t j=0;j<f->cols;j++)o->values.push_back(f->at(r,j));
  fac_ml_guard_release(o);fac_ml_guard_discard(order);return o;
}
static void *fac_dataframe_slice_rows(void *p,int32_t count,bool tail) {
  FacDataFrame*f=fac_dataframe_checked(p);if(count<0)do_throw("dataframe.head/tail: count must not be negative",18);int64_t n=std::min<int64_t>(count,f->rows),start=tail?f->rows-n:0;
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>();o->rows=n;o->cols=f->cols;o->names=f->names;o->values.reserve((size_t)(n*o->cols));for(int64_t r=start;r<start+n;r++)for(int64_t c=0;c<f->cols;c++)o->values.push_back(f->at(r,c));return fac_ml_guard_release(o);
}
void *fac_dataframe_head(void *p,int32_t n) { return fac_dataframe_slice_rows(p,n,false); }
void *fac_dataframe_tail(void *p,int32_t n) { return fac_dataframe_slice_rows(p,n,true); }
double fac_dataframe_reduce(void *p,FacStr *name,int32_t op) {
  if(!name)do_throw("dataframe.reduce: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);int32_t c=fac_dataframe_col(f,std::string(sd(name),(size_t)sl(name)));if(c<0)do_throw("dataframe.reduce: unknown column",18);if(f->rows==0)do_throw("dataframe.reduce: empty column",18);
  if(op==0||op==3){long double sum=0;for(int64_t r=0;r<f->rows;r++)sum+=f->at(r,c);double mean=op==0?(double)(sum/f->rows):0.0;if(op==0)return mean;long double sq=0;for(int64_t r=0;r<f->rows;r++){long double d=f->at(r,c)-mean;sq+=d*d;}return std::sqrt((double)(sq/f->rows));}
  double v=f->at(0,c);for(int64_t r=1;r<f->rows;r++)v=op==1?std::min(v,f->at(r,c)):std::max(v,f->at(r,c));return v;
}
double fac_dataframe_mean(void*p,FacStr*n){return fac_dataframe_reduce(p,n,0);}double fac_dataframe_min(void*p,FacStr*n){return fac_dataframe_reduce(p,n,1);}double fac_dataframe_max(void*p,FacStr*n){return fac_dataframe_reduce(p,n,2);}double fac_dataframe_stddev(void*p,FacStr*n){return fac_dataframe_reduce(p,n,3);}
void *fac_dataframe_to_tensor(void *p) { FacDataFrame*f=fac_dataframe_checked(p);if(f->rows<=0)do_throw("dataframe.toTensor: empty dataframe cannot become a tensor",18);FacTensor *o=fac_ml_guard_new<FacTensor>((int32_t)f->rows,(int32_t)f->cols);o->values=f->values;return fac_ml_guard_release(o); }
FacStr *fac_dataframe_to_csv(void *p) {
  FacDataFrame*f=fac_dataframe_checked(p);std::ostringstream out;out<<std::setprecision(17);
  out << fac_dataframe_csv_header(f->names);
  for(int64_t r=0;r<f->rows;r++){out<<'\n';for(int64_t c=0;c<f->cols;c++){if(c)out<<',';out<<f->at(r,c);}}
  return mks(out.str());
}
void *fac_dataframe_concat_rows(void *ap,void *bp) {
  FacDataFrame*a=fac_dataframe_checked(ap),*b=fac_dataframe_checked(bp);if(a->cols!=b->cols||a->names!=b->names)do_throw("dataframe.concatRows: columns and names must match",18);
  const int64_t max_rows=FAC_TENSOR_MAX_ELEMENTS/a->cols;
  if(b->rows>max_rows||a->rows>max_rows-b->rows)do_throw("dataframe.concatRows: result exceeds the 16,777,216 element limit",8);
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>();o->rows=a->rows+b->rows;o->cols=a->cols;o->names=a->names;o->values.reserve(a->values.size()+b->values.size());o->values.insert(o->values.end(),a->values.begin(),a->values.end());o->values.insert(o->values.end(),b->values.begin(),b->values.end());return fac_ml_guard_release(o);
}

// V101 DataFrame extensions: immutable owned-copy transformations and grouped numeric reductions.
void *fac_dataframe_with_column(void *p,FacStr *name,void *tp) {
  if(!name)do_throw("dataframe.withColumn: null column name",6);
  FacDataFrame*f=fac_dataframe_checked(p);FacTensor*t=fac_tensor_checked(tp);FacMLDataFrameWork *work=fac_ml_guard_new<FacMLDataFrameWork>();
  work->name1.assign(sd(name),(size_t)sl(name));
  if(work->name1.empty()||work->name1.find('|')!=std::string::npos)do_throw("dataframe.withColumn: name must be non-empty and cannot contain |",18);
  if(fac_dataframe_col(f,work->name1)>=0)do_throw("dataframe.withColumn: column already exists",18);
  if(t->rows!=f->rows||t->cols!=1)do_throw("dataframe.withColumn: values must have shape [rows,1]",18);
  fac_tensor_validate_finite(t,"dataframe.withColumn");
  if(f->values.size()>(size_t)FAC_TENSOR_MAX_ELEMENTS-(size_t)f->rows)do_throw("dataframe.withColumn: result exceeds tensor element limit",8);
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>();o->rows=f->rows;o->cols=f->cols+1;o->names=f->names;o->names.push_back(work->name1);
  o->values.resize((size_t)o->rows*(size_t)o->cols);
  for(int64_t r=0;r<o->rows;r++){for(int64_t c=0;c<f->cols;c++)o->values[(size_t)r*(size_t)o->cols+(size_t)c]=f->at(r,c);o->values[(size_t)r*(size_t)o->cols+(size_t)f->cols]=t->values[(size_t)r];}
  fac_ml_guard_release(o);fac_ml_guard_discard(work);return o;
}
void *fac_dataframe_rename_column(void *p,FacStr *old_name,FacStr *new_name) {
  if(!old_name||!new_name)do_throw("dataframe.renameColumn: null name",6);
  FacDataFrame*f=fac_dataframe_checked(p);FacMLDataFrameWork *work=fac_ml_guard_new<FacMLDataFrameWork>();work->name1.assign(sd(old_name),(size_t)sl(old_name));work->name2.assign(sd(new_name),(size_t)sl(new_name));
  if(work->name2.empty()||work->name2.find('|')!=std::string::npos)do_throw("dataframe.renameColumn: new name must be non-empty and cannot contain |",18);
  int32_t c=fac_dataframe_col(f,work->name1);if(c<0)do_throw("dataframe.renameColumn: unknown column",18);
  int32_t existing=fac_dataframe_col(f,work->name2);if(existing>=0&&existing!=c)do_throw("dataframe.renameColumn: new name already exists",18);
  FacDataFrame *o=fac_ml_guard_new<FacDataFrame>(*f);o->names[(size_t)c]=work->name2;fac_ml_guard_release(o);fac_ml_guard_discard(work);return o;
}
static double fac_dataframe_quantile_impl(FacDataFrame*f,int32_t c,double q) {
  if(f->rows==0)do_throw("dataframe.quantile: empty column",18);
  if(!std::isfinite(q)||q<0.0||q>1.0)do_throw("dataframe.quantile: q must be in [0,1]",18);
  auto *v=fac_ml_guard_new<std::vector<double>>();v->reserve((size_t)f->rows);for(int64_t r=0;r<f->rows;r++)v->push_back(f->at(r,c));std::sort(v->begin(),v->end());
  double pos=q*(double)(v->size()-1);size_t lo=(size_t)std::floor(pos),hi=(size_t)std::ceil(pos);double frac=pos-(double)lo;
  long double result=(long double)(*v)[lo]*(1.0L-(long double)frac)+(long double)(*v)[hi]*(long double)frac;
  double out=(double)result;if(!std::isfinite(out))do_throw("dataframe.quantile: result is outside finite float64 range",18);fac_ml_guard_discard(v);return out;
}
double fac_dataframe_median(void*p,FacStr*n){if(!n)do_throw("dataframe.median: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);int32_t c=fac_dataframe_col(f,std::string(sd(n),(size_t)sl(n)));if(c<0)do_throw("dataframe.median: unknown column",18);return fac_dataframe_quantile_impl(f,c,0.5);}
double fac_dataframe_variance(void*p,FacStr*n){if(!n)do_throw("dataframe.variance: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);int32_t c=fac_dataframe_col(f,std::string(sd(n),(size_t)sl(n)));if(c<0)do_throw("dataframe.variance: unknown column",18);if(f->rows==0)do_throw("dataframe.variance: empty column",18);long double mean=0.0L,m2=0.0L;int64_t k=0;for(int64_t r=0;r<f->rows;r++){long double x=f->at(r,c);++k;long double d=x-mean;mean+=d/(long double)k;m2+=d*(x-mean);}double result=(double)(m2/(long double)f->rows);if(!std::isfinite(result))do_throw("dataframe.variance: result is outside finite float64 range",18);return result;}
double fac_dataframe_quantile(void*p,FacStr*n,double q){if(!n)do_throw("dataframe.quantile: null column name",6);FacDataFrame*f=fac_dataframe_checked(p);int32_t c=fac_dataframe_col(f,std::string(sd(n),(size_t)sl(n)));if(c<0)do_throw("dataframe.quantile: unknown column",18);return fac_dataframe_quantile_impl(f,c,q);}
static void *fac_dataframe_group_reduce(void*p,FacStr*key_name,FacStr*value_name,int op) {
  if(!key_name||((op>=0)&&!value_name))do_throw("dataframe.group: null column name",6);
  FacDataFrame*f=fac_dataframe_checked(p);
  try {
    int32_t kc=fac_dataframe_col(f,std::string(sd(key_name),(size_t)sl(key_name)));
    if(kc<0)do_throw("dataframe.group: unknown key column",18);
    FacMLDataFrameGroupWork *work=fac_ml_guard_new<FacMLDataFrameGroupWork>();
    int32_t vc=-1;
    if(op>=0){vc=fac_dataframe_col(f,std::string(sd(value_name),(size_t)sl(value_name)));if(vc<0)do_throw("dataframe.group: unknown value column",18);if(vc==kc)do_throw("dataframe.group: key and value columns must differ",18);const char*prefix=op==0?"mean_":op==1?"sum_":op==2?"min_":"max_";work->result_name=prefix+std::string(sd(value_name),(size_t)sl(value_name));}
    else work->result_name=(f->names[(size_t)kc]=="count"?"row_count":"count");
    if(work->result_name==f->names[(size_t)kc])do_throw("dataframe.group: generated result name conflicts with key column",18);
    // The returned frame has two columns, so cap distinct keys at half of the
    // shared Tensor/DataFrame element budget before growing the map.
    constexpr size_t max_groups=(size_t)FAC_TENSOR_MAX_ELEMENTS/2u;
    for(int64_t r=0;r<f->rows;r++) {
      const double key=f->at(r,kc);
      const double value=op>=0?f->at(r,vc):0.0;
      auto it=work->groups.find(key);
      if(it==work->groups.end()) {
        if(work->groups.size()>=max_groups)
          do_throw("dataframe.group: result exceeds 16,777,216 value limit",8);
        FacMLGroupAggregate initial;
        initial.count=1;
        initial.minimum=value;
        initial.maximum=value;
        initial.sum=(long double)value;
        it=work->groups.emplace(key,initial).first;
      } else {
        FacMLGroupAggregate &aggregate=it->second;
        if(aggregate.count==UINT64_MAX)
          do_throw("dataframe.group: group row count overflow",8);
        ++aggregate.count;
        if(op>=0) {
          aggregate.sum+=(long double)value;
          if(!std::isfinite(aggregate.sum))
            do_throw("dataframe.group: aggregate is outside finite range",18);
          aggregate.minimum=std::min(aggregate.minimum,value);
          aggregate.maximum=std::max(aggregate.maximum,value);
        }
      }
    }
    if(work->groups.empty())do_throw("dataframe.group: cannot group an empty dataframe",18);
    FacDataFrame *o=fac_ml_guard_new<FacDataFrame>();
    o->rows=(int64_t)work->groups.size();o->cols=2;o->names={f->names[(size_t)kc],work->result_name};o->values.reserve(work->groups.size()*2u);
    for(const auto&entry:work->groups) {
      const FacMLGroupAggregate &aggregate=entry.second;
      double value=0.0;
      if(op==0)value=fac_ml_checked_f64(aggregate.sum/(long double)aggregate.count,"dataframe.groupMean");
      else if(op==1)value=fac_ml_checked_f64(aggregate.sum,"dataframe.groupSum");
      else if(op==2)value=aggregate.minimum;
      else if(op==3)value=aggregate.maximum;
      else value=(double)aggregate.count;
      if(!std::isfinite(value))do_throw("dataframe.group: aggregate is outside finite float64 range",18);
      o->values.push_back(entry.first);o->values.push_back(value);
    }
    fac_dataframe_validate_shape(o);
    fac_ml_guard_release(o);fac_ml_guard_discard(work);return o;
  } catch(const std::bad_alloc &) {
    do_throw("dataframe.group: out of memory",5);
  } catch(const std::length_error &) {
    do_throw("dataframe.group: requested group table is too large",14);
  }
}
void *fac_dataframe_group_mean(void*p,FacStr*k,FacStr*v){return fac_dataframe_group_reduce(p,k,v,0);}
void *fac_dataframe_group_sum(void*p,FacStr*k,FacStr*v){return fac_dataframe_group_reduce(p,k,v,1);}
void *fac_dataframe_group_min(void*p,FacStr*k,FacStr*v){return fac_dataframe_group_reduce(p,k,v,2);}
void *fac_dataframe_group_max(void*p,FacStr*k,FacStr*v){return fac_dataframe_group_reduce(p,k,v,3);}
void *fac_dataframe_group_count(void*p,FacStr*k){return fac_dataframe_group_reduce(p,k,nullptr,-1);}

// V100 Tensor reverse-mode autograd. A tape stores values and gradients as float64 tensors.
// Tapes are deliberately thread-confined: FAC longjmp-based errors make a lock
// held across arbitrary tape operations unsafe, so reject cross-thread access
// before touching mutable node storage. Use one tape per worker for parallel work.
static void fac_tautograd_require_owner(const FacTensorGradTape *t) {
  if (t->owner_token != fac_autograd_current_thread_token())
    do_throw("autograd.tensor: tape belongs to another thread", 16);
}
static FacTensorGradTape *fac_tautograd_checked(void*p){
  if(!p)do_throw("autograd tensor: null tape",6);
  FacTensorGradTape *t=(FacTensorGradTape*)p;
  fac_tautograd_require_owner(t);
  return t;
}
static FacTensorGradNode &fac_tautograd_node(FacTensorGradTape*t,int32_t id){if(id<0||(size_t)id>=t->nodes.size())do_throw("autograd tensor: node id out of range",2);FacTensorGradNode&node=t->nodes[(size_t)id];fac_tensor_validate_shape(&node.value,"autograd.tensor node");if(node.grad.size()!=node.value.values.size())do_throw("autograd.tensor: gradient storage does not match value shape",18);return node;}
static void fac_tautograd_finite(const std::vector<double>&v,const char*op){for(double x:v)if(!std::isfinite(x))do_throw(std::string(op)+": non-finite tensor value",18);}
static int32_t fac_tautograd_push(FacTensorGradTape *t, const FacTensor &value, int op,
                                   int32_t a = -1, int32_t b = -1, double scalar = 0.0) {
  fac_tautograd_finite(value.values, "autograd.tensor");
  if (t->nodes.size() >= 65536u)
    do_throw("autograd.tensor: node limit of 65,536 reached", 8);
  const uint64_t n = (uint64_t)value.values.size();
  if (n > FAC_TENSOR_MAX_ELEMENTS || t->stored_elements > FAC_TENSOR_MAX_ELEMENTS - n)
    do_throw("autograd.tensor: tape storage exceeds 16,777,216 values", 8);

  FacTensorGradNode *node = fac_ml_guard_new<FacTensorGradNode>();
  fac_ml_allocation_boundary([&] {
    node->value = value;
    node->grad.assign(value.values.size(), 0.0);
    node->op = op; node->a = a; node->b = b; node->scalar = scalar;
    t->nodes.push_back(std::move(*node));
  }, "autograd.tensor");
  const int32_t id = (int32_t)t->nodes.size() - 1;
  t->stored_elements += n;
  fac_ml_guard_discard(node);
  return id;
}
void *fac_autograd_tensor_create(){return new FacTensorGradTape;}
void fac_autograd_tensor_free(void*p){
  if(!p)return;
  FacTensorGradTape *t=(FacTensorGradTape*)p;
  fac_tautograd_require_owner(t);
  delete t;
}
int32_t fac_autograd_tensor_variable(void*p,void*tp){FacTensorGradTape*t=fac_tautograd_checked(p);FacTensor*x=fac_tensor_checked(tp);return fac_tautograd_push(t,*x,FAC_TGRAD_LEAF);}
static int32_t fac_autograd_tensor_binary(void*p,int32_t ai,int32_t bi,int op){FacTensorGradTape*t=fac_tautograd_checked(p);FacTensorGradNode&a=fac_tautograd_node(t,ai);FacTensorGradNode&b=fac_tautograd_node(t,bi);FacTensor *out=nullptr;
  if(op==FAC_TGRAD_MATMUL){if(a.value.cols!=b.value.rows)do_throw("autograd.tensor.matmul: inner dimensions do not match",18);out=fac_ml_guard_new<FacTensor>(a.value.rows,b.value.cols);for(int64_t i=0;i<a.value.rows;i++)for(int64_t k=0;k<a.value.cols;k++){double x=a.value.values[(size_t)i*(size_t)a.value.cols+(size_t)k];for(int64_t j=0;j<b.value.cols;j++){size_t q=(size_t)i*(size_t)out->cols+(size_t)j;out->values[q]=fac_ml_checked_f64((long double)out->values[q]+(long double)x*b.value.values[(size_t)k*(size_t)b.value.cols+(size_t)j],"autograd.tensor.matmul");}}}
  else {if(a.value.rows!=b.value.rows||a.value.cols!=b.value.cols)do_throw("autograd.tensor: operand shapes must match",18);out=fac_ml_guard_new<FacTensor>(a.value.rows,a.value.cols);for(size_t i=0;i<out->values.size();i++){double x=a.value.values[i],y=b.value.values[i];long double z=op==FAC_TGRAD_ADD?(long double)x+y:op==FAC_TGRAD_SUB?(long double)x-y:(long double)x*y;out->values[i]=fac_ml_checked_f64(z,"autograd.tensor operation");}}
  int32_t id=fac_tautograd_push(t,*out,op,ai,bi);fac_ml_guard_discard(out);return id;
}
int32_t fac_autograd_tensor_add(void*p,int32_t a,int32_t b){return fac_autograd_tensor_binary(p,a,b,FAC_TGRAD_ADD);}
int32_t fac_autograd_tensor_sub(void*p,int32_t a,int32_t b){return fac_autograd_tensor_binary(p,a,b,FAC_TGRAD_SUB);}
int32_t fac_autograd_tensor_hadamard(void*p,int32_t a,int32_t b){return fac_autograd_tensor_binary(p,a,b,FAC_TGRAD_HADAMARD);}
int32_t fac_autograd_tensor_matmul(void*p,int32_t a,int32_t b){return fac_autograd_tensor_binary(p,a,b,FAC_TGRAD_MATMUL);}
int32_t fac_autograd_tensor_scale(void*p,int32_t a,double scalar){FacTensorGradTape*t=fac_tautograd_checked(p);FacTensorGradNode&n=fac_tautograd_node(t,a);if(!std::isfinite(scalar))do_throw("autograd.tensor.scale: scalar must be finite",18);FacTensor *out=fac_ml_guard_new<FacTensor>(n.value);for(double&x:out->values)x=fac_ml_checked_f64((long double)x*scalar,"autograd.tensor.scale");int32_t id=fac_tautograd_push(t,*out,FAC_TGRAD_SCALE,a,-1,scalar);fac_ml_guard_discard(out);return id;}
static int32_t fac_autograd_tensor_reduce(void*p,int32_t a,int op){FacTensorGradTape*t=fac_tautograd_checked(p);FacTensorGradNode&n=fac_tautograd_node(t,a);long double sum=0;for(double x:n.value.values)sum+=x;FacTensor *out=fac_ml_guard_new<FacTensor>(1,1);out->values[0]=fac_ml_checked_f64(op==FAC_TGRAD_MEAN?(sum/(long double)n.value.values.size()):sum,"autograd.tensor.reduce");int32_t id=fac_tautograd_push(t,*out,op,a);fac_ml_guard_discard(out);return id;}
int32_t fac_autograd_tensor_sum(void*p,int32_t a){return fac_autograd_tensor_reduce(p,a,FAC_TGRAD_SUM);}
int32_t fac_autograd_tensor_mean(void*p,int32_t a){return fac_autograd_tensor_reduce(p,a,FAC_TGRAD_MEAN);}
static int32_t fac_autograd_tensor_activation(void*p,int32_t a,int op){FacTensorGradTape*t=fac_tautograd_checked(p);FacTensorGradNode&n=fac_tautograd_node(t,a);FacTensor *out=fac_ml_guard_new<FacTensor>(n.value);for(double&x:out->values){if(op==FAC_TGRAD_RELU)x=std::max(0.0,x);else if(op==FAC_TGRAD_SIGMOID)x=fac_tensor_sigmoid(x);else x=std::tanh(x);}int32_t id=fac_tautograd_push(t,*out,op,a);fac_ml_guard_discard(out);return id;}
int32_t fac_autograd_tensor_relu(void*p,int32_t a){return fac_autograd_tensor_activation(p,a,FAC_TGRAD_RELU);}
int32_t fac_autograd_tensor_sigmoid(void*p,int32_t a){return fac_autograd_tensor_activation(p,a,FAC_TGRAD_SIGMOID);}
int32_t fac_autograd_tensor_tanh(void*p,int32_t a){return fac_autograd_tensor_activation(p,a,FAC_TGRAD_TANH);}
void *fac_autograd_tensor_value(void*p,int32_t id){FacTensorGradTape*t=fac_tautograd_checked(p);return fac_ml_owned_new<FacTensor>(fac_tautograd_node(t,id).value);}
void *fac_autograd_tensor_grad(void*p,int32_t id){FacTensorGradTape*t=fac_tautograd_checked(p);FacTensorGradNode&n=fac_tautograd_node(t,id);FacTensor*out=fac_ml_owned_new<FacTensor>(n.value.rows,n.value.cols);out->values=n.grad;return out;}
void fac_autograd_tensor_zero_grad(void*p){FacTensorGradTape*t=fac_tautograd_checked(p);for(auto&n:t->nodes)std::fill(n.grad.begin(),n.grad.end(),0.0);}
void fac_autograd_tensor_backward_seed(void*p,int32_t output,double seed){
  FacTensorGradTape*t=fac_tautograd_checked(p);if(!std::isfinite(seed))do_throw("autograd.tensor.backward: seed must be finite",18);FacTensorGradNode&out=fac_tautograd_node(t,output);if(out.value.values.size()!=1)do_throw("autograd.tensor.backward: output must contain exactly one value; use tensor.sum or tensor.mean",18);
  auto *grads=fac_ml_guard_new<std::vector<std::vector<double>>>();
  fac_ml_allocation_boundary([&] {
    grads->reserve(t->nodes.size());
    for (const auto &node : t->nodes) grads->emplace_back(node.value.values.size(), 0.0);
  }, "autograd.tensor.backward");
  (*grads)[(size_t)output][0]=seed;
  auto add=[&](int32_t id,size_t at,double delta){double next=(*grads)[(size_t)id][at]+delta;if(!std::isfinite(next))do_throw("autograd.tensor.backward: gradient became non-finite",18);(*grads)[(size_t)id][at]=next;};
  for(int64_t ix=output;ix>=0;--ix){const FacTensorGradNode&n=t->nodes[(size_t)ix];const auto&g=(*grads)[(size_t)ix];if(n.op==FAC_TGRAD_LEAF)continue;const FacTensorGradNode&a=t->nodes[(size_t)n.a];
    if(n.op==FAC_TGRAD_ADD||n.op==FAC_TGRAD_SUB){for(size_t i=0;i<g.size();i++){add(n.a,i,g[i]);add(n.b,i,n.op==FAC_TGRAD_ADD?g[i]:-g[i]);}}
    else if(n.op==FAC_TGRAD_HADAMARD){const auto&b=t->nodes[(size_t)n.b];for(size_t i=0;i<g.size();i++){add(n.a,i,g[i]*b.value.values[i]);add(n.b,i,g[i]*a.value.values[i]);}}
    else if(n.op==FAC_TGRAD_MATMUL){const auto&b=t->nodes[(size_t)n.b];for(int64_t i=0;i<a.value.rows;i++)for(int64_t k=0;k<a.value.cols;k++){long double z=0;for(int64_t j=0;j<b.value.cols;j++)z+=(long double)g[(size_t)i*(size_t)b.value.cols+(size_t)j]*b.value.values[(size_t)k*(size_t)b.value.cols+(size_t)j];add(n.a,(size_t)i*(size_t)a.value.cols+(size_t)k,(double)z);}for(int64_t k=0;k<a.value.cols;k++)for(int64_t j=0;j<b.value.cols;j++){long double z=0;for(int64_t i=0;i<a.value.rows;i++)z+=(long double)a.value.values[(size_t)i*(size_t)a.value.cols+(size_t)k]*g[(size_t)i*(size_t)b.value.cols+(size_t)j];add(n.b,(size_t)k*(size_t)b.value.cols+(size_t)j,(double)z);}}
    else if(n.op==FAC_TGRAD_SCALE){for(size_t i=0;i<g.size();i++)add(n.a,i,g[i]*n.scalar);}
    else if(n.op==FAC_TGRAD_SUM||n.op==FAC_TGRAD_MEAN){double d=g[0]*(n.op==FAC_TGRAD_MEAN?1.0/(double)a.value.values.size():1.0);for(size_t i=0;i<a.value.values.size();i++)add(n.a,i,d);}
    else if(n.op==FAC_TGRAD_RELU||n.op==FAC_TGRAD_SIGMOID||n.op==FAC_TGRAD_TANH){for(size_t i=0;i<g.size();i++){double x=a.value.values[i],y=n.value.values[i],d=n.op==FAC_TGRAD_RELU?(x>0.0?1.0:0.0):n.op==FAC_TGRAD_SIGMOID?y*(1.0-y):1.0-y*y;add(n.a,i,g[i]*d);}}
  }
  for(size_t i=0;i<grads->size();i++){fac_tautograd_finite((*grads)[i],"autograd.tensor.backward");}
  for(size_t i=0;i<grads->size();i++)t->nodes[i].grad.swap((*grads)[i]);
  fac_ml_guard_discard(grads);
}
void fac_autograd_tensor_backward(void*p,int32_t output){fac_autograd_tensor_backward_seed(p,output,1.0);}

// autograd -- scalar reverse-mode tape; node identifiers are valid only on their originating tape.
// Mutable tape state stays on its creating thread. Cross-thread use/free is a
// defined FAC Concurrency error rather than an unsynchronized vector access.
static void fac_autograd_require_owner(const FacGradTape *t) {
  if (t->owner_token != fac_autograd_current_thread_token())
    do_throw("autograd: tape belongs to another thread", 16);
}
static FacGradTape *fac_autograd_checked(void *p) {
  if(!p)do_throw("autograd: null tape",6);
  FacGradTape *t=(FacGradTape*)p;
  fac_autograd_require_owner(t);
  return t;
}
static FacGradNode &fac_autograd_node(FacGradTape*t,int32_t id) { if(id<0||(size_t)id>=t->nodes.size())do_throw("autograd: node id out of range",2);return t->nodes[(size_t)id]; }
static int32_t fac_autograd_push(FacGradTape*t,int32_t op,int32_t a,int32_t b,double exponent,double value) {
  if(!std::isfinite(value))do_throw("autograd: operation produced a non-finite value",18);
  if(t->nodes.size()>=1048576u)do_throw("autograd: tape node limit of 1,048,576 reached",8);
  FacGradNode n;n.op=op;n.a=a;n.b=b;n.exponent=exponent;n.value=value;
  fac_ml_allocation_boundary([&] { t->nodes.push_back(n); }, "autograd");
  return (int32_t)t->nodes.size()-1;
}
void *fac_autograd_create(){return new FacGradTape;}
void fac_autograd_free(void*p){
  if(!p)return;
  FacGradTape *t=(FacGradTape*)p;
  fac_autograd_require_owner(t);
  delete t;
}
int32_t fac_autograd_variable(void*p,double value){FacGradTape*t=fac_autograd_checked(p);if(!std::isfinite(value))do_throw("autograd.variable: value must be finite",18);return fac_autograd_push(t,FAC_GRAD_LEAF,-1,-1,0.0,value);}
static int32_t fac_autograd_binary(void*p,int32_t a,int32_t b,int32_t op){FacGradTape*t=fac_autograd_checked(p);double x=fac_autograd_node(t,a).value,y=fac_autograd_node(t,b).value,z=0.0;
  if(op==FAC_GRAD_ADD)z=x+y;else if(op==FAC_GRAD_SUB)z=x-y;else if(op==FAC_GRAD_MUL)z=x*y;else {if(y==0.0)do_throw("autograd.div: division by zero",3);z=x/y;}return fac_autograd_push(t,op,a,b,0.0,z);}
int32_t fac_autograd_add(void*p,int32_t a,int32_t b){return fac_autograd_binary(p,a,b,FAC_GRAD_ADD);}int32_t fac_autograd_sub(void*p,int32_t a,int32_t b){return fac_autograd_binary(p,a,b,FAC_GRAD_SUB);}int32_t fac_autograd_mul(void*p,int32_t a,int32_t b){return fac_autograd_binary(p,a,b,FAC_GRAD_MUL);}int32_t fac_autograd_div(void*p,int32_t a,int32_t b){return fac_autograd_binary(p,a,b,FAC_GRAD_DIV);}
int32_t fac_autograd_unary(void*p,int32_t a,int32_t op){FacGradTape*t=fac_autograd_checked(p);double x=fac_autograd_node(t,a).value,z=0.0;
  if(op==FAC_GRAD_NEG)z=-x;else if(op==FAC_GRAD_EXP)z=std::exp(x);else if(op==FAC_GRAD_LOG){if(x<=0.0)do_throw("autograd.log: input must be positive",18);z=std::log(x);}else if(op==FAC_GRAD_TANH)z=std::tanh(x);else if(op==FAC_GRAD_SIGMOID)z=fac_tensor_sigmoid(x);else if(op==FAC_GRAD_RELU)z=std::max(0.0,x);else if(op==FAC_GRAD_SOFTPLUS)z=std::max(x,0.0)+std::log1p(std::exp(-std::fabs(x)));return fac_autograd_push(t,op,a,-1,0.0,z);}
int32_t fac_autograd_neg(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_NEG);}int32_t fac_autograd_exp(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_EXP);}int32_t fac_autograd_log(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_LOG);}int32_t fac_autograd_tanh(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_TANH);}int32_t fac_autograd_sigmoid(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_SIGMOID);}int32_t fac_autograd_relu(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_RELU);}int32_t fac_autograd_softplus(void*p,int32_t a){return fac_autograd_unary(p,a,FAC_GRAD_SOFTPLUS);}
int32_t fac_autograd_pow(void*p,int32_t a,double exponent){FacGradTape*t=fac_autograd_checked(p);double x=fac_autograd_node(t,a).value;if(!std::isfinite(exponent)||x<=0.0)do_throw("autograd.pow: exponent must be finite and base must be positive",18);return fac_autograd_push(t,FAC_GRAD_POW,a,-1,exponent,std::pow(x,exponent));}
double fac_autograd_value(void*p,int32_t id){return fac_autograd_node(fac_autograd_checked(p),id).value;}double fac_autograd_grad(void*p,int32_t id){return fac_autograd_node(fac_autograd_checked(p),id).grad;}
void fac_autograd_zero_grad(void*p){FacGradTape*t=fac_autograd_checked(p);for(auto&n:t->nodes)n.grad=0.0;}
void fac_autograd_backward_seed(void*p,int32_t output,double seed){
  FacGradTape*t=fac_autograd_checked(p);if(!std::isfinite(seed))do_throw("autograd.backward: seed must be finite",18);fac_autograd_node(t,output);
  // Compute into temporary storage so overflow cannot leave a half-updated gradient tape.
  auto *grads=fac_ml_guard_new<std::vector<double>>(t->nodes.size(),0.0);(*grads)[(size_t)output]=seed;
  auto add_grad=[&](int32_t id,double delta){double next=(*grads)[(size_t)id]+delta;if(!std::isfinite(next))do_throw("autograd.backward: gradient became non-finite",18);(*grads)[(size_t)id]=next;};
  for(int64_t i=output;i>=0;i--){FacGradNode&n=t->nodes[(size_t)i];double g=(*grads)[(size_t)i];if(g==0.0||n.op==FAC_GRAD_LEAF)continue;FacGradNode&a=t->nodes[(size_t)n.a];
    switch(n.op){case FAC_GRAD_ADD:add_grad(n.a,g);add_grad(n.b,g);break;case FAC_GRAD_SUB:add_grad(n.a,g);add_grad(n.b,-g);break;case FAC_GRAD_MUL:add_grad(n.a,g*t->nodes[(size_t)n.b].value);add_grad(n.b,g*a.value);break;case FAC_GRAD_DIV:{double b=t->nodes[(size_t)n.b].value;add_grad(n.a,g/b);add_grad(n.b,-g*a.value/(b*b));break;}case FAC_GRAD_NEG:add_grad(n.a,-g);break;case FAC_GRAD_EXP:add_grad(n.a,g*n.value);break;case FAC_GRAD_LOG:add_grad(n.a,g/a.value);break;case FAC_GRAD_TANH:add_grad(n.a,g*(1.0-n.value*n.value));break;case FAC_GRAD_SIGMOID:add_grad(n.a,g*n.value*(1.0-n.value));break;case FAC_GRAD_RELU:if(a.value>0.0)add_grad(n.a,g);break;case FAC_GRAD_SOFTPLUS:add_grad(n.a,g*fac_tensor_sigmoid(a.value));break;case FAC_GRAD_POW:add_grad(n.a,g*n.exponent*std::pow(a.value,n.exponent-1.0));break;default:break;}
  }
  for(size_t i=0;i<grads->size();i++)t->nodes[i].grad=(*grads)[i];
  fac_ml_guard_discard(grads);
}
void fac_autograd_backward(void*p,int32_t output){fac_autograd_backward_seed(p,output,1.0);}

} // extern "C"
