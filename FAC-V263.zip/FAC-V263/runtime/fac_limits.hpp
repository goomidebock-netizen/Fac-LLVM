#pragma once
#include <cstdint>

// Shared resource ceilings used by the Runtime and standalone image decoder tests.
static constexpr uint64_t FAC_GFX_MAX_PIXELS = UINT64_C(1) << 24; // 16M pixels
