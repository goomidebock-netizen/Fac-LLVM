// fac_pal_audio_sdl.inc -- Platform Abstraction Layer: เสียงสำหรับ Linux/macOS ผ่าน SDL2 (โหลดด้วย dlopen ร่วมกับ fac_pal_sdl.inc)
// mixer ในตัว: หลายเสียงเล่นซ้อนกันได้, วนลูปได้, master volume, ทุกเสียงถูกแปลงเป็น stereo 44100 Hz S16 ตอนสั่งเล่น (clip ถูกคัดลอก -> free clip ทีหลังได้)
// เอาต์พุตจริงเลือกโดย SDL (ALSA/PulseAudio/CoreAudio ฯลฯ); ถ้าเปิดอุปกรณ์ไม่ได้ ฟังก์ชันคืน false และ fac_lib.inc ถอยไปใช้ aplay/paplay เดิม
extern "C++" {
namespace palaudio {
struct Spec { int freq; uint16_t format; uint8_t channels, silence; uint16_t samples, padding; uint32_t size; void (*cb)(void *, uint8_t *, int); void *ud; };
struct Voice { std::vector<int16_t> pcm; size_t pos = 0; bool loop = false; };
static const int RATE = 44100;
static const size_t MAX_VOICES = 64;
static std::mutex mu;
static std::mutex lifecycle_mu; // serializes SDL device initialization and shutdown
static std::vector<Voice> voices;
static std::atomic<double> master{1.0};
static uint32_t dev = 0; // accessed only while lifecycle_mu is held
static bool tried = false, subsys = false; // accessed only while lifecycle_mu is held
static uint32_t (*OpenDev)(const char *, int, const Spec *, Spec *, int);
static void (*CloseDev)(uint32_t);
static void (*PauseDev)(uint32_t, int);

static void callback(void *, uint8_t *out, int len) {
  int n = len / 2;                                   // จำนวนตัวอย่าง int16 (stereo interleaved)
  static thread_local std::vector<int32_t> acc;
  acc.assign((size_t)n, 0);
  {
    std::lock_guard<std::mutex> lk(mu);
    for (auto &v : voices) {
      if (v.pcm.empty()) continue;
      for (int k = 0; k < n; k++) {
        if (v.pos >= v.pcm.size()) { if (v.loop) v.pos = 0; else break; }
        acc[(size_t)k] += v.pcm[v.pos++];
      }
    }
    voices.erase(std::remove_if(voices.begin(), voices.end(), [](const Voice &v) { return !v.loop && v.pos >= v.pcm.size(); }), voices.end());
  }
  double m = master.load(std::memory_order_relaxed);
  int16_t *o = (int16_t *)out;
  for (int k = 0; k < n; k++) { double s = acc[(size_t)k] * m; o[k] = (int16_t)(s > 32767 ? 32767 : s < -32768 ? -32768 : std::lround(s)); }
}
static void shutdown() {
  std::lock_guard<std::mutex> state(lifecycle_mu);
  if (dev) { CloseDev(dev); dev = 0; }
  if (subsys) { pal::g.QuitSubSystem(0x10); subsys = false; }
  // SDL keeps a small amount of process-global state after QuitSubSystem;
  // release the complete SDL runtime at process shutdown to keep leak checks clean.
  if (pal::g.Quit) pal::g.Quit();
}
static bool open() {
  std::lock_guard<std::mutex> state(lifecycle_mu);
  if (dev) return true;
  if (tried) return false;
  tried = true;
  if (!pal::load()) return false;
  void *h = pal::g.handle;
  if (!pal::sym(h, "SDL_OpenAudioDevice", OpenDev) || !pal::sym(h, "SDL_CloseAudioDevice", CloseDev) || !pal::sym(h, "SDL_PauseAudioDevice", PauseDev)) return false;
  if (pal::g.InitSubSystem(0x10) != 0) return false;   // SDL_INIT_AUDIO
  subsys = true;
  Spec want = {}, got = {};
  want.freq = RATE; want.format = 0x8010; /* AUDIO_S16SYS (little-endian) */ want.channels = 2; want.samples = 1024; want.cb = callback;
  dev = OpenDev(nullptr, 0, &want, &got, 0);          // allowed_changes = 0 -> SDL แปลงรูปแบบให้เองถ้าฮาร์ดแวร์ไม่รองรับ
  if (dev == 0) { pal::g.QuitSubSystem(0x10); subsys = false; return false; }
  PauseDev(dev, 0);
  static const bool registered = (std::atexit(shutdown), true);
  (void)registered;
  return true;
}
static bool available() { return open(); }
// แปลง clip (mono/stereo, อัตราใดก็ได้) เป็น stereo 44100 ด้วย linear interpolation
static std::vector<int16_t> convert(const FacAudioClip *c) {
  size_t ch = (size_t)c->channels, frames = c->pcm.size() / ch;
  std::vector<int16_t> out;
  if (!frames) return out;
  size_t of = (size_t)((double)frames * RATE / c->rate + 0.5);
  out.resize(of * 2);
  for (size_t i = 0; i < of; i++) {
    double sp = (double)i * c->rate / RATE; size_t a = (size_t)sp; double fr = sp - (double)a; size_t b = a + 1 < frames ? a + 1 : a;
    if (a >= frames) a = b = frames - 1;
    for (size_t k = 0; k < 2; k++) { size_t cc = ch == 1 ? 0 : k; double s = c->pcm[a * ch + cc] * (1 - fr) + c->pcm[b * ch + cc] * fr; out[i * 2 + k] = (int16_t)std::lround(s); }
  }
  return out;
}
static bool play(const FacAudioClip *c, bool loop) {
  if (!c || !open()) return false;
  Voice v; v.pcm = convert(c); v.loop = loop;
  if (v.pcm.empty()) return true;                     // clip ว่าง: สำเร็จแต่ไม่มีเสียง
  std::lock_guard<std::mutex> lk(mu);
  if (voices.size() >= MAX_VOICES) return false;
  voices.push_back(std::move(v));
  return true;
}
static void stopAll() { std::lock_guard<std::mutex> lk(mu); voices.clear(); }
static int count() { std::lock_guard<std::mutex> lk(mu); return (int)voices.size(); }
}  // namespace palaudio
}  // extern "C++"
