// Fac runtime  (RT) -- C++17, C ABI.  คอมไพล์ด้วย clang++/g++ แล้วลิงก์กับโค้ดที่ facc สร้าง
// layout ที่ compiler รู้ (ต้องตรงกับ src/codegen.cpp):
//   FacStr  { ptr data; i64 len(bytes); i64 cap; i64 ncp(code points); i64 flags }  flags bit0=immortal; remaining bits=reference count
//   FacList { ptr data; i64 len; i64 cap; i32 esz; i32 ek }                        ek: 0=plain 1=string(FacStr*)
#include <algorithm>
#include <charconv>
#include <chrono>
#include <cmath>
#include <limits>
#include <condition_variable>
#include <deque>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstddef>
#include <string_view>
#include <random>
#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <set>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <type_traits>
#include <filesystem>
#include <regex>
#include <new>
#include <memory>
#include <exception>
#include <stdexcept>
#include <type_traits>
#include <csignal>
#include <cerrno>
#include <sys/stat.h>
#ifndef _WIN32
#include <unistd.h>
#include <dlfcn.h>
#endif
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <mmsystem.h>
#endif

extern "C" {
struct FacStr { char *data; int64_t len, cap, ncp, flags; };
struct FacList {
  void *data; int64_t len, cap; int32_t esz, ek;
  void (*dropFn)(void *);
  void (*copyFn)(void *, const void *);
};

// ---------------------------------------------------------------- output
static std::atomic<bool> g_mt{false};
static std::mutex g_wmu;
#if defined(__GLIBC__)
#define FW(p, n) fwrite_unlocked(p, 1, n, stdout)
#else
#define FW(p, n) fwrite(p, 1, n, stdout)
#endif
static thread_local int g_fd = 1;
static void flush_out() { fflush(stdout); }
static void wr(const char *p, size_t n) {  // ใช้ stdio เพื่อรักษาลำดับ output กับโค้ด C ที่เรียกผ่าน FFI
  if (g_mt.load(std::memory_order_relaxed)) {
    std::lock_guard<std::mutex> lk(g_wmu);
    if (g_fd == 2) { fflush(stdout); fwrite(p, 1, n, stderr); }
    else fwrite(p, 1, n, stdout);
    return;
  }
  if (g_fd == 2) { fflush(stdout); fwrite(p, 1, n, stderr); }
  else FW(p, n);
}
static void wrs(const std::string &s) { wr(s.data(), s.size()); }

// ---------------------------------------------------------------- errors
static thread_local std::string g_errmsg; static thread_local int32_t g_errcode = 0;
static thread_local void *g_handlers[256]; static thread_local int g_hsp = 0;
struct FacCleanup { void *slot; int32_t kind; void (*drop)(void *); };
static constexpr size_t FAC_STACK_ENTRY_LIMIT = 16384;
// Small-buffer TLS stack: keep the hot path as direct indexed memory access,
// but spill to the heap only for unusually deep scopes/expressions. Templates
// must have C++ linkage; the surrounding runtime functions retain the C ABI.
} // extern "C"
extern "C++" {
template <typename T, size_t InlineEntries>
class FacTLSStack {
  static_assert(std::is_trivially_copyable<T>::value, "FAC TLS stack entries must be trivially copyable");
  T local_[InlineEntries];
  T *data_ = local_;
  size_t size_ = 0;
  size_t capacity_ = InlineEntries;
public:
  FacTLSStack() = default;
  FacTLSStack(const FacTLSStack &) = delete;
  FacTLSStack &operator=(const FacTLSStack &) = delete;
  ~FacTLSStack() { if (data_ != local_) free(data_); }
  bool push_back(const T &value) {
    if (size_ == capacity_) {
      if (capacity_ >= FAC_STACK_ENTRY_LIMIT) return false;
      const size_t next = capacity_ > FAC_STACK_ENTRY_LIMIT / 2 ? FAC_STACK_ENTRY_LIMIT : capacity_ * 2;
      if (next > SIZE_MAX / sizeof(T)) return false;
      T *fresh = data_ == local_ ? (T *)malloc(next * sizeof(T)) : (T *)realloc(data_, next * sizeof(T));
      if (!fresh) return false;
      if (data_ == local_ && size_) memcpy(fresh, local_, size_ * sizeof(T));
      data_ = fresh; capacity_ = next;
    }
    data_[size_++] = value;
    return true;
  }
  void pop_back() { if (size_) --size_; }
  T &back() { return data_[size_ - 1]; }
  T &operator[](size_t i) { return data_[i]; }
  const T &operator[](size_t i) const { return data_[i]; }
  void erase(size_t i) {
    if (i >= size_) return;
    if (i + 1 < size_) memmove(data_ + i, data_ + i + 1, (size_ - i - 1) * sizeof(T));
    --size_;
  }
  size_t capacity() const { return capacity_; }
  // Release spill storage when the stack is idle, but keep the small inline
  // reserve so common future calls remain allocation-free.
  bool trim() {
    if (size_ != 0) return false;
    if (data_ != local_) { free(data_); data_ = local_; capacity_ = InlineEntries; }
    return true;
  }
 };

// A tiny per-thread cache for raw, short-lived byte workspaces. It deliberately
// does not pool FAC-owned objects: refcounts, finalizers, cycle registration and
// debug/tracking accounting remain on the ordinary allocator path. One block
// per class keeps retained memory bounded to about 1.4 KiB per live thread.
class FacScratchPool {
  struct alignas(std::max_align_t) Header {
    uint32_t classIndex;
    uint32_t magic;
  };
  static constexpr uint32_t kMagic = 0xFAC5C8A1u;
  static constexpr size_t kClassCount = 3;
  static constexpr size_t class_capacity(size_t i) {
    return i == 0 ? 64u : i == 1 ? 256u : 1024u;
  }
  Header *cached_[kClassCount]{};
  uint64_t hits_ = 0;
  uint64_t upstream_allocations_ = 0;
  static Header *header(void *p) { return reinterpret_cast<Header *>(p) - 1; }
  static void *payload(Header *h) { return static_cast<void *>(h + 1); }
public:
  FacScratchPool() = default;
  FacScratchPool(const FacScratchPool &) = delete;
  FacScratchPool &operator=(const FacScratchPool &) = delete;
  ~FacScratchPool() { trim(); }

  void *allocate(size_t bytes) noexcept {
    if (bytes == 0) bytes = 1;
    size_t index = kClassCount;
    for (size_t i = 0; i < kClassCount; ++i) {
      if (bytes <= class_capacity(i)) { index = i; break; }
    }
    if (index < kClassCount && cached_[index]) {
      Header *h = cached_[index];
      cached_[index] = nullptr;
      ++hits_;
      return payload(h);
    }
    const size_t capacity = index < kClassCount ? class_capacity(index) : bytes;
    if (capacity > SIZE_MAX - sizeof(Header)) return nullptr;
    Header *h = static_cast<Header *>(malloc(sizeof(Header) + capacity));
    if (!h) return nullptr;
    h->classIndex = index < kClassCount ? static_cast<uint32_t>(index) : UINT32_MAX;
    h->magic = kMagic;
    ++upstream_allocations_;
    return payload(h);
  }

  void release(void *p) noexcept {
    if (!p) return;
    Header *h = header(p);
    if (h->magic != kMagic) {
      fprintf(stderr, "FAC internal: invalid temporary scratch block\n");
      abort();
    }
    const uint32_t index = h->classIndex;
    if (index < kClassCount && !cached_[index]) {
      cached_[index] = h;
      return;
    }
    h->magic = 0;
    free(h);
  }

  bool trim() noexcept {
    for (size_t i = 0; i < kClassCount; ++i) {
      if (cached_[i]) {
        cached_[i]->magic = 0;
        free(cached_[i]);
        cached_[i] = nullptr;
      }
    }
    return true;
  }

  uint64_t cached_bytes() const noexcept {
    uint64_t total = 0;
    for (size_t i = 0; i < kClassCount; ++i) {
      if (cached_[i]) total += sizeof(Header) + class_capacity(i);
    }
    return total;
  }
  uint64_t hits() const noexcept { return hits_; }
  uint64_t upstream_allocations() const noexcept { return upstream_allocations_; }
};
} // extern "C++"
extern "C" {
// 32 inline entries per stack cover ordinary expression/scope nesting while
// halving per-thread inline TLS storage versus the previous 64-entry reserve.
static thread_local FacTLSStack<FacCleanup, 32> g_cleanups;
static thread_local int g_csp = 0;
static thread_local int g_handler_cleanup[256];
// temp stack: ค่า owned ชั่วคราวของ expression (เช่น ผลลัพธ์ "a"+s ที่ยังไม่ถูกปล่อยปลายคำสั่ง) -- เก็บ "ค่าตัวชี้" ไม่ใช่ slot
// ตอน throw (longjmp ข้ามโค้ด free ที่ codegen วางไว้) runtime ปล่อยทุกตัวที่อยู่เหนือระดับที่ try บันทึกไว้
struct JV; void fac_jd_free(JV *v);   // ต้นไม้ JSON (kind 7)
struct FacTmp { void *val; int32_t kind; void *aux; };   // kind 8: เรียก aux(val) (เช่น drop.Struct ของ struct ชั่วคราว)
// Temporary ownership stack follows the same allocation-free small-buffer path.
static thread_local FacTLSStack<FacTmp, 32> g_tmps;
static thread_local int g_tsp = 0;
static thread_local FacScratchPool g_scratch_pool;
static thread_local uint64_t g_runtime_stack_peak = 32u * (sizeof(FacCleanup) + sizeof(FacTmp));
static uint64_t fac_runtime_stack_bytes_impl() {
  const uint64_t a = (uint64_t)g_cleanups.capacity() * (uint64_t)sizeof(FacCleanup);
  const uint64_t b = (uint64_t)g_tmps.capacity() * (uint64_t)sizeof(FacTmp);
  return b > UINT64_MAX - a ? UINT64_MAX : a + b;
}
static void fac_runtime_stack_update_peak() {
  const uint64_t now = fac_runtime_stack_bytes_impl();
  if (now > g_runtime_stack_peak) g_runtime_stack_peak = now;
}
static thread_local int g_handler_tmp[256];
static const bool g_tmp_check = getenv("FAC_TMP_CHECK") != nullptr;   // โหมดตรวจ: push/pop ต้องคู่กันเสมอ (ใช้ในชุดทดสอบ)
static void fac_tmp_exit_check() { if (g_tsp != 0) { fprintf(stderr, "FAC internal: temp stack not empty at exit (%d left)\n", g_tsp); _exit(97); } }
static const int g_tmp_reg = g_tmp_check ? atexit(fac_tmp_exit_check) : 0;
// FAC call-depth guard state is exported as TLS so generated LLVM IR can update it
// inline. This preserves the guard while removing two out-of-line runtime calls per FAC call.
thread_local uint32_t fac_recursion_depth = 0;
thread_local uint64_t fac_recursion_stack_anchor = 0;
static int g_argc = 0; static char **g_argv = nullptr;
static inline const char *sd(const FacStr *s) { return s ? s->data : ""; }
[[noreturn]] static void do_throw(std::string msg, int32_t code);
static inline void *xmalloc(size_t n) { void *p = malloc(n ? n : 1); if (!p) do_throw("out of memory", 5); return p; }
void *fac_runtime_scratch_alloc(size_t n) {
  void *p = g_scratch_pool.allocate(n);
  if (!p) do_throw("out of memory allocating temporary workspace", 5);
  return p;
}
void fac_runtime_scratch_free(void *p) { g_scratch_pool.release(p); }
uint64_t fac_runtime_scratch_cached_bytes() { return g_scratch_pool.cached_bytes(); }
uint64_t fac_runtime_scratch_hits() { return g_scratch_pool.hits(); }
uint64_t fac_runtime_scratch_upstream_allocations() { return g_scratch_pool.upstream_allocations(); }
static inline int64_t sl(const FacStr *s) { return s ? s->len : 0; }

static thread_local uint32_t g_handler_depth[256];
static thread_local uint64_t g_handler_stack_anchor[256];
void fac_str_free(FacStr *s);
void fac_list_free(FacList *l);
struct FacDS;
void fac_ds_free(FacDS *d);
void fac_closure_release(void *p);
void fac_obj_retain(void *p);
void fac_obj_release(void *p);
void fac_obj_weak_release(void *p);
static void fac_cleanup_drop_one(const FacCleanup &c) {
  if (!c.slot) return;
  if (c.kind == 1) fac_str_free(*reinterpret_cast<FacStr **>(c.slot));
  else if (c.kind == 2) fac_list_free(*reinterpret_cast<FacList **>(c.slot));
  else if (c.kind == 3) fac_ds_free(reinterpret_cast<FacDS *>(*reinterpret_cast<void **>(c.slot)));
  else if (c.kind == 4 && c.drop) c.drop(c.slot);
  else if (c.kind == 5) fac_closure_release(*reinterpret_cast<void **>(c.slot));
  else if (c.kind == 6) fac_obj_release(*reinterpret_cast<void **>(c.slot));
  else if (c.kind == 9) fac_obj_weak_release(*reinterpret_cast<void **>(c.slot));
}
void fac_cleanup_push(void *slot, int32_t kind, void *drop) {
  FacCleanup c{slot, kind, reinterpret_cast<void (*)(void *)>(drop)};
  if (g_csp >= (int)FAC_STACK_ENTRY_LIMIT) {
    // The entry was not registered, so release this value before unwinding older entries.
    fac_cleanup_drop_one(c);
    do_throw("FAC cleanup stack capacity exceeded", 8);
  }
  if (!g_cleanups.push_back(c)) { fac_cleanup_drop_one(c); do_throw("out of memory growing FAC cleanup stack", 5); }
  ++g_csp; fac_runtime_stack_update_peak();
}
void fac_cleanup_pop() { if (g_csp > 0) { g_cleanups.pop_back(); --g_csp; } }
static void fac_tmp_drop_one(const FacTmp &t) {
  if (!t.val) return;
  if (t.kind == 1) fac_str_free(static_cast<FacStr *>(t.val));
  else if (t.kind == 2) fac_list_free(static_cast<FacList *>(t.val));
  else if (t.kind == 3) fac_ds_free(static_cast<FacDS *>(t.val));
  else if (t.kind == 5) fac_closure_release(t.val);
  else if (t.kind == 6) fac_obj_release(t.val);
  else if (t.kind == 9) fac_obj_weak_release(t.val);
  else if (t.kind == 7) fac_jd_free(static_cast<JV *>(t.val));
  else if (t.kind == 8 && t.aux) reinterpret_cast<void (*)(void *)>(t.aux)(t.val);
}
void fac_tmp_push(void *val, int32_t kind) {
  if (!val) return;
  if (g_tsp >= (int)FAC_STACK_ENTRY_LIMIT) {
    fac_tmp_drop_one({val, kind, nullptr});
    do_throw("FAC temporary stack capacity exceeded", 8);
  }
  if (!g_tmps.push_back({val, kind, nullptr})) { fac_tmp_drop_one({val, kind, nullptr}); do_throw("out of memory growing FAC temporary stack", 5); }
  ++g_tsp; fac_runtime_stack_update_peak();
}
void fac_tmp_push_drop(void *val, void *dropFn) {
  if (!val) return;
  if (g_tsp >= (int)FAC_STACK_ENTRY_LIMIT) {
    fac_tmp_drop_one({val, 8, dropFn});
    do_throw("FAC temporary stack capacity exceeded", 8);
  }
  if (!g_tmps.push_back({val, 8, dropFn})) { fac_tmp_drop_one({val, 8, dropFn}); do_throw("out of memory growing FAC temporary stack", 5); }
  ++g_tsp; fac_runtime_stack_update_peak();
}
static void fac_tmp_free_raw(void *p) { fac_runtime_scratch_free(p); }
void fac_tmp_pop(void *val);
struct FacScratchScope {
  void *value;
  explicit FacScratchScope(void *p) : value(p) {}
  FacScratchScope(const FacScratchScope &) = delete;
  FacScratchScope &operator=(const FacScratchScope &) = delete;
  ~FacScratchScope() noexcept {
    if (value) { fac_tmp_pop(value); fac_runtime_scratch_free(value); }
  }
};
void fac_tmp_pop(void *val) {
  if (!val || g_tsp == 0) return;
  // Almost all generated temporaries are released in strict LIFO order.
  if (g_tmps.back().val == val) { g_tmps.pop_back(); --g_tsp; return; }
  // Keep the defensive fallback for values whose lifetimes intentionally overlap.
  for (int i = g_tsp - 2; i >= 0; i--)
    if (g_tmps[(size_t)i].val == val) { g_tmps.erase((size_t)i); --g_tsp; return; }
}
// A failing drop must not prevent older ownership entries from being released.
// Keep the failure as a thread-local diagnostic bit; callers preserve the
// primary FAC/C++ error while the remainder of each LIFO stack is drained.
static thread_local bool g_cleanup_drop_failed = false;
static thread_local bool g_temporary_drop_failed = false;
static void fac_tmp_run_to(int depth) noexcept {
  while (g_tsp > depth) {
    FacTmp t = g_tmps.back(); g_tmps.pop_back(); --g_tsp;
    try { fac_tmp_drop_one(t); }
    catch (...) { g_temporary_drop_failed = true; }
  }
}
static void fac_cleanup_run_to(int depth) noexcept {
  while (g_csp > depth) {
    FacCleanup c = g_cleanups.back(); g_cleanups.pop_back(); --g_csp;
    try { fac_cleanup_drop_one(c); }
    catch (...) { g_cleanup_drop_failed = true; }
  }
}
void fac_try_enter(void *jb) {
  if (g_hsp >= 256) do_throw("FAC try-handler nesting limit exceeded", 8);
  g_handlers[g_hsp] = jb;
  g_handler_depth[g_hsp] = fac_recursion_depth;
  g_handler_stack_anchor[g_hsp] = fac_recursion_stack_anchor;
  g_handler_cleanup[g_hsp] = g_csp;
  g_handler_tmp[g_hsp] = g_tsp;
  g_hsp++;
}
void fac_try_leave() {
  if (g_tmp_check && g_hsp > 0 && g_tsp != g_handler_tmp[g_hsp - 1]) { fprintf(stderr, "FAC internal: temp stack imbalance at try exit (%d != %d)\n", g_tsp, g_handler_tmp[g_hsp - 1]); abort(); }
  if (g_hsp > 0) g_hsp--;
}
[[noreturn]] static void do_throw(std::string msg, int32_t code) {
  g_errmsg.assign(msg.data(), msg.size()); g_errcode = code;
  std::string().swap(msg);   // do_throw ไม่คืนการควบคุม (ข้าม destructor): ปล่อย buffer ของพารามิเตอร์เองก่อน ไม่งั้นรั่วทุกครั้งที่ throw
  if (g_hsp == 0) { fac_cleanup_run_to(0); fac_tmp_run_to(0); flush_out(); fprintf(stderr, "%s\n", g_errmsg.c_str()); fflush(stderr); exit(1); }
  int h = --g_hsp;
  void *jb = g_handlers[h];
  fac_cleanup_run_to(g_handler_cleanup[h]);
  fac_tmp_run_to(g_handler_tmp[h]);
  fac_recursion_depth = g_handler_depth[h]; // longjmp bypasses generated function epilogues
  fac_recursion_stack_anchor = g_handler_stack_anchor[h];
  __builtin_longjmp((void **)jb, 1);
}
[[noreturn]] void fac_throw(FacStr *msg, int32_t code) { do_throw(std::string(sd(msg), sl(msg)), code); }
// Consumes an owned temporary message before longjmp bypasses its generated cleanup.
[[noreturn]] void fac_throw_owned(FacStr *msg, int32_t code) {
  std::string copy(sd(msg), (size_t)sl(msg));
  fac_str_free(msg);
  do_throw(std::move(copy), code);
}
// Slow path used only when the inline generated guard detects a limit violation.
// The hot path is emitted directly as TLS loads/stores in each FAC function.
[[noreturn]] void fac_recursion_fail(int32_t reason) {
  if (reason == 1) do_throw("stack overflow: recursion exhausted the FAC stack budget", 8);
  do_throw("stack overflow: FAC recursion depth limit exceeded", 8);
}
[[noreturn]] void fac_oob(int64_t i, int64_t n) { do_throw("index out of range: " + std::to_string(i) + " (size " + std::to_string(n) + ")", 2); }
[[noreturn]] void fac_div0() { do_throw("div by zero", 3); }
[[noreturn]] void fac_assert_fail(FacStr *msg) { do_throw(std::string("assert failed: ") + sd(msg), 4); }
// สร้างสตริงใหม่จาก error ปัจจุบัน (caller เป็นเจ้าของ)
static FacStr *mk(const char *p, int64_t n);
FacStr *fac_err_msg() { return mk(g_errmsg.data(), (int64_t)g_errmsg.size()); }
int32_t fac_err_code() { return g_errcode; }

// ---------------------------------------------------------------- memory
// FAC-managed allocator. The normal path has no per-allocation header. Memory
// diagnostics are opt-in and keep size metadata in a side table only after
// memory.startTracking(), so ordinary programs do not pay for allocator headers.
static std::atomic<bool> g_debug{false};
static std::atomic<bool> g_mem_tracking{false};
static std::set<void *> g_live; static std::mutex g_live_m;
static std::atomic<uint64_t> g_live_count{0};

// Opt-in allocation accounting uses a compact open-addressed table instead of
// std::unordered_map's one heap node per live allocation. The table is protected
// by g_mem_m; a flat table avoids allocator recursion and reduces metadata/cache
// traffic when memory.startTracking() is enabled.
class FacMemLiveTable {
  struct Slot { void *key = nullptr; size_t bytes = 0; uint8_t state = 0; };
  static constexpr size_t kInitialCapacity = 64;
  static constexpr uint8_t kEmpty = 0, kOccupied = 1, kTombstone = 2;
  std::vector<Slot> slots_;
  size_t size_ = 0;
  size_t tombstones_ = 0;

  static size_t hash_key(const void *key) {
    uint64_t x = (uint64_t)(uintptr_t)key;
    x ^= x >> 30;
    x *= UINT64_C(0xbf58476d1ce4e5b9);
    x ^= x >> 27;
    x *= UINT64_C(0x94d049bb133111eb);
    x ^= x >> 31;
    return (size_t)x;
  }
  static bool place(Slot *slots, size_t capacity, void *key, size_t bytes, bool *reusedTombstone = nullptr) {
    if (reusedTombstone) *reusedTombstone = false;
    const size_t mask = capacity - 1;
    size_t index = hash_key(key) & mask;
    size_t firstTombstone = SIZE_MAX;
    for (size_t probes = 0; probes < capacity; ++probes) {
      Slot &slot = slots[index];
      if (slot.state == kEmpty) {
        const bool reused = firstTombstone != SIZE_MAX;
        Slot &dst = slots[reused ? firstTombstone : index];
        dst.key = key; dst.bytes = bytes; dst.state = kOccupied;
        if (reusedTombstone) *reusedTombstone = reused;
        return true;
      }
      if (slot.state == kTombstone) {
        if (firstTombstone == SIZE_MAX) firstTombstone = index;
      } else if (slot.key == key) {
        return false;
      }
      index = (index + 1) & mask;
    }
    if (firstTombstone != SIZE_MAX) {
      Slot &dst = slots[firstTombstone];
      dst.key = key; dst.bytes = bytes; dst.state = kOccupied;
      if (reusedTombstone) *reusedTombstone = true;
      return true;
    }
    return false;
  }
  bool rebuild(size_t capacity) {
    std::vector<Slot> fresh(capacity);
    for (const Slot &slot : slots_) {
      if (slot.state == kOccupied && !place(fresh.data(), fresh.size(), slot.key, slot.bytes)) return false;
    }
    slots_.swap(fresh);
    tombstones_ = 0;
    return true;
  }
  bool prepare_insert() {
    if (slots_.empty()) return rebuild(kInitialCapacity);
    const size_t capacity = slots_.size();
    // Keep at least 25% genuinely empty slots so lookup and key replacement
    // always terminate without allocating on free/realloc paths.
    if (size_ + tombstones_ + 1 < capacity - capacity / 4) return true;
    if (size_ + 1 >= capacity - capacity / 4) {
      if (capacity > SIZE_MAX / 2 || capacity * 2 > SIZE_MAX / sizeof(Slot)) return false;
      return rebuild(capacity * 2);
    }
    return rebuild(capacity); // tombstone compaction, no capacity growth
  }
  size_t find_index(const void *key) const {
    if (slots_.empty() || !key) return SIZE_MAX;
    const size_t mask = slots_.size() - 1;
    size_t index = hash_key(key) & mask;
    for (size_t probes = 0; probes < slots_.size(); ++probes) {
      const Slot &slot = slots_[index];
      if (slot.state == kEmpty) return SIZE_MAX;
      if (slot.state == kOccupied && slot.key == key) return index;
      index = (index + 1) & mask;
    }
    return SIZE_MAX;
  }
public:
  bool insert(void *key, size_t bytes) {
    if (!key || !prepare_insert()) return false;
    bool reusedTombstone = false;
    if (!place(slots_.data(), slots_.size(), key, bytes, &reusedTombstone)) return false;
    ++size_;
    if (reusedTombstone) --tombstones_;
    return true;
  }
  bool get(const void *key, size_t &bytes) const {
    const size_t index = find_index(key);
    if (index == SIZE_MAX) return false;
    bytes = slots_[index].bytes;
    return true;
  }
  bool erase(const void *key, size_t &bytes) {
    const size_t index = find_index(key);
    if (index == SIZE_MAX) return false;
    Slot &slot = slots_[index];
    bytes = slot.bytes;
    slot.key = nullptr; slot.bytes = 0; slot.state = kTombstone;
    --size_; ++tombstones_;
    return true;
  }
  bool replace_key(const void *oldKey, void *newKey, size_t bytes) {
    const size_t index = find_index(oldKey);
    if (index == SIZE_MAX || !newKey) return false;
    if (oldKey == newKey) { slots_[index].bytes = bytes; return true; }
    Slot &slot = slots_[index];
    slot.key = nullptr; slot.bytes = 0; slot.state = kTombstone;
    --size_; ++tombstones_;
    bool reusedTombstone = false;
    if (!place(slots_.data(), slots_.size(), newKey, bytes, &reusedTombstone)) return false;
    ++size_;
    if (reusedTombstone) --tombstones_;
    // Replacing a key preserves occupied+tombstone pressure unless the new
    // hash probe reuses a tombstone (possibly the slot just vacated).
    return true;
  }
  size_t storage_bytes() const {
    const size_t capacity = slots_.capacity();
    return capacity > SIZE_MAX / sizeof(Slot) ? SIZE_MAX : capacity * sizeof(Slot);
  }
};
static FacMemLiveTable g_mem_live; static std::mutex g_mem_m;
static std::atomic<uint64_t> g_mem_used{0}, g_mem_peak{0}, g_mem_blocks{0};
static std::atomic<uint64_t> g_mem_allocs{0}, g_mem_reallocs{0};
static void fac_mem_update_peak(uint64_t now) {
  uint64_t peak = g_mem_peak.load(std::memory_order_relaxed);
  while (peak < now && !g_mem_peak.compare_exchange_weak(peak, now, std::memory_order_relaxed)) {}
}
static void fac_mem_account_alloc(size_t n) {
  uint64_t now = g_mem_used.fetch_add((uint64_t)n, std::memory_order_relaxed) + (uint64_t)n;
  fac_mem_update_peak(now);
  g_mem_blocks.fetch_add(1, std::memory_order_relaxed);
}
static void fac_mem_account_free(size_t n) {
  uint64_t old = g_mem_used.fetch_sub((uint64_t)n, std::memory_order_relaxed);
  if (old < (uint64_t)n) { fprintf(stderr, "FAC internal: memory accounting underflow\n"); abort(); }
  uint64_t blocks = g_mem_blocks.fetch_sub(1, std::memory_order_relaxed);
  if (blocks == 0) { fprintf(stderr, "FAC internal: memory block accounting underflow\n"); abort(); }
}
void fac_set_debug(int32_t on) { g_debug.store(on != 0, std::memory_order_release); }
[[noreturn]] void fac_null_deref() { do_throw("null pointer dereference", 6); }
static void *fac_alloc_impl(int64_t n, bool clear) {
  if (n < 0 || (uint64_t)n > (uint64_t)SIZE_MAX) do_throw("invalid allocation size", 5);
  const size_t payload = n > 0 ? (size_t)n : 1;
  void *p = clear ? calloc(1, payload) : malloc(payload);
  if (!p) do_throw("out of memory", 5);
  if (g_mem_tracking.load(std::memory_order_relaxed)) {
    try {
      std::lock_guard<std::mutex> g(g_mem_m);
      if (!g_mem_live.insert(p, payload)) throw std::bad_alloc();
    } catch (...) { free(p); do_throw("out of memory while tracking allocation", 5); }
    fac_mem_account_alloc(payload);
    g_mem_allocs.fetch_add(1, std::memory_order_relaxed);
  }
  if (g_debug.load(std::memory_order_acquire)) {
    try {
      std::lock_guard<std::mutex> g(g_live_m);
      if (g_live.insert(p).second) g_live_count.fetch_add(1, std::memory_order_relaxed);
    }
    catch (...) {
      if (g_mem_tracking.load(std::memory_order_relaxed)) {
        std::lock_guard<std::mutex> g(g_mem_m); size_t ignored = 0; if (g_mem_live.erase(p, ignored)) fac_mem_account_free(ignored);
      }
      free(p); do_throw("out of memory while recording debug allocation", 5);
    }
  }
  return p;
}
void *fac_alloc(int64_t n) { return fac_alloc_impl(n, true); }
// Internal fast path for objects whose complete payload is immediately written.
static void *fac_alloc_uninit(int64_t n) { return fac_alloc_impl(n, false); }
void fac_free(void *p) {
  if (!p) return;
  // Debug registration belongs to the allocation, not to the current global
  // debug switch. Keep the hot path lock-free unless debug records are live.
  if (g_debug.load(std::memory_order_acquire) || g_live_count.load(std::memory_order_relaxed) != 0) {
    std::lock_guard<std::mutex> g(g_live_m);
    if (g_live.erase(p)) g_live_count.fetch_sub(1, std::memory_order_relaxed);
  }
  if (g_mem_tracking.load(std::memory_order_relaxed)) {
    size_t n = 0;
    { std::lock_guard<std::mutex> g(g_mem_m); g_mem_live.erase(p, n); }
    if (n) fac_mem_account_free(n);
  }
  free(p);
}
void *fac_realloc(void *p, int64_t n) {
  if (!p) return fac_alloc(n);
  if (n < 0 || (uint64_t)n > (uint64_t)SIZE_MAX) do_throw("invalid reallocation size", 5);
  const size_t payload = n > 0 ? (size_t)n : 1;
  void *q = nullptr;
  bool tracked = false;
  size_t oldSize = 0;
  if (g_mem_tracking.load(std::memory_order_relaxed)) {
    std::unique_lock<std::mutex> g(g_mem_m);
    tracked = g_mem_live.get(p, oldSize);
    if (tracked) {
      q = realloc(p, payload);
      if (!q) { g.unlock(); do_throw("out of memory", 5); }
      if (!g_mem_live.replace_key(p, q, payload)) {
        // The table keeps spare empty slots, so this is an internal invariant
        // failure rather than an expected allocation failure.
        fprintf(stderr, "FAC internal: tracked realloc lost allocation record\n");
        abort();
      }
    }
  }
  if (!q && !tracked) {
    q = realloc(p, payload);
    if (!q) do_throw("out of memory", 5);
  }
  if (tracked) {
    g_mem_reallocs.fetch_add(1, std::memory_order_relaxed);
    if (payload > oldSize) {
      uint64_t delta = (uint64_t)(payload - oldSize);
      uint64_t now = g_mem_used.fetch_add(delta, std::memory_order_relaxed) + delta;
      uint64_t peak = g_mem_peak.load(std::memory_order_relaxed);
      while (peak < now && !g_mem_peak.compare_exchange_weak(peak, now, std::memory_order_relaxed)) {}
    } else if (payload < oldSize) g_mem_used.fetch_sub((uint64_t)(oldSize - payload), std::memory_order_relaxed);
  }
  if (q != p && (g_debug.load(std::memory_order_acquire) || g_live_count.load(std::memory_order_relaxed) != 0)) {
    std::lock_guard<std::mutex> g(g_live_m);
    auto node = g_live.extract(p);
    if (!node.empty()) { node.value() = q; g_live.insert(std::move(node)); }
  }
  return q;
}
void fac_mem_start_tracking() { g_mem_tracking.store(true, std::memory_order_release); }
void fac_mem_reset_peak() {
  g_mem_peak.store(g_mem_used.load(std::memory_order_acquire), std::memory_order_release);
  // Capture an allocation racing with the reset as well; concurrent snapshots
  // remain approximate, but a completed single-threaded reset is exact.
  fac_mem_update_peak(g_mem_used.load(std::memory_order_acquire));
}
uint64_t fac_mem_used() { return g_mem_used.load(std::memory_order_relaxed); }
uint64_t fac_mem_peak() { return g_mem_peak.load(std::memory_order_relaxed); }
uint64_t fac_mem_blocks() { return g_mem_blocks.load(std::memory_order_relaxed); }
uint64_t fac_mem_reserved() {
  const uint64_t used = g_mem_used.load(std::memory_order_relaxed);
  // Payload plus the flat tracking-table's reserved slot storage. This is not
  // allocator metadata or process RSS; it describes FAC tracking diagnostics.
  uint64_t overhead = 0;
  { std::lock_guard<std::mutex> g(g_mem_m); overhead = (uint64_t)g_mem_live.storage_bytes(); }
  return overhead > UINT64_MAX - used ? UINT64_MAX : used + overhead;
}
uint64_t fac_mem_allocs() { return g_mem_allocs.load(std::memory_order_relaxed); }
uint64_t fac_mem_reallocs() { return g_mem_reallocs.load(std::memory_order_relaxed); }
uint64_t fac_runtime_stack_bytes() { return fac_runtime_stack_bytes_impl(); }
uint64_t fac_runtime_stack_peak_bytes() { return g_runtime_stack_peak; }
// Return false while FAC-managed values are still registered. Releasing only
// the idle spill buffers does not affect other threads or ownership records.
int32_t fac_runtime_trim_thread() {
  if (g_csp != 0 || g_tsp != 0) return 0;
  return g_cleanups.trim() && g_tmps.trim() && g_scratch_pool.trim() ? 1 : 0;
}
// Class object storage: an atomic refcount and drop callback live immediately
// before the object payload. The payload pointer remains ABI-compatible with
// ptr %S.Class, so methods can use it as their `this` address.
// vtbl: ตาราง virtual method ของ "ชนิดจริง" ของ object -- void*[2N+1] = {N, sel1, fn1, sel2, fn2, ...}; header 64 ไบต์ให้ payload คง alignment 16
// (คอมไพเลอร์เข้าถึง vtbl ผ่าน fac_vcall เท่านั้น จึงไม่ผูกกับ offset ใน IR)
static constexpr uint32_t FAC_WEAK_NO_SLOT = UINT32_MAX;
static constexpr uint32_t FAC_WEAK_STATE_COUNT_BITS = 39;
static constexpr uint32_t FAC_WEAK_STATE_GEN_SHIFT = 40;
static constexpr uint64_t FAC_WEAK_STATE_COUNT_MASK = (uint64_t(1) << FAC_WEAK_STATE_COUNT_BITS) - 1u;
static constexpr uint64_t FAC_WEAK_STATE_ANCHOR = uint64_t(1) << FAC_WEAK_STATE_COUNT_BITS;
struct FacWeakSlot {
  // Generation, object-anchor bit and external-handle count share one CAS word.
  // This lets stale tokens fail atomically even when a slot is quickly reused.
  std::atomic<uint64_t> state{uint64_t(1) << FAC_WEAK_STATE_GEN_SHIFT};
  std::atomic<void *> object{nullptr};
  uint32_t slotIndex = FAC_WEAK_NO_SLOT;
  uint32_t nextFree = FAC_WEAK_NO_SLOT; // protected by g_obj_mu
};
struct alignas(16) FacObjHeader {
  std::atomic<int64_t> refs;
  void (*drop)(void *);       // release managed fields
  void **vtbl;
  void (*trace)(void *);      // enumerate strong object-field edges
  void (*finalize)(void *);   // run user destructors before releasing any fields
  FacWeakSlot *weak;          // stable slot-backed weak control; detached before finalization
  void *pad[2];               // keep payload 16-byte aligned (64-byte header)
};
// The registry is protected together with refcount transitions. Cycle collection
// is explicit and must run at a quiescent point: FAC code must not mutate object
// fields from another thread while memory.collectCycles() is executing.
static std::recursive_mutex g_obj_mu;
enum FacObjRegistryState : uint8_t {
  FAC_OBJ_LIVE = 0,
  FAC_OBJ_DESTROYING = 1,
  FAC_OBJ_CYCLE_DESTROYING = 2
};
// One registry records both liveness and the short destruction window. Keeping
// the state in the existing registry avoids a second hash node/allocation for
// every final release while letting C ABI entry points validate pointers before
// reading their headers. The count tracks live objects only.
static std::unordered_map<void *, uint8_t> g_obj_registry;
// Public weak handles are opaque pointer-sized generation tokens, not pointers
// to runtime memory. Slot blocks are allocated lazily and never moved/freed, so
// readers can safely inspect atomics without a global mutex or reclamation hazard.
// Generation is included in the same atomic word as the external handle count;
// stale tokens therefore cannot retain/release a newly reused slot.
#if UINTPTR_MAX > UINT32_MAX
static constexpr uint32_t FAC_WEAK_SLOT_BITS = 23;
static constexpr uint32_t FAC_WEAK_GENERATION_BITS = 24;
#else
static constexpr uint32_t FAC_WEAK_SLOT_BITS = 12;
static constexpr uint32_t FAC_WEAK_GENERATION_BITS = 19;
#endif
static constexpr uint32_t FAC_WEAK_SLOT_MASK = (1u << FAC_WEAK_SLOT_BITS) - 1u;
static constexpr uint32_t FAC_WEAK_GENERATION_MAX = (1u << FAC_WEAK_GENERATION_BITS) - 1u;
static constexpr uintptr_t FAC_WEAK_TOKEN_MASK = (uintptr_t(1) << (FAC_WEAK_SLOT_BITS + FAC_WEAK_GENERATION_BITS)) - 1u;
static constexpr uint32_t FAC_WEAK_BLOCK_BITS = 10;
static constexpr uint32_t FAC_WEAK_BLOCK_SIZE = 1u << FAC_WEAK_BLOCK_BITS;
static constexpr uint32_t FAC_WEAK_BLOCK_COUNT = 1u << (FAC_WEAK_SLOT_BITS - FAC_WEAK_BLOCK_BITS);
struct FacWeakSlotBlock { FacWeakSlot slots[FAC_WEAK_BLOCK_SIZE]; };
static std::atomic<FacWeakSlotBlock *> g_weak_blocks[FAC_WEAK_BLOCK_COUNT]{};
static uint32_t g_weak_slot_count = 0; // protected by g_obj_mu
static uint32_t g_weak_free_head = FAC_WEAK_NO_SLOT; // protected by g_obj_mu
static uint64_t g_obj_live_count = 0; // protected by g_obj_mu
static thread_local std::vector<void *> *g_cycle_edges = nullptr;
static std::atomic<bool> g_cycle_collecting{false};

// Restore the collector's process-wide exclusion flag and this thread's trace
// context on every C++ exit path. In particular, a failed trace/allocation must
// not leave later memory.collectCycles() calls permanently disabled.
struct FacCycleCollectionStateGuard {
  std::vector<void *> *previousEdges = g_cycle_edges;
  bool active = true;

  void reset() noexcept {
    if (!active) return;
    g_cycle_edges = previousEdges;
    g_cycle_collecting.store(false, std::memory_order_release);
    active = false;
  }

  ~FacCycleCollectionStateGuard() { reset(); }
};

void fac_cycle_visit(void *obj) {
  if (obj && g_cycle_edges) g_cycle_edges->push_back(obj);
}
void *fac_vcall(void *obj, int64_t sel) {
  if (!obj) do_throw("เรียก method ผ่าน object ที่เป็น null", 7);
  void **vt = (reinterpret_cast<FacObjHeader *>(obj) - 1)->vtbl;
  int64_t n = vt ? (int64_t)(intptr_t)vt[0] : 0;
  for (int64_t i = 0; i < n; i++) if ((int64_t)(intptr_t)vt[1 + 2 * i] == sel) return vt[2 + 2 * i];
  do_throw("object ไม่มี method ที่เรียก (virtual table ไม่ตรง)", 7);
  return nullptr;
}
// instanceof / downcast: คืน vtbl ของ "ชนิดจริง" (null ถ้า obj เป็น null) -- compiler เทียบกับ @vtbl.<Class> ของลูกหลานทุกตัว
void *fac_obj_vtbl(void *obj) { return obj ? static_cast<void *>((reinterpret_cast<FacObjHeader *>(obj) - 1)->vtbl) : nullptr; }
[[noreturn]] void fac_cast_fail(FacStr *msg) { do_throw(std::string("downcast ล้มเหลว: object ไม่ใช่ชนิด ") + sd(msg), 7); }
// hook ของ list dyn obj Name: slot = ตำแหน่งของตัวชี้ object ใน list (ถือ 1 reference ต่อ slot)
void fac_obj_slot_drop(void *slot) { fac_obj_release(*static_cast<void **>(slot)); }
void fac_obj_slot_copy(void *dst, const void *src) { void *o = *static_cast<void *const *>(src); fac_obj_retain(o); *static_cast<void **>(dst) = o; }
void *fac_obj_new(int64_t bytes, void *dropFn, void *vtbl, void *traceFn, void *finalizeFn) {
  if (bytes < 0 || (uint64_t)bytes > (uint64_t)SIZE_MAX - sizeof(FacObjHeader)) do_throw("class object size overflow", 7);
  size_t total = sizeof(FacObjHeader) + (size_t)(bytes > 0 ? bytes : 1);
  void *raw = fac_alloc((int64_t)total);
  auto *h = reinterpret_cast<FacObjHeader *>(raw);
  new (&h->refs) std::atomic<int64_t>(1);
  h->drop = reinterpret_cast<void (*)(void *)>(dropFn);
  h->vtbl = reinterpret_cast<void **>(vtbl);
  h->trace = reinterpret_cast<void (*)(void *)>(traceFn);
  h->finalize = reinterpret_cast<void (*)(void *)>(finalizeFn);
  h->weak = nullptr;
  h->pad[0] = h->pad[1] = nullptr;
  void *obj = reinterpret_cast<void *>(h + 1);
  try {
    std::lock_guard<std::recursive_mutex> lock(g_obj_mu);
    auto inserted = g_obj_registry.emplace(obj, FAC_OBJ_LIVE);
    if (!inserted.second) throw std::runtime_error("duplicate class object registry entry");
    ++g_obj_live_count;
  } catch (...) {
    h->refs.~atomic<int64_t>();
    fac_free(raw);
    do_throw("out of memory registering class object", 5);
  }
  return obj;
}

// Weak tokens reference permanent, lazily allocated slots rather than heap
// control blocks. Each slot packs generation, object-anchor state and external
// handle count into one atomic word. Slot blocks are kept for process lifetime;
// generation changes make stale tokens fail before they can affect a reused slot.
static void *fac_weak_token(uint32_t slotIndex, uint32_t generation) {
  const uintptr_t token = (uintptr_t(generation) << FAC_WEAK_SLOT_BITS) |
                          (uintptr_t(slotIndex) + 1u);
  return reinterpret_cast<void *>(token);
}
static FacWeakSlot *fac_weak_slot_at(uint32_t index) {
  const uint32_t blockIndex = index >> FAC_WEAK_BLOCK_BITS;
  if (blockIndex >= FAC_WEAK_BLOCK_COUNT) return nullptr;
  FacWeakSlotBlock *block = g_weak_blocks[blockIndex].load(std::memory_order_acquire);
  return block ? &block->slots[index & (FAC_WEAK_BLOCK_SIZE - 1u)] : nullptr;
}
static bool fac_weak_decode(void *opaque, FacWeakSlot *&slot, uint32_t &generation) {
  const uintptr_t token = reinterpret_cast<uintptr_t>(opaque);
  if (token == 0 || (token & ~FAC_WEAK_TOKEN_MASK) != 0) return false;
  const uint32_t slotValue = static_cast<uint32_t>(token & FAC_WEAK_SLOT_MASK);
  generation = static_cast<uint32_t>(token >> FAC_WEAK_SLOT_BITS);
  if (slotValue == 0 || generation == 0) return false;
  slot = fac_weak_slot_at(slotValue - 1u);
  return slot != nullptr;
}
static uint32_t fac_weak_state_generation(uint64_t state) {
  return static_cast<uint32_t>(state >> FAC_WEAK_STATE_GEN_SHIFT);
}
static uint64_t fac_weak_state_handles(uint64_t state) {
  return state & FAC_WEAK_STATE_COUNT_MASK;
}
static bool fac_weak_allocate_slot_locked(void *object, FacWeakSlot *&result) {
  uint32_t index = FAC_WEAK_NO_SLOT;
  const bool reused = g_weak_free_head != FAC_WEAK_NO_SLOT;
  if (reused) {
    index = g_weak_free_head;
    FacWeakSlot *slot = fac_weak_slot_at(index);
    if (!slot) return false;
    g_weak_free_head = slot->nextFree;
    slot->nextFree = FAC_WEAK_NO_SLOT;
    result = slot;
  } else {
    if (g_weak_slot_count >= FAC_WEAK_SLOT_MASK) return false;
    index = g_weak_slot_count;
    const uint32_t blockIndex = index >> FAC_WEAK_BLOCK_BITS;
    if (!g_weak_blocks[blockIndex].load(std::memory_order_acquire)) {
      // Throwing allocation is caught and translated by fac_obj_weak().
      auto *block = new FacWeakSlotBlock;
      g_weak_blocks[blockIndex].store(block, std::memory_order_release);
    }
    result = fac_weak_slot_at(index);
    if (!result) return false;
    ++g_weak_slot_count;
  }
  if (!result) return false;
  const uint64_t state = result->state.load(std::memory_order_acquire);
  const uint32_t generation = fac_weak_state_generation(state);
  if (generation == 0 || generation > FAC_WEAK_GENERATION_MAX ||
      (state & (FAC_WEAK_STATE_ANCHOR | FAC_WEAK_STATE_COUNT_MASK)) != 0) {
    if (reused) {
      result->nextFree = g_weak_free_head;
      g_weak_free_head = index;
    } else {
      --g_weak_slot_count;
    }
    result = nullptr;
    return false;
  }
  result->slotIndex = index;
  result->object.store(object, std::memory_order_release);
  result->state.store((uint64_t(generation) << FAC_WEAK_STATE_GEN_SHIFT) |
                      FAC_WEAK_STATE_ANCHOR, std::memory_order_release);
  return true;
}
// Caller holds g_obj_mu. Retire an already-empty, anchor-free slot by changing
// its generation atomically before linking it into the free list.
static void fac_weak_retire_slot_locked(FacWeakSlot *slot, uint32_t generation) {
  if (!slot) return;
  uint64_t expected = uint64_t(generation) << FAC_WEAK_STATE_GEN_SHIFT;
  if (generation >= FAC_WEAK_GENERATION_MAX) return; // permanently retire; never wrap
  const uint64_t retired = uint64_t(generation + 1u) << FAC_WEAK_STATE_GEN_SHIFT;
  if (slot->state.compare_exchange_strong(expected, retired,
                                          std::memory_order_acq_rel,
                                          std::memory_order_acquire)) {
    slot->nextFree = g_weak_free_head;
    g_weak_free_head = slot->slotIndex;
  }
}
static void fac_weak_drop_anchor_locked(FacWeakSlot *slot) {
  if (!slot) return;
  slot->object.store(nullptr, std::memory_order_release);
  uint64_t state = slot->state.load(std::memory_order_acquire);
  for (;;) {
    const uint32_t generation = fac_weak_state_generation(state);
    if (generation == 0 || !(state & FAC_WEAK_STATE_ANCHOR)) return;
    const uint64_t handles = fac_weak_state_handles(state);
    uint64_t next = state & ~FAC_WEAK_STATE_ANCHOR;
    if (handles == 0) {
      if (generation < FAC_WEAK_GENERATION_MAX)
        next = uint64_t(generation + 1u) << FAC_WEAK_STATE_GEN_SHIFT;
      else
        next = uint64_t(generation) << FAC_WEAK_STATE_GEN_SHIFT;
    }
    if (slot->state.compare_exchange_weak(state, next,
                                          std::memory_order_acq_rel,
                                          std::memory_order_acquire)) {
      if (handles == 0 && generation < FAC_WEAK_GENERATION_MAX) {
        slot->nextFree = g_weak_free_head;
        g_weak_free_head = slot->slotIndex;
      }
      return;
    }
  }
}
void *fac_obj_weak(void *p) {
  if (!p) return nullptr;
  std::unique_lock<std::recursive_mutex> objectLock(g_obj_mu);
  auto registered = g_obj_registry.find(p);
  if (registered == g_obj_registry.end() || registered->second != FAC_OBJ_LIVE) return nullptr;
  auto *h = reinterpret_cast<FacObjHeader *>(p) - 1;
  if (h->refs.load(std::memory_order_acquire) <= 0) return nullptr;
  FacWeakSlot *w = h->weak;
  if (!w) {
    try {
      if (!fac_weak_allocate_slot_locked(p, w)) {
        objectLock.unlock();
        do_throw("weak reference handle slot limit reached", 5);
      }
    } catch (const std::bad_alloc &) {
      objectLock.unlock();
      do_throw("out of memory registering weak reference handle", 5);
    } catch (...) {
      objectLock.unlock();
      do_throw("failed to register weak reference handle", 7);
    }
    h->weak = w;
  }
  uint64_t state = w->state.load(std::memory_order_relaxed);
  for (;;) {
    const uint32_t generation = fac_weak_state_generation(state);
    const uint64_t handles = fac_weak_state_handles(state);
    if (generation == 0 || !(state & FAC_WEAK_STATE_ANCHOR) || handles == FAC_WEAK_STATE_COUNT_MASK) {
      objectLock.unlock();
      do_throw("weak reference handle count overflow", 7);
    }
    if (w->state.compare_exchange_weak(state, state + 1u,
                                       std::memory_order_acq_rel,
                                       std::memory_order_relaxed))
      return fac_weak_token(w->slotIndex, generation);
  }
}
void fac_obj_weak_retain(void *p) {
  if (!p) return;
  FacWeakSlot *slot = nullptr;
  uint32_t generation = 0;
  if (!fac_weak_decode(p, slot, generation))
    do_throw("cannot retain an invalid or expired weak reference handle", 7);
  uint64_t state = slot->state.load(std::memory_order_acquire);
  for (;;) {
    const uint64_t handles = fac_weak_state_handles(state);
    if (fac_weak_state_generation(state) != generation || handles == 0) 
      do_throw("cannot retain an invalid or expired weak reference handle", 7);
    if (handles == FAC_WEAK_STATE_COUNT_MASK)
      do_throw("weak reference handle count overflow", 7);
    if (slot->state.compare_exchange_weak(state, state + 1u,
                                          std::memory_order_acq_rel,
                                          std::memory_order_acquire)) return;
  }
}
void fac_obj_weak_release(void *p) {
  if (!p) return;
  FacWeakSlot *slot = nullptr;
  uint32_t generation = 0;
  if (!fac_weak_decode(p, slot, generation))
    do_throw("cannot release an invalid or expired weak reference handle", 7);
  uint64_t state = slot->state.load(std::memory_order_acquire);
  for (;;) {
    const uint64_t handles = fac_weak_state_handles(state);
    if (fac_weak_state_generation(state) != generation || handles == 0)
      do_throw("cannot release an invalid or expired weak reference handle", 7);
    const uint64_t next = state - 1u;
    if (slot->state.compare_exchange_weak(state, next,
                                          std::memory_order_acq_rel,
                                          std::memory_order_acquire)) {
      if (handles == 1 && !(next & FAC_WEAK_STATE_ANCHOR)) {
        std::lock_guard<std::recursive_mutex> lock(g_obj_mu);
        fac_weak_retire_slot_locked(slot, generation);
      }
      return;
    }
  }
}
int32_t fac_obj_weak_alive(void *p) {
  if (!p) return 0;
  FacWeakSlot *slot = nullptr;
  uint32_t generation = 0;
  if (!fac_weak_decode(p, slot, generation)) return 0;
  const uint64_t before = slot->state.load(std::memory_order_acquire);
  if (fac_weak_state_generation(before) != generation || fac_weak_state_handles(before) == 0) return 0;
  void *object = slot->object.load(std::memory_order_acquire);
  const uint64_t after = slot->state.load(std::memory_order_acquire);
  if (fac_weak_state_generation(after) != generation || fac_weak_state_handles(after) == 0) return 0;
  return object != nullptr ? 1 : 0;
}
void *fac_obj_weak_lock(void *p) {
  if (!p) return nullptr;
  std::unique_lock<std::recursive_mutex> objectLock(g_obj_mu);
  FacWeakSlot *slot = nullptr;
  uint32_t generation = 0;
  if (!fac_weak_decode(p, slot, generation)) return nullptr;
  uint64_t state = slot->state.load(std::memory_order_acquire);
  if (fac_weak_state_generation(state) != generation || fac_weak_state_handles(state) == 0) return nullptr;
  void *obj = slot->object.load(std::memory_order_acquire);
  if (!obj) return nullptr;
  auto registered = g_obj_registry.find(obj);
  if (registered == g_obj_registry.end() || registered->second != FAC_OBJ_LIVE) return nullptr;
  auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
  int64_t cur = h->refs.load(std::memory_order_acquire);
  for (;;) {
    if (cur <= 0) return nullptr;
    if (cur == INT64_MAX) {
      objectLock.unlock();
      do_throw("class object reference count overflow while locking weak reference", 7);
    }
    if (h->refs.compare_exchange_weak(cur, cur + 1, std::memory_order_acq_rel, std::memory_order_acquire)) return obj;
  }
}
static void fac_obj_detach_weak(FacObjHeader *h) {
  // Caller holds g_obj_mu; slot memory is permanent and generation CAS protects reuse.
  FacWeakSlot *w = h->weak;
  h->weak = nullptr;
  if (!w) return;
  fac_weak_drop_anchor_locked(w);
}

void fac_obj_retain(void *p) {
  if (!p) return;
  std::unique_lock<std::recursive_mutex> lock(g_obj_mu);
  // Retain is only valid for a currently-owned strong handle. In particular,
  // do not inspect the header of a freed/stale pointer supplied through an
  // unchecked native boundary.
  auto registered = g_obj_registry.find(p);
  if (registered == g_obj_registry.end() || registered->second != FAC_OBJ_LIVE) {
    lock.unlock();
    do_throw("cannot retain a non-live class object", 7);
  }
  auto *h = reinterpret_cast<FacObjHeader *>(p) - 1;
  int64_t cur = h->refs.load(std::memory_order_acquire);
  for (;;) {
    if (cur == -1) { lock.unlock(); do_throw("ไม่สามารถ retain object ระหว่าง cycle collection/destruction ได้", 7); }
    if (cur <= 0) { lock.unlock(); do_throw("class object reference count underflow", 7); }
    if (cur == INT64_MAX) { lock.unlock(); do_throw("class object reference count overflow", 7); }
    if (h->refs.compare_exchange_weak(cur, cur + 1, std::memory_order_acq_rel, std::memory_order_acquire)) return;
  }
}
// Object finalizers and field-drop callbacks are user/generated FAC code. A
// FAC error in either callback must not longjmp past the remainder of object
// destruction: the object has already left the live registry and cannot be
// recovered by the caller. Catch callback errors at this narrow boundary,
// finish releasing the object graph, then rethrow the first error.
struct FacDeferredCallbackError {
  char message[1024]{};
  int32_t code = 0;
  bool pending = false;
};
// Nested object releases share the outer destruction error sink. A child
// finalizer/drop error is recorded here instead of being rethrown through the
// parent's generated field-drop callback, allowing the parent to release its
// remaining owned fields before the first error is reported.
static thread_local FacDeferredCallbackError *g_object_callback_error_sink = nullptr;

static void fac_defer_object_callback_error(FacDeferredCallbackError &firstError,
                                            const char *message, size_t length,
                                            int32_t code) {
  if (firstError.pending) return;
  const size_t count = std::min(length, sizeof(firstError.message) - 1);
  if (count) memcpy(firstError.message, message, count);
  firstError.message[count] = '\0';
  firstError.code = code;
  firstError.pending = true;
}

// Trace callbacks are generated and normally only call fac_cycle_visit(), but
// keep a local FAC error boundary as well as a C++ exception boundary. Without
// it, a FAC longjmp would bypass the collector's lock/state cleanup and leave
// the process-wide collection flag set forever.
static bool fac_trace_cycle_object(void (*trace)(void *), void *object,
                                   std::vector<void *> &edges,
                                   char *errorMessage, size_t errorCapacity,
                                   int32_t &errorCode) {
  std::vector<void *> *previous = g_cycle_edges;
  g_cycle_edges = &edges;
  if (g_hsp >= 256) {
    g_cycle_edges = previous;
    static constexpr char message[] = "cycle trace exceeded FAC try-handler nesting limit";
    const size_t count = std::min(sizeof(message) - 1, errorCapacity ? errorCapacity - 1 : 0);
    if (count) memcpy(errorMessage, message, count);
    if (errorCapacity) errorMessage[count] = '\0';
    errorCode = 8;
    return false;
  }

  void *handler[5]{};
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    try {
      trace(object);
    } catch (...) {
      fac_try_leave();
      g_cycle_edges = previous;
      throw;
    }
    fac_try_leave();
    g_cycle_edges = previous;
    return true;
  }

  // do_throw already popped this local handler and restored its FAC cleanup
  // depths before jumping back here. Copy the diagnostic before returning.
  const size_t count = std::min(g_errmsg.size(), errorCapacity ? errorCapacity - 1 : 0);
  if (count) memcpy(errorMessage, g_errmsg.data(), count);
  if (errorCapacity) errorMessage[count] = '\0';
  errorCode = g_errcode;
  g_cycle_edges = previous;
  return false;
}

static void fac_run_object_callback(void (*callback)(void *), void *object,
                                    FacDeferredCallbackError &firstError) {
  if (!callback) return;
  void *handler[5]{};
  fac_try_enter(handler);

  // The outermost callback owns the error sink. Nested fac_obj_release() calls
  // reuse it, so a child's error is deferred until the whole ownership graph
  // has been dropped rather than escaping through the parent's field-drop
  // callback and skipping its remaining fields.
  FacDeferredCallbackError *previousSink = g_object_callback_error_sink;
  const bool ownsSink = previousSink == nullptr;
  if (ownsSink) g_object_callback_error_sink = &firstError;
  FacDeferredCallbackError *sink = ownsSink ? &firstError : previousSink;

  if (__builtin_setjmp(handler) == 0) {
    try {
      callback(object);
    } catch (...) {
      static constexpr char message[] = "FAC object callback raised a C++ exception";
      fac_defer_object_callback_error(*sink, message, sizeof(message) - 1, 7);
    }
    fac_try_leave();
  } else {
    fac_defer_object_callback_error(*sink, g_errmsg.data(), g_errmsg.size(), g_errcode);
  }

  if (ownsSink) g_object_callback_error_sink = previousSink;
}

[[noreturn]] static void fac_rethrow_object_callback_error(const FacDeferredCallbackError &error) {
  do_throw(std::string(error.message), error.code);
}

void fac_obj_release(void *p) {
  if (!p) return;
  std::unique_lock<std::recursive_mutex> lock(g_obj_mu);
  auto registered = g_obj_registry.find(p);
  if (registered == g_obj_registry.end()) {
    lock.unlock();
    do_throw("cannot release a non-live class object", 7);
  }
  // During cycle collection, generated field drops release peer edges after
  // the entire dead set has been unlinked. Those releases were historically
  // ignored by the -1 header sentinel; preserve that behavior without reading
  // a peer header while it is being destroyed.
  if (registered->second == FAC_OBJ_CYCLE_DESTROYING) return;
  if (registered->second != FAC_OBJ_LIVE) {
    lock.unlock();
    do_throw("class object reference count underflow", 7);
  }

  auto *h = reinterpret_cast<FacObjHeader *>(p) - 1;
  int64_t cur = h->refs.load(std::memory_order_acquire);
  for (;;) {
    if (cur <= 0) { lock.unlock(); do_throw("class object reference count underflow", 7); }
    const bool registeringDestruction = cur == 1;
    if (registeringDestruction) {
      // Change state in the existing registry node before decrementing to
      // zero. This requires no new allocation on the final-release path.
      registered->second = FAC_OBJ_DESTROYING;
      --g_obj_live_count;
    }
    if (!h->refs.compare_exchange_weak(cur, cur - 1, std::memory_order_acq_rel, std::memory_order_acquire)) {
      if (registeringDestruction) {
        registered->second = FAC_OBJ_LIVE;
        ++g_obj_live_count;
      }
      continue;
    }
    if (cur != 1) return;
    fac_obj_detach_weak(h);
    lock.unlock();
    // Do not hold the registry lock while calling user destructor code. The
    // callback boundary catches FAC longjmp errors so `drop` and storage free
    // still run even when a user finalizer fails.
    FacDeferredCallbackError callbackError;
    fac_run_object_callback(h->finalize, p, callbackError);
    fac_run_object_callback(h->drop, p, callbackError);
    {
      // Remove the registry node and free storage while holding the same lock
      // used by fac_obj_new, so the address cannot be registered as another
      // object before the old destruction record is cleared.
      std::lock_guard<std::recursive_mutex> finishLock(g_obj_mu);
      g_obj_registry.erase(p);
      h->refs.~atomic<int64_t>();
      fac_free(h);
    }
    if (callbackError.pending) fac_rethrow_object_callback_error(callbackError);
    return;
  }
}

// Trial-deletion collector for cycles made exclusively from object-valued class
// fields (including object fields nested inside by-value structs). References
// held by locals, lists, closures, FFI, etc. are external roots because they are
// not represented by the generated trace callbacks.
int64_t fac_obj_collect_cycles() {
  bool expected = false;
  if (!g_cycle_collecting.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) return 0;
  FacCycleCollectionStateGuard collectionState;

  int64_t collected = 0;
  FacDeferredCallbackError callbackError;
  char collectionError[128]{};
  int32_t collectionErrorCode = 0;
  {
    // Keep every STL container and the registry lock in this inner scope.
    // FAC errors are rethrown only after leaving it, so longjmp cannot skip
    // these C++ destructors.
    std::unique_lock<std::recursive_mutex> lock(g_obj_mu);
    std::vector<void *> edges;
    std::vector<void *> objects;
    std::vector<size_t> work;
    std::vector<void *> dead;
    // One pointer-to-index table replaces the former live/incoming/marked
    // hash containers. Incoming counts and mark state live in contiguous arrays,
    // cutting per-object hash-node allocations while preserving average O(1)
    // membership checks for both edge counting and root marking.
    std::unordered_map<void *, size_t> objectIndex;
    std::vector<int64_t> incoming;
    std::vector<uint8_t> marked;
    try {
      objects.reserve(static_cast<size_t>(g_obj_live_count));
      for (const auto &entry : g_obj_registry)
        if (entry.second == FAC_OBJ_LIVE) objects.push_back(entry.first);
      // A moderate load factor keeps edge lookups quick on dense graphs while
      // using only one hash table for all graph membership queries.
      objectIndex.max_load_factor(0.75f);
      objectIndex.reserve(objects.size());
      for (size_t i = 0; i < objects.size(); ++i)
        objectIndex.emplace(objects[i], i);
      incoming.assign(objects.size(), 0);
      marked.assign(objects.size(), 0);
      work.reserve(objects.size());
      dead.reserve(objects.size());

      // Count strong edges wholly contained in the managed object graph.
      // If a trace callback reports a FAC error, abort before changing any
      // registry/refcount state; the caller may repair/retry collection later.
      bool traceFailed = false;
      for (void *obj : objects) {
        auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
        if (!h->trace) continue;
        edges.clear();
        if (!fac_trace_cycle_object(h->trace, obj, edges, collectionError,
                                    sizeof(collectionError), collectionErrorCode)) {
          traceFailed = true;
          break;
        }
        for (void *child : edges) {
          const auto it = objectIndex.find(child);
          if (it != objectIndex.end()) {
            int64_t &count = incoming[it->second];
            if (count < INT64_MAX) ++count;
          }
        }
      }

      if (!traceFailed) {
        // Any reference not explained by a traced object field is an external root.
        // A count mismatch in either direction is conservatively treated as rooted.
        for (size_t i = 0; i < objects.size(); ++i) {
          auto *h = reinterpret_cast<FacObjHeader *>(objects[i]) - 1;
          const int64_t refs = h->refs.load(std::memory_order_acquire);
          if (refs != incoming[i]) { marked[i] = 1; work.push_back(i); }
        }

        // Mark all objects reachable from roots; the rest are unreachable cycles.
        while (!work.empty()) {
          const size_t index = work.back(); work.pop_back();
          void *obj = objects[index];
          auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
          if (!h->trace) continue;
          edges.clear();
          if (!fac_trace_cycle_object(h->trace, obj, edges, collectionError,
                                      sizeof(collectionError), collectionErrorCode)) {
            traceFailed = true;
            break;
          }
          for (void *child : edges) {
            const auto it = objectIndex.find(child);
            if (it != objectIndex.end() && !marked[it->second]) {
              marked[it->second] = 1;
              work.push_back(it->second);
            }
          }
        }
      }

      if (!traceFailed) {
        for (size_t i = 0; i < objects.size(); ++i)
          if (!marked[i]) dead.push_back(objects[i]);
        // Mark and unlink the whole dead set before running user code. State
        // changes reuse existing registry nodes, so this phase cannot allocate.
        // It also lets peer releases recognize cycle-batch teardown without
        // dereferencing a header whose destruction has started.
        for (void *obj : dead) {
          auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
          auto registered = g_obj_registry.find(obj);
          if (registered != g_obj_registry.end() && registered->second == FAC_OBJ_LIVE) {
            registered->second = FAC_OBJ_CYCLE_DESTROYING;
            --g_obj_live_count;
          }
          h->refs.store(-1, std::memory_order_release);
          fac_obj_detach_weak(h);
        }
        lock.unlock();

        // Two-phase destruction: every user destructor sees all cycle peers and
        // their managed fields still alive; only then are any managed fields freed.
        // A callback error is deferred so every peer is finalized and released.
        for (void *obj : dead) {
          auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
          fac_run_object_callback(h->finalize, obj, callbackError);
        }
        for (void *obj : dead) {
          auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
          fac_run_object_callback(h->drop, obj, callbackError);
        }
        {
          // As with single-object release, keep registry state and allocator
          // address reuse ordered under the object mutex.
          std::lock_guard<std::recursive_mutex> finishLock(g_obj_mu);
          for (void *obj : dead) {
            auto *h = reinterpret_cast<FacObjHeader *>(obj) - 1;
            g_obj_registry.erase(obj);
            h->refs.~atomic<int64_t>();
            fac_free(h);
          }
        }
        collected = (int64_t)dead.size();
      }
    } catch (const std::bad_alloc &) {
      g_cycle_edges = collectionState.previousEdges;
      if (lock.owns_lock()) lock.unlock();
      static constexpr char message[] = "out of memory during cycle collection";
      memcpy(collectionError, message, sizeof(message));
      collectionErrorCode = 5;
    } catch (...) {
      g_cycle_edges = collectionState.previousEdges;
      if (lock.owns_lock()) lock.unlock();
      static constexpr char message[] = "unexpected failure during cycle collection";
      memcpy(collectionError, message, sizeof(message));
      collectionErrorCode = 7;
    }
  }

  // Clear collector state before translating a deferred FAC error. The guard
  // also covers C++ exceptions raised before the inner collection try block.
  collectionState.reset();
  if (collectionErrorCode) do_throw(std::string(collectionError), collectionErrorCode);
  if (callbackError.pending) fac_rethrow_object_callback_error(callbackError);
  return collected;
}
uint64_t fac_obj_live_count() {
  std::lock_guard<std::recursive_mutex> lock(g_obj_mu);
  return g_obj_live_count;
}

// Closure layout: { function pointer, signed reference count, drop callback, captures... }.
// A negative count marks compiler-emitted static closures as immortal.
struct FacClosureHeader { void *fn; int64_t refs; void (*drop)(void *); };
void fac_closure_retain(void *p) {
  if (!p) return;
  auto *c = reinterpret_cast<FacClosureHeader *>(p);
  int64_t *refs = &c->refs;
  int64_t cur = __atomic_load_n(refs, __ATOMIC_ACQUIRE);
  while (cur >= 0) {
    // Callers must already own a reference while retaining; in particular,
    // fac_thread_start retains before publishing the callback to its worker.
    // Never let signed overflow turn a live closure into an immortal one.
    if (cur == INT64_MAX) do_throw("closure reference count overflow", 7);
    if (__atomic_compare_exchange_n(refs, &cur, cur + 1, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) return;
  }
}
void fac_closure_release(void *p) {
  if (!p) return;
  auto *c = reinterpret_cast<FacClosureHeader *>(p);
  int64_t *refs = &c->refs;
  int64_t cur = __atomic_load_n(refs, __ATOMIC_ACQUIRE);
  for (;;) {
    if (cur < 0) return; // compiler-emitted static closure: immortal
    if (cur <= 0) do_throw("closure reference count underflow", 7);
    int64_t next = cur - 1;
    if (!__atomic_compare_exchange_n(refs, &cur, next, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) continue;
    if (next != 0) return;
    void (*drop)(void *) = c->drop;
    if (drop) drop(p);
    fac_free(p);
    return;
  }
}
static size_t fac_checked_mem_size(int64_t n) {
  if (n < 0 || (uint64_t)n > (uint64_t)SIZE_MAX) do_throw("invalid memory-operation size", 5);
  return (size_t)n;
}
void fac_memcpy(void *d, const void *s, int64_t n) {
  size_t z = fac_checked_mem_size(n); if (!z) return;
  if (!d || !s) do_throw("null pointer in memory copy", 6);
  memmove(d, s, z);
}
void fac_memset(void *d, int32_t v, int64_t n) {
  size_t z = fac_checked_mem_size(n); if (!z) return;
  if (!d) do_throw("null pointer in memory set", 6);
  memset(d, v, z);
}
int32_t fac_memcmp(const void *a, const void *b, int64_t n) {
  size_t z = fac_checked_mem_size(n); if (!z) return 0;
  if (!a || !b) do_throw("null pointer in memory compare", 6);
  return memcmp(a, b, z);
}

// ---------------------------------------------------------------- strings
static int64_t countcp(const char *p, int64_t n) { int64_t c = 0; for (int64_t i = 0; i < n; i++) c += ((p[i] & 0xC0) != 0x80); return c; }
static FacStr *mk(const char *p, int64_t n) {
  if (n < 0 || (n && !p) || (uint64_t)n > (uint64_t)SIZE_MAX - sizeof(FacStr) - 1)
    do_throw("string size or source is invalid", 5);
  // Header and UTF-8 bytes share one allocation: one malloc/free pair per string.
  FacStr *s = (FacStr *)fac_alloc_uninit((int64_t)(sizeof(FacStr) + (size_t)n + 1));
  s->data = reinterpret_cast<char *>(s + 1);
  if (n) memcpy(s->data, p, (size_t)n);
  s->data[n] = 0; s->len = n; s->cap = n; s->ncp = countcp(p ? p : "", n); s->flags = 2; // one owning reference; bit0 is reserved for immortal literals
  return s;
}
static void enc(std::string &o, uint32_t c) {
  if (c > 0x10FFFFu || (c >= 0xD800u && c <= 0xDFFFu)) c = 0xFFFD;   // never emit invalid UTF-8 (surrogates, > U+10FFFF, negative ints): U+FFFD instead
  if (c < 0x80) o += (char)c;
  else if (c < 0x800) { o += (char)(0xC0 | (c >> 6)); o += (char)(0x80 | (c & 63)); }
  else if (c < 0x10000) { o += (char)(0xE0 | (c >> 12)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
  else { o += (char)(0xF0 | (c >> 18)); o += (char)(0x80 | ((c >> 12) & 63)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
}
static uint32_t dec(const char *p, int *w) {  // strict + safe on broken/truncated UTF-8: never reads past the NUL, a bad sequence is 1 byte = U+FFFD
  unsigned char c = (unsigned char)p[0];
  auto cont = [&](int i) { return ((unsigned char)p[i] & 0xC0) == 0x80; };
  if (c < 0x80) { *w = 1; return c; }
  // overlong forms (C0/C1, E0 80..9F, F0 80..8F), UTF-16 surrogates (ED A0..BF) and values above U+10FFFF (F4 90.., F5..FF) are rejected:
  // accepting them lets one character have several encodings, which defeats byte-wise checks (the classic "overlong '/'" bypass)
  if (c >= 0xC2 && c <= 0xDF && cont(1)) { *w = 2; return ((c & 31u) << 6) | (p[1] & 63); }
  if ((c >> 4) == 14 && cont(1) && cont(2)) {
    unsigned char c1 = (unsigned char)p[1];
    if (!((c == 0xE0 && c1 < 0xA0) || (c == 0xED && c1 >= 0xA0))) { *w = 3; return ((c & 15u) << 12) | ((p[1] & 63u) << 6) | (p[2] & 63); }
  }
  if (c >= 0xF0 && c <= 0xF4 && cont(1) && cont(2) && cont(3)) {
    unsigned char c1 = (unsigned char)p[1];
    if (!((c == 0xF0 && c1 < 0x90) || (c == 0xF4 && c1 >= 0x90))) { *w = 4; return ((c & 7u) << 18) | ((p[1] & 63u) << 12) | ((p[2] & 63u) << 6) | (p[3] & 63); }
  }
  *w = 1; return 0xFFFD;
}
static int64_t cpoff(const FacStr *s, int64_t idx) {  // byte offset ของ code point ที่ idx
  if (!s) return 0;
  if (s->ncp == s->len) return idx;
  int64_t i = 0, c = 0;
  while (i < s->len && c < idx) { i++; while (i < s->len && (s->data[i] & 0xC0) == 0x80) i++; c++; }
  return i;
}
static FacStr *mks(const std::string &s) { return mk(s.data(), (int64_t)s.size()); }
// Strings are immutable after construction. Copies therefore share the same
// byte buffer and only adjust an atomic reference count instead of allocating
// and copying every byte. Bit 0 marks compiler-emitted immortal literals;
// bits 1..63 store refs*2 so the layout remains compatible with LLVM's i64.
FacStr *fac_str_dup(FacStr *s) {
  if (!s) return nullptr;
  int64_t old = __atomic_load_n(&s->flags, __ATOMIC_RELAXED);
  for (;;) {
    if (old & 1) return s;
    if (old <= 0) do_throw("string reference count is invalid", 5);
    if (old > INT64_MAX - 2) do_throw("string reference count overflow", 5);
    if (__atomic_compare_exchange_n(&s->flags, &old, old + 2, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) return s;
  }
}
void fac_str_free(FacStr *s) {
  if (!s) return;
  int64_t old = __atomic_load_n(&s->flags, __ATOMIC_RELAXED);
  if (old & 1) return; // immortal literal
  int64_t now = __atomic_sub_fetch(&s->flags, 2, __ATOMIC_ACQ_REL);
  if (now == 0) fac_free(s); // header and UTF-8 payload share one accounted allocation
  else if (now < 0) { fprintf(stderr, "FAC internal: string reference count underflow\n"); abort(); }
}
FacStr *fac_str_cat_many(FacStr *const *parts, int64_t count);
FacStr *fac_str_cat(FacStr *a, FacStr *b) {
  int64_t la = sl(a), lb = sl(b), ca = a ? a->ncp : 0, cb = b ? b->ncp : 0;
  if (la < 0 || lb < 0 || ca < 0 || cb < 0 || lb > INT64_MAX - la - 1 ||
      cb > INT64_MAX - ca || (uint64_t)(la + lb) >= (uint64_t)SIZE_MAX)
    do_throw("string concatenation size overflow", 5);
  if ((uint64_t)(la + lb) > (uint64_t)SIZE_MAX - sizeof(FacStr) - 1)
    do_throw("string concatenation size overflow", 5);
  FacStr *r = (FacStr *)fac_alloc_uninit((int64_t)(sizeof(FacStr) + (size_t)(la + lb) + 1));
  r->data = reinterpret_cast<char *>(r + 1);
  if (la) memcpy(r->data, sd(a), (size_t)la);
  if (lb) memcpy(r->data + la, sd(b), (size_t)lb);
  r->data[la + lb] = 0; r->len = r->cap = la + lb;
  r->ncp = ca + cb; r->flags = 2;
  return r;
}
FacStr *fac_str_cat_many(FacStr *const *parts, int64_t count) {
  if (count < 0 || (count && !parts)) do_throw("invalid string concatenation parts", 5);
  int64_t total = 0, codepoints = 0;
  for (int64_t i = 0; i < count; i++) {
    FacStr *p = parts[i];
    int64_t bytes = sl(p), cps = p ? p->ncp : 0;
    if (bytes < 0 || cps < 0 || bytes > INT64_MAX - total - 1 || cps > INT64_MAX - codepoints)
      do_throw("string concatenation size overflow", 5);
    total += bytes; codepoints += cps;
  }
  if ((uint64_t)total > (uint64_t)SIZE_MAX - sizeof(FacStr) - 1)
    do_throw("string concatenation size overflow", 5);
  FacStr *r = (FacStr *)fac_alloc_uninit((int64_t)(sizeof(FacStr) + (size_t)total + 1));
  r->data = reinterpret_cast<char *>(r + 1);
  int64_t offset = 0;
  for (int64_t i = 0; i < count; i++) {
    int64_t bytes = sl(parts[i]);
    if (bytes) memcpy(r->data + offset, parts[i]->data, (size_t)bytes);
    offset += bytes;
  }
  r->data[total] = 0; r->len = r->cap = total; r->ncp = codepoints; r->flags = 2;
  return r;
}
int32_t fac_str_eq(FacStr *a, FacStr *b) { int64_t la = sl(a); return la == sl(b) && (la == 0 || memcmp(a->data, b->data, (size_t)la) == 0); }
int32_t fac_str_cmp(FacStr *a, FacStr *b) {
  int64_t la = sl(a), lb = sl(b); int c = memcmp(sd(a), sd(b), (size_t)std::min(la, lb));
  return c ? (c < 0 ? -1 : 1) : (la < lb ? -1 : la > lb ? 1 : 0);
}
int32_t fac_str_len(FacStr *s) {
  int64_t n = s ? s->ncp : 0;
  if (n < 0 || n > INT32_MAX) do_throw("string length exceeds Int range", 5);
  return (int32_t)n;
}
int32_t fac_str_bytelen(FacStr *s) {
  int64_t n = sl(s);
  if (n < 0 || n > INT32_MAX) do_throw("string byte length exceeds Int range", 5);
  return (int32_t)n;
}
int32_t fac_str_at(FacStr *s, int64_t i) {
  int64_t n = s ? s->ncp : 0; if (i < 0 || i >= n) fac_oob(i, n);
  if (s->ncp == s->len) { unsigned char b = (unsigned char)s->data[i]; return b < 0x80 ? (int32_t)b : 0xFFFD; }   // every byte is a lead byte: bytes >= 0x80 are malformed
  int w; return (int32_t)dec(s->data + cpoff(s, i), &w);
}
FacStr *fac_str_slice(FacStr *s, int64_t a, int64_t b) {
  int64_t n = s ? s->ncp : 0;
  if (a < 0 || b > n || a > b) do_throw("slice out of range: [" + std::to_string(a) + ":" + std::to_string(b) + "] size " + std::to_string(n), 2);
  int64_t oa = cpoff(s, a), ob = cpoff(s, b); return mk(sd(s) + oa, ob - oa);
}
// Extended-grapheme approximation for editing/display. It covers combining
// marks, variation selectors, emoji modifiers/ZWJ sequences, RI flag pairs,
// common Indic marks and Thai vowel/tone marks without a heavyweight Unicode
// database. Full locale-aware shaping remains a font/rendering concern.
static bool fac_unicode_extend(uint32_t c) {
  return (c >= 0x0300 && c <= 0x036F) || (c >= 0x0483 && c <= 0x0489) ||
    (c >= 0x0591 && c <= 0x05BD) || c == 0x05BF || (c >= 0x05C1 && c <= 0x05C2) ||
    (c >= 0x0610 && c <= 0x061A) || (c >= 0x064B && c <= 0x065F) || c == 0x0670 ||
    (c >= 0x06D6 && c <= 0x06ED) || (c >= 0x0900 && c <= 0x0903) ||
    (c >= 0x093A && c <= 0x093C) || (c >= 0x093E && c <= 0x094F) ||
    (c >= 0x0951 && c <= 0x0957) || (c >= 0x1AB0 && c <= 0x1AFF) ||
    (c >= 0x1DC0 && c <= 0x1DFF) || (c >= 0x20D0 && c <= 0x20FF) ||
    (c >= 0xFE00 && c <= 0xFE0F) || (c >= 0xFE20 && c <= 0xFE2F) ||
    (c >= 0x1F3FB && c <= 0x1F3FF) || (c >= 0xE0100 && c <= 0xE01EF) ||
    c == 0x0E31 || (c >= 0x0E34 && c <= 0x0E3A) ||
    (c >= 0x0E47 && c <= 0x0E4E) || c == 0x0E33;
}
static bool fac_unicode_spacing_mark(uint32_t c) {
  return c == 0x0903 || (c >= 0x093B && c <= 0x0940) ||
    (c >= 0x0949 && c <= 0x094C) || (c >= 0x0982 && c <= 0x0983) ||
    (c >= 0x09BE && c <= 0x09C0) || (c >= 0x0A3E && c <= 0x0A40) ||
    (c >= 0x0ABE && c <= 0x0AC0) || (c >= 0x0B3E && c <= 0x0B40) ||
    (c >= 0x0BBE && c <= 0x0BC2) || (c >= 0x0C01 && c <= 0x0C03) ||
    (c >= 0x0D3E && c <= 0x0D40) || c == 0x0E30 || c == 0x0E32;
}
static bool fac_unicode_prepend(uint32_t c) {
  return (c >= 0x0600 && c <= 0x0605) || c == 0x06DD || c == 0x070F ||
    c == 0x08E2 || c == 0x110BD || (c >= 0x0E40 && c <= 0x0E44);
}
static bool fac_grapheme_control(uint32_t c) {
  return c == 0x000A || c == 0x000D || (c < 0x0020) || (c >= 0x007F && c <= 0x009F) ||
    c == 0x2028 || c == 0x2029;
}
static bool fac_grapheme_no_break(uint32_t prev, uint32_t cp, int riRun) {
  // GB3: CR x LF. Other controls force a boundary (GB4/GB5).
  if (prev == 0x000D && cp == 0x000A) return true;
  if (fac_grapheme_control(prev) || fac_grapheme_control(cp)) return false;
  // Common GB9/9a/9b and the ZWJ emoji sequence rule (GB11 approximation).
  bool noBreak = fac_unicode_extend(cp) || fac_unicode_spacing_mark(cp) || cp == 0x200D ||
    prev == 0x200D || fac_unicode_prepend(prev);
  // Pair regional indicators into flag clusters.
  if (prev >= 0x1F1E6 && prev <= 0x1F1FF && cp >= 0x1F1E6 && cp <= 0x1F1FF && (riRun & 1))
    noBreak = true;
  return noBreak;
}
static int64_t fac_grapheme_count(FacStr *s) {
  if (!s || !s->data || s->len <= 0) return 0;
  const char *q = s->data, *end = s->data + s->len;
  uint32_t prev = 0; int riRun = 0; int64_t count = 0; bool first = true;
  while (q < end) {
    int width = 1; uint32_t cp = dec(q, &width);
    if (first || !fac_grapheme_no_break(prev, cp, riRun)) count++;
    if (cp >= 0x1F1E6 && cp <= 0x1F1FF)
      riRun = (prev >= 0x1F1E6 && prev <= 0x1F1FF) ? riRun + 1 : 1;
    else riRun = 0;
    prev = cp; q += std::max(1, width); first = false;
  }
  return count;
}
// Return the byte offset at the beginning of cluster `target`; target==count
// returns the end offset. This streams UTF-8 once and performs no allocation.
static int64_t fac_grapheme_byte_offset(FacStr *s, int64_t target) {
  if (!s || !s->data || s->len <= 0 || target <= 0) return 0;
  const char *q = s->data, *end = s->data + s->len;
  uint32_t prev = 0; int riRun = 0; int64_t cluster = 0; bool first = true;
  while (q < end) {
    int width = 1; uint32_t cp = dec(q, &width);
    if (!first && !fac_grapheme_no_break(prev, cp, riRun)) {
      cluster++;
      if (cluster == target) return (int64_t)(q - s->data);
    }
    if (cp >= 0x1F1E6 && cp <= 0x1F1FF)
      riRun = (prev >= 0x1F1E6 && prev <= 0x1F1FF) ? riRun + 1 : 1;
    else riRun = 0;
    prev = cp; q += std::max(1, width); first = false;
  }
  return s->len;
}
int32_t fac_str_grapheme_len(FacStr *s) {
  int64_t n = fac_grapheme_count(s);
  if (n > INT32_MAX) do_throw("string grapheme length exceeds Int range", 5);
  return (int32_t)n;
}
FacStr *fac_str_grapheme_slice(FacStr *s, int64_t a, int64_t b) {
  int64_t n = fac_grapheme_count(s);
  if (a < 0 || b > n || a > b) do_throw("grapheme slice out of range: [" + std::to_string(a) + ":" + std::to_string(b) + "] size " + std::to_string(n), 2);
  int64_t oa = fac_grapheme_byte_offset(s, a), ob = fac_grapheme_byte_offset(s, b);
  const char *base = s ? s->data : "";
  return mk(base + oa, ob - oa);
}
FacStr *fac_str_from_i64(int64_t v) { return mks(std::to_string(v)); }
FacStr *fac_str_from_u64(uint64_t v) { return mks(std::to_string(v)); }
static std::string fmtd(double v) { char b[64]; auto r = std::to_chars(b, b + 64, v); std::string s(b, r.ptr); if (s.find_first_of(".en") == std::string::npos) s += ".0"; return s; }
static std::string fmtf(float v) { char b[64]; auto r = std::to_chars(b, b + 64, v); std::string s(b, r.ptr); if (s.find_first_of(".en") == std::string::npos) s += ".0"; return s; }
FacStr *fac_str_from_f64(double v) { return mks(fmtd(v)); }
FacStr *fac_str_from_f32(float v) { return mks(fmtf(v)); }
FacStr *fac_str_from_char(int32_t c) { std::string s; enc(s, (uint32_t)c); return mks(s); }
FacStr *fac_str_from_bool(int32_t b) { return mks(b ? "true" : "false"); }
FacStr *fac_str_from_chars(const char *p, int64_t n) {
  if (n < 0 || (n && !p)) do_throw("invalid character buffer", 5);
  int64_t k = 0; while (k < n && p[k]) k++; return mk(p, k);
}
FacStr *fac_str_from_unichars(const int32_t *p, int64_t n) {
  if (n < 0 || (n && !p)) do_throw("invalid Unicode buffer", 5);
  std::string s; for (int64_t i = 0; i < n && p[i]; i++) enc(s, (uint32_t)p[i]); return mks(s);
}

// เปลี่ยนตัวพิมพ์ใหญ่/เล็ก: ASCII + Latin-1 + Latin Extended-A + Greek + Cyrillic (ภาษาไทยไม่มีตัวพิมพ์)
static uint32_t cp_upper(uint32_t c) {
  if (c < 128) return (c >= 'a' && c <= 'z') ? c - 32 : c;
  if (c >= 0xE0 && c <= 0xFE && c != 0xF7) return c - 32;
  if (c == 0xFF) return 0x178;
  if (c >= 0x100 && c <= 0x17F) { if ((c >= 0x100 && c <= 0x137) || (c >= 0x14A && c <= 0x177)) return (c & 1) ? c - 1 : c; if ((c >= 0x139 && c <= 0x148) || (c >= 0x179 && c <= 0x17E)) return (c & 1) ? c : c - 1; return c; }
  if (c >= 0x3B1 && c <= 0x3C9) return c == 0x3C2 ? 0x3A3 : c - 32;
  if (c >= 0x430 && c <= 0x44F) return c - 32;
  if (c >= 0x450 && c <= 0x45F) return c - 80;
  return c;
}
static uint32_t cp_lower(uint32_t c) {
  if (c < 128) return (c >= 'A' && c <= 'Z') ? c + 32 : c;
  if (c >= 0xC0 && c <= 0xDE && c != 0xD7) return c + 32;
  if (c == 0x178) return 0xFF;
  if (c >= 0x100 && c <= 0x17F) { if ((c >= 0x100 && c <= 0x137) || (c >= 0x14A && c <= 0x177)) return (c & 1) ? c : c + 1; if ((c >= 0x139 && c <= 0x148) || (c >= 0x179 && c <= 0x17E)) return (c & 1) ? c + 1 : c; return c; }
  if (c >= 0x391 && c <= 0x3A9 && c != 0x3A2) return c + 32;
  if (c >= 0x410 && c <= 0x42F) return c + 32;
  if (c >= 0x400 && c <= 0x40F) return c + 80;
  return c;
}
static FacStr *recase(FacStr *s, uint32_t (*f)(uint32_t), bool firstOnly = false) {
  std::string r; const char *p = sd(s); int64_t n = sl(s);
  for (int64_t i = 0; i < n;) { int w; uint32_t c = dec(p + i, &w); if (!firstOnly || i == 0) c = f(c); enc(r, c); i += w; if (firstOnly && i < n) { r.append(p + i, (size_t)(n - i)); break; } }
  return mks(r);
}
FacStr *fac_str_upper(FacStr *s) { return recase(s, cp_upper); }
FacStr *fac_str_lower(FacStr *s) { return recase(s, cp_lower); }
FacStr *fac_str_capitalize_u(FacStr *s) { return recase(s, cp_upper, true); }
static bool isws(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f'; }
FacStr *fac_str_trim(FacStr *s) {
  int64_t a = 0, b = sl(s); while (a < b && isws(s->data[a])) a++; while (b > a && isws(s->data[b - 1])) b--;
  return mk(sd(s) + a, b - a);
}
static int64_t bfind(FacStr *s, FacStr *sub) {
  std::string_view h(sd(s), (size_t)sl(s)), n(sd(sub), (size_t)sl(sub)); size_t p = h.find(n);
  return p == std::string_view::npos ? -1 : (int64_t)p;
}
int32_t fac_str_find(FacStr *s, FacStr *sub) {
  int64_t p = bfind(s, sub); if (p < 0) return -1;
  int64_t index = countcp(sd(s), p);
  if (index > INT32_MAX) do_throw("string index exceeds Int range", 5);
  return (int32_t)index;
}
int32_t fac_str_contains(FacStr *s, FacStr *sub) { return bfind(s, sub) >= 0; }
int32_t fac_str_starts(FacStr *s, FacStr *p) { int64_t n = sl(p); return n <= sl(s) && memcmp(sd(s), sd(p), (size_t)n) == 0; }
int32_t fac_str_ends(FacStr *s, FacStr *p) { int64_t n = sl(p), m = sl(s); return n <= m && memcmp(sd(s) + m - n, sd(p), (size_t)n) == 0; }
FacStr *fac_str_replace(FacStr *s, FacStr *a, FacStr *b) {
  std::string src(sd(s), sl(s)), x(sd(a), sl(a)), y(sd(b), sl(b));
  if (x.empty()) return mks(src);
  std::string r; size_t i = 0, p;
  while ((p = src.find(x, i)) != std::string::npos) { r.append(src, i, p - i); r += y; i = p + x.size(); }
  r.append(src, i, std::string::npos); return mks(r);
}

// ---------------------------------------------------------------- lists
static int64_t fac_list_checked_bytes(int64_t cap, int32_t esz) {
  if (cap < 0 || esz <= 0 || (uint64_t)cap > (uint64_t)SIZE_MAX / (uint64_t)esz ||
      cap > INT64_MAX / (int64_t)esz)
    do_throw("list capacity overflow", 5);
  return cap * (int64_t)esz;
}
FacList *fac_list_new(int32_t esz, int32_t ek) {
  if (esz <= 0) do_throw("invalid list element size", 5);
  FacList *l = (FacList *)fac_alloc_uninit((int64_t)sizeof(FacList));
  l->data = nullptr; l->len = l->cap = 0; l->esz = esz; l->ek = ek;
  l->dropFn = nullptr; l->copyFn = nullptr;
  return l;
}
void fac_list_set_ops(FacList *l, void (*dropFn)(void *), void (*copyFn)(void *, const void *)) {
  if (!l) return;
  l->dropFn = dropFn; l->copyFn = copyFn;
}
void fac_list_free(FacList *l) {
  if (!l) return;
  char *d = (char *)l->data;
  if (l->dropFn) for (int64_t i = 0; i < l->len; i++) l->dropFn(d + i * l->esz);
  else if (l->ek == 1) for (int64_t i = 0; i < l->len; i++) fac_str_free(((FacStr **)l->data)[i]);
  fac_free(l->data); fac_free(l);
}
void fac_list_grow(FacList *l) {
  if (!l || l->esz <= 0 || l->cap < 0 || l->len < 0 || l->len > l->cap) do_throw("invalid list", 5);
  // 1.5x growth reduces retained slack for large lists while keeping
  // amortized append complexity O(1). The extra +1 guarantees progress at
  // small capacities (8 -> 13 -> 20 -> 31 ...).
  int64_t next = 8;
  if (l->cap) {
    const int64_t half = l->cap / 2;
    if (l->cap > INT64_MAX - half - 1) do_throw("list capacity overflow", 5);
    next = l->cap + half + 1;
  }
  if (next <= l->cap) do_throw("list capacity overflow", 5);
  int64_t bytes = fac_list_checked_bytes(next, l->esz);
  l->data = l->data ? fac_realloc(l->data, bytes) : fac_alloc_uninit(bytes);
  l->cap = next;
}
void fac_list_insert(FacList *l, int64_t idx, const void *v) {
  if (!l || l->esz <= 0 || l->len < 0 || l->cap < l->len ||
      (l->cap > 0 && !l->data)) do_throw("invalid list", 5);
  if (!v) do_throw("null list element source", 6);
  const int64_t capacityBytes = fac_list_checked_bytes(l->cap, l->esz);
  if (idx < 0 || idx > l->len) fac_oob(idx, l->len);

  // The source may point into this list. Snapshot it before growth/memmove so
  // reallocating or shifting the list cannot invalidate the source value.
  const void *src = v;
  void *snapshot = nullptr;
  FacScratchScope snapshotScope(nullptr);
  if (l->data && capacityBytes > 0) {
    const uintptr_t base = (uintptr_t)l->data, from = (uintptr_t)v;
    const size_t elementBytes = (size_t)l->esz;
    const size_t listBytes = (size_t)capacityBytes;
    const bool overlaps = from >= base ? (from - base < listBytes)
                                       : (base - from < elementBytes);
    if (overlaps) {
      snapshot = fac_runtime_scratch_alloc(elementBytes);
      memcpy(snapshot, v, elementBytes);
      fac_tmp_push_drop(snapshot, reinterpret_cast<void *>(fac_tmp_free_raw));
      snapshotScope.value = snapshot;
      src = snapshot;
    }
  }

  if (l->len == l->cap) fac_list_grow(l);
  char *d = (char *)l->data;
  const size_t tailBytes = (size_t)((l->len - idx) * (int64_t)l->esz);
  const size_t offset = (size_t)(idx * (int64_t)l->esz);
  memmove(d + offset + (size_t)l->esz, d + offset, tailBytes);
  // Make the inserted slot a valid empty value before any callback can throw.
  // copy.Struct / object-slot-copy leave it empty until each retain succeeds.
  memset(d + offset, 0, (size_t)l->esz);
  l->len++;
  if (l->copyFn) l->copyFn(d + offset, src);
  else memcpy(d + offset, src, (size_t)l->esz);

}
void fac_list_remove(FacList *l, int64_t idx) {  // idx = -1 -> ตัวสุดท้าย
  if (!l || l->esz <= 0 || l->len < 0 || l->cap < l->len || (l->len && !l->data)) do_throw("invalid list", 5);
  fac_list_checked_bytes(l->cap, l->esz);
  if (idx == -1) idx = l->len - 1;
  if (idx < 0 || idx >= l->len) fac_oob(idx, l->len);
  char *d = (char *)l->data;
  if (l->dropFn) l->dropFn(d + idx * l->esz);
  else if (l->ek == 1) fac_str_free(((FacStr **)l->data)[idx]);
  memmove(d + idx * l->esz, d + (idx + 1) * l->esz, (size_t)((l->len - idx - 1) * l->esz)); l->len--;
}
void fac_list_clear(FacList *l) {
  if (!l || l->esz <= 0 || l->len < 0 || l->cap < l->len || (l->len && !l->data)) do_throw("invalid list", 5);
  fac_list_checked_bytes(l->cap, l->esz);
  if (l->dropFn) { char *d = (char *)l->data; for (int64_t i = 0; i < l->len; i++) l->dropFn(d + i * l->esz); }
  else if (l->ek == 1) for (int64_t i = 0; i < l->len; i++) fac_str_free(((FacStr **)l->data)[i]);
  l->len = 0;
}
FacList *fac_list_from(const void *data, int64_t len, int32_t esz, int32_t ek) {
  if (len < 0) do_throw("list length cannot be negative", 5);
  if (len > 0 && !data) do_throw("null source for non-empty list", 6);
  int64_t bytes = len ? fac_list_checked_bytes(len, esz) : 0;
  FacList *l = fac_list_new(esz, ek);
  if (len == 0) return l;
  fac_tmp_push(l, 2);
  l->data = fac_alloc(bytes); l->cap = len;
  if (ek == 1) {
    for (int64_t i = 0; i < len; i++) {
      l->len = i + 1; // zeroed slot is safe to drop if retaining the source throws
      ((FacStr **)l->data)[i] = fac_str_dup(((FacStr *const *)data)[i]);
    }
  } else { memcpy(l->data, data, (size_t)bytes); l->len = len; }
  fac_tmp_pop(l);
  return l;
}
FacList *fac_list_copy(FacList *l) {
  if (!l) return nullptr;
  if (l->esz <= 0 || l->len < 0 || l->cap < l->len || (l->len && !l->data)) do_throw("invalid list", 5);
  fac_list_checked_bytes(l->cap, l->esz);
  int64_t bytes = l->len ? fac_list_checked_bytes(l->len, l->esz) : 0;
  FacList *r = fac_list_new(l->esz, l->ek);
  r->dropFn = l->dropFn; r->copyFn = l->copyFn;
  if (!l->len) return r;
  fac_tmp_push(r, 2);
  r->data = fac_alloc(bytes); r->cap = l->len;
  const char *src = (const char *)l->data; char *dst = (char *)r->data;
  for (int64_t i = 0; i < l->len; i++) {
    r->len = i + 1; // allocated storage is zeroed, allowing partial cleanup on an exception
    if (r->copyFn) r->copyFn(dst + i * r->esz, src + i * r->esz);
    else if (r->ek == 1) ((FacStr **)r->data)[i] = fac_str_dup(((FacStr *const *)l->data)[i]);
    else memcpy(dst + i * r->esz, src + i * r->esz, (size_t)r->esz);
  }
  fac_tmp_pop(r);
  return r;
}
FacList *fac_list_slice(FacList *l, int64_t a, int64_t b) {
  if (!l || l->esz <= 0 || l->len < 0 || l->cap < l->len || (l->len && !l->data)) do_throw("invalid list", 5);
  fac_list_checked_bytes(l->cap, l->esz);
  if (a < 0 || b > l->len || a > b) do_throw("slice out of range: [" + std::to_string(a) + ":" + std::to_string(b) + "] size " + std::to_string(l->len), 2);
  int64_t count = b - a;
  FacList *r = fac_list_new(l->esz, l->ek);
  r->dropFn = l->dropFn; r->copyFn = l->copyFn;
  if (!count) return r;
  int64_t bytes = fac_list_checked_bytes(count, r->esz);
  fac_tmp_push(r, 2);
  r->data = fac_alloc(bytes); r->cap = count;
  const char *src = (const char *)l->data + (size_t)fac_list_checked_bytes(a, l->esz); char *dst = (char *)r->data;
  for (int64_t i = 0; i < count; i++) {
    r->len = i + 1;
    if (r->copyFn) r->copyFn(dst + i * r->esz, src + i * r->esz);
    else if (r->ek == 1) ((FacStr **)r->data)[i] = fac_str_dup(((FacStr *const *)src)[i]);
    else memcpy(dst + i * r->esz, src + i * r->esz, (size_t)r->esz);
  }
  fac_tmp_pop(r);
  return r;
}
FacList *fac_array_slice(const void *data, int64_t n, int64_t a, int64_t b, int32_t esz, int32_t ek) {
  if (n < 0 || a < 0 || b > n || a > b) do_throw("slice out of range: [" + std::to_string(a) + ":" + std::to_string(b) + "] size " + std::to_string(n), 2);
  fac_list_checked_bytes(n, esz);
  if (a > 0 && !data) do_throw("null array data", 6);
  size_t offset = (size_t)fac_list_checked_bytes(a, esz);
  return fac_list_from(data ? (const char *)data + offset : nullptr, b - a, esz, ek);
}
FacList *fac_str_split(FacStr *s, FacStr *sep) {
  FacList *l = fac_list_new(8, 1); fac_tmp_push(l, 2);
  std::string src(sd(s), (size_t)sl(s)), d(sd(sep), (size_t)sl(sep));
  auto push = [&](const std::string &x) {
    if (l->len == l->cap) fac_list_grow(l);
    FacStr *e = mks(x);
    ((FacStr **)l->data)[l->len++] = e;
  };
  if (d.empty()) {
    for (int64_t i = 0; i < sl(s);) { int w; dec(src.data() + i, &w); push(src.substr((size_t)i, (size_t)w)); i += w; }
  } else {
    size_t i = 0, p;
    while ((p = src.find(d, i)) != std::string::npos) { push(src.substr(i, p - i)); i = p + d.size(); }
    push(src.substr(i));
  }
  fac_tmp_pop(l);
  return l;
}
FacStr *fac_str_join(FacList *l, FacStr *sep) {
  std::string r; for (int64_t i = 0; i < l->len; i++) { if (i) r.append(sd(sep), (size_t)sl(sep)); FacStr *e = ((FacStr **)l->data)[i]; r.append(sd(e), (size_t)sl(e)); }
  return mks(r);
}

// type code: 1=i8 2=i16 3=i32 4=i64 5=u8 6=u16 7=u32 8=u64 9=f32 10=f64 11=bool 12=char 13=unichar 14=string 15=enum(i32)
static size_t fac_checked_element_bytes(int64_t count, int64_t elementSize, const char *what) {
  if (count < 0 || elementSize <= 0 || (uint64_t)count > (uint64_t)SIZE_MAX / (uint64_t)elementSize ||
      count > INT64_MAX / elementSize)
    do_throw(std::string(what) + " size overflow or invalid dimensions", 5);
  return (size_t)count * (size_t)elementSize;
}
extern "C++" { template <class T> static void sort_t(void *d, int64_t n) { if (n > 1) std::sort((T *)d, (T *)d + n); } }
void fac_sort(void *d, int64_t n, int32_t code) {
  if (n < 0) do_throw("sort count cannot be negative", 5);
  int64_t width = 0;
  switch (code) {
    case 1: width = sizeof(int8_t); break; case 2: width = sizeof(int16_t); break;
    case 3: case 15: width = sizeof(int32_t); break; case 4: width = sizeof(int64_t); break;
    case 5: case 11: case 12: width = sizeof(uint8_t); break; case 6: width = sizeof(uint16_t); break;
    case 7: case 13: width = sizeof(uint32_t); break; case 8: width = sizeof(uint64_t); break;
    case 9: width = sizeof(float); break; case 10: width = sizeof(double); break; case 14: width = sizeof(FacStr *); break;
    default: do_throw("sort received unknown element type", 5);
  }
  fac_checked_element_bytes(n, width, "sort");
  if (n > 0 && !d) do_throw("sort received null data", 6);
  if (n < 2) return;
  switch (code) {
    case 1: sort_t<int8_t>(d, n); break; case 2: sort_t<int16_t>(d, n); break; case 3: case 15: sort_t<int32_t>(d, n); break;
    case 4: sort_t<int64_t>(d, n); break; case 5: case 11: case 12: sort_t<uint8_t>(d, n); break; case 6: sort_t<uint16_t>(d, n); break;
    case 7: sort_t<uint32_t>(d, n); break; case 8: sort_t<uint64_t>(d, n); break;
    case 9: std::sort((float *)d, (float *)d + n, [](float a, float b) { return a < b || (b != b && a == a); }); break;
    case 10: std::sort((double *)d, (double *)d + n, [](double a, double b) { return a < b || (b != b && a == a); }); break;
    case 14: std::sort((FacStr **)d, (FacStr **)d + n, [](FacStr *a, FacStr *b) { return fac_str_cmp(a, b) < 0; }); break;
  }
}
// Stable merge sort using the user comparator (cmp(ctx, a, b) < 0 means a precedes b).
static void msort(char *a, char *tmp, int64_t n, int64_t esz, void *ctx, int32_t (*cmp)(void *, const void *, const void *)) {
  if (n < 2) return;
  int64_t m = n / 2;
  msort(a, tmp, m, esz, ctx, cmp); msort(a + (size_t)m * (size_t)esz, tmp, n - m, esz, ctx, cmp);
  int64_t i = 0, j = m, k = 0;
  while (i < m && j < n) { if (cmp(ctx, a + (size_t)j * esz, a + (size_t)i * esz) < 0) { memcpy(tmp + (size_t)k * esz, a + (size_t)j * esz, (size_t)esz); j++; } else { memcpy(tmp + (size_t)k * esz, a + (size_t)i * esz, (size_t)esz); i++; } k++; }
  while (i < m) { memcpy(tmp + (size_t)k * esz, a + (size_t)i * esz, (size_t)esz); i++; k++; }
  while (j < n) { memcpy(tmp + (size_t)k * esz, a + (size_t)j * esz, (size_t)esz); j++; k++; }
  memcpy(a, tmp, fac_checked_element_bytes(n, esz, "sort"));
}
void fac_sort_cmp(void *d, int64_t n, int64_t esz, void *ctx, int32_t (*cmp)(void *, const void *, const void *)) {
  size_t bytes = fac_checked_element_bytes(n, esz, "sort");
  if (n < 2) return;
  if (!d || !cmp) do_throw("sort received null data or comparator", 6);
  char *tmp = (char *)fac_runtime_scratch_alloc(bytes);
  fac_tmp_push_drop(tmp, reinterpret_cast<void *>(fac_tmp_free_raw));
  FacScratchScope scratchScope(tmp);
  msort((char *)d, tmp, n, esz, ctx, cmp);
}
void fac_reverse(void *d, int64_t n, int32_t esz) {
  size_t bytes = fac_checked_element_bytes(n, esz, "reverse");
  if (n < 2) return;
  if (!d) do_throw("reverse received null data", 6);
  (void)bytes;
  char *p = (char *)d;
  void *tmp = fac_runtime_scratch_alloc((size_t)esz);
  fac_tmp_push_drop(tmp, reinterpret_cast<void *>(fac_tmp_free_raw));
  FacScratchScope scratchScope(tmp);
  for (int64_t i = 0, j = n - 1; i < j; i++, j--) {
    memcpy(tmp, p + (size_t)i * (size_t)esz, (size_t)esz);
    memcpy(p + (size_t)i * (size_t)esz, p + (size_t)j * (size_t)esz, (size_t)esz);
    memcpy(p + (size_t)j * (size_t)esz, tmp, (size_t)esz);
  }
}
void fac_fill(void *d, int64_t n, int32_t esz, const void *v) {
  size_t bytes = fac_checked_element_bytes(n, esz, "fill");
  if (n == 0) return;
  if (!d || !v) do_throw("fill received null data or value", 6);
  std::vector<unsigned char> snapshot((size_t)esz);
  memcpy(snapshot.data(), v, (size_t)esz); // source may alias a destination element
  char *dst = (char *)d;
  for (int64_t i = 0; i < n; i++) memcpy(dst + (size_t)i * (size_t)esz, snapshot.data(), (size_t)esz);
  (void)bytes;
}
int32_t fac_find(void *d, int64_t n, int32_t esz, int32_t code, const void *v) {
  if (n < 0 || n > INT32_MAX || esz <= 0) do_throw("find received invalid dimensions", 5);
  fac_checked_element_bytes(n, esz, "find");
  if (n == 0) return -1;
  if (!d || !v) do_throw("find received null data or value", 6);
  if (code == 14 && esz != (int32_t)sizeof(FacStr *)) do_throw("find string element size mismatch", 5);
  for (int64_t i = 0; i < n; i++) {
    if (code == 14) { if (fac_str_eq(((FacStr **)d)[i], *(FacStr *const *)v)) return (int32_t)i; }
    else if (memcmp((char *)d + (size_t)i * (size_t)esz, v, (size_t)esz) == 0) return (int32_t)i;
  }
  return -1;
}

// ---------------------------------------------------------------- print
void fac_use(int32_t fd) { g_fd = fd; }
void fac_print_nl() { wr("\n", 1); }
void fac_print_i64(int64_t v) { char b[32]; auto r = std::to_chars(b, b + 32, v); wr(b, (size_t)(r.ptr - b)); }
void fac_print_u64(uint64_t v) { char b[32]; auto r = std::to_chars(b, b + 32, v); wr(b, (size_t)(r.ptr - b)); }
void fac_print_f64(double v) { wrs(fmtd(v)); }
void fac_print_f32(float v) { wrs(fmtf(v)); }
void fac_print_str(FacStr *s) { wr(sd(s), (size_t)sl(s)); }
void fac_print_char(int32_t c) { std::string s; enc(s, (uint32_t)c); wrs(s); }
void fac_print_bool(int32_t b) { if (b) wr("true", 4); else wr("false", 5); }
void fac_print_ptr(void *p) { char b[32]; snprintf(b, 32, "0x%llx", (unsigned long long)(uintptr_t)p); wrs(b); }
static void print_elem(const char *p, int32_t code) {
  switch (code) {
    case 1: fac_print_i64(*(int8_t *)p); break; case 2: fac_print_i64(*(int16_t *)p); break;
    case 3: case 15: fac_print_i64(*(int32_t *)p); break; case 4: fac_print_i64(*(int64_t *)p); break;
    case 5: fac_print_u64(*(uint8_t *)p); break; case 6: fac_print_u64(*(uint16_t *)p); break;
    case 7: fac_print_u64(*(uint32_t *)p); break; case 8: fac_print_u64(*(uint64_t *)p); break;
    case 9: fac_print_f32(*(float *)p); break; case 10: fac_print_f64(*(double *)p); break;
    case 11: fac_print_bool(*(uint8_t *)p); break; case 12: fac_print_char(*(uint8_t *)p); break;
    case 13: fac_print_char(*(int32_t *)p); break; case 14: fac_print_str(*(FacStr **)p); break;
  }
}
static int esize(int32_t code) { switch (code) { case 1: case 5: case 11: case 12: return 1; case 2: case 6: return 2; case 3: case 7: case 9: case 13: case 15: return 4; default: return 8; } }
void fac_print_seq(const void *d, int64_t n, int32_t code) {
  const char *p = (const char *)d;
  if (code == 12) { int64_t k = 0; while (k < n && p[k]) k++; wr(p, (size_t)k); return; }       // char[] = ข้อความ
  if (code == 13) { for (int64_t i = 0; i < n && ((const int32_t *)p)[i]; i++) fac_print_char(((const int32_t *)p)[i]); return; }
  wr("[", 1);
  for (int64_t i = 0; i < n; i++) { if (i) wr(", ", 2); print_elem(p + i * esize(code), code); }
  wr("]", 1);
}

// ---------------------------------------------------------------- input
static int peekc() { int c = fgetc(stdin); if (c != EOF) ungetc(c, stdin); return c; }
static std::string token() {
  flush_out(); int c; std::string t;
  
  while ((c = fgetc(stdin)) != EOF && isws((char)c)) {}
  while (c != EOF && !isws((char)c)) { t += (char)c; c = fgetc(stdin); }
  if (c != EOF) ungetc(c, stdin);
  if (t.empty()) do_throw("end of input: Scanner อ่านไม่ได้ (ข้อมูลหมดแล้ว ใช้ terminal.in.eof() เช็กก่อน)", 16);
  while (peekc() == ' ' || peekc() == '\t') fgetc(stdin);              // กินช่องว่างท้าย token + ขึ้นบรรทัดใหม่ 1 ตัว
  if (peekc() == '\r') fgetc(stdin);
  if (peekc() == '\n') fgetc(stdin);
  return t;
}
FacStr *fac_readline() {
  flush_out(); std::string t; int c;
  while ((c = fgetc(stdin)) != EOF && c != '\n') t += (char)c;
  if (!t.empty() && t.back() == '\r') t.pop_back();
  return mks(t);
}
int64_t fac_scan_i64() {
  std::string t = token(); size_t i = (!t.empty() && (t[0] == '-' || t[0] == '+')) ? 1 : 0;
  bool hex = t.size() > i + 1 && t[i] == '0' && (t[i + 1] == 'x' || t[i + 1] == 'X');
  return strtoll(t.c_str(), nullptr, hex ? 16 : 10);
}
double fac_scan_f64() { std::string t = token(); return strtod(t.c_str(), nullptr); }
FacStr *fac_scan_str() { return mks(token()); }
int32_t fac_scan_char() { std::string t = token(); if (t.empty()) return 0; int w; return (int32_t)dec(t.c_str(), &w); }
int32_t fac_scan_bool() { std::string t = token(); return t == "true" || t == "1"; }

// ---------------------------------------------------------------- parse / convert
int64_t fac_parse_i64(FacStr *s) {
  std::string t(sd(s), sl(s)); size_t a = 0, b = t.size(); while (a < b && isws(t[a])) a++; while (b > a && isws(t[b - 1])) b--;
  t = t.substr(a, b - a); char *e = nullptr; errno = 0; long long v = strtoll(t.c_str(), &e, 10);
  if (t.empty() || *e || errno) do_throw("parse error: \"" + t + "\" is not an integer", 6);
  return v;
}
double fac_parse_f64(FacStr *s) {
  std::string t(sd(s), sl(s)); { size_t a = 0, b = t.size(); while (a < b && isws(t[a])) a++; while (b > a && isws(t[b - 1])) b--; t = t.substr(a, b - a); }
  char *e = nullptr; double v = strtod(t.c_str(), &e);
  if (t.empty() || *e) do_throw("parse error: \"" + t + "\" is not a number", 6);
  return v;
}
int32_t fac_parse_bool(FacStr *s) {
  std::string t(sd(s), sl(s)); if (t == "true") return 1; if (t == "false") return 0;
  do_throw("parse error: \"" + t + "\" is not a boolean", 6);
}
int64_t fac_ipow(int64_t b, int64_t e) { if (e < 0) return 0; uint64_t r = 1, x = (uint64_t)b; while (e) { if (e & 1) r *= x; x *= x; e >>= 1; } return (int64_t)r; }  // wrap-around ชัดเจน (ไม่ใช่ UB)
int64_t fac_iabs(int64_t v) { return v < 0 ? (int64_t)(0 - (uint64_t)v) : v; }

// ---------------------------------------------------------------- random / time / sys / file
static std::atomic<uint64_t> g_rng_seed{(uint64_t)std::chrono::steady_clock::now().time_since_epoch().count()};
static std::atomic<uint64_t> g_rng_epoch{1};
static std::atomic<uint64_t> g_rng_stream{0};
// Each thread owns its engine. A seed epoch safely reinitializes every stream
// without taking a mutex on every random number (and without sharing mt19937).
void fac_rand_seed(int64_t s) {
  g_rng_seed.store((uint64_t)s, std::memory_order_relaxed);
  g_rng_stream.store(0, std::memory_order_relaxed);
  g_rng_epoch.fetch_add(1, std::memory_order_release);
}
static std::mt19937_64 &rng_engine() {
  thread_local std::mt19937_64 rng;
  thread_local uint64_t local_epoch = 0;
  uint64_t epoch = g_rng_epoch.load(std::memory_order_acquire);
  if (local_epoch != epoch) {
    uint64_t seed, stable_epoch;
    do {
      stable_epoch = g_rng_epoch.load(std::memory_order_acquire);
      seed = g_rng_seed.load(std::memory_order_relaxed);
    } while (stable_epoch != g_rng_epoch.load(std::memory_order_acquire));
    uint64_t stream = g_rng_stream.fetch_add(1, std::memory_order_relaxed);
    // Stream zero preserves the historic single-thread seeded sequence.
    rng.seed(stream == 0 ? seed : seed ^ (stream * UINT64_C(0x9E3779B97F4A7C15)));
    local_epoch = stable_epoch;
  }
  return rng;
}
static uint64_t rng_next() { return rng_engine()(); }
int64_t fac_rand_int(int64_t lo, int64_t hi) {
  if (hi < lo) std::swap(lo, hi);
  uint64_t range = (uint64_t)hi - (uint64_t)lo + 1;      // 0 = ช่วงเต็ม 2^64
  if (!range) return (int64_t)rng_next();
  uint64_t lim = UINT64_MAX - UINT64_MAX % range, x;      // ตัด modulo bias
  do { x = rng_next(); } while (x >= lim);
  return (int64_t)((uint64_t)lo + x % range);
}
uint64_t fac_rand_uint(uint64_t lo, uint64_t hi) {
  if (hi < lo) std::swap(lo, hi);
  const uint64_t range = hi - lo + 1; // zero represents the complete uint64 domain
  if (!range) return rng_next();
  const uint64_t threshold = (uint64_t)(0 - range) % range;
  uint64_t value;
  do { value = rng_next(); } while (value < threshold);
  return lo + value % range;
}
double fac_rand_f64() { return (rng_next() >> 11) * (1.0 / 9007199254740992.0); }
int32_t fac_rand_bool() { return (int32_t)(rng_next() & 1); }
static long double fac_rand_read_weight(const void *data, int64_t index, int32_t kind, int32_t bits, int32_t isSigned) {
  const unsigned char *p = (const unsigned char *)data + (size_t)index * (size_t)(bits / 8);
  if (kind == 1) {
    if (bits == 32) { float v; memcpy(&v, p, sizeof v); return (long double)v; }
    if (bits == 64) { double v; memcpy(&v, p, sizeof v); return (long double)v; }
  } else if (kind == 0) {
    if (isSigned) {
      switch (bits) {
        case 8: { int8_t v; memcpy(&v, p, sizeof v); return (long double)v; }
        case 16: { int16_t v; memcpy(&v, p, sizeof v); return (long double)v; }
        case 32: { int32_t v; memcpy(&v, p, sizeof v); return (long double)v; }
        case 64: { int64_t v; memcpy(&v, p, sizeof v); return (long double)v; }
      }
    } else {
      switch (bits) {
        case 8: { uint8_t v; memcpy(&v, p, sizeof v); return (long double)v; }
        case 16: { uint16_t v; memcpy(&v, p, sizeof v); return (long double)v; }
        case 32: { uint32_t v; memcpy(&v, p, sizeof v); return (long double)v; }
        case 64: { uint64_t v; memcpy(&v, p, sizeof v); return (long double)v; }
      }
    }
  }
  do_throw("random.weighted: unsupported weight type", 8);
  return 0;
}
int64_t fac_rand_weighted_index(const void *weights, int64_t weightCount, int64_t valueCount,
                                int32_t kind, int32_t bits, int32_t isSigned) {
  if (!weights || weightCount <= 0 || weightCount != valueCount)
    do_throw("random.weighted: values and weights must have the same non-zero length", 8);
  if ((kind != 0 && kind != 1) || (kind == 1 && bits != 32 && bits != 64) ||
      (kind == 0 && bits != 8 && bits != 16 && bits != 32 && bits != 64))
    do_throw("random.weighted: unsupported weight type", 8);
  long double total = 0.0L;
  int64_t lastPositive = -1;
  for (int64_t i = 0; i < weightCount; ++i) {
    const long double w = fac_rand_read_weight(weights, i, kind, bits, isSigned);
    if (!std::isfinite(w) || w < 0.0L) do_throw("random.weighted: weights must be finite and non-negative", 8);
    if (w > 0.0L) lastPositive = i;
    total += w;
    if (!std::isfinite(total)) do_throw("random.weighted: total weight is out of range", 8);
  }
  if (!(total > 0.0L) || lastPositive < 0) do_throw("random.weighted: at least one weight must be positive", 8);
  const long double unit = (long double)(rng_next() >> 11) * (1.0L / 9007199254740992.0L);
  const long double target = unit * total;
  long double cumulative = 0.0L;
  for (int64_t i = 0; i < weightCount; ++i) {
    cumulative += fac_rand_read_weight(weights, i, kind, bits, isSigned);
    if (target < cumulative) return i;
  }
  return lastPositive; // protects the final bucket from accumulated round-off
}
int64_t fac_rand_markov_index(const void *weights, int64_t weightCount, int64_t currentState,
                              int64_t stateCount, int32_t kind, int32_t bits, int32_t isSigned) {
  if (stateCount <= 0 || stateCount > 1000000 || currentState < 0 || currentState >= stateCount)
    do_throw("random.markov: state index or state count is out of range", 8);
  if (stateCount > INT64_MAX / stateCount || weightCount != stateCount * stateCount)
    do_throw("random.markov: transition matrix must contain stateCount * stateCount weights", 8);
  const size_t elementSize = (size_t)bits / 8;
  if (!weights || elementSize == 0 || (uint64_t)(stateCount * stateCount) > SIZE_MAX / elementSize)
    do_throw("random.markov: invalid transition matrix", 8);
  const unsigned char *row = (const unsigned char *)weights + (size_t)(currentState * stateCount) * elementSize;
  return fac_rand_weighted_index(row, stateCount, stateCount, kind, bits, isSigned);
}
uint64_t fac_time_now() { return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count(); }
void fac_sleep(int64_t ms) { flush_out(); std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }
FacList *fac_args() {
  FacList *l = fac_list_new(8, 1);
  // List growth or string allocation can raise a FAC error via longjmp. Keep
  // partial results on the cleanup stack so every already-copied argument is
  // released before control leaves this C ABI frame.
  fac_cleanup_push(&l, 2, nullptr);
  for (int i = 1; i < g_argc; i++) {
    if (l->len == l->cap) fac_list_grow(l);
    FacStr *e = mks(g_argv[i]);
    ((FacStr **)l->data)[l->len++] = e;
  }
  fac_cleanup_pop();
  return l;
}
FacStr *fac_env(FacStr *k) { const char *v = getenv(sd(k)); return mks(v ? v : ""); }
[[noreturn]] void fac_exit(int32_t code) { flush_out(); exit(code); }
static std::atomic<uint64_t> g_file_live_handles{0};

// A file handle is an opaque, process-stable token rather than a raw FILE*.
// Records are retained as closed tombstones until process shutdown so a stale
// pointer alias can never become valid again when libc reuses a FILE* address
// (or when the record allocator would otherwise recycle the token address).
// Each record serializes all operations and close on the same native stream.
struct FacFileHandleState {
  std::mutex mutex;
  FILE *stream = nullptr;
  bool closed = false;
  explicit FacFileHandleState(FILE *f) : stream(f) {}
  ~FacFileHandleState() { if (stream) (void)fclose(stream); }
};
static std::mutex g_file_handles_mu;
static std::unordered_map<void *, std::unique_ptr<FacFileHandleState>> g_file_handles;

static FacFileHandleState *fac_file_find_state(void *handle) {
  if (!handle) return nullptr;
  std::lock_guard<std::mutex> lock(g_file_handles_mu);
  auto it = g_file_handles.find(handle);
  return it == g_file_handles.end() ? nullptr : it->second.get();
}

static bool fac_file_lock_open(void *handle, FacFileHandleState *&state,
                               std::unique_lock<std::mutex> &operationLock) {
  state = fac_file_find_state(handle);
  if (!state) return false;
  operationLock = std::unique_lock<std::mutex>(state->mutex);
  return !state->closed && state->stream != nullptr;
}

void *fac_file_open(FacStr *path, FacStr *mode) {
  FILE *stream = fopen(sd(path), sd(mode));
  if (!stream) do_throw(std::string("cannot open file: ") + sd(path), 7);

  std::unique_ptr<FacFileHandleState> state;
  void *token = nullptr;
  bool registered = false;
  try {
    state.reset(new FacFileHandleState(stream));
    token = state.get();
    std::lock_guard<std::mutex> lock(g_file_handles_mu);
    registered = g_file_handles.emplace(token, std::move(state)).second;
  } catch (...) {
    // The local state closes the stream if ownership has not transferred to
    // the permanent registry. The registry never erases a token before exit.
    registered = false;
  }
  if (!registered) {
    state.reset();
    // If insertion failed before a state object could own the stream, close it.
    if (!token) (void)fclose(stream);
    do_throw("out of memory while tracking open file handle", 5);
  }
  g_file_live_handles.fetch_add(1, std::memory_order_relaxed);
  return token;
}
uint64_t fac_file_live_handles() { return g_file_live_handles.load(std::memory_order_relaxed); }
static constexpr size_t FAC_FILE_READ_MAX_BYTES = (size_t)64 << 20;
static constexpr size_t FAC_FILE_LINE_MAX_BYTES = (size_t)16 << 20;
static bool fac_file_read_bounded(FILE *f, std::string &out, size_t limit, bool &tooLarge) {
  char b[8192]; size_t n = 0;
  tooLarge = false;
  try {
    while ((n = fread(b, 1, sizeof b, f)) > 0) {
      if (out.size() > limit || n > limit - out.size()) { tooLarge = true; return false; }
      out.append(b, n);
    }
  } catch (const std::bad_alloc &) { return false; }
  return ferror(f) == 0;
}
FacStr *fac_file_readline(void *handle) {
  std::string text;
  bool invalid = false, tooLarge = false, outOfMemory = false, ioError = false;
  {
    FacFileHandleState *state = nullptr;
    std::unique_lock<std::mutex> operationLock;
    if (!fac_file_lock_open(handle, state, operationLock)) {
      invalid = true;
    } else {
      int c = EOF;
      try {
        while ((c = fgetc(state->stream)) != EOF) {
          if (c == '\n') break;
          if (text.size() >= FAC_FILE_LINE_MAX_BYTES) { tooLarge = true; break; }
          text += (char)c;
        }
      } catch (const std::bad_alloc &) {
        outOfMemory = true;
      }
      ioError = ferror(state->stream) != 0;
    }
  }
  if (invalid) do_throw("file.readLine: invalid or closed handle", 7);
  if (tooLarge) { std::string().swap(text); do_throw("file.readLine: line exceeds 16 MiB limit", 7); }
  if (outOfMemory) { std::string().swap(text); do_throw("file.readLine: out of memory", 5); }
  if (ioError) { std::string().swap(text); do_throw("file.readLine: read failed", 7); }
  if (!text.empty() && text.back() == '\r') text.pop_back();
  return mks(text);
}
FacStr *fac_file_readall(void *handle) {
  std::string text;
  bool invalid = false, tooLarge = false, ok = false;
  {
    FacFileHandleState *state = nullptr;
    std::unique_lock<std::mutex> operationLock;
    if (!fac_file_lock_open(handle, state, operationLock)) {
      invalid = true;
    } else {
      ok = fac_file_read_bounded(state->stream, text, FAC_FILE_READ_MAX_BYTES, tooLarge);
    }
  }
  if (invalid) do_throw("file.readAll: invalid or closed handle", 7);
  if (!ok) { std::string().swap(text); do_throw(tooLarge ? "file.readAll: input exceeds 64 MiB limit" : "file.readAll: read failed or out of memory", 7); }
  return mks(text);
}
static bool fac_file_write_bytes(FILE *f, const char *p, size_t n) {
  if (!f || (!p && n)) return false;
  size_t off = 0;
  while (off < n) {
    size_t wrote = fwrite(p + off, 1, n - off, f);
    if (wrote == 0) return false;
    off += wrote;
  }
  return ferror(f) == 0;
}
void fac_file_write(void *handle, FacStr *s) {
  if (!s) do_throw("file.write: null value", 7);
  bool invalid = false, wrote = false;
  {
    FacFileHandleState *state = nullptr;
    std::unique_lock<std::mutex> operationLock;
    if (!fac_file_lock_open(handle, state, operationLock)) invalid = true;
    else wrote = fac_file_write_bytes(state->stream, sd(s), (size_t)sl(s));
  }
  if (invalid) do_throw("file.write: invalid or closed handle", 7);
  if (!wrote) do_throw("file.write: write failed", 7);
}
void fac_file_writeline(void *handle, FacStr *s) {
  if (!s) do_throw("file.writeLine: null value", 7);
  bool invalid = false, wrote = false;
  {
    FacFileHandleState *state = nullptr;
    std::unique_lock<std::mutex> operationLock;
    if (!fac_file_lock_open(handle, state, operationLock)) invalid = true;
    else wrote = fac_file_write_bytes(state->stream, sd(s), (size_t)sl(s)) &&
                 fputc('\n', state->stream) != EOF;
  }
  if (invalid) do_throw("file.writeLine: invalid or closed handle", 7);
  if (!wrote) do_throw("file.writeLine: write failed", 7);
}
void fac_file_flush(void *handle) {
  bool invalid = false, flushed = false;
  {
    FacFileHandleState *state = nullptr;
    std::unique_lock<std::mutex> operationLock;
    if (!fac_file_lock_open(handle, state, operationLock)) invalid = true;
    else flushed = fflush(state->stream) == 0;
  }
  if (invalid) do_throw("file.flush: invalid or closed handle", 7);
  if (!flushed) do_throw("file.flush: flush failed", 7);
}
int32_t fac_file_eof(void *handle) {
  bool invalid = false, ioError = false;
  int32_t result = 1;
  {
    FacFileHandleState *state = nullptr;
    std::unique_lock<std::mutex> operationLock;
    if (!fac_file_lock_open(handle, state, operationLock)) {
      invalid = true;
    } else {
      const int c = fgetc(state->stream);
      if (c == EOF) {
        ioError = ferror(state->stream) != 0;
        result = 1;
      } else if (ungetc(c, state->stream) == EOF) {
        ioError = true;
      } else {
        result = 0;
      }
    }
  }
  if (invalid) do_throw("file.eof: invalid or closed handle", 7);
  if (ioError) do_throw("file.eof: read failed", 7);
  return result;
}
void fac_file_close(void *handle) {
  if (!handle) return;
  FacFileHandleState *state = fac_file_find_state(handle);
  if (!state) return;
  bool closedNow = false;
  {
    std::lock_guard<std::mutex> operationLock(state->mutex);
    if (!state->closed) {
      state->closed = true;
      FILE *stream = state->stream;
      state->stream = nullptr;
      if (stream) (void)fclose(stream);
      closedNow = true;
    }
  }
  if (closedNow) {
    const uint64_t previous = g_file_live_handles.fetch_sub(1, std::memory_order_relaxed);
    if (previous == 0) {
      fprintf(stderr, "FAC internal: file handle accounting underflow\n");
      abort();
    }
  }
}
int32_t fac_file_exists(FacStr *p) { struct stat st; return stat(sd(p), &st) == 0; }
int32_t fac_file_delete(FacStr *p) { return remove(sd(p)) == 0; }

int32_t fac_char_isdigit(int32_t c) { return c >= '0' && c <= '9'; }
int32_t fac_char_isalpha(int32_t c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c > 127; }
int32_t fac_char_isspace(int32_t c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f'; }
int32_t fac_char_toint(int32_t c) { return (c >= '0' && c <= '9') ? c - '0' : c; }

// ================================================================ V2 data structures
// elem code ใช้ชุดเดียวกับ print/sort:  1=i8 2=i16 3=i32 4=i64 5=u8 6=u16 7=u32 8=u64 9=f32 10=f64 11=bool 12=char 13=unichar 14=string 15=enum
extern "C++" {
#include <functional>
#include <list>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <type_traits>
#include <queue>
#include <set>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <type_traits>
#include <deque>
#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <type_traits>
#include <vector>
struct Elem { int code = 3; int sz = 4; };
static int cmpv(int code, const void *a, const void *b) {
  switch (code) {
    case 1: { auto x = *(const int8_t *)a, y = *(const int8_t *)b; return x < y ? -1 : x > y; }
    case 2: { auto x = *(const int16_t *)a, y = *(const int16_t *)b; return x < y ? -1 : x > y; }
    case 3: case 15: { auto x = *(const int32_t *)a, y = *(const int32_t *)b; return x < y ? -1 : x > y; }
    case 4: { auto x = *(const int64_t *)a, y = *(const int64_t *)b; return x < y ? -1 : x > y; }
    case 5: case 11: case 12: { auto x = *(const uint8_t *)a, y = *(const uint8_t *)b; return x < y ? -1 : x > y; }
    case 6: { auto x = *(const uint16_t *)a, y = *(const uint16_t *)b; return x < y ? -1 : x > y; }
    case 7: case 13: { auto x = *(const uint32_t *)a, y = *(const uint32_t *)b; return x < y ? -1 : x > y; }
    case 8: { auto x = *(const uint64_t *)a, y = *(const uint64_t *)b; return x < y ? -1 : x > y; }
    case 9: { auto x = *(const float *)a, y = *(const float *)b; return x < y ? -1 : x > y; }
    case 10: { auto x = *(const double *)a, y = *(const double *)b; return x < y ? -1 : x > y; }
    case 14: return fac_str_cmp(*(FacStr *const *)a, *(FacStr *const *)b);
  }
  return memcmp(a, b, 8);
}
static size_t hashv(int code, const void *p, int sz) {
  if (code == 14) { FacStr *s = *(FacStr *const *)p; return std::hash<std::string_view>()(std::string_view(sd(s), (size_t)sl(s))); }
  return std::hash<std::string_view>()(std::string_view((const char *)p, (size_t)sz));
}
static void dupv(const Elem &e, const void *src, void *dst) {
  if (e.code == 14) *(FacStr **)dst = fac_str_dup(*(FacStr *const *)src); else memcpy(dst, src, (size_t)e.sz);
}
static void freev(const Elem &e, void *p) { if (e.code == 14) fac_str_free(*(FacStr **)p); }
static std::string mkblob(const Elem &e, const void *src) { std::string b((size_t)e.sz, 0); dupv(e, src, &b[0]); return b; }
// A std::string owns only the bytes of a FAC value blob, not the managed
// object referenced by a string-valued blob. If a container allocation fails
// before the move commits, release that pending managed reference explicitly.
template <class Container>
static void fac_blob_push_back(Container &container, const Elem &e, const void *src) {
  std::string pending = mkblob(e, src);
  try { container.push_back(std::move(pending)); }
  catch (...) { if (!pending.empty()) freev(e, pending.data()); throw; }
}
template <class Container>
static void fac_blob_push_front(Container &container, const Elem &e, const void *src) {
  std::string pending = mkblob(e, src);
  try { container.push_front(std::move(pending)); }
  catch (...) { if (!pending.empty()) freev(e, pending.data()); throw; }
}
template <class Container, class Iterator>
static void fac_blob_insert(Container &container, Iterator position, const Elem &e, const void *src) {
  std::string pending = mkblob(e, src);
  try { container.insert(position, std::move(pending)); }
  catch (...) { if (!pending.empty()) freev(e, pending.data()); throw; }
}
static FacList *mklist(const Elem &e, const std::vector<const std::string *> &v) {
  FacList *l = fac_list_new(e.sz, e.code == 14 ? 1 : 0);
  for (auto *b : v) { if (l->len == l->cap) fac_list_grow(l); dupv(e, b->data(), (char *)l->data + l->len * e.sz); l->len++; }
  return l;
}
struct FacDS { virtual ~FacDS() {} virtual FacDS *clone() = 0; virtual int64_t size() = 0; virtual void clear() = 0; };
// STL allocation failures must become ordinary FAC Resource errors at the C
// ABI boundary. Leave the catch scope before do_throw(), because FAC unwinding
// uses longjmp and must not bypass a live C++ exception object.
template <typename F>
static void fac_oom_guard(F &&work) {
  bool failed = false;
  try { work(); }
  catch (const std::bad_alloc &) { failed = true; }
  catch (const std::length_error &) { failed = true; }
  if (failed) do_throw("out of memory", 5);
}
template <typename R, typename F>
static R fac_oom_guard_result(F &&work) {
  R result{};
  bool failed = false;
  try { result = work(); }
  catch (const std::bad_alloc &) { failed = true; }
  catch (const std::length_error &) { failed = true; }
  if (failed) do_throw("out of memory", 5);
  return result;
}
struct KH { int code, sz; size_t operator()(std::string_view k) const { return hashv(code, k.data(), sz); } };
struct KE { int code; bool operator()(std::string_view a, std::string_view b) const { return cmpv(code, a.data(), b.data()) == 0; } };

// ---- hashmap / hashset (เรียงตามลำดับที่ใส่)
struct Item { std::string k, v; bool live; };
struct HMap : FacDS {
  // A flat open-addressed index avoids one allocator-backed STL node per key.
  // Slots contain item-index + 1; zero is empty and SIZE_MAX is a tombstone.
  // The item vector owns key/value blobs and preserves insertion order.
  static constexpr size_t EMPTY = 0;
  static constexpr size_t DELETED = std::numeric_limits<size_t>::max();
  static constexpr size_t INITIAL_CAPACITY = 32;
  Elem K, V;
  std::vector<Item> items;
  std::vector<size_t> slots;
  size_t nlive = 0, nused = 0, ndeleted = 0;

  HMap(Elem k, Elem v) : K(k), V(v) {}
  ~HMap() { clear(); }

  void releaseItem(Item &it) {
    if (!it.k.empty()) freev(K, it.k.data());
    if (V.sz && !it.v.empty()) freev(V, it.v.data());
    it.live = false;
  }
  void clear() override {
    for (auto &it : items) if (it.live) releaseItem(it);
    items.clear(); slots.clear(); nlive = nused = ndeleted = 0;
  }
  int64_t size() override { return (int64_t)nlive; }
  FacDS *clone() override {
    std::unique_ptr<HMap> copy(new HMap(K, V));
    for (auto &it : items) if (it.live)
      copy->put(it.k.data(), V.sz ? it.v.data() : nullptr);
    return copy.release();
  }

  static size_t probeNext(size_t pos, size_t step, size_t mask) {
    return (pos + step + 1) & mask; // triangular probing visits every power-of-two slot
  }
  size_t findSlot(const void *key) const {
    if (slots.empty()) return SIZE_MAX;
    const size_t mask = slots.size() - 1;
    size_t pos = hashv(K.code, key, K.sz) & mask;
    for (size_t step = 0; step < slots.size(); ++step) {
      const size_t entry = slots[pos];
      if (entry == EMPTY) return SIZE_MAX;
      if (entry != DELETED) {
        const Item &it = items[entry - 1];
        if (it.live && cmpv(K.code, key, it.k.data()) == 0) return pos;
      }
      pos = probeNext(pos, step, mask);
    }
    return SIZE_MAX;
  }
  size_t findIndex(const void *key) const {
    const size_t slot = findSlot(key);
    return slot == SIZE_MAX ? SIZE_MAX : slots[slot] - 1;
  }
  size_t insertionSlot(const void *key) const {
    const size_t mask = slots.size() - 1;
    size_t pos = hashv(K.code, key, K.sz) & mask;
    size_t firstDeleted = SIZE_MAX;
    for (size_t step = 0; step < slots.size(); ++step) {
      const size_t entry = slots[pos];
      if (entry == EMPTY) return firstDeleted == SIZE_MAX ? pos : firstDeleted;
      if (entry == DELETED && firstDeleted == SIZE_MAX) firstDeleted = pos;
      pos = probeNext(pos, step, mask);
    }
    return firstDeleted;
  }
  void insertKnownUnique(std::vector<size_t> &table, size_t itemIndex) const {
    const size_t mask = table.size() - 1;
    const Item &it = items[itemIndex];
    size_t pos = hashv(K.code, it.k.data(), K.sz) & mask;
    for (size_t step = 0; step < table.size(); ++step) {
      if (table[pos] == EMPTY) { table[pos] = itemIndex + 1; return; }
      pos = probeNext(pos, step, mask);
    }
    throw std::length_error("HashMap index capacity exhausted");
  }
  void rehash(size_t capacity) {
    if (capacity < INITIAL_CAPACITY) capacity = INITIAL_CAPACITY;
    if ((capacity & (capacity - 1)) != 0) throw std::length_error("invalid HashMap capacity");
    std::vector<size_t> fresh(capacity, EMPTY);
    for (size_t i = 0; i < items.size(); ++i)
      if (items[i].live) insertKnownUnique(fresh, i);
    slots.swap(fresh);
    nused = nlive;
    ndeleted = 0;
  }
  void prepareInsert() {
    if (slots.empty()) { rehash(INITIAL_CAPACITY); return; }
    const size_t maxFill = slots.size() - slots.size() / 4; // 75% maximum occupancy
    if (nused + 1 <= maxFill) return;
    const size_t liveAfterInsert = nlive + 1;
    if (liveAfterInsert <= maxFill) {
      rehash(slots.size()); // tombstones, not live keys, filled the table
    } else {
      if (slots.size() > std::numeric_limits<size_t>::max() / 2)
        throw std::length_error("HashMap capacity overflow");
      rehash(slots.size() * 2);
    }
  }

  Item *find(const void *key) {
    const size_t index = findIndex(key);
    return index == SIZE_MAX ? nullptr : &items[index];
  }
  void put(const void *key, const void *value) {
    const size_t existing = findIndex(key);
    if (existing != SIZE_MAX) {
      Item &it = items[existing];
      if (V.sz) {
        // Construct the new managed value before dropping the old one.
        std::string replacement = mkblob(V, value);
        freev(V, it.v.data());
        it.v = std::move(replacement);
      }
      return;
    }

    // Allocate/grow the index before taking ownership of a key or value.
    // After the item append succeeds, publishing its slot cannot throw.
    prepareInsert();
    const size_t slot = insertionSlot(key);
    if (slot == SIZE_MAX) throw std::length_error("HashMap index capacity exhausted");

    Item pending{};
    pending.live = true;
    try {
      pending.k = mkblob(K, key);
      if (V.sz) pending.v = mkblob(V, value);
      static_assert(std::is_nothrow_move_constructible<Item>::value,
                    "HashMap Item must remain nothrow-movable");
      items.push_back(std::move(pending));
    } catch (...) {
      if (!pending.k.empty()) freev(K, pending.k.data());
      if (V.sz && !pending.v.empty()) freev(V, pending.v.data());
      throw;
    }

    const size_t entry = items.size(); // index + 1 (zero is the empty marker)
    if (slots[slot] == DELETED) --ndeleted;
    else ++nused;
    slots[slot] = entry;
    ++nlive;
  }
  void erase(const void *key) {
    const size_t slot = findSlot(key);
    if (slot == SIZE_MAX) return;
    const size_t index = slots[slot] - 1;
    slots[slot] = DELETED;
    ++ndeleted;
    releaseItem(items[index]);
    --nlive;

    if (items.size() <= 32 || nlive * 2 >= items.size()) return;

    // Best-effort compaction keeps iteration storage proportional to live
    // entries. The current table and values remain untouched unless the full
    // replacement has been built successfully.
    std::vector<Item> compactItems;
    std::vector<size_t> compactSlots;
    try {
      compactItems.reserve(nlive);
      size_t capacity = INITIAL_CAPACITY;
      while (nlive > capacity - capacity / 4) {
        if (capacity > std::numeric_limits<size_t>::max() / 2)
          throw std::length_error("HashMap capacity overflow");
        capacity *= 2;
      }
      compactSlots.assign(capacity, EMPTY);
      for (const auto &source : items) if (source.live) {
        Item pending{};
        pending.live = true;
        try {
          pending.k = mkblob(K, source.k.data());
          if (V.sz) pending.v = mkblob(V, source.v.data());
          compactItems.push_back(std::move(pending));
        } catch (...) {
          if (!pending.k.empty()) freev(K, pending.k.data());
          if (V.sz && !pending.v.empty()) freev(V, pending.v.data());
          throw;
        }
        const size_t compactIndex = compactItems.size() - 1;
        const size_t mask = compactSlots.size() - 1;
        size_t pos = hashv(K.code, compactItems.back().k.data(), K.sz) & mask;
        bool inserted = false;
        for (size_t step = 0; step < compactSlots.size(); ++step) {
          if (compactSlots[pos] == EMPTY) {
            compactSlots[pos] = compactIndex + 1;
            inserted = true;
            break;
          }
          pos = probeNext(pos, step, mask);
        }
        if (!inserted) throw std::length_error("HashMap compaction index capacity exhausted");
      }
    } catch (...) {
      for (auto &it : compactItems) if (it.live) releaseItem(it);
      return;
    }

    for (auto &it : items) if (it.live) releaseItem(it);
    items.swap(compactItems);
    slots.swap(compactSlots);
    nused = nlive;
    ndeleted = 0;
  }
};
struct Tree : FacDS {  // AVL
  struct N { std::string k; N *l = nullptr, *r = nullptr; int h = 1; };
  Elem K; N *root = nullptr; int64_t n = 0;
  Tree(Elem k) : K(k) {}
  ~Tree() { clear(); }
  static int H(N *x) { return x ? x->h : 0; }
  static void upd(N *x) { x->h = 1 + std::max(H(x->l), H(x->r)); }
  static N *rotR(N *y) { N *x = y->l; y->l = x->r; x->r = y; upd(y); upd(x); return x; }
  static N *rotL(N *x) { N *y = x->r; x->r = y->l; y->l = x; upd(x); upd(y); return y; }
  N *bal(N *x) {
    upd(x); int b = H(x->l) - H(x->r);
    if (b > 1) { if (H(x->l->l) < H(x->l->r)) x->l = rotL(x->l); return rotR(x); }
    if (b < -1) { if (H(x->r->r) < H(x->r->l)) x->r = rotR(x->r); return rotL(x); }
    return x;
  }
  N *ins(N *x, const void *k, bool &added) {
    if (!x) { std::unique_ptr<N> t(new N); t->k = mkblob(K, k); added = true; return t.release(); }
    int c = cmpv(K.code, k, x->k.data());
    if (c < 0) x->l = ins(x->l, k, added); else if (c > 0) x->r = ins(x->r, k, added); else return x;
    return bal(x);
  }
  N *minN(N *x) { while (x->l) x = x->l; return x; }
  N *del(N *x, const void *k, bool &removed) {
    if (!x) return nullptr;
    int c = cmpv(K.code, k, x->k.data());
    if (c < 0) x->l = del(x->l, k, removed); else if (c > 0) x->r = del(x->r, k, removed);
    else {
      removed = true;
      if (!x->l || !x->r) { N *t = x->l ? x->l : x->r; freev(K, &x->k[0]); delete x; return t; }
      N *m = minN(x->r); std::string mk = m->k;      // เตรียมก่อนเปลี่ยนเจ้าของ key
      freev(K, &x->k[0]); x->k = std::move(mk); bool dummy = false;
      x->r = delRaw(x->r, x->k.data(), dummy);        // ลบ node เดิมของ successor โดยไม่ free key
    }
    return bal(x);
  }
  N *delRaw(N *x, const void *k, bool &removed) {  // เหมือน del แต่ไม่ free key ของ node ที่ลบ (เจ้าของ key ย้ายไปแล้ว)
    if (!x) return nullptr;
    int c = cmpv(K.code, k, x->k.data());
    if (c < 0) x->l = delRaw(x->l, k, removed); else if (c > 0) x->r = delRaw(x->r, k, removed);
    else { removed = true; N *t = x->l ? x->l : x->r; if (x->l && x->r) { N *m = minN(x->r); std::string replacement = m->k; x->k = std::move(replacement); bool d = false; x->r = delRaw(x->r, x->k.data(), d); return bal(x); } delete x; return t; }
    return bal(x);
  }
  void freeAll(N *x) { if (!x) return; freeAll(x->l); freeAll(x->r); freev(K, &x->k[0]); delete x; }
  void clear() override { freeAll(root); root = nullptr; n = 0; }
  int64_t size() override { return n; }
  N *cp(N *x) {
    if (!x) return nullptr;
    std::unique_ptr<N> t(new N);
    t->k = mkblob(K, x->k.data()); t->h = x->h;
    try { t->l = cp(x->l); t->r = cp(x->r); }
    catch (...) {
      freeAll(t->l); t->l = nullptr;
      freeAll(t->r); t->r = nullptr;
      if (!t->k.empty()) freev(K, t->k.data());
      t->k.clear();
      throw;
    }
    return t.release();
  }
  FacDS *clone() override { std::unique_ptr<Tree> t(new Tree(K)); t->root = cp(root); t->n = n; return t.release(); }
  void walk(N *x, int mode, std::vector<const std::string *> &o) {
    if (!x) return;
    if (mode == 1) o.push_back(&x->k);
    walk(x->l, mode, o);
    if (mode == 0) o.push_back(&x->k);
    walk(x->r, mode, o);
    if (mode == 2) o.push_back(&x->k);
  }
};
struct Graph : FacDS {
  struct Edge { int to; double w; };
  // Stable node blobs back the non-owning string_view key index. High-degree
  // adjacency rows gain a secondary hash index; low-degree rows stay compact
  // vectors to avoid the per-node overhead of a hash table.
  static constexpr size_t kNeighborIndexThreshold = 48;
  Elem K;
  std::deque<std::string> nodes;
  std::vector<bool> alive;
  std::vector<std::vector<Edge>> adj;
  std::vector<std::unique_ptr<std::unordered_set<int>>> neighbor_index;
  std::unordered_map<std::string_view, int, KH, KE> idx;
  int64_t live = 0;

  Graph(Elem k) : K(k), idx(16, KH{k.code, k.sz}, KE{k.code}) {}
  std::string_view keyView(const void *k) const { return std::string_view((const char *)k, (size_t)K.sz); }
  std::string_view storedKey(const std::string &key) const { return std::string_view(key.data(), key.size()); }

  template <typename T>
  static void reserveGeometric(std::vector<T> &v, size_t required) {
    if (required <= v.capacity()) return;
    const size_t max = v.max_size();
    if (required > max) throw std::length_error("Graph capacity exceeded");
    size_t grown = v.capacity() ? v.capacity() : 8;
    while (grown < required) {
      if (grown > max / 2) { grown = required; break; }
      grown *= 2;
    }
    v.reserve(grown);
  }

  bool hasNeighbor(int from, int to) const {
    if (from < 0 || (size_t)from >= adj.size()) return false;
    if ((size_t)from < neighbor_index.size() && neighbor_index[(size_t)from])
      return neighbor_index[(size_t)from]->find(to) != neighbor_index[(size_t)from]->end();
    for (const auto &e : adj[(size_t)from]) if (e.to == to) return true;
    return false;
  }

  ~Graph() { clear(); }
  void clear() override {
    idx.clear();
    for (size_t i = 0; i < nodes.size(); i++)
      if (i < alive.size() && alive[i] && !nodes[i].empty()) freev(K, nodes[i].data());
    nodes.clear(); alive.clear(); adj.clear(); neighbor_index.clear(); live = 0;
  }
  int64_t size() override { return live; }

  FacDS *clone() override {
    std::unique_ptr<Graph> copy(new Graph(K));
    copy->alive.reserve(alive.size());
    copy->adj.reserve(adj.size());
    copy->neighbor_index.reserve(neighbor_index.size());
    copy->idx.reserve((size_t)live);
    for (size_t i = 0; i < nodes.size(); i++) {
      std::vector<Edge> edges = adj[i];
      std::unique_ptr<std::unordered_set<int>> edgeIndex;
      if (i < neighbor_index.size() && neighbor_index[i])
        edgeIndex.reset(new std::unordered_set<int>(*neighbor_index[i]));
      const bool nodeAlive = i < alive.size() && alive[i];
      std::string key = nodeAlive ? mkblob(K, nodes[i].data()) : nodes[i];
      try { copy->nodes.push_back(std::move(key)); }
      catch (...) {
        if (nodeAlive && !key.empty()) freev(K, key.data());
        throw;
      }
      copy->alive.push_back(nodeAlive);
      copy->adj.push_back(std::move(edges));
      copy->neighbor_index.push_back(std::move(edgeIndex));
      if (nodeAlive) copy->idx.emplace(copy->storedKey(copy->nodes.back()), (int)i);
    }
    copy->live = live;
    return copy.release();
  }

  int get(const void *k, bool create, bool *created = nullptr) {
    if (created) *created = false;
    const std::string_view lookup = keyView(k);
    auto i = idx.find(lookup);
    if (i != idx.end()) return i->second;
    if (!create) return -1;
    if (nodes.size() >= (size_t)INT32_MAX) do_throw("graph node limit exceeded", 5);

    // Grow every parallel array geometrically before publishing the node.
    // The hash table manages its own load factor; reserve(size + 1) here would
    // force repeated rehashing and turn bulk insertion quadratic.
    const size_t required = nodes.size() + 1;
    reserveGeometric(alive, required);
    reserveGeometric(adj, required);
    reserveGeometric(neighbor_index, required);

    std::string ownedKey = mkblob(K, k);
    try {
      nodes.push_back(std::move(ownedKey));
    } catch (...) {
      if (!ownedKey.empty()) freev(K, ownedKey.data());
      throw;
    }

    const int id = (int)nodes.size() - 1;
    try {
      auto inserted = idx.emplace(storedKey(nodes.back()), id);
      if (!inserted.second) {
        freev(K, nodes.back().data());
        nodes.pop_back();
        return inserted.first->second;
      }
    } catch (...) {
      freev(K, nodes.back().data());
      nodes.pop_back();
      throw;
    }

    // Outer capacity is already available; these pushes cannot allocate.
    alive.push_back(true);
    adj.emplace_back();
    neighbor_index.emplace_back(nullptr);
    ++live;
    if (created) *created = true;
    return id;
  }

  void rollbackLastNode(int id) noexcept {
    if (id < 0 || nodes.empty() || (size_t)id + 1 != nodes.size() ||
        (size_t)id >= alive.size() || !alive[(size_t)id] ||
        (size_t)id >= adj.size() || !adj[(size_t)id].empty()) return;
    idx.erase(storedKey(nodes[(size_t)id]));
    freev(K, nodes[(size_t)id].data());
    nodes.pop_back(); alive.pop_back(); adj.pop_back(); neighbor_index.pop_back();
    if (live > 0) --live;
  }

  void edge(int a, int b, double w, bool directed) {
    const bool forward = hasNeighbor(a, b);
    const bool reverse = (!directed && a != b) ? hasNeighbor(b, a) : false;

    // Prepare active-index insertions before changing edge vectors. An index
    // that crosses the threshold is built off to the side and only published
    // after both edge directions have committed successfully.
    bool insertedActiveA = false, insertedActiveB = false;
    std::unique_ptr<std::unordered_set<int>> stagedA, stagedB;
    auto prepareIndex = [&](int from, int to, bool needed, bool &insertedActive,
                            std::unique_ptr<std::unordered_set<int>> &staged) {
      if (!needed) return;
      auto &current = neighbor_index[(size_t)from];
      if (current) {
        insertedActive = current->insert(to).second;
        return;
      }
      const auto &row = adj[(size_t)from];
      if (row.size() + 1 < kNeighborIndexThreshold) return;
      staged.reset(new std::unordered_set<int>());
      staged->reserve((row.size() + 1) * 2);
      for (const auto &e : row) staged->insert(e.to);
      staged->insert(to);
    };

    try {
      prepareIndex(a, b, !forward, insertedActiveA, stagedA);
      if (!directed && a != b)
        prepareIndex(b, a, !reverse, insertedActiveB, stagedB);

      bool pushedA = false;
      try {
        if (!forward) { adj[(size_t)a].push_back({b, w}); pushedA = true; }
        if (!directed && a != b && !reverse) adj[(size_t)b].push_back({a, w});
      } catch (...) {
        if (pushedA) adj[(size_t)a].pop_back();
        throw;
      }
    } catch (...) {
      if (insertedActiveA && neighbor_index[(size_t)a]) neighbor_index[(size_t)a]->erase(b);
      if (insertedActiveB && neighbor_index[(size_t)b]) neighbor_index[(size_t)b]->erase(a);
      throw;
    }

    if (stagedA) neighbor_index[(size_t)a] = std::move(stagedA);
    if (stagedB) neighbor_index[(size_t)b] = std::move(stagedB);
    if (forward) {
      for (auto &e : adj[(size_t)a]) if (e.to == b) { e.w = w; break; }
    }
    if (!directed && a != b && reverse) {
      for (auto &e : adj[(size_t)b]) if (e.to == a) { e.w = w; break; }
    }
  }

  void removeOne(int from, int to) noexcept {
    auto &row = adj[(size_t)from];
    for (size_t i = 0; i < row.size(); ++i) {
      if (row[i].to == to) {
        row.erase(row.begin() + (ptrdiff_t)i);
        if (neighbor_index[(size_t)from]) neighbor_index[(size_t)from]->erase(to);
        return;
      }
    }
  }

  void addEdge(const void *from, const void *to, double w, bool directed) {
    if (!std::isfinite(w) || w < 0.0)
      do_throw("graph edge weight must be finite and non-negative", 8);
    int a = -1, b = -1; bool createdA = false, createdB = false;
    try {
      a = get(from, true, &createdA);
      b = get(to, true, &createdB);
      edge(a, b, w, directed);
    } catch (...) {
      if (createdB) rollbackLastNode(b);
      if (createdA) rollbackLastNode(a);
      throw;
    }
  }

  FacList *order(const std::vector<int> &o) {
    std::vector<const std::string *> v;
    v.reserve(o.size());
    for (int i : o) v.push_back(&nodes[(size_t)i]);
    return mklist(K, v);
  }
};
struct Linked : FacDS {
  Elem E; std::list<std::string> l;
  Linked(Elem e) : E(e) {}
  ~Linked() { clear(); }
  void clear() override { for (auto &b : l) freev(E, &b[0]); l.clear(); }
  int64_t size() override { return (int64_t)l.size(); }
  FacDS *clone() override { std::unique_ptr<Linked> n(new Linked(E)); for (auto &b : l) fac_blob_push_back(n->l, E, b.data()); return n.release(); }
};
// ---- stack / queue / binary min-heap (all own copied elements)
struct StackDS : FacDS {
  Elem E; std::vector<std::string> v;
  explicit StackDS(Elem e) : E(e) {}
  ~StackDS() { clear(); }
  void clear() override { for (auto &x : v) if (!x.empty()) freev(E, &x[0]); v.clear(); }
  int64_t size() override { return (int64_t)v.size(); }
  FacDS *clone() override { std::unique_ptr<StackDS> r(new StackDS(E)); for (auto &x : v) fac_blob_push_back(r->v, E, x.data()); return r.release(); }
  void push(const void *x) { fac_blob_push_back(v, E, x); }
  void peek(void *out) { if (v.empty()) do_throw("stack is empty", 8); memcpy(out, v.back().data(), (size_t)E.sz); }
  void pop(void *out) { if (v.empty()) do_throw("stack is empty", 8); std::string x = std::move(v.back()); v.pop_back(); memcpy(out, x.data(), (size_t)E.sz); }
};
struct QueueDS : FacDS {
  Elem E; std::deque<std::string> q;
  explicit QueueDS(Elem e) : E(e) {}
  ~QueueDS() { clear(); }
  void clear() override { for (auto &x : q) if (!x.empty()) freev(E, &x[0]); q.clear(); }
  int64_t size() override { return (int64_t)q.size(); }
  FacDS *clone() override { std::unique_ptr<QueueDS> r(new QueueDS(E)); for (auto &x : q) fac_blob_push_back(r->q, E, x.data()); return r.release(); }
  void enqueue(const void *x) { fac_blob_push_back(q, E, x); }
  void front(void *out) { if (q.empty()) do_throw("queue is empty", 8); memcpy(out, q.front().data(), (size_t)E.sz); }
  void back(void *out) { if (q.empty()) do_throw("queue is empty", 8); memcpy(out, q.back().data(), (size_t)E.sz); }
  void dequeue(void *out) { if (q.empty()) do_throw("queue is empty", 8); std::string x = std::move(q.front()); q.pop_front(); memcpy(out, x.data(), (size_t)E.sz); }
};
struct HeapDS : FacDS {
  Elem E; std::vector<std::string> v; bool maxHeap;
  explicit HeapDS(Elem e, bool mx = false) : E(e), maxHeap(mx) {}
  ~HeapDS() { clear(); }
  bool cmp(const std::string &a, const std::string &b) const { int c = cmpv(E.code, a.data(), b.data()); return maxHeap ? c < 0 : c > 0; } // min-heap / max-heap
  void clear() override { for (auto &x : v) if (!x.empty()) freev(E, &x[0]); v.clear(); }
  int64_t size() override { return (int64_t)v.size(); }
  FacDS *clone() override { std::unique_ptr<HeapDS> r(new HeapDS(E, maxHeap)); for (auto &x : v) fac_blob_push_back(r->v, E, x.data()); std::make_heap(r->v.begin(), r->v.end(), [r = r.get()](const std::string &a, const std::string &b) { return r->cmp(a, b); }); return r.release(); }
  void push(const void *x) { fac_blob_push_back(v, E, x); std::push_heap(v.begin(), v.end(), [this](const std::string &a, const std::string &b) { return cmp(a, b); }); }
  void peek(void *out) { if (v.empty()) do_throw("heap is empty", 8); memcpy(out, v.front().data(), (size_t)E.sz); }
  void pop(void *out) { if (v.empty()) do_throw("heap is empty", 8); std::pop_heap(v.begin(), v.end(), [this](const std::string &a, const std::string &b) { return cmp(a, b); }); std::string x = std::move(v.back()); v.pop_back(); memcpy(out, x.data(), (size_t)E.sz); }
};
// ---- trie for UTF-8 byte strings
struct TrieDS : FacDS {
  struct Node;
  struct Child { unsigned char key; std::unique_ptr<Node> node; };
  struct Node {
    bool end = false;
    std::vector<Child> next;
    Node *parent = nullptr;
    Node *gcNext = nullptr; // Intrusive worklist link for stack-safe subtree destruction.
    unsigned char parentKey = 0;
  };
  Node root; int64_t n = 0;
  static auto child(Node *x, unsigned char c) { return std::lower_bound(x->next.begin(), x->next.end(), c, [](const Child &a, unsigned char b) { return a.key < b; }); }
  static auto child(const Node *x, unsigned char c) { return std::lower_bound(x->next.begin(), x->next.end(), c, [](const Child &a, unsigned char b) { return a.key < b; }); }
  // unique_ptr's default destruction follows child pointers recursively. Detach
  // every edge first, then delete nodes from an intrusive worklist so a key's
  // byte length cannot consume the C++ call stack.
  static void destroySubtree(Node *pending) noexcept {
    while (pending) {
      Node *current = pending;
      pending = current->gcNext;
      for (Child &edge : current->next) if (edge.node) {
        Node *descendant = edge.node.release();
        descendant->gcNext = pending;
        pending = descendant;
      }
      current->next.clear(); // all unique_ptrs were released above
      delete current;
    }
  }
  ~TrieDS() override { clear(); }
  void clear() override {
    Node *pending = nullptr;
    for (Child &edge : root.next) if (edge.node) {
      Node *descendant = edge.node.release();
      descendant->gcNext = pending;
      pending = descendant;
    }
    root.next.clear();
    root.end = false; n = 0;
    destroySubtree(pending);
  }
  int64_t size() override { return n; }
  FacDS *clone() override { std::unique_ptr<TrieDS> r(new TrieDS()); std::vector<std::string> all; collect(&root, std::string(), all); for (auto &x : all) r->insert(x); return r.release(); }
  static std::string value(const void *p) { FacStr *s = *(FacStr *const *)p; return s ? std::string(sd(s), (size_t)sl(s)) : std::string(); }
  void insert(const std::string &s) {
    Node *x = &root;
    Node *firstCreatedParent = nullptr;
    unsigned char firstCreatedKey = 0;
    try {
      for (unsigned char c : s) {
        auto it = child(x, c);
        if (it == x->next.end() || it->key != c) {
          auto fresh = std::make_unique<Node>();
          fresh->parent = x; fresh->parentKey = c;
          it = x->next.insert(it, Child{c, std::move(fresh)});
          // Once a path edge is absent, every later node in this insertion is
          // new. Remember its first edge so a failed insertion can roll back
          // the whole unpublished suffix without allocating another path.
          if (!firstCreatedParent) { firstCreatedParent = x; firstCreatedKey = c; }
        }
        x = it->node.get();
      }
    } catch (...) {
      if (firstCreatedParent) {
        auto it = child(firstCreatedParent, firstCreatedKey);
        if (it != firstCreatedParent->next.end() && it->key == firstCreatedKey) {
          destroySubtree(it->node.release());
          firstCreatedParent->next.erase(it);
        }
      }
      throw;
    }
    if (!x->end) { x->end = true; n++; }
  }
  bool has(const std::string &s) const { const Node *x = &root; for (unsigned char c : s) { auto it = child(x, c); if (it == x->next.end() || it->key != c) return false; x = it->node.get(); } return x->end; }
  bool prefix(const std::string &s) const { const Node *x = &root; for (unsigned char c : s) { auto it = child(x, c); if (it == x->next.end() || it->key != c) return false; x = it->node.get(); } return true; }
  void remove(const std::string &s) {
    Node *current = &root;
    for (unsigned char c : s) {
      auto it = child(current, c);
      if (it == current->next.end() || it->key != c) return;
      current = it->node.get();
    }
    if (!current->end) return;
    current->end = false; --n;
    // Parent links let us prune the now-empty suffix without recursion or an
    // auxiliary path allocation. Node addresses remain stable across vector moves.
    while (current != &root && !current->end && current->next.empty()) {
      Node *parent = current->parent;
      const unsigned char edge = current->parentKey;
      auto it = child(parent, edge);
      if (it == parent->next.end() || it->key != edge || it->node.get() != current) break;
      std::unique_ptr<Node> removed = std::move(it->node);
      parent->next.erase(it);
      destroySubtree(removed.release()); // current has no children at this point
      current = parent;
    }
  }
  static void collect(const Node *rootNode, const std::string &prefix, std::vector<std::string> &out) {
    struct Frame { const Node *node; size_t nextChild; size_t pathLength; bool emitted; };
    std::string path = prefix;
    std::vector<Frame> stack;
    stack.push_back({rootNode, 0, path.size(), false});
    while (!stack.empty()) {
      Frame &frame = stack.back();
      if (!frame.emitted) {
        if (frame.node->end) out.push_back(path);
        frame.emitted = true;
      }
      if (frame.nextChild < frame.node->next.size()) {
        const Child &edge = frame.node->next[frame.nextChild++];
        path.push_back((char)edge.key);
        stack.push_back({edge.node.get(), 0, path.size(), false});
      } else {
        stack.pop_back();
        if (!stack.empty()) path.resize(stack.back().pathLength);
      }
    }
  }
  FacList *words(const std::string &prefix) const {
    const Node *x = &root;
    for (unsigned char c : prefix) { auto it = child(x, c); if (it == x->next.end() || it->key != c) return fac_list_new(8, 1); x = it->node.get(); }
    std::vector<std::string> strings; collect(x, prefix, strings);
    FacList *l = fac_list_new(8, 1);
    for (auto &v : strings) { if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = mks(v); }
    return l;
  }
};
// ---- fixed-size two-dimensional matrix. Payload bytes are contiguous row-major.
struct MatrixDS : FacDS {
  Elem E; int64_t R, C; std::vector<unsigned char> data;
  MatrixDS(int64_t r, int64_t c, Elem e) : E(e), R(r), C(c) {
    if (r <= 0 || c <= 0 || r > INT64_MAX / c || r * c > INT32_MAX || e.sz <= 0 || (uint64_t)(r * c) > SIZE_MAX / (size_t)e.sz)
      do_throw("invalid matrix dimensions", 5);
    data.resize((size_t)(r * c) * (size_t)e.sz, 0);
  }
  ~MatrixDS() { clear(); }
  void clear() override {
    if (E.code == 14) for (int64_t i = 0; i < R * C; i++) { FacStr **p = (FacStr **)(data.data() + (size_t)i * E.sz); if (*p) fac_str_free(*p); }
    std::fill(data.begin(), data.end(), 0);
  }
  int64_t size() override { return R * C; }
  FacDS *clone() override { std::unique_ptr<MatrixDS> m(new MatrixDS(R, C, E)); for (int64_t i = 0; i < R * C; i++) { const void *src = data.data() + (size_t)i * E.sz; void *dst = m->data.data() + (size_t)i * E.sz; if (E.code == 14) { FacStr *v = *(FacStr *const *)src; *(FacStr **)dst = v ? fac_str_dup(v) : nullptr; } else memcpy(dst, src, (size_t)E.sz); } return m.release(); }
  void *at(int64_t r, int64_t c) { if (r < 0 || r >= R) fac_oob(r, R); if (c < 0 || c >= C) fac_oob(c, C); return data.data() + (size_t)(r * C + c) * E.sz; }
  void set(int64_t r, int64_t c, const void *src) {
    void *dst = at(r, c);
    if (E.code == 14) {
      FacStr *v = *(FacStr *const *)src;
      FacStr *copy = v ? fac_str_dup(v) : nullptr; // duplicate before freeing; src may alias dst
      FacStr *old = *(FacStr **)dst;
      if (old) fac_str_free(old);
      *(FacStr **)dst = copy;
    } else memcpy(dst, src, (size_t)E.sz);
  }
  void get(int64_t r, int64_t c, void *dst) { memcpy(dst, at(r, c), (size_t)E.sz); }
  void fill(const void *src) {
    if (E.code == 14) {
      FacStr *v = *(FacStr *const *)src;
      FacStr *snapshot = v ? fac_str_dup(v) : nullptr; // keep source alive while every cell is replaced
      for (int64_t i = 0; i < R * C; i++) {
        FacStr **dst = (FacStr **)(data.data() + (size_t)i * E.sz);
        FacStr *copy = snapshot ? fac_str_dup(snapshot) : nullptr;
        if (*dst) fac_str_free(*dst);
        *dst = copy;
      }
      if (snapshot) fac_str_free(snapshot);
    } else {
      std::vector<unsigned char> snapshot((size_t)E.sz);
      memcpy(snapshot.data(), src, (size_t)E.sz);
      for (int64_t i = 0; i < R * C; i++) memcpy(data.data() + (size_t)i * E.sz, snapshot.data(), (size_t)E.sz);
    }
  }
};
}  // extern "C++"

extern "C" {
void fac_ds_free(FacDS *d) { delete d; }
FacDS *fac_ds_copy(FacDS *d) {
  return d ? fac_oom_guard_result<FacDS *>([&] { return d->clone(); }) : nullptr;
}
int64_t fac_ds_len(FacDS *d) { return d ? d->size() : 0; }
void fac_ds_clear(FacDS *d) { d->clear(); }
// ---- hashmap
FacDS *fac_hm_new(int32_t kc, int32_t ksz, int32_t vc, int32_t vsz) {
  return fac_oom_guard_result<FacDS *>([&] { return new HMap({kc, ksz}, {vc, vsz}); });
}
void fac_hm_set(HMap *m, const void *k, const void *v) { fac_oom_guard([&] { m->put(k, v); }); }
void fac_hm_get(HMap *m, const void *k, void *out) {
  Item *it = m->find(k);
  if (!it) { if (m->K.code == 14) do_throw(std::string("key not found: ") + sd(*(FacStr *const *)k), 8); do_throw("key not found", 8); }
  memcpy(out, it->v.data(), (size_t)m->V.sz);
}
void fac_hm_getor(HMap *m, const void *k, const void *def, void *out) { Item *it = m->find(k); memcpy(out, it ? it->v.data() : (const char *)def, (size_t)m->V.sz); }
int32_t fac_hm_has(HMap *m, const void *k) { return m->find(k) != nullptr; }
void fac_hm_remove(HMap *m, const void *k) { m->erase(k); }
FacList *fac_hm_keys(HMap *m) { return fac_oom_guard_result<FacList *>([&] { std::vector<const std::string *> v; for (auto &i : m->items) if (i.live) v.push_back(&i.k); return mklist(m->K, v); }); }
FacList *fac_hm_values(HMap *m) { return fac_oom_guard_result<FacList *>([&] { std::vector<const std::string *> v; for (auto &i : m->items) if (i.live) v.push_back(&i.v); return mklist(m->V, v); }); }
// ---- hashset
FacDS *fac_hs_new(int32_t kc, int32_t ksz) {
  return fac_oom_guard_result<FacDS *>([&] { return new HMap({kc, ksz}, {0, 0}); });
}
void fac_hs_add(HMap *m, const void *k) { fac_oom_guard([&] { m->put(k, nullptr); }); }
FacList *fac_hs_tolist(HMap *m) { return fac_hm_keys(m); }
FacDS *fac_hs_union(HMap *a, HMap *b) {
  return fac_oom_guard_result<FacDS *>([&] {
    std::unique_ptr<HMap> result(static_cast<HMap *>(a->clone()));
    for (auto &i : b->items) if (i.live) result->put(i.k.data(), nullptr);
    return result.release();
  });
}
FacDS *fac_hs_intersect(HMap *a, HMap *b) {
  return fac_oom_guard_result<FacDS *>([&] {
    std::unique_ptr<HMap> result(new HMap(a->K, a->V));
    for (auto &i : a->items) if (i.live && b->find(i.k.data())) result->put(i.k.data(), nullptr);
    return result.release();
  });
}
FacDS *fac_hs_diff(HMap *a, HMap *b) {
  return fac_oom_guard_result<FacDS *>([&] {
    std::unique_ptr<HMap> result(new HMap(a->K, a->V));
    for (auto &i : a->items) if (i.live && !b->find(i.k.data())) result->put(i.k.data(), nullptr);
    return result.release();
  });
}
// ---- tree
FacDS *fac_tr_new(int32_t kc, int32_t ksz) { return fac_oom_guard_result<FacDS *>([&] { return new Tree({kc, ksz}); }); }
void fac_tr_add(Tree *t, const void *k) { fac_oom_guard([&] { bool a = false; t->root = t->ins(t->root, k, a); if (a) t->n++; }); }
int32_t fac_tr_has(Tree *t, const void *k) { Tree::N *x = t->root; while (x) { int c = cmpv(t->K.code, k, x->k.data()); if (!c) return 1; x = c < 0 ? x->l : x->r; } return 0; }
void fac_tr_remove(Tree *t, const void *k) { fac_oom_guard([&] { bool r = false; t->root = t->del(t->root, k, r); if (r) t->n--; }); }
void fac_tr_min(Tree *t, void *out) { if (!t->root) do_throw("tree is empty", 8); memcpy(out, t->minN(t->root)->k.data(), (size_t)t->K.sz); }
void fac_tr_max(Tree *t, void *out) { if (!t->root) do_throw("tree is empty", 8); Tree::N *x = t->root; while (x->r) x = x->r; memcpy(out, x->k.data(), (size_t)t->K.sz); }
int32_t fac_tr_height(Tree *t) { return Tree::H(t->root); }
FacList *fac_tr_walk(Tree *t, int32_t mode) { return fac_oom_guard_result<FacList *>([&] { std::vector<const std::string *> v; t->walk(t->root, mode, v); return mklist(t->K, v); }); }
FacList *fac_tr_inorder(Tree *t) { return fac_tr_walk(t, 0); }
FacList *fac_tr_preorder(Tree *t) { return fac_tr_walk(t, 1); }
FacList *fac_tr_postorder(Tree *t) { return fac_tr_walk(t, 2); }
// ---- graph
FacDS *fac_g_new(int32_t kc, int32_t ksz) {
  return fac_oom_guard_result<FacDS *>([&] { return new Graph({kc, ksz}); });
}
void fac_g_addnode(Graph *g, const void *k) { fac_oom_guard([&] { g->get(k, true); }); }
void fac_g_addedge2(Graph *g, const void *a, const void *b) { fac_oom_guard([&] { g->addEdge(a, b, 1, false); }); }
void fac_g_addedge3(Graph *g, const void *a, const void *b, double w) { fac_oom_guard([&] { g->addEdge(a, b, w, false); }); }
void fac_g_addarc2(Graph *g, const void *a, const void *b) { fac_oom_guard([&] { g->addEdge(a, b, 1, true); }); }
void fac_g_addarc3(Graph *g, const void *a, const void *b, double w) { fac_oom_guard([&] { g->addEdge(a, b, w, true); }); }
FacList *fac_g_neighbors(Graph *g, const void *k) {
  return fac_oom_guard_result<FacList *>([&] {
    int a = g->get(k, false); if (a < 0) do_throw("node not found", 8);
    std::vector<int> o;
    for (auto &e : g->adj[a]) if (g->alive[e.to]) o.push_back(e.to);
    return g->order(o);
  });
}
int32_t fac_g_hasedge(Graph *g, const void *a, const void *b) {
  int x = g->get(a, false), y = g->get(b, false);
  return x >= 0 && y >= 0 && g->hasNeighbor(x, y) ? 1 : 0;
}
void fac_g_removeedge(Graph *g, const void *a, const void *b) {
  int x = g->get(a, false), y = g->get(b, false); if (x < 0 || y < 0) return;
  g->removeOne(x, y);
  if (x != y) g->removeOne(y, x);
}
void fac_g_removenode(Graph *g, const void *k) {
  int a = g->get(k, false); if (a < 0) return;
  for (size_t from = 0; from < g->adj.size(); ++from) {
    if ((int)from == a) continue;
    auto &row = g->adj[from];
    for (size_t i = 0; i < row.size();) {
      if (row[i].to == a) {
        row.erase(row.begin() + (ptrdiff_t)i);
        if (g->neighbor_index[from]) g->neighbor_index[from]->erase(a);
      } else ++i;
    }
  }
  g->adj[(size_t)a].clear();
  if (g->neighbor_index[(size_t)a]) g->neighbor_index[(size_t)a]->clear();
  g->idx.erase(g->storedKey(g->nodes[(size_t)a]));
  freev(g->K, g->nodes[(size_t)a].data());
  g->alive[(size_t)a] = false;
  --g->live;
}
FacList *fac_g_bfs(Graph *g, const void *s) {
  return fac_oom_guard_result<FacList *>([&] {
    int a = g->get(s, false); if (a < 0) do_throw("node not found", 8);
    std::vector<int> o; std::vector<bool> seen(g->nodes.size()); std::queue<int> q; q.push(a); seen[(size_t)a] = true;
    while (!q.empty()) { int x = q.front(); q.pop(); o.push_back(x); for (auto &e : g->adj[(size_t)x]) if (g->alive[(size_t)e.to] && !seen[(size_t)e.to]) { seen[(size_t)e.to] = true; q.push(e.to); } }
    return g->order(o);
  });
}
FacList *fac_g_dfs(Graph *g, const void *s) {
  return fac_oom_guard_result<FacList *>([&] {
    int a = g->get(s, false); if (a < 0) do_throw("node not found", 8);
    std::vector<int> o; std::vector<bool> seen(g->nodes.size()); std::vector<int> st{a};
    while (!st.empty()) {
      int x = st.back(); st.pop_back(); if (seen[(size_t)x]) continue; seen[(size_t)x] = true; o.push_back(x);
      for (size_t i = g->adj[(size_t)x].size(); i > 0; i--) { int t = g->adj[(size_t)x][i - 1].to; if (g->alive[(size_t)t] && !seen[(size_t)t]) st.push_back(t); }
    }
    return g->order(o);
  });
}
FacList *fac_g_shortest(Graph *g, const void *s, const void *t) {
  return fac_oom_guard_result<FacList *>([&] {
    int a = g->get(s, false), b = g->get(t, false); if (a < 0 || b < 0) do_throw("node not found", 8);
    const size_t n = g->nodes.size();
    const double infinity = std::numeric_limits<double>::infinity();
    std::vector<double> dist(n, infinity);
    std::vector<int> prev(n, -1);
    typedef std::pair<double, int> P;
    std::priority_queue<P, std::vector<P>, std::greater<P>> pq;
    dist[(size_t)a] = 0.0; pq.push({0.0, a});
    while (!pq.empty()) {
      P p = pq.top(); pq.pop();
      const int x = p.second;
      if (p.first != dist[(size_t)x]) continue;
      if (x == b) break; // valid because Graph rejects negative/non-finite weights
      for (const auto &e : g->adj[(size_t)x]) {
        if (!g->alive[(size_t)e.to]) continue;
        const double candidate = dist[(size_t)x] + e.w;
        if (candidate < dist[(size_t)e.to]) {
          dist[(size_t)e.to] = candidate;
          prev[(size_t)e.to] = x;
          pq.push({candidate, e.to});
        }
      }
    }
    std::vector<int> path;
    if (std::isfinite(dist[(size_t)b]))
      for (int x = b; x != -1; x = prev[(size_t)x]) path.push_back(x);
    std::reverse(path.begin(), path.end()); return g->order(path);
  });
}
// ---- linked (doubly linked list)
FacDS *fac_ll_new(int32_t code, int32_t sz) { return fac_oom_guard_result<FacDS *>([&] { return new Linked({code, sz}); }); }
void fac_ll_addfirst(Linked *d, const void *v) { fac_oom_guard([&] { fac_blob_push_front(d->l, d->E, v); }); }
void fac_ll_addlast(Linked *d, const void *v) { fac_oom_guard([&] { fac_blob_push_back(d->l, d->E, v); }); }
void fac_ll_removefirst(Linked *d) { if (d->l.empty()) do_throw("linked is empty", 8); freev(d->E, &d->l.front()[0]); d->l.pop_front(); }
void fac_ll_removelast(Linked *d) { if (d->l.empty()) do_throw("linked is empty", 8); freev(d->E, &d->l.back()[0]); d->l.pop_back(); }
void fac_ll_first(Linked *d, void *out) { if (d->l.empty()) do_throw("linked is empty", 8); memcpy(out, d->l.front().data(), (size_t)d->E.sz); }
void fac_ll_last(Linked *d, void *out) { if (d->l.empty()) do_throw("linked is empty", 8); memcpy(out, d->l.back().data(), (size_t)d->E.sz); }
int32_t fac_ll_find(Linked *d, const void *v) { int32_t i = 0; for (auto &b : d->l) { if (cmpv(d->E.code, b.data(), v) == 0) return i; i++; } return -1; }
void *fac_ll_ptr(Linked *d, int64_t i) { if (i < 0 || i >= (int64_t)d->l.size()) fac_oob(i, (int64_t)d->l.size()); auto it = d->l.begin(); std::advance(it, i); return &(*it)[0]; }
void fac_ll_insert(Linked *d, int64_t i, const void *v) { if (i < 0 || i > (int64_t)d->l.size()) fac_oob(i, (int64_t)d->l.size()); fac_oom_guard([&] { auto it = d->l.begin(); std::advance(it, i); fac_blob_insert(d->l, it, d->E, v); }); }
void fac_ll_remove(Linked *d, int64_t i) { if (i < 0 || i >= (int64_t)d->l.size()) fac_oob(i, (int64_t)d->l.size()); auto it = d->l.begin(); std::advance(it, i); freev(d->E, &(*it)[0]); d->l.erase(it); }
// ---- stack / queue / heap / trie / matrix
FacDS *fac_st_new(int32_t code, int32_t sz) { return fac_oom_guard_result<FacDS *>([&] { return new StackDS({code, sz}); }); }
void fac_st_push(StackDS *d, const void *v) { fac_oom_guard([&] { d->push(v); }); }
void fac_st_pop(StackDS *d, void *out) { d->pop(out); }
void fac_st_peek(StackDS *d, void *out) { d->peek(out); }
FacDS *fac_q_new(int32_t code, int32_t sz) { return fac_oom_guard_result<FacDS *>([&] { return new QueueDS({code, sz}); }); }
void fac_q_enqueue(QueueDS *d, const void *v) { fac_oom_guard([&] { d->enqueue(v); }); }
void fac_q_dequeue(QueueDS *d, void *out) { d->dequeue(out); }
void fac_q_front(QueueDS *d, void *out) { d->front(out); }
void fac_q_back(QueueDS *d, void *out) { d->back(out); }
FacDS *fac_hp_new(int32_t code, int32_t sz) { return fac_oom_guard_result<FacDS *>([&] { return new HeapDS({code, sz}, false); }); }
FacDS *fac_mxh_new(int32_t code, int32_t sz) { return fac_oom_guard_result<FacDS *>([&] { return new HeapDS({code, sz}, true); }); }
void fac_hp_push(HeapDS *d, const void *v) { fac_oom_guard([&] { d->push(v); }); }
void fac_hp_pop(HeapDS *d, void *out) { d->pop(out); }
void fac_hp_peek(HeapDS *d, void *out) { d->peek(out); }
FacDS *fac_ti_new() { return fac_oom_guard_result<FacDS *>([&] { return new TrieDS(); }); }
void fac_ti_insert(TrieDS *d, const void *v) { fac_oom_guard([&] { d->insert(TrieDS::value(v)); }); }
int32_t fac_ti_has(TrieDS *d, const void *v) { return fac_oom_guard_result<int32_t>([&] { return d->has(TrieDS::value(v)) ? 1 : 0; }); }
int32_t fac_ti_prefix(TrieDS *d, const void *v) { return fac_oom_guard_result<int32_t>([&] { return d->prefix(TrieDS::value(v)) ? 1 : 0; }); }
void fac_ti_remove(TrieDS *d, const void *v) { fac_oom_guard([&] { d->remove(TrieDS::value(v)); }); }
FacList *fac_ti_words(TrieDS *d, const void *v) { return fac_oom_guard_result<FacList *>([&] { return d->words(TrieDS::value(v)); }); }
FacDS *fac_mx_new(int64_t r, int64_t c, int32_t code, int32_t sz) { return fac_oom_guard_result<FacDS *>([&] { return new MatrixDS(r, c, {code, sz}); }); }
void *fac_mx_ptr(MatrixDS *m, int64_t r, int64_t c) { return m->at(r, c); }
void fac_mx_set(MatrixDS *m, int64_t r, int64_t c, const void *v) { m->set(r, c, v); }
void fac_mx_get(MatrixDS *m, int64_t r, int64_t c, void *out) { m->get(r, c, out); }
void fac_mx_fill(MatrixDS *m, const void *v) { fac_oom_guard([&] { m->fill(v); }); }
int32_t fac_mx_rows(MatrixDS *m) { return (int32_t)m->R; }
int32_t fac_mx_cols(MatrixDS *m) { return (int32_t)m->C; }
// ---- arraylist extras
void fac_list_reserve(FacList *l, int64_t n) {
  if (!l || l->esz <= 0 || l->len < 0 || l->cap < l->len || (l->len && !l->data)) do_throw("invalid list", 5);
  fac_list_checked_bytes(l->cap, l->esz);
  if (n < 0) do_throw("list reserve size cannot be negative", 5);
  if (n > l->cap) {
    int64_t bytes = fac_list_checked_bytes(n, l->esz);
    void *data = fac_realloc(l->data, bytes);
    l->data = data; l->cap = n;
  }
}
void fac_list_shrink(FacList *l) {
  if (!l || l->esz <= 0 || l->len < 0 || l->cap < l->len || (l->len && !l->data)) do_throw("invalid list", 5);
  fac_list_checked_bytes(l->cap, l->esz);
  if (l->cap > l->len) {
    int64_t bytes = l->len ? fac_list_checked_bytes(l->len, l->esz) : 1;
    void *data = fac_realloc(l->data, bytes);
    l->data = data; l->cap = l->len;
  }
}
}  // extern "C"

// ================================================================ §19 libraries: path / regex / thread / json
extern "C" {
static bool issep(char c) { return c == '/' || c == '\\'; }
FacStr *fac_path_join(FacStr *a, FacStr *b) {
  std::string x(sd(a), (size_t)sl(a)), y(sd(b), (size_t)sl(b));
  if (x.empty()) return mks(y);
  if (y.empty()) return mks(x);
  if (!issep(x.back())) x += '/';
  return mks(x + y);
}
FacStr *fac_path_name(FacStr *p) { std::string x(sd(p), (size_t)sl(p)); while (!x.empty() && issep(x.back())) x.pop_back(); size_t i = x.find_last_of("/\\"); return mks(i == std::string::npos ? x : x.substr(i + 1)); }
FacStr *fac_path_ext(FacStr *p) {
  std::string n(sd(p), (size_t)sl(p)); while (!n.empty() && issep(n.back())) n.pop_back(); { size_t j = n.find_last_of("/\\"); if (j != std::string::npos) n = n.substr(j + 1); }
  size_t i = n.rfind('.'); return mks(i == std::string::npos || i == 0 ? "" : n.substr(i)); }
FacStr *fac_path_parent(FacStr *p) { std::string x(sd(p), (size_t)sl(p)); while (x.size() > 1 && issep(x.back())) x.pop_back(); size_t i = x.find_last_of("/\\"); if (i == std::string::npos) return mks(""); if (i == 0) return mks(x.substr(0, 1)); return mks(x.substr(0, i)); }
FacStr *fac_path_change_extension(FacStr *p, FacStr *ext) {
  std::string x(sd(p), (size_t)sl(p)), e(sd(ext), (size_t)sl(ext));
  // A trailing separator denotes a directory, not a filename.
  if (!x.empty() && issep(x.back())) return mks(x);
  size_t leaf = x.find_last_of("/\\"); leaf = leaf == std::string::npos ? 0 : leaf + 1;
  size_t dot = x.find_last_of('.');
  // Treat a leading dot (for example .config) as part of the name, not an extension.
  if (dot != std::string::npos && dot > leaf) x.resize(dot);
  if (!e.empty()) { if (e[0] != '.') x += '.'; x += e; }
  return mks(x);
}
FacStr *fac_path_with_name(FacStr *p, FacStr *name) {
  std::string x(sd(p), (size_t)sl(p)), n(sd(name), (size_t)sl(name));
  // A trailing separator means the input denotes a directory: append the new name.
  if (!x.empty() && issep(x.back())) return mks(x + n);
  size_t sep = x.find_last_of("/\\");
  if (sep == std::string::npos) return mks(n);
  // Preserve the separator style already used by the input path.
  return mks(x.substr(0, sep + 1) + n);
}
int32_t fac_path_is_symlink(FacStr *p) {
  std::error_code ec;
  bool result = std::filesystem::is_symlink(std::filesystem::symlink_status(std::filesystem::path(sd(p)), ec));
  return !ec && result;
}
int32_t fac_path_component_count(FacStr *p) {
  std::string x(sd(p), (size_t)sl(p));
  int32_t count = 0; bool in = false;
  for (char c : x) {
    if (issep(c)) in = false;
    else if (!in) { if (count < INT32_MAX) ++count; in = true; }
  }
  return count;
}
int32_t fac_path_exists(FacStr *p) { struct stat st; return stat(sd(p), &st) == 0; }
int32_t fac_path_isdir(FacStr *p) { struct stat st; return stat(sd(p), &st) == 0 && (st.st_mode & S_IFMT) == S_IFDIR; }
FacList *fac_path_list(FacStr *d) {
  std::vector<std::string> names; std::error_code ec;
  std::filesystem::directory_iterator it(sd(d), ec), endit;
  while (!ec && it != endit) { names.push_back(it->path().filename().string()); it.increment(ec); }
  if (ec) do_throw(std::string("cannot list directory: ") + sd(d), 7);
  std::sort(names.begin(), names.end());
  FacList *l = fac_list_new(8, 1);
  for (auto &n : names) { FacStr *e = mks(n); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = e; }
  return l;
}
// หมายเหตุ: ห้าม do_throw (longjmp) ขณะอยู่ใน catch block -- จะทำให้ exception state ของ C++ พัง
// จึงเก็บข้อความแล้วออกจาก catch ก่อนค่อย throw ของ Fac
// หมายเหตุ: do_throw ไม่ unwind (longjmp ข้าม destructor) -> ทุกตัวแปรที่มี destructor ต้องอยู่ในบล็อกที่จบก่อนเรียก do_throw
// และข้อความ error ต้อง std::move เข้าไป (ห้ามส่งตัวแปรที่ยังเป็นของเฟรมนี้แบบ copy)
// std::regex matches recursively (stack use grows with the subject): ".*" over 50k chars already overflows an 8 MB
// stack and segfaults the program. Large subjects therefore run on a dedicated thread with a 256 MiB stack (pages are
// committed lazily) and subjects above 256 KiB are refused with a FAC error. This does NOT bound run time: patterns with
// nested unbounded quantifiers such as (a*)*b are still exponential (ReDoS) -- never apply untrusted patterns.
static constexpr size_t kRxMaxSubject = (size_t)256 << 10, kRxMaxPattern = 2048, kRxInline = 4096, kRxStack = (size_t)256 << 20;
static void rxrun(size_t subjLen, std::string &err, const std::function<void()> &work) {
  if (subjLen > kRxMaxSubject) { err = "regex: input too large (max 262144 bytes)"; return; }
  auto safe = [&] { try { work(); } catch (std::exception &e) { err = std::string("regex error: ") + e.what(); } catch (...) { err = "regex error"; } };
  if (subjLen <= kRxInline) { safe(); return; }
  std::function<void()> fn = safe;
  pthread_attr_t at; pthread_attr_init(&at);
  pthread_t th;
  if (pthread_attr_setstacksize(&at, kRxStack) != 0 ||
      pthread_create(&th, &at, [](void *q) -> void * { (*(std::function<void()> *)q)(); return nullptr; }, &fn) != 0) {
    pthread_attr_destroy(&at); err = "regex: not enough memory to run on a large input"; return;
  }
  pthread_attr_destroy(&at); pthread_join(th, nullptr);
}
static bool mkre(FacStr *p, std::regex &out, std::string &err) {
  if (sl(p) > (int64_t)kRxMaxPattern) { err = "invalid regex: pattern too long (max 2048 bytes)"; return false; }
  try { out = std::regex(sd(p)); return true; } catch (std::exception &e) { err = std::string("invalid regex: ") + e.what(); } return false;
}
int32_t fac_regex_match(FacStr *p, FacStr *s) {
  std::string err; int32_t res = 0;
  { std::regex r; if (mkre(p, r, err)) { std::string t(sd(s), (size_t)sl(s)); rxrun(t.size(), err, [&] { res = std::regex_match(t, r); }); } }
  if (!err.empty()) do_throw(std::move(err), 9);
  return res;
}
FacStr *fac_regex_find(FacStr *p, FacStr *s) {
  std::string err, out;
  { std::regex r; if (mkre(p, r, err)) { std::string t(sd(s), (size_t)sl(s)); rxrun(t.size(), err, [&] { std::smatch m; if (std::regex_search(t, m, r)) out = m.str(); }); } }
  if (!err.empty()) { std::string().swap(out); do_throw(std::move(err), 9); }
  return mks(out);
}
FacList *fac_regex_findall(FacStr *p, FacStr *s) {
  std::string err; std::vector<std::string> found;
  { std::regex r; if (mkre(p, r, err)) { std::string t(sd(s), (size_t)sl(s));
      rxrun(t.size(), err, [&] { for (auto it = std::sregex_iterator(t.begin(), t.end(), r); it != std::sregex_iterator(); ++it) found.push_back(it->str()); }); } }
  if (!err.empty()) { std::vector<std::string>().swap(found); do_throw(std::move(err), 9); }
  FacList *l = fac_list_new(8, 1);
  for (auto &x : found) { FacStr *e = mks(x); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = e; }
  return l;
}
FacStr *fac_regex_replace(FacStr *p, FacStr *s, FacStr *rep) {
  std::string err, out;
  { std::regex r; if (mkre(p, r, err)) { rxrun((size_t)sl(s), err, [&] { out = std::regex_replace(std::string(sd(s), (size_t)sl(s)), r, std::string(sd(rep), (size_t)sl(rep))); }); } }
  if (!err.empty()) { std::string().swap(out); do_throw(std::move(err), 9); }
  return mks(out);
}

enum class FacTaskState : int32_t {
  Starting = 0,
  Running = 1,
  Succeeded = 2,
  Failed = 3,
  Cancelled = 4,
  Joined = 5
};

struct ThreadH {
  std::thread t;
  // Task lifecycle is observable until the owning caller consumes the handle
  // with thread.join(). The mutex serializes cancellation requests with the
  // transition out of Running; the atomic state supports lock-free polling.
  std::mutex stateMutex;
  std::atomic<FacTaskState> state{FacTaskState::Starting};
  std::atomic<bool> cancelRequested{false};
  std::atomic<bool> cancellationObserved{false};
  // Written only by the worker and read only after join() establishes a
  // happens-before edge. Fixed storage keeps error capture noexcept on OOM.
  char error[1024]{};
  int32_t errorCode = 0;
  bool failed = false;
};

static thread_local ThreadH *g_fac_current_task = nullptr;

static void fac_thread_store_error(ThreadH *h, const char *message, size_t length, int32_t code) noexcept {
  if (!h) return;
  const char *suffix = "";
  if (g_cleanup_drop_failed && g_temporary_drop_failed)
    suffix = "; cleanup callbacks and temporary drops also raised exceptions; remaining drops completed";
  else if (g_cleanup_drop_failed)
    suffix = "; cleanup callbacks also raised exceptions; remaining cleanup completed";
  else if (g_temporary_drop_failed)
    suffix = "; temporary drops also raised exceptions; remaining drops completed";
  const size_t suffixLength = strlen(suffix);
  const size_t maxPrimary = sizeof(h->error) - 1 - suffixLength;
  const size_t count = std::min(length, maxPrimary);
  if (count) memcpy(h->error, message, count);
  if (suffixLength) memcpy(h->error + count, suffix, suffixLength);
  h->error[count + suffixLength] = '\0';
  h->errorCode = code;
  h->failed = true;
}

static void fac_thread_worker(void *clo, ThreadH *h) {
  // Each worker reports only failures from its own ownership unwind.
  g_cleanup_drop_failed = false;
  g_temporary_drop_failed = false;
  g_fac_current_task = h;
  {
    std::lock_guard<std::mutex> lock(h->stateMutex);
    h->state.store(FacTaskState::Running, std::memory_order_release);
  }
  // FAC uses a thread-local setjmp/longjmp error stack. Install a worker-local
  // boundary so `throw` inside a thread is saved in the handle and re-raised
  // by thread.join() on the caller, instead of terminating the whole process.
  void *handler[5]{};
  const int workerCleanupBase = g_csp;
  const int workerTmpBase = g_tsp;
  fac_try_enter(handler);
  if (__builtin_setjmp(handler) == 0) {
    bool caughtCppException = false;
    char cppError[sizeof(h->error)]{};
    size_t cppErrorLength = 0;
    try {
      using Entry = void (*)(void *);
      Entry fn = reinterpret_cast<Entry>(*(void **)clo);
      if (!fn) do_throw("thread.start: closure has no entry function", 6);
      fn(clo);
    } catch (const std::exception &e) {
      const char *what = e.what();
      if (!what) what = "unknown C++ exception";
      while (cppErrorLength < sizeof(cppError) - 1 && what[cppErrorLength]) {
        cppError[cppErrorLength] = what[cppErrorLength];
        ++cppErrorLength;
      }
      caughtCppException = true;
    } catch (...) {
      static const char message[] = "uncaught non-standard C++ exception in FAC thread";
      cppErrorLength = sizeof(message) - 1;
      memcpy(cppError, message, cppErrorLength);
      caughtCppException = true;
    }
    if (caughtCppException) {
      // A native C++ exception does not pass through do_throw(), so its FAC
      // ownership entries would otherwise survive until TLS destruction
      // without releasing the values they own. Unwind to the worker boundary
      // after leaving the C++ catch block; a FAC error raised by a drop callback
      // still reaches the worker's setjmp boundary below.
      fac_cleanup_run_to(workerCleanupBase);
      fac_tmp_run_to(workerTmpBase);
      fac_thread_store_error(h, cppError, cppErrorLength, 8);
    }
    fac_try_leave();
  } else {
    // do_throw() already ran the worker's FAC cleanup/temp stacks to the
    // boundary before control arrived here.
    fac_thread_store_error(h, g_errmsg.data(), g_errmsg.size(), g_errcode);
  }
  fac_closure_release(clo);
  {
    std::lock_guard<std::mutex> lock(h->stateMutex);
    if (h->failed) {
      h->state.store(FacTaskState::Failed, std::memory_order_release);
    } else if (h->cancellationObserved.load(std::memory_order_acquire)) {
      h->state.store(FacTaskState::Cancelled, std::memory_order_release);
    } else {
      h->state.store(FacTaskState::Succeeded, std::memory_order_release);
    }
  }
  g_fac_current_task = nullptr;
}

void *fac_thread_start(void *clo) {
  g_mt = true;
  if (!clo) do_throw("thread.start: null closure", 6);
  if (!*(void **)clo) do_throw("thread.start: closure has no entry function", 6);

  fac_closure_retain(clo); // the new thread outlives the caller and owns a reference
  ThreadH *h = new (std::nothrow) ThreadH{};
  if (!h) {
    fac_closure_release(clo);
    do_throw("out of memory creating FAC thread handle", 5);
  }
  bool launchFailed = false;
  try {
    h->t = std::thread([clo, h] { fac_thread_worker(clo, h); });
  } catch (...) {
    launchFailed = true;
  }
  if (launchFailed) {
    delete h;
    fac_closure_release(clo);
    do_throw("cannot start FAC thread", 8);
  }
  return h;
}

// Request cooperative cancellation. This never terminates a native thread;
// the callback must poll thread.cancelled() and return on its own. The caller
// must serialize cancel/query operations with the consuming thread.join().
int32_t fac_thread_cancel(void *h) {
  if (!h) return 0;
  ThreadH *p = (ThreadH *)h;
  try {
    std::lock_guard<std::mutex> lock(p->stateMutex);
    const FacTaskState state = p->state.load(std::memory_order_acquire);
    if (state != FacTaskState::Starting && state != FacTaskState::Running) return 0;
    p->cancelRequested.store(true, std::memory_order_release);
    return 1;
  } catch (...) {
    return 0; // Never let a C++ exception escape the C ABI.
  }
}

// Cancellation is cooperative and task-local. Outside thread.start callbacks,
// this query is false. A task is marked Cancelled only when its callback
// observes the request and then returns without raising an error.
int32_t fac_thread_cancelled() {
  ThreadH *task = g_fac_current_task;
  if (!task || !task->cancelRequested.load(std::memory_order_acquire)) return 0;
  task->cancellationObserved.store(true, std::memory_order_release);
  return 1;
}

int32_t fac_thread_is_done(void *h) {
  if (!h) return 0;
  const FacTaskState state = ((ThreadH *)h)->state.load(std::memory_order_acquire);
  return state == FacTaskState::Succeeded || state == FacTaskState::Failed ||
         state == FacTaskState::Cancelled || state == FacTaskState::Joined;
}

int32_t fac_thread_is_cancelled(void *h) {
  if (!h) return 0;
  return ((ThreadH *)h)->state.load(std::memory_order_acquire) == FacTaskState::Cancelled;
}

void fac_thread_join(void *h) {
  if (!h) return;
  ThreadH *p = (ThreadH *)h;
  bool joinFailed = false;
  try {
    if (p->t.joinable()) p->t.join();
  } catch (...) {
    joinFailed = true;
  }
  if (joinFailed) {
    // A joinable std::thread cannot be destroyed. Detaching here could let
    // the worker outlive data reachable through the caller-owned closure.
    if (p->t.joinable()) std::terminate();
    delete p;
    do_throw("cannot join FAC thread", 8);
  }

  p->state.store(FacTaskState::Joined, std::memory_order_release);
  const bool failed = p->failed;
  const int32_t code = p->errorCode ? p->errorCode : 8;
  char message[sizeof(p->error)];
  memcpy(message, p->error, sizeof(message));
  delete p;
  if (failed) do_throw(std::string(message), code);
}
}
extern "C++" {
struct MutexDS : FacDS { std::mutex m; FacDS *clone() override { return new MutexDS; } int64_t size() override { return 0; } void clear() override {} };
}
extern "C" {
FacDS *fac_mutex_new() { return new MutexDS; }
void fac_mutex_lock(MutexDS *m) { m->m.lock(); }
void fac_mutex_unlock(MutexDS *m) { m->m.unlock(); }

// ---- JSON encode (builder)
struct JB { std::string s; };
void *fac_jb_new() { return new JB; }
void fac_jb_raw(JB *b, FacStr *s) { b->s.append(sd(s), (size_t)sl(s)); }
static void jstr(JB *b, const char *p, size_t n) {
  b->s += '"';
  for (size_t i = 0; i < n; i++) {
    unsigned char c = (unsigned char)p[i];
    if (c == '"') b->s += "\\\""; else if (c == '\\') b->s += "\\\\"; else if (c == '\n') b->s += "\\n"; else if (c == '\r') b->s += "\\r"; else if (c == '\t') b->s += "\\t";
    else if (c < 0x20) { char t[8]; snprintf(t, 8, "\\u%04x", c); b->s += t; } else b->s += (char)c;
  }
  b->s += '"';
}
void fac_jb_str(JB *b, FacStr *s) { jstr(b, sd(s), (size_t)sl(s)); }
void fac_jb_i64(JB *b, int64_t v) { b->s += std::to_string(v); }
void fac_jb_u64(JB *b, uint64_t v) { b->s += std::to_string(v); }
void fac_jb_f64(JB *b, double v) { if (v != v || v - v != 0) b->s += "null"; else b->s += fmtd(v); }
void fac_jb_bool(JB *b, int32_t v) { b->s += v ? "true" : "false"; }
void fac_jb_char(JB *b, int32_t c) { std::string t; enc(t, (uint32_t)c); jstr(b, t.data(), t.size()); }
static void jelem(JB *b, const char *p, int32_t code) {
  switch (code) {
    case 1: fac_jb_i64(b, *(const int8_t *)p); break; case 2: fac_jb_i64(b, *(const int16_t *)p); break;
    case 3: case 15: fac_jb_i64(b, *(const int32_t *)p); break; case 4: fac_jb_i64(b, *(const int64_t *)p); break;
    case 5: fac_jb_u64(b, *(const uint8_t *)p); break; case 6: fac_jb_u64(b, *(const uint16_t *)p); break;
    case 7: fac_jb_u64(b, *(const uint32_t *)p); break; case 8: fac_jb_u64(b, *(const uint64_t *)p); break;
    case 9: fac_jb_f64(b, *(const float *)p); break; case 10: fac_jb_f64(b, *(const double *)p); break;
    case 11: fac_jb_bool(b, *(const uint8_t *)p); break; case 12: fac_jb_char(b, *(const uint8_t *)p); break;
    case 13: fac_jb_char(b, *(const int32_t *)p); break; case 14: fac_jb_str(b, *(FacStr *const *)p); break;
  }
}
void fac_jb_seq(JB *b, const void *d, int64_t n, int32_t code) {
  b->s += '['; for (int64_t i = 0; i < n; i++) { if (i) b->s += ','; jelem(b, (const char *)d + i * esize(code), code); } b->s += ']';
}
static void jkey(JB *b, const Elem &k, const char *p) {
  if (k.code == 14) fac_jb_str(b, *(FacStr *const *)p);
  else { JB t; jelem(&t, p, k.code); jstr(b, t.s.data(), t.s.size()); }
}
void fac_jb_ds(JB *b, FacDS *d) {
  if (!d) { b->s += "null"; return; }
  if (HMap *m = dynamic_cast<HMap *>(d)) {
    bool first = true;
    if (m->V.sz) { b->s += '{'; for (auto &i : m->items) if (i.live) { if (!first) b->s += ','; first = false; jkey(b, m->K, i.k.data()); b->s += ':'; jelem(b, i.v.data(), m->V.code); } b->s += '}'; }
    else { b->s += '['; for (auto &i : m->items) if (i.live) { if (!first) b->s += ','; first = false; jelem(b, i.k.data(), m->K.code); } b->s += ']'; }
  } else if (Tree *t = dynamic_cast<Tree *>(d)) {
    std::vector<const std::string *> v; t->walk(t->root, 0, v); b->s += '[';
    for (size_t i = 0; i < v.size(); i++) { if (i) b->s += ','; jelem(b, v[i]->data(), t->K.code); } b->s += ']';
  } else if (Linked *l = dynamic_cast<Linked *>(d)) {
    b->s += '['; bool first = true; for (auto &e : l->l) { if (!first) b->s += ','; first = false; jelem(b, e.data(), l->E.code); } b->s += ']';
  } else do_throw("json.encode: this data structure is not supported", 10);
}
FacStr *fac_jb_finish(JB *b) { FacStr *r = mks(b->s); delete b; return r; }

// ---- JSON decode
struct JV {
  int t = 0; bool b = false, isint = false; double d = 0; int64_t i = 0; std::string s;
  JV *parent = nullptr; // non-owning; prevents a child node from being attached to multiple owners
  std::vector<JV *> a; std::vector<std::pair<std::string, JV *>> o;
  ~JV() { for (auto *x : a) delete x; for (auto &p : o) delete p.second; }
};
struct JErr { std::string m; };
struct JP {
  const char *p; const char *e; int depth = 0;
  [[noreturn]] void bad(const char *m) { throw JErr{std::string("json: ") + m}; }
  void ws() { while (p < e && isws(*p)) p++; }
  JV *val() {
    ws(); if (p >= e) bad("unexpected end");
    if (depth >= 512) bad("nesting too deep");          // กัน stack overflow จาก [[[[[...
    struct DG { int &d; DG(int &x) : d(x) { d++; } ~DG() { d--; } } dg(depth);
    std::unique_ptr<JV> v(new JV);
    if (*p == '{') {
      v->t = 5; p++; ws();
      if (p < e && *p == '}') { p++; return v.release(); }
      while (true) {
        ws(); if (p >= e || *p != '"') bad("expected string key");
        std::string k = str(); ws(); if (p >= e || *p != ':') bad("expected ':'"); p++;
        std::unique_ptr<JV> child(val());
        child->parent = v.get();
        v->o.emplace_back(std::move(k), child.get()); child.release();
        ws();
        if (p < e && *p == ',') { p++; continue; }
        if (p < e && *p == '}') { p++; break; }
        bad("expected ',' or '}'");
      }
    } else if (*p == '[') {
      v->t = 4; p++; ws();
      if (p < e && *p == ']') { p++; return v.release(); }
      while (true) {
        std::unique_ptr<JV> child(val());
        child->parent = v.get();
        v->a.push_back(child.get()); child.release(); ws();
        if (p < e && *p == ',') { p++; continue; }
        if (p < e && *p == ']') { p++; break; }
        bad("expected ',' or ']'");
      }
    } else if (*p == '"') { v->t = 3; v->s = str(); }
    else if (e - p >= 4 && !strncmp(p, "true", 4)) { v->t = 1; v->b = true; p += 4; }
    else if (e - p >= 5 && !strncmp(p, "false", 5)) { v->t = 1; p += 5; }
    else if (e - p >= 4 && !strncmp(p, "null", 4)) { v->t = 0; p += 4; }
    else {
      const char *st = p;
      if (p < e && *p == '-') p++;
      if (p >= e) bad("invalid number");
      if (*p == '0') {
        p++;
        if (p < e && *p >= '0' && *p <= '9') bad("leading zero in number");
      } else if (*p >= '1' && *p <= '9') {
        do { p++; } while (p < e && *p >= '0' && *p <= '9');
      } else bad("invalid number");
      bool fl = false;
      if (p < e && *p == '.') {
        fl = true; p++;
        if (p >= e || *p < '0' || *p > '9') bad("fraction requires a digit");
        do { p++; } while (p < e && *p >= '0' && *p <= '9');
      }
      if (p < e && (*p == 'e' || *p == 'E')) {
        fl = true; p++;
        if (p < e && (*p == '+' || *p == '-')) p++;
        if (p >= e || *p < '0' || *p > '9') bad("exponent requires a digit");
        do { p++; } while (p < e && *p >= '0' && *p <= '9');
      }
      std::string n(st, (size_t)(p - st));
      char *endp = nullptr; errno = 0;
      double parsed = strtod(n.c_str(), &endp);
      if (endp != n.c_str() + n.size() || !std::isfinite(parsed)) bad("number is out of range");
      v->t = 2; v->d = parsed; v->isint = !fl;
      if (!fl) {
        int64_t iv = 0;
        auto cv = std::from_chars(n.data(), n.data() + n.size(), iv, 10);
        if (cv.ec == std::errc() && cv.ptr == n.data() + n.size()) v->i = iv;
        else v->isint = false;
      }
    }
    return v.release();
  }
  std::string str() {
    std::string r; p++;
    while (true) {
      if (p >= e) bad("unterminated string");
      char c = *p++;
      if (c == '"') break;
      if (c != '\\') { if ((unsigned char)c < 0x20) bad("unescaped control character"); r += c; continue; }
      if (p >= e) bad("bad escape");
      char x = *p++;
      switch (x) {
        case 'n': r += '\n'; break; case 't': r += '\t'; break; case 'r': r += '\r'; break; case 'b': r += '\b'; break; case 'f': r += '\f'; break;
        case 'u': {
          auto hex4 = [&](const char *q) -> int64_t { uint32_t v = 0; for (int i = 0; i < 4; i++) { char h = q[i]; int d = (h >= '0' && h <= '9') ? h - '0' : (h >= 'a' && h <= 'f') ? h - 'a' + 10 : (h >= 'A' && h <= 'F') ? h - 'A' + 10 : -1; if (d < 0) return -1; v = v * 16 + (uint32_t)d; } return v; };
          if (e - p < 4) bad("bad \\u escape");
          int64_t cp = hex4(p); if (cp < 0) bad("bad \\u escape"); p += 4;
          if (cp >= 0xD800 && cp <= 0xDBFF) {
            if (e - p < 6 || p[0] != '\\' || p[1] != 'u') bad("unpaired high surrogate");
            int64_t lo = hex4(p + 2);
            if (lo < 0xDC00 || lo > 0xDFFF) bad("invalid low surrogate");
            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); p += 6;
          } else if (cp >= 0xDC00 && cp <= 0xDFFF) bad("unpaired low surrogate");
          enc(r, (uint32_t)cp); break; }
        case '"': r += '"'; break; case '\\': r += '\\'; break; case '/': r += '/'; break;
        default: bad("invalid escape sequence");
      }
    }
    return r;
  }
};
JV *fac_jd_parse(FacStr *s) {
  std::string err;
  std::unique_ptr<JV> root;
  try {
    JP p{sd(s), sd(s) + sl(s)}; root.reset(p.val()); p.ws();
    if (p.p != p.e) p.bad("trailing characters");
  } catch (JErr &e) { err = std::move(e.m); }
    catch (const std::bad_alloc &) { err = "json: out of memory"; }
    catch (const std::exception &) { err = "json: parse failed"; }
  if (!err.empty()) {
    root.reset(); // run the recursive JV destructor before the non-local FAC throw
    do_throw(std::move(err), 10);
  }
  return root.release();
}
void fac_jd_free(JV *v) { delete v; }
JV *fac_jd_get(JV *n, FacStr *key) {
  if (!n) return nullptr;
  if (n->t != 5) do_throw("json: expected an object", 10);
  for (auto &p : n->o) if (p.first == sd(key)) return p.second;
  return nullptr;
}
FacStr *fac_jd_str(JV *n) { if (!n || n->t == 0) return nullptr; if (n->t != 3) do_throw("json: expected a string", 10); return mks(n->s); }
int64_t fac_jd_i64(JV *n) { if (!n || n->t == 0) return 0; if (n->t != 2) do_throw("json: expected a number", 10); if (n->isint) return n->i; if (!(n->d == n->d)) return 0; if (n->d >= 9223372036854775807.0) return INT64_MAX; if (n->d <= -9223372036854775808.0) return INT64_MIN; return (int64_t)n->d; }
double fac_jd_f64(JV *n) { if (!n || n->t == 0) return 0; if (n->t != 2) do_throw("json: expected a number", 10); return n->d; }
int32_t fac_jd_bool(JV *n) { if (!n || n->t == 0) return 0; if (n->t != 1) do_throw("json: expected a boolean", 10); return n->b; }
int32_t fac_jd_enum(JV *n, FacStr **tbl, int32_t cnt) {
  if (!n || n->t == 0) return 0;
  if (n->t != 3) do_throw("json: expected an enum name (string)", 10);
  for (int32_t i = 0; i < cnt; i++) if (n->s == sd(tbl[i])) return i;
  do_throw("json: unknown enum value \"" + n->s + "\"", 10);
}
FacList *fac_jd_list(JV *n, int32_t code, int32_t esz) {
  FacList *l = fac_list_new(esz, code == 14 ? 1 : 0);
  // A later element can have the wrong JSON type. Register the partially
  // populated result so fac_jd_* validation errors and allocation failures
  // release both its backing buffer and any strings already converted.
  fac_cleanup_push(&l, 2, nullptr);
  if (!n || n->t == 0) { fac_cleanup_pop(); return l; }
  if (n->t != 4) do_throw("json: expected an array", 10);
  for (JV *x : n->a) {
    if (l->len == l->cap) fac_list_grow(l);
    char *dst = (char *)l->data + l->len * esz;
    switch (code) {
      case 14: *(FacStr **)dst = fac_jd_str(x); break;
      case 9: *(float *)dst = (float)fac_jd_f64(x); break;
      case 10: *(double *)dst = fac_jd_f64(x); break;
      case 11: *(uint8_t *)dst = (uint8_t)fac_jd_bool(x); break;
      default: { int64_t v = fac_jd_i64(x); memcpy(dst, &v, (size_t)esz); }  // little-endian
    }
    l->len++;
  }
  fac_cleanup_pop();
  return l;
}
}  // extern "C"

// ---------------------------------------------------------------- init / shutdown
#ifndef _WIN32
// ถ้าโปรแกรมล้ม (เช่น recursion ลึกเกิน stack / pointer ผิด) ให้พิมพ์ output ที่ค้างอยู่ใน buffer + บอกสาเหตุ แทนที่จะเงียบหายไป
static void fac_crash(int sig) {
  alarm(2);  // กันค้างกรณี crash ตอนถือ lock ของ stdio
  fflush(stdout);
  const char *m = sig == SIGSEGV ? "\nfatal: segmentation fault (stack overflow จาก recursion ลึกเกินไป หรือ pointer/array ผิด)\n"
                : sig == SIGBUS  ? "\nfatal: bus error\n" : "\nfatal: arithmetic fault\n";
  ssize_t r = write(2, m, strlen(m)); (void)r;
  signal(sig, SIG_DFL); raise(sig);
}
static void install_crash_handlers() {
  static char *altstk = (char *)malloc(1 << 16);
  if (altstk) { stack_t ss; ss.ss_sp = altstk; ss.ss_size = 1 << 16; ss.ss_flags = 0; sigaltstack(&ss, nullptr); }
  struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_handler = fac_crash; sigemptyset(&sa.sa_mask); sa.sa_flags = SA_ONSTACK | SA_NODEFER;
  sigaction(SIGSEGV, &sa, nullptr); sigaction(SIGBUS, &sa, nullptr); sigaction(SIGFPE, &sa, nullptr);
}
#endif
void fac_init(int32_t argc, char **argv) {
  g_argc = argc; g_argv = argv;
#ifndef _WIN32
  install_crash_handlers();
#endif
#ifdef _WIN32
  SetConsoleOutputCP(65001);
#endif
  setvbuf(stdout, nullptr, _IOFBF, 1 << 16);
  atexit(flush_out);
}
void fac_shutdown() { flush_out(); }
}  // extern "C"

// ---- FFI helpers
extern "C" {
const char *fac_cstr(FacStr *s) { return s ? s->data : ""; }
FacStr *fac_cstr_new(const char *p) { return p ? mk(p, (int64_t)strlen(p)) : mks(""); }
}

#include "fac_lib.inc"
#include "fac_sync.inc"
#include "fac_ml.inc"
#include "fac_sqlite.inc"
