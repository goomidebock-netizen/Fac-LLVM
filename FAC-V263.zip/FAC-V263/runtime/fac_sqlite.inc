// fac_sqlite.inc -- optional SQLite C API loaded at runtime (no hard link dependency).
// FAC code uses opaque handles from stdlib/sqlite.fac. SQLite text parameters are
// passed as NUL-terminated UTF-8 strings; embedded NULs and BLOBs belong in a future
// dedicated byte-buffer API, not this string-only interface.

#include <memory>
#include <mutex>
#include <unordered_map>

namespace {
struct FacSqliteApi {
  void *library = nullptr;
  using OpenV2 = int (*)(const char *, void **, int, const char *);
  using CloseV2 = int (*)(void *);
  using Errmsg = const char *(*)(void *);
  using BusyTimeout = int (*)(void *, int);
  using Exec = int (*)(void *, const char *, int (*)(void *, int, char **, char **), void *, char **);
  using SqliteFree = void (*)(void *);
  using PrepareV2 = int (*)(void *, const char *, int, void **, const char **);
  using Step = int (*)(void *);
  using Finalize = int (*)(void *);
  using Reset = int (*)(void *);
  using ClearBindings = int (*)(void *);
  using BindInt64 = int (*)(void *, int, int64_t);
  using BindDouble = int (*)(void *, int, double);
  using BindText = int (*)(void *, int, const char *, int, void (*)(void *));
  using BindNull = int (*)(void *, int);
  using ColumnCount = int (*)(void *);
  using ColumnName = const char *(*)(void *, int);
  using ColumnType = int (*)(void *, int);
  using ColumnInt64 = int64_t (*)(void *, int);
  using ColumnDouble = double (*)(void *, int);
  using ColumnText = const unsigned char *(*)(void *, int);
  using ColumnBytes = int (*)(void *, int);
  using Changes = int (*)(void *);
  using LastInsertRowId = int64_t (*)(void *);
  using DbHandle = void *(*)(void *);

  OpenV2 open_v2 = nullptr;
  CloseV2 close_v2 = nullptr;
  Errmsg errmsg = nullptr;
  BusyTimeout busy_timeout = nullptr;
  Exec exec = nullptr;
  SqliteFree free_fn = nullptr;
  PrepareV2 prepare_v2 = nullptr;
  Step step = nullptr;
  Finalize finalize = nullptr;
  Reset reset = nullptr;
  ClearBindings clear_bindings = nullptr;
  BindInt64 bind_int64 = nullptr;
  BindDouble bind_double = nullptr;
  BindText bind_text = nullptr;
  BindNull bind_null = nullptr;
  ColumnCount column_count = nullptr;
  ColumnName column_name = nullptr;
  ColumnType column_type = nullptr;
  ColumnInt64 column_int64 = nullptr;
  ColumnDouble column_double = nullptr;
  ColumnText column_text = nullptr;
  ColumnBytes column_bytes = nullptr;
  Changes changes = nullptr;
  LastInsertRowId last_insert_rowid = nullptr;
  DbHandle db_handle = nullptr;
  bool ready = false;
  std::string error;
};

static FacSqliteApi g_fac_sqlite;
static std::once_flag g_fac_sqlite_once;
static thread_local std::string g_fac_sqlite_error;

static void *fac_sqlite_load_symbol(void *lib, const char *name) {
#ifdef _WIN32
  return lib ? reinterpret_cast<void *>(GetProcAddress((HMODULE)lib, name)) : nullptr;
#else
  return lib ? dlsym(lib, name) : nullptr;
#endif
}

template <typename T>
static bool fac_sqlite_resolve(void *lib, T &out, const char *name) {
  out = reinterpret_cast<T>(fac_sqlite_load_symbol(lib, name));
  return out != nullptr;
}

static void fac_sqlite_initialize() {
#ifdef _WIN32
  const char *names[] = {"sqlite3.dll", "SQLite3.dll", nullptr};
  for (int i = 0; names[i] && !g_fac_sqlite.library; ++i)
    g_fac_sqlite.library = reinterpret_cast<void *>(LoadLibraryA(names[i]));
#elif defined(__APPLE__)
  const char *names[] = {"libsqlite3.dylib", "/usr/lib/libsqlite3.dylib", nullptr};
  for (int i = 0; names[i] && !g_fac_sqlite.library; ++i)
    g_fac_sqlite.library = dlopen(names[i], RTLD_NOW | RTLD_LOCAL);
#else
  const char *names[] = {"libsqlite3.so.0", "libsqlite3.so", nullptr};
  for (int i = 0; names[i] && !g_fac_sqlite.library; ++i)
    g_fac_sqlite.library = dlopen(names[i], RTLD_NOW | RTLD_LOCAL);
#endif
  if (!g_fac_sqlite.library) {
    g_fac_sqlite.error = "SQLite library not found (install SQLite shared library; Windows: sqlite3.dll)";
    return;
  }
#define FAC_SQLITE_SYM(member, symbol) \
  if (!fac_sqlite_resolve(g_fac_sqlite.library, g_fac_sqlite.member, symbol)) { \
    g_fac_sqlite.error = std::string("SQLite library is missing required symbol: ") + symbol; return; }
  FAC_SQLITE_SYM(open_v2, "sqlite3_open_v2")
  FAC_SQLITE_SYM(close_v2, "sqlite3_close_v2")
  FAC_SQLITE_SYM(errmsg, "sqlite3_errmsg")
  FAC_SQLITE_SYM(busy_timeout, "sqlite3_busy_timeout")
  FAC_SQLITE_SYM(exec, "sqlite3_exec")
  FAC_SQLITE_SYM(free_fn, "sqlite3_free")
  FAC_SQLITE_SYM(prepare_v2, "sqlite3_prepare_v2")
  FAC_SQLITE_SYM(step, "sqlite3_step")
  FAC_SQLITE_SYM(finalize, "sqlite3_finalize")
  FAC_SQLITE_SYM(reset, "sqlite3_reset")
  FAC_SQLITE_SYM(clear_bindings, "sqlite3_clear_bindings")
  FAC_SQLITE_SYM(bind_int64, "sqlite3_bind_int64")
  FAC_SQLITE_SYM(bind_double, "sqlite3_bind_double")
  FAC_SQLITE_SYM(bind_text, "sqlite3_bind_text")
  FAC_SQLITE_SYM(bind_null, "sqlite3_bind_null")
  FAC_SQLITE_SYM(column_count, "sqlite3_column_count")
  FAC_SQLITE_SYM(column_name, "sqlite3_column_name")
  FAC_SQLITE_SYM(column_type, "sqlite3_column_type")
  FAC_SQLITE_SYM(column_int64, "sqlite3_column_int64")
  FAC_SQLITE_SYM(column_double, "sqlite3_column_double")
  FAC_SQLITE_SYM(column_text, "sqlite3_column_text")
  FAC_SQLITE_SYM(column_bytes, "sqlite3_column_bytes")
  FAC_SQLITE_SYM(changes, "sqlite3_changes")
  FAC_SQLITE_SYM(last_insert_rowid, "sqlite3_last_insert_rowid")
  FAC_SQLITE_SYM(db_handle, "sqlite3_db_handle")
#undef FAC_SQLITE_SYM
  g_fac_sqlite.ready = true;
}

static FacSqliteApi *fac_sqlite_api() {
  try { std::call_once(g_fac_sqlite_once, fac_sqlite_initialize); }
  catch (...) { g_fac_sqlite.error = "Unable to initialize SQLite loader"; }
  if (!g_fac_sqlite.ready) g_fac_sqlite_error = g_fac_sqlite.error;
  return g_fac_sqlite.ready ? &g_fac_sqlite : nullptr;
}

static size_t fac_sqlite_bounded_len(const char *s, size_t limit) {
  size_t n = 0;
  if (!s) return 0;
  while (n < limit && s[n] != '\0') ++n;
  return n;
}

static char *fac_sqlite_copy_cstr(const char *s) {
  if (!s) s = "";
  const size_t n = strlen(s);
  if (n >= (1u << 20)) return nullptr; // Never export an unbounded diagnostic string.
  char *p = (char *)malloc(n + 1);
  if (!p) return nullptr;
  memcpy(p, s, n + 1);
  return p;
}

static const char *fac_sqlite_db_error(FacSqliteApi *api, void *db) {
  if (api && db) {
    const char *s = api->errmsg(db);
    if (s && *s) return s;
  }
  return g_fac_sqlite_error.empty() ? "SQLite operation failed" : g_fac_sqlite_error.c_str();
}

struct FacSqliteConnection {
  std::mutex mutex;
  void *db = nullptr;
  bool handleActive = true;
};
struct FacSqliteStatement {
  std::shared_ptr<FacSqliteConnection> connection;
  void *stmt = nullptr;
  bool handleActive = true;
};

// Handles crossing the C ABI are monotonically increasing opaque tokens, not
// addresses of native records. Registry lookup happens before any state access;
// removing a token makes stale aliases fail closed without dereferencing freed
// memory or accidentally naming a later allocation (ABA).
static std::mutex g_fac_sqlite_registry_mutex;
static std::unordered_map<void *, std::shared_ptr<FacSqliteConnection>> g_fac_sqlite_connections;
static std::unordered_map<void *, std::shared_ptr<FacSqliteStatement>> g_fac_sqlite_statements;
static uintptr_t g_fac_sqlite_next_token = (uintptr_t)0x10000;
static thread_local std::string g_fac_sqlite_column_text;
static thread_local std::string g_fac_sqlite_column_name;

static void *fac_sqlite_next_token_locked() {
  if (!g_fac_sqlite_next_token || g_fac_sqlite_next_token > UINTPTR_MAX - (uintptr_t)16) return nullptr;
  uintptr_t value = g_fac_sqlite_next_token;
  g_fac_sqlite_next_token += (uintptr_t)16;
  return reinterpret_cast<void *>(value);
}

static void *fac_sqlite_register_connection(const std::shared_ptr<FacSqliteConnection> &state) {
  std::lock_guard<std::mutex> lock(g_fac_sqlite_registry_mutex);
  void *token = fac_sqlite_next_token_locked();
  if (!token) return nullptr;
  try { g_fac_sqlite_connections.emplace(token, state); }
  catch (...) { return nullptr; }
  return token;
}
static void *fac_sqlite_register_statement(const std::shared_ptr<FacSqliteStatement> &state) {
  std::lock_guard<std::mutex> lock(g_fac_sqlite_registry_mutex);
  void *token = fac_sqlite_next_token_locked();
  if (!token) return nullptr;
  try { g_fac_sqlite_statements.emplace(token, state); }
  catch (...) { return nullptr; }
  return token;
}
static std::shared_ptr<FacSqliteConnection> fac_sqlite_find_connection(void *token) {
  if (!token) return {};
  std::lock_guard<std::mutex> lock(g_fac_sqlite_registry_mutex);
  auto it = g_fac_sqlite_connections.find(token);
  return it == g_fac_sqlite_connections.end() ? std::shared_ptr<FacSqliteConnection>() : it->second;
}
static std::shared_ptr<FacSqliteStatement> fac_sqlite_find_statement(void *token) {
  if (!token) return {};
  std::lock_guard<std::mutex> lock(g_fac_sqlite_registry_mutex);
  auto it = g_fac_sqlite_statements.find(token);
  return it == g_fac_sqlite_statements.end() ? std::shared_ptr<FacSqliteStatement>() : it->second;
}
static std::shared_ptr<FacSqliteConnection> fac_sqlite_remove_connection(void *token) {
  if (!token) return {};
  std::lock_guard<std::mutex> lock(g_fac_sqlite_registry_mutex);
  auto it = g_fac_sqlite_connections.find(token);
  if (it == g_fac_sqlite_connections.end()) return {};
  auto state = it->second;
  g_fac_sqlite_connections.erase(it);
  return state;
}
static std::shared_ptr<FacSqliteStatement> fac_sqlite_remove_statement(void *token) {
  if (!token) return {};
  std::lock_guard<std::mutex> lock(g_fac_sqlite_registry_mutex);
  auto it = g_fac_sqlite_statements.find(token);
  if (it == g_fac_sqlite_statements.end()) return {};
  auto state = it->second;
  g_fac_sqlite_statements.erase(it);
  return state;
}
} // namespace

extern "C" {
int32_t fac_sqlite_available() { return fac_sqlite_api() ? 1 : 0; }

char *fac_sqlite_open_error() {
  fac_sqlite_api();
  return fac_sqlite_copy_cstr(g_fac_sqlite_error.empty() ? g_fac_sqlite.error.c_str() : g_fac_sqlite_error.c_str());
}

void *fac_sqlite_open(const char *path, int32_t readOnly, int32_t create, int32_t timeoutMs) {
  FacSqliteApi *api = fac_sqlite_api();
  if (!api) return nullptr;
  if (!path || !*path) { g_fac_sqlite_error = "Database path cannot be empty"; return nullptr; }
  if (timeoutMs < 0 || timeoutMs > 600000) { g_fac_sqlite_error = "SQLite busy timeout must be between 0 and 600000 ms"; return nullptr; }
  void *nativeDb = nullptr;
  int flags = readOnly ? 0x00000001 : (0x00000002 | (create ? 0x00000004 : 0));
  flags |= 0x00010000; // SQLITE_OPEN_FULLMUTEX: serialize native calls on this connection.
  int rc = api->open_v2(path, &nativeDb, flags, nullptr);
  if (rc != 0 || !nativeDb) {
    g_fac_sqlite_error = fac_sqlite_db_error(api, nativeDb);
    if (nativeDb) api->close_v2(nativeDb);
    return nullptr;
  }
  rc = api->busy_timeout(nativeDb, timeoutMs);
  if (rc != 0) {
    g_fac_sqlite_error = fac_sqlite_db_error(api, nativeDb);
    api->close_v2(nativeDb);
    return nullptr;
  }
  std::shared_ptr<FacSqliteConnection> state;
  try { state = std::make_shared<FacSqliteConnection>(); }
  catch (...) { api->close_v2(nativeDb); g_fac_sqlite_error = "Out of memory creating SQLite connection"; return nullptr; }
  state->db = nativeDb;
  void *token = fac_sqlite_register_connection(state);
  if (!token) { api->close_v2(nativeDb); state->db = nullptr; g_fac_sqlite_error = "Unable to allocate SQLite connection token"; return nullptr; }
  g_fac_sqlite_error.clear();
  return token;
}

int32_t fac_sqlite_close(void *h) {
  auto conn = fac_sqlite_find_connection(h);
  if (!conn) { g_fac_sqlite_error = "Invalid or stale SQLite connection handle"; return -1; }
  std::lock_guard<std::mutex> lock(conn->mutex);
  if (!conn->handleActive || !conn->db) return 0;
  FacSqliteApi *api = fac_sqlite_api();
  if (!api) return -1;
  int rc = api->close_v2(conn->db);
  if (rc == 0) conn->db = nullptr;
  else g_fac_sqlite_error = fac_sqlite_db_error(api, conn->db);
  return rc;
}

void fac_sqlite_connection_free(void *h) {
  auto conn = fac_sqlite_remove_connection(h);
  if (!conn) return;
  std::lock_guard<std::mutex> lock(conn->mutex);
  conn->handleActive = false;
  if (conn->db) {
    FacSqliteApi *api = fac_sqlite_api();
    if (api) api->close_v2(conn->db);
    conn->db = nullptr;
  }
}

char *fac_sqlite_error(void *h) {
  auto conn = fac_sqlite_find_connection(h);
  if (!conn) { g_fac_sqlite_error = "Invalid or stale SQLite connection handle"; return fac_sqlite_copy_cstr(g_fac_sqlite_error.c_str()); }
  std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api();
  return fac_sqlite_copy_cstr(fac_sqlite_db_error(api, conn->db));
}

int32_t fac_sqlite_set_busy_timeout(void *h, int32_t timeoutMs) {
  auto conn = fac_sqlite_find_connection(h);
  if (!conn || timeoutMs < 0 || timeoutMs > 600000) return -1;
  std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api();
  if (!api || !conn->handleActive || !conn->db) return -1;
  int rc = api->busy_timeout(conn->db, timeoutMs);
  if (rc != 0) g_fac_sqlite_error = fac_sqlite_db_error(api, conn->db);
  return rc;
}

int32_t fac_sqlite_exec(void *h, const char *sql) {
  auto conn = fac_sqlite_find_connection(h);
  if (!conn || !sql) return -1;
  std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api();
  if (!api || !conn->handleActive || !conn->db) return -1;
  char *nativeError = nullptr;
  int rc = api->exec(conn->db, sql, nullptr, nullptr, &nativeError);
  if (rc != 0) {
    const char *fallback = fac_sqlite_db_error(api, conn->db);
    g_fac_sqlite_error = nativeError && *nativeError ? nativeError : fallback;
  } else g_fac_sqlite_error.clear();
  if (nativeError) api->free_fn(nativeError);
  return rc;
}

void *fac_sqlite_prepare(void *h, const char *sql) {
  auto conn = fac_sqlite_find_connection(h);
  if (!conn || !sql) return nullptr;
  size_t n = fac_sqlite_bounded_len(sql, 16u * 1024u * 1024u + 1u);
  if (n > 16u * 1024u * 1024u) { g_fac_sqlite_error = "SQL statement exceeds 16 MiB limit"; return nullptr; }
  std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api();
  if (!api || !conn->handleActive || !conn->db) return nullptr;
  void *nativeStmt = nullptr;
  int rc = api->prepare_v2(conn->db, sql, (int)n, &nativeStmt, nullptr);
  if (rc != 0 || !nativeStmt) {
    g_fac_sqlite_error = fac_sqlite_db_error(api, conn->db);
    if (nativeStmt) api->finalize(nativeStmt);
    return nullptr;
  }
  std::shared_ptr<FacSqliteStatement> state;
  try { state = std::make_shared<FacSqliteStatement>(); }
  catch (...) { api->finalize(nativeStmt); g_fac_sqlite_error = "Out of memory creating SQLite statement"; return nullptr; }
  state->connection = conn;
  state->stmt = nativeStmt;
  void *token = fac_sqlite_register_statement(state);
  if (!token) { api->finalize(nativeStmt); state->stmt = nullptr; g_fac_sqlite_error = "Unable to allocate SQLite statement token"; return nullptr; }
  g_fac_sqlite_error.clear();
  return token;
}

int32_t fac_sqlite_statement_finalize(void *h) {
  auto stmt = fac_sqlite_find_statement(h);
  if (!stmt) { g_fac_sqlite_error = "Invalid or stale SQLite statement handle"; return -1; }
  auto conn = stmt->connection;
  std::lock_guard<std::mutex> lock(conn->mutex);
  if (!stmt->handleActive || !stmt->stmt) return 0;
  FacSqliteApi *api = fac_sqlite_api();
  if (!api) return -1;
  void *db = api->db_handle(stmt->stmt);
  const char *before = db ? api->errmsg(db) : nullptr;
  std::string priorError = (before && *before) ? before : "SQLite statement finalization failed";
  int rc = api->finalize(stmt->stmt);
  if (rc != 0) g_fac_sqlite_error = std::move(priorError);
  stmt->stmt = nullptr;
  return rc;
}

void fac_sqlite_statement_free(void *h) {
  auto stmt = fac_sqlite_remove_statement(h);
  if (!stmt) return;
  auto conn = stmt->connection;
  std::lock_guard<std::mutex> lock(conn->mutex);
  stmt->handleActive = false;
  if (stmt->stmt) {
    FacSqliteApi *api = fac_sqlite_api();
    if (api) api->finalize(stmt->stmt);
    stmt->stmt = nullptr;
  }
}

char *fac_sqlite_statement_error(void *h) {
  auto stmt = fac_sqlite_find_statement(h);
  if (!stmt) { g_fac_sqlite_error = "Invalid or stale SQLite statement handle"; return fac_sqlite_copy_cstr(g_fac_sqlite_error.c_str()); }
  auto conn = stmt->connection;
  std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api();
  void *db = (api && stmt->stmt) ? api->db_handle(stmt->stmt) : nullptr;
  return fac_sqlite_copy_cstr(fac_sqlite_db_error(api, db));
}

int32_t fac_sqlite_step(void *h) {
  auto stmt = fac_sqlite_find_statement(h);
  if (!stmt) return -1;
  auto conn = stmt->connection;
  std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api();
  if (!api || !stmt->handleActive || !stmt->stmt) return -1;
  return api->step(stmt->stmt); // SQLITE_ROW=100; SQLITE_DONE=101; other values are errors.
}
int32_t fac_sqlite_reset(void *h) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt) return -1;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->reset(stmt->stmt) : -1;
}
int32_t fac_sqlite_clear_bindings(void *h) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt) return -1;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->clear_bindings(stmt->stmt) : -1;
}
int32_t fac_sqlite_bind_int64(void *h, int32_t index, int64_t value) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || index <= 0) return -1;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->bind_int64(stmt->stmt, index, value) : -1;
}
int32_t fac_sqlite_bind_double(void *h, int32_t index, double value) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || index <= 0) return -1;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->bind_double(stmt->stmt, index, value) : -1;
}
int32_t fac_sqlite_bind_text(void *h, int32_t index, const char *value) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || index <= 0 || !value) return -1;
  size_t n = fac_sqlite_bounded_len(value, 16u * 1024u * 1024u + 1u);
  if (n > 16u * 1024u * 1024u) return -1;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); if (!api || !stmt->handleActive || !stmt->stmt) return -1;
  auto transient = reinterpret_cast<void (*)(void *)>(static_cast<intptr_t>(-1));
  return api->bind_text(stmt->stmt, index, value, (int)n, transient);
}
int32_t fac_sqlite_bind_null(void *h, int32_t index) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || index <= 0) return -1;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->bind_null(stmt->stmt, index) : -1;
}
int32_t fac_sqlite_column_count(void *h) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt) return 0;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->column_count(stmt->stmt) : 0;
}
const char *fac_sqlite_column_name(void *h, int32_t column) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || column < 0) return "";
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); if (!api || !stmt->handleActive || !stmt->stmt) return "";
  const char *value = api->column_name(stmt->stmt, column);
  try { g_fac_sqlite_column_name.assign(value ? value : ""); }
  catch (...) { g_fac_sqlite_error = "Out of memory copying SQLite column name"; return ""; }
  return g_fac_sqlite_column_name.c_str();
}
int32_t fac_sqlite_column_type(void *h, int32_t column) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || column < 0) return 5;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->column_type(stmt->stmt, column) : 5;
}
int64_t fac_sqlite_column_int64(void *h, int32_t column) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || column < 0) return 0;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->column_int64(stmt->stmt, column) : 0;
}
double fac_sqlite_column_double(void *h, int32_t column) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || column < 0) return 0.0;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->column_double(stmt->stmt, column) : 0.0;
}
const char *fac_sqlite_column_text(void *h, int32_t column) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || column < 0) return nullptr;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); if (!api || !stmt->handleActive || !stmt->stmt) return nullptr;
  const unsigned char *value = api->column_text(stmt->stmt, column);
  int bytes = api->column_bytes(stmt->stmt, column);
  if (!value) { g_fac_sqlite_column_text.clear(); return nullptr; }
  if (bytes < 0) return nullptr;
  try { g_fac_sqlite_column_text.assign(reinterpret_cast<const char *>(value), (size_t)bytes); }
  catch (...) { g_fac_sqlite_error = "Out of memory copying SQLite column text"; return nullptr; }
  return g_fac_sqlite_column_text.c_str();
}
int32_t fac_sqlite_column_bytes(void *h, int32_t column) {
  auto stmt = fac_sqlite_find_statement(h); if (!stmt || column < 0) return 0;
  auto conn = stmt->connection; std::lock_guard<std::mutex> lock(conn->mutex);
  FacSqliteApi *api = fac_sqlite_api(); return (api && stmt->handleActive && stmt->stmt) ? api->column_bytes(stmt->stmt, column) : 0;
}
int32_t fac_sqlite_changes(void *h) {
  auto conn = fac_sqlite_find_connection(h); if (!conn) return 0;
  std::lock_guard<std::mutex> lock(conn->mutex); FacSqliteApi *api = fac_sqlite_api();
  return (api && conn->handleActive && conn->db) ? api->changes(conn->db) : 0;
}
int64_t fac_sqlite_last_insert_rowid(void *h) {
  auto conn = fac_sqlite_find_connection(h); if (!conn) return 0;
  std::lock_guard<std::mutex> lock(conn->mutex); FacSqliteApi *api = fac_sqlite_api();
  return (api && conn->handleActive && conn->db) ? api->last_insert_rowid(conn->db) : 0;
}
void fac_sqlite_string_free(char *s) { free(s); }
} // extern "C"
