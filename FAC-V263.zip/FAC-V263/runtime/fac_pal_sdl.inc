// fac_pal_sdl.inc -- Platform Abstraction Layer: หน้าต่าง + input สำหรับ Linux/macOS (และ BSD)
// โหลด SDL2 ตอนรัน (dlopen) ด้วย ABI ที่ประกาศเองขั้นต่ำ -> ไม่ต้องมี SDL header ตอน build runtime
// และโปรแกรมที่ไม่ได้เรียก graphic.open ไม่ต้องมี SDL ติดตั้งเลย.  API ฝั่ง Fac เหมือน Windows ทุกอย่าง.
// รวมเข้าไฟล์ผ่าน fac_lib.inc เฉพาะ non-Windows (อยู่ใน extern "C" และหลัง struct Canvas)
extern "C++" {
#include <dlfcn.h>

namespace pal {
typedef unsigned int u32;
struct Sdl {
  bool tried = false, ok = false; std::string err;
  int (*Init)(u32); void (*Quit)(); const char *(*GetError)();
  void *(*CreateWindow)(const char *, int, int, int, int, u32);
  void *(*CreateRenderer)(void *, int, u32);
  void *(*CreateTexture)(void *, u32, int, int, int);
  int (*UpdateTexture)(void *, const void *, const void *, int);
  int (*RenderClear)(void *); int (*RenderCopy)(void *, void *, const void *, const void *); void (*RenderPresent)(void *);
  int (*PollEvent)(void *);
  void (*DestroyTexture)(void *); void (*DestroyRenderer)(void *); void (*DestroyWindow)(void *);
  void (*SetHint)(const char *, const char *);
  int (*InitSubSystem)(u32); void (*QuitSubSystem)(u32);
  void (*StartTextInput)() = nullptr; void (*StopTextInput)() = nullptr;
  char *(*GetClipboardText)() = nullptr; int (*SetClipboardText)(const char *) = nullptr; void (*FreeClipboardText)(void *) = nullptr;
  int refs = 0; void *handle = nullptr;
};
static Sdl g;
static std::mutex load_mu;
static std::mutex video_mu; // protects the process-wide video subsystem reference count
template <class F> static bool sym(void *h, const char *n, F &out) { out = (F)dlsym(h, n); return out != nullptr; }
static bool load() {
  std::lock_guard<std::mutex> lk(load_mu);
  if (g.tried) return g.ok;
  g.tried = true;
  const char *names[] = {
#ifdef __APPLE__
    "libSDL2-2.0.0.dylib", "libSDL2.dylib", "/opt/homebrew/lib/libSDL2.dylib", "/usr/local/lib/libSDL2.dylib",
#else
    "libSDL2-2.0.so.0", "libSDL2.so", "libSDL2-2.0.so",
#endif
    nullptr};
  void *h = nullptr;
  for (int i = 0; names[i] && !h; i++) h = dlopen(names[i], RTLD_NOW | RTLD_LOCAL);
  if (!h) { g.err = "ไม่พบไลบรารี SDL2 (ติดตั้ง: apt install libsdl2-2.0-0 | brew install sdl2)"; return false; }
  bool ok = sym(h, "SDL_Init", g.Init) && sym(h, "SDL_Quit", g.Quit) && sym(h, "SDL_GetError", g.GetError) && sym(h, "SDL_CreateWindow", g.CreateWindow) &&
            sym(h, "SDL_CreateRenderer", g.CreateRenderer) && sym(h, "SDL_CreateTexture", g.CreateTexture) && sym(h, "SDL_UpdateTexture", g.UpdateTexture) &&
            sym(h, "SDL_RenderClear", g.RenderClear) && sym(h, "SDL_RenderCopy", g.RenderCopy) && sym(h, "SDL_RenderPresent", g.RenderPresent) &&
            sym(h, "SDL_PollEvent", g.PollEvent) && sym(h, "SDL_DestroyTexture", g.DestroyTexture) && sym(h, "SDL_DestroyRenderer", g.DestroyRenderer) &&
            sym(h, "SDL_DestroyWindow", g.DestroyWindow) && sym(h, "SDL_SetHint", g.SetHint) &&
            sym(h, "SDL_InitSubSystem", g.InitSubSystem) && sym(h, "SDL_QuitSubSystem", g.QuitSubSystem);
  if (!ok) { g.err = "SDL2 เวอร์ชันไม่รองรับ (ขาดฟังก์ชันที่ต้องใช้)"; return false; }
  // Text input is part of SDL2 core. Clipboard functions are optional on old
  // or reduced SDL builds; the FAC API reports failure/empty text in that case.
  sym(h, "SDL_StartTextInput", g.StartTextInput);
  sym(h, "SDL_StopTextInput", g.StopTextInput);
  sym(h, "SDL_GetClipboardText", g.GetClipboardText);
  sym(h, "SDL_SetClipboardText", g.SetClipboardText);
  sym(h, "SDL_free", g.FreeClipboardText);
  g.handle = h; g.ok = true; return true;
}
// ค่าคงที่ของ ABI SDL2 (เสถียรตลอดสาย 2.x)
enum : u32 { INIT_VIDEO = 0x20, WIN_SHOWN = 0x4, POS_UNDEF = 0x1FFF0000, PF_XRGB8888 = 0x16161804, TEX_STREAMING = 1, REND_SOFTWARE = 1,
             EV_QUIT = 0x100, EV_WINDOW = 0x200, EV_KEYDOWN = 0x300, EV_KEYUP = 0x301, EV_TEXTINPUT = 0x303, EV_MOTION = 0x400, EV_BDOWN = 0x401, EV_BUP = 0x402, WINEV_CLOSE = 14 };
// SDL keycode -> รหัสภายในของ Fac (ใช้เลขเดียวกับ Windows VK เพื่อให้ graphic.key ใช้ตารางเดียวกันทุก OS)
static int mapKey(int32_t sym) {
  if (sym >= 'a' && sym <= 'z') return sym - 32;
  if (sym >= '0' && sym <= '9') return sym;
  switch (sym) {
    case 32: return 0x20; case 27: return 0x1B; case 13: return 0x0D; case 9: return 0x09; case 8: return 0x08;
    case 0x40000050: return 0x25; case 0x40000052: return 0x26; case 0x4000004F: return 0x27; case 0x40000051: return 0x28;
    case 0x4000004A: return 0x24; case 0x4000004D: return 0x23; case 0x4000004C: return 0x2E;
    case 0x400000E1: case 0x400000E5: return 0x10; case 0x400000E0: case 0x400000E4: return 0x11;
  }
  return -1;
}
}  // namespace pal
}  // extern "C++"

Canvas *fac_gfx_open(int32_t w, int32_t h, FacStr *title) {
  if (!pal::load()) do_throw("graphic.open: " + pal::g.err, 14);
  Canvas *c = fac_gfx_create(w, h); // validate/allocate before holding the global SDL lock
  std::unique_lock<std::mutex> state(pal::video_mu);
  if (pal::g.refs == 0) {
    pal::g.SetHint("SDL_RENDER_VSYNC", "0");
    if (pal::g.InitSubSystem(pal::INIT_VIDEO) != 0) {
      std::string e = std::string("graphic.open: SDL_Init ล้มเหลว: ") + pal::g.GetError();
      state.unlock(); delete c; do_throw(std::move(e), 14);
    }
  }
  c->win = pal::g.CreateWindow(sd(title), (int)pal::POS_UNDEF, (int)pal::POS_UNDEF, w, h, pal::WIN_SHOWN);
  if (c->win) { c->ren = pal::g.CreateRenderer(c->win, -1, 0); if (!c->ren) c->ren = pal::g.CreateRenderer(c->win, -1, pal::REND_SOFTWARE); }
  if (c->ren) c->tex = pal::g.CreateTexture(c->ren, pal::PF_XRGB8888, pal::TEX_STREAMING, w, h);
  if (!c->tex) {
    std::string e = std::string("graphic.open: สร้างหน้าต่างไม่ได้: ") + pal::g.GetError();
    if (c->ren) pal::g.DestroyRenderer(c->ren);
    if (c->win) pal::g.DestroyWindow(c->win);
    if (pal::g.refs == 0) pal::g.QuitSubSystem(pal::INIT_VIDEO);
    state.unlock(); delete c; do_throw(std::move(e), 14);
  }
  pal::g.refs++;
  return c;
}
static void fac_pal_close(Canvas *c) {
  if (!c) return;
  std::lock_guard<std::mutex> state(pal::video_mu);
  if (!c->win) return;
  if (c->textInputActive && pal::g.StopTextInput) pal::g.StopTextInput();
  c->textInputActive = false;
  if (c->tex) pal::g.DestroyTexture(c->tex);
  if (c->ren) pal::g.DestroyRenderer(c->ren);
  pal::g.DestroyWindow(c->win);
  c->tex = c->ren = c->win = nullptr;
  if (--pal::g.refs == 0) pal::g.QuitSubSystem(pal::INIT_VIDEO);
}
int32_t fac_gfx_poll(Canvas *c) {
  if (!c) return 0;
  c->textFrame.clear();
  std::lock_guard<std::mutex> state(pal::video_mu);
  if (!c->win) return !c->closed;
  alignas(16) unsigned char ev[64];
  while (pal::g.PollEvent(ev)) {
    pal::u32 type; memcpy(&type, ev, 4);
    switch (type) {
      case pal::EV_QUIT: c->closed = true; break;
      case pal::EV_WINDOW: if (ev[12] == pal::WINEV_CLOSE) c->closed = true; break;
      case pal::EV_KEYDOWN: case pal::EV_KEYUP: { int32_t sym; memcpy(&sym, ev + 20, 4); int k = pal::mapKey(sym); if (k >= 0 && k < 256) c->keys[k] = (type == pal::EV_KEYDOWN); break; }
      case pal::EV_TEXTINPUT: if (c->textInputActive) { const char *text = (const char *)(ev + 12); fac_gfx_append_text(c, text, strnlen(text, 32)); } break;
      case pal::EV_MOTION: { int32_t x, y; memcpy(&x, ev + 20, 4); memcpy(&y, ev + 24, 4); c->mx = x; c->my = y; break; }
      case pal::EV_BDOWN: case pal::EV_BUP: {
        int32_t x, y; memcpy(&x, ev + 20, 4); memcpy(&y, ev + 24, 4); c->mx = x; c->my = y;
        int bit = ev[16] == 1 ? 1 : ev[16] == 3 ? 2 : ev[16] == 2 ? 4 : 0;
        if (bit) { if (type == pal::EV_BDOWN) c->mbuttons |= bit; else c->mbuttons &= ~bit; }
        if (ev[16] == 1) c->mdown = (type == pal::EV_BDOWN);
        break;
      }
    }
  }
  return !c->closed;
}
void fac_gfx_present(Canvas *c) {
  std::lock_guard<std::mutex> state(pal::video_mu);
  if (!c->win || !c->tex) return;
  pal::g.UpdateTexture(c->tex, nullptr, c->px.data(), c->w * 4);
  pal::g.RenderClear(c->ren); pal::g.RenderCopy(c->ren, c->tex, nullptr, nullptr); pal::g.RenderPresent(c->ren);
}
