// Optional Pango/Cairo/Fontconfig backend for vector fonts.
// No Pango headers or link-time dependency: applications keep the bitmap fallback
// unless the shared libraries are available at runtime.
#ifndef _WIN32
namespace facfont {
struct PangoFontMap; struct PangoContext; struct PangoLayout; struct PangoFontDescription;
struct Cairo; struct CairoSurface; struct FcConfig; struct FcPattern; struct FcBlanks;
using FcChar8 = unsigned char;
struct PangoRectangle { int x, y, width, height; };

struct Api {
  void *pango=nullptr, *pangocairo=nullptr, *pangoft2=nullptr, *cairo=nullptr, *fontconfig=nullptr, *gobject=nullptr;
  PangoFontMap *(*font_map_default)()=nullptr;
  PangoContext *(*font_map_context)(PangoFontMap*)=nullptr;
  PangoLayout *(*layout_new)(PangoContext*)=nullptr;
  void (*layout_set_desc)(PangoLayout*, const PangoFontDescription*)=nullptr;
  void (*layout_set_text)(PangoLayout*, const char*, int)=nullptr;
  void (*layout_get_extents)(PangoLayout*, PangoRectangle*, PangoRectangle*)=nullptr;
  void (*layout_get_size)(PangoLayout*, int*, int*)=nullptr;
  PangoFontDescription *(*desc_new)()=nullptr;
  void (*desc_family)(PangoFontDescription*, const char*)=nullptr;
  void (*desc_abs_size)(PangoFontDescription*, double)=nullptr;
  void (*desc_free)(PangoFontDescription*)=nullptr;
  void (*show_layout)(Cairo*, PangoLayout*)=nullptr;
  FcConfig *(*fc_current)()=nullptr;
  int (*fc_init)()=nullptr;
  int (*fc_add_file)(FcConfig*, const FcChar8*)=nullptr;
  int (*fc_build)(FcConfig*)=nullptr;
  FcPattern *(*fc_query)(const FcChar8*, unsigned int, const FcBlanks*, int*)=nullptr;
  int (*fc_get_string)(FcPattern*, const char*, int, FcChar8**)=nullptr;
  void (*fc_pattern_destroy)(FcPattern*)=nullptr;
  void (*fc_map_changed)(PangoFontMap*)=nullptr;
  CairoSurface *(*surface_create)(unsigned char*, int, int, int, int)=nullptr;
  Cairo *(*cairo_create)(CairoSurface*)=nullptr;
  void (*cairo_destroy)(Cairo*)=nullptr;
  void (*surface_destroy)(CairoSurface*)=nullptr;
  void (*surface_flush)(CairoSurface*)=nullptr;
  void (*cairo_move_to)(Cairo*, double, double)=nullptr;
  void (*cairo_source_rgba)(Cairo*, double, double, double, double)=nullptr;
  void (*g_unref)(void*)=nullptr;
  bool ready=false;
  // Pango layouts and the default font map are shared backend state.
  // Serialize all FAC entry points that touch these objects, not only
  // Fontconfig registration. A recursive mutex permits helpers such as
  // fac_font_vector_draw() to call fac_font_layout_text() safely.
  std::recursive_mutex backendMutex;
  std::set<std::string> registeredFiles;

  template<class T> bool sym(T &dst, void *lib, const char *name) {
    dst = reinterpret_cast<T>(lib ? dlsym(lib, name) : nullptr);
    return dst != nullptr;
  }
  void *openAny(std::initializer_list<const char*> names) {
    for (auto n : names) { if (void *h=dlopen(n, RTLD_NOW|RTLD_LOCAL)) return h; }
    return nullptr;
  }
  Api() {
#if defined(__APPLE__)
    pango=openAny({"libpango-1.0.0.dylib", "libpango-1.0.dylib"});
    pangocairo=openAny({"libpangocairo-1.0.0.dylib", "libpangocairo-1.0.dylib"});
    pangoft2=openAny({"libpangoft2-1.0.0.dylib", "libpangoft2-1.0.dylib"});
    cairo=openAny({"libcairo.2.dylib", "libcairo.dylib"});
    fontconfig=openAny({"libfontconfig.1.dylib", "libfontconfig.dylib"});
    gobject=openAny({"libgobject-2.0.0.dylib", "libgobject-2.0.dylib"});
#else
    pango=openAny({"libpango-1.0.so.0"});
    pangocairo=openAny({"libpangocairo-1.0.so.0"});
    pangoft2=openAny({"libpangoft2-1.0.so.0"});
    cairo=openAny({"libcairo.so.2"});
    fontconfig=openAny({"libfontconfig.so.1"});
    gobject=openAny({"libgobject-2.0.so.0"});
#endif
    bool ok=true;
    ok &= sym(font_map_default,pangocairo,"pango_cairo_font_map_get_default");
    ok &= sym(font_map_context,pango,"pango_font_map_create_context");
    ok &= sym(layout_new,pango,"pango_layout_new");
    ok &= sym(layout_set_desc,pango,"pango_layout_set_font_description");
    ok &= sym(layout_set_text,pango,"pango_layout_set_text");
    ok &= sym(layout_get_extents,pango,"pango_layout_get_pixel_extents");
    ok &= sym(layout_get_size,pango,"pango_layout_get_pixel_size");
    ok &= sym(desc_new,pango,"pango_font_description_new");
    ok &= sym(desc_family,pango,"pango_font_description_set_family");
    ok &= sym(desc_abs_size,pango,"pango_font_description_set_absolute_size");
    ok &= sym(desc_free,pango,"pango_font_description_free");
    ok &= sym(show_layout,pangocairo,"pango_cairo_show_layout");
    ok &= sym(fc_current,fontconfig,"FcConfigGetCurrent");
    ok &= sym(fc_init,fontconfig,"FcInit");
    ok &= sym(fc_add_file,fontconfig,"FcConfigAppFontAddFile");
    ok &= sym(fc_build,fontconfig,"FcConfigBuildFonts");
    ok &= sym(fc_query,fontconfig,"FcFreeTypeQuery");
    ok &= sym(fc_get_string,fontconfig,"FcPatternGetString");
    ok &= sym(fc_pattern_destroy,fontconfig,"FcPatternDestroy");
    ok &= sym(fc_map_changed,pangoft2,"pango_fc_font_map_config_changed");
    ok &= sym(surface_create,cairo,"cairo_image_surface_create_for_data");
    ok &= sym(cairo_create,cairo,"cairo_create");
    ok &= sym(cairo_destroy,cairo,"cairo_destroy");
    ok &= sym(surface_destroy,cairo,"cairo_surface_destroy");
    ok &= sym(surface_flush,cairo,"cairo_surface_flush");
    ok &= sym(cairo_move_to,cairo,"cairo_move_to");
    ok &= sym(cairo_source_rgba,cairo,"cairo_set_source_rgba");
    ok &= sym(g_unref,gobject,"g_object_unref");
    ready=ok;
  }
  // Pango/Fontconfig maintain process-global caches and may own backend
  // worker/TLS state. Keep their dlopen references pinned until process exit
  // rather than dlclose during static destruction, when other runtime TLS and
  // library-owned teardown callbacks may still be pending.
  ~Api() = default;
};
static Api &api() { static Api a; return a; }
static bool validUtf8(const char *s, size_t n) {
  size_t i=0;
  while (i<n) {
    unsigned char c=(unsigned char)s[i++];
    if (c<0x80) continue;
    uint32_t cp=0; int more=0;
    if (c>=0xC2 && c<=0xDF) { cp=c&0x1F; more=1; }
    else if (c>=0xE0 && c<=0xEF) { cp=c&0x0F; more=2; }
    else if (c>=0xF0 && c<=0xF4) { cp=c&0x07; more=3; }
    else return false;
    if (i+(size_t)more>n) return false;
    for (int k=0;k<more;k++) { unsigned char d=(unsigned char)s[i++]; if ((d&0xC0)!=0x80) return false; cp=(cp<<6)|(d&0x3F); }
    if ((more==1 && cp<0x80)||(more==2 && cp<0x800)||(more==3 && cp<0x10000)||cp>0x10FFFF||(cp>=0xD800&&cp<=0xDFFF)) return false;
  }
  return true;
}
} // namespace facfont
#endif
