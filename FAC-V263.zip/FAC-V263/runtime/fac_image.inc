// fac_image.inc -- ตัวถอดรหัสภาพในตัว (ไม่พึ่ง library ภายนอก, ไม่ขึ้นกับ OS/สถาปัตยกรรม): zlib/DEFLATE + PNG
// PNG: color type 0,2,3,4,6 / bit depth 1,2,4,8,16 / tRNS / Adam7 interlace / ตรวจ CRC ทุก chunk และ Adler-32 ของ zlib
// 16-bit ถูกลดเป็น 8-bit ด้วยการตัดเอา byte สูง. ข้อมูลเสียหายหรือเกินขีดจำกัดจะ throw Error (code 14) ไม่ crash
// ขีดจำกัด: ภาพไม่เกิน 16M พิกเซล; จำกัดขนาดเพื่อคุมหน่วยความจำของ Canvas + depth buffer.
#include <cstdint>
#include "fac_limits.hpp"
#include <cstring>
#include <string>
#include <vector>

namespace fimg {
struct Bits {
  const uint8_t *p; size_t n, pos = 0; uint32_t buf = 0; int cnt = 0; bool bad = false;
  uint32_t get(int need) {
    while (cnt < need) { if (pos >= n) { bad = true; return 0; } buf |= (uint32_t)p[pos++] << cnt; cnt += 8; }
    uint32_t v = buf & ((1u << need) - 1); buf >>= need; cnt -= need; return v;
  }
};
struct Huff { uint16_t count[16]; uint16_t symbol[320]; };
static int construct(Huff &h, const uint8_t *len, int n) {
  for (int i = 0; i < 16; i++) h.count[i] = 0;
  for (int s = 0; s < n; s++) h.count[len[s]]++;
  if (h.count[0] == n) return 0;
  int left = 1;
  for (int l = 1; l < 16; l++) { left <<= 1; left -= h.count[l]; if (left < 0) return left; }
  uint16_t offs[16]; offs[1] = 0;
  for (int l = 1; l < 15; l++) offs[l + 1] = (uint16_t)(offs[l] + h.count[l]);
  for (int s = 0; s < n; s++) if (len[s]) h.symbol[offs[len[s]]++] = (uint16_t)s;
  return left;
}
static int decodeSym(Bits &b, const Huff &h) {
  int code = 0, first = 0, index = 0;
  for (int l = 1; l < 16; l++) {
    code |= (int)b.get(1); if (b.bad) return -1;
    int count = h.count[l];
    if (code - count < first) return h.symbol[index + (code - first)];
    index += count; first += count; first <<= 1; code <<= 1;
  }
  return -1;
}
static bool codes(Bits &b, std::vector<uint8_t> &out, const Huff &lc, const Huff &dc, size_t cap) {
  static const uint16_t lbase[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
  static const uint16_t lext[29] = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
  static const uint16_t dbase[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
  static const uint16_t dext[30] = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};
  for (;;) {
    int s = decodeSym(b, lc); if (s < 0) return false;
    if (s < 256) { if (out.size() >= cap) return false; out.push_back((uint8_t)s); }
    else if (s == 256) return true;
    else {
      s -= 257; if (s >= 29) return false;
      size_t len = lbase[s] + b.get(lext[s]); int ds = decodeSym(b, dc); if (ds < 0 || ds >= 30) return false;
      size_t dist = dbase[ds] + b.get(dext[ds]); if (b.bad || dist > out.size() || out.size() + len > cap) return false;
      size_t from = out.size() - dist; for (size_t i = 0; i < len; i++) out.push_back(out[from + i]);
    }
  }
}
static bool inflateRaw(const uint8_t *src, size_t n, std::vector<uint8_t> &out, size_t cap, size_t *used) {
  Bits b{src, n};
  int last;
  do {
    last = (int)b.get(1); int type = (int)b.get(2); if (b.bad) return false;
    if (type == 0) {
      b.buf = 0; b.cnt = 0;
      if (b.pos + 4 > n) return false;
      unsigned len = src[b.pos] | src[b.pos + 1] << 8, nlen = src[b.pos + 2] | src[b.pos + 3] << 8; b.pos += 4;
      if ((len ^ 0xFFFF) != nlen || b.pos + len > n || out.size() + len > cap) return false;
      out.insert(out.end(), src + b.pos, src + b.pos + len); b.pos += len;
    } else if (type == 1) {
      struct FixedHuffman { Huff litlen; Huff distance; };
      // Function-local static initialization is synchronized by C++ across threads.
      static const FixedHuffman fixed = [] {
        FixedHuffman f{}; uint8_t l[288]; int i = 0;
        for (; i < 144; i++) l[i] = 8;
        for (; i < 256; i++) l[i] = 9;
        for (; i < 280; i++) l[i] = 7;
        for (; i < 288; i++) l[i] = 8;
        construct(f.litlen, l, 288);
        for (i = 0; i < 30; i++) l[i] = 5;
        construct(f.distance, l, 30);
        return f;
      }();
      if (!codes(b, out, fixed.litlen, fixed.distance, cap)) return false;
    } else if (type == 2) {
      int nlen = (int)b.get(5) + 257, ndist = (int)b.get(5) + 1, ncode = (int)b.get(4) + 4;
      if (b.bad || nlen > 286 || ndist > 30) return false;
      static const uint8_t order[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
      uint8_t lengths[320]; int idx = 0;
      for (; idx < ncode; idx++) lengths[order[idx]] = (uint8_t)b.get(3);
      for (; idx < 19; idx++) lengths[order[idx]] = 0;
      if (b.bad) return false;
      Huff lencode, distcode;
      if (construct(lencode, lengths, 19) != 0) return false;
      idx = 0;
      while (idx < nlen + ndist) {
        int sym = decodeSym(b, lencode); if (sym < 0) return false;
        if (sym < 16) lengths[idx++] = (uint8_t)sym;
        else {
          int len = 0, rep;
          if (sym == 16) { if (idx == 0) return false; len = lengths[idx - 1]; rep = 3 + (int)b.get(2); }
          else if (sym == 17) rep = 3 + (int)b.get(3); else rep = 11 + (int)b.get(7);
          if (b.bad || idx + rep > nlen + ndist) return false;
          while (rep--) lengths[idx++] = (uint8_t)len;
        }
      }
      if (lengths[256] == 0) return false;
      int e = construct(lencode, lengths, nlen); if (e < 0 || (e > 0 && nlen - lencode.count[0] != 1)) return false;
      e = construct(distcode, lengths + nlen, ndist); if (e < 0 || (e > 0 && ndist - distcode.count[0] != 1)) return false;
      if (!codes(b, out, lencode, distcode, cap)) return false;
    } else return false;
  } while (!last);
  if (used) *used = b.pos;
  return true;
}
static bool zlibInflate(const uint8_t *d, size_t n, std::vector<uint8_t> &out, size_t cap) {
  if (n < 6 || (d[0] & 0x0F) != 8 || (d[0] >> 4) > 7 || ((d[0] << 8) | d[1]) % 31 != 0 || (d[1] & 0x20)) return false;
  size_t used = 0; if (!inflateRaw(d + 2, n - 2, out, cap, &used)) return false;
  if (2 + used + 4 > n) return false;
  uint32_t a = 1, bb = 0; for (uint8_t c : out) { a = (a + c) % 65521; bb = (bb + a) % 65521; }
  const uint8_t *t = d + 2 + used; uint32_t want = (uint32_t)t[0] << 24 | (uint32_t)t[1] << 16 | (uint32_t)t[2] << 8 | t[3];
  return want == ((bb << 16) | a);
}

struct Image { int w = 0, h = 0; bool alpha = false; std::vector<uint8_t> rgba; };
static uint32_t be32(const uint8_t *p) { return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3]; }

// คืน "" เมื่อสำเร็จ หรือข้อความ error
static std::string decodePng(const uint8_t *d, size_t n, Image &img, uint32_t (*crc)(const uint8_t *, size_t, uint32_t)) {
  static const uint8_t sig[8] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};
  if (n < 8 || memcmp(d, sig, 8) != 0) return "ไม่ใช่ไฟล์ PNG";
  size_t pos = 8; bool gotHdr = false, gotEnd = false;
  uint32_t W = 0, H = 0; int depth = 0, ctype = 0, interlace = 0;
  std::vector<uint8_t> idat, plte, trns;
  while (pos + 12 <= n && !gotEnd) {
    uint32_t len = be32(d + pos); if (len > 0x7FFFFFFFu || pos + 12 + (size_t)len > n) return "chunk PNG ถูกตัดหรือขนาดผิด";
    const uint8_t *type = d + pos + 4, *body = d + pos + 8;
    if (crc(type, (size_t)len + 4, 0) != be32(body + len)) return "CRC ของ chunk PNG ไม่ตรง (ไฟล์เสียหาย)";
    if (!memcmp(type, "IHDR", 4)) {
      if (len != 13 || gotHdr) return "IHDR ไม่ถูกต้อง";
      W = be32(body); H = be32(body + 4); depth = body[8]; ctype = body[9]; interlace = body[12];
      if (body[10] != 0 || body[11] != 0 || interlace > 1) return "PNG method/filter/interlace ไม่รองรับ";
      if (W == 0 || H == 0 || (uint64_t)W * H > FAC_GFX_MAX_PIXELS) return "ขนาดภาพ PNG ใหญ่เกินไปหรือเป็นศูนย์ (สูงสุด 16M พิกเซล)";
      bool ok = (ctype == 0 && (depth == 1 || depth == 2 || depth == 4 || depth == 8 || depth == 16)) || (ctype == 3 && (depth == 1 || depth == 2 || depth == 4 || depth == 8)) ||
                ((ctype == 2 || ctype == 4 || ctype == 6) && (depth == 8 || depth == 16));
      if (!ok) return "color type/bit depth ของ PNG ไม่ถูกต้อง"; gotHdr = true;
    } else if (!gotHdr) return "PNG ต้องเริ่มด้วย IHDR";
    else if (!memcmp(type, "PLTE", 4)) { if (len % 3 || len > 768 || len == 0) return "PLTE ไม่ถูกต้อง"; plte.assign(body, body + len); }
    else if (!memcmp(type, "tRNS", 4)) trns.assign(body, body + len);
    else if (!memcmp(type, "IDAT", 4)) { if (idat.size() + len > ((size_t)1 << 30)) return "ข้อมูล PNG ใหญ่เกินไป"; idat.insert(idat.end(), body, body + len); }
    else if (!memcmp(type, "IEND", 4)) gotEnd = true;
    else if (!(type[0] & 0x20)) return "พบ critical chunk ที่ไม่รู้จัก";
    pos += 12 + (size_t)len;
  }
  if (!gotHdr || !gotEnd || idat.empty()) return "PNG ไม่สมบูรณ์ (ไม่มี IDAT/IEND)";
  if (ctype == 3 && plte.empty()) return "PNG แบบ palette ไม่มี PLTE";
  int chans = ctype == 0 ? 1 : ctype == 2 ? 3 : ctype == 3 ? 1 : ctype == 4 ? 2 : 4;
  size_t bitsPP = (size_t)chans * (size_t)depth, bpp = std::max<size_t>(1, bitsPP / 8);
  struct Pass { uint32_t xs, ys, dx, dy; };
  static const Pass ipass[7] = {{0,0,8,8},{4,0,8,8},{0,4,4,8},{2,0,4,4},{0,2,2,4},{1,0,2,2},{0,1,1,2}};
  static const Pass npass[1] = {{0,0,1,1}};
  int np = interlace ? 7 : 1; const Pass *ps = interlace ? ipass : npass;
  size_t need = 0;
  for (int i = 0; i < np; i++) {
    uint32_t pw = W > ps[i].xs ? (W - ps[i].xs + ps[i].dx - 1) / ps[i].dx : 0, ph = H > ps[i].ys ? (H - ps[i].ys + ps[i].dy - 1) / ps[i].dy : 0;
    if (pw && ph) need += (size_t)ph * (1 + ((size_t)pw * bitsPP + 7) / 8);
  }
  std::vector<uint8_t> raw; raw.reserve(need);
  if (!zlibInflate(idat.data(), idat.size(), raw, need)) return "ข้อมูลบีบอัด (zlib) ของ PNG เสียหาย";
  if (raw.size() != need) return "ข้อมูลภาพ PNG สั้น/ยาวผิดขนาด";
  // tRNS
  bool hasT = !trns.empty() && (ctype == 0 || ctype == 2 || ctype == 3);
  uint16_t tg = 0, tr = 0, tgc = 0, tb = 0;
  if (hasT && ctype == 0) { if (trns.size() < 2) return "tRNS ไม่ถูกต้อง"; tg = (uint16_t)(trns[0] << 8 | trns[1]); }
  if (hasT && ctype == 2) { if (trns.size() < 6) return "tRNS ไม่ถูกต้อง"; tr = (uint16_t)(trns[0] << 8 | trns[1]); tgc = (uint16_t)(trns[2] << 8 | trns[3]); tb = (uint16_t)(trns[4] << 8 | trns[5]); }
  img.w = (int)W; img.h = (int)H; img.alpha = (ctype == 4 || ctype == 6 || hasT);
  img.rgba.assign((size_t)W * H * 4, 255);
  size_t off = 0;
  for (int pi = 0; pi < np; pi++) {
    uint32_t pw = W > ps[pi].xs ? (W - ps[pi].xs + ps[pi].dx - 1) / ps[pi].dx : 0, ph = H > ps[pi].ys ? (H - ps[pi].ys + ps[pi].dy - 1) / ps[pi].dy : 0;
    if (!pw || !ph) continue;
    size_t stride = ((size_t)pw * bitsPP + 7) / 8;
    std::vector<uint8_t> prev(stride, 0), cur(stride);
    for (uint32_t y = 0; y < ph; y++) {
      uint8_t ft = raw[off++]; memcpy(cur.data(), &raw[off], stride); off += stride;
      for (size_t i = 0; i < stride; i++) {
        int a = i >= bpp ? cur[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0, x = cur[i], v;
        switch (ft) {
          case 0: v = x; break; case 1: v = x + a; break; case 2: v = x + b; break; case 3: v = x + ((a + b) >> 1); break;
          case 4: { int p = a + b - c, pa = abs(p - a), pb = abs(p - b), pc = abs(p - c); v = x + ((pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c)); break; }
          default: return "filter type PNG ไม่ถูกต้อง";
        }
        cur[i] = (uint8_t)v;
      }
      for (uint32_t x = 0; x < pw; x++) {
        uint8_t *o = &img.rgba[((size_t)(ps[pi].ys + y * ps[pi].dy) * W + (ps[pi].xs + x * ps[pi].dx)) * 4];
        auto sample = [&](int ch) -> uint32_t {   // ค่าดิบของ channel ch (0..2^depth-1)
          if (depth == 8) return cur[(size_t)x * chans + ch];
          if (depth == 16) return (uint32_t)cur[((size_t)x * chans + ch) * 2] << 8 | cur[((size_t)x * chans + ch) * 2 + 1];
          size_t bit = (size_t)x * depth; return (cur[bit / 8] >> (8 - depth - (int)(bit % 8))) & ((1u << depth) - 1);
        };
        auto to8 = [&](uint32_t v) -> uint8_t { return depth == 16 ? (uint8_t)(v >> 8) : depth == 8 ? (uint8_t)v : (uint8_t)(v * 255 / ((1u << depth) - 1)); };
        if (ctype == 0) { uint32_t g = sample(0); uint8_t v = to8(g); o[0] = o[1] = o[2] = v; if (hasT && g == tg) o[3] = 0; }
        else if (ctype == 2) { uint32_t r = sample(0), g = sample(1), bl = sample(2); o[0] = to8(r); o[1] = to8(g); o[2] = to8(bl); if (hasT && r == tr && g == tgc && bl == tb) o[3] = 0; }
        else if (ctype == 3) { uint32_t i = sample(0); if (i * 3 + 2 >= plte.size()) return "index ของ palette เกินขนาด PLTE"; o[0] = plte[i * 3]; o[1] = plte[i * 3 + 1]; o[2] = plte[i * 3 + 2]; if (hasT && i < trns.size()) o[3] = trns[i]; }
        else if (ctype == 4) { uint8_t v = to8(sample(0)); o[0] = o[1] = o[2] = v; o[3] = to8(sample(1)); }
        else { o[0] = to8(sample(0)); o[1] = to8(sample(1)); o[2] = to8(sample(2)); o[3] = to8(sample(3)); }
      }
      prev.swap(cur);
    }
  }
  return "";
}
}  // namespace fimg
