// fac_lib.inc -- standard runtime libraries, including foundational 3D/GPU-resource/audio/font/input APIs
// (included at the end of fac_rt.cpp, so it shares the static helpers: mk, mks, sd, sl, do_throw ...)
#include <ctime>
#include <cstring>
#include <cmath>
#include <limits>
#include <cerrno>
#if defined(__linux__) || defined(__APPLE__)
#include <dlfcn.h>
#endif
#include "fac_limits.hpp"
#ifndef _WIN32
#include <fcntl.h>
#if defined(__linux__)
#include <sys/random.h>
#endif
#include <spawn.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#else
#include <process.h>
#endif

// ================================================================ time
static int64_t dfc(int64_t y, unsigned m, unsigned d) {  // days from civil (Hinnant)
  y -= m <= 2; int64_t era = (y >= 0 ? y : y - 399) / 400; unsigned yoe = (unsigned)(y - era * 400);
  unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1; unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return era * 146097 + (int64_t)doe - 719468;
}
static struct tm tmof(int64_t ms, bool utc) {
  // C++ signed division truncates toward zero; adjust negative fractional seconds
  // without negating INT64_MIN (which would overflow).
  int64_t s = ms / 1000;
  if (ms < 0 && ms % 1000) --s;
  if constexpr (std::numeric_limits<time_t>::is_signed) {
    if (s < (int64_t)std::numeric_limits<time_t>::min() || s > (int64_t)std::numeric_limits<time_t>::max())
      do_throw("time: timestamp is out of range", 12);
  } else {
    if (s < 0 || (uint64_t)s > (uint64_t)std::numeric_limits<time_t>::max())
      do_throw("time: timestamp is out of range", 12);
  }
  time_t t = (time_t)s; struct tm r{}; bool ok = false;
#ifdef _WIN32
  ok = (utc ? gmtime_s(&r, &t) : localtime_s(&r, &t)) == 0;
#else
  ok = (utc ? gmtime_r(&t, &r) : localtime_r(&t, &r)) != nullptr;
#endif
  if (!ok) do_throw("time: timestamp is out of range", 12);
  return r;
}
extern "C" {
int64_t fac_time_sec() { return (int64_t)time(nullptr); }
uint64_t fac_time_mono() { return (uint64_t)std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
FacStr *fac_time_format(int64_t ms, FacStr *fmt) { struct tm r = tmof(ms, false); char b[512]; size_t n = strftime(b, sizeof b, sd(fmt), &r); return mk(b, (int64_t)n); }
FacStr *fac_time_formatutc(int64_t ms, FacStr *fmt) { struct tm r = tmof(ms, true); char b[512]; size_t n = strftime(b, sizeof b, sd(fmt), &r); return mk(b, (int64_t)n); }
FacStr *fac_time_iso(int64_t ms) { struct tm r = tmof(ms, true); char b[64]; size_t n = strftime(b, sizeof b, "%Y-%m-%dT%H:%M:%SZ", &r); return mk(b, (int64_t)n); }
int64_t fac_time_parse(FacStr *s, FacStr *fmt) {  // อ่านเป็น UTC; รองรับ %Y %y %m %d %H %M %S และตัวอักษรตรงๆ
  const char *p = sd(s), *f = sd(fmt); int Y = 1970, mo = 1, d = 1, H = 0, Mi = 0, S = 0;
  auto num = [&](int maxd, int &out) { int n = 0, v = 0; while (n < maxd && isdigit((unsigned char)*p)) { v = v * 10 + (*p++ - '0'); n++; } if (!n) do_throw("time.parse: format mismatch", 12); out = v; };
  for (; *f; f++) {
    if (*f != '%') { if (*p != *f) do_throw("time.parse: format mismatch", 12); p++; continue; }
    f++;
    switch (*f) { case 'Y': num(4, Y); break; case 'y': num(2, Y); Y += Y < 70 ? 2000 : 1900; break; case 'm': num(2, mo); break; case 'd': num(2, d); break;
      case 'H': num(2, H); break; case 'M': num(2, Mi); break; case 'S': num(2, S); break; default: do_throw("time.parse: unsupported %" + std::string(1, *f), 12); }
  }
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || H > 23 || Mi > 59 || S > 60) do_throw("time.parse: value out of range", 12);
  return ((dfc(Y, (unsigned)mo, (unsigned)d) * 24 + H) * 60 + Mi) * 60000 + (int64_t)S * 1000;
}
int32_t fac_time_year(int64_t ms) { return tmof(ms, false).tm_year + 1900; }
int32_t fac_time_month(int64_t ms) { return tmof(ms, false).tm_mon + 1; }
int32_t fac_time_day(int64_t ms) { return tmof(ms, false).tm_mday; }
int32_t fac_time_hour(int64_t ms) { return tmof(ms, false).tm_hour; }
int32_t fac_time_minute(int64_t ms) { return tmof(ms, false).tm_min; }
int32_t fac_time_second(int64_t ms) { return tmof(ms, false).tm_sec; }
int32_t fac_time_weekday(int64_t ms) { return tmof(ms, false).tm_wday; }  // 0 = อาทิตย์
int32_t fac_time_utcoffset() {
  time_t t = time(nullptr); struct tm l = tmof((int64_t)t * 1000, false), g = tmof((int64_t)t * 1000, true);
  int64_t a = ((dfc(l.tm_year + 1900, (unsigned)l.tm_mon + 1, (unsigned)l.tm_mday) * 24 + l.tm_hour) * 60 + l.tm_min);
  int64_t b = ((dfc(g.tm_year + 1900, (unsigned)g.tm_mon + 1, (unsigned)g.tm_mday) * 24 + g.tm_hour) * 60 + g.tm_min);
  return (int32_t)(a - b);
}
}

// ================================================================ crypto
static const uint32_t K256[64] = {0x428A2F98u, 0x71374491u, 0xB5C0FBCFu, 0xE9B5DBA5u, 0x3956C25Bu, 0x59F111F1u, 0x923F82A4u, 0xAB1C5ED5u, 0xD807AA98u, 0x12835B01u, 0x243185BEu, 0x550C7DC3u, 0x72BE5D74u, 0x80DEB1FEu, 0x9BDC06A7u, 0xC19BF174u, 0xE49B69C1u, 0xEFBE4786u, 0x0FC19DC6u, 0x240CA1CCu, 0x2DE92C6Fu, 0x4A7484AAu, 0x5CB0A9DCu, 0x76F988DAu, 0x983E5152u, 0xA831C66Du, 0xB00327C8u, 0xBF597FC7u, 0xC6E00BF3u, 0xD5A79147u, 0x06CA6351u, 0x14292967u, 0x27B70A85u, 0x2E1B2138u, 0x4D2C6DFCu, 0x53380D13u, 0x650A7354u, 0x766A0ABBu, 0x81C2C92Eu, 0x92722C85u, 0xA2BFE8A1u, 0xA81A664Bu, 0xC24B8B70u, 0xC76C51A3u, 0xD192E819u, 0xD6990624u, 0xF40E3585u, 0x106AA070u, 0x19A4C116u, 0x1E376C08u, 0x2748774Cu, 0x34B0BCB5u, 0x391C0CB3u, 0x4ED8AA4Au, 0x5B9CCA4Fu, 0x682E6FF3u, 0x748F82EEu, 0x78A5636Fu, 0x84C87814u, 0x8CC70208u, 0x90BEFFFAu, 0xA4506CEBu, 0xBEF9A3F7u, 0xC67178F2u};
static const uint32_t H256[8] = {0x6A09E667u, 0xBB67AE85u, 0x3C6EF372u, 0xA54FF53Au, 0x510E527Fu, 0x9B05688Cu, 0x1F83D9ABu, 0x5BE0CD19u};
static const uint64_t K512[80] = {0x428A2F98D728AE22ULL, 0x7137449123EF65CDULL, 0xB5C0FBCFEC4D3B2FULL, 0xE9B5DBA58189DBBCULL, 0x3956C25BF348B538ULL, 0x59F111F1B605D019ULL, 0x923F82A4AF194F9BULL, 0xAB1C5ED5DA6D8118ULL, 0xD807AA98A3030242ULL, 0x12835B0145706FBEULL, 0x243185BE4EE4B28CULL, 0x550C7DC3D5FFB4E2ULL, 0x72BE5D74F27B896FULL, 0x80DEB1FE3B1696B1ULL, 0x9BDC06A725C71235ULL, 0xC19BF174CF692694ULL, 0xE49B69C19EF14AD2ULL, 0xEFBE4786384F25E3ULL, 0x0FC19DC68B8CD5B5ULL, 0x240CA1CC77AC9C65ULL, 0x2DE92C6F592B0275ULL, 0x4A7484AA6EA6E483ULL, 0x5CB0A9DCBD41FBD4ULL, 0x76F988DA831153B5ULL, 0x983E5152EE66DFABULL, 0xA831C66D2DB43210ULL, 0xB00327C898FB213FULL, 0xBF597FC7BEEF0EE4ULL, 0xC6E00BF33DA88FC2ULL, 0xD5A79147930AA725ULL, 0x06CA6351E003826FULL, 0x142929670A0E6E70ULL, 0x27B70A8546D22FFCULL, 0x2E1B21385C26C926ULL, 0x4D2C6DFC5AC42AEDULL, 0x53380D139D95B3DFULL, 0x650A73548BAF63DEULL, 0x766A0ABB3C77B2A8ULL, 0x81C2C92E47EDAEE6ULL, 0x92722C851482353BULL, 0xA2BFE8A14CF10364ULL, 0xA81A664BBC423001ULL, 0xC24B8B70D0F89791ULL, 0xC76C51A30654BE30ULL, 0xD192E819D6EF5218ULL, 0xD69906245565A910ULL, 0xF40E35855771202AULL, 0x106AA07032BBD1B8ULL, 0x19A4C116B8D2D0C8ULL, 0x1E376C085141AB53ULL, 0x2748774CDF8EEB99ULL, 0x34B0BCB5E19B48A8ULL, 0x391C0CB3C5C95A63ULL, 0x4ED8AA4AE3418ACBULL, 0x5B9CCA4F7763E373ULL, 0x682E6FF3D6B2B8A3ULL, 0x748F82EE5DEFB2FCULL, 0x78A5636F43172F60ULL, 0x84C87814A1F0AB72ULL, 0x8CC702081A6439ECULL, 0x90BEFFFA23631E28ULL, 0xA4506CEBDE82BDE9ULL, 0xBEF9A3F7B2C67915ULL, 0xC67178F2E372532BULL, 0xCA273ECEEA26619CULL, 0xD186B8C721C0C207ULL, 0xEADA7DD6CDE0EB1EULL, 0xF57D4F7FEE6ED178ULL, 0x06F067AA72176FBAULL, 0x0A637DC5A2C898A6ULL, 0x113F9804BEF90DAEULL, 0x1B710B35131C471BULL, 0x28DB77F523047D84ULL, 0x32CAAB7B40C72493ULL, 0x3C9EBE0A15C9BEBCULL, 0x431D67C49C100D4CULL, 0x4CC5D4BECB3E42B6ULL, 0x597F299CFC657E2AULL, 0x5FCB6FAB3AD6FAECULL, 0x6C44198C4A475817ULL};
static const uint64_t H512[8] = {0x6A09E667F3BCC908ULL, 0xBB67AE8584CAA73BULL, 0x3C6EF372FE94F82BULL, 0xA54FF53A5F1D36F1ULL, 0x510E527FADE682D1ULL, 0x9B05688C2B3E6C1FULL, 0x1F83D9ABFB41BD6BULL, 0x5BE0CD19137E2179ULL};
static inline uint32_t ror32(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
static inline uint64_t ror64(uint64_t x, int n) { return (x >> n) | (x << (64 - n)); }
static inline uint32_t rol32(uint32_t x, int n) { return (x << n) | (x >> (32 - n)); }
static std::string padmsg(const uint8_t *d, size_t n, size_t block, size_t lenbytes, bool bigendian) {
  std::string m((const char *)d, n); m += (char)0x80;
  while ((m.size() + lenbytes) % block) m += (char)0;
  uint64_t bits = (uint64_t)n * 8;
  for (size_t i = 0; i < lenbytes; i++) { size_t sh = bigendian ? (lenbytes - 1 - i) : i; m += (char)(sh < 8 ? (bits >> (sh * 8)) & 0xff : 0); }
  return m;
}
static void sha256(const uint8_t *d, size_t n, uint8_t *out) {
  uint32_t h[8]; memcpy(h, H256, sizeof h); std::string m = padmsg(d, n, 64, 8, true);
  for (size_t o = 0; o < m.size(); o += 64) {
    uint32_t w[64]; const uint8_t *b = (const uint8_t *)m.data() + o;
    for (int i = 0; i < 16; i++) w[i] = (uint32_t)b[i * 4] << 24 | (uint32_t)b[i * 4 + 1] << 16 | (uint32_t)b[i * 4 + 2] << 8 | b[i * 4 + 3];
    for (int i = 16; i < 64; i++) { uint32_t s0 = ror32(w[i - 15], 7) ^ ror32(w[i - 15], 18) ^ (w[i - 15] >> 3), s1 = ror32(w[i - 2], 17) ^ ror32(w[i - 2], 19) ^ (w[i - 2] >> 10); w[i] = w[i - 16] + s0 + w[i - 7] + s1; }
    uint32_t a = h[0], bb = h[1], c = h[2], dd = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int i = 0; i < 64; i++) {
      uint32_t S1 = ror32(e, 6) ^ ror32(e, 11) ^ ror32(e, 25), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K256[i] + w[i];
      uint32_t S0 = ror32(a, 2) ^ ror32(a, 13) ^ ror32(a, 22), mj = (a & bb) ^ (a & c) ^ (bb & c), t2 = S0 + mj;
      hh = g; g = f; f = e; e = dd + t1; dd = c; c = bb; bb = a; a = t1 + t2;
    }
    h[0] += a; h[1] += bb; h[2] += c; h[3] += dd; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
  }
  for (int i = 0; i < 8; i++) for (int j = 0; j < 4; j++) out[i * 4 + j] = (uint8_t)(h[i] >> (24 - 8 * j));
}
static void sha512(const uint8_t *d, size_t n, uint8_t *out) {
  uint64_t h[8]; memcpy(h, H512, sizeof h); std::string m = padmsg(d, n, 128, 16, true);
  for (size_t o = 0; o < m.size(); o += 128) {
    uint64_t w[80]; const uint8_t *b = (const uint8_t *)m.data() + o;
    for (int i = 0; i < 16; i++) { w[i] = 0; for (int j = 0; j < 8; j++) w[i] = (w[i] << 8) | b[i * 8 + j]; }
    for (int i = 16; i < 80; i++) { uint64_t s0 = ror64(w[i - 15], 1) ^ ror64(w[i - 15], 8) ^ (w[i - 15] >> 7), s1 = ror64(w[i - 2], 19) ^ ror64(w[i - 2], 61) ^ (w[i - 2] >> 6); w[i] = w[i - 16] + s0 + w[i - 7] + s1; }
    uint64_t a = h[0], bb = h[1], c = h[2], dd = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int i = 0; i < 80; i++) {
      uint64_t S1 = ror64(e, 14) ^ ror64(e, 18) ^ ror64(e, 41), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K512[i] + w[i];
      uint64_t S0 = ror64(a, 28) ^ ror64(a, 34) ^ ror64(a, 39), mj = (a & bb) ^ (a & c) ^ (bb & c), t2 = S0 + mj;
      hh = g; g = f; f = e; e = dd + t1; dd = c; c = bb; bb = a; a = t1 + t2;
    }
    h[0] += a; h[1] += bb; h[2] += c; h[3] += dd; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
  }
  for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) out[i * 8 + j] = (uint8_t)(h[i] >> (56 - 8 * j));
}
static void sha1(const uint8_t *d, size_t n, uint8_t *out) {
  uint32_t h[5] = {0x67452301u, 0xEFCDAB89u, 0x98BADCFEu, 0x10325476u, 0xC3D2E1F0u}; std::string m = padmsg(d, n, 64, 8, true);
  for (size_t o = 0; o < m.size(); o += 64) {
    uint32_t w[80]; const uint8_t *b = (const uint8_t *)m.data() + o;
    for (int i = 0; i < 16; i++) w[i] = (uint32_t)b[i * 4] << 24 | (uint32_t)b[i * 4 + 1] << 16 | (uint32_t)b[i * 4 + 2] << 8 | b[i * 4 + 3];
    for (int i = 16; i < 80; i++) w[i] = rol32(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
    uint32_t a = h[0], bb = h[1], c = h[2], dd = h[3], e = h[4];
    for (int i = 0; i < 80; i++) {
      uint32_t f, k;
      if (i < 20) { f = (bb & c) | (~bb & dd); k = 0x5A827999u; } else if (i < 40) { f = bb ^ c ^ dd; k = 0x6ED9EBA1u; }
      else if (i < 60) { f = (bb & c) | (bb & dd) | (c & dd); k = 0x8F1BBCDCu; } else { f = bb ^ c ^ dd; k = 0xCA62C1D6u; }
      uint32_t t = rol32(a, 5) + f + e + k + w[i]; e = dd; dd = c; c = rol32(bb, 30); bb = a; a = t;
    }
    h[0] += a; h[1] += bb; h[2] += c; h[3] += dd; h[4] += e;
  }
  for (int i = 0; i < 5; i++) for (int j = 0; j < 4; j++) out[i * 4 + j] = (uint8_t)(h[i] >> (24 - 8 * j));
}
static void md5(const uint8_t *d, size_t n, uint8_t *out) {
  static const int S[64] = {7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
                            4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21};
  static const std::vector<uint32_t> Kv = [] { std::vector<uint32_t> k(64); for (int i = 0; i < 64; i++) k[(size_t)i] = (uint32_t)(4294967296.0 * fabs(sin((double)(i + 1)))); return k; }();  // magic static = thread-safe
  const uint32_t *K = Kv.data();
  uint32_t a0 = 0x67452301u, b0 = 0xefcdab89u, c0 = 0x98badcfeu, d0 = 0x10325476u; std::string m = padmsg(d, n, 64, 8, false);
  for (size_t o = 0; o < m.size(); o += 64) {
    uint32_t M[16]; const uint8_t *b = (const uint8_t *)m.data() + o;
    for (int i = 0; i < 16; i++) M[i] = (uint32_t)b[i * 4] | (uint32_t)b[i * 4 + 1] << 8 | (uint32_t)b[i * 4 + 2] << 16 | (uint32_t)b[i * 4 + 3] << 24;
    uint32_t A = a0, B = b0, C = c0, D = d0;
    for (int i = 0; i < 64; i++) {
      uint32_t F; int g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = F + A + K[i] + M[g]; A = D; D = C; C = B; B = B + rol32(F, S[i]);
    }
    a0 += A; b0 += B; c0 += C; d0 += D;
  }
  uint32_t r[4] = {a0, b0, c0, d0}; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) out[i * 4 + j] = (uint8_t)(r[i] >> (8 * j));
}
static std::string hexs(const uint8_t *p, size_t n) { static const char *H = "0123456789abcdef"; std::string r; for (size_t i = 0; i < n; i++) { r += H[p[i] >> 4]; r += H[p[i] & 15]; } return r; }
typedef void (*HashFn)(const uint8_t *, size_t, uint8_t *);
static FacStr *hashhex(HashFn f, size_t olen, FacStr *s) { uint8_t o[64]; f((const uint8_t *)sd(s), (size_t)sl(s), o); return mks(hexs(o, olen)); }
static std::string hmac(HashFn f, size_t block, size_t olen, const std::string &key0, const std::string &msg) {
  std::string key = key0; uint8_t tmp[64];
  if (key.size() > block) { f((const uint8_t *)key.data(), key.size(), tmp); key.assign((char *)tmp, olen); }
  key.resize(block, 0);
  std::string ip(block, 0), op(block, 0); for (size_t i = 0; i < block; i++) { ip[i] = (char)(key[i] ^ 0x36); op[i] = (char)(key[i] ^ 0x5c); }
  f((const uint8_t *)(ip + msg).data(), ip.size() + msg.size(), tmp);
  std::string inner((char *)tmp, olen); f((const uint8_t *)(op + inner).data(), op.size() + inner.size(), tmp);
  return std::string((char *)tmp, olen);
}
static uint32_t crc32s(const uint8_t *p, size_t n, uint32_t crc = 0) {
  static const std::vector<uint32_t> Tv = [] { std::vector<uint32_t> t(256); for (uint32_t i = 0; i < 256; i++) { uint32_t c = i; for (int k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1; t[i] = c; } return t; }();
  const uint32_t *T = Tv.data();
  crc = ~crc; for (size_t i = 0; i < n; i++) crc = T[(crc ^ p[i]) & 0xff] ^ (crc >> 8); return ~crc;
}
// Cryptographic bytes must come from the operating system CSPRNG, not from
// std::random_device (whose guarantees vary by standard-library implementation).
static const char *fac_os_random_fill(uint8_t *out, size_t n) {
  if (!n) return nullptr;
#ifdef _WIN32
  struct BCryptApi {
    HMODULE module = nullptr;
    using Fn = LONG (WINAPI *)(void *, unsigned char *, ULONG, ULONG);
    Fn gen = nullptr;
    BCryptApi() {
      // Restrict lookup to System32; an application-local DLL must not be able
      // to shadow the Windows cryptographic provider.
      module = LoadLibraryExW(L"bcrypt.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
      if (module) gen = reinterpret_cast<Fn>(GetProcAddress(module, "BCryptGenRandom"));
    }
  };
  static const BCryptApi api;
  if (!api.gen) return "crypto: operating-system random generator unavailable";
  size_t off = 0;
  while (off < n) {
    ULONG chunk = (ULONG)std::min<size_t>(n - off, (size_t)std::numeric_limits<ULONG>::max());
    // BCRYPT_USE_SYSTEM_PREFERRED_RNG = 0x00000002; no provider handle needed.
    if (api.gen(nullptr, out + off, chunk, 0x00000002u) < 0)
      return "crypto: operating-system random generator failed";
    off += chunk;
  }
#else
  size_t done = 0;
#if defined(__linux__)
  while (done < n) {
    ssize_t got = getrandom(out + done, n - done, 0);
    if (got > 0) { done += (size_t)got; continue; }
    if (got < 0 && errno == EINTR) continue;
    if (got < 0 && errno == ENOSYS) break; // old kernel: fall back to /dev/urandom
    return "crypto: getrandom failed";
  }
  if (done == n) return nullptr;
#elif defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__)
  arc4random_buf(out, n);
  return nullptr;
#endif
  int fd;
  do { fd = open("/dev/urandom", O_RDONLY
#ifdef O_CLOEXEC
                 | O_CLOEXEC
#endif
                 ); } while (fd < 0 && errno == EINTR);
  if (fd < 0) return "crypto: cannot open operating-system random source";
  while (done < n) {
    ssize_t got = read(fd, out + done, n - done);
    if (got > 0) { done += (size_t)got; continue; }
    if (got < 0 && errno == EINTR) continue;
    close(fd);
    return "crypto: operating-system random source failed";
  }
  close(fd);
#endif
  return nullptr;
}
static std::vector<uint8_t> rndbytes(size_t n) {
  std::vector<uint8_t> out(n);
  const char *err = fac_os_random_fill(out.data(), n);
  if (err) {
    std::vector<uint8_t>().swap(out); // do_throw uses longjmp; release storage first.
    do_throw(err, 13);
  }
  return out;
}
static uint64_t fac_crypto_random_u64() {
  // Batch OS entropy per thread: 4 KiB per refill, no heap allocation and no
  // syscall for each randomInt call. Every byte still originates in the OS CSPRNG.
  struct Pool {
    uint64_t values[512]{};
    size_t next = 512;
    ~Pool() {
      volatile uint8_t *p = reinterpret_cast<volatile uint8_t *>(values);
      for (size_t i = 0; i < sizeof values; ++i) p[i] = 0;
    }
  };
  static thread_local Pool pool;
  if (pool.next == 512) {
    const char *err = fac_os_random_fill(reinterpret_cast<uint8_t *>(pool.values), sizeof pool.values);
    if (err) { pool.next = 512; do_throw(err, 13); }
    pool.next = 0;
  }
  return pool.values[pool.next++];
}

extern "C" {
FacStr *fac_crypto_sha256(FacStr *s) { return hashhex(sha256, 32, s); }
FacStr *fac_crypto_sha512(FacStr *s) { return hashhex(sha512, 64, s); }
FacStr *fac_crypto_sha1(FacStr *s) { return hashhex(sha1, 20, s); }
FacStr *fac_crypto_md5(FacStr *s) { return hashhex(md5, 16, s); }
FacStr *fac_crypto_hmac256(FacStr *k, FacStr *m) {
  std::string r = hmac(sha256, 64, 32,
      std::string(sd(k), (size_t)sl(k)), std::string(sd(m), (size_t)sl(m)));
  return mks(hexs((const uint8_t *)r.data(), r.size()));
}
FacStr *fac_crypto_hmac512(FacStr *k, FacStr *m) {
  std::string r = hmac(sha512, 128, 64,
      std::string(sd(k), (size_t)sl(k)), std::string(sd(m), (size_t)sl(m)));
  return mks(hexs((const uint8_t *)r.data(), r.size()));
}
static std::string fac_sha256_file_hex(const char *path, std::string &error) {
  std::unique_ptr<FILE, int (*)(FILE *)> f(fopen(path, "rb"), fclose);
  if (!f) { error = std::string("cannot open file: ") + path; return {}; }
  constexpr size_t MAX_HASH_FILE_BYTES = (size_t)64 << 20;
  std::string all;
  char buf[16384];
  for (;;) {
    const size_t n = fread(buf, 1, sizeof buf, f.get());
    if (n) {
      if (n > MAX_HASH_FILE_BYTES - all.size()) { error = "SHA-256 file exceeds 64 MiB limit"; return {}; }
      try { all.append(buf, n); }
      catch (const std::bad_alloc &) { error = "out of memory hashing file"; return {}; }
    }
    if (n < sizeof buf) {
      if (ferror(f.get())) { error = "cannot read file for SHA-256"; return {}; }
      break;
    }
  }
  uint8_t digest[32];
  sha256((const uint8_t *)all.data(), all.size(), digest);
  return hexs(digest, sizeof digest);
}
FacStr *fac_crypto_sha256file(FacStr *path) {
  std::string error, digest;
  try { digest = fac_sha256_file_hex(sd(path), error); }
  catch (const std::bad_alloc &) { error = "out of memory hashing file"; }
  catch (const std::exception &) { error = "SHA-256 file operation failed"; }
  if (!error.empty()) { std::string().swap(digest); do_throw(std::move(error), 7); }
  return mks(digest);
}
uint32_t fac_crypto_crc32(FacStr *s) {
  return crc32s((const uint8_t *)sd(s), (size_t)sl(s));
}
FacStr *fac_crypto_b64enc(FacStr *s) {
  static const char *T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const uint8_t *p = (const uint8_t *)sd(s); const size_t n = (size_t)sl(s);
  std::string r; r.reserve(((n + 2) / 3) * 4);
  for (size_t i = 0; i < n; i += 3) {
    const uint32_t v = (uint32_t)p[i] << 16 |
        (i + 1 < n ? (uint32_t)p[i + 1] << 8 : 0) |
        (i + 2 < n ? p[i + 2] : 0);
    r += T[v >> 18]; r += T[(v >> 12) & 63];
    r += i + 1 < n ? T[(v >> 6) & 63] : '=';
    r += i + 2 < n ? T[v & 63] : '=';
  }
  return mks(r);
}
FacStr *fac_crypto_b64dec(FacStr *s) {
  std::string r; uint32_t v = 0; int bits = 0;
  for (int64_t i = 0; i < sl(s); i++) {
    const char c = s->data[i]; int d;
    if (c >= 'A' && c <= 'Z') d = c - 'A';
    else if (c >= 'a' && c <= 'z') d = c - 'a' + 26;
    else if (c >= '0' && c <= '9') d = c - '0' + 52;
    else if (c == '+' || c == '-') d = 62;
    else if (c == '/' || c == '_') d = 63;
    else if (c == '=' || isws(c)) continue;
    else do_throw("base64: invalid character", 13);
    v = (v << 6) | (uint32_t)d; bits += 6;
    if (bits >= 8) { bits -= 8; r += (char)((v >> bits) & 0xff); }
  }
  return mks(r);
}
FacStr *fac_crypto_hexenc(FacStr *s) {
  return mks(hexs((const uint8_t *)sd(s), (size_t)sl(s)));
}
FacStr *fac_crypto_hexdec(FacStr *s) {
  if (sl(s) % 2) do_throw("hex: odd length", 13);
  std::string r; r.reserve((size_t)sl(s) / 2);
  for (int64_t i = 0; i < sl(s); i += 2) {
    auto h = [](char c) -> int {
      if (c >= '0' && c <= '9') return c - '0';
      if (c >= 'a' && c <= 'f') return c - 'a' + 10;
      if (c >= 'A' && c <= 'F') return c - 'A' + 10;
      return -1;
    };
    const int hi = h(s->data[i]), lo = h(s->data[i + 1]);
    if (hi < 0 || lo < 0) do_throw("hex: invalid character", 13);
    r += (char)(hi * 16 + lo);
  }
  return mks(r);
}
FacStr *fac_crypto_randhex(int32_t n) { if (n < 0 || n > 1 << 20) do_throw("crypto.randomHex: bad size", 13); auto v = rndbytes((size_t)n); return mks(hexs(v.data(), v.size())); }
FacStr *fac_crypto_randbytes(int32_t n) { if (n < 0 || n > 1 << 20) do_throw("crypto.randomBytes: bad size", 13); auto v = rndbytes((size_t)n); return mk((const char *)v.data(), n); }
int64_t fac_crypto_randint(int64_t lo, int64_t hi) {
  if (hi < lo) std::swap(lo, hi);
  // Unsigned arithmetic represents the entire signed interval without UB,
  // including INT64_MIN..INT64_MAX (whose span is exactly 2^64).
  const uint64_t span = (uint64_t)hi - (uint64_t)lo + UINT64_C(1);
  uint64_t value = 0;
  if (span == 0) {
    value = fac_crypto_random_u64();
  } else {
    // Rejection threshold makes modulo reduction exactly uniform over span.
    const uint64_t threshold = (uint64_t)(0 - span) % span;
    do { value = fac_crypto_random_u64(); } while (value < threshold);
    value = (uint64_t)lo + (value % span);
  }
  int64_t result;
  memcpy(&result, &value, sizeof result); // preserve the two's-complement bit pattern
  return result;
}
FacStr *fac_crypto_uuid() { auto v = rndbytes(16); v[6] = (v[6] & 0x0f) | 0x40; v[8] = (v[8] & 0x3f) | 0x80; std::string h = hexs(v.data(), 16); return mks(h.substr(0, 8) + "-" + h.substr(8, 4) + "-" + h.substr(12, 4) + "-" + h.substr(16, 4) + "-" + h.substr(20)); }
int32_t fac_crypto_consteq(FacStr *a, FacStr *b) { if (sl(a) != sl(b)) return 0; uint8_t d = 0; for (int64_t i = 0; i < sl(a); i++) d |= (uint8_t)(a->data[i] ^ b->data[i]); return d == 0; }
}

// ================================================================ graphic (software canvas; หน้าต่างบน Windows ผ่าน Win32 GDI)
struct Canvas {
  // A live Canvas is a shared mutable resource. Serialize per-handle access;
  // recursive locking is required because public drawing operations delegate
  // to other public drawing primitives.
  mutable std::recursive_mutex stateMutex;
  int w = 0, h = 0; std::vector<uint32_t> px; std::vector<double> depth; std::vector<uint8_t> alpha;   // alpha ว่าง = ทึบทั้งภาพ (มีค่าเมื่อโหลด PNG ที่มี alpha)
  bool closed = false; bool keys[256] = {}; int mx = 0, my = 0; bool mdown = false; int mbuttons = 0;
  std::string textFrame; bool textInputActive = false; uint16_t pendingHighSurrogate = 0;
#ifdef _WIN32
  HWND hwnd = nullptr;
#else
  void *win = nullptr, *ren = nullptr, *tex = nullptr;   // SDL2 (ดู fac_pal_sdl.inc)
#endif
};

struct FacCanvasLock {
  std::unique_lock<std::recursive_mutex> lock;
  explicit FacCanvasLock(Canvas *canvas) {
    if (canvas) lock = std::unique_lock<std::recursive_mutex>(canvas->stateMutex);
  }
};

// Blits read one canvas and mutate another. std::lock acquires both without
// imposing an address/order convention, avoiding A<-B vs B<-A deadlocks.
struct FacCanvasPairLock {
  std::unique_lock<std::recursive_mutex> first;
  std::unique_lock<std::recursive_mutex> second;
  FacCanvasPairLock(Canvas *dst, Canvas *src) {
    if (dst && src && dst != src) {
      first = std::unique_lock<std::recursive_mutex>(dst->stateMutex, std::defer_lock);
      second = std::unique_lock<std::recursive_mutex>(src->stateMutex, std::defer_lock);
      std::lock(first, second);
    } else if (dst) {
      first = std::unique_lock<std::recursive_mutex>(dst->stateMutex);
    } else if (src) {
      first = std::unique_lock<std::recursive_mutex>(src->stateMutex);
    }
  }
};

// Text input is a per-poll UTF-8 snapshot. Bound the queue so a malicious or
// broken event producer cannot grow it without limit between frames.
static constexpr size_t FAC_GFX_TEXT_FRAME_LIMIT = 65536;
static void fac_gfx_append_text(Canvas *c, const char *data, size_t n) {
  if (!c || !data || !n || c->textFrame.size() >= FAC_GFX_TEXT_FRAME_LIMIT) return;
  size_t room = FAC_GFX_TEXT_FRAME_LIMIT - c->textFrame.size();
  if (n > room) {
    n = room;
    // data[n] is the first excluded byte. If it is a continuation byte,
    // back up to exclude the incomplete code point at the truncation edge.
    while (n && (((unsigned char)data[n] & 0xC0u) == 0x80u)) --n;
  }
  c->textFrame.append(data, n);
}
static void fac_gfx_append_codepoint(Canvas *c, uint32_t cp) {
  if (!c || cp < 0x20 || cp == 0x7F || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) return;
  std::string encoded; enc(encoded, cp);
  fac_gfx_append_text(c, encoded.data(), encoded.size());
}
#ifdef _WIN32
static void fac_gfx_append_utf16(Canvas *c, uint16_t unit) {
  if (!c) return;
  if (unit >= 0xD800 && unit <= 0xDBFF) {
    if (c->pendingHighSurrogate) fac_gfx_append_codepoint(c, 0xFFFD);
    c->pendingHighSurrogate = unit;
    return;
  }
  if (unit >= 0xDC00 && unit <= 0xDFFF) {
    if (c->pendingHighSurrogate) {
      uint32_t cp = 0x10000u + (((uint32_t)c->pendingHighSurrogate - 0xD800u) << 10) + ((uint32_t)unit - 0xDC00u);
      c->pendingHighSurrogate = 0;
      fac_gfx_append_codepoint(c, cp);
    } else fac_gfx_append_codepoint(c, 0xFFFD);
    return;
  }
  if (c->pendingHighSurrogate) { c->pendingHighSurrogate = 0; fac_gfx_append_codepoint(c, 0xFFFD); }
  fac_gfx_append_codepoint(c, unit);
}
#endif
static inline void cpx64(Canvas *c, int64_t x, int64_t y, uint32_t col) {
  if (c && x >= 0 && y >= 0 && x < c->w && y < c->h)
    c->px[(size_t)y * (size_t)c->w + (size_t)x] = col & 0xFFFFFF;
}
static inline void cpx(Canvas *c, int x, int y, uint32_t col) { cpx64(c, x, y, col); }
static const struct { char c; const char *b; } GLYPH[] = {
  {'0', "111101101101111"}, {'1', "010110010010111"}, {'2', "111001111100111"}, {'3', "111001111001111"}, {'4', "101101111001001"}, {'5', "111100111001111"},
  {'6', "111100111101111"}, {'7', "111001010010010"}, {'8', "111101111101111"}, {'9', "111101111001111"}, {'A', "010101111101101"}, {'B', "110101110101110"},
  {'C', "011100100100011"}, {'D', "110101101101110"}, {'E', "111100110100111"}, {'F', "111100110100100"}, {'G', "011100101101011"}, {'H', "101101111101101"},
  {'I', "111010010010111"}, {'J', "001001001101010"}, {'K', "101101110101101"}, {'L', "100100100100111"}, {'M', "101111111101101"}, {'N', "110101101101101"},
  {'O', "010101101101010"}, {'P', "110101110100100"}, {'Q', "010101101110011"}, {'R', "110101110101101"}, {'S', "011100010001110"}, {'T', "111010010010010"},
  {'U', "101101101101111"}, {'V', "101101101101010"}, {'W', "101101111111101"}, {'X', "101101010101101"}, {'Y', "101101010010010"}, {'Z', "111001010100111"},
  {'.', "000000000000010"}, {',', "000000000010100"}, {':', "000010000010000"}, {'-', "000000111000000"}, {'+', "000010111010000"}, {'=', "000111000111000"},
  {'!', "010010010000010"}, {'?', "111001010000010"}, {'/', "001001010100100"}, {'(', "010100100100010"}, {')', "010001001001010"}, {'%', "101001010100101"},
  {'_', "000000000000111"}, {'*', "000101010101000"}, {'#', "101111101111101"}, {'<', "001010100010001"}, {'>', "100010001010100"}, {' ', "000000000000000"}};
extern "C++" {
#include "fac_image.inc"
}
extern "C" {
Canvas *fac_gfx_create(int32_t w, int32_t h) {
  if (w <= 0 || h <= 0 || (uint64_t)(uint32_t)w * (uint64_t)(uint32_t)h > FAC_GFX_MAX_PIXELS) do_throw("graphic.create: bad size (maximum 16M pixels)", 14);
  Canvas *c = new (std::nothrow) Canvas; bool ok = c != nullptr;
  if (ok) { c->w = w; c->h = h; try { c->px.assign((size_t)w * (size_t)h, 0); c->depth.assign((size_t)w * (size_t)h, std::numeric_limits<double>::infinity()); } catch (std::bad_alloc &) { ok = false; delete c; c = nullptr; } }
  if (!ok) do_throw("out of memory", 5);
  return c;
}
int32_t fac_gfx_width(Canvas *c) { FacCanvasLock lock(c); return c ? c->w : 0; }
int32_t fac_gfx_height(Canvas *c) { FacCanvasLock lock(c); return c ? c->h : 0; }
uint32_t fac_gfx_rgb(int32_t r, int32_t g, int32_t b) { return ((uint32_t)(r & 255) << 16) | ((uint32_t)(g & 255) << 8) | (uint32_t)(b & 255); }
void fac_gfx_clear(Canvas *c, int32_t col) { FacCanvasLock lock(c); if (c) std::fill(c->px.begin(), c->px.end(), (uint32_t)col & 0xFFFFFF); }
void fac_gfx_pixel(Canvas *c, int32_t x, int32_t y, int32_t col) { FacCanvasLock lock(c); cpx(c, x, y, (uint32_t)col); }
uint32_t fac_gfx_get(Canvas *c, int32_t x, int32_t y) { FacCanvasLock lock(c); return c && (unsigned)x < (unsigned)c->w && (unsigned)y < (unsigned)c->h ? c->px[(size_t)y * (size_t)c->w + (size_t)x] : 0; }
void fac_gfx_line(Canvas *c, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t col) {
  FacCanvasLock lock(c);
  if (!c) return;
  if ((x0 < 0 && x1 < 0) || (y0 < 0 && y1 < 0) || (x0 >= c->w && x1 >= c->w) || (y0 >= c->h && y1 >= c->h)) return;   // อยู่นอกจอทั้งเส้น
  if (llabs((long long)x1 - x0) > (1 << 28) || llabs((long long)y1 - y0) > (1 << 28)) return;                    // กัน overflow/ลูปยาวมาก
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  while (true) { cpx(c, x0, y0, (uint32_t)col); if (x0 == x1 && y0 == y1) break; int e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
}
void fac_gfx_fillrect(Canvas *c, int32_t x, int32_t y, int32_t w, int32_t h, int32_t col) {
  FacCanvasLock lock(c);
  if (!c || w <= 0 || h <= 0) return;
  int x0 = (int)std::max<int64_t>(x, 0), y0 = (int)std::max<int64_t>(y, 0), x1 = (int)std::min<int64_t>((int64_t)x + w, c->w), y1 = (int)std::min<int64_t>((int64_t)y + h, c->h);   // 64-bit กัน overflow
  for (int j = y0; j < y1; j++) for (int i = x0; i < x1; i++) c->px[(size_t)j * (size_t)c->w + (size_t)i] = (uint32_t)col & 0xFFFFFF;
}
void fac_gfx_rect(Canvas *c, int32_t x, int32_t y, int32_t w, int32_t h, int32_t col) {
  FacCanvasLock lock(c);
  if (!c || w <= 0 || h <= 0) return;
  const int64_t x2 = (int64_t)x + (int64_t)w - 1;
  const int64_t y2 = (int64_t)y + (int64_t)h - 1;
  auto i32 = [](int64_t v) { return (int32_t)std::max<int64_t>(INT32_MIN, std::min<int64_t>(INT32_MAX, v)); };
  fac_gfx_line(c, x, y, i32(x2), y, col); fac_gfx_line(c, x, i32(y2), i32(x2), i32(y2), col);
  fac_gfx_line(c, x, y, x, i32(y2), col); fac_gfx_line(c, i32(x2), y, i32(x2), i32(y2), col);
}
void fac_gfx_circle(Canvas *c, int32_t cx, int32_t cy, int32_t r, int32_t col) {
  FacCanvasLock lock(c);
  if (!c || r < 0 || r > (1 << 20)) return;
  int x = r, y = 0, e = 1 - r;
  auto pixel64 = [&](int64_t px, int64_t py) {
    if (px >= 0 && py >= 0 && px < c->w && py < c->h)
      c->px[(size_t)py * (size_t)c->w + (size_t)px] = (uint32_t)col & 0xFFFFFF;
  };
  while (x >= y) {
    pixel64((int64_t)cx + x, (int64_t)cy + y); pixel64((int64_t)cx + y, (int64_t)cy + x);
    pixel64((int64_t)cx - y, (int64_t)cy + x); pixel64((int64_t)cx - x, (int64_t)cy + y);
    pixel64((int64_t)cx - x, (int64_t)cy - y); pixel64((int64_t)cx - y, (int64_t)cy - x);
    pixel64((int64_t)cx + y, (int64_t)cy - x); pixel64((int64_t)cx + x, (int64_t)cy - y);
    y++; if (e < 0) e += 2 * y + 1; else { x--; e += 2 * (y - x) + 1; }
  }
}
void fac_gfx_fillcircle(Canvas *c, int32_t cx, int32_t cy, int32_t r, int32_t col) {
  FacCanvasLock lock(c);
  if (!c || r < 0 || r > (1 << 20)) return;
  for (int dy = -r; dy <= r; dy++) {
    int64_t dx = (int64_t)sqrt((double)((int64_t)r * r - (int64_t)dy * dy));
    const int64_t left = (int64_t)cx - dx, right = (int64_t)cx + dx;
    const int64_t row = (int64_t)cy + dy;
    if (row < 0 || row >= c->h || right < 0 || left >= c->w) continue;
    const int64_t x0 = std::max<int64_t>(0, left), x1 = std::min<int64_t>((int64_t)c->w - 1, right);
    for (int64_t px = x0; px <= x1; px++) c->px[(size_t)row * (size_t)c->w + (size_t)px] = (uint32_t)col & 0xFFFFFF;
  }
}
void fac_gfx_filltri(Canvas *c, int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t col) {
  FacCanvasLock lock(c);
  if (!c || c->w <= 0 || c->h <= 0) return;
  // Keep the edge products within signed 64-bit range and match the line rasterizer's
  // coordinate-delta guard. This avoids compiler-specific __int128 on Windows Clang.
  constexpr int64_t maxDelta = INT64_C(1) << 28;
  auto tooFar = [](int32_t a, int32_t b) { return std::llabs((int64_t)a - (int64_t)b) > maxDelta; };
  if (tooFar(x0,x1) || tooFar(x1,x2) || tooFar(x2,x0) ||
      tooFar(y0,y1) || tooFar(y1,y2) || tooFar(y2,y0)) return;
  int minx = std::max(0, std::min({x0, x1, x2})), maxx = std::min(c->w - 1, std::max({x0, x1, x2})), miny = std::max(0, std::min({y0, y1, y2})), maxy = std::min(c->h - 1, std::max({y0, y1, y2}));
  auto ed = [](int ax, int ay, int bx, int by, int px, int py) -> int64_t {
    const int64_t dx1 = (int64_t)bx - (int64_t)ax;
    const int64_t dy1 = (int64_t)by - (int64_t)ay;
    const int64_t dx2 = (int64_t)px - (int64_t)ax;
    const int64_t dy2 = (int64_t)py - (int64_t)ay;
    return dx1 * dy2 - dy1 * dx2;
  };
  for (int y = miny; y <= maxy; y++) for (int x = minx; x <= maxx; x++) {
    int64_t a = ed(x0, y0, x1, y1, x, y), b = ed(x1, y1, x2, y2, x, y), d = ed(x2, y2, x0, y0, x, y);
    if ((a >= 0 && b >= 0 && d >= 0) || (a <= 0 && b <= 0 && d <= 0)) cpx(c, x, y, (uint32_t)col);
  }
}
void fac_gfx_bitmap_text(Canvas *c, int32_t x, int32_t y, FacStr *s, int32_t col, int32_t scale) {
  if (!c || !s || !s->data || s->len <= 0) return;
  if (scale < 1) scale = 1;
  if (scale > 512) do_throw("graphic.text: scale exceeds 512", 14);
  FacCanvasLock lock(c);
  int64_t cx = x, cy = y;
  const char *q = s->data, *end = s->data + s->len;
  uint32_t prev = 0; int riRun = 0; bool first = true;
  while (q < end) {
    int width = 1; uint32_t cp = dec(q, &width);
    bool beginsCluster = first || !fac_grapheme_no_break(prev, cp, riRun);
    if (beginsCluster) {
      if (cp == '\n') { cx = x; cy += 6LL * scale; }
      else {
        char ch = cp <= 0x7F ? (char)cp : 0;
        if (ch >= 'a' && ch <= 'z') ch -= 32;
        const char *bits = nullptr; for (auto &g : GLYPH) if (g.c == ch) { bits = g.b; break; }
        if (bits) for (int r = 0; r < 5; r++) for (int k = 0; k < 3; k++) if (bits[r * 3 + k] == '1') fac_gfx_fillrect(c, (int32_t)std::max<int64_t>(INT32_MIN, std::min<int64_t>(INT32_MAX, cx + (int64_t)k * scale)), (int32_t)std::max<int64_t>(INT32_MIN, std::min<int64_t>(INT32_MAX, cy + (int64_t)r * scale)), scale, scale, col);
        cx += 4LL * scale;
      }
    }
    if (cp >= 0x1F1E6 && cp <= 0x1F1FF) riRun = (prev >= 0x1F1E6 && prev <= 0x1F1FF) ? riRun + 1 : 1;
    else riRun = 0;
    prev = cp; q += std::max(1, width); first = false;
  }
}
static void put32be(std::string &o, uint32_t v) { for (int i = 3; i >= 0; i--) o += (char)(v >> (i * 8)); }
static void pchunk(std::string &o, const char *type, const std::string &data) {
  put32be(o, (uint32_t)data.size()); std::string td = std::string(type, 4) + data; o += td; put32be(o, crc32s((const uint8_t *)td.data(), td.size()));
}
// do_throw ไม่ unwind -> impl คืน false + ข้อความ แล้ว wrapper ปล่อยตัวแปรทั้งหมดก่อนค่อย throw
static bool fac_gfx_save_impl(Canvas *c, FacStr *path, std::string &err, int &code) {
  FacCanvasLock lock(c);
  if (!c) { err = "graphic.save: null canvas"; code = 14; return false; }
  std::string p(sd(path)), out; std::string ext = p.size() >= 4 ? p.substr(p.size() - 4) : ""; for (auto &ch : ext) ch = (char)tolower(ch);
  if (ext == ".ppm") {
    out = "P6\n" + std::to_string(c->w) + " " + std::to_string(c->h) + "\n255\n";
    for (uint32_t v : c->px) { out += (char)(v >> 16); out += (char)(v >> 8); out += (char)v; }
  } else if (ext == ".bmp") {
    uint32_t rowb = ((uint32_t)c->w * 3 + 3) & ~3u, sz = 54 + rowb * (uint32_t)c->h;
    auto le32 = [&](uint32_t v) { for (int i = 0; i < 4; i++) out += (char)(v >> (8 * i)); };
    out += "BM"; le32(sz); le32(0); le32(54); le32(40); le32((uint32_t)c->w); le32((uint32_t)(-c->h)); out += std::string("\x01\x00\x18\x00", 4); le32(0); le32(rowb * (uint32_t)c->h); le32(2835); le32(2835); le32(0); le32(0);
    for (int y = 0; y < c->h; y++) { for (int x = 0; x < c->w; x++) { uint32_t v = c->px[(size_t)y * (size_t)c->w + (size_t)x]; out += (char)v; out += (char)(v >> 8); out += (char)(v >> 16); } for (uint32_t k = (uint32_t)c->w * 3; k < rowb; k++) out += (char)0; }
  } else if (ext == ".png") {  // PNG แบบ zlib stored (ไม่บีบอัด) เปิดได้ทุกโปรแกรม; ถ้าภาพมี alpha เขียนเป็น RGBA
    bool al = !c->alpha.empty(); size_t bpx = al ? 4 : 3;
    std::string raw; raw.reserve((size_t)c->h * ((size_t)c->w * bpx + 1));
    for (int y = 0; y < c->h; y++) { raw += (char)0; for (int x = 0; x < c->w; x++) { size_t k = (size_t)y * (size_t)c->w + (size_t)x; uint32_t v = c->px[k]; raw += (char)(v >> 16); raw += (char)(v >> 8); raw += (char)v; if (al) raw += (char)c->alpha[k]; } }
    std::string z = "\x78\x01"; size_t pos = 0;
    do { size_t n = std::min<size_t>(65535, raw.size() - pos); bool last = pos + n >= raw.size(); z += (char)(last ? 1 : 0); z += (char)(n & 255); z += (char)(n >> 8); z += (char)(~n & 255); z += (char)((~n >> 8) & 255); z.append(raw, pos, n); pos += n; } while (pos < raw.size());
    uint32_t a = 1, b = 0; for (unsigned char ch : raw) { a = (a + ch) % 65521; b = (b + a) % 65521; } put32be(z, (b << 16) | a);
    out = std::string("\x89PNG\r\n\x1a\n", 8); std::string ihdr; put32be(ihdr, (uint32_t)c->w); put32be(ihdr, (uint32_t)c->h); ihdr += std::string(al ? "\x08\x06\x00\x00\x00" : "\x08\x02\x00\x00\x00", 5);
    pchunk(out, "IHDR", ihdr); pchunk(out, "IDAT", z); pchunk(out, "IEND", "");
  } else { err = "graphic.save: ใช้นามสกุล .png .bmp หรือ .ppm"; code = 14; return false; }
  FILE *f = fopen(p.c_str(), "wb"); if (!f) { err = "cannot write file: " + p; code = 7; return false; }
  const bool wrote = fac_file_write_bytes(f, out.data(), out.size());
  const bool flushed = fflush(f) == 0;
  const int closed = fclose(f);
  if (!wrote || !flushed || closed != 0) { err = "graphic.save: write failed"; code = 7; return false; }
  return true;
}
void fac_gfx_save(Canvas *c, FacStr *path) { std::string err; int code = 14; if (!fac_gfx_save_impl(c, path, err, code)) do_throw(std::move(err), code); }
#ifndef _WIN32
static void fac_pal_close(Canvas *c);
#endif
void fac_gfx_free(Canvas *c) {
  if (!c) return;
  {
    FacCanvasLock lock(c);
#ifdef _WIN32
    if (c->hwnd) DestroyWindow(c->hwnd);
#else
    fac_pal_close(c);
#endif
  }
  // Callers must prevent new uses of this raw handle before free begins.
  delete c;
}
#ifdef _WIN32
static LRESULT CALLBACK facWndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  Canvas *c = (Canvas *)GetWindowLongPtrA(h, GWLP_USERDATA);
  FacCanvasLock lock(c);
  switch (m) {
    case WM_CLOSE: if (c) c->closed = true; return 0;
    case WM_KEYDOWN: if (c && w < 256) c->keys[w] = true; break;
    case WM_KEYUP: if (c && w < 256) c->keys[w] = false; break;
    case WM_CHAR: if (c && c->textInputActive) fac_gfx_append_utf16(c, (uint16_t)w); return 0;
    case WM_IME_CHAR: if (c && c->textInputActive) { fac_gfx_append_utf16(c, (uint16_t)w); return 0; } break;
    case WM_MOUSEMOVE: if (c) { c->mx = (short)LOWORD(l); c->my = (short)HIWORD(l); } break;
    case WM_LBUTTONDOWN: if (c) { c->mdown = true; c->mbuttons |= 1; } break;
    case WM_LBUTTONUP: if (c) { c->mdown = false; c->mbuttons &= ~1; } break;
    case WM_RBUTTONDOWN: if (c) c->mbuttons |= 2; break;
    case WM_RBUTTONUP: if (c) c->mbuttons &= ~2; break;
    case WM_MBUTTONDOWN: if (c) c->mbuttons |= 4; break;
    case WM_MBUTTONUP: if (c) c->mbuttons &= ~4; break;
  }
  return DefWindowProcA(h, m, w, l);
}
Canvas *fac_gfx_open(int32_t w, int32_t h, FacStr *title) {
  Canvas *c = fac_gfx_create(w, h);
  static bool reg = false;
  if (!reg) { WNDCLASSA wc = {}; wc.lpfnWndProc = facWndProc; wc.hInstance = GetModuleHandleA(nullptr); wc.hCursor = LoadCursorA(nullptr, IDC_ARROW); wc.lpszClassName = "FacWindow"; RegisterClassA(&wc); reg = true; }
  DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX; RECT r = {0, 0, w, h}; AdjustWindowRect(&r, style, FALSE);
  c->hwnd = CreateWindowExA(0, "FacWindow", sd(title), style | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, nullptr, nullptr, GetModuleHandleA(nullptr), nullptr);
  if (!c->hwnd) { delete c; do_throw("graphic.open: cannot create window", 14); }
  SetWindowLongPtrA(c->hwnd, GWLP_USERDATA, (LONG_PTR)c);
  return c;
}
int32_t fac_gfx_poll(Canvas *c) { FacCanvasLock lock(c); if (!c) return 0; c->textFrame.clear(); MSG m; while (PeekMessageA(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageA(&m); } if (c->pendingHighSurrogate) { c->pendingHighSurrogate = 0; fac_gfx_append_codepoint(c, 0xFFFD); } return !c->closed; }
void fac_gfx_present(Canvas *c) {
  FacCanvasLock lock(c);
  if (!c || !c->hwnd) return; HDC dc = GetDC(c->hwnd); BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth = c->w; bi.bmiHeader.biHeight = -c->h;
  bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
  StretchDIBits(dc, 0, 0, c->w, c->h, 0, 0, c->w, c->h, c->px.data(), &bi, DIB_RGB_COLORS, SRCCOPY); ReleaseDC(c->hwnd, dc);
}
#else
#include "fac_pal_sdl.inc"
#endif
int32_t fac_gfx_key(Canvas *c, FacStr *name) {
  FacCanvasLock lock(c);
  if (!c) return 0;
  std::string n = sd(name); for (auto &ch : n) ch = (char)tolower(ch); int vk = -1;
  // รหัสภายในใช้เลขแบบ Windows VK ทุก OS (PAL แปลง SDL keycode มาเป็นเลขชุดนี้) -> ชื่อคีย์ทำงานเหมือนกันทุกแพลตฟอร์ม
  if (n == "left") vk = 0x25; else if (n == "right") vk = 0x27; else if (n == "up") vk = 0x26; else if (n == "down") vk = 0x28;
  else if (n == "space") vk = 0x20; else if (n == "esc") vk = 0x1B; else if (n == "enter") vk = 0x0D; else if (n == "shift") vk = 0x10; else if (n == "ctrl") vk = 0x11;
  else if (n == "tab") vk = 0x09; else if (n == "backspace") vk = 0x08;
  else if (n == "home") vk = 0x24; else if (n == "end") vk = 0x23; else if (n == "delete") vk = 0x2E;
  if (vk < 0 && n.size() == 1) vk = toupper((unsigned char)n[0]);
  return vk >= 0 && vk < 256 && c->keys[vk];
}
int32_t fac_gfx_mousex(Canvas *c) { FacCanvasLock lock(c); return c ? c->mx : 0; }
int32_t fac_gfx_mousey(Canvas *c) { FacCanvasLock lock(c); return c ? c->my : 0; }
int32_t fac_gfx_mousedown(Canvas *c) { FacCanvasLock lock(c); return c ? c->mdown : 0; }
void fac_gfx_start_text_input(Canvas *c) {
  FacCanvasLock lock(c);
  if (!c) return;
  c->textInputActive = true;
#ifdef _WIN32
  if (c->hwnd) SetFocus(c->hwnd);
#else
  if (c->win && pal::g.StartTextInput) { std::lock_guard<std::mutex> state(pal::video_mu); pal::g.StartTextInput(); }
#endif
}
void fac_gfx_stop_text_input(Canvas *c) {
  FacCanvasLock lock(c);
  if (!c) return;
  c->textInputActive = false; c->pendingHighSurrogate = 0;
#ifdef _WIN32
  // No global Win32 text-input mode to stop.
#else
  if (c->win && pal::g.StopTextInput) { std::lock_guard<std::mutex> state(pal::video_mu); pal::g.StopTextInput(); }
#endif
}
FacStr *fac_gfx_text_input(Canvas *c) { FacCanvasLock lock(c); return mks(c ? c->textFrame : std::string()); }
FacStr *fac_gfx_clipboard_get(Canvas *c) {
  FacCanvasLock lock(c);
  if (!c) return mks("");
#ifdef _WIN32
  if (!OpenClipboard(c->hwnd)) return mks("");
  HANDLE h = GetClipboardData(CF_UNICODETEXT);
  if (!h) { CloseClipboard(); return mks(""); }
  const wchar_t *wide = (const wchar_t *)GlobalLock(h);
  if (!wide) { CloseClipboard(); return mks(""); }
  int chars = (int)wcsnlen(wide, 1 << 20);
  int bytes = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, wide, chars, nullptr, 0, nullptr, nullptr);
  std::string out;
  if (bytes > 0 && bytes <= (1 << 22)) { out.resize((size_t)bytes); WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, wide, chars, out.data(), bytes, nullptr, nullptr); }
  GlobalUnlock(h); CloseClipboard(); return mks(out);
#else
  std::lock_guard<std::mutex> state(pal::video_mu);
  if (!c->win || !pal::g.GetClipboardText || !pal::g.FreeClipboardText) return mks("");
  char *p = pal::g.GetClipboardText(); if (!p) return mks("");
  std::string out(p); pal::g.FreeClipboardText(p); if (out.size() > (1u << 22)) out.resize(1u << 22);
  return mks(out);
#endif
}
int32_t fac_gfx_clipboard_set(Canvas *c, FacStr *value) {
  FacCanvasLock lock(c);
  if (!c || !value || sl(value) > (1 << 22)) return 0;
#ifdef _WIN32
  if (!c->hwnd || !OpenClipboard(c->hwnd)) return 0;
  int bytes = (int)sl(value);
  int chars = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, value->data, bytes, nullptr, 0);
  if ((bytes > 0 && chars == 0) || chars > (1 << 20)) { CloseClipboard(); return 0; }
  HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, (size_t)(chars + 1) * sizeof(wchar_t));
  if (!mem) { CloseClipboard(); return 0; }
  wchar_t *dst = (wchar_t *)GlobalLock(mem);
  if (!dst) { GlobalFree(mem); CloseClipboard(); return 0; }
  if (chars) MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, value->data, bytes, dst, chars);
  dst[chars] = 0; GlobalUnlock(mem);
  if (!EmptyClipboard() || !SetClipboardData(CF_UNICODETEXT, mem)) { GlobalFree(mem); CloseClipboard(); return 0; }
  CloseClipboard(); return 1;
#else
  std::lock_guard<std::mutex> state(pal::video_mu);
  if (!c->win || !pal::g.SetClipboardText) return 0;
  return pal::g.SetClipboardText(sd(value)) == 0;
#endif
}
}

// ================================================================ three: minimal perspective 3D rasterizer (software reference backend)
struct FacCamera3D { double x=0, y=0, z=0, yaw=0, pitch=0, fov=70; };
struct FacV3 { double x, y, z; };
struct FacPV { double x, y, z; bool ok; };
static FacPV fac3_view(const FacCamera3D *c, double x, double y, double z) {
  if (!c) return {0,0,0,false};
  double dx=x-c->x, dy=y-c->y, dz=z-c->z;
  double cy=cos(c->yaw), sy=sin(c->yaw), cp=cos(c->pitch), sp=sin(c->pitch);
  double vx=dx*cy-dz*sy, vz=dx*sy+dz*cy;
  double vy=dy*cp-vz*sp; vz=dy*sp+vz*cp;
  return {vx,vy,vz, std::isfinite(vx)&&std::isfinite(vy)&&std::isfinite(vz)&&vz>0.05};
}
static FacPV fac3_project(const Canvas *cv, const FacCamera3D *c, double x, double y, double z) {
  FacPV v=fac3_view(c,x,y,z); if (!cv || !v.ok) return {0,0,v.z,false};
  double f=(std::min(cv->w,cv->h)*0.5)/tan(std::max(1.0,std::min(179.0,c->fov))*3.14159265358979323846/360.0);
  double sx=cv->w*0.5+v.x*f/v.z, sy=cv->h*0.5-v.y*f/v.z;
  if (!std::isfinite(sx)||!std::isfinite(sy)) return {0,0,v.z,false};
  return {sx,sy,v.z,true};
}
static void fac3_raster(Canvas *c, FacPV a, FacPV b, FacPV d, uint32_t col) {
  if (!c || !a.ok || !b.ok || !d.ok) return;
  double area=(b.x-a.x)*(d.y-a.y)-(b.y-a.y)*(d.x-a.x);
  if (!std::isfinite(area)||fabs(area)<1e-9) return;
  double minx=std::min({a.x,b.x,d.x}), maxx=std::max({a.x,b.x,d.x});
  double miny=std::min({a.y,b.y,d.y}), maxy=std::max({a.y,b.y,d.y});
  if (maxx<0 || maxy<0 || minx>=c->w || miny>=c->h) return;
  // Clamp in floating point before integer conversion to avoid overflow for distant vertices.
  int x0=(int)floor(std::max(0.0,minx)), x1=(int)ceil(std::min((double)c->w-1,maxx));
  int y0=(int)floor(std::max(0.0,miny)), y1=(int)ceil(std::min((double)c->h-1,maxy));
  if (x0>x1||y0>y1) return;
  double ia=1.0/a.z, ib=1.0/b.z, id=1.0/d.z;
  for (int y=y0;y<=y1;y++) for (int x=x0;x<=x1;x++) {
    double px=x+0.5, py=y+0.5;
    double wa=((b.x-px)*(d.y-py)-(b.y-py)*(d.x-px))/area;
    double wb=((d.x-px)*(a.y-py)-(d.y-py)*(a.x-px))/area;
    double wd=1.0-wa-wb;
    if (wa < -1e-9 || wb < -1e-9 || wd < -1e-9) continue;
    double iz=wa*ia+wb*ib+wd*id; if (iz<=0) continue; double zz=1.0/iz;
    size_t idx=(size_t)y*c->w+x;
    if (zz < c->depth[idx]) { c->depth[idx]=zz; c->px[idx]=col&0xFFFFFF; }
  }
}
extern "C" {
FacCamera3D *fac_3d_camera(double x,double y,double z,double yaw,double pitch,double fov) {
  if (!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)||!std::isfinite(yaw)||!std::isfinite(pitch)||!std::isfinite(fov)||fov<1||fov>179)
    do_throw("three.camera: invalid camera values or fov outside 1..179", 14);
  auto *c=new FacCamera3D; c->x=x;c->y=y;c->z=z;c->yaw=yaw;c->pitch=pitch;c->fov=fov;return c;
}
void fac_3d_free(FacCamera3D *c) { delete c; }
void fac_3d_begin(Canvas *c, FacCamera3D *) { FacCanvasLock lock(c); if(c) std::fill(c->depth.begin(),c->depth.end(),std::numeric_limits<double>::infinity()); }
int32_t fac_3d_projectx(Canvas *c,FacCamera3D *cam,double x,double y,double z) { FacCanvasLock lock(c); auto p=fac3_project(c,cam,x,y,z);return p.ok?(int32_t)std::llround(p.x):INT32_MIN; }
int32_t fac_3d_projecty(Canvas *c,FacCamera3D *cam,double x,double y,double z) { FacCanvasLock lock(c); auto p=fac3_project(c,cam,x,y,z);return p.ok?(int32_t)std::llround(p.y):INT32_MIN; }
double fac_3d_projectdepth(Canvas *,FacCamera3D *cam,double x,double y,double z) { auto p=fac3_view(cam,x,y,z);return p.ok?p.z:-1.0; }
void fac_3d_point(Canvas *c,FacCamera3D *cam,double x,double y,double z,int32_t color,int32_t size) {
  FacCanvasLock lock(c);
  auto p=fac3_project(c,cam,x,y,z);if(!p.ok||!c)return; size=std::max(1,std::min(size,128)); int r=size/2;
  int cx=(int)llround(p.x),cy=(int)llround(p.y);
  for(int yy=-r;yy<=r;yy++)for(int xx=-r;xx<=r;xx++){int sx=cx+xx,sy=cy+yy;if((unsigned)sx<(unsigned)c->w&&(unsigned)sy<(unsigned)c->h){size_t k=(size_t)sy*c->w+sx;if(p.z<c->depth[k]){c->depth[k]=p.z;c->px[k]=(uint32_t)color&0xFFFFFF;}}}
}
void fac_3d_line(Canvas *c,FacCamera3D *cam,double x0,double y0,double z0,double x1,double y1,double z1,int32_t color) {
  FacCanvasLock lock(c);
  auto a=fac3_project(c,cam,x0,y0,z0),b=fac3_project(c,cam,x1,y1,z1);if(!a.ok||!b.ok||!c)return;
  int ax=(int)llround(a.x),ay=(int)llround(a.y),bx=(int)llround(b.x),by=(int)llround(b.y);
  int dx=abs(bx-ax),sx=ax<bx?1:-1,dy=-abs(by-ay),sy=ay<by?1:-1,err=dx+dy,steps=std::max(dx,-dy),i=0;
  for(;;){if((unsigned)ax<(unsigned)c->w&&(unsigned)ay<(unsigned)c->h){double t=steps?double(i)/steps:0,zz=1.0/((1-t)/a.z+t/b.z);size_t k=(size_t)ay*c->w+ax;if(zz<c->depth[k]){c->depth[k]=zz;c->px[k]=(uint32_t)color&0xFFFFFF;}}if(ax==bx&&ay==by)break;int e=2*err;if(e>=dy){err+=dy;ax+=sx;}if(e<=dx){err+=dx;ay+=sy;}i++;}
}
void fac_3d_triangle(Canvas *c,FacCamera3D *cam,double x1,double y1,double z1,double x2,double y2,double z2,double x3,double y3,double z3,int32_t color) {
  FacCanvasLock lock(c);
  fac3_raster(c,fac3_project(c,cam,x1,y1,z1),fac3_project(c,cam,x2,y2,z2),fac3_project(c,cam,x3,y3,z3),(uint32_t)color);
}
void fac_3d_cube(Canvas *c,FacCamera3D *cam,double x,double y,double z,double size,int32_t color) {
  FacCanvasLock lock(c);
  if(size<=0||!std::isfinite(size))return; double h=size*0.5;
  FacV3 v[8]={{x-h,y-h,z-h},{x+h,y-h,z-h},{x+h,y+h,z-h},{x-h,y+h,z-h},{x-h,y-h,z+h},{x+h,y-h,z+h},{x+h,y+h,z+h},{x-h,y+h,z+h}};
  // Two triangles per face. Fixed face shading keeps the first renderer useful without a light/material system.
  static const int f[12][3]={{0,2,1},{0,3,2},{4,5,6},{4,6,7},{0,1,5},{0,5,4},{3,7,6},{3,6,2},{0,4,7},{0,7,3},{1,2,6},{1,6,5}};
  static const double shade[6]={0.55,1.0,0.62,0.90,0.75,0.68};
  for(int i=0;i<12;i++){double k=shade[i/2];uint32_t col=(uint32_t)color;int r=(int)(((col>>16)&255)*k),g=(int)(((col>>8)&255)*k),b=(int)((col&255)*k);uint32_t fc=((uint32_t)std::min(255,r)<<16)|((uint32_t)std::min(255,g)<<8)|(uint32_t)std::min(255,b);auto&t=f[i];fac3_raster(c,fac3_project(c,cam,v[t[0]].x,v[t[0]].y,v[t[0]].z),fac3_project(c,cam,v[t[1]].x,v[t[1]].y,v[t[1]].z),fac3_project(c,cam,v[t[2]].x,v[t[2]].y,v[t[2]].z),fc);}
}
void fac_3d_sphere(Canvas *c,FacCamera3D *cam,double x,double y,double z,double radius,int32_t color) {
  if(!(radius>0.0)||!std::isfinite(radius))do_throw("three.sphere: radius must be positive and finite",14);
  FacCanvasLock lock(c);
  constexpr int slices=16, stacks=10; constexpr double pi=3.14159265358979323846;
  FacV3 ring[stacks+1][slices+1];
  for(int a=0;a<=stacks;a++){double phi=-pi*0.5+pi*(double)a/stacks,cp=std::cos(phi),sp=std::sin(phi);for(int b=0;b<=slices;b++){double theta=2.0*pi*(double)b/slices;ring[a][b]={x+radius*cp*std::cos(theta),y+radius*sp,z+radius*cp*std::sin(theta)};}}
  for(int a=0;a<stacks;a++)for(int b=0;b<slices;b++){FacV3 p0=ring[a][b],p1=ring[a+1][b],p2=ring[a+1][b+1],p3=ring[a][b+1];fac3_raster(c,fac3_project(c,cam,p0.x,p0.y,p0.z),fac3_project(c,cam,p1.x,p1.y,p1.z),fac3_project(c,cam,p2.x,p2.y,p2.z),(uint32_t)color);fac3_raster(c,fac3_project(c,cam,p0.x,p0.y,p0.z),fac3_project(c,cam,p2.x,p2.y,p2.z),fac3_project(c,cam,p3.x,p3.y,p3.z),(uint32_t)color);}
}
void fac_3d_plane(Canvas *c,FacCamera3D *cam,double x,double y,double z,double size,int32_t color) {
  if(!(size>0.0)||!std::isfinite(size))do_throw("three.plane: size must be positive and finite",14);
  FacCanvasLock lock(c);
  double h=size*0.5;
  FacPV a=fac3_project(c,cam,x-h,y-h,z),b=fac3_project(c,cam,x+h,y-h,z),d=fac3_project(c,cam,x+h,y+h,z),e=fac3_project(c,cam,x-h,y+h,z);
  fac3_raster(c,a,b,d,(uint32_t)color);fac3_raster(c,a,d,e,(uint32_t)color);
}
void fac_3d_grid(Canvas *c,FacCamera3D *cam,double x,double y,double z,double extent,int32_t divisions,int32_t color) {
  if(!(extent>0.0)||!std::isfinite(extent)||divisions<1||divisions>256)do_throw("three.grid: extent must be positive and divisions must be 1..256",14);
  FacCanvasLock lock(c);
  for(int32_t i=0;i<=divisions;i++){double t=-extent+2.0*extent*(double)i/divisions;fac_3d_line(c,cam,x-extent,y,z+t,x+extent,y,z+t,color);fac_3d_line(c,cam,x+t,y,z-extent,x+t,y,z+extent,color);}
}
void fac_3d_move_camera(FacCamera3D *cam,double dx,double dy,double dz) { if(!cam)do_throw("three.moveCamera: null camera",6);double x=cam->x+dx,y=cam->y+dy,z=cam->z+dz;if(!std::isfinite(dx)||!std::isfinite(dy)||!std::isfinite(dz)||!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z))do_throw("three.moveCamera: invalid movement",14);cam->x=x;cam->y=y;cam->z=z; }
void fac_3d_rotate_camera(FacCamera3D *cam,double yaw_delta,double pitch_delta) { if(!cam)do_throw("three.rotateCamera: null camera",6);double yaw=cam->yaw+yaw_delta,pitch=cam->pitch+pitch_delta;if(!std::isfinite(yaw_delta)||!std::isfinite(pitch_delta)||!std::isfinite(yaw)||!std::isfinite(pitch))do_throw("three.rotateCamera: invalid rotation",14);cam->yaw=yaw;cam->pitch=std::max(-1.5533430342749532,std::min(1.5533430342749532,pitch)); }
void fac_3d_set_fov(FacCamera3D *cam,double fov) { if(!cam)do_throw("three.setFov: null camera",6);if(!std::isfinite(fov)||fov<1.0||fov>179.0)do_throw("three.setFov: fov must be in 1..179 degrees",14);cam->fov=fov; }
}

// ================================================================ CPU float64 buffers and SIMD-friendly numeric kernels
// The historical gpu.* namespace is retained for source compatibility, but this
// build is deliberately CPU-only: it does not load or depend on any device runtime.
struct FacGpuBuffer { std::vector<uint8_t> bytes; };



extern "C" {
FacStr *fac_gpu_backend(){return mks("software-reference");}
int32_t fac_gpu_hardware(){return 0;}
FacGpuBuffer *fac_gpu_buffer_create(int64_t n){if(n<0||n>(int64_t)268435456)do_throw("gpu.bufferCreate: size must be 0..256 MiB",14);FacGpuBuffer*b=nullptr;try{b=new(std::nothrow) FacGpuBuffer;if(!b)do_throw("gpu.bufferCreate: out of memory",5);b->bytes.resize((size_t)n);}catch(const std::bad_alloc&){delete b;do_throw("gpu.bufferCreate: out of memory",5);}catch(const std::length_error&){delete b;do_throw("gpu.bufferCreate: requested size is not representable",14);}return b;}
void fac_gpu_buffer_free(FacGpuBuffer*b){delete b;}
int64_t fac_gpu_buffer_size(FacGpuBuffer*b){return b?(int64_t)b->bytes.size():0;}
int32_t fac_gpu_buffer_write(FacGpuBuffer*b,int64_t off,FacStr*s){if(!b||!s||off<0||off>(int64_t)b->bytes.size()||sl(s)>(int64_t)b->bytes.size()-off)return 0;if(sl(s))memcpy(b->bytes.data()+off,sd(s),(size_t)sl(s));return 1;}
FacStr *fac_gpu_buffer_read(FacGpuBuffer*b,int64_t off,int64_t n){if(!b||off<0||n<0||off>(int64_t)b->bytes.size()||n>(int64_t)b->bytes.size()-off)do_throw("gpu.bufferRead: range out of bounds",14);return mk(n ? (const char*)b->bytes.data()+off : "",n);}
int32_t fac_gpu_buffer_copy(FacGpuBuffer*d,int64_t doff,FacGpuBuffer*s,int64_t soff,int64_t n){if(!d||!s||doff<0||soff<0||n<0||doff>(int64_t)d->bytes.size()||soff>(int64_t)s->bytes.size()||n>(int64_t)d->bytes.size()-doff||n>(int64_t)s->bytes.size()-soff)return 0;if(n)memmove(d->bytes.data()+doff,s->bytes.data()+soff,(size_t)n);return 1;}

// Cross-platform float64 compute dispatch. V100 currently executes this API on the
// software/reference CPU backend; buffers encode IEEE-754 binary64 in little-endian order.
static bool fac_gpu_f64_range(const FacGpuBuffer*b,uint64_t count){return b&&count<=16777216u&&count<=UINT64_MAX/8u&&(uint64_t)b->bytes.size()>=count*8u;}
static double fac_gpu_load_f64(const FacGpuBuffer*b,uint64_t i){uint64_t bits=0;size_t off=(size_t)i*8u;for(unsigned k=0;k<8;k++)bits|=(uint64_t)b->bytes[off+k]<<(k*8);double v;memcpy(&v,&bits,sizeof(v));return v;}
static void fac_gpu_store_f64(FacGpuBuffer*b,uint64_t i,double v){uint64_t bits=0;memcpy(&bits,&v,sizeof(bits));size_t off=(size_t)i*8u;for(unsigned k=0;k<8;k++)b->bytes[off+k]=(uint8_t)(bits>>(k*8));}
FacStr *fac_gpu_backend_capabilities(){
  return mks("buffer,f64-add,f64-sub,f64-mul,f64-scale,f64-matmul;software-reference;no-hardware-acceleration");
}
// Compatibility shim for programs built against V167-V169. No device probing
// is performed in the CPU-only backend.
FacStr *fac_gpu_opencl_status(){return mks("disabled");}
// The reference backend keeps the wire/storage format explicitly little-endian.
// On hosts with IEEE-754 binary64 and little-endian byte order, copy bounded
// contiguous blocks into real double objects before arithmetic.  This avoids
// byte-at-a-time decode/encode in the hot loop and gives Clang/GCC's loop
// vectorizers a simple, alias-free input/output loop.  Big-endian or unusual
// floating-point hosts retain the fully portable scalar decoder below.
static bool fac_gpu_native_f64_blocks() {
  const uint16_t one = 1;
  return sizeof(double) == 8 && std::numeric_limits<double>::is_iec559 &&
         *reinterpret_cast<const uint8_t *>(&one) == 1;
}
static constexpr size_t FAC_GPU_SIMD_BLOCK = 512;
static void fac_gpu_copy_f64_block(double *dst, const FacGpuBuffer *src,
                                   uint64_t first, size_t count) {
  if (count) std::memcpy(dst, src->bytes.data() + (size_t)first * 8u, count * 8u);
}
// x86-64 guarantees SSE2 and AArch64 guarantees Advanced SIMD. GCC and Clang
// lower this 128-bit vector extension to the native ISA for those targets. Keep
// a scalar tail and a scalar fallback for other 64-bit architectures/toolchains.
#if (defined(__GNUC__) || defined(__clang__)) && (defined(__x86_64__) || defined(__amd64__) || defined(__aarch64__) || defined(__arm64__))
#define FAC_GPU_HAVE_F64X2 1
typedef double FacGpuF64x2 __attribute__((vector_size(16)));
#else
#define FAC_GPU_HAVE_F64X2 0
#endif
static void fac_gpu_add_f64_block_kernel(double * __restrict out,
                                         const double * __restrict left,
                                         const double * __restrict right,
                                         size_t count) {
  size_t i=0;
#if FAC_GPU_HAVE_F64X2
  for (;i+2<=count;i+=2) {
    FacGpuF64x2 l{},r{};
    std::memcpy(&l,left+i,sizeof(l)); std::memcpy(&r,right+i,sizeof(r));
    const FacGpuF64x2 value=l+r;
    std::memcpy(out+i,&value,sizeof(value));
  }
#endif
  for (;i<count;i++) out[i]=left[i]+right[i];
}
enum FacGpuF64BinaryOp { FAC_GPU_F64_SUB, FAC_GPU_F64_MUL };
static void fac_gpu_binary_f64_block_kernel(double * __restrict out,
                                            const double * __restrict left,
                                            const double * __restrict right,
                                            size_t count, FacGpuF64BinaryOp op) {
  size_t i=0;
#if FAC_GPU_HAVE_F64X2
  for (;i+2<=count;i+=2) {
    FacGpuF64x2 l{},r{},value{};
    std::memcpy(&l,left+i,sizeof(l)); std::memcpy(&r,right+i,sizeof(r));
    value = op == FAC_GPU_F64_SUB ? l-r : l*r;
    std::memcpy(out+i,&value,sizeof(value));
  }
#endif
  for (;i<count;i++) out[i]=op == FAC_GPU_F64_SUB ? left[i]-right[i] : left[i]*right[i];
}
static int32_t fac_gpu_binary_f64(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,
                                  int64_t count,FacGpuF64BinaryOp op) {
  if(count<0||!fac_gpu_f64_range(d,(uint64_t)count)||!fac_gpu_f64_range(a,(uint64_t)count)||!fac_gpu_f64_range(b,(uint64_t)count))return 0;
  try {
    std::vector<double> out((size_t)count);
    if (fac_gpu_native_f64_blocks()) {
      alignas(64) double left[FAC_GPU_SIMD_BLOCK], right[FAC_GPU_SIMD_BLOCK];
      for (uint64_t base=0;base<(uint64_t)count;base+=FAC_GPU_SIMD_BLOCK) {
        const size_t n=(size_t)std::min<uint64_t>(FAC_GPU_SIMD_BLOCK,(uint64_t)count-base);
        fac_gpu_copy_f64_block(left,a,base,n); fac_gpu_copy_f64_block(right,b,base,n);
        fac_gpu_binary_f64_block_kernel(out.data()+(size_t)base,left,right,n,op);
      }
    } else {
      for(uint64_t i=0;i<(uint64_t)count;i++) {
        const double x=fac_gpu_load_f64(a,i), y=fac_gpu_load_f64(b,i);
        out[(size_t)i]=op==FAC_GPU_F64_SUB ? x-y : x*y;
      }
    }
    for(double value:out) if(!std::isfinite(value)) return 0;
    if(count) {
      if(fac_gpu_native_f64_blocks()) std::memcpy(d->bytes.data(),out.data(),(size_t)count*8u);
      else for(uint64_t i=0;i<(uint64_t)count;i++)fac_gpu_store_f64(d,i,out[(size_t)i]);
    }
    return 1;
  } catch(const std::bad_alloc&){return 0;} catch(const std::length_error&){return 0;}
}
static void fac_gpu_scale_f64_block_kernel(double * __restrict out,
                                           const double * __restrict input,
                                           double scale, size_t count) {
  size_t i=0;
#if FAC_GPU_HAVE_F64X2
  const FacGpuF64x2 factor={scale,scale};
  for (;i+2<=count;i+=2) {
    FacGpuF64x2 value{};
    std::memcpy(&value,input+i,sizeof(value));
    value=value*factor;
    std::memcpy(out+i,&value,sizeof(value));
  }
#endif
  for (;i<count;i++) out[i]=input[i]*scale;
}
int32_t fac_gpu_add_f64(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){
  if(count<0||!fac_gpu_f64_range(d,(uint64_t)count)||!fac_gpu_f64_range(a,(uint64_t)count)||!fac_gpu_f64_range(b,(uint64_t)count))return 0;
  try {
    std::vector<double> out((size_t)count);
    if (fac_gpu_native_f64_blocks()) {
      alignas(64) double left[FAC_GPU_SIMD_BLOCK], right[FAC_GPU_SIMD_BLOCK];
      for (uint64_t base=0;base<(uint64_t)count;base+=FAC_GPU_SIMD_BLOCK) {
        const size_t n=(size_t)std::min<uint64_t>(FAC_GPU_SIMD_BLOCK,(uint64_t)count-base);
        fac_gpu_copy_f64_block(left,a,base,n); fac_gpu_copy_f64_block(right,b,base,n);
        fac_gpu_add_f64_block_kernel(out.data()+(size_t)base,left,right,n);
      }
      // Validate the complete result before writing any destination byte. This
      // preserves the API's no-partial-write behavior, including on overflow.
      for(double value:out) if(!std::isfinite(value)) return 0;
      if(count) std::memcpy(d->bytes.data(),out.data(),(size_t)count*8u);
      return 1;
    }
    for(uint64_t i=0;i<(uint64_t)count;i++){out[(size_t)i]=fac_gpu_load_f64(a,i)+fac_gpu_load_f64(b,i);if(!std::isfinite(out[(size_t)i]))return 0;}
    for(uint64_t i=0;i<(uint64_t)count;i++)fac_gpu_store_f64(d,i,out[(size_t)i]);
    return 1;
  } catch(const std::bad_alloc&){return 0;} catch(const std::length_error&){return 0;}
}
int32_t fac_gpu_sub_f64(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){
  return fac_gpu_binary_f64(d,a,b,count,FAC_GPU_F64_SUB);
}
int32_t fac_gpu_mul_f64(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){
  return fac_gpu_binary_f64(d,a,b,count,FAC_GPU_F64_MUL);
}
int32_t fac_gpu_scale_f64(FacGpuBuffer*d,FacGpuBuffer*a,int64_t count,double scale){
  if(!std::isfinite(scale)||count<0||!fac_gpu_f64_range(d,(uint64_t)count)||!fac_gpu_f64_range(a,(uint64_t)count))return 0;
  try {
    std::vector<double> out((size_t)count);
    if (fac_gpu_native_f64_blocks()) {
      alignas(64) double input[FAC_GPU_SIMD_BLOCK];
      for (uint64_t base=0;base<(uint64_t)count;base+=FAC_GPU_SIMD_BLOCK) {
        const size_t n=(size_t)std::min<uint64_t>(FAC_GPU_SIMD_BLOCK,(uint64_t)count-base);
        fac_gpu_copy_f64_block(input,a,base,n);
        fac_gpu_scale_f64_block_kernel(out.data()+(size_t)base,input,scale,n);
      }
      for(double value:out) if(!std::isfinite(value)) return 0;
      if(count) std::memcpy(d->bytes.data(),out.data(),(size_t)count*8u);
      return 1;
    }
    for(uint64_t i=0;i<(uint64_t)count;i++){out[(size_t)i]=fac_gpu_load_f64(a,i)*scale;if(!std::isfinite(out[(size_t)i]))return 0;}
    for(uint64_t i=0;i<(uint64_t)count;i++)fac_gpu_store_f64(d,i,out[(size_t)i]);
    return 1;
  } catch(const std::bad_alloc&){return 0;} catch(const std::length_error&){return 0;}
}
int32_t fac_gpu_write_f64(FacGpuBuffer*b,int64_t index,double value){if(!b||index<0||(uint64_t)index>=(uint64_t)b->bytes.size()/8u||!std::isfinite(value))return 0;fac_gpu_store_f64(b,(uint64_t)index,value);return 1;}
double fac_gpu_read_f64(FacGpuBuffer*b,int64_t index){if(!b||index<0||(uint64_t)index>=(uint64_t)b->bytes.size()/8u)do_throw("gpu.readF64: index out of range",14);return fac_gpu_load_f64(b,(uint64_t)index);}

// Public SIMD bulk API: logical float64 vectors have two lanes. The same
// little-endian GPU-buffer representation is used so callers can interoperate
// with gpu.* without copying or changing the storage ABI.
#if FAC_GPU_HAVE_F64X2
static const char *fac_simd_backend_name() {
#if defined(__x86_64__) || defined(__amd64__)
  return "x86-sse2";
#elif defined(__aarch64__) || defined(__arm64__)
  return "arm-advanced-simd";
#else
  return "compiler-vector-128";
#endif
}
#else
static const char *fac_simd_backend_name() { return "scalar-fallback"; }
#endif
FacStr *fac_simd_backend(){return mks(fac_simd_backend_name());}
int32_t fac_simd_width_f64(){return 2;}
int32_t fac_simd_native_f64x2(){return FAC_GPU_HAVE_F64X2 ? 1 : 0;}

enum FacSimdF64BinaryOp { FAC_SIMD_F64_ADD, FAC_SIMD_F64_SUB, FAC_SIMD_F64_MUL, FAC_SIMD_F64_DIV };
static double fac_simd_f64_apply(double a,double b,FacSimdF64BinaryOp op) {
  switch(op) {
    case FAC_SIMD_F64_ADD: return a+b;
    case FAC_SIMD_F64_SUB: return a-b;
    case FAC_SIMD_F64_MUL: return a*b;
    case FAC_SIMD_F64_DIV: return a/b;
  }
  return std::numeric_limits<double>::quiet_NaN();
}
static void fac_simd_f64_binary_kernel(double * __restrict out,
                                       const double * __restrict left,
                                       const double * __restrict right,
                                       size_t count, FacSimdF64BinaryOp op) {
  size_t i=0;
#if FAC_GPU_HAVE_F64X2
  for (;i+2<=count;i+=2) {
    FacGpuF64x2 a{},b{},value{};
    std::memcpy(&a,left+i,sizeof(a));
    std::memcpy(&b,right+i,sizeof(b));
    switch(op) {
      case FAC_SIMD_F64_ADD: value=a+b; break;
      case FAC_SIMD_F64_SUB: value=a-b; break;
      case FAC_SIMD_F64_MUL: value=a*b; break;
      case FAC_SIMD_F64_DIV: value=a/b; break;
    }
    std::memcpy(out+i,&value,sizeof(value));
  }
#endif
  for (;i<count;i++) out[i]=fac_simd_f64_apply(left[i],right[i],op);
}
static int32_t fac_simd_f64_binary(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,
                                   int64_t count,FacSimdF64BinaryOp op) {
  if(count<0||(count&1)!=0||!fac_gpu_f64_range(d,(uint64_t)count)||
     !fac_gpu_f64_range(a,(uint64_t)count)||!fac_gpu_f64_range(b,(uint64_t)count)) return 0;
  try {
    std::vector<double> out((size_t)count);
    if(fac_gpu_native_f64_blocks()) {
      alignas(64) double left[FAC_GPU_SIMD_BLOCK],right[FAC_GPU_SIMD_BLOCK];
      for(uint64_t base=0;base<(uint64_t)count;base+=FAC_GPU_SIMD_BLOCK) {
        const size_t n=(size_t)std::min<uint64_t>(FAC_GPU_SIMD_BLOCK,(uint64_t)count-base);
        fac_gpu_copy_f64_block(left,a,base,n);
        fac_gpu_copy_f64_block(right,b,base,n);
        fac_simd_f64_binary_kernel(out.data()+(size_t)base,left,right,n,op);
      }
    } else {
      for(uint64_t i=0;i<(uint64_t)count;i++)
        out[(size_t)i]=fac_simd_f64_apply(fac_gpu_load_f64(a,i),fac_gpu_load_f64(b,i),op);
    }
    for(double value:out) if(!std::isfinite(value)) return 0;
    if(count) std::memcpy(d->bytes.data(),out.data(),(size_t)count*8u);
    return 1;
  } catch(const std::bad_alloc&) { return 0; }
    catch(const std::length_error&) { return 0; }
}
int32_t fac_simd_add_f64x2(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){return fac_simd_f64_binary(d,a,b,count,FAC_SIMD_F64_ADD);}
int32_t fac_simd_sub_f64x2(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){return fac_simd_f64_binary(d,a,b,count,FAC_SIMD_F64_SUB);}
int32_t fac_simd_mul_f64x2(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){return fac_simd_f64_binary(d,a,b,count,FAC_SIMD_F64_MUL);}
int32_t fac_simd_div_f64x2(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t count){return fac_simd_f64_binary(d,a,b,count,FAC_SIMD_F64_DIV);}
int32_t fac_simd_scale_f64x2(FacGpuBuffer*d,FacGpuBuffer*a,int64_t count,double scale){if(count<0||(count&1)!=0)return 0;return fac_gpu_scale_f64(d,a,count,scale);}
int32_t fac_gpu_matmul_f64(FacGpuBuffer*d,FacGpuBuffer*a,FacGpuBuffer*b,int64_t rows,int64_t inner,int64_t cols){
  if(rows<=0||inner<=0||cols<=0||rows>16777216/inner||inner>16777216/cols||rows>16777216/cols)return 0;
  uint64_t na=(uint64_t)rows*(uint64_t)inner,nb=(uint64_t)inner*(uint64_t)cols,nc=(uint64_t)rows*(uint64_t)cols;
  if(!fac_gpu_f64_range(a,na)||!fac_gpu_f64_range(b,nb)||!fac_gpu_f64_range(d,nc))return 0;
  try {
    std::vector<double> out((size_t)nc,0.0);
    for(int64_t i=0;i<rows;i++)for(int64_t k=0;k<inner;k++){double x=fac_gpu_load_f64(a,(uint64_t)i*(uint64_t)inner+(uint64_t)k);for(int64_t j=0;j<cols;j++)out[(size_t)i*(size_t)cols+(size_t)j]+=x*fac_gpu_load_f64(b,(uint64_t)k*(uint64_t)cols+(uint64_t)j);}
    for(uint64_t i=0;i<nc;i++)if(!std::isfinite(out[(size_t)i]))return 0;
    for(uint64_t i=0;i<nc;i++)fac_gpu_store_f64(d,i,out[(size_t)i]);return 1;
  } catch(const std::bad_alloc&) { return 0; } catch(const std::length_error&) { return 0; }
}
}

// ================================================================ audio: PCM16 clips and WAV I/O; playback uses native/OS command backend
struct FacAudioClip { int rate=44100, channels=1; std::vector<int16_t> pcm; };
static std::atomic<unsigned long long> g_audio_seq{0};
static std::mutex g_audio_control_mu;
#ifndef _WIN32
static pid_t g_audio_child=-1; static std::string g_audio_path;
extern char **environ;
#endif
static void fac_audio_put16(std::string&o,uint16_t v){o+=(char)(v&255);o+=(char)(v>>8);}
static void fac_audio_put32(std::string&o,uint32_t v){for(int i=0;i<4;i++)o+=(char)(v>>(i*8));}
static std::string fac_audio_wav(const FacAudioClip*c){std::string o;uint32_t data=(uint32_t)(c->pcm.size()*2);o.reserve(44+data);o+="RIFF";fac_audio_put32(o,36+data);o+="WAVEfmt ";fac_audio_put32(o,16);fac_audio_put16(o,1);fac_audio_put16(o,(uint16_t)c->channels);fac_audio_put32(o,(uint32_t)c->rate);fac_audio_put32(o,(uint32_t)c->rate*c->channels*2);fac_audio_put16(o,(uint16_t)(c->channels*2));fac_audio_put16(o,16);o+="data";fac_audio_put32(o,data);for(int16_t v:c->pcm)fac_audio_put16(o,(uint16_t)v);return o;}
static bool fac_audio_cmd(const char*name){const char*path=getenv("PATH");if(!path)return false;std::string p(path);size_t at=0;while(at<=p.size()){size_t end=p.find(':',at);if(end==std::string::npos)end=p.size();std::string dir=p.substr(at,end-at);if(dir.empty())dir=".";std::string f=dir+"/"+name;if(access(f.c_str(),X_OK)==0)return true;at=end+1;}return false;}
#ifndef _WIN32
#include "fac_pal_audio_sdl.inc"
#endif
extern "C" {
FacAudioClip *fac_audio_create(int32_t rate,int32_t channels,int64_t frames){if(rate<8000||rate>192000||channels<1||channels>2||frames<0||frames>(int64_t)20000000/channels)do_throw("audio.create: invalid format or clip too large",14);FacAudioClip*c=nullptr;try{c=new(std::nothrow) FacAudioClip;if(!c)do_throw("audio.create: out of memory",5);c->rate=rate;c->channels=channels;c->pcm.assign((size_t)frames*channels,0);}catch(const std::bad_alloc&){delete c;do_throw("audio.create: out of memory",5);}catch(const std::length_error&){delete c;do_throw("audio.create: requested clip is too large",14);}return c;}
FacAudioClip *fac_audio_tone(double freq,double seconds,int32_t rate,double volume){if(!std::isfinite(freq)||!std::isfinite(seconds)||!std::isfinite(volume)||rate<8000||rate>192000||freq<=0||freq>=rate/2.0||seconds<0||seconds>120||volume<0||volume>1)do_throw("audio.tone: invalid frequency, duration, rate or volume",14);int64_t frames=(int64_t)llround(seconds*rate);auto*c=fac_audio_create(rate,1,frames);for(int64_t i=0;i<frames;i++){double fade=std::min(1.0,std::min(i/(rate*0.01+1.0),(frames-i)/(rate*0.01+1.0)));double v=sin(6.283185307179586*freq*i/rate)*volume*fade;c->pcm[(size_t)i]=(int16_t)std::llround(v*32767);}return c;}
void fac_audio_free(FacAudioClip*c){delete c;}
int64_t fac_audio_frames(FacAudioClip*c){return c&&c->channels?(int64_t)c->pcm.size()/c->channels:0;}
int32_t fac_audio_rate(FacAudioClip*c){return c?c->rate:0;}
int32_t fac_audio_channels(FacAudioClip*c){return c?c->channels:0;}
double fac_audio_duration(FacAudioClip*c){return c&&c->rate?(double)fac_audio_frames(c)/c->rate:0.0;}
void fac_audio_gain(FacAudioClip*c,double gain){if(!c||!std::isfinite(gain)||gain<0||gain>8)do_throw("audio.gain: gain must be between 0 and 8",14);for(auto&v:c->pcm)v=(int16_t)std::max(-32768.0,std::min(32767.0,std::round(v*gain)));}
void fac_audio_mix(FacAudioClip*d,FacAudioClip*s,double gain){if(!d||!s||d->rate!=s->rate||d->channels!=s->channels||!std::isfinite(gain)||gain<0||gain>8)do_throw("audio.mix: incompatible clips or invalid gain",14);try{if(s->pcm.size()>d->pcm.size())d->pcm.resize(s->pcm.size(),0);}catch(const std::bad_alloc&){do_throw("audio.mix: out of memory",5);}for(size_t i=0;i<s->pcm.size();i++)d->pcm[i]=(int16_t)std::max(-32768.0,std::min(32767.0,std::round(d->pcm[i]+s->pcm[i]*gain)));}
void fac_audio_savewav(FacAudioClip*c,FacStr*path){
  if(!c)do_throw("audio.saveWav: null clip",14);
  // Keep all C++ temporaries inside the lambda so a subsequent FAC longjmp
  // cannot bypass their destructors.
  bool ok = [&]() {
    std::string w = fac_audio_wav(c);
    FILE *f = fopen(sd(path), "wb");
    if (!f) return false;
    bool wrote = fac_file_write_bytes(f, w.data(), w.size());
    bool flushed = fflush(f) == 0;
    int closed = fclose(f);
    return wrote && flushed && closed == 0;
  }();
  if(!ok)do_throw("audio.saveWav: write failed",7);
}
static FacAudioClip *fac_audio_load_impl(FacStr *path, std::string &err, int &errCode) {
  FILE *f = fopen(sd(path), "rb");
  if (!f) { err = std::string("audio.load: cannot open ") + sd(path); errCode = 7; return nullptr; }
  constexpr size_t MAX_WAV_BYTES = 64u * 1024u * 1024u;
  std::string d; char buf[8192]; size_t n = 0;
  while ((n = fread(buf, 1, sizeof buf, f)) > 0) {
    if (n > MAX_WAV_BYTES - d.size()) {
      fclose(f); err = "audio.load: WAV file exceeds 64 MiB limit"; errCode = 14; return nullptr;
    }
    try { d.append(buf, n); }
    catch (const std::bad_alloc &) { fclose(f); err = "audio.load: out of memory"; errCode = 5; return nullptr; }
  }
  bool readError = ferror(f) != 0; fclose(f);
  if (readError) { err = "audio.load: read failed"; errCode = 7; return nullptr; }
  auto u16 = [&](size_t i) -> uint16_t {
    return i <= d.size() && d.size() - i >= 2 ? (uint16_t)((uint8_t)d[i] | ((uint16_t)(uint8_t)d[i + 1] << 8)) : 0;
  };
  auto u32 = [&](size_t i) -> uint32_t {
    return i <= d.size() && d.size() - i >= 4 ? (uint32_t)(uint8_t)d[i] | ((uint32_t)(uint8_t)d[i + 1] << 8) |
           ((uint32_t)(uint8_t)d[i + 2] << 16) | ((uint32_t)(uint8_t)d[i + 3] << 24) : 0;
  };
  if (d.size() < 44 || d.compare(0, 4, "RIFF") != 0 || d.compare(8, 4, "WAVE") != 0) {
    err = "audio.load: not a WAV file"; errCode = 14; return nullptr;
  }
  const uint32_t riffLen = u32(4);
  if ((size_t)riffLen > d.size() - 8 || riffLen < 36) {
    err = "audio.load: invalid RIFF length"; errCode = 14; return nullptr;
  }
  const size_t riffEnd = 8u + (size_t)riffLen;
  int fmt = 0, channels = 0, rate = 0, bits = 0;
  size_t dataAt = 0, dataLen = 0;
  for (size_t i = 12; i <= riffEnd && riffEnd - i >= 8;) {
    const uint32_t len32 = u32(i + 4);
    const size_t start = i + 8, len = (size_t)len32;
    if (len > riffEnd - start) {
      err = "audio.load: truncated WAV chunk"; errCode = 14; return nullptr;
    }
    if (d.compare(i, 4, "fmt ") == 0 && len >= 16) {
      fmt = u16(start); channels = u16(start + 2); rate = (int)u32(start + 4); bits = u16(start + 14);
    } else if (d.compare(i, 4, "data") == 0) {
      dataAt = start; dataLen = len;
    }
    const size_t padded = len + (len & 1u);
    if (padded > riffEnd - start) {
      err = "audio.load: truncated WAV padding"; errCode = 14; return nullptr;
    }
    i = start + padded;
  }
  if (fmt != 1 || bits != 16 || channels < 1 || channels > 2 || rate < 8000 || rate > 192000 ||
      !dataAt || dataLen % 2 || dataLen / 2 > 20000000 || dataLen / 2 % (size_t)channels != 0) {
    err = "audio.load: supports PCM16 WAV (mono/stereo) only"; errCode = 14; return nullptr;
  }
  try {
    std::unique_ptr<FacAudioClip> c(new FacAudioClip);
    c->rate = rate; c->channels = channels;
    c->pcm.resize(dataLen / 2);
    for (size_t i = 0; i < c->pcm.size(); i++) c->pcm[i] = (int16_t)u16(dataAt + i * 2);
    return c.release();
  } catch (const std::bad_alloc &) {
    err = "audio.load: out of memory"; errCode = 5; return nullptr;
  }
}
FacAudioClip *fac_audio_load(FacStr *path) {
  std::string err; int errCode = 14;
  FacAudioClip *clip = fac_audio_load_impl(path, err, errCode);
  if (clip) return clip;
  do_throw(std::move(err), errCode);
}

int32_t fac_audio_available(){
#ifdef _WIN32
 return 1;
#else
 return palaudio::available()||fac_audio_cmd("aplay")||fac_audio_cmd("paplay");
#endif
}
static void fac_audio_stop_locked(){
#ifdef _WIN32
 PlaySoundA(nullptr,nullptr,0);
#else
 palaudio::stopAll();
 if(g_audio_child>0){
   const pid_t child = g_audio_child;
   int st=0;
   auto reap_nonblocking = [&]() {
     pid_t r;
     do { r=waitpid(child,&st,WNOHANG); } while(r<0 && errno==EINTR);
     return r;
   };
   pid_t done=reap_nonblocking();
   if(done==0 || (done<0 && errno!=ECHILD)){
     (void)kill(child,SIGTERM);
     const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(1);
     while(std::chrono::steady_clock::now()<deadline){
       done=reap_nonblocking();
       if(done==child || (done<0 && errno==ECHILD)) break;
       if(done<0) break;
       std::this_thread::sleep_for(std::chrono::milliseconds(10));
     }
     if(done==0 || (done<0 && errno!=ECHILD)){
       (void)kill(child,SIGKILL);
       pid_t reaped;
       do { reaped=waitpid(child,&st,0); } while(reaped<0 && errno==EINTR);
     }
   }
   g_audio_child=-1;
 }
 if(!g_audio_path.empty()){unlink(g_audio_path.c_str());g_audio_path.clear();}
#endif
}
void fac_audio_stop(){std::lock_guard<std::mutex> lk(g_audio_control_mu);fac_audio_stop_locked();}
int32_t fac_audio_play(FacAudioClip*c){if(!c)return 0;std::string w=fac_audio_wav(c);
#ifdef _WIN32
 std::lock_guard<std::mutex> lk(g_audio_control_mu);
 static std::string playingWav;fac_audio_stop_locked();playingWav=std::move(w);return PlaySoundA(playingWav.data(),nullptr,SND_ASYNC|SND_MEMORY|SND_NODEFAULT)!=0;
#else
 if(palaudio::play(c,false))return 1;   // SDL mixer: เล่นซ้อนกันได้
 if(!fac_audio_available())return 0;
 std::lock_guard<std::mutex> lk(g_audio_control_mu);
 fac_audio_stop_locked();
 // mkstemp creates a private 0600 file atomically, avoiding predictable-name symlink attacks.
 char pathTemplate[]="/tmp/fac_audio_XXXXXX";
 int fd=mkstemp(pathTemplate); if(fd<0)return 0;
 std::string path(pathTemplate);
 FILE*f=fdopen(fd,"wb"); if(!f){close(fd);unlink(path.c_str());return 0;}
 bool ok=fwrite(w.data(),1,w.size(),f)==w.size();
 if(fclose(f)!=0)ok=false;
 if(!ok){unlink(path.c_str());return 0;}
 pid_t pid=-1; char *fileArg=path.data();
 char *aplayArgs[]={const_cast<char*>("aplay"),const_cast<char*>("-q"),fileArg,nullptr};
 int spawnError=posix_spawnp(&pid,"aplay",nullptr,nullptr,aplayArgs,environ);
 if(spawnError!=0){
   char *paplayArgs[]={const_cast<char*>("paplay"),fileArg,nullptr};
   spawnError=posix_spawnp(&pid,"paplay",nullptr,nullptr,paplayArgs,environ);
 }
 if(spawnError!=0){unlink(path.c_str());return 0;}
 g_audio_child=pid;g_audio_path=std::move(path);
 static const bool cleanupRegistered=(std::atexit(fac_audio_stop),true);(void)cleanupRegistered;
 return 1;
#endif
}
int32_t fac_audio_playloop(FacAudioClip*c){if(!c)return 0;
#ifdef _WIN32
 std::string w=fac_audio_wav(c);std::lock_guard<std::mutex> lk(g_audio_control_mu);
 static std::string loopWav;fac_audio_stop_locked();loopWav=std::move(w);return PlaySoundA(loopWav.data(),nullptr,SND_ASYNC|SND_MEMORY|SND_NODEFAULT|SND_LOOP)!=0;
#else
 return palaudio::play(c,true)?1:0;
#endif
}
void fac_audio_volume(double v){if(!std::isfinite(v)||v<0||v>1)do_throw("audio.volume: volume must be between 0 and 1",14);
#ifndef _WIN32
 palaudio::master.store(v,std::memory_order_relaxed);
#endif
}
int32_t fac_audio_playing(){
#ifdef _WIN32
 return 0;
#else
 return palaudio::count();
#endif
}
}

// ================================================================ font: bitmap fallback + optional Pango/Cairo vector backend
#include "fac_font_pango.inc"
struct FacFont {
  int scale=1;
  bool vector=false;
  int pixelSize=0;
  std::string family="Bitmap";
#ifndef _WIN32
  facfont::PangoContext *context=nullptr;
  facfont::PangoLayout *layout=nullptr;
#endif
};
#ifndef _WIN32
static bool fac_font_set_desc(FacFont *f, int size) {
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(!a.ready||!f||!f->layout)return false;
  auto *desc=a.desc_new(); if(!desc)return false;
  a.desc_family(desc,f->family.c_str());
  a.desc_abs_size(desc,(double)size*1024.0);
  a.layout_set_desc(f->layout,desc);
  a.desc_free(desc);
  f->pixelSize=size;
  return true;
}
static FacFont *fac_font_make_vector(const std::string &family, int size) {
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(!a.ready)return nullptr;
  auto *map=a.font_map_default(); if(!map)return nullptr;
  auto *f=new(std::nothrow) FacFont; if(!f)return nullptr;
  f->family=family; f->vector=true;
  f->context=a.font_map_context(map);
  if(!f->context){delete f;return nullptr;}
  f->layout=a.layout_new(f->context);
  if(!f->layout||!fac_font_set_desc(f,size)){
    if(f->layout)a.g_unref(f->layout); a.g_unref(f->context); delete f; return nullptr;
  }
  return f;
}
static bool fac_font_layout_text(FacFont *f, FacStr *s) {
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(!f||!s||s->len<0||s->len>1048576||(!s->data&&s->len))return false;
  const char *text=s->data?s->data:"";
  if(!facfont::validUtf8(text,(size_t)s->len))return false;
  a.layout_set_text(f->layout,text,(int)s->len);
  return true;
}
static void fac_font_vector_draw(Canvas *c, FacFont *f, int32_t x, int32_t y, FacStr *s, int32_t color) {
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(!fac_font_layout_text(f,s))do_throw("font.draw: text must be valid UTF-8 and at most 1 MiB",14);
  facfont::PangoRectangle ink{0,0,0,0}, logical{0,0,0,0};
  a.layout_get_extents(f->layout,&ink,&logical);
  int64_t left=std::min<int64_t>(ink.x,logical.x), top=std::min<int64_t>(ink.y,logical.y);
  int64_t right=std::max<int64_t>((int64_t)ink.x+ink.width,(int64_t)logical.x+logical.width);
  int64_t bottom=std::max<int64_t>((int64_t)ink.y+ink.height,(int64_t)logical.y+logical.height);
  const int pad=3;
  int64_t ww=std::max<int64_t>(1,right-left+pad*2), hh=std::max<int64_t>(1,bottom-top+pad*2);
  if(!c)do_throw("font.draw: null canvas",6);
  if(ww>16384||hh>16384||ww*hh>(int64_t)FAC_GFX_MAX_PIXELS)do_throw("font.draw: raster area exceeds 16M pixels",14);
  int w=(int)ww,h=(int)hh,stride=(w+3)&~3;
  std::vector<unsigned char> mask;
  try { mask.assign((size_t)stride*(size_t)h,0); } catch(const std::bad_alloc&) { do_throw("out of memory",5); }
  // Cairo A8 stores glyph coverage only; FAC applies the requested RGB color below.
  auto *surface=a.surface_create(mask.data(),2,w,h,stride); // CAIRO_FORMAT_A8 == 2
  if(!surface)do_throw("font.draw: cannot create raster surface",14);
  auto *cr=a.cairo_create(surface);
  if(!cr){a.surface_destroy(surface);do_throw("font.draw: cannot create Cairo context",14);}
  a.cairo_source_rgba(cr,1.0,1.0,1.0,1.0);
  a.cairo_move_to(cr,(double)(pad-left),(double)(pad-top));
  a.show_layout(cr,f->layout);
  a.surface_flush(surface);
  FacCanvasLock canvasLock(c);
  int64_t ox=(int64_t)x+left-pad, oy=(int64_t)y+top-pad;
  uint32_t rgb=(uint32_t)color&0xFFFFFF;
  int sr=(rgb>>16)&255,sg=(rgb>>8)&255,sb=rgb&255;
  int x0=(int)std::max<int64_t>(0,ox), y0=(int)std::max<int64_t>(0,oy);
  int x1=(int)std::min<int64_t>(c->w,ox+w), y1=(int)std::min<int64_t>(c->h,oy+h);
  for(int py=y0;py<y1;py++)for(int px=x0;px<x1;px++){
    unsigned alpha=mask[(size_t)(py-oy)*(size_t)stride+(size_t)(px-ox)];
    if(!alpha)continue;
    uint32_t dst=c->px[(size_t)py*(size_t)c->w+(size_t)px];
    unsigned dr=(dst>>16)&255,dg=(dst>>8)&255,db=dst&255, inv=255-alpha;
    unsigned rr=(sr*alpha+dr*inv+127)/255,gg=(sg*alpha+dg*inv+127)/255,bb=(sb*alpha+db*inv+127)/255;
    c->px[(size_t)py*(size_t)c->w+(size_t)px]=(rr<<16)|(gg<<8)|bb;
  }
  a.cairo_destroy(cr); a.surface_destroy(surface);
}
#endif
extern "C" {
int32_t fac_font_backend_available(){
#ifndef _WIN32
  return facfont::api().ready?1:0;
#else
  return 0;
#endif
}
FacFont *fac_font_create(int32_t scale){if(scale<1||scale>64)do_throw("font.create: scale must be 1..64",14);auto*f=new(std::nothrow) FacFont;if(!f)do_throw("out of memory",5);f->scale=scale;return f;}
FacFont *fac_font_load(FacStr *path,int32_t size){
  if(!path||!path->data||path->len<=0||path->len>4096)do_throw("font.load: invalid font path",14);
  if(size<1||size>512)do_throw("font.load: size must be 1..512 pixels",14);
#ifdef _WIN32
  do_throw("font.load: vector font backend is unavailable on this platform; use font.create for bitmap fallback",14);
#else
  auto &a=facfont::api(); if(!a.ready)do_throw("font.load: Pango/Cairo/Fontconfig runtime libraries are unavailable",14);
  std::string file(sd(path)); std::error_code ec;
  if(!std::filesystem::is_regular_file(std::filesystem::u8path(file),ec)||ec)do_throw("font.load: font file does not exist or is not a regular file",7);
  std::string family; bool ok=false;
  {
    std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
    if(!a.fc_init())ok=false;
    else {
      int count=0; auto *pattern=a.fc_query((const facfont::FcChar8*)file.c_str(),0,nullptr,&count);
      if(pattern){facfont::FcChar8 *value=nullptr;if(a.fc_get_string(pattern,"family",0,&value)==0&&value)family=(const char*)value;a.fc_pattern_destroy(pattern);}
      auto *cfg=a.fc_current();
      if(!family.empty()&&cfg){
        if(a.registeredFiles.find(file)==a.registeredFiles.end()){
          if(a.fc_add_file(cfg,(const facfont::FcChar8*)file.c_str())&&a.fc_build(cfg))a.registeredFiles.insert(file);
        }
        ok=a.registeredFiles.find(file)!=a.registeredFiles.end();
        if(ok){auto *map=a.font_map_default();if(map&&a.fc_map_changed)a.fc_map_changed(map);}
      }
    }
  }
  if(!ok)do_throw("font.load: Fontconfig could not register this font file",14);
  auto *f=fac_font_make_vector(family,size);
  if(!f)do_throw("font.load: Pango could not create a layout for the font",14);
  return f;
#endif
}
void fac_font_free(FacFont*f){if(!f)return;
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(f->layout)a.g_unref(f->layout);if(f->context)a.g_unref(f->context);
#endif
  delete f;
}
void fac_font_setscale(FacFont*f,int32_t scale){
  if(!f||scale<1||scale>64)do_throw("font.setScale: scale must be 1..64",14);
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
#endif
  if(f->vector)do_throw("font.setScale: use font.setSize for vector fonts",14);f->scale=scale;
}
void fac_font_setsize(FacFont*f,int32_t size){if(!f||!f->vector||size<1||size>512)do_throw("font.setSize: requires vector font and size 1..512",14);
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(!fac_font_set_desc(f,size))do_throw("font.setSize: could not update font description",14);
#endif
}
int32_t fac_font_size(FacFont*f){if(!f)return 0;
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
#endif
  return f->vector?f->pixelSize:f->scale;
}
int32_t fac_font_isvector(FacFont*f){if(!f)return 0;
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
#endif
  return f->vector?1:0;
}
FacStr *fac_font_family(FacFont*f){
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
#endif
  return mks(f?f->family:"Bitmap");
}
void fac_font_draw(Canvas*c,FacFont*f,int32_t x,int32_t y,FacStr*s,int32_t color){if(!f||!c)do_throw("font.draw: null handle",14);
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
#endif
#ifndef _WIN32
  if(f->vector){fac_font_vector_draw(c,f,x,y,s,color);return;}
#endif
  fac_gfx_bitmap_text(c,x,y,s,color,f->scale);
}
int32_t fac_font_measure(FacFont*f,FacStr*s){
  if(!f)return 0;
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(f->vector){if(!fac_font_layout_text(f,s))return 0;int w=0,h=0;a.layout_get_size(f->layout,&w,&h);return std::max(0,w);}
#endif
  if(!s||!s->data||s->len<=0)return 0;
  int64_t line=0,best=0;const char*q=s->data,*end=s->data+s->len;uint32_t prev=0;int riRun=0;bool first=true;
  while(q<end){int n=1;uint32_t cp=dec(q,&n);bool begins=first||!fac_grapheme_no_break(prev,cp,riRun);
    if(begins){if(cp=='\n'){best=std::max(best,line);line=0;}else line+=4*(int64_t)f->scale;}
    if(cp>=0x1F1E6&&cp<=0x1F1FF)riRun=(prev>=0x1F1E6&&prev<=0x1F1FF)?riRun+1:1;else riRun=0;
    prev=cp;q+=std::max(1,n);first=false;
  }
  int64_t out=std::max(best,line);return out>INT32_MAX?INT32_MAX:(int32_t)out;
}
int32_t fac_font_height(FacFont*f){if(!f)return 0;
#ifndef _WIN32
  auto &a=facfont::api(); std::lock_guard<std::recursive_mutex> guard(a.backendMutex);
  if(f->vector){a.layout_set_text(f->layout,"Mg",2);int w=0,h=0;a.layout_get_size(f->layout,&w,&h);return std::max(0,h);}
#endif
  return 6*f->scale;
}
}

// ================================================================ default system-font path for the canvas/UI renderer
// graphic.text and the reusable render.text UI path use system typography by default.
// The legacy 3x5 renderer remains available through graphic.bitmapText and is also
// used as a conservative fallback when the host has no native text backend.
static int fac_system_font_pixels(int32_t scale) {
  if (scale < 1) scale = 1;
  if (scale > 512) scale = 512;
  return std::max(8, std::min(512, (int)scale * 6));
}

#ifdef _WIN32
static bool fac_win_utf8_to_wide(FacStr *s, std::wstring &out) {
  if (!s || s->len < 0 || s->len > 1048576 || (!s->data && s->len)) return false;
  if (s->len == 0) { out.clear(); return true; }
  int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s->data, (int)s->len, nullptr, 0);
  if (count <= 0 || count > 1048576) return false;
  try { out.resize((size_t)count); } catch (...) { return false; }
  return MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s->data, (int)s->len, out.data(), count) == count;
}

static bool fac_win_system_text_measure(const std::wstring &text, int pixelSize, int &outWidth, int &outHeight) {
  HDC dc = CreateCompatibleDC(nullptr);
  if (!dc) return false;
  HFONT font = CreateFontW(-pixelSize, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
      DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
      DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
  if (!font) { DeleteDC(dc); return false; }
  HGDIOBJ oldFont = SelectObject(dc, font);
  TEXTMETRICW tm{};
  if (!GetTextMetricsW(dc, &tm)) {
    SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
  }
  int lineHeight = std::max(1, (int)tm.tmHeight + (int)tm.tmExternalLeading);
  int maxWidth = 0;
  size_t start = 0;
  while (start <= text.size()) {
    size_t end = text.find(L'\n', start);
    if (end == std::wstring::npos) end = text.size();
    size_t len = end - start;
    if (len && text[start + len - 1] == L'\r') --len;
    SIZE extent{};
    if (len && !GetTextExtentPoint32W(dc, text.data() + start, (int)len, &extent)) {
      SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
    }
    maxWidth = std::max(maxWidth, (int)extent.cx);
    if (end == text.size()) break;
    start = end + 1;
  }
  SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc);
  outWidth = maxWidth; outHeight = lineHeight;
  return true;
}

static bool fac_win_system_text_draw(Canvas *canvas, int32_t x, int32_t y, FacStr *value, int32_t color, int pixelSize) {
  if (!canvas || !value) return false;
  std::wstring text;
  if (!fac_win_utf8_to_wide(value, text)) return false;
  if (text.empty()) return true;
  HDC dc = CreateCompatibleDC(nullptr);
  if (!dc) return false;
  HFONT font = CreateFontW(-pixelSize, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
      DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
      DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
  if (!font) { DeleteDC(dc); return false; }
  HGDIOBJ oldFont = SelectObject(dc, font);
  TEXTMETRICW tm{};
  if (!GetTextMetricsW(dc, &tm)) {
    SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
  }
  int lineHeight = std::max(1, (int)tm.tmHeight + (int)tm.tmExternalLeading);
  std::vector<std::pair<size_t,size_t>> lines;
  int maxWidth = 0;
  size_t start = 0;
  try {
    while (start <= text.size()) {
      size_t end = text.find(L'\n', start);
      if (end == std::wstring::npos) end = text.size();
      size_t len = end - start;
      if (len && text[start + len - 1] == L'\r') --len;
      SIZE extent{};
      if (len && !GetTextExtentPoint32W(dc, text.data() + start, (int)len, &extent)) {
        SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
      }
      maxWidth = std::max(maxWidth, (int)extent.cx);
      lines.emplace_back(start, len);
      if (end == text.size()) break;
      start = end + 1;
      if (lines.size() > 65536) { SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false; }
    }
  } catch (...) { SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false; }
  const int pad = 2;
  int64_t dibW64 = (int64_t)maxWidth + pad * 2;
  int64_t dibH64 = (int64_t)lineHeight * (int64_t)lines.size() + pad * 2;
  if (dibW64 <= 0 || dibH64 <= 0 || dibW64 > 16384 || dibH64 > 16384 || dibW64 * dibH64 > 64000000) {
    SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
  }
  int dibW = (int)dibW64, dibH = (int)dibH64;
  BITMAPINFO bi{};
  bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bi.bmiHeader.biWidth = dibW;
  bi.bmiHeader.biHeight = -dibH;
  bi.bmiHeader.biPlanes = 1;
  bi.bmiHeader.biBitCount = 32;
  bi.bmiHeader.biCompression = BI_RGB;
  void *bits = nullptr;
  HBITMAP bitmap = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (!bitmap || !bits) {
    if (bitmap) DeleteObject(bitmap);
    SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc); return false;
  }
  HGDIOBJ oldBitmap = SelectObject(dc, bitmap);
  std::memset(bits, 0, (size_t)dibW * (size_t)dibH * sizeof(uint32_t));
  SetBkMode(dc, OPAQUE); SetBkColor(dc, RGB(0,0,0)); SetTextColor(dc, RGB(255,255,255));
  bool ok = true;
  for (size_t i = 0; i < lines.size(); ++i) {
    const auto &line = lines[i];
    if (line.second && !TextOutW(dc, pad, pad + (int)i * lineHeight,
                                text.data() + line.first, (int)line.second)) { ok = false; break; }
  }
  if (ok) {
    GdiFlush();
    const uint32_t *src = (const uint32_t *)bits;
    uint32_t rgb = (uint32_t)color & 0xFFFFFFu;
    unsigned sr=(rgb>>16)&255, sg=(rgb>>8)&255, sb=rgb&255;
    for (int py=0; py<dibH; ++py) for (int px=0; px<dibW; ++px) {
      uint32_t sample = src[(size_t)py * (size_t)dibW + (size_t)px];
      unsigned alpha = std::max({(sample>>16)&255u,(sample>>8)&255u,sample&255u});
      if (!alpha) continue;
      int64_t dx=(int64_t)x+px-pad, dy=(int64_t)y+py-pad;
      if (dx<0 || dy<0 || dx>=canvas->w || dy>=canvas->h) continue;
      uint32_t &dst=canvas->px[(size_t)dy*(size_t)canvas->w+(size_t)dx];
      unsigned dr=(dst>>16)&255,dg=(dst>>8)&255,db=dst&255,inv=255-alpha;
      unsigned rr=(sr*alpha+dr*inv+127)/255,gg=(sg*alpha+dg*inv+127)/255,bb=(sb*alpha+db*inv+127)/255;
      dst=(rr<<16)|(gg<<8)|bb;
    }
  }
  SelectObject(dc, oldBitmap); DeleteObject(bitmap);
  SelectObject(dc, oldFont); DeleteObject(font); DeleteDC(dc);
  return ok;
}
#endif

#ifndef _WIN32
struct FacSystemFontCache {
  std::map<int, FacFont*> fonts;
  ~FacSystemFontCache() { for (auto &entry : fonts) fac_font_free(entry.second); }
};
static FacFont *fac_system_font_for_scale(int32_t scale) {
  static thread_local FacSystemFontCache cache;
  int pixels = fac_system_font_pixels(scale);
  auto it = cache.fonts.find(pixels);
  if (it != cache.fonts.end()) return it->second;
  if (!facfont::api().ready) return nullptr;
  FacFont *font = fac_font_make_vector("Sans", pixels);
  if (!font) return nullptr;
  if (cache.fonts.size() >= 16) {
    auto first = cache.fonts.begin();
    fac_font_free(first->second);
    cache.fonts.erase(first);
  }
  cache.fonts.emplace(pixels, font);
  return font;
}
#endif

extern "C" {
int32_t fac_gfx_system_text_available() {
#ifdef _WIN32
  return 1; // Native GDI system font rendering (Segoe UI fallback).
#else
  return facfont::api().ready ? 1 : 0;
#endif
}
void fac_gfx_system_text(Canvas *canvas, int32_t x, int32_t y, FacStr *value, int32_t color, int32_t scale) {
  if (!canvas || !value || !value->data || value->len <= 0) return;
  if (scale < 1) scale = 1;
  if (scale > 512) do_throw("graphic.systemText: scale exceeds 512", 14);
  int pixels = fac_system_font_pixels(scale);
#ifdef _WIN32
  { FacCanvasLock lock(canvas); if (fac_win_system_text_draw(canvas, x, y, value, color, pixels)) return; }
#else
  if (FacFont *font = fac_system_font_for_scale(scale)) { fac_font_vector_draw(canvas, font, x, y, value, color); return; }
#endif
  // Explicitly retain functionality on minimal/headless systems without a vector backend.
  fac_gfx_bitmap_text(canvas, x, y, value, color, scale);
}
int32_t fac_gfx_system_textwidth(FacStr *value, int32_t scale) {
  if (!value || value->len <= 0) return 0;
  if (scale < 1) scale = 1;
  if (scale > 512) scale = 512;
  int pixels = fac_system_font_pixels(scale);
#ifdef _WIN32
  std::wstring text;
  int width=0,height=0;
  if (fac_win_utf8_to_wide(value,text) && fac_win_system_text_measure(text,pixels,width,height)) return width;
#else
  if (FacFont *font = fac_system_font_for_scale(scale)) return fac_font_measure(font, value);
#endif
  int64_t count = fac_str_grapheme_len(value), unit = 4LL * scale;
  if (count > INT32_MAX / unit) return INT32_MAX;
  return (int32_t)(count * unit);
}
void fac_gfx_text(Canvas *canvas, int32_t x, int32_t y, FacStr *value, int32_t color, int32_t scale) {
  fac_gfx_system_text(canvas, x, y, value, color, scale);
}
int32_t fac_gfx_textwidth(FacStr *value, int32_t scale) {
  return fac_gfx_system_textwidth(value, scale);
}
void fac_gfx_bitmap_text1(Canvas *canvas, int32_t x, int32_t y, FacStr *value, int32_t color) {
  fac_gfx_bitmap_text(canvas, x, y, value, color, 1);
}
}

// ================================================================ keyboard/mouse: consistent aliases over the active graphic window
extern "C" {
int32_t fac_keyboard_down(Canvas*c,FacStr*k){return c?fac_gfx_key(c,k):0;}
int32_t fac_mouse_x(Canvas*c){return c?fac_gfx_mousex(c):0;}
int32_t fac_mouse_y(Canvas*c){return c?fac_gfx_mousey(c):0;}
int32_t fac_mouse_down(Canvas*c){return c?fac_gfx_mousedown(c):0;}
int32_t fac_mouse_button(Canvas*c,FacStr*name){FacCanvasLock lock(c);if(!c)return 0;std::string n=sd(name);for(char&ch:n)ch=(char)tolower((unsigned char)ch);if(n=="left")return(c->mbuttons&1)!=0||c->mdown;if(n=="right")return(c->mbuttons&2)!=0;if(n=="middle")return(c->mbuttons&4)!=0;return 0;}
}

// ================================================================ json (dynamic), csv
static void jser(JV *v, std::string &o, int ind, int depth) {
  if (depth > 512) throw JErr{"json: nesting too deep"};   // same limit as the parser; callers convert to a FAC error
  if (!v) { o += "null"; return; }
  auto nl = [&](int d) { if (ind) { o += '\n'; o.append((size_t)(d * ind), ' '); } };
  switch (v->t) {
    case 0: o += "null"; break; case 1: o += v->b ? "true" : "false"; break;
    case 2: o += v->isint ? std::to_string(v->i) : std::isfinite(v->d) ? fmtd(v->d) : std::string("null"); break;   // NaN/Infinity are not valid JSON
    case 3: { JB b; jstr(&b, v->s.data(), v->s.size()); o += b.s; break; }
    case 4: if (v->a.empty()) { o += "[]"; break; } o += '['; for (size_t i = 0; i < v->a.size(); i++) { if (i) o += ','; nl(depth + 1); jser(v->a[i], o, ind, depth + 1); } nl(depth); o += ']'; break;
    case 5: if (v->o.empty()) { o += "{}"; break; } o += '{'; for (size_t i = 0; i < v->o.size(); i++) { if (i) o += ','; nl(depth + 1); JB b; jstr(&b, v->o[i].first.data(), v->o[i].first.size()); o += b.s; o += ind ? ": " : ":"; jser(v->o[i].second, o, ind, depth + 1); } nl(depth); o += '}'; break;
  }
}
extern "C" {
JV *fac_json_at(JV *n, int64_t i) { if (!n || n->t != 4) do_throw("json: expected an array", 10); if (i < 0 || i >= (int64_t)n->a.size()) fac_oob(i, (int64_t)n->a.size()); return n->a[(size_t)i]; }
int64_t fac_json_len(JV *n) { if (!n) return 0; return n->t == 4 ? (int64_t)n->a.size() : n->t == 5 ? (int64_t)n->o.size() : n->t == 3 ? (int64_t)n->s.size() : 0; }
FacStr *fac_json_kind(JV *n) { static const char *k[] = {"null", "boolean", "number", "string", "array", "object"}; return mks(n ? k[n->t] : "null"); }
int32_t fac_json_has(JV *n, FacStr *key) { if (!n || n->t != 5) return 0; for (auto &p : n->o) if (p.first == sd(key)) return 1; return 0; }
FacList *fac_json_keys(JV *n) {
  FacList *l = fac_list_new(8, 1); if (!n || n->t != 5) return l;
  for (auto &p : n->o) { FacStr *e = mks(p.first); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = e; }
  return l;
}
int32_t fac_json_valid(FacStr *s) {
  try { JP p{sd(s), sd(s) + sl(s)}; std::unique_ptr<JV> v(p.val()); p.ws(); return p.p == p.e; }
  catch (...) { return 0; }
}
static FacStr *fac_json_render_owned(JV *node, int indent) {
  std::string out, error;
  {
    std::unique_ptr<JV> root(node);
    try { jser(root.get(), out, indent, 0); }
    catch (JErr &e) { error = std::move(e.m); }
    catch (const std::bad_alloc &) { error = "json: out of memory while rendering"; }
    root.reset(); // destroy the owned tree before FAC's longjmp-based error transfer
  }
  if (!error.empty()) { std::string().swap(out); do_throw(std::move(error), 10); }
  return mks(out);
}
FacStr *fac_json_pretty(FacStr *s) { return fac_json_render_owned(fac_jd_parse(s), 2); }
FacStr *fac_json_compact(FacStr *s) { return fac_json_render_owned(fac_jd_parse(s), 0); }
FacList *fac_csv_parseline(FacStr *s) {
  FacList *l = fac_list_new(8, 1); std::string cur; bool q = false; const char *p = sd(s); int64_t n = sl(s);
  auto push = [&]() { FacStr *e = mks(cur); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = e; cur.clear(); };
  for (int64_t i = 0; i < n; i++) {
    char c = p[i];
    if (q) { if (c == '"') { if (i + 1 < n && p[i + 1] == '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c == '"') q = true; else if (c == ',') push(); else if (c == '\r' || c == '\n') {} else cur += c;
  }
  push(); return l;
}
FacStr *fac_csv_formatline(FacList *l) {
  std::string o;
  for (int64_t i = 0; i < l->len; i++) {
    if (i) o += ','; FacStr *e = ((FacStr **)l->data)[i]; std::string f(sd(e), (size_t)sl(e));
    if (f.find_first_of(",\"\r\n") != std::string::npos) { o += '"'; for (char c : f) { if (c == '"') o += '"'; o += c; } o += '"'; } else o += f;
  }
  return mks(o);
}

// ================================================================ file / sys extras
FacList *fac_file_readlines(FacStr *path) {
  FILE *f = fopen(sd(path), "rb"); if (!f) do_throw(std::string("cannot open file: ") + sd(path), 7);
  std::string all; bool tooLarge = false;
  const bool ok = fac_file_read_bounded(f, all, FAC_FILE_READ_MAX_BYTES, tooLarge);
  const int closeResult = fclose(f);
  if (!ok || closeResult != 0) { std::string().swap(all); do_throw(tooLarge ? "file.readLines: input exceeds 64 MiB limit" : "file.readLines: read failed or out of memory", 7); }
  size_t lineCount = 0;
  for (char c : all) if (c == '\n' && ++lineCount > 1000000) { std::string().swap(all); do_throw("file.readLines: exceeds 1,000,000 lines", 7); }
  if (!all.empty() && all.back() != '\n' && ++lineCount > 1000000) { std::string().swap(all); do_throw("file.readLines: exceeds 1,000,000 lines", 7); }
  FacList *l = fac_list_new(8, 1); size_t i = 0;
  while (i < all.size()) { size_t e = all.find('\n', i); if (e == std::string::npos) e = all.size(); std::string line = all.substr(i, e - i); if (!line.empty() && line.back() == '\r') line.pop_back(); FacStr *v = mks(line); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = v; i = e + 1; }
  return l;
}
FacStr *fac_file_readtext(FacStr *path) {
  FILE *f = fopen(sd(path), "rb"); if (!f) do_throw(std::string("cannot open file: ") + sd(path), 7);
  std::string all; bool tooLarge = false;
  const bool ok = fac_file_read_bounded(f, all, FAC_FILE_READ_MAX_BYTES, tooLarge);
  const int closeResult = fclose(f);
  if (!ok || closeResult != 0) { std::string().swap(all); do_throw(tooLarge ? "file.readText: input exceeds 64 MiB limit" : "file.readText: read failed or out of memory", 7); }
  return mks(all);
}
void fac_file_writeall(FacStr *path, FacStr *s) {
  FILE *f = fopen(sd(path), "wb"); if (!f) do_throw("file.writeAll: cannot open output", 7);
  bool wrote = fac_file_write_bytes(f, sd(s), (size_t)sl(s));
  bool flushed = fflush(f) == 0; int closed = fclose(f);
  if (!wrote || !flushed || closed != 0) do_throw("file.writeAll: write failed", 7);
}
void fac_file_append(FacStr *path, FacStr *s) {
  FILE *f = fopen(sd(path), "ab"); if (!f) do_throw("file.append: cannot open output", 7);
  bool wrote = fac_file_write_bytes(f, sd(s), (size_t)sl(s));
  bool flushed = fflush(f) == 0; int closed = fclose(f);
  if (!wrote || !flushed || closed != 0) do_throw("file.append: write failed", 7);
}
int64_t fac_file_size(FacStr *path) { struct stat st; if (stat(sd(path), &st) != 0) do_throw(std::string("cannot stat file: ") + sd(path), 7); return (int64_t)st.st_size; }
int32_t fac_file_mkdir(FacStr *p) { std::error_code ec; std::filesystem::create_directories(sd(p), ec); return !ec; }
int32_t fac_file_rename(FacStr *a, FacStr *b) { return rename(sd(a), sd(b)) == 0; }
int32_t fac_file_copy(FacStr *a, FacStr *b) { std::error_code ec; std::filesystem::copy_file(sd(a), sd(b), std::filesystem::copy_options::overwrite_existing, ec); return !ec; }
int32_t fac_sys_run(FacStr *cmd) { flush_out(); int r = system(sd(cmd));
#ifndef _WIN32
  return WIFEXITED(r) ? WEXITSTATUS(r) : -1;
#else
  return r;
#endif
}
FacStr *fac_sys_output(FacStr *cmd) {
  if (!cmd) do_throw("sys.output: null command", 15);
  constexpr size_t MAX_CAPTURE_BYTES = (size_t)64 << 20;
  flush_out();
#ifdef _WIN32
  FILE *f = _popen(sd(cmd), "r");
#else
  FILE *f = popen(sd(cmd), "r");
#endif
  if (!f) do_throw("sys.output: cannot run command", 15);
  std::string all; char b[8192]; size_t n = 0; bool tooLarge = false, readError = false;
  try {
    while ((n = fread(b, 1, sizeof b, f)) > 0) {
      if (!tooLarge) {
        if (all.size() > MAX_CAPTURE_BYTES || n > MAX_CAPTURE_BYTES - all.size()) {
          tooLarge = true; std::string().swap(all); // keep draining the pipe, but do not retain unbounded output
        } else all.append(b, n);
      }
    }
    readError = ferror(f) != 0;
  } catch (const std::bad_alloc &) { tooLarge = true; std::string().swap(all); }
#ifdef _WIN32
  const int closeResult = _pclose(f);
#else
  const int closeResult = pclose(f);
#endif
  if (tooLarge) do_throw("sys.output: captured output exceeds 64 MiB limit", 15);
  if (readError || closeResult == -1) { std::string().swap(all); do_throw("sys.output: failed while reading command output", 15); }
  return mks(all);
}
FacStr *fac_sys_cwd() { std::error_code ec; return mks(std::filesystem::current_path(ec).string()); }
int32_t fac_sys_chdir(FacStr *p) { std::error_code ec; std::filesystem::current_path(sd(p), ec); return !ec; }
int32_t fac_sys_pid() {
#ifdef _WIN32
  return (int32_t)_getpid();
#else
  return (int32_t)getpid();
#endif
}
FacStr *fac_sys_platform() {
#if defined(_WIN32)
  return mks("windows");
#elif defined(__APPLE__)
  return mks("macos");
#else
  return mks("linux");
#endif
}
int32_t fac_sys_cpus() { return (int32_t)std::max(1u, std::thread::hardware_concurrency()); }
FacStr *fac_sys_hostname() {
#ifdef _WIN32
  char b[256]; DWORD n = sizeof b; return GetComputerNameA(b, &n) ? mks(b) : mks("");
#else
  char b[256]; return gethostname(b, sizeof b) == 0 ? mks(b) : mks("");
#endif
}
// ================================================================ math / random / string extras
double fac_lerp(double a, double b, double t) { return a + (b - a) * t; }
double fac_clamp(double x, double lo, double hi) { return x < lo ? lo : x > hi ? hi : x; }
int32_t fac_sign(double x) { return x > 0 ? 1 : x < 0 ? -1 : 0; }
int32_t fac_isnan(double x) { return x != x; }
int32_t fac_isfinite(double x) { return std::isfinite(x) ? 1 : 0; }
double fac_degtorad(double degrees) { return degrees * 0.017453292519943295769236907684886; }
double fac_radtodeg(double radians) { return radians * 57.295779513082320876798154814105; }
double fac_smoothstep(double edge0, double edge1, double x) { if(!std::isfinite(edge0)||!std::isfinite(edge1)||!(edge1>edge0))do_throw("math.smoothstep: edges must be finite and edge1 > edge0",18); double t=std::max(0.0,std::min(1.0,(x-edge0)/(edge1-edge0))); return t*t*(3.0-2.0*t); }
double fac_wrap(double x, double lo, double hi) { if(!std::isfinite(lo)||!std::isfinite(hi)||!(hi>lo))do_throw("math.wrap: bounds must be finite and max > min",18); double span=hi-lo; double v=std::fmod(x-lo,span); if(v<0.0)v+=span; return lo+v; }
double fac_rand_gauss(double mean, double sd_) {
  if (!std::isfinite(mean) || !std::isfinite(sd_) || sd_ < 0)
    do_throw("random.gauss: mean and standard deviation must be finite and deviation non-negative", 8);
  if (sd_ == 0) return mean;
  std::normal_distribution<double> d(mean, sd_);
  return d(rng_engine());
}
double fac_rand_normal(double mean, double sd_) { return fac_rand_gauss(mean, sd_); }
double fac_rand_uniform_f64(double lo, double hi) {
  if (!std::isfinite(lo) || !std::isfinite(hi)) do_throw("random.uniform: bounds must be finite", 8);
  if (hi < lo) std::swap(lo, hi);
  if (lo == hi) return lo;
  return lo + (hi - lo) * fac_rand_f64(); // [lo, hi)
}
double fac_rand_triangular(double lo, double mode, double hi) {
  if (!std::isfinite(lo) || !std::isfinite(mode) || !std::isfinite(hi) || lo > mode || mode > hi || hi < lo)
    do_throw("random.triangular: require finite min <= mode <= max", 8);
  if (lo == hi) return lo;
  const double u = fac_rand_f64();
  const double split = (mode - lo) / (hi - lo);
  if (u < split) return lo + std::sqrt(u * (hi - lo) * (mode - lo));
  return hi - std::sqrt((1.0 - u) * (hi - lo) * (hi - mode));
}
double fac_rand_exponential(double lambda) {
  if (!std::isfinite(lambda) || lambda <= 0.0)
    do_throw("random.exponential: rate lambda must be finite and greater than zero", 8);
  return -std::log1p(-fac_rand_f64()) / lambda;
}
uint64_t fac_rand_poisson(double lambda) {
  if (!std::isfinite(lambda) || lambda < 0.0 || lambda > 1.0e12)
    do_throw("random.poisson: lambda must be finite and in [0, 1e12]", 8);
  if (lambda == 0.0) return 0;
  std::poisson_distribution<uint64_t> d(lambda);
  return d(rng_engine());
}

// Deterministic coordinate noise. It intentionally does not consume the RNG
// stream, so asking for the same point always returns the same value.
static uint64_t fac_noise_mix(uint64_t x) {
  x += UINT64_C(0x9E3779B97F4A7C15);
  x = (x ^ (x >> 30)) * UINT64_C(0xBF58476D1CE4E5B9);
  x = (x ^ (x >> 27)) * UINT64_C(0x94D049BB133111EB);
  return x ^ (x >> 31);
}
static uint64_t fac_noise_hash2(int64_t x, int64_t y) {
  return fac_noise_mix((uint64_t)x ^ fac_noise_mix((uint64_t)y + UINT64_C(0xD1B54A32D192ED03)));
}
static double fac_noise_fade(double t) { return t * t * t * (t * (t * 6.0 - 15.0) + 10.0); }
static double fac_noise_lerp(double a, double b, double t) { return a + (b - a) * t; }
static void fac_noise_check(double x, double y = 0.0) {
  constexpr double limit = 4503599627370496.0; // 2^52: cell precision is still meaningful
  if (!std::isfinite(x) || !std::isfinite(y) || std::fabs(x) >= limit || std::fabs(y) >= limit)
    do_throw("random noise: coordinates must be finite and have magnitude below 2^52", 8);
}
double fac_rand_perlin1(double x) {
  fac_noise_check(x);
  const double cell = std::floor(x), t = x - cell;
  const int64_t i = (int64_t)cell;
  const double g0 = (fac_noise_mix((uint64_t)i) & 1) ? -t : t;
  const double g1 = (fac_noise_mix((uint64_t)(i + 1)) & 1) ? -(t - 1.0) : (t - 1.0);
  return fac_noise_lerp(g0, g1, fac_noise_fade(t)) * 2.0;
}
static double fac_noise_grad2(uint64_t h, double x, double y) {
  static constexpr double k = 0.70710678118654752440;
  switch (h & 7u) {
    case 0: return x; case 1: return -x; case 2: return y; case 3: return -y;
    case 4: return (x + y) * k; case 5: return (x - y) * k;
    case 6: return (-x + y) * k; default: return (-x - y) * k;
  }
}
double fac_rand_perlin2(double x, double y) {
  fac_noise_check(x, y);
  const double fx = std::floor(x), fy = std::floor(y);
  const int64_t ix = (int64_t)fx, iy = (int64_t)fy;
  const double dx = x - fx, dy = y - fy;
  const double n00 = fac_noise_grad2(fac_noise_hash2(ix, iy), dx, dy);
  const double n10 = fac_noise_grad2(fac_noise_hash2(ix + 1, iy), dx - 1.0, dy);
  const double n01 = fac_noise_grad2(fac_noise_hash2(ix, iy + 1), dx, dy - 1.0);
  const double n11 = fac_noise_grad2(fac_noise_hash2(ix + 1, iy + 1), dx - 1.0, dy - 1.0);
  const double u = fac_noise_fade(dx), v = fac_noise_fade(dy);
  return fac_noise_lerp(fac_noise_lerp(n00, n10, u), fac_noise_lerp(n01, n11, u), v) * 1.4142135623730951;
}
double fac_rand_simplex1(double x) { return fac_rand_perlin1(x); }
double fac_rand_simplex2(double x, double y) {
  fac_noise_check(x, y);
  constexpr double F2 = 0.36602540378443864676;
  constexpr double G2 = 0.21132486540518711775;
  const double skew = (x + y) * F2;
  const int64_t i = (int64_t)std::floor(x + skew);
  const int64_t j = (int64_t)std::floor(y + skew);
  const double unskew = (double)(i + j) * G2;
  const double x0 = x - ((double)i - unskew), y0 = y - ((double)j - unskew);
  const int64_t i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
  const double x1 = x0 - (double)i1 + G2, y1 = y0 - (double)j1 + G2;
  const double x2 = x0 - 1.0 + 2.0 * G2, y2 = y0 - 1.0 + 2.0 * G2;
  auto corner = [](uint64_t h, double a, double b) {
    double t = 0.5 - a * a - b * b;
    if (t <= 0.0) return 0.0;
    t *= t;
    return t * t * fac_noise_grad2(h, a, b);
  };
  const double n0 = corner(fac_noise_hash2(i, j), x0, y0);
  const double n1 = corner(fac_noise_hash2(i + i1, j + j1), x1, y1);
  const double n2 = corner(fac_noise_hash2(i + 1, j + 1), x2, y2);
  return 70.0 * (n0 + n1 + n2);
}
double fac_rand_fbm1(double x, int32_t octaves) {
  if (octaves < 1 || octaves > 16) do_throw("random.fbm: octaves must be in [1, 16]", 8);
  double sum = 0.0, amplitude = 1.0, norm = 0.0, frequency = 1.0;
  for (int32_t i = 0; i < octaves; ++i) {
    sum += fac_rand_perlin1(x * frequency) * amplitude;
    norm += amplitude; amplitude *= 0.5; frequency *= 2.0;
  }
  return sum / norm;
}
double fac_rand_fbm2(double x, double y, int32_t octaves) {
  if (octaves < 1 || octaves > 16) do_throw("random.fbm: octaves must be in [1, 16]", 8);
  double sum = 0.0, amplitude = 1.0, norm = 0.0, frequency = 1.0;
  for (int32_t i = 0; i < octaves; ++i) {
    sum += fac_rand_perlin2(x * frequency, y * frequency) * amplitude;
    norm += amplitude; amplitude *= 0.5; frequency *= 2.0;
  }
  return sum / norm;
}
FacStr *fac_str_repeat(FacStr *s, int32_t n) { if (n > 0 && sl(s) > 0 && (int64_t)n * sl(s) > ((int64_t)1 << 30)) do_throw("string.repeat: result too large", 8); std::string r; for (int32_t i = 0; i < n; i++) r.append(sd(s), (size_t)sl(s)); return mks(r); }
static FacStr *padstr(FacStr *s, int32_t w, int32_t ch, bool left) {
  int64_t n = s ? s->ncp : 0; if (w <= n) return mk(sd(s), sl(s)); if (w > ((int32_t)1 << 28)) do_throw("string.pad: width too large", 8);
  std::string pad; for (int64_t i = n; i < w; i++) enc(pad, (uint32_t)ch); std::string x(sd(s), (size_t)sl(s));
  return mks(left ? pad + x : x + pad);
}
FacStr *fac_str_padleft(FacStr *s, int32_t w, int32_t ch) { return padstr(s, w, ch, true); }
FacStr *fac_str_padright(FacStr *s, int32_t w, int32_t ch) { return padstr(s, w, ch, false); }
FacStr *fac_str_reverse(FacStr *s) {
  std::vector<std::string> cps; const char *p = sd(s); int64_t n = sl(s);
  for (int64_t i = 0; i < n;) { int w; dec(p + i, &w); cps.push_back(std::string(p + i, (size_t)w)); i += w; }
  std::string r; for (size_t i = cps.size(); i > 0; i--) r += cps[i - 1]; return mks(r);
}
int32_t fac_str_count(FacStr *s, FacStr *sub) { if (!sl(sub)) return 0; std::string h(sd(s), (size_t)sl(s)), n(sd(sub), (size_t)sl(sub)); int32_t c = 0; size_t p = 0; while ((p = h.find(n, p)) != std::string::npos) { c++; p += n.size(); } return c; }
int32_t fac_str_lastfind(FacStr *s, FacStr *sub) { std::string h(sd(s), (size_t)sl(s)), n(sd(sub), (size_t)sl(sub)); size_t p = h.rfind(n); return p == std::string::npos ? -1 : (int32_t)countcp(h.data(), (int64_t)p); }
FacList *fac_str_lines(FacStr *s) {
  FacList *l = fac_list_new(8, 1); std::string all(sd(s), (size_t)sl(s)); size_t i = 0;
  while (i < all.size()) { size_t e = all.find('\n', i); if (e == std::string::npos) e = all.size(); std::string line = all.substr(i, e - i); if (!line.empty() && line.back() == '\r') line.pop_back(); FacStr *x = mks(line); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = x; i = e + 1; }
  return l;
}
FacStr *fac_str_capitalize(FacStr *s) { return fac_str_capitalize_u(s); }
int32_t fac_str_isnumber(FacStr *s) { std::string t(sd(s), (size_t)sl(s)); if (t.empty()) return 0; char *e; strtod(t.c_str(), &e); return *e == 0; }

}  // extern "C"

// ================================================================ byte/string bridge
static constexpr int32_t FAC_MAX_BYTE_LIST = 16 * 1024 * 1024;
static bool fac_list_is_i32_bytes(FacList *list) {
  return list && list->esz == (int32_t)sizeof(int32_t) && list->ek == 0 &&
         list->len >= 0 && list->len <= FAC_MAX_BYTE_LIST &&
         (list->len == 0 || list->data != nullptr);
}
static bool fac_utf8_valid_bytes(const int32_t *bytes, int64_t length) {
  int64_t i = 0;
  auto cont = [&](int64_t at) { return at < length && bytes[at] >= 0x80 && bytes[at] <= 0xBF; };
  while (i < length) {
    const int32_t c = bytes[i];
    if (c < 0 || c > 255) return false;
    if (c <= 0x7F) { ++i; continue; }
    if (c >= 0xC2 && c <= 0xDF) {
      if (!cont(i + 1)) return false; i += 2; continue;
    }
    if (c == 0xE0) {
      if (i + 2 >= length || bytes[i + 1] < 0xA0 || bytes[i + 1] > 0xBF || !cont(i + 2)) return false;
      i += 3; continue;
    }
    if ((c >= 0xE1 && c <= 0xEC) || (c >= 0xEE && c <= 0xEF)) {
      if (!cont(i + 1) || !cont(i + 2)) return false; i += 3; continue;
    }
    if (c == 0xED) {
      if (i + 2 >= length || bytes[i + 1] < 0x80 || bytes[i + 1] > 0x9F || !cont(i + 2)) return false;
      i += 3; continue;
    }
    if (c == 0xF0) {
      if (i + 3 >= length || bytes[i + 1] < 0x90 || bytes[i + 1] > 0xBF || !cont(i + 2) || !cont(i + 3)) return false;
      i += 4; continue;
    }
    if (c >= 0xF1 && c <= 0xF3) {
      if (!cont(i + 1) || !cont(i + 2) || !cont(i + 3)) return false; i += 4; continue;
    }
    if (c == 0xF4) {
      if (i + 3 >= length || bytes[i + 1] < 0x80 || bytes[i + 1] > 0x8F || !cont(i + 2) || !cont(i + 3)) return false;
      i += 4; continue;
    }
    return false;
  }
  return true;
}
extern "C" {
FacList *fac_str_tobytes(FacStr *text) {
  if (!text || sl(text) < 0 || sl(text) > FAC_MAX_BYTE_LIST) do_throw("string.toBytes: text exceeds 16 MiB byte limit", 8);
  const int64_t n = sl(text);
  FacList *out = fac_list_new((int32_t)sizeof(int32_t), 0);
  fac_tmp_push(out, 2);
  if (n) {
    while (out->cap < n) fac_list_grow(out);
    out->len = n;
    int32_t *dst = (int32_t *)out->data;
    for (int64_t i = 0; i < n; ++i) dst[i] = (unsigned char)sd(text)[i];
  }
  fac_tmp_pop(out);
  return out;
}
FacStr *fac_str_frombytes(FacList *bytes) {
  if (!fac_list_is_i32_bytes(bytes)) do_throw("string.fromBytes: expected list dyn int with at most 16 MiB", 13);
  const int64_t n = bytes->len;
  const int32_t *src = (const int32_t *)bytes->data;
  for (int64_t i = 0; i < n; ++i) if (src[i] < 0 || src[i] > 255) do_throw("string.fromBytes: byte outside [0,255]", 13);
  if (!fac_utf8_valid_bytes(src, n)) do_throw("string.fromBytes: input is not valid UTF-8", 13);
  if ((uint64_t)n > (uint64_t)SIZE_MAX - sizeof(FacStr) - 1) do_throw("string.fromBytes: size overflow", 5);
  FacStr *out = (FacStr *)fac_alloc_uninit((int64_t)(sizeof(FacStr) + (size_t)n + 1));
  out->data = reinterpret_cast<char *>(out + 1);
  for (int64_t i = 0; i < n; ++i) out->data[i] = (char)src[i];
  out->data[n] = 0; out->len = n; out->cap = n; out->ncp = countcp(out->data, n); out->flags = 2;
  return out;
}
}

// ================================================================ net (TCP + HTTP/1.1 แบบ http เท่านั้น)
#ifdef _WIN32
typedef SOCKET sock_t;
#define SOCK_BAD INVALID_SOCKET
static void sclose(sock_t s) { closesocket(s); }
#else
typedef int sock_t;
#define SOCK_BAD (-1)
static void sclose(sock_t s) { close(s); }
#endif
struct Sock { uint64_t opaque; }; // Stable opaque token; never dereferenced by the Runtime.
struct FacSocketState {
  sock_t fd = SOCK_BAD;
  std::mutex lifecycleMutex;
  std::condition_variable idle;
  std::mutex readMutex;
  std::mutex writeMutex;
  std::mutex optionMutex;
  size_t activeOperations = 0;
  bool closed = false;
  bool closing = false;
  bool transferring = false;
  bool transferred = false;
};

// shared_ptr locals also need an explicit cleanup record: FAC errors use longjmp,
// which bypasses C++ destructors in the active Runtime frame.
template <typename T>
struct FacSharedStateRefGuard {
  std::shared_ptr<T> value;
  bool registered = false;
  static void cleanup(void *raw) {
    auto *self = static_cast<FacSharedStateRefGuard *>(raw);
    if (!self) return;
    self->value.reset();
    self->registered = false;
  }
  FacSharedStateRefGuard() {
    fac_cleanup_push(this, 4, reinterpret_cast<void *>(&FacSharedStateRefGuard::cleanup));
    registered = true;
  }
  FacSharedStateRefGuard(const FacSharedStateRefGuard &) = delete;
  FacSharedStateRefGuard &operator=(const FacSharedStateRefGuard &) = delete;
  void set(std::shared_ptr<T> next) { value = std::move(next); }
  explicit operator bool() const noexcept { return (bool)value; }
  T *operator->() const noexcept { return value.get(); }
  T *get() const noexcept { return value.get(); }
  std::shared_ptr<T> &shared() noexcept { return value; }
  ~FacSharedStateRefGuard() noexcept {
    if (registered) { fac_cleanup_pop(); registered = false; }
    value.reset();
  }
};

// FAC errors use longjmp and therefore bypass C++ destructors. Resource guards
// register cleanup callbacks so locks/leases are released before the jump.
struct FacRuntimeMutexGuard {
  std::mutex *mutex = nullptr;
  bool locked = false;
  bool registered = false;
  static void cleanup(void *value) {
    auto *self = static_cast<FacRuntimeMutexGuard *>(value);
    if (self && self->locked) { self->locked = false; self->mutex->unlock(); }
    if (self) self->registered = false;
  }
  explicit FacRuntimeMutexGuard(std::mutex &m) : mutex(&m) {
    fac_cleanup_push(this, 4, reinterpret_cast<void *>(&FacRuntimeMutexGuard::cleanup));
    registered = true;
    try { mutex->lock(); locked = true; }
    catch (...) { fac_cleanup_pop(); registered = false; throw; }
  }
  FacRuntimeMutexGuard(const FacRuntimeMutexGuard &) = delete;
  FacRuntimeMutexGuard &operator=(const FacRuntimeMutexGuard &) = delete;
  void unlock() noexcept {
    if (registered) { fac_cleanup_pop(); registered = false; }
    if (locked) { locked = false; mutex->unlock(); }
  }
  ~FacRuntimeMutexGuard() noexcept { unlock(); }
};

struct FacSocketOperationGuard {
  std::shared_ptr<FacSocketState> state;
  std::mutex *directionMutex = nullptr;
  bool directionLocked = false;
  bool active = false;
  bool registered = false;
  static void cleanup(void *value) {
    auto *self = static_cast<FacSocketOperationGuard *>(value);
    if (!self) return;
    if (self->active) {
      { std::lock_guard<std::mutex> lock(self->state->lifecycleMutex);
        self->active = false;
        if (self->state->activeOperations) --self->state->activeOperations;
        if (self->state->activeOperations == 0) self->state->idle.notify_all();
      }
    }
    if (self->directionLocked) { self->directionLocked = false; self->directionMutex->unlock(); }
    self->state.reset();
    self->registered = false;
  }
  FacSocketOperationGuard(const std::shared_ptr<FacSocketState> &s, std::mutex &direction, const char *message)
      : directionMutex(&direction) {
    fac_cleanup_push(this, 4, reinterpret_cast<void *>(&FacSocketOperationGuard::cleanup));
    registered = true;
    state = s;
    if (!state) do_throw(message, 11);
    try { directionMutex->lock(); directionLocked = true; }
    catch (...) { fac_cleanup_pop(); registered = false; throw; }
    bool invalid = false;
    { std::lock_guard<std::mutex> lock(state->lifecycleMutex);
      invalid = state->closed || state->closing || state->transferring || state->transferred || state->fd == SOCK_BAD;
      if (!invalid) { ++state->activeOperations; active = true; }
    }
    if (invalid) do_throw(message, 11);
  }
  FacSocketOperationGuard(const FacSocketOperationGuard &) = delete;
  FacSocketOperationGuard &operator=(const FacSocketOperationGuard &) = delete;
  void unlock() noexcept {
    if (!registered) return;
    fac_cleanup_pop(); registered = false;
    cleanup(this);
  }
  ~FacSocketOperationGuard() noexcept { unlock(); }
};

struct FacSocketTransferGuard {
  std::shared_ptr<FacSocketState> state;
  bool transferring = false;
  bool registered = false;
  static void cleanup(void *value) {
    auto *self = static_cast<FacSocketTransferGuard *>(value);
    if (!self) return;
    if (self->transferring && self->state) {
      std::lock_guard<std::mutex> lock(self->state->lifecycleMutex);
      self->state->transferring = false;
      self->transferring = false;
      self->state->idle.notify_all();
    }
    self->state.reset();
    self->registered = false;
  }
  explicit FacSocketTransferGuard(const std::shared_ptr<FacSocketState> &s, const char *message) {
    fac_cleanup_push(this, 4, reinterpret_cast<void *>(&FacSocketTransferGuard::cleanup));
    registered = true;
    state = s;
    if (!state) do_throw(message, 11);
    try {
      std::unique_lock<std::mutex> lock(state->lifecycleMutex);
      if (state->closed || state->closing || state->transferring || state->transferred || state->fd == SOCK_BAD) {
        lock.unlock(); do_throw(message, 11);
      }
      state->transferring = true; transferring = true;
      state->idle.wait(lock, [&] { return state->activeOperations == 0; });
    } catch (...) {
      if (transferring) cleanup(this);
      if (registered) { fac_cleanup_pop(); registered = false; }
      throw;
    }
  }
  FacSocketTransferGuard(const FacSocketTransferGuard &) = delete;
  FacSocketTransferGuard &operator=(const FacSocketTransferGuard &) = delete;
  void commit(Sock *token);
  ~FacSocketTransferGuard() noexcept {
    if (registered) { fac_cleanup_pop(); registered = false; cleanup(this); }
  }
};

static std::mutex g_fac_socket_registry_mutex;
static std::unordered_map<Sock *, std::shared_ptr<FacSocketState>> g_fac_socket_registry;
static std::vector<std::unique_ptr<Sock>> g_fac_socket_tokens; // Tombstones prevent token-address reuse.
static std::atomic<uint64_t> g_fac_socket_token_counter{1};

static std::shared_ptr<FacSocketState> fac_socket_lookup(Sock *token) {
  if (!token) return {};
  std::lock_guard<std::mutex> lock(g_fac_socket_registry_mutex);
  auto it = g_fac_socket_registry.find(token);
  return it == g_fac_socket_registry.end() ? std::shared_ptr<FacSocketState>{} : it->second;
}
static void fac_socket_retire(Sock *token) {
  if (!token) return;
  std::lock_guard<std::mutex> lock(g_fac_socket_registry_mutex);
  g_fac_socket_registry.erase(token);
}
static Sock *fac_socket_make_handle(sock_t fd) {
  std::shared_ptr<FacSocketState> state;
  std::unique_ptr<Sock> token;
  try {
    state = std::make_shared<FacSocketState>();
    state->fd = fd;
    token.reset(new (std::nothrow) Sock{g_fac_socket_token_counter.fetch_add(1, std::memory_order_relaxed)});
    if (!token) { sclose(fd); state->fd = SOCK_BAD; return nullptr; }
    Sock *raw = token.get();
    std::lock_guard<std::mutex> lock(g_fac_socket_registry_mutex);
    g_fac_socket_tokens.push_back(std::move(token));
    auto inserted = g_fac_socket_registry.emplace(raw, state);
    if (!inserted.second) { sclose(fd); state->fd = SOCK_BAD; return nullptr; }
    return raw;
  } catch (...) {
    if (state && state->fd != SOCK_BAD) { sclose(state->fd); state->fd = SOCK_BAD; }
    else if (!state) sclose(fd);
    return nullptr;
  }
}
static void fac_socket_close_state(const std::shared_ptr<FacSocketState> &state, bool fromTls = false) {
  if (!state) return;
  sock_t fd = SOCK_BAD;
  std::unique_lock<std::mutex> lock(state->lifecycleMutex);
  if (state->closed) return;
  if (state->transferred && !fromTls) return;
  state->closing = true;
  state->idle.wait(lock, [&] { return state->activeOperations == 0 && !state->transferring; });
  if (state->transferred && !fromTls) { state->closing = false; state->idle.notify_all(); return; }
  state->closed = true;
  fd = state->fd; state->fd = SOCK_BAD;
  lock.unlock();
  if (fd != SOCK_BAD) sclose(fd);
}
void FacSocketTransferGuard::commit(Sock *token) {
  if (!transferring) return;
  {
    std::lock_guard<std::mutex> lock(state->lifecycleMutex);
    state->transferred = true;
    state->transferring = false;
    transferring = false;
    state->idle.notify_all();
  }
  fac_socket_retire(token);
  if (registered) { fac_cleanup_pop(); registered = false; }
  state.reset();
}
struct FacSocketUnwindClose {
  Sock *token = nullptr;
  std::shared_ptr<FacSocketState> state;
  bool registered = false;
  static void cleanup(void *value) {
    auto *self = static_cast<FacSocketUnwindClose *>(value);
    if (!self) return;
    if (self->state) {
      fac_socket_close_state(self->state);
      if (self->token) fac_socket_retire(self->token);
      self->state.reset();
    }
    self->registered = false;
  }
  explicit FacSocketUnwindClose(Sock *s) : token(s), state(fac_socket_lookup(s)) {
    fac_cleanup_push(this, 4, reinterpret_cast<void *>(&FacSocketUnwindClose::cleanup));
    registered = true;
  }
  FacSocketUnwindClose(const FacSocketUnwindClose &) = delete;
  FacSocketUnwindClose &operator=(const FacSocketUnwindClose &) = delete;
  ~FacSocketUnwindClose() { if (registered) { fac_cleanup_pop(); registered = false; } }
  void dismiss() { if (registered) { fac_cleanup_pop(); registered = false; } state.reset(); }
};
static void netinit() {
#ifdef _WIN32
  // C++11 guarantees thread-safe initialization of function-local statics.
  static const int startupResult = [] { WSADATA d{}; return WSAStartup(MAKEWORD(2, 2), &d); }();
  if (startupResult != 0) do_throw("net: WSAStartup failed", 11);
#endif
}
static std::string recvall(FacSocketState *s) {
  constexpr size_t MAX_BYTES = (size_t)64 << 20;
  std::string r; char b[8192];
  while (true) {
    int n = (int)recv(s->fd, b, sizeof b, 0);
    if (n <= 0) break;
    if ((size_t)n > MAX_BYTES - r.size()) { std::string().swap(r); do_throw("net.recvAll: response exceeds 64 MiB limit", 11); }
    try { r.append(b, (size_t)n); } catch (const std::bad_alloc &) { std::string().swap(r); do_throw("net.recvAll: out of memory", 5); }
  }
  return r;
}
static std::string recvall_limited(FacSocketState *s, size_t maxBytes, int deadlineSec) {
  std::string r; char b[8192];
  auto t0 = std::chrono::steady_clock::now();
  while (true) {
    int n = (int)recv(s->fd, b, sizeof b, 0);
    if (n <= 0) break;
    if (r.size() + (size_t)n > maxBytes) do_throw("net: response too large", 11);
    r.append(b, (size_t)n);
    if (std::chrono::steady_clock::now() - t0 > std::chrono::seconds(deadlineSec)) do_throw("net: http request timed out", 11);
  }
  return r;
}
static void sendall(FacSocketState *s, const std::string &d) {
  size_t o = 0;
  while (o < d.size()) {
#ifdef MSG_NOSIGNAL
    int fl = MSG_NOSIGNAL;
#else
    int fl = 0;
#endif
    int n = (int)send(s->fd, d.data() + o, (int)std::min<size_t>(d.size() - o, 1 << 20), fl);
    if (n <= 0) do_throw("net: send failed", 11);
    o += (size_t)n;
  }
}
extern "C" {
Sock *fac_net_connect(FacStr *host, int32_t port) {
  if (!host || !sd(host)[0] || sl(host) > 253) do_throw("net: host must contain 1..253 bytes", 11);
  for (int64_t i = 0; i < sl(host); ++i) { unsigned char c = (unsigned char)sd(host)[i]; if (c <= 0x20 || c == 0x7f) do_throw("net: host contains whitespace or control bytes", 11); }
  if (port < 1 || port > 65535) do_throw("net: port must be between 1 and 65535", 11);
  netinit(); struct addrinfo hints = {}, *res = nullptr; hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM;
  if (getaddrinfo(sd(host), std::to_string(port).c_str(), &hints, &res) != 0) do_throw(std::string("net: cannot resolve ") + sd(host), 11);
  sock_t fd = SOCK_BAD;
  for (auto *a = res; a; a = a->ai_next) { fd = socket(a->ai_family, a->ai_socktype, a->ai_protocol); if (fd == SOCK_BAD) continue; if (connect(fd, a->ai_addr, (int)a->ai_addrlen) == 0) break; sclose(fd); fd = SOCK_BAD; }
  freeaddrinfo(res);
  if (fd == SOCK_BAD) do_throw(std::string("net: cannot connect to ") + sd(host) + ":" + std::to_string(port), 11);
  Sock *out = fac_socket_make_handle(fd);
  if (!out) do_throw("net: out of memory creating socket handle", 5);
  return out;
}
Sock *fac_net_listen(int32_t port) {
  if (port < 0 || port > 65535) do_throw("net: port must be between 0 and 65535", 11);
  netinit(); sock_t fd = socket(AF_INET, SOCK_STREAM, 0); if (fd == SOCK_BAD) do_throw("net: cannot create socket", 11);
  int one = 1;
#ifdef _WIN32
  if (setsockopt(fd, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, (const char *)&one, sizeof one) != 0) { sclose(fd); do_throw("net: cannot set exclusive listener ownership", 11); }
#else
  if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&one, sizeof one) != 0) { sclose(fd); do_throw("net: cannot configure listener socket", 11); }
#endif
  struct sockaddr_in a = {}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_ANY); a.sin_port = htons((uint16_t)port);
  if (bind(fd, (struct sockaddr *)&a, sizeof a) != 0 || listen(fd, 16) != 0) { sclose(fd); do_throw("net: cannot listen on port " + std::to_string(port), 11); }
  Sock *out = fac_socket_make_handle(fd);
  if (!out) do_throw("net: out of memory creating listener handle", 5);
  return out;
}
int32_t fac_net_localport(Sock *s) {
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) return -1;
  FacSocketOperationGuard lock(state.shared(), state->optionMutex, "net.localPort: stale or closed socket");
  struct sockaddr_in a{}; socklen_t l = sizeof a;
  if (getsockname(state->fd, (struct sockaddr *)&a, &l) != 0) return -1;
  return ntohs(a.sin_port);
}
Sock *fac_net_accept(Sock *s) {
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s));
  if (!state) do_throw("net: null, stale or closed listening socket", 11);
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net: null, stale or closed listening socket");
  sock_t fd = accept(state->fd, nullptr, nullptr);
  if (fd == SOCK_BAD) do_throw("net: accept failed", 11);
  Sock *out = fac_socket_make_handle(fd);
  if (!out) do_throw("net: out of memory creating accepted socket", 5);
  return out;
}
int32_t fac_net_send(Sock *s, FacStr *d) {
  if (!d) do_throw("net.send: null socket or data", 11);
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.send: null, stale or closed socket", 11);
  FacSocketOperationGuard lock(state.shared(), state->writeMutex, "net.send: null, stale or closed socket");
  sendall(state.get(), std::string(sd(d), (size_t)sl(d))); return (int32_t)sl(d);
}
int32_t fac_net_sendbytes(Sock *s, FacList *bytes) {
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.sendBytes: null, stale or closed socket", 11);
  if (!fac_list_is_i32_bytes(bytes)) do_throw("net.sendBytes: expected list dyn int with at most 16 MiB", 13);
  const int32_t *src = (const int32_t *)bytes->data;
  for (int64_t i = 0; i < bytes->len; ++i) if (src[i] < 0 || src[i] > 255) do_throw("net.sendBytes: byte outside [0,255]", 13);
  FacSocketOperationGuard lock(state.shared(), state->writeMutex, "net.sendBytes: null, stale or closed socket");
  char chunk[8192]; int64_t offset = 0;
  while (offset < bytes->len) {
    const int count = (int)std::min<int64_t>((int64_t)sizeof chunk, bytes->len - offset);
    for (int i = 0; i < count; ++i) chunk[i] = (char)src[offset + i];
    size_t sent = 0;
    while (sent < (size_t)count) {
#ifdef MSG_NOSIGNAL
      int flags = MSG_NOSIGNAL;
#else
      int flags = 0;
#endif
      int n = (int)send(state->fd, chunk + sent, (int)((size_t)count - sent), flags);
      if (n <= 0) do_throw("net.sendBytes: send failed", 11);
      sent += (size_t)n;
    }
    offset += count;
  }
  return (int32_t)bytes->len;
}
FacStr *fac_net_recv(Sock *s, int32_t max) {
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.recv: null, stale or closed socket", 11);
  std::string b((size_t)std::min(std::max(max, 1), 1 << 24), 0);
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net.recv: null, stale or closed socket");
  int n = (int)recv(state->fd, &b[0], (int)b.size(), 0);
  lock.unlock(); // Release before allocating the FAC result.
  return mk(b.data(), n > 0 ? n : 0);
}
FacStr *fac_net_recvexact(Sock *s, int32_t count) {
  constexpr int32_t MAX_EXACT = 64 * 1024 * 1024;
  if (count < 0 || count > MAX_EXACT) do_throw("net.recvExact: count must be between 0 and 64 MiB", 11);
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.recvExact: null, stale or closed socket", 11);
  std::string data((size_t)count, '\0');
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net.recvExact: null, stale or closed socket");
  size_t offset = 0;
  while (offset < data.size()) {
    int want = (int)std::min<size_t>(data.size() - offset, 1u << 20);
    int n = (int)recv(state->fd, &data[offset], want, 0);
    if (n < 0) do_throw("net.recvExact: receive failed or timed out", 11);
    if (n == 0) do_throw("net.recvExact: connection closed before requested byte count", 11);
    offset += (size_t)n;
  }
  lock.unlock();
  return mks(data);
}
FacList *fac_net_recvexactbytes(Sock *s, int32_t count) {
  if (count < 0 || count > FAC_MAX_BYTE_LIST) do_throw("net.recvExactBytes: count must be between 0 and 16 MiB", 11);
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.recvExactBytes: null, stale or closed socket", 11);
  FacList *out = fac_list_new((int32_t)sizeof(int32_t), 0); fac_tmp_push(out, 2);
  if (count > 0) { while (out->cap < count) fac_list_grow(out); out->len = count; }
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net.recvExactBytes: null, stale or closed socket");
  if (count > 0) {
    int32_t *dst = (int32_t *)out->data; char chunk[8192]; int32_t offset = 0;
    while (offset < count) {
      const int want = std::min<int32_t>((int32_t)sizeof chunk, count - offset);
      int n = (int)recv(state->fd, chunk, want, 0);
      if (n < 0) do_throw("net.recvExactBytes: receive failed or timed out", 11);
      if (n == 0) do_throw("net.recvExactBytes: connection closed before requested byte count", 11);
      for (int i = 0; i < n; ++i) dst[offset + i] = (unsigned char)chunk[i];
      offset += n;
    }
  }
  lock.unlock();
  fac_tmp_pop(out); return out;
}
FacStr *fac_net_recvlinestrict(Sock *s) {
  constexpr size_t MAX_LINE = 1024u * 1024u;
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.recvLineStrict: null, stale or closed socket", 11);
  std::string line; char c = 0;
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net.recvLineStrict: null, stale or closed socket");
  while (true) {
    int n = (int)recv(state->fd, &c, 1, 0);
    if (n < 0) do_throw("net.recvLineStrict: receive failed or timed out", 11);
    if (n == 0) do_throw("net.recvLineStrict: connection closed before CRLF", 11);
    if (c == '\n') { if (line.empty() || line.back() != '\r') do_throw("net.recvLineStrict: line must end with CRLF", 10); line.pop_back(); break; }
    if (!line.empty() && line.back() == '\r') do_throw("net.recvLineStrict: CR must be followed by LF", 10);
    if (line.size() >= MAX_LINE) do_throw("net.recvLineStrict: line exceeds 1 MiB limit", 10);
    line.push_back(c);
  }
  lock.unlock();
  return mks(line);
}
FacStr *fac_net_recvline(Sock *s) {
  constexpr size_t MAX_LINE = 1024u * 1024u;
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.recvLine: null, stale or closed socket", 11);
  std::string r; char c = 0;
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net.recvLine: null, stale or closed socket");
  while (true) { int n = (int)recv(state->fd, &c, 1, 0); if (n <= 0 || c == '\n') break; if (r.size() >= MAX_LINE) do_throw("net: line exceeds 1 MiB limit", 11); r += c; }
  if (!r.empty() && r.back() == '\r') r.pop_back();
  lock.unlock();
  return mks(r);
}
void fac_net_close(Sock *s) {
  if (!s) return;
  auto state = fac_socket_lookup(s); if (!state) return;
  fac_socket_close_state(state);
  fac_socket_retire(s);
}

static int parseHttpPort(const char *text) {
  if (!text || !*text) do_throw("net: invalid port in url", 11);
  errno = 0; char *end = nullptr;
  long value = strtol(text, &end, 10);
  if (errno == ERANGE || end == text || !end || *end != '\0' || value < 1 || value > 65535)
    do_throw("net: invalid port in url", 11);
  return (int)value;
}
static std::string httpTrimOWS(const std::string &s) {
  size_t a = 0, b = s.size();
  while (a < b && (s[a] == ' ' || s[a] == '\t')) ++a;
  while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t')) --b;
  return s.substr(a, b - a);
}
static std::string httpLower(std::string s) {
  for (char &c : s) c = (char)tolower((unsigned char)c);
  return s;
}
static bool httpTokenChar(unsigned char c) {
  return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
         c == '!' || c == '#' || c == '$' || c == '%' || c == '&' || c == '\'' || c == '*' ||
         c == '+' || c == '-' || c == '.' || c == '^' || c == '_' || c == '`' || c == '|' || c == '~';
}
static unsigned long long httpParseDecimal(const std::string &s) {
  if (s.empty()) do_throw("net: invalid Content-Length", 11);
  unsigned long long n = 0;
  for (unsigned char c : s) {
    if (c < '0' || c > '9' || n > (std::numeric_limits<unsigned long long>::max() - (unsigned)(c - '0')) / 10)
      do_throw("net: invalid Content-Length", 11);
    n = n * 10 + (unsigned)(c - '0');
  }
  return n;
}
static std::string httpDecodeChunked(const std::string &body, size_t maxBytes) {
  std::string out; size_t pos = 0;
  while (true) {
    size_t e = body.find("\r\n", pos);
    if (e == std::string::npos || e - pos > 8192) do_throw("net: truncated chunked response", 11);
    std::string sizeLine = body.substr(pos, e - pos);
    size_t semi = sizeLine.find(';');
    if (semi != std::string::npos) sizeLine.resize(semi);
    if (sizeLine.empty() || sizeLine.size() > 16 || sizeLine.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos)
      do_throw("net: malformed chunk size", 11);
    errno = 0; char *end = nullptr;
    unsigned long long n = strtoull(sizeLine.c_str(), &end, 16);
    if (errno == ERANGE || !end || *end != '\0') do_throw("net: malformed chunk size", 11);
    pos = e + 2;
    if (n == 0) {
      // The zero-size chunk is followed by zero or more trailer fields and a final empty line.
      while (true) {
        size_t te = body.find("\r\n", pos);
        if (te == std::string::npos) do_throw("net: truncated chunked response trailers", 11);
        if (te == pos) {
          pos += 2;
          if (pos != body.size()) do_throw("net: unexpected bytes after chunked response", 11);
          return out;
        }
        std::string trailer = body.substr(pos, te - pos);
        size_t colon = trailer.find(':');
        if (colon == std::string::npos || colon == 0 || !std::all_of(trailer.begin(), trailer.begin() + (ptrdiff_t)colon,
              [](unsigned char c) { return httpTokenChar(c); }))
          do_throw("net: malformed chunked response trailer", 11);
        for (size_t i = colon + 1; i < trailer.size(); ++i) {
          unsigned char c = (unsigned char)trailer[i];
          if ((c < 0x20 && c != '\t') || c == 0x7f) do_throw("net: malformed chunked response trailer", 11);
        }
        pos = te + 2;
      }
    }
    if (n > (unsigned long long)(body.size() - pos)) do_throw("net: truncated chunked response", 11);
    if (n > (unsigned long long)(maxBytes - out.size())) do_throw("net: chunked response too large", 11);
    out.append(body, pos, (size_t)n);
    pos += (size_t)n;
    if (body.compare(pos, 2, "\r\n") != 0) do_throw("net: malformed chunk terminator", 11);
    pos += 2;
  }
}
static std::string httpreq(const std::string &method, const std::string &url, const std::string &body) {
  if (url.compare(0, 8, "https://") == 0) do_throw("net: https ยังไม่รองรับ (ใช้ extern + libcurl)", 11);
  if (url.compare(0, 7, "http://") != 0) do_throw("net: url ต้องขึ้นต้นด้วย http://", 11);
  std::string rest = url.substr(7), path = "/", hp = rest;
  size_t targetStart = rest.find_first_of("/?#");
  if (targetStart != std::string::npos) {
    hp = rest.substr(0, targetStart);
    if (rest[targetStart] == '/') path = rest.substr(targetStart);
    else if (rest[targetStart] == '?') path = "/" + rest.substr(targetStart);
    // A fragment is client-side only and is never sent in an HTTP request target.
  }
  size_t fragment = path.find('#'); if (fragment != std::string::npos) path.resize(fragment);
  if (path.empty()) path = "/";
  for (unsigned char ch : url) if (ch <= 0x20 || ch == 0x7f) do_throw("net: url contains control characters or spaces (encode them first)", 11);   // prevent request/header injection
  std::string host; int port = 80;
  if (!hp.empty() && hp[0] == '[') {
    size_t close = hp.find(']');
    if (close == std::string::npos) do_throw("net: invalid bracketed IPv6 host", 11);
    host = hp.substr(1, close - 1);
    if (close + 1 < hp.size()) {
      if (hp[close + 1] != ':') do_throw("net: invalid authority after IPv6 host", 11);
      port = parseHttpPort(hp.c_str() + close + 2);
    }
  } else {
    size_t c = hp.rfind(':');
    if (c != std::string::npos && hp.find(':') == c) {
      host = hp.substr(0, c);
      port = parseHttpPort(hp.c_str() + c + 1);
    } else host = hp;
  }
  if (host.empty() || port <= 0 || port > 65535) do_throw("net: invalid host or port in url", 11);
  FacStr *h = mks(host); Sock *s = fac_net_connect(h, port); fac_str_free(h);
  FacSocketUnwindClose socketCleanup(s);
  if (!socketCleanup.state) do_throw("net: socket became unavailable before HTTP request", 11);
  std::string req = method + " " + path + " HTTP/1.1\r\nHost: " + hp + "\r\nConnection: close\r\nUser-Agent: fac\r\n";
  if (method == "POST") req += "Content-Length: " + std::to_string(body.size()) + "\r\nContent-Type: text/plain\r\n";
  req += "\r\n" + body;
  std::string resp;
  {
    {
      FacSocketOperationGuard optionLock(socketCleanup.state, socketCleanup.state->optionMutex, "net: HTTP socket is closed");
#ifdef _WIN32
    DWORD tv = 30000;
    const bool timeoutOk = setsockopt(socketCleanup.state->fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv) == 0 &&
                           setsockopt(socketCleanup.state->fd, SOL_SOCKET, SO_SNDTIMEO, (const char *)&tv, sizeof tv) == 0;
#else
    struct timeval tv; tv.tv_sec = 30; tv.tv_usec = 0;
    const bool timeoutOk = setsockopt(socketCleanup.state->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv) == 0 &&
                           setsockopt(socketCleanup.state->fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv) == 0;
#endif
      if (!timeoutOk) do_throw("net: cannot configure HTTP socket timeout", 11);
    }
    { FacSocketOperationGuard writeLock(socketCleanup.state, socketCleanup.state->writeMutex, "net: HTTP socket is closed");
      sendall(socketCleanup.state.get(), req);
    }
    { FacSocketOperationGuard readLock(socketCleanup.state, socketCleanup.state->readMutex, "net: HTTP socket is closed");
      resp = recvall_limited(socketCleanup.state.get(), (size_t)64 << 20, 60);
    }
  }
  fac_net_close(s);
  socketCleanup.dismiss();
  size_t he = std::string::npos, lineEnd = std::string::npos;
  std::string head, statusLine; int status = 0;
  // Ignore informational responses (100 Continue / 103 Early Hints) and parse the final response.
  while (true) {
    he = resp.find("\r\n\r\n");
    if (he == std::string::npos) do_throw("net: malformed http response", 11);
    head = resp.substr(0, he);
    lineEnd = head.find("\r\n");
    statusLine = lineEnd == std::string::npos ? head : head.substr(0, lineEnd);
    if (statusLine.size() < 12 ||
        (statusLine.compare(0, 9, "HTTP/1.1 ") != 0 && statusLine.compare(0, 9, "HTTP/1.0 ") != 0) ||
        statusLine[9] < '0' || statusLine[9] > '9' || statusLine[10] < '0' || statusLine[10] > '9' ||
        statusLine[11] < '0' || statusLine[11] > '9' || (statusLine.size() > 12 && statusLine[12] != ' '))
      do_throw("net: malformed HTTP status line", 11);
    status = (statusLine[9] - '0') * 100 + (statusLine[10] - '0') * 10 + (statusLine[11] - '0');
    if (status < 100 || status > 599) do_throw("net: malformed HTTP status line", 11);
    if (status == 101) do_throw("net: HTTP protocol upgrades are not supported", 11);
    if (status < 200) { resp.erase(0, he + 4); continue; }
    break;
  }
  std::string bod = resp.substr(he + 4);
  bool hasLength = false, hasTransferEncoding = false;
  unsigned long long contentLength = 0;
  size_t pos = lineEnd == std::string::npos ? head.size() : lineEnd + 2;
  while (pos < head.size()) {
    size_t e = head.find("\r\n", pos);
    if (e == std::string::npos) e = head.size();
    std::string line = head.substr(pos, e - pos);
    size_t colon = line.find(':');
    if (colon == std::string::npos || colon == 0 || line[0] == ' ' || line[0] == '\t' ||
        !std::all_of(line.begin(), line.begin() + (ptrdiff_t)colon, [](unsigned char c) { return httpTokenChar(c); }))
      do_throw("net: malformed HTTP header", 11);
    std::string name = httpLower(line.substr(0, colon));
    std::string value = httpTrimOWS(line.substr(colon + 1));
    for (unsigned char c : value) if ((c < 0x20 && c != '\t') || c == 0x7f) do_throw("net: malformed HTTP header", 11);
    if (name == "content-length") {
      unsigned long long parsed = httpParseDecimal(value);
      if (hasLength && parsed != contentLength) do_throw("net: conflicting Content-Length headers", 11);
      hasLength = true; contentLength = parsed;
    } else if (name == "transfer-encoding") {
      if (hasTransferEncoding || httpLower(value) != "chunked") do_throw("net: unsupported Transfer-Encoding", 11);
      hasTransferEncoding = true;
    }
    pos = e + 2;
  }
  if (hasLength && hasTransferEncoding) do_throw("net: response has both Transfer-Encoding and Content-Length", 11);
  if (status == 204 || status == 304) bod.clear();
  else if (hasTransferEncoding) bod = httpDecodeChunked(bod, (size_t)64 << 20);
  else if (hasLength) {
    if (contentLength > ((unsigned long long)64 << 20)) do_throw("net: response too large", 11);
    if (contentLength > (unsigned long long)bod.size()) do_throw("net: truncated HTTP body", 11);
    if (contentLength < (unsigned long long)bod.size()) do_throw("net: unexpected bytes after HTTP body", 11);
    bod.resize((size_t)contentLength);
  }
  if (status >= 400 || status == 0) do_throw("http " + std::to_string(status) + ": " + bod.substr(0, 200), 11);
  return bod;
}
FacStr *fac_net_httpget(FacStr *url) { return mks(httpreq("GET", std::string(sd(url), (size_t)sl(url)), "")); }
FacStr *fac_net_httppost(FacStr *url, FacStr *body) { return mks(httpreq("POST", std::string(sd(url), (size_t)sl(url)), std::string(sd(body), (size_t)sl(body)))); }
}
// ================================================================ optional TLS transport (OpenSSL loaded dynamically)
// OpenSSL is intentionally not a build-time dependency. On POSIX systems this
// backend loads OpenSSL 1.1.1+ / 3.x at runtime; Windows remains unavailable in
// this release until a Schannel backend can be implemented and audited.
struct FacTlsHandle { uint64_t opaque; }; // Stable opaque token; never dereferenced by the Runtime.
#ifndef _WIN32
struct FacTlsApi {
  void *sslLib = nullptr;
  void *cryptoLib = nullptr;
  const void *(*clientMethod)() = nullptr;
  const void *(*serverMethod)() = nullptr;
  void *(*ctxNew)(const void *) = nullptr;
  void (*ctxFree)(void *) = nullptr;
  long (*ctxCtrl)(void *, int, long, void *) = nullptr;
  void (*ctxSetVerify)(void *, int, void *) = nullptr;
  int (*ctxDefaultVerifyPaths)(void *) = nullptr;
  int (*ctxUseCertChain)(void *, const char *) = nullptr;
  int (*ctxUsePrivateKey)(void *, const char *, int) = nullptr;
  int (*ctxCheckPrivateKey)(const void *) = nullptr;
  void *(*sslNew)(void *) = nullptr;
  void (*sslFree)(void *) = nullptr;
  int (*sslSetFd)(void *, int) = nullptr;
  int (*sslSet1Host)(void *, const char *) = nullptr;
  long (*sslCtrl)(void *, int, long, void *) = nullptr;
  int (*sslConnect)(void *) = nullptr;
  int (*sslAccept)(void *) = nullptr;
  int (*sslRead)(void *, void *, int) = nullptr;
  int (*sslWrite)(void *, const void *, int) = nullptr;
  int (*sslGetError)(const void *, int) = nullptr;
  long (*sslGetVerifyResult)(const void *) = nullptr;
  const char *(*sslGetVersion)(const void *) = nullptr;
  const void *(*sslGetCurrentCipher)(const void *) = nullptr;
  const char *(*cipherGetName)(const void *) = nullptr;
  int (*sslShutdown)(void *) = nullptr;
  unsigned long (*errGetError)() = nullptr;
  void (*errErrorString)(unsigned long, char *, size_t) = nullptr;
  bool ready = false;

  template <class T> static bool symbol(T &out, void *lib, const char *name) {
    if (!lib) return false;
    void *p = dlsym(lib, name);
    if (!p || sizeof(out) != sizeof(p)) return false;
    memcpy(&out, &p, sizeof(p));
    return true;
  }

  FacTlsApi() {
#if defined(__APPLE__)
    const char *sslNames[] = {"libssl.3.dylib", "libssl.dylib", nullptr};
    const char *cryptoNames[] = {"libcrypto.3.dylib", "libcrypto.dylib", nullptr};
#else
    const char *sslNames[] = {"libssl.so.3", "libssl.so.1.1", "libssl.so", nullptr};
    const char *cryptoNames[] = {"libcrypto.so.3", "libcrypto.so.1.1", "libcrypto.so", nullptr};
#endif
    for (const char **p = sslNames; *p && !sslLib; ++p) sslLib = dlopen(*p, RTLD_NOW | RTLD_LOCAL);
    for (const char **p = cryptoNames; *p && !cryptoLib; ++p) cryptoLib = dlopen(*p, RTLD_NOW | RTLD_LOCAL);
#define FAC_TLS_SSL_SYM(field, name) symbol(field, sslLib, name)
#define FAC_TLS_CRYPTO_SYM(field, name) symbol(field, cryptoLib, name)
    bool ok = true;
    ok &= FAC_TLS_SSL_SYM(clientMethod, "TLS_client_method");
    ok &= FAC_TLS_SSL_SYM(serverMethod, "TLS_server_method");
    ok &= FAC_TLS_SSL_SYM(ctxNew, "SSL_CTX_new");
    ok &= FAC_TLS_SSL_SYM(ctxFree, "SSL_CTX_free");
    ok &= FAC_TLS_SSL_SYM(ctxCtrl, "SSL_CTX_ctrl");
    ok &= FAC_TLS_SSL_SYM(ctxSetVerify, "SSL_CTX_set_verify");
    ok &= FAC_TLS_SSL_SYM(ctxDefaultVerifyPaths, "SSL_CTX_set_default_verify_paths");
    ok &= FAC_TLS_SSL_SYM(ctxUseCertChain, "SSL_CTX_use_certificate_chain_file");
    ok &= FAC_TLS_SSL_SYM(ctxUsePrivateKey, "SSL_CTX_use_PrivateKey_file");
    ok &= FAC_TLS_SSL_SYM(ctxCheckPrivateKey, "SSL_CTX_check_private_key");
    ok &= FAC_TLS_SSL_SYM(sslNew, "SSL_new");
    ok &= FAC_TLS_SSL_SYM(sslFree, "SSL_free");
    ok &= FAC_TLS_SSL_SYM(sslSetFd, "SSL_set_fd");
    ok &= FAC_TLS_SSL_SYM(sslSet1Host, "SSL_set1_host");
    ok &= FAC_TLS_SSL_SYM(sslCtrl, "SSL_ctrl");
    ok &= FAC_TLS_SSL_SYM(sslConnect, "SSL_connect");
    ok &= FAC_TLS_SSL_SYM(sslAccept, "SSL_accept");
    ok &= FAC_TLS_SSL_SYM(sslRead, "SSL_read");
    ok &= FAC_TLS_SSL_SYM(sslWrite, "SSL_write");
    ok &= FAC_TLS_SSL_SYM(sslGetError, "SSL_get_error");
    ok &= FAC_TLS_SSL_SYM(sslGetVerifyResult, "SSL_get_verify_result");
    ok &= FAC_TLS_SSL_SYM(sslGetVersion, "SSL_get_version");
    ok &= FAC_TLS_SSL_SYM(sslGetCurrentCipher, "SSL_get_current_cipher");
    ok &= FAC_TLS_SSL_SYM(cipherGetName, "SSL_CIPHER_get_name");
    ok &= FAC_TLS_SSL_SYM(sslShutdown, "SSL_shutdown");
    ok &= FAC_TLS_CRYPTO_SYM(errGetError, "ERR_get_error");
    ok &= FAC_TLS_CRYPTO_SYM(errErrorString, "ERR_error_string_n");
#undef FAC_TLS_SSL_SYM
#undef FAC_TLS_CRYPTO_SYM
    ready = ok;
  }
};
static FacTlsApi &fac_tls_api() { static FacTlsApi api; return api; }
static std::string fac_tls_error(FacTlsApi &api, const char *prefix, void *ssl = nullptr, int result = 0) {
  int kind = ssl ? api.sslGetError(ssl, result) : 0;
  unsigned long e = api.errGetError();
  char detail[256] = {};
  if (e) api.errErrorString(e, detail, sizeof detail);
  std::string message(prefix);
  if (detail[0]) message += std::string(": ") + detail;
  else if (kind == 2) message += ": TLS operation wants more input";
  else if (kind == 3) message += ": TLS operation wants output";
  else if (kind == 6) message += ": peer sent TLS close_notify";
  else message += ": TLS backend operation failed";
  return message;
}
static void fac_tls_free_parts(FacTlsApi &api, void *ctx, void *ssl) {
  if (ssl) api.sslFree(ssl);
  if (ctx) api.ctxFree(ctx);
}
struct FacTlsState {
  std::shared_ptr<FacSocketState> socket;
  void *ctx = nullptr;
  void *ssl = nullptr;
  std::mutex mutex;
  std::atomic<bool> closing{false};
  bool active = true;
};
static std::mutex g_fac_tls_registry_mutex;
static std::unordered_map<FacTlsHandle *, std::shared_ptr<FacTlsState>> g_fac_tls_registry;
static std::vector<std::unique_ptr<FacTlsHandle>> g_fac_tls_tokens;
static std::atomic<uint64_t> g_fac_tls_token_counter{1};
static std::shared_ptr<FacTlsState> fac_tls_lookup(FacTlsHandle *token) {
  if (!token) return {};
  std::lock_guard<std::mutex> lock(g_fac_tls_registry_mutex);
  auto it = g_fac_tls_registry.find(token);
  return it == g_fac_tls_registry.end() ? std::shared_ptr<FacTlsState>{} : it->second;
}
static void fac_tls_retire(FacTlsHandle *token) {
  if (!token) return;
  std::lock_guard<std::mutex> lock(g_fac_tls_registry_mutex);
  g_fac_tls_registry.erase(token);
}
static FacTlsHandle *fac_tls_wrap(Sock *socketToken, const std::shared_ptr<FacSocketState> &socketState, FacSocketTransferGuard &socketTransfer, void *ctx, void *ssl) {
  std::shared_ptr<FacTlsState> state;
  std::unique_ptr<FacTlsHandle> token;
  try {
    state = std::make_shared<FacTlsState>();
    state->socket = socketState; state->ctx = ctx; state->ssl = ssl;
    token.reset(new (std::nothrow) FacTlsHandle{g_fac_tls_token_counter.fetch_add(1, std::memory_order_relaxed)});
    if (!token) throw std::bad_alloc();
    FacTlsHandle *raw = token.get();
    {
      std::lock_guard<std::mutex> lock(g_fac_tls_registry_mutex);
      g_fac_tls_tokens.push_back(std::move(token));
      auto inserted = g_fac_tls_registry.emplace(raw, state);
      if (!inserted.second) throw std::bad_alloc();
    }
    // The transfer reservation drained prior socket operations and prevents
    // new ones until TLS takes ownership. Old aliases become stale atomically.
    socketTransfer.commit(socketToken);
    return raw;
  } catch (...) {
    fac_tls_free_parts(fac_tls_api(), ctx, ssl);
    return nullptr;
  }
}
static bool fac_tls_want_retry(FacTlsApi &api, void *ssl, int result) {
  int error = api.sslGetError(ssl, result);
  return error == 2 || error == 3;
}
static void fac_tls_require_open(const std::shared_ptr<FacTlsState> &state, const char *message) {
  if (!state || state->closing.load(std::memory_order_acquire) || !state->active || !state->ssl) do_throw(message, 11);
}

#endif

extern "C" {
int32_t fac_tls_available() {
#ifndef _WIN32
  return fac_tls_api().ready ? 1 : 0;
#else
  return 0;
#endif
}
FacTlsHandle *fac_tls_wrapclient(Sock *socket, FacStr *serverName) {
#ifndef _WIN32
  if (!serverName) do_throw("tls.wrapClient: invalid server name", 4);
  FacSharedStateRefGuard<FacSocketState> socketState; socketState.set(fac_socket_lookup(socket));
  if (!socketState) do_throw("tls.wrapClient: invalid, stale or closed socket or server name", 4);
  FacSocketTransferGuard socketLock(socketState.shared(), "tls.wrapClient: invalid, stale or closed socket");
  if (!fac_tls_api().ready) do_throw("tls.wrapClient: OpenSSL 1.1.1+ / 3.x runtime backend is unavailable", 11);
  std::string host(sd(serverName), (size_t)sl(serverName));
  if (host.empty() || host.size() > 253 || host.find('\0') != std::string::npos ||
      !std::all_of(host.begin(), host.end(), [](unsigned char c) { return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '.'; }))
    do_throw("tls.wrapClient: serverName must be an ASCII DNS hostname (IP literals and IDNs are not supported)", 4);
  FacTlsApi &api = fac_tls_api();
  void *ctx = api.ctxNew(api.clientMethod());
  if (!ctx) do_throw(fac_tls_error(api, "tls.wrapClient: cannot create TLS context"), 11);
  if (api.ctxCtrl(ctx, 123, 0x0303, nullptr) <= 0) {
    std::string msg = fac_tls_error(api, "tls.wrapClient: cannot require TLS 1.2 or newer"); api.ctxFree(ctx); do_throw(msg, 11);
  }
  api.ctxSetVerify(ctx, 1, nullptr);
  if (api.ctxDefaultVerifyPaths(ctx) != 1) {
    std::string msg = fac_tls_error(api, "tls.wrapClient: cannot load system trust roots"); api.ctxFree(ctx); do_throw(msg, 11);
  }
  void *ssl = api.sslNew(ctx);
  if (!ssl) { std::string msg = fac_tls_error(api, "tls.wrapClient: cannot create TLS session"); api.ctxFree(ctx); do_throw(msg, 11); }
  if (api.sslSetFd(ssl, socketState->fd) != 1 || api.sslSet1Host(ssl, host.c_str()) != 1 || api.sslCtrl(ssl, 55, 0, (void *)host.c_str()) != 1) {
    std::string msg = fac_tls_error(api, "tls.wrapClient: cannot configure hostname verification/SNI"); fac_tls_free_parts(api, ctx, ssl); do_throw(msg, 11);
  }
  int result = api.sslConnect(ssl);
  while (result <= 0 && fac_tls_want_retry(api, ssl, result)) result = api.sslConnect(ssl);
  if (result != 1) { std::string msg = fac_tls_error(api, "tls.wrapClient: handshake failed", ssl, result); fac_tls_free_parts(api, ctx, ssl); do_throw(msg, 11); }
  if (api.sslGetVerifyResult(ssl) != 0) { fac_tls_free_parts(api, ctx, ssl); do_throw("tls.wrapClient: peer certificate verification failed", 11); }
  FacTlsHandle *out = fac_tls_wrap(socket, socketState.shared(), socketLock, ctx, ssl);
  if (!out) do_throw("tls.wrapClient: out of memory creating TLS handle", 5);
  return out;
#else
  (void)socket; (void)serverName; do_throw("tls: OpenSSL backend is not available on Windows in this release; use a POSIX OpenSSL build", 11);
#endif
}
FacTlsHandle *fac_tls_wrapserver(Sock *socket, FacStr *certificateFile, FacStr *privateKeyFile) {
#ifndef _WIN32
  if (!certificateFile || !privateKeyFile) do_throw("tls.wrapServer: invalid certificate/key paths", 4);
  FacSharedStateRefGuard<FacSocketState> socketState; socketState.set(fac_socket_lookup(socket));
  if (!socketState) do_throw("tls.wrapServer: invalid, stale or closed socket or certificate paths", 4);
  FacSocketTransferGuard socketLock(socketState.shared(), "tls.wrapServer: invalid, stale or closed socket");
  if (!fac_tls_api().ready) do_throw("tls.wrapServer: OpenSSL 1.1.1+ / 3.x runtime backend is unavailable", 11);
  std::string cert(sd(certificateFile), (size_t)sl(certificateFile));
  std::string key(sd(privateKeyFile), (size_t)sl(privateKeyFile));
  if (cert.empty() || key.empty() || cert.find('\0') != std::string::npos || key.find('\0') != std::string::npos)
    do_throw("tls.wrapServer: certificate and private-key paths must be non-empty", 4);
  FacTlsApi &api = fac_tls_api();
  void *ctx = api.ctxNew(api.serverMethod());
  if (!ctx) do_throw(fac_tls_error(api, "tls.wrapServer: cannot create TLS context"), 11);
  if (api.ctxCtrl(ctx, 123, 0x0303, nullptr) <= 0 || api.ctxUseCertChain(ctx, cert.c_str()) != 1 ||
      api.ctxUsePrivateKey(ctx, key.c_str(), 1) != 1 || api.ctxCheckPrivateKey(ctx) != 1) {
    std::string msg = fac_tls_error(api, "tls.wrapServer: cannot configure certificate/private key or TLS 1.2 minimum"); api.ctxFree(ctx); do_throw(msg, 11);
  }
  void *ssl = api.sslNew(ctx);
  if (!ssl) { std::string msg = fac_tls_error(api, "tls.wrapServer: cannot create TLS session"); api.ctxFree(ctx); do_throw(msg, 11); }
  if (api.sslSetFd(ssl, socketState->fd) != 1) { std::string msg = fac_tls_error(api, "tls.wrapServer: cannot attach TCP socket"); fac_tls_free_parts(api, ctx, ssl); do_throw(msg, 11); }
  int result = api.sslAccept(ssl);
  while (result <= 0 && fac_tls_want_retry(api, ssl, result)) result = api.sslAccept(ssl);
  if (result != 1) { std::string msg = fac_tls_error(api, "tls.wrapServer: handshake failed", ssl, result); fac_tls_free_parts(api, ctx, ssl); do_throw(msg, 11); }
  FacTlsHandle *out = fac_tls_wrap(socket, socketState.shared(), socketLock, ctx, ssl);
  if (!out) do_throw("tls.wrapServer: out of memory creating TLS handle", 5);
  return out;
#else
  (void)socket; (void)certificateFile; (void)privateKeyFile; do_throw("tls: OpenSSL backend is not available on Windows in this release", 11);
#endif
}
int32_t fac_tls_sendbytes(FacTlsHandle *handle, FacList *bytes) {
#ifndef _WIN32
  FacSharedStateRefGuard<FacTlsState> state; state.set(fac_tls_lookup(handle)); if (!state) do_throw("tls.sendBytes: null, stale or closed TLS stream", 11);
  if (!fac_list_is_i32_bytes(bytes)) do_throw("tls.sendBytes: expected list dyn int with at most 16 MiB", 13);
  const int32_t *src = (const int32_t *)bytes->data;
  for (int64_t i = 0; i < bytes->len; ++i) if (src[i] < 0 || src[i] > 255) do_throw("tls.sendBytes: byte outside [0,255]", 13);
  FacRuntimeMutexGuard lock(state->mutex); fac_tls_require_open(state.shared(), "tls.sendBytes: null, stale or closed TLS stream");
  FacTlsApi &api = fac_tls_api(); size_t offset = 0;
  while (offset < (size_t)bytes->len) {
    int count = (int)std::min<size_t>((size_t)bytes->len - offset, 16384);
    char chunk[16384]; for (int i = 0; i < count; ++i) chunk[i] = (char)src[offset + (size_t)i];
    int result = api.sslWrite(state->ssl, chunk, count);
    while (result <= 0 && fac_tls_want_retry(api, state->ssl, result)) result = api.sslWrite(state->ssl, chunk, count);
    if (result <= 0) do_throw(fac_tls_error(api, "tls.sendBytes: TLS write failed", state->ssl, result), 11);
    offset += (size_t)result;
  }
  return (int32_t)bytes->len;
#else
  (void)handle; (void)bytes; do_throw("tls.sendBytes: TLS backend unavailable", 11);
#endif
}
FacList *fac_tls_recvexactbytes(FacTlsHandle *handle, int32_t count) {
#ifndef _WIN32
  if (count < 0 || count > FAC_MAX_BYTE_LIST) do_throw("tls.recvExactBytes: count must be between 0 and 16 MiB", 11);
  FacSharedStateRefGuard<FacTlsState> state; state.set(fac_tls_lookup(handle)); if (!state) do_throw("tls.recvExactBytes: null, stale or closed TLS stream", 11);
  FacList *out = fac_list_new((int32_t)sizeof(int32_t), 0); fac_tmp_push(out, 2);
  if (count > 0) { while (out->cap < count) fac_list_grow(out); out->len = count; }
  FacRuntimeMutexGuard lock(state->mutex); fac_tls_require_open(state.shared(), "tls.recvExactBytes: null, stale or closed TLS stream");
  if (count > 0) {
    int32_t *dst = (int32_t *)out->data; char chunk[8192]; int32_t offset = 0; FacTlsApi &api = fac_tls_api();
    while (offset < count) {
      int want = std::min<int32_t>((int32_t)sizeof chunk, count - offset);
      int result = api.sslRead(state->ssl, chunk, want);
      while (result <= 0 && fac_tls_want_retry(api, state->ssl, result)) result = api.sslRead(state->ssl, chunk, want);
      if (result <= 0) do_throw(fac_tls_error(api, "tls.recvExactBytes: TLS read failed or peer closed", state->ssl, result), 11);
      for (int i = 0; i < result; ++i) dst[offset + i] = (unsigned char)chunk[i];
      offset += result;
    }
  }
  lock.unlock(); fac_tmp_pop(out); return out;
#else
  (void)handle; (void)count; do_throw("tls.recvExactBytes: TLS backend unavailable", 11);
#endif
}
void fac_tls_close(FacTlsHandle *handle) {
#ifndef _WIN32
  if (!handle) return;
  FacSharedStateRefGuard<FacTlsState> state; state.set(fac_tls_lookup(handle)); if (!state) return;
  state->closing.store(true, std::memory_order_release);
  { FacRuntimeMutexGuard lock(state->mutex);
    if (state->active) {
      state->active = false;
      FacTlsApi &api = fac_tls_api();
      if (state->ssl) { api.sslShutdown(state->ssl); api.sslFree(state->ssl); state->ssl = nullptr; }
      if (state->ctx) { api.ctxFree(state->ctx); state->ctx = nullptr; }
      if (state->socket) {
        fac_socket_close_state(state->socket, true);
        state->socket.reset();
      }
    }
  }
  fac_tls_retire(handle);
#else
  (void)handle;
#endif
}
FacStr *fac_tls_version(FacTlsHandle *handle) {
#ifndef _WIN32
  FacSharedStateRefGuard<FacTlsState> state; state.set(fac_tls_lookup(handle)); if (!state) do_throw("tls.version: null, stale or closed TLS stream", 11);
  FacRuntimeMutexGuard lock(state->mutex); fac_tls_require_open(state.shared(), "tls.version: null, stale or closed TLS stream");
  const char *value = fac_tls_api().sslGetVersion(state->ssl); std::string copy(value ? value : ""); lock.unlock(); return mks(copy);
#else
  (void)handle; do_throw("tls.version: TLS backend unavailable", 11);
#endif
}
FacStr *fac_tls_cipher(FacTlsHandle *handle) {
#ifndef _WIN32
  FacSharedStateRefGuard<FacTlsState> state; state.set(fac_tls_lookup(handle)); if (!state) do_throw("tls.cipher: null, stale or closed TLS stream", 11);
  FacRuntimeMutexGuard lock(state->mutex); fac_tls_require_open(state.shared(), "tls.cipher: null, stale or closed TLS stream");
  FacTlsApi &api = fac_tls_api(); const void *cipher = api.sslGetCurrentCipher(state->ssl);
  const char *value = cipher ? api.cipherGetName(cipher) : nullptr;
  std::string copy(value ? value : ""); lock.unlock(); return mks(copy);
#else
  (void)handle; do_throw("tls.cipher: TLS backend unavailable", 11);
#endif
}
}

extern "C" void fac_gfx_text1(Canvas *c, int32_t x, int32_t y, FacStr *s, int32_t col) { fac_gfx_system_text(c, x, y, s, col, 1); }


// Internal reusable scheduler used by thread.parallelFor. The public FAC API
// remains synchronous; worker threads persist across calls and each worker has
// its own queue so one fast worker cannot consume another worker's ticket.
extern "C++" {
struct FacParallelJob {
  using Entry = void (*)(void *, int32_t);
  void *closure = nullptr;
  Entry entry = nullptr;
  int32_t count = 0;
  std::atomic<int64_t> next{0};
  std::atomic<int32_t> remaining{0};
  std::atomic<bool> failed{false};
  char error[1024]{};
  int32_t errorCode = 8;
  std::mutex doneMutex;
  std::condition_variable done;
};

class FacParallelPool;
static thread_local FacParallelPool *g_fac_parallel_worker_pool = nullptr;

class FacParallelPool {
  static constexpr size_t kMaxWorkers = 32;
  // Bound queued job tickets per worker. A parallelFor call contributes at
  // most one ticket to each participant queue, so this caps pending scheduler
  // metadata even when many caller threads submit concurrently.
  static constexpr size_t kMaxQueuedJobsPerWorker = 64;
  std::mutex mutex_;
  std::mutex growMutex_;
  std::condition_variable ready_;
  std::condition_variable spaceAvailable_;
  size_t spaceWaiters_ = 0; // guarded by mutex_
  size_t saturatedQueues_ = 0; // number of queues currently at their hard limit; guarded by mutex_
  std::vector<std::deque<FacParallelJob *>> queues_;
  std::vector<std::thread> workers_;
  std::atomic<size_t> workerCount_{0};
  std::atomic<size_t> nextWorker_{0};
  size_t workerLimit_ = 1;
  bool stopping_ = false;
  bool disabled_ = false;

  static void saveFailure(FacParallelJob *job, const char *message, size_t length, int32_t code) noexcept {
    bool expected = false;
    if (!job->failed.compare_exchange_strong(expected, true, std::memory_order_relaxed)) return;
    const size_t count = std::min(length, sizeof(job->error) - 1);
    if (count && message) memcpy(job->error, message, count);
    job->error[count] = '\0';
    job->errorCode = code ? code : 8;
  }

  static void execute(FacParallelJob *job) noexcept {
    void *handler[5]{};
    fac_try_enter(handler);
    if (__builtin_setjmp(handler) == 0) {
      try {
        while (!job->failed.load(std::memory_order_relaxed)) {
          const int64_t index = job->next.fetch_add(1, std::memory_order_relaxed);
          if (index >= (int64_t)job->count) break;
          job->entry(job->closure, (int32_t)index);
        }
      } catch (...) {
        static const char message[] = "thread.parallelFor: callback raised a C++ exception";
        saveFailure(job, message, sizeof(message) - 1, 8);
      }
      fac_try_leave();
    } else {
      saveFailure(job, g_errmsg.data(), g_errmsg.size(), g_errcode);
    }

    if (job->remaining.fetch_sub(1, std::memory_order_acq_rel) == 1) {
      // Notify while holding the waiter's mutex. The caller can then reacquire
      // the mutex and destroy this stack-owned condition_variable only after
      // notify_all() has returned, avoiding concurrent notify/destruction.
      {
        std::lock_guard<std::mutex> lock(job->doneMutex);
        job->done.notify_all();
      }
    }
  }

  void workerLoop(size_t workerIndex) noexcept {
    g_fac_parallel_worker_pool = this;
    for (;;) {
      FacParallelJob *job = nullptr;
      bool wakeSubmitters = false;
      {
        std::unique_lock<std::mutex> lock(mutex_);
        ready_.wait(lock, [&] { return stopping_ || !queues_[workerIndex].empty(); });
        if (queues_[workerIndex].empty()) {
          if (stopping_) break;
          continue;
        }
        const bool wasFull = queues_[workerIndex].size() == kMaxQueuedJobsPerWorker;
        job = queues_[workerIndex].front();
        queues_[workerIndex].pop_front();
        if (wasFull) --saturatedQueues_;
        wakeSubmitters = wasFull && spaceWaiters_ != 0;
      }
      // Avoid broadcast overhead on the normal no-backlog path. A broadcast
      // is needed because waiting callers target different worker-slot sets.
      if (wakeSubmitters) spaceAvailable_.notify_all();
      execute(job);
    }
    g_fac_parallel_worker_pool = nullptr;
  }

public:
  FacParallelPool() noexcept {
    unsigned int detected = std::thread::hardware_concurrency();
    workerLimit_ = std::min((size_t)std::max(1u, detected), kMaxWorkers);
    try {
      // Reserve once; workers and their private queues are then added lazily
      // as parallelFor requests actual concurrency, avoiding idle thread cost.
      queues_.reserve(kMaxWorkers);
      workers_.reserve(kMaxWorkers);
    } catch (...) {
      disabled_ = true;
    }
  }

  void ensureWorkers(size_t desired) noexcept {
    if (disabled_) return;
    desired = std::min(desired, workerLimit_);
    try {
      std::lock_guard<std::mutex> grow(growMutex_);
      while (workerCount_.load(std::memory_order_acquire) < desired) {
        size_t index = 0;
        {
          std::lock_guard<std::mutex> lock(mutex_);
          if (stopping_) return;
          queues_.emplace_back();
          index = queues_.size() - 1;
        }
        try {
          workers_.emplace_back([this, index] { workerLoop(index); });
          workerCount_.store(workers_.size(), std::memory_order_release);
        } catch (...) {
          std::lock_guard<std::mutex> lock(mutex_);
          if (queues_.size() == index + 1) queues_.pop_back();
          break;
        }
      }
    } catch (...) {
      // Callers fall back to synchronous execution if pool growth is unavailable.
    }
  }

  ~FacParallelPool() {
    {
      std::lock_guard<std::mutex> lock(mutex_);
      stopping_ = true;
    }
    ready_.notify_all();
    spaceAvailable_.notify_all();
    for (auto &worker : workers_) {
      if (!worker.joinable()) continue;
      try { worker.join(); } catch (...) { std::terminate(); }
    }
  }

  size_t workerLimit() const noexcept { return workerLimit_; }
  size_t workerCount() const noexcept { return workerCount_.load(std::memory_order_acquire); }
  bool isWorkerThread() const noexcept { return g_fac_parallel_worker_pool == this; }
  void runInline(FacParallelJob *job) noexcept {
    job->remaining.store(1, std::memory_order_relaxed);
    execute(job);
  }

  bool submit(FacParallelJob *job, size_t participants) noexcept {
    // workerCount_ is published only after each std::thread is appended. Do
    // not inspect workers_.size() here: another caller may be growing the
    // vector concurrently under growMutex_.
    if (participants == 0 || participants > workerCount_.load(std::memory_order_acquire)) return false;
    size_t before[kMaxWorkers]{};
    size_t slots[kMaxWorkers]{};
    try {
      {
        std::unique_lock<std::mutex> lock(mutex_);
        const size_t active = workerCount_.load(std::memory_order_acquire);
        if (stopping_ || active == 0 || participants > active) return false;
        const size_t first = nextWorker_.fetch_add(participants, std::memory_order_relaxed) % active;
        for (size_t i = 0; i < participants; ++i)
          slots[i] = (first + i) % active;

        // Apply back-pressure before mutating any queue. The selected slots
        // are distinct and active cannot shrink, so waiting is safe while the
        // pool mutex protects queue sizes. Workers wake submitters after pop.
        for (;;) {
          if (stopping_) return false;
          bool hasCapacity = true;
          if (saturatedQueues_ == 0) {
            // Hot path: no queue is at the hard bound, so only capture the
            // rollback sizes. This avoids a per-worker capacity branch.
            for (size_t i = 0; i < participants; ++i)
              before[i] = queues_[slots[i]].size();
          } else {
            for (size_t i = 0; i < participants; ++i) {
              before[i] = queues_[slots[i]].size();
              if (before[i] >= kMaxQueuedJobsPerWorker) {
                hasCapacity = false;
                break;
              }
            }
          }
          if (hasCapacity) break;
          // The mutex is released while waiting, so workers can pop tickets.
          // Recheck all selected queues after every wake (including spurious
          // wakes) before publishing any part of this batch. Count waiters so
          // workers avoid broadcasting on the ordinary no-contention path.
          ++spaceWaiters_;
          try {
            spaceAvailable_.wait(lock);
          } catch (...) {
            --spaceWaiters_;
            throw;
          }
          --spaceWaiters_;
        }
        try {
          for (size_t i = 0; i < participants; ++i) queues_[slots[i]].push_back(job);
        } catch (...) {
          // Workers cannot observe a partial submission while mutex_ is held.
          for (size_t i = 0; i < participants; ++i)
            while (queues_[slots[i]].size() > before[i]) queues_[slots[i]].pop_back();
          return false;
        }
        for (size_t i = 0; i < participants; ++i)
          if (queues_[slots[i]].size() == kMaxQueuedJobsPerWorker) ++saturatedQueues_;
        job->remaining.store((int32_t)participants, std::memory_order_release);
      }
      ready_.notify_all();
      return true;
    } catch (...) {
      return false;
    }
  }

  static void wait(FacParallelJob *job) {
    std::unique_lock<std::mutex> lock(job->doneMutex);
    job->done.wait(lock, [&] { return job->remaining.load(std::memory_order_acquire) == 0; });
  }
};

static FacParallelPool &fac_parallel_pool() {
  static FacParallelPool pool;
  return pool;
}
}

// ================================================================ รอบเติม API: terminal/string/char/math/random/memory/file/sys/path/regex/json builder/thread/atomic/crypto/csv/net/graphic
extern "C" {
void fac_out_flush() { flush_out(); }
int32_t fac_in_eof() { flush_out(); int c = fgetc(stdin); if (c == EOF) return 1; ungetc(c, stdin); return 0; }
FacStr *fac_in_readall() { flush_out(); std::string t; char b[4096]; size_t n; while ((n = fread(b, 1, sizeof b, stdin)) > 0) t.append(b, n); return mks(t); }
int32_t fac_in_readchar() {
  flush_out(); int c = fgetc(stdin); if (c == EOF) return -1;
  int extra = (c >> 5) == 6 ? 1 : (c >> 4) == 14 ? 2 : (c >> 3) == 30 ? 3 : 0; std::string s(1, (char)c);
  for (int i = 0; i < extra; i++) { int d = fgetc(stdin); if (d == EOF) break; s += (char)d; }
  int w; return (int32_t)dec(s.c_str(), &w);
}
void fac_term_clear() { wr("\x1b[2J\x1b[H", 7); }
int32_t fac_char_isupper(int32_t c) { return c >= 'A' && c <= 'Z'; }
int32_t fac_char_islower(int32_t c) { return c >= 'a' && c <= 'z'; }
int32_t fac_char_isalnum(int32_t c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c > 127; }
int32_t fac_char_ispunct(int32_t c) { return c > 32 && c < 127 && !fac_char_isalnum(c); }
int32_t fac_char_toupper(int32_t c) { return (int32_t)cp_upper((uint32_t)c); }
int32_t fac_char_tolower(int32_t c) { return (int32_t)cp_lower((uint32_t)c); }
FacStr *fac_str_trimleft(FacStr *s) { int64_t a = 0, b = sl(s); while (a < b && isws(s->data[a])) a++; return mk(sd(s) + a, b - a); }
FacStr *fac_str_trimright(FacStr *s) { int64_t b = sl(s); while (b > 0 && isws(s->data[b - 1])) b--; return mk(sd(s), b); }
int32_t fac_str_eqnocase(FacStr *a, FacStr *b) { if (sl(a) != sl(b)) return 0; for (int64_t i = 0; i < sl(a); i++) if (tolower((unsigned char)a->data[i]) != tolower((unsigned char)b->data[i])) return 0; return 1; }
FacList *fac_str_chars(FacStr *s) { FacStr *e = mks(""); FacList *l = fac_str_split(s, e); fac_str_free(e); return l; }
double fac_deg(double r) { return r * 180.0 / 3.14159265358979323846; }
double fac_rad(double d) { return d * 3.14159265358979323846 / 180.0; }
static uint64_t fac_abs_u64(int64_t v) { return v < 0 ? uint64_t(0) - (uint64_t)v : (uint64_t)v; }
int64_t fac_gcd(int64_t a, int64_t b) {
  uint64_t x = fac_abs_u64(a), y = fac_abs_u64(b);
  while (y) { uint64_t r = x % y; x = y; y = r; }
  if (x > (uint64_t)INT64_MAX) do_throw("math.gcd: result exceeds int64 range", 8);
  return (int64_t)x;
}
int64_t fac_lcm(int64_t a, int64_t b) {
  if (!a || !b) return 0;
  uint64_t x = fac_abs_u64(a), y = fac_abs_u64(b), u = x, v = y;
  while (v) { uint64_t r = u % v; u = v; v = r; }
  uint64_t q = x / u;
  if (y && q > (uint64_t)INT64_MAX / y) do_throw("math.lcm: result exceeds int64 range", 8);
  return (int64_t)(q * y);
}
int32_t fac_isinf(double x) { return std::isinf(x); }
int64_t fac_pmod(int64_t a, int64_t m) {
  if (!m) do_throw("div by zero", 3);
  const uint64_t mod = fac_abs_u64(m);
  uint64_t rem = fac_abs_u64(a) % mod;
  if (a < 0 && rem) rem = mod - rem;
  return (int64_t)rem;
}
void fac_shuffle(void *d, int64_t n, int32_t esz) {
  if (n < 0 || esz <= 0) do_throw("random.shuffle: invalid count or element size", 8);
  if (n < 2) return;
  if (!d) do_throw("random.shuffle: null data", 8);
  if (n > INT64_MAX / esz) do_throw("random.shuffle: size overflow", 8);
  char *p = (char *)d; std::string t((size_t)esz, 0);
  for (int64_t i = n - 1; i > 0; i--) { int64_t j = (int64_t)(rng_next() % (uint64_t)(i + 1)); if (i == j) continue; memcpy(&t[0], p + i * esz, (size_t)esz); memcpy(p + i * esz, p + j * esz, (size_t)esz); memcpy(p + j * esz, &t[0], (size_t)esz); }
}
int64_t fac_rand_index(int64_t n) { if (n <= 0) do_throw("random.choice: empty collection", 8); return (int64_t)(rng_next() % (uint64_t)n); }
void fac_memzero(void *p, int64_t n) {
  if (n < 0) do_throw("memory.zero: size cannot be negative", 8);
  if (n == 0) return;
  if (!p) do_throw("memory.zero: null pointer", 8);
  memset(p, 0, (size_t)n);
}
int32_t fac_file_isfile(FacStr *p) { struct stat st; return stat(sd(p), &st) == 0 && (st.st_mode & S_IFMT) == S_IFREG; }
int64_t fac_file_modified(FacStr *p) { struct stat st; if (stat(sd(p), &st) != 0) do_throw(std::string("cannot stat file: ") + sd(p), 7); return (int64_t)st.st_mtime * 1000; }
void fac_sys_setenv(FacStr *k, FacStr *v) {
#ifdef _WIN32
  _putenv_s(sd(k), sd(v));
#else
  setenv(sd(k), sd(v), 1);
#endif
}
FacStr *fac_sys_tempdir() { std::error_code ec; return mks(std::filesystem::temp_directory_path(ec).string()); }
FacStr *fac_path_stem(FacStr *p) { std::string n(sd(p), (size_t)sl(p)); while (!n.empty() && issep(n.back())) n.pop_back(); { size_t j = n.find_last_of("/\\"); if (j != std::string::npos) n = n.substr(j + 1); } size_t i = n.rfind('.'); return mks(i == std::string::npos || i == 0 ? n : n.substr(0, i)); }
FacStr *fac_path_absolute(FacStr *p) { std::error_code ec; return mks(std::filesystem::absolute(sd(p), ec).string()); }
int32_t fac_path_isabs(FacStr *p) { return std::filesystem::path(sd(p)).is_absolute(); }
FacStr *fac_path_normalize(FacStr *p) { return mks(std::filesystem::path(sd(p)).lexically_normal().string()); }
static void lpush(FacList *l, const std::string &s) { FacStr *e = mks(s); if (l->len == l->cap) fac_list_grow(l); ((FacStr **)l->data)[l->len++] = e; }
FacList *fac_regex_groups(FacStr *p, FacStr *s) {
  std::string err; std::vector<std::string> g;
  { std::regex r; if (mkre(p, r, err)) { std::string t(sd(s), (size_t)sl(s));
      rxrun(t.size(), err, [&] { std::smatch m; if (std::regex_search(t, m, r)) for (size_t i = 1; i < m.size(); i++) g.push_back(m[i].str()); }); } }
  if (!err.empty()) { std::vector<std::string>().swap(g); do_throw(std::move(err), 9); }
  FacList *l = fac_list_new(8, 1); for (auto &x : g) lpush(l, x); return l;
}
FacList *fac_regex_split(FacStr *p, FacStr *s) {
  std::string err; std::vector<std::string> g;
  { std::regex r; if (mkre(p, r, err)) { std::string t(sd(s), (size_t)sl(s));
      rxrun(t.size(), err, [&] { for (std::sregex_token_iterator it(t.begin(), t.end(), r, -1), e; it != e; ++it) g.push_back(it->str()); }); } }
  if (!err.empty()) { std::vector<std::string>().swap(g); do_throw(std::move(err), 9); }
  FacList *l = fac_list_new(8, 1); for (auto &x : g) lpush(l, x); return l;
}
int32_t fac_regex_count(FacStr *p, FacStr *s) {
  std::string err; int32_t n = 0;
  { std::regex r; if (mkre(p, r, err)) { std::string t(sd(s), (size_t)sl(s));
      rxrun(t.size(), err, [&] { n = (int32_t)std::distance(std::sregex_iterator(t.begin(), t.end(), r), std::sregex_iterator()); }); } }
  if (!err.empty()) do_throw(std::move(err), 9);
  return n;
}
// ---- json builder (set/push รับ node ลูกไปเป็นเจ้าของ ห้าม free ลูกซ้ำ)
JV *fac_json_object() { JV *v = new JV; v->t = 5; return v; }
JV *fac_json_array() { JV *v = new JV; v->t = 4; return v; }
JV *fac_json_newstr(FacStr *s) { JV *v = new JV; v->t = 3; v->s.assign(sd(s), (size_t)sl(s)); return v; }
JV *fac_json_newint(int64_t i) { JV *v = new JV; v->t = 2; v->isint = true; v->i = i; v->d = (double)i; return v; }
JV *fac_json_newfloat(double d) { JV *v = new JV; v->t = 2; v->d = d; return v; }
JV *fac_json_newbool(int32_t b) { JV *v = new JV; v->t = 1; v->b = b != 0; return v; }
JV *fac_json_newnull() { return new JV; }
// set/push take ownership of the child. Inserting a node into itself or into its own subtree would create a cycle
// (infinite recursion in stringify, double free on destruction), so it is rejected; null becomes JSON null.
static bool jcontains(JV *root, JV *target) {
  std::vector<JV *> st{root};
  while (!st.empty()) { JV *x = st.back(); st.pop_back(); if (x == target) return true; for (auto *c : x->a) st.push_back(c); for (auto &q : x->o) st.push_back(q.second); }
  return false;
}
static bool jcycle(JV *parent, JV *child) { return child == parent || ((child->t == 4 || child->t == 5) && jcontains(child, parent)); }
void fac_json_set(JV *o, FacStr *key, JV *n) {
  if (!o || o->t != 5 || !key) do_throw("json.set: expected an object and key", 10);
  const std::string keyCopy(sd(key), (size_t)sl(key));
  for (auto &p : o->o) if (p.first == keyCopy && p.second == n) return;
  if (n && n->parent) do_throw("json.set: child node is already owned", 10);
  JV *created = n ? nullptr : new (std::nothrow) JV;
  if (!n) { if (!created) do_throw("json.set: allocation failed", 5); n = created; }
  if (jcycle(o, n)) { delete created; do_throw("json.set: cannot insert a value into itself or an ancestor", 10); }
  for (auto &p : o->o) if (p.first == keyCopy) {
    delete p.second; p.second = n; n->parent = o; return;
  }
  try { o->o.push_back({keyCopy, n}); }
  catch (...) { delete created; do_throw("json.set: allocation failed", 5); }
  n->parent = o;
}
void fac_json_push(JV *a, JV *n) {
  if (!a || a->t != 4) do_throw("json.push: expected an array", 10);
  if (n && n->parent) do_throw("json.push: child node is already owned", 10);
  JV *created = n ? nullptr : new (std::nothrow) JV;
  if (!n) { if (!created) do_throw("json.push: allocation failed", 5); n = created; }
  if (jcycle(a, n)) { delete created; do_throw("json.push: cannot insert a value into itself or an ancestor", 10); }
  try { a->a.push_back(n); }
  catch (...) { delete created; do_throw("json.push: allocation failed", 5); }
  n->parent = a;
}
static bool jser_safe(JV *v, int ind, std::string &o, std::string &err) { try { jser(v, o, ind, 0); return true; } catch (JErr &e) { err = std::move(e.m); return false; } }
FacStr *fac_json_stringify(JV *v) { std::string o, err; if (!jser_safe(v, 0, o, err)) { std::string().swap(o); do_throw(std::move(err), 10); } return mks(o); }
FacStr *fac_json_stringifyp(JV *v) { std::string o, err; if (!jser_safe(v, 2, o, err)) { std::string().swap(o); do_throw(std::move(err), 10); } return mks(o); }
// ---- thread / atomic
int64_t fac_thread_id() { return (int64_t)(std::hash<std::thread::id>()(std::this_thread::get_id()) & 0x7fffffffffffffffLL); }
void fac_thread_yield() { std::this_thread::yield(); }
int32_t fac_atomic_add(int32_t *p, int32_t v) { return __atomic_add_fetch(p, v, __ATOMIC_SEQ_CST); }
int32_t fac_atomic_get(int32_t *p) { return __atomic_load_n(p, __ATOMIC_SEQ_CST); }
void fac_atomic_set(int32_t *p, int32_t v) { __atomic_store_n(p, v, __ATOMIC_SEQ_CST); }
int32_t fac_atomic_cas(int32_t *p, int32_t expect, int32_t desire) { return __atomic_compare_exchange_n(p, &expect, desire, false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); }
// Explicitly weaker orders are provided for users who understand the synchronization contract.
int32_t fac_atomic_add_relaxed(int32_t *p, int32_t v) { return __atomic_add_fetch(p, v, __ATOMIC_RELAXED); }
int32_t fac_atomic_add_acquire(int32_t *p, int32_t v) { return __atomic_add_fetch(p, v, __ATOMIC_ACQUIRE); }
int32_t fac_atomic_add_release(int32_t *p, int32_t v) { return __atomic_add_fetch(p, v, __ATOMIC_RELEASE); }
int32_t fac_atomic_add_acqrel(int32_t *p, int32_t v) { return __atomic_add_fetch(p, v, __ATOMIC_ACQ_REL); }
int32_t fac_atomic_get_relaxed(int32_t *p) { return __atomic_load_n(p, __ATOMIC_RELAXED); }
int32_t fac_atomic_get_acquire(int32_t *p) { return __atomic_load_n(p, __ATOMIC_ACQUIRE); }
void fac_atomic_set_relaxed(int32_t *p, int32_t v) { __atomic_store_n(p, v, __ATOMIC_RELAXED); }
void fac_atomic_set_release(int32_t *p, int32_t v) { __atomic_store_n(p, v, __ATOMIC_RELEASE); }
int32_t fac_atomic_cas_relaxed(int32_t *p, int32_t expect, int32_t desire) { return __atomic_compare_exchange_n(p, &expect, desire, false, __ATOMIC_RELAXED, __ATOMIC_RELAXED); }
int32_t fac_atomic_cas_acquire(int32_t *p, int32_t expect, int32_t desire) { return __atomic_compare_exchange_n(p, &expect, desire, false, __ATOMIC_ACQUIRE, __ATOMIC_ACQUIRE); }
int32_t fac_atomic_cas_release(int32_t *p, int32_t expect, int32_t desire) { return __atomic_compare_exchange_n(p, &expect, desire, false, __ATOMIC_RELEASE, __ATOMIC_RELAXED); }
int32_t fac_atomic_cas_acqrel(int32_t *p, int32_t expect, int32_t desire) { return __atomic_compare_exchange_n(p, &expect, desire, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE); }
void fac_parallel_for(int32_t n, void *clo) {
  if (n <= 0) return;
  if (!clo) do_throw("thread.parallelFor: null closure", 6);
  typedef void (*Fn)(void *, int32_t);
  Fn fn = reinterpret_cast<Fn>(*(void **)clo);
  if (!fn) do_throw("thread.parallelFor: closure has no entry function", 6);

  g_mt.store(true, std::memory_order_release);
  FacParallelPool &pool = fac_parallel_pool();
  FacParallelJob job;
  job.closure = clo;
  job.entry = fn;
  job.count = n;

  // Nested parallelFor on a pool worker executes inline under a nested FAC
  // boundary. This avoids waiting for workers that are occupied by the parent
  // task, while preserving FAC/C++ exception conversion at the nested call.
  if (pool.isWorkerThread()) {
    pool.runInline(&job);
  } else {
    const size_t requested = std::min((size_t)n, pool.workerLimit());
    pool.ensureWorkers(requested);
    const size_t available = pool.workerCount();
    if (available < requested)
      do_throw("thread.parallelFor: unable to create the requested worker pool", 8);
    // A pool may already contain more workers than this batch needs. Submit
    // exactly the requested number of tickets rather than waking every worker
    // created by an earlier, larger parallelFor call.
    if (requested == 0 || !pool.submit(&job, requested))
      do_throw("thread.parallelFor: unable to enqueue worker tasks", 8);
    FacParallelPool::wait(&job);
  }

  if (job.failed.load(std::memory_order_acquire)) {
    const char *message = job.error[0] ? job.error : "thread.parallelFor: callback failed";
    do_throw(std::string(message), job.errorCode);
  }
}
// ---- crypto / csv / net
FacStr *fac_crypto_pbkdf2(FacStr *pw, FacStr *salt, int32_t iters, int32_t keylen) {
  // Bound attacker-controlled work factors to keep a single request from
  // monopolizing a runtime thread indefinitely. 10M remains far above common
  // interactive password-hashing work factors; applications should still
  // choose and store a reviewed iteration count rather than accept it from users.
  if (iters < 1 || iters > 10000000 || keylen < 1 || keylen > 1 << 16)
    do_throw("crypto.pbkdf2: iterations must be 1..10000000 and key length 1..65536", 13);
  std::string P(sd(pw), (size_t)sl(pw)), S(sd(salt), (size_t)sl(salt)), out;
  for (uint32_t blk = 1; out.size() < (size_t)keylen; blk++) {
    std::string u = hmac(sha256, 64, 32, P, S + std::string({(char)(blk >> 24), (char)(blk >> 16), (char)(blk >> 8), (char)blk})), t = u;
    for (int32_t i = 1; i < iters; i++) { u = hmac(sha256, 64, 32, P, u); for (size_t k = 0; k < 32; k++) t[k] ^= u[k]; }
    out += t;
  }
  out.resize((size_t)keylen); return mks(hexs((const uint8_t *)out.data(), out.size()));
}
FacStr *fac_csv_field(FacStr *line, int32_t i) { FacList *l = fac_csv_parseline(line); FacStr *r = (i >= 0 && i < l->len) ? fac_str_dup(((FacStr **)l->data)[i]) : mks(""); fac_list_free(l); return r; }
FacStr *fac_net_urlencode(FacStr *s) {
  std::string r; char b[4];
  for (int64_t i = 0; i < sl(s); i++) {
    unsigned char c = (unsigned char)s->data[i];
    // RFC 3986 unreserved characters are ASCII only; do not let the process locale
    // accidentally pass UTF-8 bytes through as letters/digits.
    bool unreserved = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                      (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~';
    if (unreserved) r += (char)c;
    else { snprintf(b, sizeof b, "%%%02X", c); r += b; }
  }
  return mks(r);
}
FacStr *fac_net_urldecode(FacStr *s) {
  std::string r; for (int64_t i = 0; i < sl(s); i++) { char c = s->data[i]; if (c == '%' && i + 2 < sl(s) + 0 && isxdigit((unsigned char)s->data[i + 1]) && isxdigit((unsigned char)s->data[i + 2])) { r += (char)strtol(std::string(s->data + i + 1, 2).c_str(), nullptr, 16); i += 2; } else r += c == '+' ? ' ' : c; }
  return mks(r);
}
void fac_net_settimeout(Sock *s, int32_t ms) {
  if (ms < 0) do_throw("net.setTimeout: timeout must be >= 0 milliseconds", 11);
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.setTimeout: null, stale or closed socket", 11);
  FacSocketOperationGuard lock(state.shared(), state->optionMutex, "net.setTimeout: null, stale or closed socket");
#ifdef _WIN32
  DWORD t = (DWORD)ms;
  if (setsockopt(state->fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&t, sizeof t) != 0 ||
      setsockopt(state->fd, SOL_SOCKET, SO_SNDTIMEO, (const char *)&t, sizeof t) != 0)
    do_throw("net.setTimeout: receive/send timeout configuration failed", 11);
#else
  struct timeval tv; tv.tv_sec = ms / 1000; tv.tv_usec = (ms % 1000) * 1000;
  if (setsockopt(state->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv) != 0 ||
      setsockopt(state->fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv) != 0)
    do_throw("net.setTimeout: receive/send timeout configuration failed", 11);
#endif
}
FacStr *fac_net_recvall(Sock *s) {
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.recvAll: null, stale or closed socket", 11);
  FacSocketOperationGuard lock(state.shared(), state->readMutex, "net.recvAll: null, stale or closed socket");
  std::string result = recvall(state.get()); lock.unlock(); return mks(result);
}
int32_t fac_net_sendline(Sock *s, FacStr *d) {
  if (!d) do_throw("net.sendLine: null socket or data", 11);
  FacSharedStateRefGuard<FacSocketState> state; state.set(fac_socket_lookup(s)); if (!state) do_throw("net.sendLine: null, stale or closed socket", 11);
  FacSocketOperationGuard lock(state.shared(), state->writeMutex, "net.sendLine: null, stale or closed socket");
  const int32_t result = (int32_t)sl(d) + 1; sendall(state.get(), std::string(sd(d), (size_t)sl(d)) + "\n"); return result;
}
// ---- graphic เพิ่ม
void fac_gfx_blit(Canvas *d, Canvas *s, int32_t x, int32_t y) {
  FacCanvasPairLock lock(d, s);
  if (!d || !s) return;
  for (int j = 0; j < s->h; j++) for (int i = 0; i < s->w; i++)
    cpx64(d, (int64_t)x + i, (int64_t)y + j, s->px[(size_t)j * (size_t)s->w + (size_t)i]);
}
void fac_gfx_blitkey(Canvas *d, Canvas *s, int32_t x, int32_t y, int32_t key) {
  FacCanvasPairLock lock(d, s);
  if (!d || !s) return;
  for (int j = 0; j < s->h; j++) for (int i = 0; i < s->w; i++) {
    uint32_t v = s->px[(size_t)j * (size_t)s->w + (size_t)i];
    if (v != ((uint32_t)key & 0xFFFFFF)) cpx64(d, (int64_t)x + i, (int64_t)y + j, v);
  }
}
static inline void mixpx(uint32_t &p, uint32_t s, uint32_t a) {   // a: 0..255 (ใช้สูตรเดียวกับ graphic.blend)
  if (a >= 255) { p = s & 0xFFFFFF; return; } if (a == 0) return; uint32_t r = 0;
  for (int sh = 0; sh <= 16; sh += 8) { uint32_t sc = (s >> sh) & 255, dc = (p >> sh) & 255; r |= ((sc * a + dc * (255 - a)) / 255) << sh; }
  p = r & 0xFFFFFF;
}
// วาดบริเวณ (sx,sy,sw,sh) ของ s ลง d ที่ (x,y) แบบเคารพ alpha ต่อพิกเซล (ไม่มี alpha = ทึบ); clip ทั้งฝั่งต้นทางและปลายทาง
static void blitRegionFlip(Canvas *d, Canvas *s, int64_t x, int64_t y, int64_t sx, int64_t sy, int64_t sw, int64_t sh, bool fx, bool fy) {
  FacCanvasPairLock lock(d, s);
  if (!d || !s || sw <= 0 || sh <= 0) return;
  // ช่วงดัชนี i,j ภายในบริเวณต้นทาง (0..sw-1, 0..sh-1) ที่อยู่ในภาพต้นทาง และปลายทางของมันอยู่ในภาพปลายทาง
  // ตำแหน่งปลายทางของ i คือ x+i (ปกติ) หรือ x+(sw-1-i) (พลิกแนวนอน); แถว j คล้ายกัน
  int64_t i0 = std::max<int64_t>(0, -sx), i1 = std::min<int64_t>(sw, (int64_t)s->w - sx);
  int64_t j0 = std::max<int64_t>(0, -sy), j1 = std::min<int64_t>(sh, (int64_t)s->h - sy);
  if (!fx) { i0 = std::max<int64_t>(i0, -x); i1 = std::min<int64_t>(i1, (int64_t)d->w - x); }
  else { i0 = std::max<int64_t>(i0, x + sw - (int64_t)d->w); i1 = std::min<int64_t>(i1, x + sw); }
  if (!fy) { j0 = std::max<int64_t>(j0, -y); j1 = std::min<int64_t>(j1, (int64_t)d->h - y); }
  else { j0 = std::max<int64_t>(j0, y + sh - (int64_t)d->h); j1 = std::min<int64_t>(j1, y + sh); }
  if (i0 >= i1 || j0 >= j1) return;
  std::vector<uint32_t> tp; std::vector<uint8_t> ta; const uint32_t *sp = s->px.data(); const uint8_t *sa = s->alpha.empty() ? nullptr : s->alpha.data();
  if (d == s) { tp = s->px; sp = tp.data(); if (sa) { ta = s->alpha; sa = ta.data(); } }   // ต้นทางกับปลายทางเป็นภาพเดียวกัน: ใช้สำเนา
  for (int64_t j = j0; j < j1; j++) for (int64_t i = i0; i < i1; i++) {
    size_t si = (size_t)(sy + j) * (size_t)s->w + (size_t)(sx + i);
    int64_t dx = fx ? x + (sw - 1 - i) : x + i, dy = fy ? y + (sh - 1 - j) : y + j;
    mixpx(d->px[(size_t)dy * (size_t)d->w + (size_t)dx], sp[si], sa ? sa[si] : 255);
  }
}
static void blitRegion(Canvas *d, Canvas *s, int64_t x, int64_t y, int64_t sx, int64_t sy, int64_t sw, int64_t sh) { blitRegionFlip(d, s, x, y, sx, sy, sw, sh, false, false); }
void fac_gfx_blitalpha(Canvas *d, Canvas *s, int32_t x, int32_t y) { FacCanvasPairLock lock(d, s); if (s) blitRegion(d, s, x, y, 0, 0, s->w, s->h); }
void fac_gfx_blitregion(Canvas *d, Canvas *s, int32_t x, int32_t y, int32_t sx, int32_t sy, int32_t sw, int32_t sh) { blitRegion(d, s, x, y, sx, sy, sw, sh); }
// flags: bit0 = พลิกแนวนอน, bit1 = พลิกแนวตั้ง (พลิกเฉพาะบริเวณที่ตัดมา เหมาะกับ sprite ที่หันซ้าย/ขวา)
void fac_gfx_blitregionex(Canvas *d, Canvas *s, int32_t x, int32_t y, int32_t sx, int32_t sy, int32_t sw, int32_t sh, int32_t flags) { blitRegionFlip(d, s, x, y, sx, sy, sw, sh, (flags & 1) != 0, (flags & 2) != 0); }
// ย่อ/ขยายแบบ nearest ลงสี่เหลี่ยม (x,y,w,h); w หรือ h ติดลบ = พลิกแนวนอน/แนวตั้ง; เคารพ alpha
void fac_gfx_blitscaled(Canvas *d, Canvas *s, int32_t x, int32_t y, int32_t w, int32_t h) {
  FacCanvasPairLock lock(d, s);
  if (!d || !s || w == 0 || h == 0) return;
  bool fx = w < 0, fy = h < 0; int64_t aw = llabs((long long)w), ah = llabs((long long)h);
  int64_t ox = x, oy = y;
  if (fx) ox += (int64_t)w; if (fy) oy += (int64_t)h; // keep the top-left origin in 64-bit arithmetic
  std::vector<uint32_t> tp; std::vector<uint8_t> ta; const uint32_t *sp = s->px.data(); const uint8_t *sa = s->alpha.empty() ? nullptr : s->alpha.data();
  if (d == s) { tp = s->px; sp = tp.data(); if (sa) { ta = s->alpha; sa = ta.data(); } }
  int64_t j0 = std::max<int64_t>(0, -oy), j1 = std::min<int64_t>(ah, (int64_t)d->h - oy), i0 = std::max<int64_t>(0, -ox), i1 = std::min<int64_t>(aw, (int64_t)d->w - ox);
  for (int64_t j = j0; j < j1; j++) {
    int64_t sj = (j * 2 + 1) * s->h / (ah * 2); if (fy) sj = s->h - 1 - sj;
    for (int64_t i = i0; i < i1; i++) {
      int64_t si = (i * 2 + 1) * s->w / (aw * 2); if (fx) si = s->w - 1 - si;
      size_t k = (size_t)sj * (size_t)s->w + (size_t)si;
      mixpx(d->px[(size_t)(oy + j) * (size_t)d->w + (size_t)(ox + i)], sp[k], sa ? sa[k] : 255);
    }
  }
}
int32_t fac_gfx_hasalpha(Canvas *c) { FacCanvasLock lock(c); return c && !c->alpha.empty(); }
int32_t fac_gfx_alphaat(Canvas *c, int32_t x, int32_t y) { FacCanvasLock lock(c); if (!c || (unsigned)x >= (unsigned)c->w || (unsigned)y >= (unsigned)c->h) return 0; return c->alpha.empty() ? 255 : c->alpha[(size_t)y * (size_t)c->w + (size_t)x]; }
void fac_gfx_blend(Canvas *c, int32_t x, int32_t y, int32_t col, int32_t a) {
  FacCanvasLock lock(c);
  if (!c || (unsigned)x >= (unsigned)c->w || (unsigned)y >= (unsigned)c->h) return; a = a < 0 ? 0 : a > 255 ? 255 : a;
  uint32_t &p = c->px[(size_t)y * (size_t)c->w + (size_t)x]; uint32_t s = (uint32_t)col, r = 0;
  for (int sh = 0; sh <= 16; sh += 8) { uint32_t sc = (s >> sh) & 255, dc = (p >> sh) & 255; r |= ((sc * (uint32_t)a + dc * (uint32_t)(255 - a)) / 255) << sh; }
  p = r & 0xFFFFFF;
}
uint32_t fac_gfx_hsv(double h, double s, double v) {
  if (!std::isfinite(h) || !std::isfinite(s) || !std::isfinite(v))
    do_throw("graphic.hsv: hue, saturation and value must be finite", 14);
  s = std::max(0.0, std::min(1.0, s));
  v = std::max(0.0, std::min(1.0, v));
  h = fmod(h, 360.0); if (h < 0) h += 360.0; double c = v * s, x = c * (1 - fabs(fmod(h / 60.0, 2) - 1)), m = v - c, r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
  return fac_gfx_rgb((int)((r + m) * 255 + 0.5), (int)((g + m) * 255 + 0.5), (int)((b + m) * 255 + 0.5));
}
int32_t fac_gfx_bitmap_textwidth(FacStr *s, int32_t scale) {
  if (scale < 1) scale = 1;
  int64_t count = s ? fac_str_grapheme_len(s) : 0;
  int64_t unit = 4LL * (int64_t)scale;
  if (count > INT32_MAX / unit) return INT32_MAX;
  return (int32_t)(count * unit);
}
// ข้อควรระวัง: do_throw ไม่คืนการควบคุมและไม่เรียก destructor ของ C++ -> ห้ามถือ std::string/std::vector ไว้ตอนเรียก
// ฟังก์ชันนี้จึงแยก impl ที่คืน nullptr พร้อมข้อความ error แล้วปล่อยทรัพยากรทั้งหมดก่อนค่อย throw
#define GFXFAIL(msg, cd) do { err = (msg); code = (cd); return nullptr; } while (0)
static Canvas *fac_gfx_load_make_canvas(int32_t w, int32_t h, std::string &err, int &code) {
  if (w <= 0 || h <= 0 || (uint64_t)(uint32_t)w * (uint64_t)(uint32_t)h > FAC_GFX_MAX_PIXELS) {
    err = "graphic.load: invalid image dimensions"; code = 14; return nullptr;
  }
  Canvas *c = new (std::nothrow) Canvas;
  if (!c) { err = "graphic.load: out of memory"; code = 5; return nullptr; }
  c->w = w; c->h = h;
  try {
    const size_t pixels = (size_t)w * (size_t)h;
    c->px.assign(pixels, 0);
    c->depth.assign(pixels, std::numeric_limits<double>::infinity());
  } catch (const std::bad_alloc &) {
    delete c; err = "graphic.load: out of memory"; code = 5; return nullptr;
  } catch (const std::length_error &) {
    delete c; err = "graphic.load: image allocation is too large"; code = 14; return nullptr;
  }
  return c;
}
static Canvas *fac_gfx_load_impl(FacStr *path, std::string &err, int &code) {
  constexpr size_t MAX_IMAGE_FILE_BYTES = (size_t)256 << 20;
  FILE *f = fopen(sd(path), "rb"); if (!f) GFXFAIL(std::string("cannot open file: ") + sd(path), 7);
  std::string all; char b[8192]; size_t n = 0;
  while ((n = fread(b, 1, sizeof b, f)) > 0) {
    if (n > MAX_IMAGE_FILE_BYTES - all.size()) {
      fclose(f); GFXFAIL("graphic.load: image file exceeds 256 MiB limit", 14);
    }
    try { all.append(b, n); }
    catch (const std::bad_alloc &) { fclose(f); GFXFAIL("graphic.load: out of memory reading image", 5); }
  }
  const bool readError = ferror(f) != 0;
  const int closeResult = fclose(f);
  if (readError || closeResult != 0) GFXFAIL("graphic.load: failed while reading image", 7);

  const uint8_t *d = (const uint8_t *)all.data();
  const size_t sz = all.size();
  auto le16 = [&](size_t i) -> uint16_t {
    return i <= sz && sz - i >= 2 ? (uint16_t)((uint16_t)d[i] | ((uint16_t)d[i + 1] << 8)) : 0;
  };
  auto le32 = [&](size_t i) -> uint32_t {
    return i <= sz && sz - i >= 4 ? (uint32_t)d[i] | ((uint32_t)d[i + 1] << 8) |
           ((uint32_t)d[i + 2] << 16) | ((uint32_t)d[i + 3] << 24) : 0;
  };
  auto signed32 = [](uint32_t v) -> int64_t {
    return (v & UINT32_C(0x80000000)) ? (int64_t)v - INT64_C(0x100000000) : (int64_t)v;
  };

  if (sz >= 2 && d[0] == 'B' && d[1] == 'M') {
    if (sz < 54) GFXFAIL("graphic.load: truncated BMP header", 14);
    const uint32_t fileBytes = le32(2), off = le32(10), dibBytes = le32(14);
    if (dibBytes < 40 || (uint64_t)dibBytes > (uint64_t)sz - 14)
      GFXFAIL("graphic.load: unsupported or truncated BMP DIB header", 14);
    if (fileBytes && fileBytes > sz) GFXFAIL("graphic.load: truncated BMP file", 14);
    if (off < 14u + (uint64_t)dibBytes || off > sz)
      GFXFAIL("graphic.load: invalid BMP pixel offset", 14);

    const int64_t w64 = signed32(le32(18));
    const int64_t hSigned = signed32(le32(22));
    const uint16_t planes = le16(26), bpp = le16(28);
    const uint32_t comp = le32(30);
    if (planes != 1 || (bpp != 24 && bpp != 32) || comp != 0 || w64 <= 0 || hSigned == 0 || hSigned == INT32_MIN)
      GFXFAIL("graphic.load: supports uncompressed BMP 24/32-bit with one plane", 14);
    const int64_t h64 = hSigned < 0 ? -hSigned : hSigned;
    const uint64_t pixels = (uint64_t)w64 * (uint64_t)h64;
    if (pixels > FAC_GFX_MAX_PIXELS) GFXFAIL("graphic.load: image exceeds 16M pixel limit", 14);
    const uint64_t bytesPerPixel = bpp / 8;
    const uint64_t unpaddedRow = (uint64_t)w64 * bytesPerPixel;
    const uint64_t rowBytes = (unpaddedRow + 3u) & ~UINT64_C(3);
    if (rowBytes == 0 || rowBytes > (uint64_t)sz - off || (uint64_t)h64 > ((uint64_t)sz - off) / rowBytes)
      GFXFAIL("graphic.load: truncated BMP pixel data", 14);
    const uint64_t requiredEnd = (uint64_t)off + rowBytes * (uint64_t)h64;
    if (fileBytes && fileBytes < requiredEnd) GFXFAIL("graphic.load: BMP declared size truncates pixel data", 14);

    const int32_t w = (int32_t)w64, h = (int32_t)h64;
    Canvas *c = fac_gfx_load_make_canvas(w, h, err, code);
    if (!c) return nullptr;
    const bool flip = hSigned > 0;
    const size_t bytes = (size_t)bytesPerPixel, rowb = (size_t)rowBytes;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
      const size_t o = (size_t)off + (size_t)(flip ? h - 1 - y : y) * rowb + (size_t)x * bytes;
      c->px[(size_t)y * (size_t)w + (size_t)x] = (uint32_t)d[o + 2] << 16 | (uint32_t)d[o + 1] << 8 | d[o];
    }
    return c;
  }

  if (sz >= 2 && d[0] == 'P' && d[1] == '6') {
    size_t p = 2;
    auto skip = [&]() {
      for (;;) {
        while (p < sz && (d[p] == ' ' || d[p] == '\t' || d[p] == '\r' || d[p] == '\n' || d[p] == '\f' || d[p] == '\v')) p++;
        if (p >= sz || d[p] != '#') break;
        while (p < sz && d[p] != '\n' && d[p] != '\r') p++;
      }
    };
    auto number = [&](uint32_t &out) -> bool {
      skip();
      if (p >= sz || d[p] < '0' || d[p] > '9') return false;
      uint32_t v = 0;
      while (p < sz && d[p] >= '0' && d[p] <= '9') {
        const uint32_t digit = (uint32_t)(d[p++] - '0');
        if (v > (UINT32_MAX - digit) / 10u) return false;
        v = v * 10u + digit;
      }
      out = v; return true;
    };
    uint32_t w32 = 0, h32 = 0, maxval = 0;
    if (!number(w32) || !number(h32) || !number(maxval) || w32 == 0 || h32 == 0 || maxval != 255)
      GFXFAIL("graphic.load: invalid PPM header", 14);
    // The P6 raster starts after exactly one mandatory whitespace separator;
    // CRLF is treated as one line ending so its LF is not mistaken for pixel data.
    if (p >= sz || !(d[p] == ' ' || d[p] == '\t' || d[p] == '\r' || d[p] == '\n' || d[p] == '\f' || d[p] == '\v'))
      GFXFAIL("graphic.load: missing PPM raster separator", 14);
    const uint8_t sep = d[p++];
    if (sep == '\r' && p < sz && d[p] == '\n') p++;
    const uint64_t pixels = (uint64_t)w32 * (uint64_t)h32;
    if (pixels > FAC_GFX_MAX_PIXELS) GFXFAIL("graphic.load: image exceeds 16M pixel limit", 14);
    const uint64_t bytesNeeded = pixels * 3u;
    if (bytesNeeded > (uint64_t)sz - p) GFXFAIL("graphic.load: truncated PPM pixel data", 14);
    Canvas *c = fac_gfx_load_make_canvas((int32_t)w32, (int32_t)h32, err, code);
    if (!c) return nullptr;
    for (size_t i = 0; i < (size_t)pixels; i++)
      c->px[i] = (uint32_t)d[p + i * 3] << 16 | (uint32_t)d[p + i * 3 + 1] << 8 | d[p + i * 3 + 2];
    return c;
  }

  if (sz >= 8 && d[0] == 0x89 && d[1] == 'P' && d[2] == 'N' && d[3] == 'G') {
    fimg::Image im;
    std::string e = fimg::decodePng(d, sz, im, crc32s);
    if (!e.empty()) GFXFAIL("graphic.load: " + e, 14);
    Canvas *c = fac_gfx_load_make_canvas(im.w, im.h, err, code);
    if (!c) return nullptr;
    const size_t pixels = (size_t)im.w * (size_t)im.h;
    for (size_t i = 0; i < pixels; i++) c->px[i] = (uint32_t)im.rgba[i * 4] << 16 | (uint32_t)im.rgba[i * 4 + 1] << 8 | im.rgba[i * 4 + 2];
    if (im.alpha) {
      try { c->alpha.resize(pixels); }
      catch (const std::bad_alloc &) { delete c; GFXFAIL("graphic.load: out of memory for alpha channel", 5); }
      for (size_t i = 0; i < pixels; i++) c->alpha[i] = im.rgba[i * 4 + 3];
    }
    return c;
  }
  GFXFAIL("graphic.load: supports .png, .bmp and .ppm (P6) only", 14);
}
#undef GFXFAIL
Canvas *fac_gfx_load(FacStr *path) {
  std::string err; int code = 14; Canvas *c = nullptr;
  try { c = fac_gfx_load_impl(path, err, code); }
  catch (const std::bad_alloc &) { err = "graphic.load: out of memory"; code = 5; }
  catch (const std::exception &) { err = "graphic.load: decoder failed"; code = 14; }
  if (c) return c;
  do_throw(std::move(err), code);   // all decoder locals have unwound before the FAC longjmp
}
}

// ---- รอบแก้ core: removeArc, overflow, Unicode case, Scanner EOF
extern "C" {
void fac_g_removearc(Graph *g, const void *a, const void *b) {
  int x = g->get(a, false), y = g->get(b, false); if (x < 0 || y < 0) return;
  g->removeOne(x, y);
}
[[noreturn]] void fac_overflow() { do_throw("integer overflow", 17); }
}

// ================================================================ vec / mat4  (column-major เหมือน OpenGL: m[col*4 + row])
extern "C" {
static void m4set(float *o, const float *s) { memcpy(o, s, 64); }
void fac_mat4_identity(float *o) { float m[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}; m4set(o, m); }
void fac_mat4_translate(float *o, float x, float y, float z) { fac_mat4_identity(o); o[12] = x; o[13] = y; o[14] = z; }
void fac_mat4_scale(float *o, float x, float y, float z) { fac_mat4_identity(o); o[0] = x; o[5] = y; o[10] = z; }
void fac_mat4_rotatex(float *o, float a) { fac_mat4_identity(o); float c = cosf(a), s = sinf(a); o[5] = c; o[6] = s; o[9] = -s; o[10] = c; }
void fac_mat4_rotatey(float *o, float a) { fac_mat4_identity(o); float c = cosf(a), s = sinf(a); o[0] = c; o[2] = -s; o[8] = s; o[10] = c; }
void fac_mat4_rotatez(float *o, float a) { fac_mat4_identity(o); float c = cosf(a), s = sinf(a); o[0] = c; o[1] = s; o[4] = -s; o[5] = c; }
void fac_mat4_perspective(float *o, float fovy, float aspect, float n, float f) {
  float t = tanf(fovy / 2); memset(o, 0, 64); o[0] = 1 / (aspect * t); o[5] = 1 / t; o[10] = -(f + n) / (f - n); o[11] = -1; o[14] = -(2 * f * n) / (f - n);
}
void fac_mat4_ortho(float *o, float l, float r, float b, float t, float n, float f) {
  fac_mat4_identity(o); o[0] = 2 / (r - l); o[5] = 2 / (t - b); o[10] = -2 / (f - n); o[12] = -(r + l) / (r - l); o[13] = -(t + b) / (t - b); o[14] = -(f + n) / (f - n);
}
static void v3norm(float *v) { float l = sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); if (l > 0) { v[0] /= l; v[1] /= l; v[2] /= l; } }
static void v3cross(float *o, const float *a, const float *b) { o[0] = a[1] * b[2] - a[2] * b[1]; o[1] = a[2] * b[0] - a[0] * b[2]; o[2] = a[0] * b[1] - a[1] * b[0]; }
void fac_mat4_lookat(float *o, const float *eye, const float *center, const float *up) {
  float f[3] = {center[0] - eye[0], center[1] - eye[1], center[2] - eye[2]}, s[3], u[3]; v3norm(f); v3cross(s, f, up); v3norm(s); v3cross(u, s, f);
  fac_mat4_identity(o);
  o[0] = s[0]; o[4] = s[1]; o[8] = s[2]; o[1] = u[0]; o[5] = u[1]; o[9] = u[2]; o[2] = -f[0]; o[6] = -f[1]; o[10] = -f[2];
  o[12] = -(s[0] * eye[0] + s[1] * eye[1] + s[2] * eye[2]); o[13] = -(u[0] * eye[0] + u[1] * eye[1] + u[2] * eye[2]); o[14] = f[0] * eye[0] + f[1] * eye[1] + f[2] * eye[2];
}
void fac_mat4_transpose(float *o, const float *m) { float t[16]; for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) t[r * 4 + c] = m[c * 4 + r]; m4set(o, t); }
void fac_mat4_mul(float *o, const float *a, const float *b) {
  float t[16]; for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) { float s = 0; for (int k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; t[c * 4 + r] = s; } m4set(o, t);
}
void fac_mat4_mulv(float *o, const float *m, const float *v) { float t[4]; for (int r = 0; r < 4; r++) t[r] = m[r] * v[0] + m[4 + r] * v[1] + m[8 + r] * v[2] + m[12 + r] * v[3]; memcpy(o, t, 16); }
void fac_mat4_mulp(float *o, const float *m, const float *v) { float t[3]; for (int r = 0; r < 3; r++) t[r] = m[r] * v[0] + m[4 + r] * v[1] + m[8 + r] * v[2] + m[12 + r]; memcpy(o, t, 12); }
void fac_mat4_inverse(float *o, const float *m) {  // Gauss-Jordan (double); singular -> throw Error
  double a[4][8]; for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) { a[r][c] = m[c * 4 + r]; a[r][4 + c] = r == c; }
  for (int i = 0; i < 4; i++) {
    int p = i; for (int r = i + 1; r < 4; r++) if (fabs(a[r][i]) > fabs(a[p][i])) p = r;
    if (fabs(a[p][i]) < 1e-12) do_throw("mat4.inverse: singular matrix", 18);
    if (p != i) for (int c = 0; c < 8; c++) std::swap(a[p][c], a[i][c]);
    double d = a[i][i]; for (int c = 0; c < 8; c++) a[i][c] /= d;
    for (int r = 0; r < 4; r++) if (r != i) { double f = a[r][i]; for (int c = 0; c < 8; c++) a[r][c] -= f * a[i][c]; }
  }
  float t[16]; for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) t[c * 4 + r] = (float)a[r][4 + c]; m4set(o, t);
}
FacStr *fac_vec_str(const float *v, int32_t n) { std::string s = "("; for (int i = 0; i < n; i++) { if (i) s += ", "; s += fmtf(v[i]); } return mks(s + ")"); }
FacStr *fac_mat4_str(const float *m) {
  std::string s = "mat4["; for (int r = 0; r < 4; r++) { s += r ? "\n     [" : "["; for (int c = 0; c < 4; c++) { if (c) s += ", "; s += fmtf(m[c * 4 + r]); } s += "]"; } return mks(s + "]");
}
void fac_print_vec(const float *v, int32_t n) { FacStr *s = fac_vec_str(v, n); fac_print_str(s); fac_str_free(s); }
void fac_print_mat4(const float *m) { FacStr *s = fac_mat4_str(m); fac_print_str(s); fac_str_free(s); }
}
