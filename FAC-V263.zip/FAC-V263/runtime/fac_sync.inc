// fac_sync.inc -- sync.Channel: คิวข้อความ (string) ที่ปลอดภัยข้าม thread (included at the end of fac_rt.cpp)
//
// Used only through stdlib/sync.fac (class sync.Channel), the audited module that --safe code may share with threads.
// Design: one std::mutex + two condition variables; messages are copied in and out (no shared buffers); capacity is
// always bounded (1 .. kChanMaxCap) so a fast producer cannot exhaust memory; every blocking call has a timeout
// (negative = wait forever); close() wakes all waiters; messages are NUL-terminated C strings (no embedded NUL).
#include <condition_variable>
#include <new>

namespace {
constexpr int32_t kChanMaxCap = 1 << 20;
struct FacChan {
  std::mutex m;
  std::condition_variable notEmpty, notFull;
  std::deque<std::string> q;
  size_t cap = 1;
  bool closed = false;
};
}  // namespace

extern "C" {
// capacity is clamped to [1, 1048576]. Returns NULL on allocation failure.
void *fac_sync_chan_new(int32_t capacity) {
  FacChan *c = new (std::nothrow) FacChan;
  if (!c) return nullptr;
  c->cap = (size_t)(capacity < 1 ? 1 : capacity > kChanMaxCap ? kChanMaxCap : capacity);
  return c;
}
// 1 = queued; 0 = timed out, channel closed, or bad argument
int32_t fac_sync_chan_send(void *h, const char *msg, int32_t timeoutMs) {
  if (!h || !msg) return 0;
  FacChan *c = (FacChan *)h;
  try {
    std::string copy(msg);   // copy outside the lock
    std::unique_lock<std::mutex> lk(c->m);
    auto ready = [&] { return c->closed || c->q.size() < c->cap; };
    if (timeoutMs < 0) c->notFull.wait(lk, ready);
    else if (!c->notFull.wait_for(lk, std::chrono::milliseconds(timeoutMs), ready)) return 0;
    if (c->closed) return 0;
    c->q.push_back(std::move(copy));
    lk.unlock();
    c->notEmpty.notify_one();
    return 1;
  } catch (...) { return 0; }
}
// Returns a malloc'd NUL-terminated copy (release with fac_sync_str_free), or NULL on timeout / closed-and-empty.
char *fac_sync_chan_recv(void *h, int32_t timeoutMs) {
  if (!h) return nullptr;
  FacChan *c = (FacChan *)h;
  try {
    std::unique_lock<std::mutex> lk(c->m);
    auto ready = [&] { return c->closed || !c->q.empty(); };
    if (timeoutMs < 0) c->notEmpty.wait(lk, ready);
    else if (!c->notEmpty.wait_for(lk, std::chrono::milliseconds(timeoutMs), ready)) return nullptr;
    if (c->q.empty()) return nullptr;   // closed and drained
    // Allocate/copy before removing the queued value. If the caller cannot
    // obtain its result buffer, return NULL but leave the message available
    // for a later receive instead of silently losing it.
    const std::string &front = c->q.front();
    char *out = (char *)malloc(front.size() + 1);
    if (!out) return nullptr;
    memcpy(out, front.c_str(), front.size() + 1);
    c->q.pop_front();
    lk.unlock();
    c->notFull.notify_one();
    return out;
  } catch (...) { return nullptr; }
}
void fac_sync_str_free(char *s) { free(s); }
// After close(): send() fails, recv() drains what is queued and then returns NULL.
void fac_sync_chan_close(void *h) {
  if (!h) return;
  FacChan *c = (FacChan *)h;
  { std::lock_guard<std::mutex> lk(c->m); c->closed = true; }
  c->notEmpty.notify_all(); c->notFull.notify_all();
}
// true once the channel is closed and empty (monotonic: never goes back to false)
int32_t fac_sync_chan_done(void *h) {
  if (!h) return 1;
  FacChan *c = (FacChan *)h;
  std::lock_guard<std::mutex> lk(c->m);
  return c->closed && c->q.empty();
}
int32_t fac_sync_chan_len(void *h) {
  if (!h) return 0;
  FacChan *c = (FacChan *)h;
  std::lock_guard<std::mutex> lk(c->m);
  return (int32_t)c->q.size();
}
// Called by the owning FAC object's destructor, i.e. when no thread can still reference it.
void fac_sync_chan_free(void *h) {
  if (!h) return;
  fac_sync_chan_close(h);
  delete (FacChan *)h;
}

// ---- sync.Cell: ค่า string หนึ่งค่าที่แชร์ข้าม thread ได้ (mutex อยู่ข้างใน ไม่มีใครถือ lock ข้ามการเรียก)
// get/set/swap/cas ทั้งหมด atomic; ข้อความเป็น C string (ไม่มี NUL); คืน malloc'd copy ให้ปล่อยด้วย fac_sync_str_free
struct FacCell { std::mutex m; std::string v; };
void *fac_sync_cell_new(const char *init) {
  try { FacCell *c = new (std::nothrow) FacCell; if (!c) return nullptr; if (init) c->v = init; return c; } catch (...) { return nullptr; }
}
static char *cell_copy(const std::string &s) {
  char *out = (char *)malloc(s.size() + 1);
  if (out) memcpy(out, s.c_str(), s.size() + 1);
  return out;
}
char *fac_sync_cell_get(void *h) {
  if (!h) return nullptr;
  FacCell *c = (FacCell *)h; std::lock_guard<std::mutex> lk(c->m);
  return cell_copy(c->v);
}
// returns 1 on success, 0 on bad argument / out of memory (the old value is kept)
int32_t fac_sync_cell_set(void *h, const char *val) {
  if (!h || !val) return 0;
  FacCell *c = (FacCell *)h;
  try { std::string copy(val); std::lock_guard<std::mutex> lk(c->m); c->v.swap(copy); return 1; } catch (...) { return 0; }
}
// stores val and returns the previous value (malloc'd copy) in one atomic step; NULL on failure (the value is then unchanged)
char *fac_sync_cell_swap(void *h, const char *val) {
  if (!h || !val) return nullptr;
  FacCell *c = (FacCell *)h;
  try {
    std::string copy(val); std::lock_guard<std::mutex> lk(c->m);
    char *old = cell_copy(c->v);
    if (!old) return nullptr;
    c->v.swap(copy);
    return old;
  } catch (...) { return nullptr; }
}
// compare-and-set: 1 if the value equalled expected and was replaced by desired, else 0
int32_t fac_sync_cell_cas(void *h, const char *expected, const char *desired) {
  if (!h || !expected || !desired) return 0;
  FacCell *c = (FacCell *)h;
  try {
    std::string copy(desired); std::lock_guard<std::mutex> lk(c->m);
    if (c->v != expected) return 0;
    c->v.swap(copy); return 1;
  } catch (...) { return 0; }
}
void fac_sync_cell_free(void *h) { delete (FacCell *)h; }
}
