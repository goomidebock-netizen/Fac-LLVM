#!/usr/bin/env python3
"""FAC API contract tags: generate, check and audit (V44).

Public functions of source-level libraries carry four contract tags in ``##`` documentation
comments (FAC comments start with ``#``; ``///`` is *not* a comment in FAC):

    ## @returns   what comes back and who owns it
    ## @ownership how each parameter is treated (borrowed / by value / retained / consumed)
    ## @errors    whether the function can throw and what
    ## @thread-safety  concurrency contract

``generate`` derives the tags *mechanically* from the declaration and body (types of the
parameters, ``throw`` statements, calls to throwing built-ins, writes to ``this`` or module
state) and marks each block with ``## @generated V44``.  Generated blocks are rewritten on every
run; a block without that marker is hand-written and is never touched.  Comments cannot change
program behaviour, which ``verify-ir`` proves by comparing compiler IR before and after.

usage:
  api_contract.py audit   [--strict]          list public functions lacking contract tags
  api_contract.py generate [--write]          show / apply generated tag blocks
  api_contract.py check                       fail when a generated block is stale
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import facsrc  # noqa: E402

TAGS = ("returns", "ownership", "errors", "thread-safety")
MARK = "@generated V44"
SCALARS = {"int", "uint", "long", "ulong", "short", "ushort", "byte", "ubyte", "double", "float",
           "boolean", "char", "unichar"}


def load_manifest() -> dict:
    p = ROOT / "api" / "manifest.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    import api_manifest
    return api_manifest.build()


def throwing_builtins() -> dict:
    out = {}
    for e in load_manifest()["builtin"]:
        er = e["errors"]
        if er["model"] == "throws":
            out[e["name"]] = er["codes"]
    return out


SAFE_TS = {"safe-pure", "safe-atomic", "safe-per-thread"}


def safe_builtins() -> set:
    return {e["name"] for e in load_manifest()["builtin"] if e["thread_safety"] in SAFE_TS}


def builtin_modules() -> set:
    return set(load_manifest()["modules"]) | {"mat4"}


def split_params(text: str) -> list:
    out, depth, cur = [], 0, ""
    for ch in text:
        if ch in "(<[":
            depth += 1
        elif ch in ")>]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def param_info(p: str):
    """-> (type_text, name, is_ref)"""
    words = p.replace("...", " ... ").split()
    ref = "ref" in words
    words = [w for w in words if w != "ref"]
    name = words[-1] if words else ""
    return " ".join(words[:-1]), name, ref


def describe_param(t: str, name: str, ref: bool, retained: bool) -> str:
    base = t.split()[-1] if t.split() else t
    if ref:
        return f"{name}=borrowed mutable (ref)"
    if t.startswith("function") or "function" in t.split()[:1]:
        return f"{name}=borrowed callable" + (", retained" if retained else "")
    if t.startswith("ptr"):
        return f"{name}=non-owning handle, not freed here"
    if t.startswith("obj") or base[:1].isupper():
        return f"{name}=object reference, shared" + (" and retained by the receiver" if retained else ", not consumed")
    if t.startswith("list") or t.startswith("dyn"):
        return f"{name}=borrowed (read-only view for the call)" + (", copied into state" if retained else "")
    if base == "string":
        return f"{name}=borrowed (immutable, shared)"
    if base in SCALARS:
        return f"{name}=by value"
    return f"{name}=borrowed"


def describe_return(ret: str) -> str:
    r = ret.strip()
    if r in ("void", ""):
        return "Nothing."
    if r.startswith("("):
        return f"Tuple {r.replace(' ', '')} by value."
    if r in SCALARS:
        return f"{r} by value."
    if r in ("string", "dyn string"):
        return "Owned string (caller-owned, immutable)."
    if r.startswith("enum"):
        return f"{r.replace('enum ', '')} value; managed payloads are owned by the caller."
    if r.startswith("ptr"):
        return "Non-owning handle."
    if r.startswith("obj") or r[:1].isupper():
        return "Object reference; caller owns its reference."
    return f"{r}; ownership follows the language rules for this type."


def module_globals(src: str) -> set:
    res = facsrc.lex(src)
    toks = [t for t in res.tokens if t.kind != "comment"]
    depth, i, names = 0, 0, set()
    starters = {"var", "dyn", "heap", "ptr", "array", "list", "hashmap", "hashset", "arraylist", "linked",
                "stack", "queue", "tree", "graph", "matrix", "volatile", "align"}
    while i < len(toks):
        t = toks[i]
        if t.kind == "op" and t.text == "{":
            depth += 1
        elif t.kind == "op" and t.text == "}":
            depth -= 1
        elif depth == 0 and t.kind == "ident" and t.text in starters and (i == 0 or toks[i - 1].line != t.line):
            j = i
            name = None
            while j < len(toks) and toks[j].line == t.line:
                if toks[j].kind == "op" and toks[j].text in "=[":
                    break
                if toks[j].kind == "ident":
                    name = toks[j].text
                j += 1
            if name:
                names.add(name)
        i += 1
    return names


def facts(d, lines: list, all_funcs: set, globals_: set, modules: set) -> dict:
    body = "\n".join(lines[d.line - 1:d.end_line]) if d.end_line >= d.line else lines[d.line - 1]
    toks = [t for t in facsrc.lex(body).tokens if t.kind not in ("comment", "str", "char")]
    code = " ".join(t.text for t in toks)
    code = re.sub(r"\s*\.\s*", ".", code)
    code = re.sub(r"\s+\(", "(", code)
    params = [param_info(p) for p in split_params(d.params)]
    pnames = {n for _, n, _ in params}
    qualified = set(re.findall(r"\b([a-z][A-Za-z0-9]*\.[A-Za-z0-9_]+)\(", code))
    builtin_calls = {q for q in qualified if q.split(".")[0] in modules}
    unknown_calls = {q for q in qualified if q.split(".")[0] not in modules and not q.startswith(("this.", "super."))}
    this_calls = set(re.findall(r"\bthis\.([A-Za-z0-9_]+)\(", code))
    local_calls = {c for c in re.findall(r"(?<![.\w])([A-Za-z_]\w*)\(", code) if c in all_funcs and c != d.name}
    news = bool(re.search(r"\bnew\s+[A-Z]", code))
    mutates = bool(re.search(r"\bthis\.\w+(?:\s*\[[^\]]*\])?(?:\.\w+)*\s*(?:=(?!=)|\+=|-=|\*=|/=|%=|\+\+|--)", code))
    gl = sorted(g for g in globals_ if re.search(r"(?<![.\w])" + re.escape(g) + r"\b", code) and g not in pnames)
    throws = sorted(set(re.findall(r"\bthrow Error\([^;]*?,\s*(\d+)\s*\)", code)))
    return {"code": code, "params": params, "builtin_calls": builtin_calls, "unknown_calls": unknown_calls,
            "this_calls": this_calls, "local_calls": local_calls, "new": news, "mutates": mutates,
            "globals": gl, "throws": throws, "direct_throw": d.body_has_throw,
            "atomic": any(c.startswith(("thread.atomic", "mutex.")) for c in builtin_calls) or ".lock(" in code}


def purity(all_facts: dict, safe: set) -> dict:
    """fixpoint: key -> True when the function only reads its arguments / receiver and calls pure things."""
    pure = {k: not (f["mutates"] or f["globals"] or f["atomic"] or f["unknown_calls"] or f["new"])
            and all(c in safe for c in f["builtin_calls"]) for k, f in all_facts.items()}
    changed = True
    while changed:
        changed = False
        for k, f in all_facts.items():
            if not pure[k]:
                continue
            callees = f["local_calls"] | f["this_calls"]
            for c in callees:
                keys = [kk for kk in all_facts if kk[1] == c]
                if not keys or not all(pure[kk] for kk in keys):
                    pure[k] = False
                    changed = True
                    break
    return pure


def analyse(d, f: dict, is_pure: bool, builtins: dict) -> dict:
    parts = []
    for t, n, ref in f["params"]:
        retained = bool(n) and bool(re.search(r"(?:\bthis\.\w+|\b\w+)\s*=\s*" + re.escape(n) + r"\b(?!\s*[=(.])", f["code"]))
        freed = bool(n) and bool(re.search(r"\bfree\(\s*" + re.escape(n) + r"\s*\)", f["code"]))
        txt = describe_param(t, n, ref, retained)
        if freed:
            txt = f"{n}=consumed (freed by this call)"
        parts.append(txt)
    own = "; ".join(parts) if parts else "no parameters"
    called = sorted(c for c in f["builtin_calls"] if c in builtins)
    if f["direct_throw"] or called:
        bits = []
        if f["direct_throw"]:
            bits.append("explicit throw Error" + (f" (code {', '.join(f['throws'])})" if f["throws"] else ""))
        if called:
            bits.append("propagates Error from " + ", ".join(called[:4]) + (" ..." if len(called) > 4 else ""))
        errs = "Can throw: " + "; ".join(bits) + "."
    elif f["local_calls"] or f["this_calls"] or f["unknown_calls"] or f["new"]:
        errs = "No direct throw; errors thrown by called FAC functions or methods propagate."
    else:
        errs = "None: does not throw."
    if f["atomic"] and not f["mutates"] and not f["globals"]:
        ts = "Atomic: built on thread.atomic*/mutex operations; safe for concurrent calls."
    elif d.parent and f["mutates"]:
        ts = f"Not thread-safe: mutates the {d.parent} receiver; synchronize externally."
    elif f["globals"]:
        ts = "Not thread-safe: uses module-level state (" + ", ".join(f["globals"][:3]) + ")."
    elif is_pure and d.parent:
        ts = f"Read-only on the {d.parent} receiver: safe concurrently with other readers, not with a writer."
    elif is_pure and any(t.startswith("ptr") for t, _, _ in f["params"]):
        ts = "Operates on the supplied handle; the caller must serialize access to it."
    elif is_pure:
        ts = "Safe: depends only on its arguments."
    else:
        ts = "Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe."
    return {"returns": describe_return(d.ret), "ownership": own, "errors": errs, "thread-safety": ts}


def block_range(lines: list, decl_line: int):
    """(start_idx, end_idx_exclusive) of the contiguous ## block directly above decl_line (1-based)."""
    end = decl_line - 1
    j = end - 1
    while j >= 0 and lines[j].lstrip().startswith("##"):
        j -= 1
    return j + 1, end


def process(path: pathlib.Path, builtins: dict, safe: set, modules: set, write: bool):
    src = path.read_text(encoding="utf-8")
    eol = "\r\n" if "\r\n" in src else "\n"
    lines = src.replace("\r\n", "\n").split("\n")
    text = "\n".join(lines)
    allfn = [d for d in facsrc.scan_declarations(text) if d.kind == "function"]
    all_funcs = {d.name for d in allfn}
    globals_ = module_globals(text)
    all_facts = {(d.parent, d.name, d.line): facts(d, lines, all_funcs, globals_, modules) for d in allfn}
    # purity is keyed (line, name) so overloads / same-named methods stay distinct
    pure = purity({(k[2], k[1]): v for k, v in all_facts.items()}, safe)
    changed, report = 0, []
    for d in sorted([x for x in allfn if x.public], key=lambda x: -x.line):   # bottom-up keeps indices valid
        s, e = block_range(lines, d.line)
        existing = lines[s:e]
        generated = any(MARK in x for x in existing)
        hand_tags = any(re.search(r"@(" + "|".join(TAGS) + r")\b", x) for x in existing) and not generated
        if hand_tags:
            continue
        indent = re.match(r"\s*", lines[d.line - 1]).group(0)
        tags = analyse(d, all_facts[(d.parent, d.name, d.line)], pure[(d.line, d.name)], builtins)
        new = [f"{indent}## {MARK} (mechanical; delete this line to take ownership of the block)"]
        new += [f"{indent}## @{k} {tags[k]}" for k in TAGS]
        keep = [x for x in existing if MARK not in x and not re.search(r"@(" + "|".join(TAGS) + r")\b", x)]
        new = keep + new
        if existing != new:
            changed += 1
            report.append(f"{path.name}:{d.line}: {d.name}")
            lines[s:e] = new
    if write and changed:
        path.write_text(eol.join(lines), encoding="utf-8")
    return changed, report


def audit(strict: bool) -> int:
    import api_manifest
    data = api_manifest.build()
    gaps = [e for e in data["source"] if e["kind"] == "source-function" and any(t not in e["contract"] for t in TAGS)]
    total = sum(1 for e in data["source"] if e["kind"] == "source-function")
    print(f"{total} public source functions; {len(gaps)} lack one or more of {', '.join('@' + t for t in TAGS)}")
    for e in gaps[:50]:
        miss = [t for t in TAGS if t not in e["contract"]]
        print(f"  {e['file']}:{e['line']}: {e['name']} missing {', '.join(miss)}")
    return 1 if strict and gaps else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    a1 = sub.add_parser("audit")
    a1.add_argument("--strict", action="store_true")
    a2 = sub.add_parser("generate")
    a2.add_argument("--write", action="store_true")
    sub.add_parser("check")
    a = ap.parse_args(argv)
    if a.cmd == "audit":
        return audit(a.strict)
    builtins = throwing_builtins()
    safe, modules = safe_builtins(), builtin_modules()
    total, rep = 0, []
    for p in sorted((ROOT / "stdlib").glob("*.fac")):
        n, r = process(p, builtins, safe, modules, write=(a.cmd == "generate" and a.write))
        total += n
        rep += r
    if a.cmd == "check":
        if total:
            print(f"{total} contract blocks are stale; run: python3 tools/api_contract.py generate --write")
            for r in rep[:20]:
                print("  " + r)
            return 1
        print("contract blocks up to date")
        return 0
    verb = "updated" if a.write else "would update"
    print(f"{verb} {total} contract blocks")
    for r in rep[:15]:
        print("  " + r)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
