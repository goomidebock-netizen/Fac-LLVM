#!/usr/bin/env python3
"""FAC debugger launcher (V44) -- native gdb/lldb, function-level.

What works today (no compiler change): the program is built with ``-O0``, FAC functions keep the
symbol names the compiler emits (``fac.<module>.<function>``), so you can break on them, step at machine
level, inspect the backtrace and registers.  ``--break module.function`` is checked against the IR the
compiler produces, so a typo is reported instead of silently ignored.

What does NOT work yet: source-line breakpoints, stepping by FAC line and local-variable inspection.
That needs DWARF debug information, which ``facc`` does not emit (the ``--debug`` flag only adds
runtime null/double-free checks).  See docs/TOOLING.md ("Debugger") for the proposed ``-g`` design.

usage: fac_debug.py SOURCE.fac [--break mod.fn ...] [--list] [--print] [--compiler PATH] [-- PROGRAM ARGS]
"""
from __future__ import annotations

import argparse
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import fac_diagnostics  # noqa: E402

ROOT = HERE.parent


def defined_functions(ll: str) -> list:
    return sorted(set(re.findall(r"^define [^@\n]*@(fac\.[A-Za-z0-9_.$]+)\(", ll, re.M)))


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    prog_args: list = []
    if "--" in argv:
        i = argv.index("--")
        argv, prog_args = argv[:i], argv[i + 1:]
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("source")
    ap.add_argument("--break", dest="breaks", action="append", default=[], metavar="MOD.FN")
    ap.add_argument("--list", action="store_true", help="list breakable FAC functions and exit")
    ap.add_argument("--print", action="store_true", help="print the debugger command instead of running it")
    ap.add_argument("--compiler")
    a = ap.parse_args(argv)
    facc = fac_diagnostics.find_compiler(a.compiler)
    if not facc:
        print("error: compiler not found; build it with `make`", file=sys.stderr)
        return 1
    env = dict(os.environ)
    env.setdefault("FAC_HOME", str(ROOT))
    with tempfile.TemporaryDirectory(prefix="fac-debug-") as td:
        ll = pathlib.Path(td) / "program.ll"
        r = subprocess.run([facc, a.source, "-o", str(ll), "--emit-ll", "-O0"], env=env)
        if r.returncode:
            return r.returncode
        funcs = defined_functions(ll.read_text(encoding="utf-8", errors="replace"))
        if a.list:
            print("\n".join(f.replace("fac.", "", 1) for f in funcs))
            return 0
        syms = []
        for b in a.breaks:
            hits = [f for f in funcs if f == "fac." + b or f.endswith("." + b.split(".")[-1]) and f.startswith("fac." + b.split(".")[0] + ".")]
            if not hits:
                near = [f[4:] for f in funcs if b.split(".")[-1].lower() in f.lower()][:8]
                print(f"error: no function {b!r} in the program" + (f"; did you mean: {', '.join(near)}" if near else ""), file=sys.stderr)
                return 1
            syms += hits
        exe = pathlib.Path(td) / ("program.exe" if os.name == "nt" else "program")
        r = subprocess.run([facc, a.source, "-o", str(exe), "-O0"], env=env)
        if r.returncode:
            return r.returncode
        dbg = shutil.which("lldb") or shutil.which("gdb")
        if not dbg:
            print("error: install LLDB or GDB (the executable built successfully)", file=sys.stderr)
            return 1
        lldb = pathlib.Path(dbg).stem == "lldb"
        script = pathlib.Path(td) / "init.cmd"
        cmds = [(f"breakpoint set -n '{s}'" if lldb else f"break '{s}'") for s in syms]
        script.write_text("\n".join(cmds) + "\n", encoding="utf-8")
        if lldb:
            cmd = [dbg, "-s", str(script), "--", str(exe)] + prog_args if cmds else [dbg, "--", str(exe)] + prog_args
        else:
            cmd = [dbg, "-x", str(script), "--args", str(exe)] + prog_args if cmds else [dbg, "--args", str(exe)] + prog_args
        if a.print:
            print(" ".join(cmd))
            print("\n".join(cmds))
            return 0
        print("note: function-level debugging only; source lines/locals need DWARF output (see docs/TOOLING.md)", file=sys.stderr)
        return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
