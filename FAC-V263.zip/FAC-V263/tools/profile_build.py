#!/usr/bin/env python3
"""Measure clean FAC compiler/runtime build time with reproducible metadata.

Examples:
  python3 tools/profile_build.py --target compiler-only --cxx clang++ --compiler-flags '-std=c++17 -O1' --runs 1
  python3 tools/profile_build.py --target all --cxx g++ --compiler-flags '-std=c++17 -O1' --flags '-std=c++17 -O2' --runs 3

Each sample starts from `make clean`. Build output is retained in
`build-profile/run-N.log`; the JSON summary defaults to
`build-profile/profile.json`.
"""
from __future__ import annotations

import argparse
import json
import platform
import shlex
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(
    command: list[str], *, cwd: Path, log_path: Path | None = None, timeout: int | None = None
) -> subprocess.CompletedProcess[str]:
    try:
        if log_path is None:
            return subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False, timeout=timeout)
        with log_path.open("w", encoding="utf-8") as log:
            return subprocess.run(command, cwd=cwd, text=True, stdout=log, stderr=subprocess.STDOUT,
                                  check=False, timeout=timeout)
    except subprocess.TimeoutExpired:
        message = f"command timed out after {timeout} seconds: {command!r}"
        if log_path is not None:
            with log_path.open("a", encoding="utf-8") as log:
                log.write("\n" + message + "\n")
        return subprocess.CompletedProcess(command, 124, stdout="", stderr=message)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=("compiler-only", "runtime-only", "all"), default="compiler-only")
    parser.add_argument("--cxx", default="c++", help="compiler executable (or a whitespace-separated launcher + compiler)")
    parser.add_argument("--flags", default="-std=c++17 -O2", help="Runtime CXXFLAGS passed to Make")
    parser.add_argument("--compiler-flags", default="-std=c++17 -O1", help="COMPILER_CXXFLAGS passed to Make")
    parser.add_argument("--runs", type=int, default=3, help="number of independent clean builds (1–10)")
    parser.add_argument("--jobs", type=int, default=1, help="parallel Make jobs (default 1 to limit peak memory)")
    parser.add_argument("--timeout-seconds", type=int, default=1800, help="per-build timeout (default 1800 seconds)")
    parser.add_argument("--make", default="make", help="GNU Make executable")
    parser.add_argument("--output", default="build-profile/profile.json", help="JSON report path")
    args = parser.parse_args()
    if not 1 <= args.runs <= 10:
        parser.error("--runs must be between 1 and 10")
    if not 1 <= args.jobs <= 16:
        parser.error("--jobs must be between 1 and 16")
    if not 30 <= args.timeout_seconds <= 86400:
        parser.error("--timeout-seconds must be between 30 and 86400")
    cxx_argv = shlex.split(args.cxx)
    if not cxx_argv:
        parser.error("--cxx must name a compiler")

    profile_dir = ROOT / "build-profile"
    profile_dir.mkdir(parents=True, exist_ok=True)
    output_path = (ROOT / args.output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    version_result = run(cxx_argv + ["--version"], cwd=ROOT)
    compiler_version = (version_result.stdout or version_result.stderr).splitlines()
    compiler_version = compiler_version[0] if compiler_version else "unknown"
    samples: list[float] = []
    logs: list[str] = []
    failure: dict[str, object] | None = None

    for index in range(1, args.runs + 1):
        clean = run([args.make, "clean"], cwd=ROOT, timeout=120)
        if clean.returncode:
            failure = {"stage": "clean", "returncode": clean.returncode, "stderr": clean.stderr[-4000:]}
            break
        log_path = profile_dir / f"run-{index}.log"
        command = [
            args.make,
            f"-j{args.jobs}",
            args.target,
            f"CXX={args.cxx}",
            f"CXXFLAGS={args.flags}",
            f"COMPILER_CXXFLAGS={args.compiler_flags}",
        ]
        start = time.perf_counter()
        result = run(command, cwd=ROOT, log_path=log_path, timeout=args.timeout_seconds)
        elapsed = time.perf_counter() - start
        logs.append(str(log_path.relative_to(ROOT)))
        if result.returncode:
            failure = {
                "stage": "build",
                "run": index,
                "returncode": result.returncode,
                "log": str(log_path.relative_to(ROOT)),
            }
            break
        samples.append(elapsed)

    report: dict[str, object] = {
        "schema": 1,
        "target": args.target,
        "compiler_command": args.cxx,
        "compiler_version": compiler_version,
        "cxxflags": args.flags,
        "compiler_cxxflags": args.compiler_flags,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python": platform.python_version(),
        "requested_runs": args.runs,
        "make_jobs": args.jobs,
        "timeout_seconds": args.timeout_seconds,
        "completed_runs": len(samples),
        "sample_seconds": samples,
        "median_seconds": statistics.median(samples) if samples else None,
        "logs": logs,
        "failure": failure,
    }
    output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    if failure:
        print(f"build profile failed: {failure}; see {output_path}", file=sys.stderr)
        return int(failure.get("returncode", 1)) or 1
    print(
        f"target={args.target} compiler={compiler_version} runs={len(samples)} "
        f"median_seconds={statistics.median(samples):.3f} report={output_path}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
