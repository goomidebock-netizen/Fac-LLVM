#!/usr/bin/env python3
"""FAC formatter (V44).

Conservative, token-safe layout normaliser built on ``facsrc`` (the same lexical rules as the
compiler).  It changes ONLY whitespace at line starts/ends and runs of blank lines:

  * re-indents each line from bracket nesting ({} adds a level; a continuation line inside an
    unclosed ( or [ gets one extra level), tabs in indentation become spaces
  * strips trailing whitespace (never inside ``#* ... *#`` block comments)
  * collapses runs of blank lines (default max 1), removes leading blank lines, ensures one final newline
  * keeps CRLF/LF line endings and a UTF-8 BOM as found (override with --eol)

It never reflows, reorders or rewrites tokens.  Before returning, the result is re-lexed and the
token stream compared with the input (comments compared modulo trailing blanks); on any mismatch the
file is left untouched and an error is reported.  Files with lexical errors are skipped.

usage: facfmt.py [--check] [--diff] [--stdin] [--indent N] [--max-blank N] [--eol auto|lf|crlf] PATH...
Directories are searched recursively for *.fac.  Defaults come from the nearest fac.toml [fmt].
"""
from __future__ import annotations

import argparse
import difflib
import pathlib
import sys
from typing import List, Optional

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import facsrc  # noqa: E402

try:
    import tomllib  # Python 3.11+
except ImportError:  # pragma: no cover
    tomllib = None


class FormatError(Exception):
    pass


def _tok_key(t: facsrc.Tok):
    return (t.kind, t.text.rstrip() if t.kind == "comment" and not t.text.startswith("#*") else t.text)


def format_text(src: str, indent: int = 4, max_blank: int = 1, eol: str = "auto") -> str:
    bom = src.startswith("\ufeff")
    body = src[1:] if bom else src
    crlf = body.count("\r\n") * 2 > body.count("\n") if "\n" in body else False
    if eol == "lf":
        crlf = False
    elif eol == "crlf":
        crlf = True
    text = body.replace("\r\n", "\n")
    res = facsrc.lex(text)
    problems = list(res.issues) + facsrc.bracket_issues(res.tokens)
    if problems:
        p = sorted(problems, key=lambda x: (x.line, x.col))[0]
        raise FormatError(f"{p.line}:{p.col + 1}: {p.message}")
    lines = text.split("\n")
    by_line: dict = {}
    inside_block = set()
    for t in res.tokens:
        by_line.setdefault(t.line, []).append(t)
        if t.kind == "comment" and t.end_line > t.line:
            inside_block.update(range(t.line + 1, t.end_line + 1))
    stack: List[facsrc.Tok] = []
    out: List[str] = []
    blank = 0
    pad = " " * indent
    for i, raw in enumerate(lines, start=1):
        if i in inside_block:
            out.append(raw)
            blank = 0
            continue
        s = raw.strip()
        if not s:
            blank += 1
            if out and blank <= max_blank:
                out.append("")
            continue
        blank = 0
        toks = by_line.get(i, [])
        tmp = list(stack)
        for t in toks:
            if t.kind == "op" and t.text in "}])" and tmp:
                tmp.pop()
            else:
                break
        braces = sum(1 for t in tmp if t.text == "{")
        extra = 1 if tmp and tmp[-1].text in "([" and tmp[-1].line < i else 0
        line = pad * (braces + extra) + raw.strip(" \t\r")
        # trailing blanks are part of a trailing # comment; only code lines are right-stripped
        out.append(line if (toks and toks[-1].kind == "comment") else line.rstrip())
        for t in toks:
            if t.kind == "op":
                if t.text in "({[":
                    stack.append(t)
                elif t.text in "})]" and stack:
                    stack.pop()
    while out and out[-1] == "":
        out.pop()
    result = "\n".join(out) + ("\n" if out else "")
    # safety net: the token stream must be identical
    check = facsrc.lex(result)
    a = [_tok_key(t) for t in res.tokens]
    b = [_tok_key(t) for t in check.tokens]
    if a != b:
        raise FormatError("internal error: token stream changed; file left unformatted")
    if crlf:
        result = result.replace("\n", "\r\n")
    return ("\ufeff" if bom else "") + result


def load_config(start: pathlib.Path) -> dict:
    cfg = {}
    d = start if start.is_dir() else start.parent
    for p in [d] + list(d.resolve().parents):
        f = p / "fac.toml"
        if f.exists() and tomllib:
            try:
                cfg = tomllib.loads(f.read_text(encoding="utf-8")).get("fmt", {})
            except Exception:
                cfg = {}
            break
    return cfg


def collect(paths: List[str]) -> List[pathlib.Path]:
    files: List[pathlib.Path] = []
    for p in paths:
        pp = pathlib.Path(p)
        if pp.is_dir():
            files += sorted(x for x in pp.rglob("*.fac") if "build" not in x.parts and ".fac" not in x.parts[:-1])
        else:
            files.append(pp)
    return files


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("paths", nargs="*")
    ap.add_argument("--check", action="store_true", help="do not write; exit 1 if a file would change")
    ap.add_argument("--diff", action="store_true", help="print a unified diff instead of writing")
    ap.add_argument("--stdin", action="store_true", help="read source from stdin, write result to stdout")
    ap.add_argument("--indent", type=int)
    ap.add_argument("--max-blank", type=int)
    ap.add_argument("--eol", choices=("auto", "lf", "crlf"), default="auto")
    a = ap.parse_args(argv)
    cfg = load_config(pathlib.Path(a.paths[0]) if a.paths else pathlib.Path("."))
    indent = a.indent or int(cfg.get("indent", 4))
    max_blank = a.max_blank if a.max_blank is not None else int(cfg.get("max_blank_lines", 1))
    if a.stdin:
        try:
            sys.stdout.write(format_text(sys.stdin.read(), indent, max_blank, a.eol))
            return 0
        except FormatError as e:
            print(f"<stdin>:{e}", file=sys.stderr)
            return 2
    if not a.paths:
        ap.error("no files given")
    changed = errors = 0
    for p in collect(a.paths):
        try:
            old = p.read_bytes().decode("utf-8")
            new = format_text(old, indent, max_blank, a.eol)
        except FormatError as e:
            print(f"{p}:{e}", file=sys.stderr)
            errors += 1
            continue
        except (OSError, UnicodeDecodeError) as e:
            print(f"{p}: {e}", file=sys.stderr)
            errors += 1
            continue
        if old == new:
            continue
        changed += 1
        if a.diff:
            sys.stdout.writelines(difflib.unified_diff(old.splitlines(True), new.splitlines(True), f"a/{p}", f"b/{p}"))
        elif a.check:
            print(f"{p}: formatting differs")
        else:
            p.write_bytes(new.encode("utf-8"))
            print(f"formatted {p}")
    if errors:
        return 2
    return 1 if (a.check and changed) else 0


if __name__ == "__main__":
    raise SystemExit(main())
