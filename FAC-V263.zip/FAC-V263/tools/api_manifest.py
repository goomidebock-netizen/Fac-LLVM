#!/usr/bin/env python3
"""Generate the machine-readable FAC API manifest (api/manifest.json).

Sources of truth, in order of authority:
  1. src/codegen.hpp  BTAB[]        built-in function table (name, return/param codes, runtime symbol)
  2. src/gen_vec.inc  mat4 table    mat4.* helpers
  3. runtime/*.inc|cpp              direct ``do_throw(msg, code)`` sites of each runtime symbol
  4. stdlib/*.fac                   public declarations of source-level libraries (+ ## contract tags)
  5. api/meta.json                  curated decisions (aliases, release pairs, thread-safety policy)

Everything extracted is *mechanical*; judgement lives in api/meta.json.  The manifest never claims
more than the sources prove: an error model of ``none-direct`` means "no direct throw site was
found in the runtime function", not "cannot fail".

usage: api_manifest.py [--output api/manifest.json] [--check]
  --check   regenerate in memory and fail if api/manifest.json is stale (CI)
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import facsrc  # noqa: E402

PARAM_T = {"S": "string", "L": "list<string>", "Y": "list<int>", "M": "mutex", "g": "function(int)", "f": "function()",
           "i": "int", "l": "long", "d": "double", "c": "unichar", "p": "handle"}
RET_T = {"v": "void", "i": "int", "l": "long", "n": "int|long", "u": "ulong", "U": "uint", "c": "unichar",
         "d": "double", "b": "boolean", "S": "string", "L": "list<string>", "B": "list<int>", "p": "handle"}
MAT_T = {"f": "float", "v": "vec3", "m": "mat4"}
LIBM = {"asin", "acos", "atan", "sinh", "cosh", "tanh", "exp", "cbrt", "trunc", "atan2", "hypot", "fmod",
        "sqrt", "floor", "ceil", "round", "sin", "cos", "tan", "log", "log2", "log10", "pow"}
TAGS = ("returns", "ownership", "errors", "thread-safety")

ERROR_CODE_NAMES = {
    2: "IndexOutOfRange", 3: "DivisionByZero", 4: "AssertionFailed", 5: "OutOfMemory", 6: "NullPointer",
    7: "Io", 8: "Resource", 9: "Regex", 10: "Json", 11: "Network", 12: "TimeParse", 13: "Encoding", 14: "Media",
    15: "Process", 16: "Concurrency", 17: "IntegerOverflow", 18: "Math", 19: "Database",
}


def read(path: pathlib.Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def parse_btab() -> list:
    src = read(ROOT / "src" / "codegen.hpp")
    start = src.index("static const BI BTAB[] = {")
    end = src.index("\n};", start)
    return re.findall(r'\{"([^"]+)",\s*\'(.)\',\s*"([^"]*)",\s*"([^"]+)"\}', src[start:end])


def parse_mat4() -> list:
    src = read(ROOT / "src" / "gen_vec.inc")
    m = re.search(r"MF\[\] = \{(.*?)\{nullptr", src, re.S)
    return re.findall(r'\{"(\w+)",\s*"(\w*)",\s*"(\w+)"\}', m.group(1)) if m else []


# Runtime plumbing (temporary/cleanup stacks, object release, try-frames, the throw helper itself) can raise
# resource errors for *any* API; following them would attribute those to every function, so they are not followed.
INFRA_PREFIXES = ("fac_tmp_", "fac_cleanup_", "fac_obj_", "fac_try_", "fac_throw", "fac_list_", "fac_str_free")
INFRA_NAMES = {"do_throw", "mks", "mk", "sd", "sl"}


def runtime_throws() -> dict:
    """runtime function name -> sorted error codes it can throw (direct + through helpers).

    A C++ function body is located with a light-weight brace matcher.  ``do_throw(msg, code)``
    sites give direct codes; calls to other runtime functions are followed (transitively) so that a
    wrapper such as fac_net_httpget reports the codes of the helper that actually throws."""
    text = ""
    for f in sorted((ROOT / "runtime").glob("*")):
        if f.suffix in (".cpp", ".inc"):
            text += read(f) + "\n"
    direct: dict = {}
    callees: dict = {}
    heads = list(re.finditer(r"(?:^|\n)[^\n;{}#]*?\b([A-Za-z_][A-Za-z0-9_]*)\s*\([^;{)]*\)\s*(?:const\s*)?\{", text))
    for m in heads:
        name = m.group(1)
        if name in direct or name in ("if", "for", "while", "switch", "catch", "sizeof"):
            continue
        i = m.end() - 1
        depth, j = 0, i
        while j < len(text):
            ch = text[j]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        body = text[i:j + 1]
        direct[name] = {int(c) for c in re.findall(r"do_throw\([^;]*?,\s*(\d+)\s*\)\s*;", body)}
        callees[name] = set(re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", body))
    memo: dict = {}

    def closure(n: str, seen: tuple = ()) -> set:
        if n in memo:
            return memo[n]
        if n in seen or n not in direct:
            return set()
        acc = set(direct[n])
        for c in callees[n]:
            if c != n and c in direct and not c.startswith(INFRA_PREFIXES) and c not in INFRA_NAMES:
                acc |= closure(c, seen + (n,))
        memo[n] = acc
        return acc

    return {n: sorted(closure(n)) for n in direct}


def err_model(name: str, ret: str, codes: list, meta: dict, symbol: str) -> dict:
    leaf = name.split(".")[-1]
    if symbol in meta.get("dynamic_error_symbols", []):
        return {"model": "throws", "codes": [],
                "evidence": "Runtime rethrows the original FAC callback error after completing object/cycle cleanup; code is dynamic"}
    specific = [c for c in codes if c != 5]
    if specific:
        e = {"model": "throws", "codes": specific, "evidence": "static scan of runtime do_throw sites (direct or via helper functions; runtime plumbing excluded); an over-approximation"}
        if 5 in codes:
            e["also"] = "OutOfMemory"
        return e
    if symbol in LIBM:
        return {"model": "ieee754", "evidence": "libm; NaN/inf on domain errors"}
    if ret == "b":
        pred = leaf in meta["predicate_names"] or re.match(r"^(is|has|can|supports)[A-Z]", leaf)
        return {"model": "predicate" if pred else "status-flag",
                "evidence": "boolean return; false means no/failed (no detail)"}
    return {"model": "none-direct", "evidence": "no direct throw site in the runtime function; failures, if any, are reported through the return value"}


def ownership(name: str, ret: str, params: str, meta: dict) -> dict:
    o: dict = {"params": [], "result": None}
    for k, p in enumerate(params):
        mode = "by-value"
        if p in "SLY":
            mode = "borrowed"
        elif p == "p":
            mode = "borrowed-handle"
        elif p in "fg":
            mode = "borrowed-callable"
        elif p == "M":
            mode = "borrowed-handle"
        o["params"].append(mode)
    if name in meta["consumes_first_arg"] and o["params"]:
        o["params"][0] = "consumed"
        o["consumes"] = meta["consumes_first_arg"][name]
    if name in meta["transfers_ownership_of_arg"]:
        t = meta["transfers_ownership_of_arg"][name]
        o["params"][t["arg"]] = "consumed"
        o["transfers"] = t["note"]
    if ret in "SLB":
        o["result"] = "owned"
    elif ret == "p":
        if name in meta["borrowed_results"]:
            o["result"] = "borrowed-view"
            o["result_note"] = meta["borrowed_results"][name]
        else:
            o["result"] = "owned-handle"
            if name in meta["release_pairs"]:
                o["release"] = meta["release_pairs"][name]
    else:
        o["result"] = "by-value"
    return o


def build_builtins(meta: dict) -> list:
    throws = runtime_throws()
    alias_by_name = {a["name"]: a for a in meta["aliases"]}
    entries: dict = {}
    for q, r, p, s in parse_btab():
        key = q
        e = entries.get(key)
        sig = {"params": [PARAM_T[c] for c in p], "returns": RET_T[r], "symbol": s,
               "_p": p, "_r": r}
        if e is None:
            mod = q.split(".")[0]
            entries[key] = {"name": q, "module": mod, "kind": "builtin", "overloads": [sig]}
        else:
            e["overloads"].append(sig)
    for fn, args, sym in parse_mat4():
        q = "mat4." + fn
        entries[q] = {"name": q, "module": "mat4", "kind": "builtin", "overloads": [
            {"params": [MAT_T[c] for c in args], "returns": "mat4", "symbol": sym, "_p": "", "_r": "m"}]}
    for x in meta["extra"]:
        q = x["name"]
        if q in entries:
            continue
        entries[q] = {"name": q, "module": q.split(".")[0], "kind": "constant" if x.get("constant") else "builtin-special",
                      "overloads": [{"params_text": x["params"], "returns": x["returns"], "symbol": None, "_p": None, "_r": None}],
                      "note": x.get("note", ""), "ownership_text": x.get("ownership", "")}
    out = []
    for q in sorted(entries):
        e = entries[q]
        mod = e["module"]
        first = e["overloads"][0]
        syms = [o["symbol"] for o in e["overloads"] if o["symbol"]]
        e["errors"] = (err_model(q, first["_r"] or "", sorted({c for s in syms for c in throws.get(s, [])}), meta, syms[0] if syms else "")
                       if first["_p"] is not None else {"model": "see-note", "evidence": "special-cased by the compiler"})
        if first["_p"] is not None:
            e["ownership"] = ownership(q, first["_r"], first["_p"], meta)
        e["thread_safety"] = meta["modules"].get(mod, {}).get("thread_safety", "unspecified")
        api_note = meta.get("api_notes", {}).get(q)
        if api_note:
            e["note"] = api_note
        if q.startswith("thread.atomic"):
            e["thread_safety"] = "safe-atomic"
        a = alias_by_name.get(q)
        if a:
            e["alias_of"] = a["canonical"]
            e["status"] = a["status"]
            e["alias_kind"] = a["kind"]
            if "deprecated_in" in a:
                e["deprecated_in"] = a["deprecated_in"]
                e["remove_not_before"] = a["remove_not_before"]
        else:
            e["status"] = "stable"
        e["module_status"] = meta["modules"].get(mod, {}).get("status", "stable")
        for o in e["overloads"]:
            o.pop("_p", None)
            o.pop("_r", None)
        out.append(e)
    # canonical -> aliases
    aliases: dict = {}
    for a in meta["aliases"]:
        aliases.setdefault(a["canonical"], []).append(a["name"])
    for e in out:
        if e["name"] in aliases:
            e["aliases"] = sorted(aliases[e["name"]])
    return out


def parse_contract(doc: list) -> dict:
    tags: dict = {}
    cur = None
    for line in doc:
        m = re.match(r"@([a-z-]+)\s*(.*)", line)
        if m:
            cur = m.group(1)
            tags[cur] = m.group(2).strip()
        elif cur and line:
            tags[cur] += " " + line.strip()
        elif not line:
            cur = None
    return tags


def description_above(lines: list, decl_line: int) -> str:
    """Human description: contiguous ``#`` comment lines above a declaration (skipping its ## contract block)."""
    j = decl_line - 2
    while j >= 0 and lines[j].lstrip().startswith("##"):
        j -= 1
    out = []
    while j >= 0 and lines[j].lstrip().startswith("#") and not lines[j].lstrip().startswith(("##", "#*")):
        out.append(lines[j].lstrip()[1:].strip())
        j -= 1
    return " ".join(reversed(out)).strip()


def build_source_modules() -> list:
    out = []
    for p in sorted((ROOT / "stdlib").glob("*.fac")):
        text = read(p)
        lines = text.split("\n")
        decls = facsrc.scan_declarations(text)
        mod = p.stem
        for d in decls:
            if d.kind not in ("function", "class", "struct", "enum", "interface") or not d.public:
                continue
            e = {"name": f"{mod}.{d.parent + '.' if d.parent else ''}{d.name}", "module": mod, "kind": "source-" + d.kind,
                 "file": f"stdlib/{p.name}", "line": d.line, "signature": d.signature, "status": "stable"}
            desc = description_above(lines, d.line)
            if desc:
                e["description"] = desc
            if d.kind == "function":
                e["returns"] = d.ret
                e["params"] = d.params
                e["throws_in_body"] = d.body_has_throw
                e["contract"] = parse_contract(d.doc)
            elif d.doc:
                e["doc"] = " ".join(d.doc)
            out.append(e)
    return out


def build() -> dict:
    meta = json.loads(read(ROOT / "api" / "meta.json"))
    ver = read(ROOT / "VERSION.toml")
    label = re.search(r'label\s*=\s*"([^"]+)"', ver).group(1)
    compiler = re.search(r'compiler\s*=\s*"([^"]+)"', ver).group(1)
    builtins = build_builtins(meta)
    source = build_source_modules()
    return {
        "manifest_version": 1, "release": label, "compiler": compiler,
        "error_codes": {str(k): v for k, v in sorted(ERROR_CODE_NAMES.items())},
        "modules": meta["modules"],
        "builtin": builtins,
        "source": source,
        "counts": {"builtin": len(builtins), "source": len(source)},
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--output", default=str(ROOT / "api" / "manifest.json"))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args(argv)
    text = json.dumps(build(), indent=1, ensure_ascii=False, sort_keys=False) + "\n"
    out = pathlib.Path(a.output)
    if a.check:
        if not out.exists() or out.read_text(encoding="utf-8") != text:
            print(f"{out}: stale; run: python3 tools/api_manifest.py", file=sys.stderr)
            return 1
        print(f"{out}: up to date")
        return 0
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    d = json.loads(text)
    print(f"wrote {out} ({d['counts']['builtin']} built-in entries, {d['counts']['source']} source declarations)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
