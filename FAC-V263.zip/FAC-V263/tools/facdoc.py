#!/usr/bin/env python3
"""FAC documentation generator (V44).

Builds Markdown API reference pages from the API manifest:
  docs/api/index.md        module overview
  docs/api/<module>.md     one page per built-in or source-level module
  docs/ERROR_CODES.md      runtime Error codes and the APIs that can raise them

Built-in pages are derived from the compiler tables + runtime analysis (signature types, ownership,
error model, aliases); source-library pages additionally carry the ``##`` contract tags and the
descriptions written next to each declaration.  Output is deterministic so ``--check`` can be used
in CI to detect stale docs.

usage: facdoc.py [--output docs] [--check]
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
from collections import defaultdict

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import api_manifest  # noqa: E402

MODEL_TEXT = {
    "throws": "throws `Error`", "predicate": "predicate (never throws on a normal miss)",
    "status-flag": "boolean status flag (`false` = failed, no detail)", "ieee754": "IEEE-754 (NaN/inf)",
    "none-direct": "no direct throw site", "see-note": "see note",
}
TS_TEXT = {
    "safe-pure": "safe (pure)", "safe-atomic": "safe (atomic)", "safe-per-thread": "safe (per-thread state)",
    "externally-synchronized": "externally synchronized",
    "safe-handle": "serialized per opaque handle (do not race managed close/destruction)",
    "thread-confined": "thread-confined (each mutable handle belongs to its creating thread)",
    "unspecified": "unspecified",
}


def sig(e: dict, o: dict) -> str:
    if "params_text" in o:
        ps = o["params_text"]
    else:
        ps = ", ".join(o["params"])
    if e["kind"] == "constant":
        return f"`{e['name']}`: {o['returns']}"
    return f"`{e['name']}({ps})` → {o['returns']}"


def own_text(e: dict) -> str:
    o = e.get("ownership")
    if not o:
        return e.get("ownership_text", "")
    bits = []
    ps = [f"#{i + 1} {m}" for i, m in enumerate(o["params"]) if m not in ("by-value",)]
    if ps:
        bits.append("args: " + ", ".join(ps))
    res = o["result"]
    if res in ("owned", "owned-handle"):
        bits.append("result: owned by caller" + (f" (release with `{o['release']}`)" if "release" in o else ""))
    elif res == "borrowed-view":
        bits.append("result: borrowed view — " + o["result_note"])
    if "consumes" in o:
        bits.append("consumes arg 1: " + o["consumes"])
    if "transfers" in o:
        bits.append(o["transfers"])
    return "; ".join(bits)


def err_text(e: dict, codes: dict) -> str:
    er = e["errors"]
    t = MODEL_TEXT.get(er["model"], er["model"])
    if er["model"] == "throws":
        names = ", ".join(f"{c} {codes.get(str(c), '?')}" for c in er["codes"])
        t += f" (code {names})"
        if er.get("also"):
            t += " + OOM"
    return t


def builtin_page(mod: str, entries: list, manifest: dict) -> str:
    m = manifest["modules"].get(mod, {})
    out = [f"# `{mod}`", "", m.get("summary", ""), "",
           f"- Status: **{entries[0].get('module_status', 'stable')}**",
           f"- Thread-safety: **{TS_TEXT.get(m.get('thread_safety', 'unspecified'), m.get('thread_safety', ''))}**"
           + (" (policy; see [API conventions](../API_CONVENTIONS.md))" if m.get("thread_safety") == "externally-synchronized" else ""),
           f"- Entries: {len(entries)} · generated from the compiler tables (release {manifest['release']})", "",
           "| API | Errors | Ownership / notes |", "|---|---|---|"]
    for e in entries:
        for o in e["overloads"]:
            notes = own_text(e)
            if e.get("note"):
                notes = (notes + "; " if notes else "") + e["note"]
            if e.get("alias_of"):
                tag = "deprecated" if e["status"] == "deprecated" else "alias"
                notes = f"**{tag}** of `{e['alias_of']}`" + (f" (remove ≥ {e['remove_not_before']})" if "remove_not_before" in e else "") + ("; " + notes if notes else "")
            elif e.get("aliases"):
                notes = (notes + "; " if notes else "") + "also: " + ", ".join(f"`{a}`" for a in e["aliases"])
            out.append(f"| {sig(e, o)} | {err_text(e, manifest['error_codes'])} | {notes} |")
    out += ["", "_Parameter names are not part of the built-in contract; positional types are shown._", ""]
    return "\n".join(out)


def source_page(mod: str, entries: list, manifest: dict) -> str:
    out = [f"# `{mod}` (source library)", "", f"Source: `stdlib/{mod}.fac` · `import {mod}.fac` · release {manifest['release']}", ""]
    for e in entries:
        title = e["name"][len(mod) + 1:]
        out.append(f"### `{title}`" if e["kind"] != "source-function" else f"### `{title}`")
        out.append("")
        out.append("```fac")
        out.append(e["signature"].rstrip(" {"))
        out.append("```")
        if e.get("description"):
            out += ["", e["description"]]
        c = e.get("contract") or {}
        if c.get("returns"):
            out += ["", f"- **Returns:** {c['returns']}", f"- **Ownership:** {c['ownership']}",
                    f"- **Errors:** {c['errors']}", f"- **Thread-safety:** {c['thread-safety']}"]
            if "generated" in c:
                out.append("- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._")
        out.append("")
    return "\n".join(out)


def error_codes_page(manifest: dict) -> str:
    by_code = defaultdict(list)
    for e in manifest["builtin"]:
        for c in e["errors"].get("codes", []):
            by_code[c].append(e["name"])
    out = ["# FAC runtime error codes", "",
           "`Error` is a built-in struct `{ dyn string msg ; var int code }`. The runtime throws it with the codes below; "
           "the lists are produced by `tools/api_manifest.py` from the `do_throw(..., code)` call sites (direct and through helpers). "
           "Out-of-memory (5) can be raised by any allocating API and is not repeated per function.", "",
           "| Code | Name | Raised by (built-ins) |", "|---|---|---|"]
    for k, name in manifest["error_codes"].items():
        apis = by_code.get(int(k), [])
        shown = ", ".join(f"`{a}`" for a in apis[:12]) + (f" … (+{len(apis) - 12})" if len(apis) > 12 else "")
        out.append(f"| {k} | {name} | {shown or '(language/runtime: see below)'} |")
    out += ["", "## Known inconsistencies", "",
            "- **Code 7** is used for file I/O failures *and* for object-model errors (null object method call, failed downcast, object size overflow). "
            "Prefer matching on `msg` prefix or use the `fs.fac` wrappers, which classify the failure.",
            "- Codes **8** (resource/limits) and **14** (media) group several unrelated sources.",
            "- Compatibility rule: codes are never renumbered; new failure kinds get new numbers (see `docs/COMPATIBILITY.md`).", ""]
    return "\n".join(out)


def build(manifest: dict) -> dict:
    files = {}
    by_mod = defaultdict(list)
    for e in manifest["builtin"]:
        by_mod[e["module"]].append(e)
    src_mod = defaultdict(list)
    for e in manifest["source"]:
        src_mod[e["module"]].append(e)
    index = [f"# FAC API reference ({manifest['release']})", "",
             "Generated by `python3 tools/facdoc.py`. Policy: [`../API_CONVENTIONS.md`](../API_CONVENTIONS.md) · "
             "compatibility: [`../COMPATIBILITY.md`](../COMPATIBILITY.md) · errors: [`../ERROR_CODES.md`](../ERROR_CODES.md) · "
             "audit: [`../API_AUDIT.md`](../API_AUDIT.md).", "",
             "## Built-in modules", "", "| Module | Status | Entries | Summary |", "|---|---|---|---|"]
    for mod in sorted(by_mod):
        files[f"api/{mod}.md"] = builtin_page(mod, sorted(by_mod[mod], key=lambda x: x["name"]), manifest)
        m = manifest["modules"].get(mod, {})
        index.append(f"| [`{mod}`]({mod}.md) | {m.get('status', 'stable')} | {len(by_mod[mod])} | {m.get('summary', '')} |")
    index += ["", "## Source-level libraries (`import X.fac`)", "", "| Module | Public declarations |", "|---|---|"]
    for mod in sorted(src_mod):
        files[f"api/{mod}.md"] = source_page(mod, src_mod[mod], manifest) if mod not in by_mod else files[f"api/{mod}.md"]
        index.append(f"| [`{mod}`]({mod}.md) | {len(src_mod[mod])} |")
    files["api/index.md"] = "\n".join(index) + "\n"
    files["ERROR_CODES.md"] = error_codes_page(manifest)
    return {k: (v if v.endswith("\n") else v + "\n") for k, v in files.items()}


def project_markdown(root: pathlib.Path) -> str:
    """API page for a user project: public declarations of src/*.fac with their ## contract/doc comments."""
    import facsrc
    out = [f"# {root.name} API", "", "Generated by `fac doc` from the `##` comments above each public declaration.", ""]
    for f in sorted((root / "src").glob("*.fac")):
        text = f.read_text(encoding="utf-8", errors="replace")
        lines = text.split("\n")
        decls = [d for d in facsrc.scan_declarations(text) if d.public and d.kind in ("function", "class", "struct", "enum", "interface")]
        if not decls:
            continue
        out += [f"## `{f.stem}`", ""]
        for d in decls:
            title = (d.parent + "." if d.parent else "") + d.name
            out += [f"### `{title}`", "", "```fac", d.signature.rstrip(" {"), "```", ""]
            desc = api_manifest.description_above(lines, d.line)
            if desc:
                out += [desc, ""]
            tags = api_manifest.parse_contract(d.doc)
            for k in ("returns", "ownership", "errors", "thread-safety"):
                if tags.get(k):
                    out.append(f"- **{k}:** {tags[k]}")
            free = [x for x in d.doc if not x.startswith("@") and x]
            if free:
                out += ["", " ".join(free)]
            out.append("")
    return "\n".join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--output", default=str(ROOT / "docs"))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args(argv)
    files = build(api_manifest.build())
    out = pathlib.Path(a.output)
    stale = []
    for rel, text in files.items():
        p = out / rel
        if a.check:
            if not p.exists() or p.read_text(encoding="utf-8") != text:
                stale.append(rel)
        else:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text, encoding="utf-8")
    if a.check:
        if stale:
            print("stale docs: " + ", ".join(stale[:8]) + (" ..." if len(stale) > 8 else "") + "\nrun: python3 tools/facdoc.py", file=sys.stderr)
            return 1
        print(f"docs up to date ({len(files)} files)")
        return 0
    print(f"wrote {len(files)} files under {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
