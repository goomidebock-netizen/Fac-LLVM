#!/usr/bin/env python3
"""Structural LLVM IR linter (no LLVM needed): terminators, labels, SSA defs/uses."""
import re, sys
TERM = ('br ', 'ret ', 'ret\n', 'unreachable', 'switch ')
def lint(path):
    errs = []
    txt = open(path, encoding='utf-8').read().split('\n')
    i = 0
    globals_ = set(re.findall(r'^(@[\w.$]+)\s*=', '\n'.join(txt), re.M)) | set(re.findall(r'^declare [^@]*(@[\w.$]+)\(', '\n'.join(txt), re.M)) | set(re.findall(r'^define [^@]*(@[\w.$]+)\(', '\n'.join(txt), re.M))
    while i < len(txt):
        ln = txt[i]
        if ln.startswith('define '):
            j = i
            while not txt[j].startswith('}'): j += 1
            fn = txt[i:j+1]; name = re.search(r'(@[\w.$]+)\(', ln).group(1)
            hdr = ln
            params = set(re.findall(r'%[\w.$]+', hdr[hdr.index('('):]))
            labels = set(['entry']); defs = set(params); uses = []
            blocks = []; cur = {'name': 'entry', 'term': False, 'line': i+1, 'n': 0}
            fn2 = []; buf = None
            for l in fn[1:-1]:
                if buf is not None:
                    buf += ' ' + l.strip()
                    if l.strip() == ']': fn2.append(buf); buf = None
                    continue
                if l.strip().startswith('switch ') and l.rstrip().endswith('['):
                    buf = l.rstrip(); continue
                fn2.append(l)
            fn = [fn[0]] + fn2 + [fn[-1]]
            for k, l in enumerate(fn[1:-1], start=i+1):
                m = re.match(r'^([\w.$]+):\s*$', l)
                if m:
                    if cur is not None and not cur['term'] and cur.get('n', 1) > 0: errs.append(f'{name}: block {cur["name"]} (line {cur["line"]}) lacks terminator')
                    cur = {'name': m.group(1), 'term': False, 'line': k+1, 'n': 0}; labels.add(m.group(1)); blocks.append(cur); continue
                s = l.strip()
                if not s: continue
                if cur is None: errs.append(f'{name}: instruction before first label line {k+1}'); cur = {'name': 'entry', 'term': False, 'line': k+1}
                cur['n'] = cur.get('n', 0) + 1
                if cur['term']: errs.append(f'{name}: code after terminator in {cur["name"]} line {k+1}: {s[:60]}')
                md = re.match(r'^(%[\w.$]+)\s*=\s*(.*)', s)
                if md:
                    if md.group(1) in defs: errs.append(f'{name}: {md.group(1)} defined twice (line {k+1})')
                    defs.add(md.group(1)); rhs = md.group(2)
                else: rhs = s
                for t in re.findall(r'label %([\w.$]+)', rhs): uses.append(('L:'+t, k+1))
                rhs_v = re.sub(r'label %[\w.$]+', 'label', rhs)
                rhs_v = re.sub(r', %([\w.$]+) \]', ' ]', rhs_v) if rhs.startswith('phi') else rhs_v
                for u in re.findall(r'%[\w.$]+', rhs_v): uses.append((u, k+1))
                if re.match(r'(br |ret\b|unreachable|switch )', rhs.split(', !')[0]) : cur['term'] = True
                if rhs.startswith('phi'):
                    for t in re.findall(r', %([\w.$]+) \]', rhs): uses.append(('L:'+t, k+1))
            if cur is not None and not cur['term']: errs.append(f'{name}: last block {cur["name"]} lacks terminator')
            for u, ln_ in uses:
                if u.startswith('L:'):
                    if u[2:] not in labels: errs.append(f'{name}: missing label {u[2:]} (line {ln_})')
                elif u not in defs and not u.startswith('%S.') and not u.startswith('%Fac'):
                    errs.append(f'{name}: undefined {u} (line {ln_})')
            i = j
        i += 1
    return errs
if __name__ == '__main__':
    bad = 0
    for p in sys.argv[1:]:
        e = lint(p)
        if e: bad += 1; print('LINT FAIL', p); [print('   ', x) for x in e[:6]]
    print(f'linted {len(sys.argv)-1} files, {bad} with problems')
