#!/usr/bin/env python3
"""FAC package manager (V44) -- offline, local-path, reproducible.

A FAC *package* is a directory with ``fac.toml`` and flat ``src/*.fac`` modules.  FAC's import
resolver is flat (``import name.fac`` finds ``name.fac`` next to the entry file, then in the standard
library), so the manager works by **staging**: the modules of the project and of all its dependencies
are copied into one directory and the compiler is run there.  Nothing in the compiler or the language
changes.

fac.toml
    [package]      name, version (x.y.z), entry (default src/main.fac), kind ("bin" | "lib"), description, license
    [compat]       fac = ">=0.2.0,<0.3.0"      supported compiler versions (checked on build)
    [dependencies] util = "vendor/util"        or  util = { path = "vendor/util", version = "^1.2" }
    [build]        flags = ["-O2"], out = "build"
    [fmt]          indent = 4, max_blank_lines = 1

Rules (enforced): dependency directories must live inside the project root; dependency key must equal the
dependency's package name; versions must satisfy the requirement; no dependency cycles; no two packages may
provide the same module name; no module may shadow a standard-library module.  ``fac.lock`` records every
package with a content hash so ``lock --check`` detects drift.

usage: facpkg.py {init,add,remove,list,tree,verify,lock,pack} ...
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import zipfile
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

try:
    import tomllib
except ImportError:  # pragma: no cover
    raise SystemExit("FAC tooling needs Python 3.11+ (tomllib)")

HERE = pathlib.Path(__file__).resolve().parent
FAC_ROOT = HERE.parent
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")          # also the module name: must be a FAC identifier
VER_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")
SKIP_DIRS = {"build", ".git", "dist", ".fac"}


class PkgError(Exception):
    pass


# ---------------------------------------------------------------- versions
def parse_ver(s: str) -> Tuple[int, int, int]:
    m = VER_RE.match(s.strip())
    if not m:
        raise PkgError(f"invalid version {s!r}; use x.y.z")
    return int(m.group(1)), int(m.group(2)), int(m.group(3))


def _pad(s: str) -> str:
    parts = s.strip().split(".")
    return ".".join(parts + ["0"] * (3 - len(parts)))


def satisfies(version: str, requirement: str) -> bool:
    v = parse_ver(version)
    for comp in [c.strip() for c in requirement.split(",") if c.strip()]:
        m = re.match(r"^(>=|<=|>|<|=|\^|~)?\s*(\d+(?:\.\d+){0,2})$", comp)
        if not m:
            raise PkgError(f"invalid version requirement {comp!r}")
        op, rhs = m.group(1) or "=", parse_ver(_pad(m.group(2)))
        if op == ">=" and not v >= rhs:
            return False
        if op == ">" and not v > rhs:
            return False
        if op == "<=" and not v <= rhs:
            return False
        if op == "<" and not v < rhs:
            return False
        if op == "=" and v != rhs:
            return False
        if op == "^":
            upper = (rhs[0] + 1, 0, 0) if rhs[0] > 0 else ((0, rhs[1] + 1, 0) if rhs[1] > 0 else (0, 0, rhs[2] + 1))
            if not (v >= rhs and v < upper):
                return False
        if op == "~" and not (v >= rhs and v < (rhs[0], rhs[1] + 1, 0)):
            return False
    return True


def compiler_version(facc: Optional[str] = None) -> str:
    """Version of the compiler that will be used (``facc --version``), else the source tree's VERSION.toml."""
    for c in (facc, str(FAC_ROOT / "build" / "facc"), str(FAC_ROOT / "build" / "facc.exe")):
        if c and pathlib.Path(c).exists():
            try:
                out = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=10).stdout
                m = re.search(r"facc (\d+\.\d+\.\d+)", out)
                if m:
                    return m.group(1)
            except (OSError, subprocess.SubprocessError):
                pass
    try:
        return tomllib.loads((FAC_ROOT / "VERSION.toml").read_text(encoding="utf-8"))["release"]["compiler"]
    except (OSError, KeyError, tomllib.TOMLDecodeError):
        raise PkgError("cannot determine the compiler version (no build/facc and no VERSION.toml)")


# ---------------------------------------------------------------- manifest
@dataclass
class Package:
    name: str
    version: str
    root: pathlib.Path
    entry: str = "src/main.fac"
    kind: str = "bin"
    compat: str = ""
    deps: Dict[str, dict] = field(default_factory=dict)      # name -> {"path": str, "version": str}
    flags: List[str] = field(default_factory=list)
    out: str = "build"
    fmt: dict = field(default_factory=dict)
    raw: dict = field(default_factory=dict)

    @property
    def src_dir(self) -> pathlib.Path:
        return self.root / "src"


def load_package(root: pathlib.Path) -> Package:
    f = root / "fac.toml"
    if not f.exists():
        raise PkgError(f"{root}: no fac.toml")
    try:
        data = tomllib.loads(f.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        raise PkgError(f"{f}: invalid TOML: {e}")
    pk = data.get("package")
    if not isinstance(pk, dict) or "name" not in pk:
        raise PkgError(f"{f}: [package] with a name is required")
    name = str(pk["name"])
    if not NAME_RE.match(name):
        raise PkgError(f"{f}: package name {name!r} must be a FAC identifier (letters, digits, _; it is also the module name)")
    version = str(pk.get("version", "0.1.0"))
    parse_ver(version)
    kind = pk.get("kind", "bin")
    if kind not in ("bin", "lib"):
        raise PkgError(f"{f}: kind must be \"bin\" or \"lib\"")
    deps = {}
    for dn, spec in (data.get("dependencies") or {}).items():
        if isinstance(spec, str):
            spec = {"path": spec}
        if not isinstance(spec, dict) or "path" not in spec:
            raise PkgError(f"{f}: dependency {dn!r} needs a path")
        if not NAME_RE.match(dn):
            raise PkgError(f"{f}: dependency name {dn!r} is not a valid identifier")
        deps[dn] = {"path": str(spec["path"]), "version": str(spec.get("version", ""))}
    b = data.get("build") or {}
    return Package(name, version, root, entry=str(pk.get("entry", "src/main.fac")), kind=kind,
                   compat=str((data.get("compat") or {}).get("fac", "")), deps=deps,
                   flags=[str(x) for x in b.get("flags", [])], out=str(b.get("out", "build")),
                   fmt=data.get("fmt") or {}, raw=data)


KNOWN = {"package", "compat", "dependencies", "build", "fmt"}


def q(v) -> str:
    return json.dumps(str(v), ensure_ascii=False)


def save_manifest(p: Package) -> None:
    extra = set(p.raw) - KNOWN
    if extra:
        raise PkgError(f"fac.toml has sections facpkg cannot rewrite ({', '.join(sorted(extra))}); edit it by hand")
    pk = p.raw.get("package", {})
    lines = ["[package]", f"name = {q(p.name)}", f"version = {q(p.version)}"]
    lines.append(f"entry = {q(p.entry)}")
    if p.kind != "bin":
        lines.append(f"kind = {q(p.kind)}")
    for k in ("description", "license"):
        if k in pk:
            lines.append(f"{k} = {q(pk[k])}")
    if p.compat:
        lines += ["", "[compat]", f"fac = {q(p.compat)}"]
    lines += ["", "[dependencies]"]
    for n, spec in sorted(p.deps.items()):
        lines.append(f"{n} = {q(spec['path'])}" if not spec.get("version")
                     else f"{n} = {{ path = {q(spec['path'])}, version = {q(spec['version'])} }}")
    if p.flags or p.out != "build":
        lines += ["", "[build]"]
        if p.flags:
            lines.append("flags = [" + ", ".join(q(x) for x in p.flags) + "]")
        if p.out != "build":
            lines.append(f"out = {q(p.out)}")
    if p.fmt:
        lines += ["", "[fmt]"] + [f"{k} = {v}" for k, v in sorted(p.fmt.items())]
    (p.root / "fac.toml").write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- hashing / resolution
def tree_hash(root: pathlib.Path) -> str:
    h = hashlib.sha256()
    files = [f for f in sorted(root.rglob("*")) if f.is_file()
             and not (set(f.relative_to(root).parts[:-1]) & SKIP_DIRS) and f.name != "fac.lock"
             and (f.suffix == ".fac" or f.name == "fac.toml")]
    for f in files:
        h.update(f.relative_to(root).as_posix().encode() + b"\0" + hashlib.sha256(f.read_bytes()).digest())
    return h.hexdigest()


@dataclass
class Resolution:
    root: Package
    order: List[Package]          # dependencies first, root last


def resolve(root_dir: pathlib.Path) -> Resolution:
    top = root_dir.resolve()
    root = load_package(top)
    seen: Dict[pathlib.Path, Package] = {}
    order: List[Package] = []

    def visit(pkg: Package, chain: Tuple[str, ...]):
        if pkg.root in seen:
            return
        for dn, spec in sorted(pkg.deps.items()):
            d = (pkg.root / spec["path"]).resolve()
            try:
                d.relative_to(top)
            except ValueError:
                raise PkgError(f"{pkg.name}: dependency path escapes the project root: {spec['path']}")
            if d == top or not d.is_dir():
                raise PkgError(f"{pkg.name}: dependency {dn!r} must be an existing directory inside the project: {spec['path']}")
            dep = load_package(d)
            if dep.name != dn:
                raise PkgError(f"{pkg.name}: dependency key {dn!r} does not match the package name {dep.name!r} in {spec['path']}/fac.toml")
            if dep.name in chain or dep.name == root.name:
                raise PkgError("dependency cycle: " + " -> ".join(chain + (pkg.name, dn)))
            if spec.get("version") and not satisfies(dep.version, spec["version"]):
                raise PkgError(f"{pkg.name}: {dn} {dep.version} does not satisfy {spec['version']}")
            visit(dep, chain + (pkg.name,))
        seen[pkg.root] = pkg
        order.append(pkg)

    visit(root, ())
    names = [p.name for p in order]
    dup = {n for n in names if names.count(n) > 1}
    if dup:
        raise PkgError(f"package name used by two different directories: {', '.join(sorted(dup))}")
    return Resolution(root, order)


def check_compat(res: Resolution, facc: Optional[str] = None) -> List[str]:
    ver = compiler_version(facc)
    problems = []
    for p in res.order:
        if p.compat and not satisfies(ver, p.compat):
            problems.append(f"{p.name} {p.version} requires fac {p.compat}, compiler is {ver}")
    return problems


def modules_of(pkg: Package, is_root: bool) -> Dict[str, pathlib.Path]:
    out: Dict[str, pathlib.Path] = {}
    if not pkg.src_dir.is_dir():
        return out
    entry_name = pathlib.Path(pkg.entry).name
    for f in sorted(pkg.src_dir.glob("*.fac")):
        if not is_root and pkg.kind == "bin" and f.name == entry_name:
            continue
        out[f.stem] = f
    return out


def stage(res: Resolution, stage_dir: pathlib.Path, stdlib_dir: Optional[pathlib.Path] = None, entry_override: Optional[pathlib.Path] = None) -> pathlib.Path:
    """Copy every module into ``stage_dir``; returns the staged entry file."""
    stdlib_dir = stdlib_dir or FAC_ROOT / "stdlib"
    std = {f.stem for f in stdlib_dir.glob("*.fac")} if stdlib_dir.is_dir() else set()
    owner: Dict[str, str] = {}
    plan: Dict[str, pathlib.Path] = {}
    for pkg in res.order:
        for mod, f in modules_of(pkg, pkg is res.root).items():
            if mod in std and not (pkg is res.root and f.name == pathlib.Path(res.root.entry).name):
                raise PkgError(f"{pkg.name}: module {mod!r} shadows the standard-library module of the same name; rename {f.name}")
            if mod in owner:
                raise PkgError(f"module {mod!r} is provided by both {owner[mod]} and {pkg.name}")
            owner[mod] = pkg.name
            plan[mod] = f
    if stage_dir.exists():
        for f in stage_dir.glob("*.fac"):
            f.unlink()
    stage_dir.mkdir(parents=True, exist_ok=True)
    for mod, f in plan.items():
        (stage_dir / f"{mod}.fac").write_bytes(f.read_bytes())
    entry = entry_override or (res.root.root / res.root.entry)
    if not entry.exists():
        raise PkgError(f"entry file not found: {entry}")
    if entry_override is not None:
        (stage_dir / entry.name).write_bytes(entry.read_bytes())
    return stage_dir / entry.name


def lock_data(res: Resolution) -> dict:
    return {"version": 1, "packages": [{"name": p.name, "version": p.version,
                                        "path": "." if p is res.root else p.root.relative_to(res.root.root).as_posix(),
                                        "hash": tree_hash(p.root)} for p in res.order]}


def lock_path(res: Resolution) -> pathlib.Path:
    return res.root.root / "fac.lock"


def write_lock(res: Resolution) -> None:
    lock_path(res).write_text(json.dumps(lock_data(res), indent=1) + "\n", encoding="utf-8")


def check_lock(res: Resolution) -> List[str]:
    p = lock_path(res)
    if not p.exists():
        return ["fac.lock is missing (run: facpkg lock)"]
    try:
        old = {x["name"]: x for x in json.loads(p.read_text(encoding="utf-8"))["packages"]}
    except (ValueError, KeyError):
        return ["fac.lock is unreadable (run: facpkg lock)"]
    new = {x["name"]: x for x in lock_data(res)["packages"]}
    out = []
    for n in sorted(set(old) | set(new)):
        if n not in old:
            out.append(f"{n}: not in fac.lock")
        elif n not in new:
            out.append(f"{n}: in fac.lock but no longer a dependency")
        elif old[n]["hash"] != new[n]["hash"] or old[n]["version"] != new[n]["version"]:
            out.append(f"{n}: contents changed since fac.lock was written")
    return out


# ---------------------------------------------------------------- commands
def cmd_init(a) -> int:
    root = pathlib.Path(a.dir).resolve()
    if (root / "fac.toml").exists():
        raise PkgError("fac.toml already exists")
    name = a.name or re.sub(r"[^A-Za-z0-9_]", "_", root.name)
    if not NAME_RE.match(name):
        name = "app_" + name
    root.mkdir(parents=True, exist_ok=True)
    pkg = Package(name, "0.1.0", root, kind="lib" if a.lib else "bin", raw={"package": {}}, compat=">=0.2.0,<0.3.0")
    if a.lib:
        pkg.entry = f"src/{name}.fac"
    (root / "src").mkdir(exist_ok=True)
    main = root / pkg.entry
    if not main.exists():
        if a.lib:
            main.write_text(f"module {name}\n\n## @returns The sum of a and b, by value.\n## @ownership a, b=by value.\n## @errors None: does not throw.\n"
                            f"## @thread-safety Safe: depends only on its arguments.\npublic function int add(int a, int b) {{\n    return a + b\n}}\n", encoding="utf-8")
        else:
            main.write_text(f'import terminal.fac\n\npublic function void main() {{\n    terminal.out.println("Hello from {name}")\n}}\n', encoding="utf-8")
    save_manifest(pkg)
    (root / ".gitignore").write_text("build/\ndist/\n.fac/\n", encoding="utf-8") if not (root / ".gitignore").exists() else None
    print(f"created {root / 'fac.toml'}")
    return 0


def cmd_add(a) -> int:
    root = pathlib.Path(".").resolve()
    pkg = load_package(root)
    d = (root / a.path).resolve()
    try:
        rel = d.relative_to(root)
    except ValueError:
        raise PkgError(f"dependency path escapes project root: {a.path}")
    dep = load_package(d)
    if dep.name != a.name:
        raise PkgError(f"{a.path}/fac.toml declares package {dep.name!r}, not {a.name!r}")
    pkg.deps[a.name] = {"path": rel.as_posix(), "version": a.version or ""}
    save_manifest(pkg)
    resolve(root)                              # validate the whole graph before keeping the change
    print(f"added {a.name} {dep.version} ({rel.as_posix()})")
    return 0


def cmd_remove(a) -> int:
    root = pathlib.Path(".").resolve()
    pkg = load_package(root)
    if a.name not in pkg.deps:
        raise PkgError(f"no dependency named {a.name}")
    del pkg.deps[a.name]
    save_manifest(pkg)
    print(f"removed {a.name}")
    return 0


def cmd_list(a) -> int:
    res = resolve(pathlib.Path("."))
    for p in res.order:
        print(f"{p.name} {p.version}" + ("  (root)" if p is res.root else f"  {p.root.relative_to(res.root.root).as_posix()}"))
    return 0


def cmd_tree(a) -> int:
    res = resolve(pathlib.Path("."))
    by_root = {p.root: p for p in res.order}

    def show(p: Package, depth: int):
        print("  " * depth + f"{p.name} {p.version}")
        for dn, spec in sorted(p.deps.items()):
            show(by_root[(p.root / spec["path"]).resolve()], depth + 1)
    show(res.root, 0)
    return 0


def cmd_verify(a) -> int:
    res = resolve(pathlib.Path("."))
    problems = check_compat(res)
    with_tmp = pathlib.Path(".").resolve() / "build" / ".fac" / "verify"
    try:
        stage(res, with_tmp)
    except PkgError as e:
        problems.append(str(e))
    if (res.root.root / "fac.lock").exists():
        problems += check_lock(res)
    for p in problems:
        print("error: " + p, file=sys.stderr)
    if not problems:
        print(f"ok: {len(res.order)} package(s), compiler {compiler_version()}")
    return 1 if problems else 0


def cmd_lock(a) -> int:
    res = resolve(pathlib.Path("."))
    if a.check:
        problems = check_lock(res)
        for p in problems:
            print("error: " + p, file=sys.stderr)
        if not problems:
            print("fac.lock is up to date")
        return 1 if problems else 0
    write_lock(res)
    print(f"wrote fac.lock ({len(res.order)} packages)")
    return 0


def cmd_pack(a) -> int:
    res = resolve(pathlib.Path("."))
    root = res.root.root
    out = root / "dist"
    out.mkdir(exist_ok=True)
    target = out / f"{res.root.name}-{res.root.version}.zip"
    files = [root / "fac.toml"] + sorted(root.glob("src/*.fac")) + sorted(p for p in root.glob("*") if p.is_file() and re.match(r"^(README|LICENSE)", p.name))
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            zi = zipfile.ZipInfo(f"{res.root.name}-{res.root.version}/{f.relative_to(root).as_posix()}", (2000, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, f.read_bytes())
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    (out / (target.name + ".sha256")).write_text(f"{digest}  {target.name}\n", encoding="utf-8")
    print(f"wrote {target} (sha256 {digest[:16]}...)")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="facpkg", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    i = sub.add_parser("init")
    i.add_argument("dir", nargs="?", default=".")
    i.add_argument("--name")
    i.add_argument("--lib", action="store_true")
    for c in ("add",):
        p = sub.add_parser(c)
        p.add_argument("name")
        p.add_argument("path")
        p.add_argument("--version", help="version requirement, e.g. ^1.2")
    r = sub.add_parser("remove")
    r.add_argument("name")
    sub.add_parser("list")
    sub.add_parser("tree")
    sub.add_parser("verify", aliases=["check"])
    lk = sub.add_parser("lock")
    lk.add_argument("--check", action="store_true")
    sub.add_parser("pack")
    return ap


def main(argv=None) -> int:
    a = build_parser().parse_args(argv)
    fn = {"init": cmd_init, "add": cmd_add, "remove": cmd_remove, "list": cmd_list, "tree": cmd_tree,
          "verify": cmd_verify, "check": cmd_verify, "lock": cmd_lock, "pack": cmd_pack}[a.cmd]
    try:
        return fn(a)
    except PkgError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
