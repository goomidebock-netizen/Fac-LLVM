/* llcheck: ตรวจ + optimize + แปลง LLVM IR (.ll) เป็น object (.o) ผ่าน LLVM C API
 * ใช้ตอนเครื่องไม่มี clang (build: gcc tools/llcheck.c -o llcheck -l:libLLVM.so.20.1)
 * ใช้:  llcheck in.ll out.o [O0|O1|O2|O3]                                          */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef void *R;
extern R LLVMContextCreate(void);
extern int LLVMCreateMemoryBufferWithContentsOfFile(const char *, R *, char **);
extern int LLVMParseIRInContext(R, R, R *, char **);
extern int LLVMVerifyModule(R, int, char **);
extern void LLVMInitializeX86TargetInfo(void), LLVMInitializeX86Target(void), LLVMInitializeX86TargetMC(void),
    LLVMInitializeX86AsmPrinter(void), LLVMInitializeX86AsmParser(void);
extern char *LLVMGetDefaultTargetTriple(void);
extern int LLVMGetTargetFromTriple(const char *, R *, char **);
extern R LLVMCreateTargetMachine(R, const char *, const char *, const char *, int, int, int);
extern R LLVMCreatePassBuilderOptions(void);
extern R LLVMRunPasses(R, const char *, R, R);
extern int LLVMTargetMachineEmitToFile(R, R, const char *, int, char **);
extern void LLVMSetTarget(R, const char *);
extern R LLVMCreateTargetDataLayout(R);
extern void LLVMSetModuleDataLayout(R, R);
extern char *LLVMGetHostCPUName(void), *LLVMGetHostCPUFeatures(void);
extern char *LLVMGetErrorMessage(R);
extern int LLVMPrintModuleToFile(R, const char *, char **);

int main(int argc, char **argv) {
  if (argc < 3) { fprintf(stderr, "usage: llcheck in.ll out.o [O0|O1|O2|O3]\n"); return 2; }
  const char *lvl = argc > 3 ? argv[3] : "O2";
  char pipe[512]; snprintf(pipe, 512, "default<%s>", lvl);
  if (getenv("FAC_PIPELINE")) snprintf(pipe, 512, "%s", getenv("FAC_PIPELINE"));   /* debug: ระบุ pass pipeline เอง เช่น function(sroa,instcombine) */
  char *err = 0; R buf, mod, ctx = LLVMContextCreate();
  if (LLVMCreateMemoryBufferWithContentsOfFile(argv[1], &buf, &err)) { fprintf(stderr, "read: %s\n", err); return 1; }
  if (LLVMParseIRInContext(ctx, buf, &mod, &err)) { fprintf(stderr, "IR parse error: %s\n", err); return 1; }
  if (LLVMVerifyModule(mod, 2, &err)) { fprintf(stderr, "IR verify error: %s\n", err); return 1; }
  LLVMInitializeX86TargetInfo(); LLVMInitializeX86Target(); LLVMInitializeX86TargetMC();
  LLVMInitializeX86AsmPrinter(); LLVMInitializeX86AsmParser();
  char *tri = LLVMGetDefaultTargetTriple(); R tgt;
  if (LLVMGetTargetFromTriple(tri, &tgt, &err)) { fprintf(stderr, "target: %s\n", err); return 1; }
  int ol = !strcmp(lvl, "O0") ? 0 : !strcmp(lvl, "O1") ? 1 : !strcmp(lvl, "O2") ? 2 : 3;
  R tm = LLVMCreateTargetMachine(tgt, tri, LLVMGetHostCPUName(), LLVMGetHostCPUFeatures(), ol, 2, 0);
  LLVMSetTarget(mod, tri);
  LLVMSetModuleDataLayout(mod, LLVMCreateTargetDataLayout(tm));
  R e = LLVMRunPasses(mod, pipe, tm, LLVMCreatePassBuilderOptions());
  if (e) { fprintf(stderr, "passes: %s\n", LLVMGetErrorMessage(e)); return 1; }
  if (getenv("FAC_DUMP_OPT")) LLVMPrintModuleToFile(mod, getenv("FAC_DUMP_OPT"), &err);   /* ดู IR หลัง optimize เพื่อ debug */
  if (LLVMTargetMachineEmitToFile(tm, mod, argv[2], 1, &err)) { fprintf(stderr, "emit: %s\n", err); return 1; }
  return 0;
}
