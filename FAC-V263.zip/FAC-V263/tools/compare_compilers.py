#!/usr/bin/env python3
"""Compare LLVM IR emitted by two FAC compiler builds on the same fixtures."""
from __future__ import annotations

import argparse
import difflib
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FIXTURES = [
    "examples/language_v2.fac",
    "tests/cases/t01_ops.fac",
    "tests/cases/t23_recursion_guard.fac",
    "tests/cases/t127_control_flow.fac",
    "tests/cases/t109_native_generic_option_result.fac",
]


def compile_ir(compiler: Path, source: Path, output: Path) -> tuple[int, str]:
    env = os.environ.copy()
    # Do not allow a caller's Runtime override to influence source-to-IR checks.
    env.pop("FAC_RT", None)
    proc = subprocess.run(
        [str(compiler), str(source), "--emit-ll", "-o", str(output)],
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    return proc.returncode, proc.stdout


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, type=Path, help="previous-release facc binary")
    parser.add_argument("--candidate", required=True, type=Path, help="candidate facc binary")
    parser.add_argument("fixtures", nargs="*", help="FAC fixture paths relative to the repository root")
    args = parser.parse_args()

    baseline = args.baseline.expanduser().resolve()
    candidate = args.candidate.expanduser().resolve()
    for label, path in (("baseline", baseline), ("candidate", candidate)):
        if not path.is_file() or not os.access(path, os.X_OK):
            print(f"ERROR: {label} compiler is not an executable file: {path}", file=sys.stderr)
            return 2

    fixtures = args.fixtures or DEFAULT_FIXTURES
    failures = 0
    with tempfile.TemporaryDirectory(prefix="fac-ir-diff-") as tmp_name:
        tmp = Path(tmp_name)
        for index, fixture in enumerate(fixtures):
            source = (ROOT / fixture).resolve()
            if not source.is_file() or not source.is_relative_to(ROOT):
                print(f"ERROR: fixture must be a repository file: {fixture}", file=sys.stderr)
                return 2
            old_ir = tmp / f"{index}.baseline.ll"
            new_ir = tmp / f"{index}.candidate.ll"
            old_rc, old_log = compile_ir(baseline, source, old_ir)
            new_rc, new_log = compile_ir(candidate, source, new_ir)
            if old_rc != new_rc:
                print(f"FAIL {fixture}: exit status changed ({old_rc} -> {new_rc})")
                print("--- baseline ---\n" + old_log[-4000:])
                print("--- candidate ---\n" + new_log[-4000:])
                failures += 1
                continue
            if old_rc != 0:
                if old_log != new_log:
                    print(f"FAIL {fixture}: both compilers failed, diagnostics differ")
                    print("--- baseline ---\n" + old_log[-4000:])
                    print("--- candidate ---\n" + new_log[-4000:])
                    failures += 1
                else:
                    print(f"PASS {fixture}: identical failure diagnostic")
                continue
            old_text = old_ir.read_text(encoding="utf-8", errors="replace")
            new_text = new_ir.read_text(encoding="utf-8", errors="replace")
            if old_text == new_text:
                print(f"PASS {fixture}: LLVM IR byte-identical ({len(old_text)} bytes)")
            else:
                print(f"FAIL {fixture}: LLVM IR differs")
                diff = difflib.unified_diff(
                    old_text.splitlines(), new_text.splitlines(),
                    fromfile="baseline", tofile="candidate", n=3,
                )
                for line in list(diff)[:100]:
                    print(line)
                failures += 1

    if failures:
        print(f"Differential check: {len(fixtures) - failures}/{len(fixtures)} passed")
        return 1
    print(f"Differential check: {len(fixtures)}/{len(fixtures)} passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
