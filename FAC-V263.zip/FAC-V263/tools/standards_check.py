#!/usr/bin/env python3
"""Validate the FAC OS/architecture/ABI interoperability inventory."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "api/standards.json").read_text(encoding="utf-8"))
version = (ROOT / "VERSION.toml").read_text(encoding="utf-8")
release_line = next((x for x in version.splitlines() if x.strip().startswith('label =')), '')
release = release_line.split('"')[1] if '"' in release_line else None
errors = []
if manifest.get("schema_version") != 2:
    errors.append("unsupported schema_version (expected 2)")
if manifest.get("release") != release:
    errors.append(f"api/standards.json release {manifest.get('release')} does not match VERSION.toml {release}")
for key in ("os_families", "architectures", "object_formats", "gpu"):
    if not manifest.get(key):
        errors.append(f"missing or empty {key}")
ids = [x.get("id") for x in manifest.get("os_families", [])]
for required in ("windows", "posix", "linux", "apple", "android"):
    if required not in ids:
        errors.append(f"missing OS family {required}")
constraints = manifest.get("current_constraints", {})
if constraints.get("pointer_width_bits") != 64:
    errors.append("current platform contract must remain explicitly 64-bit")
if constraints.get("official_32_bit_support") is not False:
    errors.append("do not claim 32-bit support until runtime assumptions are removed and tested")
if constraints.get("gpu_hardware_backend") is not False:
    errors.append(f"{release} must keep native GPU execution disabled")
if constraints.get("current_gpu_fac_is_reference_buffer_backend") is not True:
    errors.append(f"{release} must describe gpu.fac as a CPU-reference buffer API")
if constraints.get("gpu_buffer_storage_host_resident") is not True:
    errors.append("numeric buffer storage must remain explicitly host-resident")
opencl = next((x for x in manifest.get("gpu", []) if x.get("id") == "opencl"), None)
if not opencl or f"paused-not-included-in-{release}" not in opencl.get("status", ""):
    errors.append(f"native OpenCL must be explicitly paused in {release}")
abi = manifest.get("language_abi", {})
for key in ("fac_internal_calling_convention", "extern_default_calling_convention", "managed_value_boundary",
            "pointer_width_bits", "data_model", "struct_layout", "exception_boundary"):
    if not abi.get(key):
        errors.append(f"missing language_abi.{key}")
if abi.get("pointer_width_bits") != 64:
    errors.append("language_abi.pointer_width_bits must agree with the current 64-bit runtime")
cc = {x.get("id") for x in manifest.get("calling_conventions", [])}
for required in ("fac-internal", "c", "system-v-amd64", "microsoft-x64", "aapcs64"):
    if required not in cc:
        errors.append(f"missing calling convention contract {required}")
layers = manifest.get("api_layers", {})
for layer in ("cross", "native", "legacy_stdlib"):
    if layer not in layers or not layers[layer].get("status"):
        errors.append(f"missing API layer status: {layer}")
if "cross" in layers and "same source spelling" not in layers["cross"].get("contract", ""):
    errors.append("cross API must define same source spelling/observable contract")
if "native" in layers and "target OS" not in layers["native"].get("contract", ""):
    errors.append("native API must declare target requirements")
if not manifest.get("interop_standards", {}).get("c_types"):
    errors.append("missing interop_standards.c_types")
if not manifest.get("gpu_interop", {}).get("synchronization_rule"):
    errors.append("missing GPU/CPU synchronization-domain rule")
if not manifest.get("release_gates", {}).get("target_supported_requires"):
    errors.append("missing target support release gates")
if not manifest.get("target_matrix"):
    errors.append("missing OS × architecture × ABI target matrix")
for target in manifest.get("target_matrix", []):
    for key in ("os", "architecture", "abi", "object_format", "status"):
        if not target.get(key):
            errors.append(f"target_matrix entry missing {key}: {target}")
if not manifest.get("toolchain_contract", {}).get("runtime_match"):
    errors.append("missing compiler/runtime/sysroot ABI matching rule")
if errors:
    for e in errors:
        print(f"standards-check: ERROR: {e}", file=sys.stderr)
    raise SystemExit(1)
print(f"standards-check: OK — {release}; {len(ids)} OS families, {len(manifest['architectures'])} architecture families")
