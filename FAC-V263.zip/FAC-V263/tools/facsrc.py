#!/usr/bin/env python3
"""facsrc -- shared lexical front-end for FAC tooling (V44).

This module mirrors the lexical grammar of ``lex()`` in ``src/lexer.cpp / src/lexer.hpp`` so that the
formatter, language server, diagnostics, documentation generator and API audits all agree
with the compiler about what is code, what is a comment and what is a string.

FAC lexical facts (verified against the compiler source):
  * ``# ...``            line comment; ``## ...`` is a documentation comment (same lexing)
  * ``#* ... *#``        block comment (may span lines, not nestable)
  * ``"..."``            string literal, single line, backslash escapes, braces are *content*
  * ``'x'``              character literal, exactly one code point (or one escape)
  * counted-loop forms include explicit inner-to-outer selector paths such as
    ``for++.for++.i``, ``for--.for++.i`` and prefix aliases ``--for.++for.i``
  * ``//`` and ``/* */`` are NOT comments in FAC (``/`` is only the division operator)

Nothing here changes the language; it only reads source text.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable, Iterator, List, Optional, Tuple

# ----------------------------------------------------------------------------- vocabulary
# Words the compiler gives special meaning to.  Kept in one place so the LSP, the formatter and
# the documentation generator stay in sync.  (Derived from src/lexer.cpp / src/lexer.hpp / docs/*.md.)
KEYWORDS = (
    "import", "module", "as", "global", "just", "without", "public", "private", "protected",
    "static", "final", "abstract", "override", "const", "extern", "export", "link", "unsafe",
    "volatile", "align", "function", "constructor", "destructor", "return", "if", "else",
    "while", "until", "do", "for", "foreach", "in", "match", "case", "default", "select", "guard", "switch", "break",
    "continue", "try", "catch", "throw", "defer", "new", "this", "super", "class", "obj",
    "interface", "implements", "extends", "struct", "enum", "instanceof", "cast", "move",
    "true", "false", "null", "weak",
)
STORAGE_KINDS = ("var", "ptr", "dyn", "heap")
TYPE_WORDS = (
    "byte", "ubyte", "short", "ushort", "int", "uint", "long", "ulong", "float", "double",
    "boolean", "char", "unichar", "string", "void", "auto",
    "array", "list", "arraylist", "linked", "stack", "queue", "maxheap", "trie", "hashmap",
    "hashset", "tree", "graph", "matrix", "mutex",
)
BUILTIN_MODULES = (
    "terminal", "string", "math", "random", "time", "memory", "file", "sys", "bit", "path",
    "json", "regex", "thread", "crypto", "graphic", "csv", "net", "three", "gpu", "audio",
    "font", "keyboard", "mouse",
)
# multi-character operators in the order the compiler tries them
OPERATORS = ("=>", "**=", "<<=", ">>=", "&&=", "||=", "..", "++", "--", "**", "<<", ">>", "<=",
             ">=", "==", "!=", "&&", "||", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "~=")
SINGLE_OPS = "+-*/%&|^~!<>=(){}[],;.:?"

IDENT0 = re.compile(r"[A-Za-z_]")
IDENT = re.compile(r"[A-Za-z0-9_]")


@dataclass
class Tok:
    kind: str          # ident int float char str op comment docblock loop
    text: str
    line: int          # 1-based
    col: int           # 0-based column (in characters)
    end_line: int
    end_col: int
    start: int         # offset in source
    end: int
    doc: bool = False  # for line comments: starts with '##'

    @property
    def is_code(self) -> bool:
        return self.kind not in ("comment",)


@dataclass
class LexIssue:
    line: int
    col: int
    message: str
    end_col: Optional[int] = None


@dataclass
class LexResult:
    tokens: List[Tok] = field(default_factory=list)
    issues: List[LexIssue] = field(default_factory=list)
    bom: bool = False


_ESCAPES = set("0ntr\\'\"{}")


def lex(src: str) -> LexResult:
    """Tokenize ``src``.  Never raises: lexical problems are collected as ``issues`` and scanning
    resumes at the next plausible position, so editors get all errors at once."""
    res = LexResult()
    i, n = 0, len(src)
    line, line_start = 1, 0
    if src.startswith("\ufeff"):
        res.bom = True
        i = 1
        line_start = 1
    toks = res.tokens

    def add(kind, s, e, sl, sc, doc=False):
        toks.append(Tok(kind, src[s:e], sl, sc, line, e - line_start, s, e, doc))

    def issue(l, c, msg, ec=None):
        res.issues.append(LexIssue(l, c, msg, ec))

    while i < n:
        c = src[i]
        if c == "\n":
            line += 1
            i += 1
            line_start = i
            continue
        if c in " \t\r":
            i += 1
            continue
        if c == "#":
            sl, sc, s = line, i - line_start, i
            if i + 1 < n and src[i + 1] == "*":
                j = i + 2
                closed = False
                while j < n:
                    if src[j] == "*" and j + 1 < n and src[j + 1] == "#":
                        j += 2
                        closed = True
                        break
                    if src[j] == "\n":
                        line += 1
                        line_start = j + 1
                    j += 1
                if not closed:
                    issue(sl, sc, "unterminated comment (#* ... *#)")
                    j = n
                add("comment", s, j, sl, sc)
                i = j
                continue
            j = i
            while j < n and src[j] != "\n":
                j += 1
            add("comment", s, j, sl, sc, doc=src.startswith("##", s))
            i = j
            continue
        sl, sc, s = line, i - line_start, i
        if IDENT0.match(c):
            j = i
            while j < n and IDENT.match(src[j]):
                j += 1
            w = src[i:j]
            if w == "for" and src.startswith(("++", "--"), j):
                op = src[j:j + 2]
                k = j + 2
                while k < n and src[k] in " \t":
                    k += 1
                if k < n and src[k] == "(":
                    add("loop", i, j + 2, sl, sc)
                    i = j + 2
                    continue
                if j + 2 < n and src[j + 2] == ".":
                    # A selector is a direction path, read from the innermost
                    # loop outwards, and always ends in the pseudo-index `i`.
                    q = j + 3
                    for_name = ("for++", "for--", "++for", "--for")
                    while True:
                        segment = next((name for name in for_name
                                        if src.startswith(name + ".", q)), None)
                        if segment is None:
                            break
                        q += len(segment) + 1
                    m = q
                    while m < n and IDENT.match(src[m]):
                        m += 1
                    if src[q:m] != "i":
                        issue(sl, sc, f"for{op} index path must end with .i")
                    add("loop", i, m, sl, sc)
                    i = m
                    continue
            add("ident", s, j, sl, sc)
            i = j
            continue
        if src.startswith(("++for", "--for"), i) and not (i + 5 < n and IDENT.match(src[i + 5])):
            k = i + 5
            while k < n and src[k] in " \t":
                k += 1
            if k < n and src[k] == "(":
                add("loop", i, i + 5, sl, sc)
                i += 5
                continue
            if i + 5 < n and src[i + 5] == ".":
                q = i + 6
                for_name = ("for++", "for--", "++for", "--for")
                while True:
                    segment = next((name for name in for_name
                                    if src.startswith(name + ".", q)), None)
                    if segment is None:
                        break
                    q += len(segment) + 1
                m = q
                while m < n and IDENT.match(src[m]):
                    m += 1
                if src[q:m] != "i":
                    issue(sl, sc, f"{src[i:i + 5]} index path must end with .i")
                add("loop", i, m, sl, sc)
                i = m
                continue
        if c.isdigit():
            j = i
            kind = "int"
            if c == "0" and i + 1 < n and src[i + 1] in "xXbBoO":
                j = i + 2
                base = src[i + 1].lower()
                digits = "0123456789abcdefABCDEF_"
                d0 = j
                while j < n and src[j] in digits:
                    j += 1
                body = src[d0:j].replace("_", "")
                ok = {"x": "0123456789abcdefABCDEF", "b": "01", "o": "01234567"}[base]
                if not body:
                    issue(sl, sc, "number literal has no digits")
                elif any(ch not in ok for ch in body):
                    bad = next(ch for ch in body if ch not in ok)
                    issue(sl, sc, f"invalid digit '{bad}' in base-{ {'x': 16, 'b': 2, 'o': 8}[base] } literal")
            else:
                while j < n and (src[j].isdigit() or src[j] == "_"):
                    j += 1
                if j + 1 < n and src[j] == "." and src[j + 1].isdigit():
                    kind = "float"
                    j += 1
                    while j < n and src[j].isdigit():
                        j += 1
                if j < n and src[j] in "eE" and j + 1 < n and (
                        src[j + 1].isdigit() or (src[j + 1] in "+-" and j + 2 < n and src[j + 2].isdigit())):
                    kind = "float"
                    j += 2
                    while j < n and src[j].isdigit():
                        j += 1
            add(kind, s, j, sl, sc)
            i = j
            continue
        if c == "'":
            j = i + 1
            ok = False
            if j < n and src[j] == "\\":
                if j + 1 < n and src[j + 1] in _ESCAPES:
                    j += 2
                    ok = True
                else:
                    issue(sl, sc, "unknown escape in char literal")
                    j += 2
            elif j < n and src[j] not in "\n'":
                j += 1
                ok = True
            if j < n and src[j] == "'" and ok:
                j += 1
            else:
                issue(sl, sc, "char literal must contain exactly one character")
                while j < n and src[j] not in "\n'":
                    j += 1
                if j < n and src[j] == "'":
                    j += 1
            add("char", s, j, sl, sc)
            i = j
            continue
        if c == '"':
            j = i + 1
            closed = False
            while j < n and src[j] != "\n":
                if src[j] == "\\":
                    if j + 1 >= n or src[j + 1] == "\n":
                        j += 1
                        break
                    if src[j + 1] not in _ESCAPES:
                        issue(line, j - line_start, f"unknown escape: \\{src[j + 1]}")
                    j += 2
                    continue
                if src[j] == '"':
                    j += 1
                    closed = True
                    break
                j += 1
            if not closed:
                issue(sl, sc, 'string literal is not closed (missing ")')
            add("str", s, j, sl, sc)
            i = j
            continue
        matched = None
        for op in OPERATORS:
            if op == ".." and ((i > 0 and src[i - 1] == ".") or (i + 2 < n and src[i + 2] == ".")):
                continue  # keep '...' as three dots (variadic)
            if src.startswith(op, i):
                matched = op
                break
        if matched is None and c in SINGLE_OPS:
            matched = c
        if matched is None:
            issue(sl, sc, f"unknown character: '{c}'")
            i += 1
            continue
        add("op", s, i + len(matched), sl, sc)
        i += len(matched)
    return res


# ----------------------------------------------------------------------------- structure
def code_tokens(toks: Iterable[Tok]) -> List[Tok]:
    return [t for t in toks if t.kind != "comment"]


def bracket_issues(toks: Iterable[Tok]) -> List[LexIssue]:
    """Unbalanced (), [], {} -- reported the way a compiler would (first offender)."""
    pairs = {")": "(", "]": "[", "}": "{"}
    stack: List[Tok] = []
    out: List[LexIssue] = []
    for t in toks:
        if t.kind != "op":
            continue
        if t.text in "([{":
            stack.append(t)
        elif t.text in pairs:
            if not stack or stack[-1].text != pairs[t.text]:
                out.append(LexIssue(t.line, t.col, f"unmatched '{t.text}'", t.col + 1))
            else:
                stack.pop()
    for t in reversed(stack):
        out.append(LexIssue(t.line, t.col, f"unclosed '{t.text}'", t.col + 1))
    return out


def diagnose(src: str) -> List[LexIssue]:
    """All lexical + bracket problems, sorted by position (same rules as the compiler lexer)."""
    r = lex(src)
    issues = list(r.issues) + bracket_issues(r.tokens)
    issues.sort(key=lambda x: (x.line, x.col))
    return issues


# ----------------------------------------------------------------------------- declarations
@dataclass
class Decl:
    kind: str                  # function class struct enum interface global import module
    name: str
    line: int                  # 1-based line of the declaration keyword/name
    col: int
    public: bool = False
    signature: str = ""        # one-line text of the header (up to '{' / end of line)
    ret: str = ""              # for functions: textual return type
    params: str = ""           # for functions: text inside the parens
    parent: str = ""           # enclosing class/struct/interface name for methods
    doc: List[str] = field(default_factory=list)   # ## doc comment lines immediately above
    body_has_throw: bool = False
    end_line: int = 0
    modifiers: Tuple[str, ...] = ()


_MODS = {"public", "private", "protected", "static", "final", "abstract", "override", "unsafe", "export"}


def _doc_above(lines: List[str], line_idx: int) -> List[str]:
    """Contiguous ``##`` lines directly above ``line_idx`` (0-based)."""
    out: List[str] = []
    j = line_idx - 1
    while j >= 0 and lines[j].lstrip().startswith("##"):
        out.append(lines[j].lstrip()[2:].strip())
        j -= 1
    out.reverse()
    return out


def scan_declarations(src: str) -> List[Decl]:
    """Lightweight (token based, no full parse) declaration index.

    Understands: module/import lines, [modifiers] function/class/struct/enum/interface headers,
    methods inside classes/structs/interfaces, and top-level variable declarations.  It does not
    type-check anything; it exists for outlines, hover, go-to-definition and documentation."""
    res = lex(src)
    toks = [t for t in res.tokens if t.kind != "comment"]
    lines = src.split("\n")
    decls: List[Decl] = []
    depth = 0
    stack: List[Tuple[str, int]] = []   # (type name, depth at which its body opened)
    i, n = 0, len(toks)

    def line_text(t: Tok) -> str:
        return lines[t.line - 1] if 0 < t.line <= len(lines) else ""

    def find_body_end(start_idx: int) -> Tuple[int, bool, int]:
        """index of matching '}' for the first '{' at/after start_idx, whether a throw occurs."""
        j = start_idx
        while j < n and not (toks[j].kind == "op" and toks[j].text == "{"):
            if toks[j].kind == "op" and toks[j].text in "}":
                return j, False, toks[j].line
            j += 1
        if j >= n:
            return n - 1, False, toks[-1].line if toks else 0
        d, thr = 0, False
        k = j
        while k < n:
            tk = toks[k]
            if tk.kind == "op" and tk.text == "{":
                d += 1
            elif tk.kind == "op" and tk.text == "}":
                d -= 1
                if d == 0:
                    return k, thr, tk.line
            elif tk.kind == "ident" and tk.text == "throw":
                thr = True
            k += 1
        return n - 1, thr, toks[-1].line

    while i < n:
        t = toks[i]
        if t.kind == "op" and t.text == "{":
            depth += 1
        elif t.kind == "op" and t.text == "}":
            depth -= 1
            while stack and stack[-1][1] >= depth:
                stack.pop()
        elif t.kind == "ident" and t.text in ("module", "import") and depth == 0:
            j = i + 1
            if j < n and toks[j].kind == "ident":
                nm = toks[j].text
                decls.append(Decl(t.text, nm, t.line, toks[j].col, signature=line_text(t).strip()))
        elif t.kind == "ident" and (t.text in _MODS or t.text in ("function", "class", "struct", "enum", "interface")):
            # collect modifier run
            j = i
            mods: List[str] = []
            while j < n and toks[j].kind == "ident" and toks[j].text in _MODS:
                mods.append(toks[j].text)
                j += 1
            if j < n and toks[j].kind == "ident" and toks[j].text in ("class", "obj") and mods == [] and False:
                pass
            if j < n and toks[j].kind == "ident" and toks[j].text == "abstract":
                mods.append("abstract")
                j += 1
            kw = toks[j].text if j < n and toks[j].kind == "ident" else ""
            if kw in ("class", "struct", "enum", "interface") and (i == 0 or toks[i - 1].text != "."):
                if j + 1 < n and toks[j + 1].kind == "ident":
                    nm = toks[j + 1]
                    endi, _, endl = find_body_end(j + 1)
                    d = Decl(kw, nm.text, nm.line, nm.col, public="public" in mods,
                             signature=line_text(nm).strip(), modifiers=tuple(mods),
                             parent=stack[-1][0] if stack else "", end_line=endl)
                    d.doc = _doc_above(lines, t.line - 1)
                    decls.append(d)
                    # remember body for methods
                    k = j + 1
                    while k < n and not (toks[k].kind == "op" and toks[k].text == "{"):
                        k += 1
                    if k < n:
                        stack.append((nm.text, depth))
                    i = j + 1
                    continue
            elif kw == "function":
                # return type tokens until the identifier followed by '('
                k = j + 1
                par = 0
                name_idx = -1
                while k < n:
                    tk = toks[k]
                    if tk.kind == "op" and tk.text == "<":
                        par += 1
                    elif tk.kind == "op" and tk.text == ">":
                        par = max(0, par - 1)
                    elif tk.kind == "op" and tk.text in (">>",):
                        par = max(0, par - 2)
                    if (tk.kind == "ident" and k + 1 < n and toks[k + 1].kind == "op" and toks[k + 1].text == "("
                            and par == 0):
                        name_idx = k
                        break
                    if tk.kind == "op" and tk.text in "{;" :
                        break
                    k += 1
                if name_idx > 0:
                    nm = toks[name_idx]
                    ret_src = " ".join(x.text for x in toks[j + 1:name_idx])
                    # params: balanced parens
                    p = name_idx + 1
                    d2 = 0
                    q = p
                    while q < n:
                        if toks[q].kind == "op" and toks[q].text == "(":
                            d2 += 1
                        elif toks[q].kind == "op" and toks[q].text == ")":
                            d2 -= 1
                            if d2 == 0:
                                break
                        q += 1
                    params_src = src[toks[p].end:toks[q].start] if q < n else ""
                    endi, thr, endl = find_body_end(q)
                    d = Decl("function", nm.text, nm.line, nm.col, public="public" in mods,
                             signature=line_text(nm).strip(), ret=ret_src.replace(" < ", "<").replace(" >", ">"),
                             params=" ".join(params_src.split()), parent=stack[-1][0] if stack else "",
                             body_has_throw=thr, end_line=endl, modifiers=tuple(mods))
                    d.doc = _doc_above(lines, t.line - 1)
                    decls.append(d)
                    i = q  # skip the header; body braces are processed by the main loop
                    continue
        i += 1
    return decls
