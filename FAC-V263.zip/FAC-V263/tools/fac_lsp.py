#!/usr/bin/env python3
"""FAC Language Server (V44) -- LSP over stdio, no third-party packages.

Features
  diagnostics      lexical errors while typing; compiler front-end errors (parse/type-check, via
                   ``facc --emit-ll``) on open and save, including errors in imported modules
  completion       keywords, types, built-in/imported module members after ``module.`` (also
                   ``terminal.out.`` / aliases), declarations of the open file, ``this.`` methods
  hover            signature, ownership, error model, alias/deprecation status for built-ins and
                   source libraries; ## documentation of local declarations
  definition       local declarations and public declarations of imported .fac modules
  documentSymbol   outline (functions, classes, structs, enums, interfaces)
  formatting       whole-document formatting through facfmt (token-safe)

Not implemented (see docs/TOOLING.md): rename, references, semantic tokens, incremental sync,
type-aware completion.  The server never changes the language: it only reads source text.
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import sys
import urllib.parse
import urllib.request
from typing import Dict, List, Optional

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import facsrc  # noqa: E402
import facfmt  # noqa: E402
import fac_diagnostics  # noqa: E402

SYMBOL_KIND = {"function": 12, "class": 5, "struct": 23, "enum": 10, "interface": 11}
KW_COMPLETION = 14
FUNC_COMPLETION = 3
MODULE_COMPLETION = 9
CLASS_COMPLETION = 7


def uri_to_path(uri: str) -> str:
    p = urllib.parse.urlparse(uri)
    path = urllib.request.url2pathname(p.path)
    if os.name == "nt" and re.match(r"^/[A-Za-z]:", p.path):
        path = p.path[1:]
    return path


def path_to_uri(path: str) -> str:
    return pathlib.Path(path).resolve().as_uri()


def u16_to_idx(line: str, u16: int) -> int:
    n = 0
    for i, ch in enumerate(line):
        if n >= u16:
            return i
        n += 2 if ord(ch) > 0xFFFF else 1
    return len(line)


def idx_to_u16(line: str, idx: int) -> int:
    return sum(2 if ord(c) > 0xFFFF else 1 for c in line[:idx])


class Server:
    def __init__(self, root: pathlib.Path = ROOT, facc: Optional[str] = None):
        self.root = root
        self.facc = facc
        self.docs: Dict[str, str] = {}
        self.shutdown = False
        self.manifest = self._load_manifest()
        self.builtin = {e["name"]: e for e in self.manifest["builtin"]}
        self.source_by_mod: Dict[str, List[dict]] = {}
        for e in self.manifest["source"]:
            self.source_by_mod.setdefault(e["module"], []).append(e)
        self.modules = set(self.manifest["modules"]) | set(self.source_by_mod)

    def _load_manifest(self) -> dict:
        p = self.root / "api" / "manifest.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        import api_manifest
        return api_manifest.build()

    # ------------------------------------------------------------------ document helpers
    def imports(self, text: str) -> Dict[str, str]:
        """alias or module name -> module name (as written in import lines)."""
        out: Dict[str, str] = {}
        for m in re.finditer(r"^\s*import\s+([A-Za-z_]\w*)\.fac(?:\s+(?:as\s+([A-Za-z_]\w*)|global|just[^\n]*|without[^\n]*))?", text, re.M):
            mod, alias = m.group(1), m.group(2)
            out[alias or mod] = mod
            if alias:
                out.setdefault(mod, mod)
        return out

    def word_at(self, text: str, line: int, ch: int):
        lines = text.split("\n")
        if line >= len(lines):
            return None
        s = lines[line]
        i = u16_to_idx(s, ch)
        a = i
        while a > 0 and (s[a - 1].isalnum() or s[a - 1] in "_."):
            a -= 1
        b = i
        while b < len(s) and (s[b].isalnum() or s[b] == "_"):
            b += 1
        word = s[a:b]
        return word.strip(".") or None

    # ------------------------------------------------------------------ diagnostics
    def diagnostics(self, uri: str, compiler: bool) -> dict:
        path = uri_to_path(uri)
        text = self.docs.get(uri, "")
        ds = fac_diagnostics.check_file(path, self.facc, None, use_compiler=compiler, text=text)
        out = []
        for d in ds:
            if pathlib.Path(d.file).resolve() != pathlib.Path(path).resolve():
                continue           # error located in an imported module: shown on that file when opened
            line = max(d.line - 1, 0)
            ln = text.split("\n")[line] if line < len(text.split("\n")) else ""
            start = d.col - 1
            end = len(ln) if d.source == "compiler" else min(len(ln), start + 1)
            out.append({"range": {"start": {"line": line, "character": idx_to_u16(ln, start)},
                                  "end": {"line": line, "character": idx_to_u16(ln, max(end, start + 1))}},
                        "severity": 1 if d.severity == "error" else 2, "source": f"fac-{d.source}", "message": d.message})
        # errors inside imported modules are summarised on the importing file so they are not silent
        for d in ds:
            if pathlib.Path(d.file).resolve() != pathlib.Path(path).resolve() and d.severity == "error":
                out.append({"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}}, "severity": 1,
                            "source": "fac-compiler", "message": f"{pathlib.Path(d.file).name}:{d.line}: {d.message}"})
                break
        return {"jsonrpc": "2.0", "method": "textDocument/publishDiagnostics", "params": {"uri": uri, "diagnostics": out}}

    # ------------------------------------------------------------------ completion
    def completion(self, uri: str, pos: dict) -> List[dict]:
        text = self.docs.get(uri, "")
        lines = text.split("\n")
        line = lines[pos["line"]] if pos["line"] < len(lines) else ""
        prefix = line[:u16_to_idx(line, pos["character"])]
        m = re.search(r"([A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)*)\.\s*(\w*)$", prefix)
        items: List[dict] = []
        if m:
            qual = m.group(1)
            imps = self.imports(text)
            head, _, rest = qual.partition(".")
            mod = imps.get(head, head)
            sub = (mod + ("." + rest if rest else ""))
            if head == "this":
                cls = self._enclosing_class(text, pos["line"] + 1)
                for d in facsrc.scan_declarations(text):
                    if d.kind == "function" and d.parent == cls:
                        items.append({"label": d.name, "kind": 2, "detail": d.ret + " " + d.name + "(" + d.params + ")"})
                return items
            seen = set()
            for name, e in self.builtin.items():
                if name.startswith(sub + "."):
                    nxt = name[len(sub) + 1:].split(".")[0]
                    if nxt in seen:
                        continue
                    seen.add(nxt)
                    full = name if "." not in name[len(sub) + 1:] else None
                    items.append({"label": nxt, "kind": FUNC_COMPLETION if full else MODULE_COMPLETION,
                                  "detail": self._sig(e) if full else "namespace",
                                  "documentation": self._builtin_md(e) if full else ""})
            for e in self.source_by_mod.get(mod, []):
                leaf = e["name"][len(mod) + 1:]
                if "." in leaf and rest == "":
                    leaf = leaf.split(".")[0]
                if leaf in seen:
                    continue
                seen.add(leaf)
                items.append({"label": leaf, "kind": FUNC_COMPLETION if e["kind"] == "source-function" else CLASS_COMPLETION,
                              "detail": e["signature"].rstrip(" {")})
            return items
        for k in facsrc.KEYWORDS:
            items.append({"label": k, "kind": KW_COMPLETION, "detail": "keyword"})
        for k in facsrc.STORAGE_KINDS + facsrc.TYPE_WORDS:
            items.append({"label": k, "kind": KW_COMPLETION, "detail": "type / storage"})
        for mname in sorted(self.modules):
            items.append({"label": mname, "kind": MODULE_COMPLETION, "detail": "module"})
        for d in facsrc.scan_declarations(text):
            if d.kind in ("function", "class", "struct", "enum", "interface") and not d.parent:
                items.append({"label": d.name, "kind": FUNC_COMPLETION if d.kind == "function" else CLASS_COMPLETION,
                              "detail": d.signature.rstrip(" {")})
        return items

    def _enclosing_class(self, text: str, line: int) -> str:
        best = ""
        for d in facsrc.scan_declarations(text):
            if d.kind in ("class", "struct", "interface") and d.line <= line <= (d.end_line or d.line):
                best = d.name
        return best

    # ------------------------------------------------------------------ hover / definition
    def _sig(self, e: dict) -> str:
        o = e["overloads"][0]
        ps = o.get("params_text") if "params_text" in o else ", ".join(o["params"])
        return f"{e['name']}({ps}) -> {o['returns']}"

    def _builtin_md(self, e: dict) -> str:
        parts = [f"```fac\n{self._sig(e)}\n```"]
        if e.get("note"):
            parts.append(e["note"])
        er = e["errors"]
        if er["model"] == "throws":
            codes = ", ".join(f"{c} {self.manifest['error_codes'].get(str(c), '?')}" for c in er["codes"])
            parts.append(f"**Errors:** throws `Error` (code {codes})")
        elif er["model"] in ("predicate", "status-flag"):
            parts.append("**Errors:** " + ("predicate" if er["model"] == "predicate" else "boolean status flag (false = failed)"))
        o = e.get("ownership")
        if o:
            if o["result"] in ("owned", "owned-handle"):
                parts.append("**Result:** owned by caller" + (f" — release with `{o['release']}`" if "release" in o else ""))
            elif o["result"] == "borrowed-view":
                parts.append("**Result:** borrowed view — " + o["result_note"])
        if e.get("alias_of"):
            parts.append(f"**{e['status'].capitalize()}:** use `{e['alias_of']}`" + (f" (removal not before {e['remove_not_before']})" if e.get("remove_not_before") else ""))
        parts.append(f"Thread-safety: {e['thread_safety']}")
        return "\n\n".join(parts)

    def _source_md(self, e: dict) -> str:
        parts = [f"```fac\n{e['signature'].rstrip(' {')}\n```"]
        if e.get("description"):
            parts.append(e["description"])
        c = e.get("contract") or {}
        for k, lab in (("returns", "Returns"), ("ownership", "Ownership"), ("errors", "Errors"), ("thread-safety", "Thread-safety")):
            if c.get(k):
                parts.append(f"**{lab}:** {c[k]}")
        return "\n\n".join(parts)

    def hover(self, uri: str, pos: dict) -> Optional[dict]:
        text = self.docs.get(uri, "")
        word = self.word_at(text, pos["line"], pos["character"])
        if not word:
            return None
        imps = self.imports(text)
        head, _, rest = word.partition(".")
        cand = [word]
        if head in imps:
            cand.append(imps[head] + ("." + rest if rest else ""))
        for c in cand:
            if c in self.builtin:
                return {"contents": {"kind": "markdown", "value": self._builtin_md(self.builtin[c])}}
            for e in self.source_by_mod.get(c.split(".")[0], []):
                if e["name"] == c or e["name"].endswith("." + c.split(".", 1)[-1]) and c.split(".")[0] == e["module"] and "." in c:
                    return {"contents": {"kind": "markdown", "value": self._source_md(e)}}
        for d in facsrc.scan_declarations(text):
            if d.name == word.split(".")[-1] and d.kind in ("function", "class", "struct", "enum", "interface"):
                body = f"```fac\n{d.signature.rstrip(' {')}\n```"
                if d.doc:
                    body += "\n\n" + "\n".join(d.doc)
                return {"contents": {"kind": "markdown", "value": body}}
        return None

    def definition(self, uri: str, pos: dict) -> Optional[list]:
        text = self.docs.get(uri, "")
        word = self.word_at(text, pos["line"], pos["character"])
        if not word:
            return None
        path = uri_to_path(uri)
        imps = self.imports(text)
        head, _, rest = word.partition(".")
        leaf = word.split(".")[-1]
        if rest and head in imps:
            mod = imps[head]
            for base in (pathlib.Path(path).parent, self.root / "stdlib"):
                f = base / f"{mod}.fac"
                if f.exists():
                    src = f.read_text(encoding="utf-8", errors="replace")
                    for d in facsrc.scan_declarations(src):
                        if d.name == leaf and d.kind in ("function", "class", "struct", "enum", "interface"):
                            return [self._loc(str(f), d)]
        for d in facsrc.scan_declarations(text):
            if d.name == leaf and d.kind in ("function", "class", "struct", "enum", "interface"):
                return [self._loc(path, d)]
        return None

    def _loc(self, path: str, d) -> dict:
        return {"uri": path_to_uri(path), "range": {"start": {"line": d.line - 1, "character": d.col},
                                                    "end": {"line": d.line - 1, "character": d.col + len(d.name)}}}

    def symbols(self, uri: str) -> List[dict]:
        text = self.docs.get(uri, "")
        out = []
        for d in facsrc.scan_declarations(text):
            if d.kind in SYMBOL_KIND:
                out.append({"name": d.name, "kind": SYMBOL_KIND[d.kind], "containerName": d.parent,
                            "location": {"uri": uri, "range": {"start": {"line": d.line - 1, "character": d.col},
                                                               "end": {"line": d.line - 1, "character": d.col + len(d.name)}}}})
        return out

    def formatting(self, uri: str, opts: dict) -> List[dict]:
        text = self.docs.get(uri, "")
        try:
            new = facfmt.format_text(text, indent=int(opts.get("tabSize", 4)) if opts.get("insertSpaces", True) else 4)
        except facfmt.FormatError:
            return []
        if new == text:
            return []
        lines = text.split("\n")
        return [{"range": {"start": {"line": 0, "character": 0},
                           "end": {"line": len(lines), "character": 0}}, "newText": new}]

    # ------------------------------------------------------------------ dispatch
    def capabilities(self) -> dict:
        return {"textDocumentSync": {"openClose": True, "change": 1, "save": {"includeText": False}},
                "completionProvider": {"triggerCharacters": ["."]}, "hoverProvider": True,
                "definitionProvider": True, "documentSymbolProvider": True, "documentFormattingProvider": True}

    def handle(self, msg: dict) -> List[dict]:
        method, params, ident = msg.get("method"), msg.get("params") or {}, msg.get("id")
        out: List[dict] = []

        def reply(result):
            if ident is not None:
                out.append({"jsonrpc": "2.0", "id": ident, "result": result})

        try:
            if method == "initialize":
                reply({"capabilities": self.capabilities(), "serverInfo": {"name": "FAC Language Server", "version": "0.4.0"}})
            elif method == "shutdown":
                self.shutdown = True
                reply(None)
            elif method == "textDocument/didOpen":
                d = params["textDocument"]
                self.docs[d["uri"]] = d["text"]
                out.append(self.diagnostics(d["uri"], compiler=True))
            elif method == "textDocument/didChange":
                uri = params["textDocument"]["uri"]
                ch = params.get("contentChanges", [])
                if ch:
                    self.docs[uri] = ch[-1]["text"]
                    out.append(self.diagnostics(uri, compiler=False))
            elif method == "textDocument/didSave":
                uri = params["textDocument"]["uri"]
                if uri in self.docs:
                    out.append(self.diagnostics(uri, compiler=True))
            elif method == "textDocument/didClose":
                uri = params["textDocument"]["uri"]
                self.docs.pop(uri, None)
                out.append({"jsonrpc": "2.0", "method": "textDocument/publishDiagnostics", "params": {"uri": uri, "diagnostics": []}})
            elif method == "textDocument/completion":
                reply({"isIncomplete": False, "items": self.completion(params["textDocument"]["uri"], params["position"])})
            elif method == "textDocument/hover":
                reply(self.hover(params["textDocument"]["uri"], params["position"]))
            elif method == "textDocument/definition":
                reply(self.definition(params["textDocument"]["uri"], params["position"]))
            elif method == "textDocument/documentSymbol":
                reply(self.symbols(params["textDocument"]["uri"]))
            elif method == "textDocument/formatting":
                reply(self.formatting(params["textDocument"]["uri"], params.get("options", {})))
            elif ident is not None and method not in ("initialized", "exit"):
                out.append({"jsonrpc": "2.0", "id": ident, "error": {"code": -32601, "message": f"method not supported: {method}"}})
        except Exception as e:  # a bad request must never take the server down
            if ident is not None:
                out.append({"jsonrpc": "2.0", "id": ident, "error": {"code": -32603, "message": f"{type(e).__name__}: {e}"}})
        return out


def read_message(stream) -> Optional[dict]:
    headers = {}
    while True:
        line = stream.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        if b":" in line:
            k, v = line.decode("ascii", "replace").split(":", 1)
            headers[k.strip().lower()] = v.strip()
    try:
        n = int(headers.get("content-length", "0"))
    except ValueError:
        return None
    if n <= 0:
        return None
    return json.loads(stream.read(n).decode("utf-8"))


def write_message(stream, obj: dict) -> None:
    body = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    stream.write(f"Content-Length: {len(body)}\r\n\r\n".encode("ascii") + body)
    stream.flush()


def serve(stdin=None, stdout=None, facc: Optional[str] = None) -> int:
    stdin = stdin or sys.stdin.buffer
    stdout = stdout or sys.stdout.buffer
    srv = Server(facc=facc)
    while True:
        try:
            msg = read_message(stdin)
        except ValueError:
            continue
        if msg is None:
            return 0 if srv.shutdown else 1
        if msg.get("method") == "exit":
            return 0 if srv.shutdown else 1
        for out in srv.handle(msg):
            write_message(stdout, out)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="FAC language server (stdio)")
    ap.add_argument("--facc", help="path to the facc compiler used for diagnostics (default: build/facc)")
    raise SystemExit(serve(facc=ap.parse_args().facc))
