#!/usr/bin/env python3
"""FAC API audit (V44): naming, duplicates, misspellings and contract consistency.

Works on the API manifest (regenerated in memory), so it covers the ~370 built-in APIs and the
public declarations of the source-level stdlib, not just stdlib/*.fac as the V42/V43 audit did.

Rules
  N001  public function names must be lowerCamelCase (types UpperCamelCase, constants UPPER_SNAKE)
  N002  names that differ only by letter case inside one module (readline / readLine)
  N003  probable misspelling: adjacent-letter transposition against a sibling name, or a word from
        the known-misspelling list (anwser, recieve, lenght ...)
  D001  two public names bound to the same runtime symbol without being recorded as aliases
  D002  alias entry whose own name or canonical target is missing from the compiler tables
  R001  predicate-style names (is/has/can/supports) must return boolean
  R002  release-style names (free/close/destroy/dispose) must return void
  R003  count/size-style names (count/size/length/len) must return an integer type
  E001  a module mixes throwing APIs and boolean status-flag APIs (not recorded as a deviation)
  O001  owned-handle result without a documented release function
  S001  source stdlib: two public functions with identical name and parameters in one module

Accepted exceptions live in api/meta.json ("known_deviations") and api/audit-exceptions.json.
Exit status 1 = findings that are not in the baseline (use in CI).

usage: api_audit.py [--json] [--markdown] [--all] [--strict] [--update-baseline] [--output FILE]
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from collections import defaultdict

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import api_manifest  # noqa: E402

MISSPELLINGS = {
    "anwser": "answer", "recieve": "receive", "lenght": "length", "lenth": "length", "widht": "width",
    "heigth": "height", "seperate": "separate", "seperator": "separator", "occurence": "occurrence",
    "paramater": "parameter", "retrun": "return", "positon": "position", "calback": "callback",
    "adress": "address", "begining": "beginning", "existance": "existence", "writeing": "writing",
    "delet": "delete", "intiger": "integer", "colour": "color", "initalize": "initialize",
    "inital": "initial", "overlapp": "overlap", "colide": "collide", "colision": "collision",
    "accelaration": "acceleration", "transparancy": "transparency", "bufer": "buffer",
}
CAMEL = re.compile(r"^[a-z][a-z0-9]*(?:[A-Z][a-z0-9]*|[0-9]+)*$")
UPPER = re.compile(r"^[A-Z][A-Z0-9_]*$")
UPPER_CAMEL = re.compile(r"^[A-Z][A-Za-z0-9]*$")
INTEGRAL = {"int", "long", "uint", "ulong", "int|long", "short", "ushort", "byte", "ubyte"}


def words(name: str):
    return [w.lower() for w in re.findall(r"[A-Z]?[a-z0-9]+|[A-Z]+(?![a-z])", name)]


def transposed(a: str, b: str) -> bool:
    if len(a) != len(b) or a == b or len(a) < 5:
        return False
    d = [i for i in range(len(a)) if a[i] != b[i]]
    return len(d) == 2 and d[1] == d[0] + 1 and a[d[0]] == b[d[1]] and a[d[1]] == b[d[0]]


def leaf(name: str) -> str:
    return name.split(".")[-1]


class Findings:
    def __init__(self):
        self.items = []

    def add(self, rule, subject, message, severity="warning"):
        self.items.append({"rule": rule, "subject": subject, "severity": severity, "message": message})


def audit(manifest: dict, meta: dict) -> list:
    F = Findings()
    builtin = {e["name"]: e for e in manifest["builtin"]}
    alias_names = {a["name"]: a for a in meta["aliases"]}
    canonicals = {a["canonical"] for a in meta["aliases"]}
    deviations = {(d["rule"], d["name"]) for d in meta["known_deviations"]}
    deviation_names = {d["name"] for d in meta["known_deviations"]}

    # --- N001 naming
    for name, e in builtin.items():
        l = leaf(name)
        if e["kind"] == "constant":
            if not UPPER.match(l):
                F.add("N001", name, f"constant '{l}' should be UPPER_SNAKE_CASE")
            continue
        if not CAMEL.match(l) and ("N001", name) not in deviations:
            F.add("N001", name, f"function name '{l}' is not lowerCamelCase")
    for e in manifest["source"]:
        l = leaf(e["name"])
        if e["kind"] == "source-function" and not CAMEL.match(l):
            F.add("N001", e["name"], f"function name '{l}' is not lowerCamelCase")
        if e["kind"] in ("source-class", "source-struct", "source-enum", "source-interface") and not UPPER_CAMEL.match(l):
            F.add("N001", e["name"], f"type name '{l}' is not UpperCamelCase")

    # --- N002 / N003 inside one module (and one nesting parent such as terminal.in)
    groups_by_scope = defaultdict(lambda: defaultdict(set))
    for name in builtin:
        mod = name.split(".")[0]
        rest = name[len(mod) + 1:]
        parent = rest.rsplit(".", 1)[0] if "." in rest else ""
        groups_by_scope[(mod, parent)][leaf(name).lower()].add(name)
    for scope, groups in groups_by_scope.items():
        for low, names in groups.items():
            if len(names) > 1:
                nm = sorted(names)
                # documented when every non-canonical spelling is a recorded alias of one of the others
                ok = all((n in alias_names and alias_names[n]["canonical"] in nm) or n in canonicals for n in nm)
                if not ok:
                    F.add("N002", "|".join(nm), f"names differ only by case: {', '.join(nm)}")
        names = sorted(n for g in groups.values() for n in g)
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                if transposed(leaf(a), leaf(b)) and not ({a, b} & set(alias_names)):
                    F.add("N003", f"{a}|{b}", f"'{leaf(a)}' and '{leaf(b)}' differ by a letter transposition")
    for name in list(builtin) + [e["name"] for e in manifest["source"]]:
        if name in alias_names:
            continue  # recorded misspellings (anwser) are reported by the alias table, not as new findings
        for w in set(words(leaf(name)) + [leaf(name).lower()]):
            if w in MISSPELLINGS:
                F.add("N003", name, f"'{w}' looks like a misspelling of '{MISSPELLINGS[w]}'")

    # --- D001 / D002 duplicates
    sym_map = defaultdict(set)
    for name, e in builtin.items():
        for o in e["overloads"]:
            if o.get("symbol"):
                sym_map[o["symbol"]].add(name)
    for sym, names in sym_map.items():
        names = sorted(names)
        if len(names) > 1:
            unrecorded = [n for n in names if n not in alias_names and n not in canonicals]
            if len(unrecorded) > 1:
                F.add("D001", "|".join(names), f"{', '.join(names)} share runtime symbol {sym} but are not recorded as aliases")
            # a name that shares a symbol with others must be an alias, or the canonical of one
            for n in names:
                if n not in alias_names and n not in canonicals and len(names) > 1:
                    F.add("D001", n, f"{n} shares runtime symbol {sym} with {', '.join(x for x in names if x != n)} but is not recorded in api/meta.json")
    for a in meta["aliases"]:
        if a["name"] not in builtin:
            F.add("D002", a["name"], f"alias '{a['name']}' is not present in the compiler tables")
        if a["canonical"] not in builtin:
            F.add("D002", a["name"], f"canonical '{a['canonical']}' does not exist")

    # --- R001-R003 return type consistency
    for name, e in builtin.items():
        if e["kind"] != "builtin":
            continue
        l = leaf(name)
        rets = {o["returns"] for o in e["overloads"]}
        if re.match(r"^(is|has|can|supports)[A-Z]", l) and rets != {"boolean"}:
            F.add("R001", name, f"predicate-style name returns {', '.join(sorted(rets))}")
        if l in ("free", "close", "destroy", "dispose", "freeBuffer") and rets != {"void"}:
            F.add("R002", name, f"release-style name returns {', '.join(sorted(rets))}")
        if l in ("count", "size", "length", "len") and not rets <= INTEGRAL:
            F.add("R003", name, f"count-style name returns {', '.join(sorted(rets))}")

    # --- E001 mixed error models per module
    fam = defaultdict(lambda: defaultdict(list))
    for name, e in builtin.items():
        if e["kind"] == "builtin":
            fam[name.split(".")[0]][e["errors"]["model"]].append(name)
    for mod, models in sorted(fam.items()):
        if models.get("throws") and models.get("status-flag"):
            if f"{mod}.*" in deviation_names:
                continue
            F.add("E001", mod, f"{mod} mixes throwing ({len(models['throws'])}) and boolean status-flag ({len(models['status-flag'])}) APIs, "
                  f"e.g. {models['throws'][0]} vs {models['status-flag'][0]}")

    # --- O001 handle ownership
    for name, e in builtin.items():
        o = e.get("ownership")
        if o and o["result"] == "owned-handle" and "release" not in o:
            F.add("O001", name, "returns an owned handle but api/meta.json records no release function")

    # --- S001 source duplicates
    seen = defaultdict(list)
    for e in manifest["source"]:
        if e["kind"] == "source-function":
            seen[(e["module"], e["name"], re.sub(r"\s+", "", e["params"]))].append(e)
    for (mod, name, params), items in seen.items():
        if len(items) > 1:
            F.add("S001", name, f"{len(items)} public functions share name and parameters in {mod}")
    return F.items


def baseline_path() -> pathlib.Path:
    return ROOT / "api" / "audit-exceptions.json"


def load_baseline() -> set:
    p = baseline_path()
    if not p.exists():
        return set()
    return set(json.loads(p.read_text(encoding="utf-8")).get("accepted", []))


def to_markdown(items: list, manifest: dict, meta: dict) -> str:
    out = [f"# FAC API Audit ({manifest['release']})", "",
           "Generated by `python3 tools/api_audit.py --markdown --output docs/API_AUDIT.md`. Built-ins come from the compiler tables, "
           "source libraries from `stdlib/`; judgement calls live in `api/meta.json`.", "",
           f"- Built-in entries audited: **{manifest['counts']['builtin']}**; source declarations: **{manifest['counts']['source']}**",
           f"- Open findings: **{len(items)}**", "",
           "## Documented aliases and duplicates (recorded, not findings)", "",
           "| Name | Canonical | Kind | Status | Why |", "|---|---|---|---|---|"]
    for a in meta["aliases"]:
        st = a["status"] + (f" (remove ≥ {a['remove_not_before']})" if "remove_not_before" in a else "")
        out.append(f"| `{a['name']}` | `{a['canonical']}` | {a['kind']} | {st} | {a['reason']} |")
    out += ["", "## Accepted deviations", "", "| Subject | Rule | Note |", "|---|---|---|"]
    for d in meta["known_deviations"]:
        out.append(f"| `{d['name']}` | {d['rule']} | {d['note']} |")
    out += ["", "## Open findings", ""]
    if not items:
        out.append("None.")
    else:
        out += ["| Rule | Subject | Message |", "|---|---|---|"]
        for f in sorted(items, key=lambda x: (x["rule"], x["subject"])):
            out.append(f"| {f['rule']} | `{f['subject']}` | {f['message']} |")
    return "\n".join(out) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--markdown", action="store_true")
    ap.add_argument("--all", action="store_true", help="also list findings already accepted in the baseline")
    ap.add_argument("--strict", action="store_true", help="ignore the baseline")
    ap.add_argument("--update-baseline", action="store_true")
    ap.add_argument("--output", help="write the report to a file")
    a = ap.parse_args(argv)
    manifest = api_manifest.build()
    meta = json.loads((ROOT / "api" / "meta.json").read_text(encoding="utf-8"))
    items = audit(manifest, meta)
    keys = {f"{f['rule']}:{f['subject']}" for f in items}
    if a.update_baseline:
        baseline_path().write_text(json.dumps({"_comment": "Findings accepted as legacy. Remove an entry once fixed; new findings fail CI.",
                                               "accepted": sorted(keys)}, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"baseline updated: {len(keys)} accepted findings")
        return 0
    accepted = set() if a.strict else load_baseline()
    new = [f for f in items if f"{f['rule']}:{f['subject']}" not in accepted]
    stale = sorted(accepted - keys)
    shown = items if (a.all or a.strict) else new
    if a.markdown:
        text = to_markdown(items, manifest, meta)
    elif a.json:
        text = json.dumps({"findings": shown, "new": len(new), "stale_baseline": stale}, indent=1, ensure_ascii=False)
    else:
        lines = [f"audited {manifest['counts']['builtin']} built-in + {manifest['counts']['source']} source declarations; "
                 f"{len(items)} findings, {len(new)} not in baseline"]
        for f in sorted(shown, key=lambda x: (x["rule"], x["subject"])):
            lines.append(f"  {f['rule']} {f['subject']}: {f['message']}")
        for k in stale:
            lines.append(f"  (baseline entry no longer reported, remove it: {k})")
        text = "\n".join(lines)
    if a.output:
        pathlib.Path(a.output).write_text(text if text.endswith("\n") else text + "\n", encoding="utf-8")
        print(f"wrote {a.output}")
    else:
        print(text)
    return 1 if new else 0


if __name__ == "__main__":
    raise SystemExit(main())
