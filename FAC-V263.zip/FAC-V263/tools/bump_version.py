#!/usr/bin/env python3
"""Increment the canonical FAC release (Vn -> Vn+1) and refresh generated API docs.

VERSION.toml is the release source of truth. Every public component version is
kept equal to it; historical milestone filenames/headings are intentionally not
rewritten. Run `make bump-version` once per delivered release.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

COMPONENT_KEYS = ("core", "lib", "api", "lang", "runtime", "stdlib")
HEADER_MACROS = {
    "core": "FAC_CORE_VERSION",
    "lib": "FAC_LIB_VERSION",
    "api": "FAC_API_VERSION",
    "lang": "FAC_LANG_VERSION",
    "runtime": "FAC_RUNTIME_VERSION",
    "stdlib": "FAC_STDLIB_VERSION",
}


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8", newline="\n")


def replace_once(text: str, pattern: str, replacement: str, label: str) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.M)
    if count != 1:
        raise ValueError(f"could not update {label}: expected exactly one match")
    return updated


def bump(root: Path, refresh_api: bool = True) -> tuple[str, str]:
    manifest_path = root / "VERSION.toml"
    manifest = read(manifest_path)
    match = re.search(r'(?m)^label\s*=\s*"(V[1-9][0-9]*)"\s*$', manifest)
    if not match:
        raise ValueError("VERSION.toml has no valid [release].label")
    current = match.group(1)
    target = f"V{int(current[1:]) + 1}"

    # Fail instead of silently repairing a drifted source tree. This makes the
    # manifest/header relationship explicit before the next release is created.
    for key in COMPONENT_KEYS:
        section = re.search(rf"(?ms)^\[components\]\s*(.*?)(?=^\[|\Z)", manifest)
        value = re.search(rf'(?m)^\s*{re.escape(key)}\s*=\s*"([^"]+)"\s*$', section.group(1)) if section else None
        if not value or value.group(1) != current:
            raise ValueError(f"VERSION.toml components.{key} must equal release label {current}")

    header_path = root / "include/fac/version.h"
    header = read(header_path)
    for key, macro in HEADER_MACROS.items():
        m = re.search(rf'(?m)^#define\s+{macro}\s+"([^"]+)"\s*$', header)
        if not m or m.group(1) != current:
            raise ValueError(f"{macro} in include/fac/version.h must equal {current}")
    for macro in ("FAC_RELEASE_VERSION",):
        m = re.search(rf'(?m)^#define\s+{macro}\s+"([^"]+)"\s*$', header)
        if not m or m.group(1) != current:
            raise ValueError(f"{macro} in include/fac/version.h must equal {current}")

    manifest = replace_once(manifest, r'(?m)^(label\s*=\s*)"' + re.escape(current) + r'"', rf'\1"{target}"', "VERSION.toml release label")
    for key in COMPONENT_KEYS:
        manifest = replace_once(manifest, rf'(?m)^({re.escape(key)}\s*=\s*)"{re.escape(current)}"', rf'\1"{target}"', f"VERSION.toml components.{key}")
    write(manifest_path, manifest)

    for macro in ("FAC_RELEASE_VERSION", *HEADER_MACROS.values()):
        header = replace_once(header, rf'(?m)^(#define\s+{macro}\s+)"{re.escape(current)}"', rf'\1"{target}"', macro)
    write(header_path, header)

    readme_path = root / "README.md"
    readme = read(readme_path)
    readme = replace_once(readme, rf'(?m)^(# Fac \(LLVM\) — compiler ภาษา Fac v[^\n]*· Release ){re.escape(current)}$', rf'\1{target}', "README release title")
    write(readme_path, readme)

    status_path = root / "docs/STATUS.md"
    status = read(status_path)
    status = replace_once(status, rf'(?m)^# FAC {re.escape(current)}$', f"# FAC {target}", "docs/STATUS.md release heading")
    write(status_path, status)

    # Keep current-state memory docs in step with the release while preserving
    # historical milestone sections and filenames.
    memory_model_path = root / "docs/MEMORY_MODEL.md"
    if memory_model_path.exists():
        memory_model = read(memory_model_path)
        memory_model = replace_once(memory_model, rf'(?m)^# FAC Memory, Ownership, Borrowing and Lifetime Model — current {re.escape(current)}',
                                    f"# FAC Memory, Ownership, Borrowing and Lifetime Model — current {target}",
                                    "docs/MEMORY_MODEL.md current release")
        write(memory_model_path, memory_model)
    safe_profile_path = root / "docs/MEMORY_SAFE_PROFILE.md"
    if safe_profile_path.exists():
        safe_profile = read(safe_profile_path)
        safe_profile = replace_once(safe_profile, rf'(?m)^# FAC `--memory-safe` profile — {re.escape(current)}',
                                    f"# FAC `--memory-safe` profile — {target}",
                                    "docs/MEMORY_SAFE_PROFILE.md current release")
        write(safe_profile_path, safe_profile)
    ownership_path = root / "docs/OWNERSHIP.md"
    if ownership_path.exists():
        ownership = read(ownership_path)
        ownership = replace_once(ownership, rf'(?m)^## Current {re.escape(current)} safe-profile policy$',
                                 f"## Current {target} safe-profile policy", "docs/OWNERSHIP.md current release")
        write(ownership_path, ownership)

    standards_path = root / "api/standards.json"
    if standards_path.exists():
        standards = json.loads(read(standards_path))
        if standards.get("release") != current:
            raise ValueError(f"api/standards.json release must equal {current}")
        standards["release"] = target
        for entry in standards.get("gpu", []):
            status = entry.get("status")
            if isinstance(status, str):
                entry["status"] = status.replace(f"paused-not-included-in-{current}", f"paused-not-included-in-{target}")
        write(standards_path, json.dumps(standards, ensure_ascii=False, indent=2) + "\n")

    if refresh_api and (root / "tools/api_manifest.py").exists():
        subprocess.run([sys.executable, str(root / "tools/api_manifest.py")], cwd=root, check=True)
        subprocess.run([sys.executable, str(root / "tools/facdoc.py")], cwd=root, check=True)
        subprocess.run([sys.executable, str(root / "tools/api_audit.py"), "--markdown",
                        "--output", "docs/API_AUDIT.md"], cwd=root, check=True)

    return current, target


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1], help="FAC source root (for tests)")
    parser.add_argument("--no-refresh-api", action="store_true", help="skip generated API manifest/docs refresh")
    args = parser.parse_args()
    try:
        previous, current = bump(args.root.resolve(), refresh_api=not args.no_refresh_api)
    except (OSError, ValueError, subprocess.CalledProcessError, json.JSONDecodeError) as exc:
        print(f"bump-version: ERROR: {exc}", file=sys.stderr)
        return 1
    print(f"bump-version: FAC {previous} -> {current}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
