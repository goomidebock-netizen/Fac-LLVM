#!/usr/bin/env python3
"""fac -- one command for FAC projects (V44): build system + tool launcher.

  fac new NAME [--lib]     create a project (fac.toml, src/, .gitignore)
  fac build [--release|--debug] [--emit-ll] [-- FACC FLAGS]
                           stage sources + dependencies, compile incrementally into build/
  fac run [--release] [-- ARGS]   build, then run
  fac check [--flags ...]  front-end diagnostics for every module (no clang needed)
  fac test [NAME]          build and run tests/*.fac, comparing stdout with tests/*.out (stdin from *.in)
  fac fmt [--check]        format src/ and tests/ with facfmt
  fac doc                  write docs/api.md from the ## documentation of src/ modules
  fac pkg ...              package manager (add, remove, list, tree, verify, lock, pack)
  fac clean | fac lsp | fac debug [--break mod.fn] | fac audit

Profiles: debug = -O0, release = -O2 (default build uses release).  Extra compiler flags come from
[build] flags in fac.toml and after ``--``.  Incremental: a build is skipped when the compiler
version, flags, staged sources and standard library are unchanged (hash in build/.fac/state.json).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
from typing import List, Optional

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import facpkg  # noqa: E402
import fac_diagnostics  # noqa: E402
import facfmt  # noqa: E402

FAC_ROOT = HERE.parent
EXE = ".exe" if os.name == "nt" else ""


def find_project(start: pathlib.Path) -> pathlib.Path:
    for p in [start.resolve()] + list(start.resolve().parents):
        if (p / "fac.toml").exists():
            return p
    raise facpkg.PkgError("no fac.toml found here or in a parent directory (create one with: fac new NAME)")


def compiler(explicit: Optional[str] = None) -> str:
    c = fac_diagnostics.find_compiler(explicit)
    if not c:
        raise facpkg.PkgError("compiler not found: build it with `make` (build/facc) or set FAC_COMPILER")
    return c


def stdlib_hash() -> str:
    h = hashlib.sha256()
    for f in sorted((FAC_ROOT / "stdlib").glob("*.fac")):
        h.update(f.name.encode() + hashlib.sha256(f.read_bytes()).digest())
    return h.hexdigest()


def fingerprint(facc: str, flags: List[str], stage_dir: pathlib.Path, entry: pathlib.Path) -> str:
    h = hashlib.sha256()
    h.update(facpkg.compiler_version(facc).encode())
    h.update(str(pathlib.Path(facc).stat().st_mtime_ns).encode())
    h.update(" ".join(flags).encode() + b"\0" + entry.name.encode())
    for f in sorted(stage_dir.glob("*.fac")):
        h.update(f.name.encode() + hashlib.sha256(f.read_bytes()).digest())
    h.update(stdlib_hash().encode())
    return h.hexdigest()


def profile_flags(profile: str) -> List[str]:
    return ["-O0"] if profile == "debug" else ["-O2"]


def env_for(facc: str) -> dict:
    e = dict(os.environ)
    e.setdefault("FAC_HOME", str(FAC_ROOT))
    return e


def do_build(root: pathlib.Path, profile: str, extra: List[str], emit_ll: bool = False, facc_path: Optional[str] = None,
             entry_override: Optional[pathlib.Path] = None, out_name: Optional[str] = None, quiet: bool = False) -> pathlib.Path:
    res = facpkg.resolve(root)
    facc = compiler(facc_path)
    problems = facpkg.check_compat(res, facc)
    if problems:
        raise facpkg.PkgError("; ".join(problems))
    pkg = res.root
    outdir = root / pkg.out
    stage_dir = outdir / ".fac" / "stage"
    entry = facpkg.stage(res, stage_dir, FAC_ROOT / "stdlib", entry_override)
    flags = profile_flags(profile) + pkg.flags + extra
    name = out_name or pkg.name
    target = outdir / (name + (".ll" if emit_ll else EXE))
    state_file = outdir / ".fac" / f"state-{name}.json"
    fp = fingerprint(facc, flags + (["--emit-ll"] if emit_ll else []), stage_dir, entry)
    if target.exists() and state_file.exists():
        try:
            if json.loads(state_file.read_text(encoding="utf-8")).get("fingerprint") == fp:
                if not quiet:
                    print(f"up to date: {target.relative_to(root)}")
                return target
        except ValueError:
            pass
    outdir.mkdir(parents=True, exist_ok=True)
    cmd = [facc, str(entry), "-o", str(target)] + flags + (["--emit-ll"] if emit_ll else [])
    if not quiet:
        print("compiling " + pkg.name + " " + pkg.version + f" ({profile})")
    r = subprocess.run(cmd, env=env_for(facc))
    if r.returncode != 0:
        raise facpkg.PkgError(f"compiler failed (exit {r.returncode})")
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text(json.dumps({"fingerprint": fp, "flags": flags}), encoding="utf-8")
    if not quiet:
        print(f"built {target.relative_to(root)}")
    return target


def split_dashdash(argv: List[str]):
    if "--" in argv:
        i = argv.index("--")
        return argv[:i], argv[i + 1:]
    return argv, []


# ------------------------------------------------------------------ commands
def cmd_new(a, rest) -> int:
    return facpkg.main(["init", a.name, "--name", pathlib.Path(a.name).name] + (["--lib"] if a.lib else []))


def cmd_build(a, rest) -> int:
    root = find_project(pathlib.Path("."))
    do_build(root, "debug" if a.debug else "release", rest, a.emit_ll, a.compiler)
    return 0


def cmd_run(a, rest) -> int:
    root = find_project(pathlib.Path("."))
    exe = do_build(root, "release" if a.release else "debug", [], False, a.compiler)
    return subprocess.call([str(exe)] + rest)


def cmd_check(a, rest) -> int:
    root = find_project(pathlib.Path("."))
    res = facpkg.resolve(root)
    problems = facpkg.check_compat(res, a.compiler) if fac_diagnostics.find_compiler(a.compiler) else []
    for p in problems:
        print("error: " + p, file=sys.stderr)
    stage_dir = root / res.root.out / ".fac" / "check"
    entry = facpkg.stage(res, stage_dir, FAC_ROOT / "stdlib")
    flags = (a.flags.split() if a.flags else []) + res.root.flags
    errors = len(problems)
    for f in sorted(stage_dir.glob("*.fac")):
        ds = fac_diagnostics.check_file(str(f), a.compiler, flags, use_compiler=(f == entry))
        for d in ds:
            shown = pathlib.Path(d.file).name
            print(f"{shown}:{d.line}:{d.col}: {d.severity}: [{d.source}] {d.message}")
            errors += d.severity == "error"
    if not errors:
        print("no problems found" + ("" if fac_diagnostics.find_compiler(a.compiler) else " (lexical only: compiler not built)"))
    return 1 if errors else 0


def cmd_test(a, rest) -> int:
    root = find_project(pathlib.Path("."))
    tests = sorted((root / "tests").glob("*.fac"))
    if a.name:
        tests = [t for t in tests if a.name in t.stem]
    cases = [t for t in tests if t.with_suffix(".out").exists()]
    if not cases:
        print("no tests found (tests/NAME.fac + tests/NAME.out)")
        return 0
    passed = failed = 0
    for t in cases:
        try:
            exe = do_build(root, "debug", [], False, a.compiler, entry_override=t, out_name="test_" + t.stem, quiet=True)
        except facpkg.PkgError as e:
            print(f"FAIL {t.stem}: {e}")
            failed += 1
            continue
        stdin = t.with_suffix(".in")
        r = subprocess.run([str(exe)], input=stdin.read_bytes() if stdin.exists() else b"", capture_output=True, timeout=120)
        want = t.with_suffix(".out").read_bytes().replace(b"\r\n", b"\n")
        if r.stdout.replace(b"\r\n", b"\n") == want:
            print(f"ok   {t.stem}")
            passed += 1
        else:
            print(f"FAIL {t.stem}: output differs")
            failed += 1
    print(f"{passed} passed, {failed} failed")
    return 1 if failed else 0


def cmd_fmt(a, rest) -> int:
    root = find_project(pathlib.Path("."))
    args = [str(root / d) for d in ("src", "tests") if (root / d).is_dir()]
    return facfmt.main((["--check"] if a.check else []) + args)


def cmd_doc(a, rest) -> int:
    import facdoc
    root = find_project(pathlib.Path("."))
    out = root / "docs" / "api.md"
    out.parent.mkdir(exist_ok=True)
    out.write_text(facdoc.project_markdown(root), encoding="utf-8")
    print(f"wrote {out.relative_to(root)}")
    return 0


def cmd_clean(a, rest) -> int:
    root = find_project(pathlib.Path("."))
    pkg = facpkg.load_package(root)
    shutil.rmtree(root / pkg.out, ignore_errors=True)
    print(f"removed {pkg.out}/")
    return 0


def main(argv=None) -> int:
    argv, rest = split_dashdash(list(sys.argv[1:] if argv is None else argv))
    ap = argparse.ArgumentParser(prog="fac", description=__doc__.split("\n")[0])
    ap.add_argument("--compiler", help="path to facc (default: build/facc)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("new")
    p.add_argument("name")
    p.add_argument("--lib", action="store_true")
    p = sub.add_parser("build")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--release", action="store_true")
    p.add_argument("--emit-ll", action="store_true")
    p = sub.add_parser("run")
    p.add_argument("--release", action="store_true")
    p = sub.add_parser("check")
    p.add_argument("--flags", default="")
    p = sub.add_parser("test")
    p.add_argument("name", nargs="?")
    p = sub.add_parser("fmt")
    p.add_argument("--check", action="store_true")
    sub.add_parser("doc")
    sub.add_parser("clean")
    sub.add_parser("pkg")
    sub.add_parser("lsp")
    sub.add_parser("debug")
    sub.add_parser("audit")
    a, unknown = ap.parse_known_args(argv)
    try:
        if a.cmd == "pkg":
            return facpkg.main(unknown + rest)
        if a.cmd == "lsp":
            import fac_lsp
            return fac_lsp.serve(facc=a.compiler)
        if a.cmd == "debug":
            import fac_debug
            return fac_debug.main(unknown + rest)
        if a.cmd == "audit":
            import api_audit
            return api_audit.main(unknown + rest)
        fn = {"new": cmd_new, "build": cmd_build, "run": cmd_run, "check": cmd_check, "test": cmd_test,
              "fmt": cmd_fmt, "doc": cmd_doc, "clean": cmd_clean}[a.cmd]
        return fn(a, rest)
    except facpkg.PkgError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
