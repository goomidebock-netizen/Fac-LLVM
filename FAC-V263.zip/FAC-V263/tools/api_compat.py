#!/usr/bin/env python3
"""FAC API compatibility checker (V44).

Compares the current API manifest with a released baseline snapshot (api/baseline/current.json)
and classifies every difference according to docs/COMPATIBILITY.md:

  BREAKING   a public name disappeared, its parameter/return types changed, its ownership
             contract changed, or it was removed before its deprecation window ended
  WARNING    error-model / error-code changes, newly deprecated names (additive but visible)
  ADDED      new public names (always allowed in a minor/patch release)

usage:
  api_compat.py check    [--baseline api/baseline/current.json] [--strict] [--json]
  api_compat.py snapshot [--output api/baseline/current.json] [--from-manifest FILE]
Exit status 1 when BREAKING changes exist (or WARNING with --strict).
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import api_manifest  # noqa: E402


def release_no(label: str) -> int:
    m = re.match(r"V(\d+)", label or "")
    return int(m.group(1)) if m else 0


def param_types(params: str) -> list:
    out, depth, cur = [], 0, ""
    for ch in params:
        if ch in "(<[":
            depth += 1
        elif ch in ")>]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    res = []
    for p in out:
        w = p.split()
        res.append(" ".join(w[:-1]) if len(w) > 1 else " ".join(w))
    return res


def snapshot(manifest: dict) -> dict:
    b = {}
    for e in manifest["builtin"]:
        b[e["name"]] = {
            "kind": e["kind"],
            "sig": sorted(json.dumps([o.get("params", o.get("params_text", "")), o["returns"]], sort_keys=True)
                          for o in e["overloads"]),
            "ownership": e.get("ownership"),
            "errors": {"model": e["errors"]["model"], "codes": e["errors"].get("codes", [])},
            "status": e["status"],
            "remove_not_before": e.get("remove_not_before"),
            "alias_of": e.get("alias_of"),
        }
    s = {}
    for e in manifest["source"]:
        s[e["name"]] = {"kind": e["kind"], "sig": [param_types(e.get("params", "")), re.sub(r"\s+", " ", e.get("returns", ""))]
                        if e["kind"] == "source-function" else []}
    return {"release": manifest["release"], "compiler": manifest["compiler"], "builtin": b, "source": s}


def compare(base: dict, cur: dict, current_release: str) -> list:
    out = []
    cur_no = release_no(current_release)
    for section in ("builtin", "source"):
        for name, old in sorted(base[section].items()):
            new = cur[section].get(name)
            if new is None:
                nb = old.get("remove_not_before") if section == "builtin" else None
                if nb and release_no(nb) <= cur_no:
                    out.append(("WARNING", name, f"removed after its deprecation window (was remove-not-before {nb})"))
                elif old.get("status") == "deprecated" and not nb:
                    out.append(("BREAKING", name, "removed without a recorded deprecation window"))
                else:
                    out.append(("BREAKING", name, "removed" + (f" before its window ended ({nb})" if nb else "")))
                continue
            if old["kind"] != new["kind"]:
                out.append(("BREAKING", name, f"kind changed {old['kind']} -> {new['kind']}"))
            if old["sig"] != new["sig"]:
                out.append(("BREAKING", name, f"signature changed {old['sig']} -> {new['sig']}"))
            if section == "builtin":
                if old["ownership"] != new["ownership"]:
                    out.append(("BREAKING", name, "ownership contract changed"))
                if old["errors"] != new["errors"]:
                    out.append(("WARNING", name, f"error contract changed {old['errors']} -> {new['errors']}"))
                if old["status"] != new["status"] and new["status"] == "deprecated":
                    out.append(("WARNING", name, f"newly deprecated (replacement: {new.get('alias_of')}, not removable before {new.get('remove_not_before')})"))
        for name in sorted(set(cur[section]) - set(base[section])):
            out.append(("ADDED", name, "new public name"))
    # policy: every deprecated entry needs a window of at least 3 releases from the baseline
    for name, e in cur["builtin"].items():
        if e["status"] == "deprecated":
            nb = e.get("remove_not_before")
            if not nb:
                out.append(("BREAKING", name, "deprecated without remove_not_before"))
            elif release_no(nb) - release_no(base["release"]) < 3 and name not in base["builtin"]:
                out.append(("BREAKING", name, f"deprecation window shorter than 3 releases ({nb})"))
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check")
    c.add_argument("--baseline", default=None)
    c.add_argument("--strict", action="store_true")
    c.add_argument("--json", action="store_true")
    s = sub.add_parser("snapshot")
    s.add_argument("--output", default=None)
    s.add_argument("--from-manifest", default=None)
    a = ap.parse_args(argv)
    manifest = (json.loads(pathlib.Path(a.from_manifest).read_text(encoding="utf-8")) if getattr(a, "from_manifest", None)
                else api_manifest.build())
    if a.cmd == "snapshot":
        snap = snapshot(manifest)
        out = pathlib.Path(a.output) if a.output else ROOT / "api" / "baseline" / "current.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(snap, indent=1, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
        print(f"wrote {out} ({len(snap['builtin'])} built-in, {len(snap['source'])} source names)")
        return 0
    base_path = pathlib.Path(a.baseline) if a.baseline else ROOT / "api" / "baseline" / "current.json"
    base = json.loads(base_path.read_text(encoding="utf-8"))
    cur = snapshot(manifest)
    diffs = compare(base, cur, manifest["release"])
    if a.json:
        print(json.dumps([{"level": l, "name": n, "message": m} for l, n, m in diffs], indent=1, ensure_ascii=False))
    else:
        print(f"compatibility of {manifest['release']} against {base['release']} ({base_path.name})")
        for level in ("BREAKING", "WARNING", "ADDED"):
            items = [d for d in diffs if d[0] == level]
            print(f"  {level}: {len(items)}")
            for _, n, m in items:
                print(f"    {n}: {m}")
    bad = any(d[0] == "BREAKING" for d in diffs) or (a.strict and any(d[0] == "WARNING" for d in diffs))
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
