#!/usr/bin/env python3
"""FAC code diagnostics (V44): lexical checks + the real compiler front-end.

Two layers, merged into one list:

  1. lexical   facsrc (same rules as the compiler lexer): unterminated strings/comments, bad escapes,
               unknown characters, unbalanced brackets.  Needs nothing installed; works on unsaved text.
  2. compiler  runs ``facc FILE --emit-ll`` (parse + type-check + IR generation, no clang needed) and
               converts its ``file:line: message`` output into structured diagnostics, including errors
               found in imported modules.

usage: fac_diagnostics.py [--facc PATH] [--no-compiler] [--flags "--safe ..."] [--json] FILE.fac...
Exit status: 1 when an error was found, 0 otherwise.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, asdict
from typing import List, Optional

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import facsrc  # noqa: E402


@dataclass
class Diag:
    file: str
    line: int          # 1-based
    col: int           # 1-based
    severity: str      # error | warning
    source: str        # lexical | compiler
    message: str


_MSG = re.compile(r"^(?P<file>.+?):(?P<line>\d+):\s*(?:(?P<sev>error|warning|note):\s*)?(?P<msg>.*)$")


def lexical(path: str, text: str) -> List[Diag]:
    return [Diag(path, i.line, i.col + 1, "error", "lexical", i.message) for i in facsrc.diagnose(text)]


def find_compiler(explicit: Optional[str] = None) -> Optional[str]:
    cands = [explicit, os.environ.get("FAC_COMPILER"), str(ROOT / "build" / "facc"),
             str(ROOT / "build" / "facc.exe"), shutil.which("facc")]
    for c in cands:
        if c and pathlib.Path(c).exists():
            return c
    return None


def parse_compiler_output(text: str, default_file: str) -> List[Diag]:
    out: List[Diag] = []
    for raw in text.splitlines():
        raw = raw.rstrip()
        if not raw or raw.startswith("facc:"):
            continue
        m = _MSG.match(raw)
        if not m:
            if out and raw.startswith((" ", "\t")):
                out[-1].message += " " + raw.strip()      # continuation line of the previous message
            else:
                out.append(Diag(default_file, 1, 1, "error", "compiler", raw))
            continue
        msg = m.group("msg")
        again = _MSG.match(msg)          # Loader prefixes "path:line: " twice for imported files
        f, ln = m.group("file"), int(m.group("line"))
        if again and again.group("file") == f:
            msg = again.group("msg")
            msg = re.sub(r"^(error|warning):\s*", "", msg)
        sev = m.group("sev") or "error"
        if sev == "note":
            continue
        out.append(Diag(f, ln, 1, sev, "compiler", msg))
    return out


def compiler_check(path: str, facc: Optional[str] = None, flags: Optional[List[str]] = None,
                   text: Optional[str] = None, timeout: int = 60) -> List[Diag]:
    exe = find_compiler(facc)
    if not exe:
        return []
    env = dict(os.environ)
    env.setdefault("FAC_HOME", str(ROOT))
    target = path
    tmp = None
    try:
        if text is not None:
            # unsaved buffer: check a copy placed next to the file so relative imports still resolve
            d = pathlib.Path(path).resolve().parent
            tmp = tempfile.NamedTemporaryFile("w", suffix=".fac", prefix=".facdiag_", dir=d, delete=False, encoding="utf-8")
            tmp.write(text)
            tmp.close()
            target = tmp.name
        with tempfile.TemporaryDirectory(prefix="fac-diag-") as td:
            r = subprocess.run([exe, target, "--emit-ll", "-o", os.path.join(td, "out.ll")] + (flags or []),
                               capture_output=True, text=True, timeout=timeout, env=env)
        diags = parse_compiler_output(r.stderr, path) if r.returncode != 0 or r.stderr.strip() else []
        if tmp:
            tn = pathlib.Path(tmp.name).name
            for d in diags:
                if pathlib.Path(d.file).name == tn:
                    d.file = path
        return diags
    except (subprocess.TimeoutExpired, OSError) as e:
        return [Diag(path, 1, 1, "warning", "compiler", f"compiler check skipped: {e}")]
    finally:
        if tmp:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass


def check_file(path: str, facc: Optional[str] = None, flags: Optional[List[str]] = None,
               use_compiler: bool = True, text: Optional[str] = None) -> List[Diag]:
    src = text if text is not None else pathlib.Path(path).read_text(encoding="utf-8", errors="replace")
    diags = lexical(path, src)
    if use_compiler and not any(d.severity == "error" for d in diags):
        diags += compiler_check(path, facc, flags, text)
    return diags


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("files", nargs="+")
    ap.add_argument("--facc")
    ap.add_argument("--no-compiler", action="store_true", help="lexical checks only")
    ap.add_argument("--flags", default="", help="extra facc flags, e.g. '--safe --strict-move'")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    flags = a.flags.split() if a.flags else []
    allds: List[Diag] = []
    for f in a.files:
        allds += check_file(f, a.facc, flags, not a.no_compiler)
    if a.json:
        print(json.dumps([asdict(d) for d in allds], indent=1, ensure_ascii=False))
    else:
        for d in allds:
            print(f"{d.file}:{d.line}:{d.col}: {d.severity}: [{d.source}] {d.message}")
        if not allds:
            print("no problems found" + ("" if (not a.no_compiler and find_compiler(a.facc)) else
                                         " (lexical only: build/facc not found)" if not a.no_compiler else " (lexical only)"))
    return 1 if any(d.severity == "error" for d in allds) else 0


if __name__ == "__main__":
    raise SystemExit(main())
