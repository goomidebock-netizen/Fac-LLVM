#!/usr/bin/env python3
"""Generate explicit FAC binary serializers for simple struct declarations.

The generator never serializes native memory layouts. It emits ordinary FAC
functions backed by serialize.BinaryWriter / deserialize.BinaryReader.
Nested structs are encoded as independent FACB v2 byte fields, so each nested
value has its own schema id, version and CRC32. Only a deliberately narrow set
of field types is accepted; unsupported fields fail generation instead of
being silently omitted.
"""
from __future__ import annotations

import argparse
import dataclasses
import pathlib
import re
import sys
from typing import Iterable


@dataclasses.dataclass(frozen=True)
class Field:
    name: str
    kind: str
    target: str = ""
    since: int = 1
    default: str | None = None
    rename_from: str = ""
    rename_since: int = 1
    convert_from: str = ""
    convert_since: int = 1


@dataclasses.dataclass(frozen=True)
class Migration:
    from_version: int
    function: str


@dataclasses.dataclass(frozen=True)
class StructDef:
    name: str
    fields: tuple[Field, ...]
    line: int
    migrations: tuple[Migration, ...] = ()


class SerdeError(ValueError):
    pass


IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
STRUCT_HEAD = re.compile(r"^\s*(?:(public|private|protected)\s+)?struct\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{\s*$")
FIELD_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"^(?:public\s+)?var\s+byte\s+([A-Za-z_]\w*)$"), "byte"),
    (re.compile(r"^(?:public\s+)?var\s+boolean\s+([A-Za-z_]\w*)$"), "boolean"),
    (re.compile(r"^(?:public\s+)?var\s+int\s+([A-Za-z_]\w*)$"), "i32"),
    (re.compile(r"^(?:public\s+)?var\s+long\s+([A-Za-z_]\w*)$"), "i64"),
    (re.compile(r"^(?:public\s+)?var\s+float\s+([A-Za-z_]\w*)$"), "f32"),
    (re.compile(r"^(?:public\s+)?var\s+double\s+([A-Za-z_]\w*)$"), "f64"),
    (re.compile(r"^(?:public\s+)?(?:dyn\s+)?string\s+([A-Za-z_]\w*)$"), "string"),
    (re.compile(r"^(?:public\s+)?list\s+var\s+int\s+([A-Za-z_]\w*)$"), "i32list"),
    (re.compile(r"^(?:public\s+)?list\s+dyn\s+string\s+([A-Za-z_]\w*)$"), "stringlist"),
    (re.compile(r"^(?:public\s+)?hashmap\s+dyn\s+string\s*,\s*string\s+([A-Za-z_]\w*)$"), "stringmap"),
)


def _strip_comment(line: str) -> str:
    # FAC declaration syntax uses # line comments. The supported field grammar
    # does not place # inside declaration string literals.
    return line.split("#", 1)[0].strip()


def _parse_key_values(raw: str, marker: str) -> dict[str, str] | None:
    if marker not in raw:
        return None
    prefix = raw.find(marker) + len(marker)
    tail = raw[prefix:]
    token = re.compile(r'([A-Za-z][A-Za-z0-9]*)=("(?:\\.|[^"\\])*"|[^\s]+)')
    attrs: dict[str, str] = {}
    pos = 0
    for match in token.finditer(tail):
        if tail[pos:match.start()].strip():
            raise SerdeError(f"malformed {marker.strip()} annotation")
        key, value = match.groups()
        if key in attrs:
            raise SerdeError(f"duplicate {key}= in {marker.strip()} annotation")
        attrs[key] = value
        pos = match.end()
    if tail[pos:].strip() or not attrs:
        raise SerdeError(f"malformed {marker.strip()} annotation")
    return attrs


def _parse_serde_annotation(raw: str) -> dict[str, str] | None:
    attrs = _parse_key_values(raw, "# @serde ")
    if attrs is None:
        return None
    allowed = {"since", "default", "renameFrom", "renameSince", "convertFrom", "convertSince"}
    unknown = set(attrs) - allowed
    if unknown:
        raise SerdeError(f"unknown @serde attribute(s): {', '.join(sorted(unknown))}")
    if "since" not in attrs or "default" not in attrs:
        raise SerdeError("malformed @serde annotation; expected '# @serde since=N default=VALUE'")
    try:
        since = int(attrs["since"])
    except ValueError as exc:
        raise SerdeError("@serde since must be an integer") from exc
    if not 1 <= since <= 65535:
        raise SerdeError("@serde since must be in [1,65535]")
    attrs["since"] = str(since)
    for key in ("renameSince", "convertSince"):
        if key in attrs:
            try:
                value = int(attrs[key])
            except ValueError as exc:
                raise SerdeError(f"@serde {key} must be an integer") from exc
            if not 1 <= value <= 65535:
                raise SerdeError(f"@serde {key} must be in [1,65535]")
            attrs[key] = str(value)
    if ("renameFrom" in attrs) != ("renameSince" in attrs):
        raise SerdeError("renameFrom and renameSince must be supplied together")
    if ("convertFrom" in attrs) != ("convertSince" in attrs):
        raise SerdeError("convertFrom and convertSince must be supplied together")
    return attrs


def _parse_migration_annotation(raw: str) -> dict[str, str] | None:
    attrs = _parse_key_values(raw, "# @serde-migrate ")
    if attrs is None:
        return None
    if set(attrs) != {"struct", "from", "function"}:
        raise SerdeError("@serde-migrate expects exactly struct=TYPE from=VERSION function=NAME")
    if not IDENT.fullmatch(attrs["struct"]) or not IDENT.fullmatch(attrs["function"]):
        raise SerdeError("@serde-migrate struct and function must be valid identifiers")
    try:
        version = int(attrs["from"])
    except ValueError as exc:
        raise SerdeError("@serde-migrate from must be an integer") from exc
    if not 1 <= version <= 65534:
        raise SerdeError("@serde-migrate from must be in [1,65534]")
    attrs["from"] = str(version)
    return attrs


def parse_structs(source: str) -> list[StructDef]:
    lines = source.splitlines()
    structs: list[StructDef] = []
    migrations: dict[str, list[Migration]] = {}
    current_name: str | None = None
    current_line = 0
    fields: list[Field] = []
    method_depth = 0
    pending_annotation: dict[str, str] | None = None

    for line_no, raw in enumerate(lines, 1):
        migration = _parse_migration_annotation(raw)
        if migration is not None:
            if current_name is not None or pending_annotation is not None:
                raise SerdeError(f"line {line_no}: @serde-migrate must be declared outside a struct")
            item = Migration(int(migration["from"]), migration["function"])
            entries = migrations.setdefault(migration["struct"], [])
            if any(existing.from_version == item.from_version for existing in entries):
                raise SerdeError(f"line {line_no}: duplicate migration from version {item.from_version} for {migration['struct']}")
            entries.append(item)
            continue

        annotation = _parse_serde_annotation(raw)
        if annotation is not None:
            if pending_annotation is not None:
                raise SerdeError(f"line {line_no}: duplicate @serde annotation before a field")
            if current_name is None:
                raise SerdeError(f"line {line_no}: @serde annotation must appear inside a struct")
            pending_annotation = annotation
            continue

        line = _strip_comment(raw)
        if not line:
            continue
        if current_name is None:
            match = STRUCT_HEAD.match(line)
            if match:
                visibility, current_name = match.groups()
                if visibility in ("private", "protected"):
                    raise SerdeError(f"line {line_no}: {visibility} struct {current_name} cannot be serialized by external generated helpers")
                if any(s.name == current_name for s in structs):
                    raise SerdeError(f"line {line_no}: duplicate struct {current_name}")
                current_line = line_no
                fields = []
            elif pending_annotation is not None:
                raise SerdeError(f"line {line_no}: @serde annotation is not attached to a struct field")
            continue

        if method_depth:
            if pending_annotation is not None:
                raise SerdeError(f"line {line_no}: @serde annotation cannot target a method")
            method_depth += line.count("{") - line.count("}")
            if method_depth < 0:
                raise SerdeError(f"line {line_no}: unmatched closing brace in struct {current_name}")
            continue

        if line.startswith("}"):
            if pending_annotation is not None:
                raise SerdeError(f"line {line_no}: @serde annotation is not followed by a field")
            if line != "}":
                raise SerdeError(f"line {line_no}: unsupported trailing tokens after struct closing brace")
            if not fields:
                raise SerdeError(f"line {current_line}: struct {current_name} has no serializable fields")
            structs.append(StructDef(current_name, tuple(fields), current_line, tuple(sorted(migrations.pop(current_name, []), key=lambda m: m.from_version))))
            current_name = None
            continue

        if re.match(r"^(?:(?:public|private|protected)\s+)?(?:public\s+)?(?:function|constructor)\b", line):
            if pending_annotation is not None:
                raise SerdeError(f"line {line_no}: @serde annotation cannot target a method")
            if re.search(r"\bconstructor\b", line):
                raise SerdeError(f"line {line_no}: explicit constructors are not supported; generated decoder uses the field-order constructor")
            method_depth = line.count("{") - line.count("}")
            if method_depth < 0:
                raise SerdeError(f"line {line_no}: malformed method body")
            continue

        if re.match(r"^(?:private|protected)\s+", line):
            raise SerdeError(f"line {line_no}: private/protected fields cannot be accessed by generated helpers")

        attrs = pending_annotation or {}
        pending_annotation = None
        since = int(attrs.get("since", "1"))
        default = attrs.get("default")
        rename_from = attrs.get("renameFrom", "")
        rename_since = int(attrs.get("renameSince", "1"))
        convert_from = attrs.get("convertFrom", "")
        convert_since = int(attrs.get("convertSince", "1"))
        nested = re.fullmatch(r"(?:public\s+)?struct\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*)", line)
        if nested:
            target, name = nested.groups()
            field = Field(name, "nested", target, since, default, rename_from, rename_since, convert_from, convert_since)
        else:
            field = None
            for pattern, kind in FIELD_PATTERNS:
                match = pattern.fullmatch(line)
                if match:
                    field = Field(match.group(1), kind, "", since, default, rename_from, rename_since, convert_from, convert_since)
                    break
        if field is None:
            raise SerdeError(f"line {line_no}: unsupported struct member declaration: {line!r}")
        if any(f.name == field.name for f in fields):
            raise SerdeError(f"line {line_no}: duplicate field {field.name} in struct {current_name}")
        if fields and field.since < fields[-1].since:
            raise SerdeError(f"line {line_no}: fields must be appended in nondecreasing @serde since order")
        if field.rename_from and not IDENT.fullmatch(field.rename_from):
            raise SerdeError(f"line {line_no}: renameFrom must be a valid field identifier")
        fields.append(field)

    if pending_annotation is not None:
        raise SerdeError("@serde annotation is not followed by a field")
    if current_name is not None:
        raise SerdeError(f"line {current_line}: struct {current_name} is not closed")
    if migrations:
        unknown = ", ".join(sorted(migrations))
        raise SerdeError(f"@serde-migrate refers to unknown struct(s): {unknown}")
    if not structs:
        raise SerdeError("no supported struct declarations found")

    names = {s.name for s in structs}
    for s in structs:
        for f in s.fields:
            if f.kind == "nested" and f.target not in names:
                raise SerdeError(f"struct {s.name}.{f.name} references unknown struct {f.target}")
    _check_acyclic(structs)
    return structs

def _check_acyclic(structs: Iterable[StructDef]) -> None:
    by_name = {s.name: s for s in structs}
    visiting: list[str] = []
    done: set[str] = set()

    def visit(name: str) -> None:
        if name in done:
            return
        if name in visiting:
            cycle = " -> ".join(visiting[visiting.index(name):] + [name])
            raise SerdeError(f"recursive struct graph is unsupported: {cycle}")
        visiting.append(name)
        for f in by_name[name].fields:
            if f.kind == "nested":
                visit(f.target)
        visiting.pop()
        done.add(name)

    for name in by_name:
        visit(name)


def _imports_insert(source: str) -> str:
    lines = source.splitlines()
    insert_at = 0
    # Keep a module declaration and leading imports before generated code.
    for i, raw in enumerate(lines):
        line = _strip_comment(raw)
        if not line or line.startswith("module ") or line.startswith("import "):
            insert_at = i + 1
            continue
        break
    existing = {m.group(1).removesuffix(".fac") for line in lines for m in [re.match(r"\s*import\s+([A-Za-z0-9_.]+)", line)] if m}
    adds = [f"import {name}.fac" for name in ("serialize", "deserialize") if name not in existing]
    if not adds:
        return source
    lines[insert_at:insert_at] = adds
    return "\n".join(lines) + ("\n" if source.endswith("\n") else "")


def _encode_field(writer: str, struct_name: str, field: Field) -> str:
    n = field.name
    if field.kind == "nested":
        return f'{writer}.writeFieldBytes("{n}", fac_encode_{field.target}(value.{n}))'
    methods = {
        "byte": "Byte", "boolean": "Boolean", "i32": "I32", "i64": "I64",
        "f32": "F32", "f64": "F64", "string": "String", "i32list": "I32List",
        "stringlist": "StringList", "stringmap": "StringMap",
    }
    return f'{writer}.writeField{methods[field.kind]}("{n}", value.{n})'


def _decode_expr(reader: str, field: Field) -> str:
    n = field.name
    if field.kind == "nested":
        return f'fac_decode_{field.target}({reader}.readFieldBytes("{n}"))'
    methods = {
        "byte": "Byte", "boolean": "Boolean", "i32": "I32", "i64": "I64",
        "f32": "F32", "f64": "F64", "string": "String", "i32list": "I32List",
        "stringlist": "StringList", "stringmap": "StringMap",
    }
    return f'{reader}.readField{methods[field.kind]}("{n}")'


def _default_expression(field: Field) -> str:
    """Validate and return a deliberately small, safe FAC literal default."""
    raw = field.default
    if raw is None:
        if field.since > 1:
            raise SerdeError(f"field {field.name}: fields introduced after schema version 1 need an explicit default")
        return ""
    if field.kind == "boolean":
        if raw not in ("true", "false"):
            raise SerdeError(f"field {field.name}: boolean default must be true or false")
        return raw
    if field.kind in ("byte", "i32", "i64"):
        if not re.fullmatch(r"-?(?:0|[1-9][0-9]*)", raw):
            raise SerdeError(f"field {field.name}: integer default must be a decimal integer literal")
        value = int(raw)
        lo, hi = {"byte": (0, 255), "i32": (-(2**31), 2**31 - 1), "i64": (-(2**63), 2**63 - 1)}[field.kind]
        if not lo <= value <= hi:
            raise SerdeError(f"field {field.name}: default is outside the {field.kind} range")
        return raw
    if field.kind in ("f32", "f64"):
        if not re.fullmatch(r"-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?", raw):
            raise SerdeError(f"field {field.name}: floating default must be a finite decimal literal")
        try:
            import math
            value = float(raw)
        except ValueError as exc:
            raise SerdeError(f"field {field.name}: invalid floating default") from exc
        if not math.isfinite(value):
            raise SerdeError(f"field {field.name}: floating default must be finite")
        return f"cast(Float, {raw})" if field.kind == "f32" else raw
    if field.kind == "string":
        if not re.fullmatch(r'"(?:[A-Za-z0-9 _.,:;!@#$%^&*()+=?\-/]|\\["\\nrt])*"', raw):
            raise SerdeError(f"field {field.name}: string default must be a quoted, simple FAC string literal")
        return raw
    raise SerdeError(f"field {field.name}: optional defaults are currently supported only for scalar fields")


def _local_type(field: Field) -> str:
    return {
        "byte": "var byte", "boolean": "var boolean", "i32": "var int", "i64": "var long",
        "f32": "var float", "f64": "var double", "string": "dyn string",
        "i32list": "list dyn int", "stringlist": "list dyn string",
        "stringmap": "hashmap dyn string, string", "nested": f"struct {field.target}",
    }[field.kind]


def _read_method(field: Field) -> str:
    if field.kind == "nested":
        return f'fac_decode_{field.target}(reader.readFieldBytes("{field.name}"))'
    methods = {
        "byte": "Byte", "boolean": "Boolean", "i32": "I32", "i64": "I64",
        "f32": "F32", "f64": "F64", "string": "String", "i32list": "I32List",
        "stringlist": "StringList", "stringmap": "StringMap",
    }
    return f'reader.readField{methods[field.kind]}("{field.name}")'


def _legacy_name(field: Field, schema_version: str = "schemaVersion") -> tuple[list[str], str]:
    if not field.rename_from:
        return [], f'"{field.name}"'
    local = f"_facserde_wire_{field.name}"
    lines = [f'dyn string {local} = "{field.name}"',
             f'if ({schema_version} < {field.rename_since}) {{ {local} = "{field.rename_from}" }}']
    return lines, local


def _current_write_method(field: Field) -> str:
    return {
        "byte": "Byte", "boolean": "Boolean", "i32": "I32", "i64": "I64",
        "f32": "F32", "f64": "F64", "string": "String", "i32list": "I32List",
        "stringlist": "StringList", "stringmap": "StringMap",
    }.get(field.kind, "Bytes")


def _legacy_write_method(field: Field) -> str:
    return "I32" if field.convert_from == "i32" else "I64"


def _legacy_read_method(field: Field) -> str:
    return "I64FromI32" if field.convert_from == "i32" else "I32FromI64"


def _validate_evolution(source: str, structs: list[StructDef], version: int) -> None:
    by_name = {s.name: s for s in structs}
    for struct in structs:
        aliases: set[str] = set()
        for field in struct.fields:
            if field.since > version:
                raise SerdeError(f"struct {struct.name}.{field.name}: @serde since={field.since} exceeds current --version={version}")
            _default_expression(field)
            if field.since > 1 and field.kind == "nested":
                raise SerdeError(f"struct {struct.name}.{field.name}: optional nested Struct fields are not supported yet")
            if (field.rename_from or field.convert_from) and field.default is None:
                raise SerdeError(f"struct {struct.name}.{field.name}: renamed/converted fields must declare default=VALUE")
            if field.rename_from:
                if field.rename_from == field.name:
                    raise SerdeError(f"struct {struct.name}.{field.name}: renameFrom must differ from the current field name")
                if field.rename_since <= field.since:
                    raise SerdeError(f"struct {struct.name}.{field.name}: renameSince must be later than since")
                if field.rename_since > version:
                    raise SerdeError(f"struct {struct.name}.{field.name}: renameSince exceeds current --version")
                if field.rename_from in aliases or any(other.name == field.rename_from for other in struct.fields):
                    raise SerdeError(f"struct {struct.name}.{field.name}: renameFrom collides with another field or alias")
                aliases.add(field.rename_from)
            if field.convert_from:
                allowed = (field.kind, field.convert_from) in (("i64", "i32"), ("i32", "i64"))
                if not allowed:
                    raise SerdeError(f"struct {struct.name}.{field.name}: only checked i32<->i64 field migrations are supported")
                if field.convert_since <= field.since:
                    raise SerdeError(f"struct {struct.name}.{field.name}: convertSince must be later than since")
                if field.convert_since > version:
                    raise SerdeError(f"struct {struct.name}.{field.name}: convertSince exceeds current --version")
        for migration in struct.migrations:
            if migration.from_version >= version:
                raise SerdeError(f"struct {struct.name}: migration from={migration.from_version} must be older than current --version={version}")
            signature = re.compile(
                rf"(?m)^\s*(?:public\s+)?function\s+struct\s+{re.escape(struct.name)}\s+{re.escape(migration.function)}\s*\(\s*struct\s+{re.escape(struct.name)}\s+[A-Za-z_]\w*\s*\)\s*\{{"
            )
            if not signature.search(source):
                raise SerdeError(f"struct {struct.name}: migration function {migration.function} must accept and return struct {struct.name}")


def generate(source: str, structs: list[StructDef], schema_prefix: str, version: int) -> str:
    if not schema_prefix or not all(IDENT.fullmatch(part) for part in schema_prefix.split(".")):
        raise SerdeError("schema prefix must be an identifier or dotted identifier with no empty segments")
    if not 1 <= version <= 65535:
        raise SerdeError("schema version must be in [1,65535]")
    _validate_evolution(source, structs, version)
    out = [_imports_insert(source).rstrip(), "", "# Generated by tools/facserde.py. Do not edit generated helpers by hand."]
    for s in structs:
        schema_id = f"{schema_prefix}.{s.name}"
        if len(schema_id.encode("utf-8")) > 128:
            raise SerdeError(f"schema id for {s.name} exceeds 128 UTF-8 bytes")
        out += [
            "",
            f"## @returns Encodes {s.name} as FACB v2; schema fields are appended by version and renamed/converted fields retain their historical wire representation.",
            "## @ownership value=by value; result=owned byte list.",
            "## @errors Throws Encoding (13) for unsupported schema versions or field values; IntegerOverflow (17) for lossy legacy narrowing; Resource (8) for stream limits.",
            "## @thread-safety Not thread-safe; use one writer per call.",
            f"public function list dyn int fac_encode_{s.name}(struct {s.name} value, int schemaVersion = {version}) {{",
            f'    if (schemaVersion < 1 || schemaVersion > {version}) {{ throw Error("Unsupported {s.name} encoder schema version", 13) }}',
            "    obj serialize.BinaryWriter writer = new serialize.BinaryWriter()",
            f'    writer.beginV2("{schema_id}", schemaVersion)',
            "    var int fieldCount = 0",
        ]
        for f in s.fields:
            out.append(f"    if (schemaVersion >= {f.since}) {{ fieldCount++ }}")
        out.append(f'    writer.beginRecord("{s.name}", fieldCount)')
        for f in s.fields:
            name_lines, wire_name = _legacy_name(f)
            out.append(f"    if (schemaVersion >= {f.since}) {{")
            for line in name_lines:
                out.append("        " + line)
            if f.convert_from:
                out.append(f"        if (schemaVersion < {f.convert_since}) {{")
                out.append(f'            writer.writeField{_legacy_write_method(f)}({wire_name}, value.{f.name})')
                out.append("        } else {")
                out.append(f'            writer.writeField{_current_write_method(f)}({wire_name}, value.{f.name})')
                out.append("        }")
            else:
                if f.kind == "nested":
                    call = f'writer.writeFieldBytes({wire_name}, fac_encode_{f.target}(value.{f.name}, schemaVersion))'
                else:
                    call = f'writer.writeField{_current_write_method(f)}({wire_name}, value.{f.name})'
                out.append(f"        {call}")
            out.append("    }")
        out += [
            "    writer.endRecord()",
            "    return writer.toBytes()",
            "}",
            "",
            f"## @returns Decodes {s.name}; applies defaults, checked numeric conversions, field renames and declared migration hooks.",
            "## @ownership encoded=borrowed; result=owned struct value.",
            "## @errors Throws Encoding (13) for malformed/incompatible fields; IntegerOverflow (17) for narrowing; Resource (8) for excessive input.",
            "## @thread-safety Not thread-safe; use one reader per call.",
            f"public function struct {s.name} fac_decode_{s.name}(list dyn int encoded) {{",
            "    obj deserialize.BinaryReader reader = new deserialize.BinaryReader(encoded)",
            f'    var int schemaVersion = reader.readHeaderV2("{schema_id}", 1, 65535)',
            f'    var int fieldCount = reader.beginRecord("{s.name}", 65535)',
            "    var int decodedFieldCount = 0",
        ]
        for f in s.fields:
            local = f"_facserde_{f.name}"
            if f.since > 1:
                out.append(f"    {_local_type(f)} {local} = {_default_expression(f)}")
            elif f.rename_from or f.convert_from:
                out.append(f"    {_local_type(f)} {local} = {_default_expression(f)}")
            else:
                out.append(f"    {_local_type(f)} {local} = {_read_method(f)}")
                out.append("    decodedFieldCount++")
                continue

            out.append(f"    if (schemaVersion >= {f.since}) {{")
            name_lines, wire_name = _legacy_name(f)
            for line in name_lines:
                out.append("        " + line)
            if f.convert_from:
                out.append(f"        if (schemaVersion < {f.convert_since}) {{")
                out.append(f"            {local} = reader.readField{_legacy_read_method(f)}({wire_name})")
                out.append("        } else {")
                out.append(f"            {local} = reader.readField{_current_write_method(f)}({wire_name})")
                out.append("        }")
            else:
                out.append(f"        {local} = reader.readField{_current_write_method(f)}({wire_name})" if f.kind != "nested" else f'        {local} = fac_decode_{f.target}(reader.readFieldBytes({wire_name}))')
            out.append("        decodedFieldCount++")
            out.append("    }")

        out += [
            "    if (schemaVersion <= " + str(version) + ") {",
            '        if (fieldCount != decodedFieldCount) { throw Error("Record field count does not match its declared schema version", 13) }',
            "    } else {",
            "        var int unknownFieldCount = fieldCount - decodedFieldCount",
            '        if (unknownFieldCount < 0) { throw Error("Record field count is smaller than the known schema prefix", 13) }',
            "        for++(unknownFieldCount) { reader.skipField() }",
            "    }",
            "    reader.endRecord()",
            "    reader.requireEnd()",
            f"    struct {s.name} value = {s.name}(",
        ]
        for idx, f in enumerate(s.fields):
            suffix = "," if idx < len(s.fields) - 1 else ");"
            out.append(f"        _facserde_{f.name}{suffix}")
        for migration in s.migrations:
            out.append(f"    if (schemaVersion <= {migration.from_version}) {{ value = {migration.function}(value) }}")
        out += ["    return value", "}"]
    return "\n".join(out).rstrip() + "\n"

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", type=pathlib.Path, help="FAC source file containing struct declarations")
    ap.add_argument("output", type=pathlib.Path, help="generated FAC source output")
    ap.add_argument("--schema-prefix", default="app.models", help="dotted schema id prefix (default: app.models)")
    ap.add_argument("--version", type=int, default=1, help="schema version for all generated structs (1..65535)")
    ap.add_argument("--check", action="store_true", help="validate/generate without writing output")
    args = ap.parse_args(argv)
    try:
        source = args.source.read_text(encoding="utf-8")
        structs = parse_structs(source)
        generated = generate(source, structs, args.schema_prefix, args.version)
        if args.check:
            print(f"valid: {len(structs)} structs; generated {len(structs) * 2} helpers")
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(generated, encoding="utf-8", newline="\n")
            print(f"generated: {args.output} ({len(structs)} structs; {len(structs) * 2} helpers)")
        return 0
    except (OSError, SerdeError) as exc:
        print(f"facserde: error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
