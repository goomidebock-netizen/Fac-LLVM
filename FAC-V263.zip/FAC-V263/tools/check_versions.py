#!/usr/bin/env python3
"""Check that all public FAC release components use the manifest version."""
from pathlib import Path
import re
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
manifest = (ROOT / "VERSION.toml").read_text(encoding="utf-8")
header = (ROOT / "include/fac/version.h").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")


def toml_string(section: str, key: str) -> str:
    section_match = re.search(rf"(?ms)^\[{re.escape(section)}\]\s*(.*?)(?=^\[|\Z)", manifest)
    if not section_match:
        raise ValueError(f"missing [{section}] section in VERSION.toml")
    match = re.search(rf'(?m)^\s*{re.escape(key)}\s*=\s*"([^"]+)"\s*$', section_match.group(1))
    if not match:
        raise ValueError(f"missing {key} in [{section}]")
    return match.group(1)


errors = []
try:
    release = toml_string("release", "label")
    compiler = toml_string("release", "compiler")
    expected = {
        "core": "FAC_CORE_VERSION",
        "lib": "FAC_LIB_VERSION",
        "api": "FAC_API_VERSION",
        "lang": "FAC_LANG_VERSION",
        "runtime": "FAC_RUNTIME_VERSION",
        "stdlib": "FAC_STDLIB_VERSION",
    }
    if not re.fullmatch(r"V[1-9][0-9]*", release):
        errors.append(f"invalid release label: {release}")
    for key, macro in expected.items():
        val = toml_string("components", key)
        hm = re.search(rf'^#define\s+{macro}\s+"([^"]+)"\s*$', header, re.M)
        if not hm:
            errors.append(f"missing {macro} in include/fac/version.h")
        elif hm.group(1) != val:
            errors.append(f"{key} manifest/header mismatch: {val} vs {hm.group(1)}")
        if val != release:
            errors.append(f"{key} version {val} does not match release {release}")
    for macro, val in (("FAC_RELEASE_VERSION", release), ("FAC_COMPILER_VERSION", compiler)):
        hm = re.search(rf'^#define\s+{macro}\s+"([^"]+)"\s*$', header, re.M)
        if not hm or hm.group(1) != val:
            errors.append(f"{macro} does not match VERSION.toml")
    if not re.search(rf"(?m)^# Fac \(LLVM\).*· Release {re.escape(release)}$", readme):
        errors.append(f"README.md release title must identify Release {release}")
    status_doc = ROOT / "docs" / "STATUS.md"
    if not status_doc.exists() or not status_doc.read_text(encoding="utf-8").startswith(f"# FAC {release}\n"):
        errors.append(f"docs/STATUS.md must start with FAC {release}")
    current_docs = {
        "docs/MEMORY_MODEL.md": f"FAC Memory, Ownership, Borrowing and Lifetime Model — current {release}",
        "docs/MEMORY_SAFE_PROFILE.md": f"FAC `--memory-safe` profile — {release}",
        "docs/OWNERSHIP.md": f"Current {release} safe-profile policy",
    }
    for relative, marker in current_docs.items():
        path = ROOT / relative
        if not path.exists() or marker not in path.read_text(encoding="utf-8"):
            errors.append(f"{relative} must identify current release {release}")
    api_manifest = ROOT / "api" / "manifest.json"
    if not api_manifest.exists() or json.loads(api_manifest.read_text(encoding="utf-8")).get("release") != release:
        errors.append(f"api/manifest.json must use release {release}")
    standards = ROOT / "api" / "standards.json"
    if not standards.exists() or json.loads(standards.read_text(encoding="utf-8")).get("release") != release:
        errors.append(f"api/standards.json must use release {release}")
    api_index = ROOT / "docs" / "api" / "index.md"
    if not api_index.exists() or f"FAC API reference ({release})" not in api_index.read_text(encoding="utf-8"):
        errors.append(f"docs/api/index.md must identify {release}")
    for api_doc in (ROOT / "docs" / "api").glob("*.md"):
        api_text = api_doc.read_text(encoding="utf-8")
        for marker in re.findall(r"(?:release |Release )(V[1-9][0-9]*)", api_text):
            if marker != release:
                errors.append(f"{api_doc.relative_to(ROOT)} contains stale release marker {marker}")
                break
    # If a compiler binary is present, verify its user-visible version output too.
    compiler_bin = ROOT / "build/facc"
    if compiler_bin.exists():
        # A version bump makes the existing build/facc stale until it is rebuilt.
        # Skip that stale binary during `make all`; verify it once its timestamp
        # is newer than all compiler sources and the version header.
        source_paths = list((ROOT / "src").glob("*.cpp")) + list((ROOT / "src").glob("*.hpp")) + list((ROOT / "src").glob("*.inc")) + [ROOT / "include/fac/version.h"]
        newest_input = max(path.stat().st_mtime_ns for path in source_paths if path.exists())
        if compiler_bin.stat().st_mtime_ns >= newest_input:
            import subprocess
            result = subprocess.run([str(compiler_bin), "--version"], text=True, capture_output=True)
            if result.returncode != 0 or release not in result.stdout:
                errors.append("build/facc --version does not report the manifest release")
            for component in ("Core", "Lib", "API", "Lang", "Runtime", "Stdlib"):
                if component not in result.stdout:
                    errors.append(f"build/facc --version missing component {component}")
        else:
            print("version check: build/facc is stale; it will be verified after rebuild")
except ValueError as exc:
    errors.append(str(exc))

if errors:
    for error in errors:
        print(f"version check: ERROR: {error}", file=sys.stderr)
    raise SystemExit(1)
print(f"version check: OK — FAC {release}; Core/Lib/API/Lang/Runtime/Stdlib all {release}")
