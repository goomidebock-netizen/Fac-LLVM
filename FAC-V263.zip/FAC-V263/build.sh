#!/bin/sh
# Linux/macOS: ต้องมี clang++ (หรือ g++) แล้วรัน ./build.sh  ->  build/facc + build/libfacrt.a
set -e
make CXX="${CXX:-c++}"
echo "เสร็จ: ./build/facc examples/language_v2.fac -o /tmp/demo --run"
