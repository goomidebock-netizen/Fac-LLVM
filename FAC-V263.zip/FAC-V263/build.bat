@echo off
setlocal
rem Windows build. Prefer clang++, fall back to g++ when available.
if not exist build mkdir build
where clang++ >nul 2>nul
if %errorlevel%==0 (
  set "FAC_CXX=clang++"
) else (
  where g++ >nul 2>nul
  if errorlevel 1 (
    echo ERROR: neither clang++ nor g++ was found in PATH.
    echo Install LLVM or MinGW-w64 and retry.
    exit /b 1
  )
  set "FAC_CXX=g++"
)
echo Building FAC compiler with %FAC_CXX%...
rem Stack canaries are supported by the supported Clang/MinGW GCC toolchains.
set "FAC_HARDEN=-fstack-protector-strong"
%FAC_CXX% -std=c++17 -O2 %FAC_HARDEN% -c src\main.cpp -o build\facc_main.o
if errorlevel 1 goto :err
%FAC_CXX% -std=c++17 -O2 %FAC_HARDEN% -c src\lexer.cpp -o build\lexer.o
if errorlevel 1 goto :err
%FAC_CXX% build\facc_main.o build\lexer.o -o build\facc.exe
if errorlevel 1 goto :err
echo Building FAC runtime...
%FAC_CXX% -std=c++17 -O2 %FAC_HARDEN% -pthread -c runtime\fac_rt.cpp -o build\fac_rt.o
if errorlevel 1 goto :err
where llvm-ar >nul 2>nul
if %errorlevel%==0 (
  llvm-ar rcs build\libfacrt.a build\fac_rt.o
) else (
  where ar >nul 2>nul
  if errorlevel 1 (
    echo ERROR: neither llvm-ar nor ar was found in PATH.
    exit /b 1
  )
  ar rcs build\libfacrt.a build\fac_rt.o
)
if errorlevel 1 goto :err
echo Build succeeded: build\facc.exe
exit /b 0
:err
echo ERROR: build failed.
exit /b 1
