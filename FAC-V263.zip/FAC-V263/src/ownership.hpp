// Conservative static borrow checks for explicit `ref` parameters.
// `ref T` is mutable; `ref const T` is shared/immutable. This is not a
// whole-program Rust-style borrow checker: it checks direct call arguments
// and direct writes through the named immutable parameter.
#pragma once
#include "ast.hpp"
#include "lexer.hpp"
#include <algorithm>
#include <cstdint>
#include <cmath>
#include <deque>
#include <functional>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

struct FacBorrowChecker {
  // 0 = not borrowed, 1 = shared/immutable borrow, 2 = mutable borrow.
  using BorrowMode = uint8_t;
  using BorrowMask = std::vector<BorrowMode>;
  using NoescapeMask = std::vector<uint8_t>;
  using ReadonlyMask = std::vector<uint8_t>;
  std::map<std::string, std::vector<BorrowMask>> signatures;
  // Legacy summary masks remain as a conservative fallback when a call's
  // receiver or overload cannot be resolved. Normal direct calls use the
  // type-aware CallContract records below.
  std::map<std::string, std::vector<NoescapeMask>> noescapeSignatures;
  // readonly is a pointee-write effect, independent from noescape retention.
  std::map<std::string, std::vector<ReadonlyMask>> readonlySignatures;
  struct CallParamContract {
    std::string type;
    int lifetimeParamIndex = -1;
    bool hasDefault = false, variadic = false, ref = false, immutableRef = false;
    bool noescape = false, readonly = false;
    // Verified body-local effect: every use of this exact ptr thread parameter
    // is the direct argument to thread.join. This is narrower than noescape: it
    // permits the opaque handle field to be consumed without inventing a pointee
    // lifetime origin, but does not apply to arbitrary pointer parameters.
    bool threadHandleJoinOnly = false;
    // Verified value-struct parameter effect: every ptr thread field is either
    // unused or forwarded only to thread.join / a verified join-only helper.
    bool threadHandleStructJoinOnly = false;
    // Verified value-struct parameter effect: every raw-pointer leaf is only
    // forwarded to an exact, uniquely-resolved noescape pointer parameter.
    // This is a body-checked aggregate effect, not a caller-supplied promise.
    bool aggregatePointerFieldsNoescape = false;
  };
  struct CallContract {
    std::vector<CallParamContract> params;
    std::vector<std::string> lifetimeNames;
    std::vector<std::pair<int, int>> lifetimeOutlives;
    size_t lifetimeParamCount = 0;
    int returnLifetimeParamIndex = -1;
    bool generic = false;
    const Node *definition = nullptr;
  };
  static CallContract functionTypeContract(const TypeSpec &functionType) {
    CallContract contract;
    contract.lifetimeParamCount = functionType.sigLifetimeParams.size();
    contract.lifetimeNames = functionType.sigLifetimeParams;
    contract.lifetimeOutlives = functionType.sigLifetimeOutlives;
    contract.returnLifetimeParamIndex = functionType.sigReturnType
        ? functionType.sigReturnType->lifetimeParamIndex : -1;
    for (size_t i = 0; i < functionType.sig.size(); ++i) {
      const TypeSpec &type = functionType.sig[i];
      CallParamContract param;
      param.type = typeKey(type);
      param.lifetimeParamIndex = type.lifetimeParamIndex;
      // Function types retain noescape in their static shape so assignment
      // compatibility can reject weaker targets. That annotation alone is not
      // a body-verified call-site proof: until indirect target resolution can
      // bind a function value to its checked implementation, pointer escape
      // analysis must remain fail-closed for indirect calls. In particular,
      // do not promote sigNoescape into a verified CallContract here.
      param.noescape = false;
      param.readonly = i < functionType.sigReadonly.size() && functionType.sigReadonly[i];
      contract.params.push_back(std::move(param));
    }
    return contract;
  }
  // Full parameter metadata is retained so ownership effects can follow the
  // same best-match overload instead of combining unrelated same-arity overloads.
  std::map<std::string, std::vector<CallContract>> callContracts;
  std::map<std::string, std::map<std::string, std::string>> fieldTypes;
  // Enum variant payload layouts are retained for the bounded return escape
  // check. This lets auto-return functions distinguish raw pointer payloads
  // from scalar payloads without treating every match binding as a pointer.
  std::map<std::string, std::vector<std::string>> enumPayloadTypeKeys;
  std::map<std::string, bool> constMethods; // Class::method -> const receiver contract

  // Bounded return-lifetime elision for verified FAC bodies:
  // - the legacy one-pointer-input case keeps its original behavior;
  // - with multiple pointer inputs, exactly one may be returnable and every
  //   other pointer input must carry a body-verified `noescape` contract;
  // - returns may name that parameter directly or a simple local pointer alias
  //   declared in any lexical block, provided its initializer names the source
  //   parameter/earlier visible alias, and the alias is unique, never assigned,
  //   and never exposed to a call. Alias visibility is collected per block;
  //   a child block inherits its parent's aliases but does not export its own.
  // Pointer arithmetic, calls, field loads and computed return expressions
  // still require an explicit named lifetime contract. Extern/abstract
  // declarations and function-value types are not inferred.
  static void collectPointerAliasHazards(const Node *node,
                                         std::map<std::string, size_t> &declarationCounts,
                                         std::set<std::string> &assignedNames) {
    if (!node) return;
    // A lambda/function has its own lexical and return domain.
    if (node->k == NK::Lambda || node->k == NK::Func) return;
    if (node->k == NK::VarDecl && !node->s.empty()) ++declarationCounts[node->s];
    if (node->k == NK::Assign && !node->c.empty() && node->c[0] &&
        node->c[0]->k == NK::Ident)
      assignedNames.insert(node->c[0]->s);
    for (const auto &child : node->c) collectPointerAliasHazards(child.get(), declarationCounts, assignedNames);
    for (const auto &method : node->methods) collectPointerAliasHazards(method.get(), declarationCounts, assignedNames);
    for (const auto &parameter : node->params)
      if (parameter.def) collectPointerAliasHazards(parameter.def.get(), declarationCounts, assignedNames);
    for (const auto &branch : node->cases) {
      for (const auto &value : branch.vals) collectPointerAliasHazards(value.get(), declarationCounts, assignedNames);
      for (const auto &range : branch.ranges) {
        collectPointerAliasHazards(range.lo.get(), declarationCounts, assignedNames);
        collectPointerAliasHazards(range.hi.get(), declarationCounts, assignedNames);
      }
      collectPointerAliasHazards(branch.guard.get(), declarationCounts, assignedNames);
      collectPointerAliasHazards(branch.body.get(), declarationCounts, assignedNames);
      collectPointerAliasHazards(branch.exprBody.get(), declarationCounts, assignedNames);
    }
    collectPointerAliasHazards(node->deflt.get(), declarationCounts, assignedNames);
  }

  static void collectScopedPointerAliases(
      const Node *node, std::map<std::string, int> &visible,
      std::map<std::string, int> &allAliases,
      const std::map<std::string, size_t> &declarationCounts,
      const std::set<std::string> &assignedNames) {
    if (!node) return;
    // Nested functions and lambdas have independent declaration/return scopes.
    if (node->k == NK::Lambda || node->k == NK::Func) return;

    if (node->k == NK::Block) {
      // Lexical child blocks inherit visible parent aliases, but aliases
      // declared inside the block never become visible in the parent scope.
      auto scope = visible;
      for (const auto &statement : node->c) {
        const Node *child = statement.get();
        if (!child) continue;
        if (child->k == NK::VarDecl) {
          if (child->s.empty()) continue;
          // Any declaration shadows an earlier spelling, even when it is not
          // itself an eligible pointer alias.
          scope.erase(child->s);
          if (child->ts.kind != "ptr" || child->isRef ||
              declarationCounts.count(child->s) == 0 ||
              declarationCounts.at(child->s) != 1 ||
              assignedNames.count(child->s) || child->c.size() != 1 ||
              !child->c[0] || child->c[0]->k != NK::Ident)
            continue;
          auto source = scope.find(child->c[0]->s);
          if (source == scope.end()) continue;
          scope[child->s] = source->second;
          allAliases[child->s] = source->second;
          continue;
        }
        collectScopedPointerAliases(child, scope, allAliases,
                                    declarationCounts, assignedNames);
      }
      return;
    }

    // Control-flow nodes recurse into their child blocks. Each block creates
    // its own scope, so aliases in one branch cannot become visible in another.
    for (const auto &child : node->c)
      collectScopedPointerAliases(child.get(), visible, allAliases,
                                  declarationCounts, assignedNames);
    for (const auto &method : node->methods)
      collectScopedPointerAliases(method.get(), visible, allAliases,
                                  declarationCounts, assignedNames);
    for (const auto &branch : node->cases) {
      for (const auto &value : branch.vals)
        collectScopedPointerAliases(value.get(), visible, allAliases,
                                    declarationCounts, assignedNames);
      for (const auto &range : branch.ranges) {
        collectScopedPointerAliases(range.lo.get(), visible, allAliases,
                                    declarationCounts, assignedNames);
        collectScopedPointerAliases(range.hi.get(), visible, allAliases,
                                    declarationCounts, assignedNames);
      }
      collectScopedPointerAliases(branch.guard.get(), visible, allAliases,
                                  declarationCounts, assignedNames);
      collectScopedPointerAliases(branch.body.get(), visible, allAliases,
                                  declarationCounts, assignedNames);
      collectScopedPointerAliases(branch.exprBody.get(), visible, allAliases,
                                  declarationCounts, assignedNames);
    }
    collectScopedPointerAliases(node->deflt.get(), visible, allAliases,
                                declarationCounts, assignedNames);
  }

  static std::map<std::string, int> verifiedLocalPointerAliases(
      const Node *body, const std::map<std::string, int> &returnable) {
    std::map<std::string, int> aliases = returnable;
    if (!body || body->k != NK::Block) return aliases;

    std::map<std::string, size_t> declarationCounts;
    std::set<std::string> assignedNames;
    collectPointerAliasHazards(body, declarationCounts, assignedNames);

    // A local declaration that reuses a parameter name shadows that parameter
    // in at least one region. Since the return walk is name-based, conservatively
    // remove that source throughout this function.
    for (auto it = aliases.begin(); it != aliases.end();) {
      if (declarationCounts.count(it->first) || assignedNames.count(it->first))
        it = aliases.erase(it);
      else ++it;
    }

    // Build aliases with lexical visibility: nested blocks may use parent
    // aliases and can return their own aliases, but never export them outward.
    std::map<std::string, int> allAliases;
    auto visible = aliases;
    collectScopedPointerAliases(body, visible, allAliases,
                                declarationCounts, assignedNames);
    for (const auto &entry : allAliases) aliases[entry.first] = entry.second;

    // Passing any candidate alias through a call can expose or mutate the
    // pointer storage (notably through `ref` parameters). Without a
    // target-specific mutation summary, disable inference for that source.
    std::set<int> exposedSources;
    collectCallExposedAliasSources(body, aliases, exposedSources);
    for (auto it = aliases.begin(); it != aliases.end();) {
      if (exposedSources.count(it->second)) it = aliases.erase(it);
      else ++it;
    }
    return aliases;
  }

  static void collectCallExposedAliasSources(
      const Node *node, const std::map<std::string, int> &aliases,
      std::set<int> &exposedSources) {
    if (!node) return;
    if (node->k == NK::Lambda || node->k == NK::Func) return;
    if (node->k == NK::Call) {
      for (size_t i = 1; i < node->c.size(); ++i) {
        const Node *argument = node->c[i].get();
        for (const auto &alias : aliases)
          if (FacBorrowChecker::referencesName(argument, alias.first))
            exposedSources.insert(alias.second);
      }
    }
    for (const auto &child : node->c)
      collectCallExposedAliasSources(child.get(), aliases, exposedSources);
    for (const auto &method : node->methods)
      collectCallExposedAliasSources(method.get(), aliases, exposedSources);
    for (const auto &branch : node->cases) {
      for (const auto &value : branch.vals)
        collectCallExposedAliasSources(value.get(), aliases, exposedSources);
      for (const auto &range : branch.ranges) {
        collectCallExposedAliasSources(range.lo.get(), aliases, exposedSources);
        collectCallExposedAliasSources(range.hi.get(), aliases, exposedSources);
      }
      collectCallExposedAliasSources(branch.guard.get(), aliases, exposedSources);
      collectCallExposedAliasSources(branch.body.get(), aliases, exposedSources);
      collectCallExposedAliasSources(branch.exprBody.get(), aliases, exposedSources);
    }
    collectCallExposedAliasSources(node->deflt.get(), aliases, exposedSources);
  }

  static bool collectPointerReturnExpressionSource(
      const Node *expr, const std::map<std::string, int> &returnable,
      int &selected, bool &sawPointerReturn) {
    if (!expr) return false;
    // A literal null carries no input lifetime and can coexist with one
    // verified non-null source without introducing another origin.
    if (expr->k == NK::NullLit) return true;
    if (expr->k == NK::Ident) {
      auto parameter = returnable.find(expr->s);
      if (parameter == returnable.end()) return false;
      if (selected >= 0 && selected != parameter->second) return false;
      selected = parameter->second;
      sawPointerReturn = true;
      return true;
    }
    if (expr->k == NK::IfV) {
      // Conditions choose the result but do not become pointer origins. Every
      // value arm must resolve to the same unique input/verified local alias.
      if (expr->c.size() < 3 || (expr->c.size() % 2) == 0) return false;
      const size_t elseIndex = expr->c.size() - 1;
      for (size_t valueIndex = 1; valueIndex < elseIndex; valueIndex += 2) {
        if (!collectPointerReturnExpressionSource(expr->c[valueIndex].get(),
                                                  returnable, selected,
                                                  sawPointerReturn))
          return false;
      }
      return collectPointerReturnExpressionSource(expr->c[elseIndex].get(),
                                                   returnable, selected,
                                                   sawPointerReturn);
    }
    if (expr->k == NK::MatchExpr) {
      // Match inference is bounded to an explicit default so all possible
      // result paths are represented. Scrutinee, pattern and guard expressions
      // select a value but are not themselves returned pointer sources.
      if (expr->cases.empty() || !expr->deflt) return false;
      for (const Case &branch : expr->cases) {
        if (!branch.exprBody ||
            !collectPointerReturnExpressionSource(branch.exprBody.get(),
                                                  returnable, selected,
                                                  sawPointerReturn))
          return false;
      }
      return collectPointerReturnExpressionSource(expr->deflt.get(),
                                                   returnable, selected,
                                                   sawPointerReturn);
    }
    // Calls, field loads, payload bindings, pointer arithmetic, casts and
    // arbitrary computed expressions remain outside source inference.
    return false;
  }

  static bool collectDirectReturnParameter(const Node *node,
                                           const std::map<std::string, int> &returnable,
                                           int &selected, bool &sawPointerReturn) {
    if (!node) return true;
    // A lambda has its own return domain; its returns do not belong to fn.
    if (node->k == NK::Lambda || node->k == NK::Func) return true;
    if (node->k == NK::Return) {
      if (node->c.empty()) return false;
      return collectPointerReturnExpressionSource(node->c[0].get(), returnable,
                                                  selected, sawPointerReturn);
    }
    for (const auto &child : node->c)
      if (!collectDirectReturnParameter(child.get(), returnable, selected, sawPointerReturn)) return false;
    for (const auto &method : node->methods)
      if (!collectDirectReturnParameter(method.get(), returnable, selected, sawPointerReturn)) return false;
    for (const auto &parameter : node->params)
      if (parameter.def && !collectDirectReturnParameter(parameter.def.get(), returnable, selected, sawPointerReturn)) return false;
    for (const auto &branch : node->cases) {
      for (const auto &value : branch.vals)
        if (!collectDirectReturnParameter(value.get(), returnable, selected, sawPointerReturn)) return false;
      for (const auto &range : branch.ranges)
        if (!collectDirectReturnParameter(range.lo.get(), returnable, selected, sawPointerReturn) ||
            !collectDirectReturnParameter(range.hi.get(), returnable, selected, sawPointerReturn)) return false;
      if (!collectDirectReturnParameter(branch.guard.get(), returnable, selected, sawPointerReturn) ||
          !collectDirectReturnParameter(branch.body.get(), returnable, selected, sawPointerReturn) ||
          !collectDirectReturnParameter(branch.exprBody.get(), returnable, selected, sawPointerReturn)) return false;
    }
    return collectDirectReturnParameter(node->deflt.get(), returnable, selected, sawPointerReturn);
  }

  static int inferredReturnLifetimeParamIndex(const Node *fn) {
    if (!fn || fn->k != NK::Func || fn->isExtern || fn->isAbstract || fn->c.empty() ||
        fn->ts.kind != "ptr" || fn->ts.lifetimeParamIndex >= 0 ||
        !fn->lifetimeParams.empty()) return -1;

    std::map<std::string, int> returnable;
    int pointerCount = 0;
    int onlyPointer = -1;
    for (size_t i = 0; i < fn->params.size(); ++i) {
      const Param &parameter = fn->params[i];
      if (parameter.ts.kind != "ptr") continue;
      ++pointerCount;
      if (parameter.noescape) continue;
      // A defaulted/variadic return source would make argument-to-lifetime
      // substitution ambiguous at a call site.
      if (parameter.def || parameter.variadic) return -1;
      onlyPointer = static_cast<int>(i);
      returnable.emplace(parameter.name, static_cast<int>(i));
    }
    if (pointerCount == 0 || returnable.empty()) return -1;
    if (pointerCount == 1) return onlyPointer;

    // For multiple pointer inputs, all but one must explicitly promise
    // non-retention. The body checker verifies each `noescape` promise.
    if (returnable.size() != 1) return -1;
    const auto verifiedAliases = verifiedLocalPointerAliases(fn->c[0].get(), returnable);
    int selected = -1;
    bool sawPointerReturn = false;
    if (!collectDirectReturnParameter(fn->c[0].get(), verifiedAliases, selected, sawPointerReturn)) return -1;
    return sawPointerReturn ? selected : -1;
  }

  static std::string typeKey(const TypeSpec &ts) {
    if (ts.hasSig || ts.cat == "func") return "function";
    if (ts.kind == "ptr") return "ptr " + ts.base;
    if (ts.cat == "array") return "array " + ts.base;
    if (ts.cat == "list") return "list " + ts.base;
    if (ts.cat == "struct") return "struct " + ts.base;
    if (ts.cat == "enum") return "enum " + ts.base;
    if (ts.cat == "obj") return "obj " + ts.base;
    if (ts.cat == "weakobj") return "weak obj " + ts.base;
    if (ts.cat == "hashmap") return "hashmap " + ts.base + "," + ts.base2;
    if (ts.cat == "hashset" || ts.cat == "trie" || ts.cat == "heap" || ts.cat == "matrix") return ts.cat + " " + ts.base;
    return ts.base;
  }

  static std::string expressionTypeKey(const Node *expr,
                                       const std::map<std::string, std::string> &types,
                                       const std::map<std::string, std::map<std::string, std::string>> &fields) {
    if (!expr) return {};
    switch (expr->k) {
      case NK::IntLit: return expr->iv >= INT32_MIN && expr->iv <= INT32_MAX ? "int" : "long";
      case NK::FloatLit: return "double";
      case NK::BoolLit: return "boolean";
      case NK::CharLit: return "char";
      case NK::StrLit: return "string";
      case NK::NullLit: return "null";
      case NK::Ident: {
        auto it = types.find(expr->s);
        return it == types.end() ? std::string{} : it->second;
      }
      case NK::Call: {
        if (expr->c.size() == 2 && expr->c[0] && expr->c[0]->k == NK::Ident && expr->c[0]->s == "addr") {
          const std::string pointee = expressionTypeKey(expr->c[1].get(), types, fields);
          return pointee.empty() ? std::string{} : "ptr " + pointee;
        }
        return {};
      }
      case NK::Member: {
        if (expr->c.empty()) return {};
        std::string owner = expressionTypeKey(expr->c[0].get(), types, fields);
        for (const char *prefix : {"struct ", "class ", "obj ", "weak obj "}) {
          const std::string p(prefix);
          if (owner.compare(0, p.size(), p) == 0) owner = owner.substr(p.size());
        }
        auto it = fields.find(owner);
        if (it == fields.end()) return {};
        auto member = it->second.find(expr->s);
        return member == it->second.end() ? std::string{} : member->second;
      }
      default: return {};
    }
  }

  static int contractTypeScore(const std::string &actual, const std::string &required) {
    if (actual.empty()) return 0;
    if (actual == required) return 4;
    if (actual == "null" && required.compare(0, 4, "ptr ") == 0) return 1;
    if (actual.compare(0, 4, "ptr ") == 0 && required.compare(0, 4, "ptr ") == 0) return 2;
    auto numeric = [](const std::string &t) {
      return t == "byte" || t == "short" || t == "int" || t == "long" ||
             t == "ubyte" || t == "ushort" || t == "uint" || t == "ulong" ||
             t == "float" || t == "double" || t == "boolean" || t == "char" || t == "unichar";
    };
    return numeric(actual) && numeric(required) ? 1 : -1;
  }

  std::vector<const CallContract *> resolveCallContracts(
      const Node *callee, const std::vector<const Node *> &args,
      const std::map<std::string, std::string> &types) const {
    if (!callee) return {};
    std::string key;
    if (callee->k == NK::Member && !callee->c.empty()) {
      std::string owner = expressionTypeKey(callee->c[0].get(), types, fieldTypes);
      for (const char *prefix : {"struct ", "class ", "obj ", "weak obj "}) {
        const std::string p(prefix);
        if (owner.compare(0, p.size(), p) == 0) owner = owner.substr(p.size());
      }
      key = owner.empty() ? callee->s : owner + "::" + callee->s;
    } else key = directCalleeName(callee);
    auto found = callContracts.find(key);
    if (key.empty() || found == callContracts.end()) return {};
    int bestScore = -1000000;
    bool hasUnknownArgumentType = false;
    std::vector<const CallContract *> best;
    for (const CallContract &candidate : found->second) {
      const size_t np = candidate.params.size();
      const size_t fixed = !candidate.params.empty() && candidate.params.back().variadic ? np - 1 : np;
      size_t minArgs = 0;
      for (size_t i = 0; i < fixed; ++i) if (!candidate.params[i].hasDefault) minArgs = i + 1;
      if (args.size() < minArgs || (args.size() > fixed && fixed == np)) continue;
      int score = candidate.generic ? -50 : 0;
      bool viable = true;
      for (size_t i = 0; i < args.size(); ++i) {
        const CallParamContract &param = candidate.params[i < fixed ? i : np - 1];
        const std::string actual = expressionTypeKey(args[i], types, fieldTypes);
        if (actual.empty()) hasUnknownArgumentType = true;
        const int part = contractTypeScore(actual, param.type);
        if (part < 0) { viable = false; break; }
        score += part;
      }
      if (!viable) continue;
      if (score > bestScore) { bestScore = score; best.clear(); best.push_back(&candidate); }
      else if (score == bestScore) best.push_back(&candidate);
    }
    // If any argument is unknown, a different concrete type could change the
    // overload winner. Keep all arity-compatible candidates and require every
    // one of them to carry the relevant effect.
    if (hasUnknownArgumentType) best.clear();
    if (best.empty()) {
      for (const CallContract &candidate : found->second) {
        const size_t np = candidate.params.size();
        const size_t fixed = !candidate.params.empty() && candidate.params.back().variadic ? np - 1 : np;
        size_t minArgs = 0;
        for (size_t i = 0; i < fixed; ++i) if (!candidate.params[i].hasDefault) minArgs = i + 1;
        if (args.size() >= minArgs && (args.size() <= fixed || fixed != np)) best.push_back(&candidate);
      }
    }
    return best;
  }

  static BorrowMode modeOf(const Param &p) {
    if (!p.ref) return 0;
    return p.immutableRef ? 1 : 2;
  }

  static bool parameterIsUsedOnlyByThreadJoin(const Node *fn, const Param &param) {
    if (!fn || fn->k != NK::Func || fn->c.empty() || param.ref ||
        typeKey(param.ts) != "ptr thread" || param.name.empty()) return false;
    bool sawJoin = false;
    bool invalidUse = false;
    std::function<void(const Node *)> visit = [&](const Node *node) {
      if (!node || invalidUse) return;
      // Nested functions/lambdas have separate binding scopes. A capture of the
      // parameter is nevertheless an escape, so reject it if the name occurs.
      if (node->k == NK::Lambda || node->k == NK::Func) {
        if (referencesName(node, param.name)) invalidUse = true;
        return;
      }
      // A same-spelled local can shadow the parameter. Rather than attempting
      // declaration-identity reconstruction in this narrow effect proof, fail
      // closed for any such declaration in the function body.
      if (node->k == NK::VarDecl && node->s == param.name) {
        invalidUse = true;
        return;
      }
      if (node->k == NK::Call && node->c.size() == 2 && node->c[0] &&
          qualifiedCallPath(node->c[0].get()) == "thread.join" && node->c[1] &&
          node->c[1]->k == NK::Ident && node->c[1]->s == param.name) {
        sawJoin = true;
        // The parameter occurrence is accounted for by this exact consuming
        // operation. Still inspect the callee expression for accidental uses.
        visit(node->c[0].get());
        return;
      }
      if (node->k == NK::Ident && node->s == param.name) {
        invalidUse = true;
        return;
      }
      for (const auto &child : node->c) visit(child.get());
      for (const auto &method : node->methods) visit(method.get());
      for (const auto &branch : node->cases) {
        for (const auto &value : branch.vals) visit(value.get());
        for (const auto &range : branch.ranges) {
          visit(range.lo.get());
          visit(range.hi.get());
        }
        visit(branch.guard.get());
        visit(branch.body.get());
        visit(branch.exprBody.get());
      }
      visit(node->deflt.get());
    };
    visit(fn->c[0].get());
    return sawJoin && !invalidUse;
  }

  static void addFunction(std::map<std::string, std::vector<BorrowMask>> &out,
                          std::map<std::string, std::vector<NoescapeMask>> &escapeOut,
                          std::map<std::string, std::vector<ReadonlyMask>> &readonlyOut,
                          std::map<std::string, std::vector<CallContract>> &contractOut,
                          const Node *fn, const std::string &key = {}) {
    if (!fn || fn->k != NK::Func || fn->s.empty()) return;
    BorrowMask mask;
    NoescapeMask escapeMask;
    ReadonlyMask readonlyMask;
    mask.reserve(fn->params.size());
    escapeMask.reserve(fn->params.size());
    readonlyMask.reserve(fn->params.size());
    CallContract contract;
    for (const auto &p : fn->params) {
      mask.push_back(modeOf(p));
      escapeMask.push_back(p.noescape ? 1 : 0);
      readonlyMask.push_back(p.readonly ? 1 : 0);
      CallParamContract cp;
      cp.type = typeKey(p.ts); cp.lifetimeParamIndex = p.ts.lifetimeParamIndex;
      cp.hasDefault = !!p.def; cp.variadic = p.variadic;
      cp.ref = p.ref; cp.immutableRef = p.immutableRef;
      cp.noescape = p.noescape; cp.readonly = p.readonly;
      cp.threadHandleJoinOnly = parameterIsUsedOnlyByThreadJoin(fn, p);
      contract.params.push_back(std::move(cp));
    }
    contract.lifetimeParamCount = fn->lifetimeParams.size();
    contract.lifetimeNames = fn->lifetimeParams;
    contract.lifetimeOutlives = fn->lifetimeOutlives;
    contract.returnLifetimeParamIndex = fn->ts.lifetimeParamIndex;
    contract.definition = fn;
    const int elidedReturnParameter = inferredReturnLifetimeParamIndex(fn);
    if (elidedReturnParameter >= 0) {
      // The implicit lifetime is intentionally synthesized only in this
      // verified direct-call contract. It is not copied into function-value
      // types, where the target body may be unknown.
      contract.lifetimeParamCount = 1;
      contract.lifetimeNames = {"<elided>"};
      contract.params[static_cast<size_t>(elidedReturnParameter)].lifetimeParamIndex = 0;
      contract.returnLifetimeParamIndex = 0;
    }
    contract.generic = !fn->typeParams.empty();
    // Keep non-borrow signatures too. If overload resolution is ambiguous,
    // only enforce a rule that every same-arity candidate requires.
    out[fn->s].push_back(mask);
    escapeOut[fn->s].push_back(escapeMask);
    readonlyOut[fn->s].push_back(readonlyMask);
    contractOut[fn->s].push_back(contract);
    if (!key.empty() && key != fn->s) {
      out[key].push_back(mask);
      escapeOut[key].push_back(escapeMask);
      readonlyOut[key].push_back(readonlyMask);
      contractOut[key].push_back(std::move(contract));
    }
  }

  void collect(const std::vector<std::unique_ptr<Program>> &programs) {
    for (const auto &p : programs) {
      for (const auto &e : p->enums) {
        if (!e || e->k != NK::EnumDef) continue;
        const std::set<std::string> genericPayloadParameters(e->typeParams.begin(),
                                                               e->typeParams.end());
        for (const auto &member : e->members) {
          std::vector<std::string> payloadTypes;
          payloadTypes.reserve(member.payloadTypes.size());
          for (const TypeSpec &payload : member.payloadTypes) {
            std::string payloadType = typeKey(payload);
            if (payload.kind != "ptr" && genericPayloadParameters.count(payload.base))
              payloadType = "@generic:" + payload.base;
            payloadTypes.push_back(std::move(payloadType));
          }
          const std::string payloadKey = e->s + "::" + member.name;
          auto knownPayload = enumPayloadTypeKeys.find(payloadKey);
          if (knownPayload == enumPayloadTypeKeys.end()) {
            enumPayloadTypeKeys.emplace(payloadKey, std::move(payloadTypes));
          } else {
            // Unqualified enum names can collide across imported modules. Do
            // not let the last collected declaration overwrite a potentially
            // pointer-bearing layout with a scalar one.
            const size_t width = std::max(knownPayload->second.size(), payloadTypes.size());
            knownPayload->second.resize(width, "@unknown");
            for (size_t i = 0; i < width; ++i) {
              if (i >= payloadTypes.size() || knownPayload->second[i] != payloadTypes[i])
                knownPayload->second[i] = "@unknown";
            }
          }
        }
      }
      for (const auto &f : p->funcs) addFunction(signatures, noescapeSignatures, readonlySignatures, callContracts, f.get());
      for (const auto &s : p->structs) {
        for (const auto &field : s->c)
          if (field && field->k == NK::VarDecl) fieldTypes[s->s][field->s] = typeKey(field->ts);
        for (const auto &m : s->methods) {
          addFunction(signatures, noescapeSignatures, readonlySignatures, callContracts, m.get(), s->s + "::" + (m ? m->s : std::string{}));
          if (m && m->k == NK::Func) constMethods[s->s + "::" + m->s] = m->isConst;
        }
        for (const auto &c : s->c)
          addFunction(signatures, noescapeSignatures, readonlySignatures, callContracts, c.get(), s->s + "::" + (c ? c->s : std::string{}));
      }
    }
    // All value-struct field metadata and direct helper contracts are now
    // available, so summarize narrowly verified join-only struct parameters.
    annotateThreadHandleStructJoinOnlyContracts();
  }

  static bool parameterMemberPath(const Node *expr, const std::string &root,
                                  std::string &projection) {
    if (!expr) return false;
    if (expr->k == NK::Ident) {
      if (expr->s != root) return false;
      projection.clear();
      return true;
    }
    if (expr->k != NK::Member || expr->c.empty()) return false;
    std::string parent;
    if (!parameterMemberPath(expr->c[0].get(), root, parent)) return false;
    projection = parent.empty() ? expr->s : parent + "." + expr->s;
    return true;
  }

  bool collectThreadHandleFieldPaths(const std::string &typeKey,
                                     const std::string &prefix,
                                     std::set<std::string> &active,
                                     std::vector<std::string> &paths) const {
    const std::string structPrefix = "struct ";
    if (typeKey.compare(0, structPrefix.size(), structPrefix) != 0) return false;
    const std::string name = typeKey.substr(structPrefix.size());
    if (name.empty() || !active.insert(name).second) return false;
    auto metadata = fieldTypes.find(name);
    if (metadata == fieldTypes.end() || metadata->second.empty()) {
      active.erase(name);
      return false;
    }
    for (const auto &field : metadata->second) {
      const std::string path = prefix.empty() ? field.first : prefix + "." + field.first;
      const std::string &fieldType = field.second;
      if (fieldType.compare(0, 4, "ptr ") == 0) {
        // Do not suppress provenance checks for any other raw-pointer type.
        if (fieldType != "ptr thread") { active.erase(name); return false; }
        paths.push_back(path);
      } else if (fieldType.compare(0, 7, "struct ") == 0) {
        if (!collectThreadHandleFieldPaths(fieldType, path, active, paths)) {
          active.erase(name);
          return false;
        }
      } else if (fieldType.find("ptr ") != std::string::npos) {
        // Pointer-bearing arrays/containers and opaque layouts are outside the
        // exact field-path subset and must retain the ordinary checks.
        active.erase(name);
        return false;
      }
    }
    active.erase(name);
    return true;
  }

  bool directHelperArgumentIsJoinOnly(const Node *call, size_t argumentIndex) const {
    if (!call || call->k != NK::Call || call->c.empty() ||
        argumentIndex + 1 >= call->c.size()) return false;
    const std::string key = directCalleeName(call->c[0].get());
    auto found = callContracts.find(key);
    if (key.empty() || found == callContracts.end()) return false;
    const size_t argc = call->c.size() - 1;
    // Keep this proof independent of overload-ranking guesses: only a single
    // non-generic declaration with the exact ptr thread parameter is accepted.
    if (found->second.size() != 1) return false;
    const CallContract &candidate = found->second.front();
    return !candidate.generic && candidate.params.size() == argc &&
           argumentIndex < candidate.params.size() &&
           candidate.params[argumentIndex].type == "ptr thread" &&
           candidate.params[argumentIndex].threadHandleJoinOnly;
  }

  bool structParameterFieldsAreJoinOnly(const CallContract &contract,
                                        size_t parameterIndex) const {
    if (!contract.definition || parameterIndex >= contract.definition->params.size()) return false;
    const Param &param = contract.definition->params[parameterIndex];
    if (param.ref || contract.params[parameterIndex].type.compare(0, 7, "struct ") != 0)
      return false;
    std::vector<std::string> pointerPaths;
    std::set<std::string> active;
    if (!collectThreadHandleFieldPaths(contract.params[parameterIndex].type, "", active,
                                       pointerPaths) || pointerPaths.empty()) return false;
    const std::set<std::string> allowed(pointerPaths.begin(), pointerPaths.end());
    bool invalidUse = false;
    std::function<void(const Node *)> visit = [&](const Node *node) {
      if (!node || invalidUse) return;
      if (node->k == NK::Lambda || node->k == NK::Func) {
        if (referencesName(node, param.name)) invalidUse = true;
        return;
      }
      if (node->k == NK::Call) {
        for (size_t i = 1; i < node->c.size(); ++i) {
          std::string projection;
          if (!parameterMemberPath(node->c[i].get(), param.name, projection) ||
              !allowed.count(projection)) continue;
          const bool directJoin = qualifiedCallPath(node->c[0].get()) == "thread.join" && i == 1;
          const bool helperJoin = directHelperArgumentIsJoinOnly(node, i - 1);
          if (!directJoin && !helperJoin) { invalidUse = true; return; }
          // The exact pointer-field use is accounted for by a verified
          // consuming/non-retaining operation; do not descend into its root.
        }
        for (const auto &child : node->c) {
          bool isAuthorizedFieldArgument = false;
          for (size_t i = 1; i < node->c.size(); ++i) {
            std::string projection;
            if (node->c[i].get() == child.get() &&
                parameterMemberPath(child.get(), param.name, projection) &&
                allowed.count(projection)) {
              const bool directJoin = qualifiedCallPath(node->c[0].get()) == "thread.join" && i == 1;
              const bool helperJoin = directHelperArgumentIsJoinOnly(node, i - 1);
              isAuthorizedFieldArgument = directJoin || helperJoin;
              break;
            }
          }
          if (!isAuthorizedFieldArgument) visit(child.get());
        }
        return;
      }
      if (node->k == NK::Member) {
        std::string projection;
        if (parameterMemberPath(node, param.name, projection)) {
          if (allowed.count(projection)) invalidUse = true;
          // Scalar sibling projections do not expose pointer fields. A nested
          // aggregate prefix, however, could carry those fields elsewhere.
          for (const std::string &path : pointerPaths)
            if (path.compare(0, projection.size() + 1, projection + ".") == 0)
              invalidUse = true;
          return;
        }
      }
      if (node->k == NK::Ident && node->s == param.name) {
        invalidUse = true; // whole aggregate, alias, return or capture
        return;
      }
      for (const auto &child : node->c) visit(child.get());
      for (const auto &method : node->methods) visit(method.get());
      for (const auto &branch : node->cases) {
        for (const auto &value : branch.vals) visit(value.get());
        for (const auto &range : branch.ranges) { visit(range.lo.get()); visit(range.hi.get()); }
        visit(branch.guard.get());
        visit(branch.body.get());
        visit(branch.exprBody.get());
      }
      visit(node->deflt.get());
    };
    visit(contract.definition->c.empty() ? nullptr : contract.definition->c[0].get());
    return !invalidUse;
  }

  bool collectValueStructPointerFieldTypes(
      const std::string &typeKey, const std::string &prefix,
      std::set<std::string> &active,
      std::vector<std::pair<std::string, std::string>> &paths) const {
    const std::string structPrefix = "struct ";
    if (typeKey.compare(0, structPrefix.size(), structPrefix) != 0) return false;
    const std::string name = typeKey.substr(structPrefix.size());
    if (name.empty() || !active.insert(name).second) return false;
    auto metadata = fieldTypes.find(name);
    if (metadata == fieldTypes.end() || metadata->second.empty()) {
      active.erase(name);
      return false;
    }
    for (const auto &field : metadata->second) {
      const std::string path = prefix.empty() ? field.first : prefix + "." + field.first;
      const std::string &fieldType = field.second;
      if (fieldType.compare(0, 4, "ptr ") == 0) {
        // Thread handles keep their dedicated join-only rule: a generic
        // noescape forwarding summary must not weaken their lifecycle proof.
        if (fieldType == "ptr thread") { active.erase(name); return false; }
        paths.emplace_back(path, fieldType);
      } else if (fieldType.compare(0, 7, "struct ") == 0) {
        if (!collectValueStructPointerFieldTypes(fieldType, path, active, paths)) {
          active.erase(name);
          return false;
        }
      } else if (fieldType.find("ptr ") != std::string::npos) {
        // Pointer-bearing arrays/containers and opaque layouts remain outside
        // this field-only proof until their element paths are modeled exactly.
        active.erase(name);
        return false;
      }
    }
    active.erase(name);
    return true;
  }

  bool directHelperArgumentIsNoescape(const Node *call, size_t argumentIndex,
                                      const std::string &expectedPointerType) const {
    if (!call || call->k != NK::Call || call->c.empty() ||
        argumentIndex + 1 >= call->c.size()) return false;
    const std::string key = directCalleeName(call->c[0].get());
    auto found = callContracts.find(key);
    if (key.empty() || found == callContracts.end() || found->second.size() != 1)
      return false;
    const CallContract &candidate = found->second.front();
    if (candidate.generic || candidate.params.size() != call->c.size() - 1 ||
        argumentIndex >= candidate.params.size()) return false;
    const CallParamContract &param = candidate.params[argumentIndex];
    return !param.ref && param.noescape && param.type == expectedPointerType;
  }

  bool structParameterPointerFieldsAreNoescape(const CallContract &contract,
                                                size_t parameterIndex) const {
    if (!contract.definition || parameterIndex >= contract.definition->params.size()) return false;
    const Param &param = contract.definition->params[parameterIndex];
    if (param.ref || contract.params[parameterIndex].type.compare(0, 7, "struct ") != 0)
      return false;
    std::vector<std::pair<std::string, std::string>> pointerFields;
    std::set<std::string> active;
    if (!collectValueStructPointerFieldTypes(contract.params[parameterIndex].type,
                                             "", active, pointerFields) ||
        pointerFields.empty()) return false;
    std::map<std::string, std::string> pointerPaths;
    for (const auto &field : pointerFields) pointerPaths.emplace(field.first, field.second);

    bool invalidUse = false;
    std::function<void(const Node *)> visit = [&](const Node *node) {
      if (!node || invalidUse) return;
      if (node->k == NK::Lambda || node->k == NK::Func) {
        if (referencesName(node, param.name)) invalidUse = true;
        return;
      }
      if (node->k == NK::Call) {
        std::set<const Node *> authorizedArguments;
        for (size_t i = 1; i < node->c.size(); ++i) {
          std::string projection;
          if (!parameterMemberPath(node->c[i].get(), param.name, projection)) continue;
          auto path = pointerPaths.find(projection);
          if (path == pointerPaths.end()) continue;
          if (!directHelperArgumentIsNoescape(node, i - 1, path->second)) {
            invalidUse = true;
            return;
          }
          authorizedArguments.insert(node->c[i].get());
        }
        for (const auto &child : node->c)
          if (!authorizedArguments.count(child.get())) visit(child.get());
        return;
      }
      if (node->k == NK::Member) {
        std::string projection;
        if (parameterMemberPath(node, param.name, projection)) {
          if (pointerPaths.count(projection)) { invalidUse = true; return; }
          // A prefix of a pointer-bearing subtree can carry those fields into
          // an alias, return, store, or capture; do not authorize the subtree.
          for (const auto &field : pointerPaths)
            if (field.first.compare(0, projection.size() + 1, projection + ".") == 0) {
              invalidUse = true;
              return;
            }
          return;
        }
      }
      if (node->k == NK::Ident && node->s == param.name) {
        invalidUse = true; // whole aggregate, alias, return, store or capture
        return;
      }
      for (const auto &child : node->c) visit(child.get());
      for (const auto &method : node->methods) visit(method.get());
      for (const auto &branch : node->cases) {
        for (const auto &value : branch.vals) visit(value.get());
        for (const auto &range : branch.ranges) { visit(range.lo.get()); visit(range.hi.get()); }
        visit(branch.guard.get());
        visit(branch.body.get());
        visit(branch.exprBody.get());
      }
      visit(node->deflt.get());
    };
    visit(contract.definition->c.empty() ? nullptr : contract.definition->c[0].get());
    return !invalidUse;
  }

  void annotateThreadHandleStructJoinOnlyContracts() {
    for (auto &entry : callContracts) {
      for (CallContract &contract : entry.second) {
        for (size_t i = 0; i < contract.params.size(); ++i) {
          contract.params[i].threadHandleStructJoinOnly =
              structParameterFieldsAreJoinOnly(contract, i);
          contract.params[i].aggregatePointerFieldsNoescape =
              structParameterPointerFieldsAreNoescape(contract, i);
        }
      }
    }
  }

  // Return the syntactic storage root. Different fields/indexes of one root
  // are treated as possibly aliasing: this deliberately prefers false
  // positives over silently permitting overlapping mutable access.
  static std::string rootOf(const Node *n) {
    if (!n) return {};
    switch (n->k) {
      case NK::Ident: return n->s;
      case NK::Member:
      case NK::Index:
      case NK::Deref:
        return n->c.empty() ? std::string{} : rootOf(n->c[0].get());
      default: return {};
    }
  }

  // Only first-level named fields are proven disjoint. Indexes, nested paths,
  // pointer dereferences and computed bases remain conservative aliases.
  static bool distinctDirectFields(const Node *a, const Node *b) {
    auto directField = [](const Node *n, std::string &root, std::string &field) {
      if (!n || n->k != NK::Member || n->c.size() != 1 || !n->c[0] ||
          n->c[0]->k != NK::Ident) return false;
      root = n->c[0]->s;
      field = n->s;
      return !root.empty() && !field.empty();
    };
    std::string rootA, fieldA, rootB, fieldB;
    return directField(a, rootA, fieldA) && directField(b, rootB, fieldB) &&
           rootA == rootB && fieldA != fieldB;
  }

  static bool mayAlias(const Node *a, const Node *b) {
    const std::string rootA = rootOf(a), rootB = rootOf(b);
    return !rootA.empty() && rootA == rootB && !distinctDirectFields(a, b);
  }

  static std::string directCalleeName(const Node *n) {
    if (!n) return {};
    if (n->k == NK::Ident || n->k == NK::Member) return n->s;
    return {};
  }

  // Preserve the canonical module path for the small set of built-ins whose
  // ownership contract is stronger than an ordinary pointer-returning call.
  // In particular, thread.start creates a separately allocated owned handle,
  // and thread.join consumes that handle.
  static std::string qualifiedCallPath(const Node *n) {
    if (!n) return {};
    if (n->k == NK::Ident) return n->s;
    if (n->k == NK::Member && !n->c.empty()) {
      const std::string prefix = qualifiedCallPath(n->c[0].get());
      return prefix.empty() ? std::string{} : prefix + "." + n->s;
    }
    return {};
  }

  static bool referencesName(const Node *n, const std::string &name) {
    if (!n) return false;
    if (n->k == NK::Ident && n->s == name) return true;
    for (const auto &c : n->c) if (referencesName(c.get(), name)) return true;
    for (const auto &m : n->methods) if (referencesName(m.get(), name)) return true;
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) if (referencesName(v.get(), name)) return true;
      for (const auto &r : cs.ranges)
        if (referencesName(r.lo.get(), name) || referencesName(r.hi.get(), name)) return true;
      if (referencesName(cs.body.get(), name) || referencesName(cs.guard.get(), name) ||
          referencesName(cs.exprBody.get(), name)) return true;
    }
    return referencesName(n->deflt.get(), name);
  }

  // Find payload bindings used as values by any nested match expression in a
  // returned expression. This must walk through wrappers such as ifv/eiv/elv:
  // checking only the top-level return node would let a nested payload pointer
  // bypass the fail-closed provenance rule.
  static bool findUntrackedMatchPayloadBinding(const Node *n, std::string &binding) {
    if (!n || n->k == NK::Lambda || n->k == NK::Func) return false;
    if (n->k == NK::MatchExpr) {
      // A match's scrutinee, patterns and guards only select a result. Inspect
      // its value arms, and recursively inspect matches nested inside those arms.
      for (const auto &branch : n->cases) {
        for (const std::string &name : branch.bindings) {
          if (referencesName(branch.exprBody.get(), name)) {
            binding = name;
            return true;
          }
        }
        if (findUntrackedMatchPayloadBinding(branch.exprBody.get(), binding)) return true;
      }
      return findUntrackedMatchPayloadBinding(n->deflt.get(), binding);
    }
    if (n->k == NK::IfV) {
      // Conditions are selection logic, not possible pointer result values.
      if (n->c.size() < 3 || (n->c.size() % 2) == 0) return false;
      const size_t elseIndex = n->c.size() - 1;
      for (size_t valueIndex = 1; valueIndex < elseIndex; valueIndex += 2)
        if (findUntrackedMatchPayloadBinding(n->c[valueIndex].get(), binding)) return true;
      return findUntrackedMatchPayloadBinding(n->c[elseIndex].get(), binding);
    }
    for (const auto &child : n->c)
      if (findUntrackedMatchPayloadBinding(child.get(), binding)) return true;
    for (const auto &method : n->methods)
      if (findUntrackedMatchPayloadBinding(method.get(), binding)) return true;
    for (const auto &parameter : n->params)
      if (parameter.def && findUntrackedMatchPayloadBinding(parameter.def.get(), binding)) return true;
    return false;
  }

  // `auto` return declarations do not carry `kind == ptr` on the parsed
  // function TypeSpec. For the bounded direct-result forms (match/ifv),
  // identify raw pointer payload bindings that are themselves returned.
  // Scalar payloads and payloads used only in conditions/comparisons are not
  // treated as returned pointer origins.
  static bool isUntrackedPointerPayloadType(const std::string &type) {
    return type.compare(0, 4, "ptr ") == 0 ||
           type.compare(0, 9, "@generic:") == 0 ||
           type == "@unknown" || type.empty() || type == "auto" || type == "var";
  }

  // Resolve a member expression rooted in a pointer-capable match payload.
  // The result type is taken from struct/class field metadata. Missing or
  // generic metadata is represented as @unknown so this bounded escape guard
  // remains fail-closed for a member that may itself be a raw pointer.
  static bool resolveUntrackedPayloadMemberType(
      const Node *n,
      const std::map<std::string, std::map<std::string, std::string>> &fieldTypes,
      const std::map<std::string, std::string> &activePointerBindings,
      std::string &resultType,
      std::string &rootBinding) {
    if (!n) return false;
    if (n->k == NK::Ident) {
      auto active = activePointerBindings.find(n->s);
      if (active == activePointerBindings.end()) return false;
      resultType = active->second;
      rootBinding = n->s;
      return true;
    }
    if (n->k != NK::Member || n->c.empty()) return false;

    std::string ownerType;
    if (!resolveUntrackedPayloadMemberType(n->c[0].get(), fieldTypes,
                                           activePointerBindings, ownerType,
                                           rootBinding)) return false;
    // FAC member access dereferences a pointer receiver. Normalize the
    // aggregate type before consulting the source-level field table.
    while (ownerType.compare(0, 4, "ptr ") == 0) ownerType.erase(0, 4);
    for (const char *prefix : {"struct ", "class ", "obj ", "weak obj "}) {
      const std::string p(prefix);
      if (ownerType.compare(0, p.size(), p) == 0) {
        ownerType.erase(0, p.size());
        break;
      }
    }
    auto aggregate = fieldTypes.find(ownerType);
    if (aggregate == fieldTypes.end()) {
      resultType = "@unknown";
      return true;
    }
    auto field = aggregate->second.find(n->s);
    resultType = field == aggregate->second.end() ? "@unknown" : field->second;
    return true;
  }

  // `auto` return declarations do not carry `kind == ptr` on the parsed
  // function TypeSpec. For bounded result paths (match/ifv), identify raw
  // pointer payload bindings and pointer-typed fields read through those
  // bindings. Scalar fields remain eligible; unresolved field layouts fail
  // closed because the result may be a raw pointer with unknown provenance.
  static bool findUntrackedPointerMatchPayloadResult(
      const Node *n,
      const std::map<std::string, std::vector<std::string>> &enumPayloadTypes,
      const std::map<std::string, std::map<std::string, std::string>> &fieldTypes,
      const std::map<std::string, std::string> &activePointerBindings,
      std::string &binding) {
    if (!n || n->k == NK::Lambda || n->k == NK::Func) return false;
    if (n->k == NK::Ident) {
      if (activePointerBindings.count(n->s)) {
        binding = n->s;
        return true;
      }
      return false;
    }
    if (n->k == NK::Member) {
      std::string memberType, rootBinding;
      if (resolveUntrackedPayloadMemberType(n, fieldTypes, activePointerBindings,
                                            memberType, rootBinding) &&
          isUntrackedPointerPayloadType(memberType)) {
        binding = rootBinding;
        return true;
      }
      return false;
    }
    if (n->k == NK::IfV) {
      if (n->c.size() < 3 || (n->c.size() % 2) == 0) return false;
      const size_t elseIndex = n->c.size() - 1;
      for (size_t valueIndex = 1; valueIndex < elseIndex; valueIndex += 2)
        if (findUntrackedPointerMatchPayloadResult(n->c[valueIndex].get(), enumPayloadTypes,
                                                   fieldTypes, activePointerBindings,
                                                   binding)) return true;
      return findUntrackedPointerMatchPayloadResult(n->c[elseIndex].get(), enumPayloadTypes,
                                                     fieldTypes, activePointerBindings,
                                                     binding);
    }
    if (n->k == NK::MatchExpr) {
      for (const auto &branch : n->cases) {
        std::map<std::string, std::string> branchBindings = activePointerBindings;
        const std::string key = branch.variantEnum + "::" + branch.variantName;
        const auto payload = enumPayloadTypes.find(key);
        for (size_t i = 0; i < branch.bindings.size(); ++i) {
          const std::string &name = branch.bindings[i];
          if (name.empty() || name == "_") continue;
          // A pattern binding shadows an outer binding with the same name.
          // Drop the outer type before classifying the inner payload.
          branchBindings.erase(name);
          // Unknown imported/generic payload layouts are conservatively
          // treated as pointer-capable. Known scalar payloads remain allowed.
          std::string payloadType = "@unknown";
          if (payload != enumPayloadTypes.end() && i < payload->second.size())
            payloadType = payload->second[i];
          if (isUntrackedPointerPayloadType(payloadType))
            branchBindings[name] = payloadType;
        }
        if (findUntrackedPointerMatchPayloadResult(branch.exprBody.get(), enumPayloadTypes,
                                                   fieldTypes, branchBindings, binding)) return true;
      }
      return findUntrackedPointerMatchPayloadResult(n->deflt.get(), enumPayloadTypes,
                                                    fieldTypes, activePointerBindings,
                                                    binding);
    }
    if (n->k == NK::Binary && n->c.size() == 2 &&
        (n->s == "+" || n->s == "-")) {
      // Pointer arithmetic preserves an untracked payload pointer. Pointer
      // subtraction is scalar only when both operands are pointer-valued;
      // comparisons and other scalar operators intentionally remain outside
      // this result-path check.
      std::string leftBinding, rightBinding;
      const bool leftPointer = findUntrackedPointerMatchPayloadResult(
          n->c[0].get(), enumPayloadTypes, fieldTypes, activePointerBindings, leftBinding);
      const bool rightPointer = findUntrackedPointerMatchPayloadResult(
          n->c[1].get(), enumPayloadTypes, fieldTypes, activePointerBindings, rightBinding);
      const bool pointerResult = n->s == "+" ? (leftPointer || rightPointer) :
                                 (leftPointer && !rightPointer);
      if (pointerResult) {
        binding = leftPointer ? leftBinding : rightBinding;
        return true;
      }
      return false;
    }
    if (n->k == NK::Assign && n->c.size() == 2) {
      std::string resultBinding;
      if (n->s == "=") {
        // An assignment expression yields the assigned value, not the target
        // lvalue. Track the RHS so assigning null/scalars remains non-pointer.
        if (findUntrackedPointerMatchPayloadResult(
                n->c[1].get(), enumPayloadTypes, fieldTypes,
                activePointerBindings, resultBinding)) {
          binding = resultBinding;
          return true;
        }
        return false;
      }
      if (n->s == "+=" || n->s == "-=") {
        // Compound pointer arithmetic yields the updated pointer value.
        if (findUntrackedPointerMatchPayloadResult(
                n->c[0].get(), enumPayloadTypes, fieldTypes,
                activePointerBindings, resultBinding)) {
          binding = resultBinding;
          return true;
        }
        return false;
      }
    }
    if (n->k == NK::PostInc && n->c.size() == 1) {
      if (findUntrackedPointerMatchPayloadResult(
              n->c[0].get(), enumPayloadTypes, fieldTypes,
              activePointerBindings, binding)) return true;
      return false;
    }
    if (n->k == NK::Unary && n->c.size() == 1 &&
        (n->s == "++" || n->s == "--")) {
      if (findUntrackedPointerMatchPayloadResult(
              n->c[0].get(), enumPayloadTypes, fieldTypes,
              activePointerBindings, binding)) return true;
      return false;
    }
    // Do not descend into arbitrary operators/calls: a pointer payload used
    // for a comparison or as an argument is not itself the returned value.
    return false;
  }

  [[noreturn]] static void failOverlap(const Node *call, const std::string &name,
                                       size_t a, size_t b, const std::string &root) {
    std::ostringstream msg;
    msg << "strict-ownership: mutable borrow conflict in call '" << name
        << "': arguments " << (a + 1) << " and " << (b + 1)
        << " may alias the same storage '" << root
        << "' (use distinct storage or redesign the API)";
    throw CompileError(call ? call->line : 0, msg.str());
  }

  [[noreturn]] static void failImmutableWrite(const Node *node, const std::string &name) {
    throw CompileError(node ? node->line : 0,
      "strict-ownership: cannot modify '" + name + "' through an immutable borrow (ref const)");
  }

  [[noreturn]] static void failImmutableReceiverCall(const Node *node, const std::string &name,
                                                      const std::string &method) {
    throw CompileError(node ? node->line : 0,
      "strict-ownership: cannot call member '" + method + "' through immutable borrow '" + name +
      "' because the method is not declared const");
  }

  void inspectCall(const Node *n, const std::set<std::string> &immutableRefs,
                   const std::map<std::string, std::string> &immutableRefTypes,
                   const std::map<std::string, std::string> &types) const {
    if (!n || n->k != NK::Call || n->c.empty()) return;
    // FAC does not yet have const-qualified instance methods. A method call
    // can mutate an object even when the receiver expression itself is not an
    // assignment. Conservatively reject member calls on a ref-const receiver
    // rather than treating an unknown method as read-only.
    const Node *callee = n->c[0].get();
    if (callee && callee->k == NK::Member && !callee->c.empty()) {
      const std::string receiverRoot = rootOf(callee->c[0].get());
      if (!receiverRoot.empty() && immutableRefs.count(receiverRoot)) {
        bool isConstMethod = false;
        auto typeIt = immutableRefTypes.find(receiverRoot);
        if (typeIt != immutableRefTypes.end() && !typeIt->second.empty()) {
          auto methodIt = constMethods.find(typeIt->second + "::" + callee->s);
          isConstMethod = methodIt != constMethods.end() && methodIt->second;
        }
        if (!isConstMethod) failImmutableReceiverCall(n, receiverRoot, callee->s);
      }
    }
    const std::string name = directCalleeName(n->c[0].get());
    auto it = signatures.find(name);
    if (name.empty() || it == signatures.end()) return; // computed/indirect calls are outside this pass
    const size_t argc = n->c.size() - 1;
    std::vector<const Node *> callArgs;
    callArgs.reserve(argc);
    for (size_t i = 0; i < argc; ++i) callArgs.push_back(n->c[i + 1].get());
    const auto selected = resolveCallContracts(n->c[0].get(), callArgs, types);

    for (size_t i = 0; i < argc; ++i) {
      const std::string argRoot = rootOf(n->c[i + 1].get());
      if (!argRoot.empty() && immutableRefs.count(argRoot)) {
        bool hasCandidate = false;
        bool definitelyMutable = true;
        if (!selected.empty()) {
          for (const auto *contract : selected) {
            if (!contract || i >= contract->params.size()) continue;
            hasCandidate = true;
            const auto &param = contract->params[i];
            if (!param.ref || param.immutableRef) { definitelyMutable = false; break; }
          }
        } else {
          for (const auto &mask : it->second) {
            if (mask.size() != argc) continue;
            hasCandidate = true;
            if (mask[i] != 2) { definitelyMutable = false; break; }
          }
        }
        if (hasCandidate && definitelyMutable)
          failImmutableWrite(n, argRoot);
      }

      for (size_t j = i + 1; j < argc; ++j) {
        bool hasCandidate = false;
        bool definitelyConflicting = true;
        if (!selected.empty()) {
          for (const auto *contract : selected) {
            if (!contract || i >= contract->params.size() || j >= contract->params.size()) continue;
            hasCandidate = true;
            const auto mode = [](const CallParamContract &p) -> BorrowMode {
              return !p.ref ? 0 : (p.immutableRef ? 1 : 2);
            };
            const BorrowMode a = mode(contract->params[i]), b = mode(contract->params[j]);
            if (!a || !b || (a == 1 && b == 1)) { definitelyConflicting = false; break; }
          }
        } else {
          for (const auto &mask : it->second) {
            if (mask.size() != argc) continue;
            hasCandidate = true;
            const BorrowMode a = mask[i], b = mask[j];
            if (!a || !b || (a == 1 && b == 1)) { definitelyConflicting = false; break; }
          }
        }
        if (!hasCandidate || !definitelyConflicting) continue;
        const Node *argA = n->c[i + 1].get();
        const Node *argB = n->c[j + 1].get();
        const std::string a = rootOf(argA);
        if (mayAlias(argA, argB)) failOverlap(n, name, i, j, a);
      }
    }
  }

  void inspectImmutableWrites(const Node *n, std::set<std::string> immutableRefs,
                              const std::map<std::string, std::string> &immutableRefTypes,
                              const std::map<std::string, std::string> &types) const {
    if (!n) return;
    // Closures capture ordinary values by value, but capturing `self` from a
    // const method would retain an alias to the same object. Reject that escape
    // until closure capture modes and escape lifetimes are modeled explicitly.
    if (n->k == NK::Lambda) {
      if (immutableRefs.count("self") && !n->c.empty() && referencesName(n->c[0].get(), "self"))
        failImmutableWrite(n, "self (captured by closure)");
      return;
    }
    if (n->k == NK::Block) {
      auto blockTypes = types;
      for (const auto &child : n->c) {
        if (child && child->k == NK::VarDecl) {
          // The initializer is evaluated before the local shadows the parameter.
          if (!child->c.empty()) inspectImmutableWrites(child->c[0].get(), immutableRefs, immutableRefTypes, blockTypes);
          immutableRefs.erase(child->s);
          blockTypes[child->s] = typeKey(child->ts);
        } else {
          inspectImmutableWrites(child.get(), immutableRefs, immutableRefTypes, blockTypes);
        }
      }
      return;
    }
    if (n->k == NK::Assign && !n->c.empty()) {
      const std::string root = rootOf(n->c[0].get());
      if (!root.empty() && immutableRefs.count(root)) failImmutableWrite(n, root);
    }
    if (n->k == NK::PostInc && !n->c.empty()) {
      const std::string root = rootOf(n->c[0].get());
      if (!root.empty() && immutableRefs.count(root)) failImmutableWrite(n, root);
    }
    if (n->k == NK::Unary && (n->s == "++" || n->s == "--") && !n->c.empty()) {
      const std::string root = rootOf(n->c[0].get());
      if (!root.empty() && immutableRefs.count(root)) failImmutableWrite(n, root);
    }
    if (n->k == NK::Call) inspectCall(n, immutableRefs, immutableRefTypes, types);
    for (const auto &c : n->c) inspectImmutableWrites(c.get(), immutableRefs, immutableRefTypes, types);
    for (const auto &m : n->methods) inspectImmutableWrites(m.get(), immutableRefs, immutableRefTypes, types);
    for (const auto &p : n->params) inspectImmutableWrites(p.def.get(), immutableRefs, immutableRefTypes, types);
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) inspectImmutableWrites(v.get(), immutableRefs, immutableRefTypes, types);
      for (const auto &r : cs.ranges) {
        inspectImmutableWrites(r.lo.get(), immutableRefs, immutableRefTypes, types);
        inspectImmutableWrites(r.hi.get(), immutableRefs, immutableRefTypes, types);
      }
      inspectImmutableWrites(cs.body.get(), immutableRefs, immutableRefTypes, types);
      inspectImmutableWrites(cs.guard.get(), immutableRefs, immutableRefTypes, types);
      inspectImmutableWrites(cs.exprBody.get(), immutableRefs, immutableRefTypes, types);
    }
    inspectImmutableWrites(n->deflt.get(), immutableRefs, immutableRefTypes, types);
  }

  void walk(const Node *n, const std::map<std::string, std::string> &types = {}) const {
    if (!n) return;
    if (n->k == NK::Block) {
      auto blockTypes = types;
      for (const auto &child : n->c) {
        if (child && child->k == NK::VarDecl) {
          if (!child->c.empty()) walk(child->c[0].get(), blockTypes);
          blockTypes[child->s] = typeKey(child->ts);
        } else walk(child.get(), blockTypes);
      }
      return;
    }
    if (n->k == NK::Call) inspectCall(n, {}, {}, types);
    for (const auto &c : n->c) walk(c.get(), types);
    for (const auto &m : n->methods) walk(m.get(), types);
    for (const auto &p : n->params) walk(p.def.get(), types);
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) walk(v.get(), types);
      for (const auto &r : cs.ranges) { walk(r.lo.get(), types); walk(r.hi.get(), types); }
      walk(cs.body.get(), types);
      walk(cs.guard.get(), types);
      walk(cs.exprBody.get(), types);
    }
    walk(n->deflt.get(), types);
  }


  [[noreturn]] static void failReadonly(const Node *node, const std::string &message) {
    throw CompileError(node ? node->line : 0, "strict-ownership: " + message);
  }

  bool callParameterReadonly(const std::vector<const FacBorrowChecker::CallContract *> &selected,
                             size_t argumentIndex, size_t argc) const {
    if (selected.empty()) return false;
    for (const auto *contract : selected) {
      if (!contract || argumentIndex >= argc || argumentIndex >= contract->params.size() ||
          !contract->params[argumentIndex].readonly) return false;
    }
    return true;
  }

  static bool referencesAny(const Node *n, const std::set<std::string> &names) {
    if (!n) return false;
    if (n->k == NK::Ident && names.count(n->s)) return true;
    for (const auto &child : n->c) if (referencesAny(child.get(), names)) return true;
    for (const auto &method : n->methods) if (referencesAny(method.get(), names)) return true;
    for (const auto &param : n->params) if (param.def && referencesAny(param.def.get(), names)) return true;
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) if (referencesAny(value.get(), names)) return true;
      for (const auto &range : cs.ranges)
        if (referencesAny(range.lo.get(), names) || referencesAny(range.hi.get(), names)) return true;
      if (referencesAny(cs.guard.get(), names) || referencesAny(cs.body.get(), names) ||
          referencesAny(cs.exprBody.get(), names)) return true;
    }
    return referencesAny(n->deflt.get(), names);
  }

  // A dereference/index expression yields the pointee value rather than
  // forwarding the pointer value itself. Keep pointer arithmetic and other
  // computed pointer expressions visible to call-effect checks.
  static bool pointerValueReferencesAny(const Node *n, const std::set<std::string> &names) {
    if (!n || n->k == NK::Deref || n->k == NK::Index) return false;
    if (n->k == NK::Ident && names.count(n->s)) return true;
    for (const auto &child : n->c) if (pointerValueReferencesAny(child.get(), names)) return true;
    for (const auto &method : n->methods) if (pointerValueReferencesAny(method.get(), names)) return true;
    for (const auto &param : n->params)
      if (param.def && pointerValueReferencesAny(param.def.get(), names)) return true;
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) if (pointerValueReferencesAny(value.get(), names)) return true;
      for (const auto &range : cs.ranges)
        if (pointerValueReferencesAny(range.lo.get(), names) || pointerValueReferencesAny(range.hi.get(), names)) return true;
      if (pointerValueReferencesAny(cs.guard.get(), names) || pointerValueReferencesAny(cs.body.get(), names) ||
          pointerValueReferencesAny(cs.exprBody.get(), names)) return true;
    }
    return pointerValueReferencesAny(n->deflt.get(), names);
  }

  static void collectPointerLocalNames(const Node *n, std::set<std::string> &names) {
    if (!n) return;
    if (n->k == NK::VarDecl && n->ts.kind == "ptr") names.insert(n->s);
    for (const auto &child : n->c) collectPointerLocalNames(child.get(), names);
    for (const auto &method : n->methods) collectPointerLocalNames(method.get(), names);
    for (const auto &cs : n->cases) {
      collectPointerLocalNames(cs.body.get(), names);
      collectPointerLocalNames(cs.exprBody.get(), names);
    }
    collectPointerLocalNames(n->deflt.get(), names);
  }

  void inspectReadonlyEffects(const Node *n, const std::set<std::string> &readonlyParams,
                              const std::set<std::string> &pointerLocals,
                              const std::map<std::string, std::string> &types) const {
    if (!n) return;
    if (n->k == NK::Block) {
      auto blockTypes = types;
      for (const auto &child : n->c) {
        if (child && child->k == NK::VarDecl) {
          if (child->ts.kind == "ptr" && !child->c.empty() && referencesAny(child->c[0].get(), readonlyParams)) {
            failReadonly(child.get(), "readonly contract violation: copying a readonly pointer into a local pointer alias is not supported yet");
          }
          if (!child->c.empty()) inspectReadonlyEffects(child->c[0].get(), readonlyParams, pointerLocals, blockTypes);
          blockTypes[child->s] = typeKey(child->ts);
        } else inspectReadonlyEffects(child.get(), readonlyParams, pointerLocals, blockTypes);
      }
      return;
    }
    if (n->k == NK::Assign && !n->c.empty()) {
      const Node *lhs = n->c[0].get();
      if (lhs && (lhs->k == NK::Index || lhs->k == NK::Deref || lhs->k == NK::Member) &&
          referencesAny(lhs, readonlyParams))
        failReadonly(n, "readonly contract violation: cannot write through or derive a writable location from a readonly pointer parameter");
      if (lhs && lhs->k == NK::Ident && pointerLocals.count(lhs->s) && n->c.size() > 1 &&
          referencesAny(n->c[1].get(), readonlyParams))
        failReadonly(n, "readonly contract violation: storing a readonly pointer into another pointer variable is not supported yet");
    }
    if ((n->k == NK::PostInc || (n->k == NK::Unary && (n->s == "++" || n->s == "--"))) && !n->c.empty()) {
      const Node *lhs = n->c[0].get();
      if (lhs && (lhs->k == NK::Index || lhs->k == NK::Deref || lhs->k == NK::Member) &&
          referencesAny(lhs, readonlyParams))
        failReadonly(n, "readonly contract violation: cannot modify through or derive a writable location from a readonly pointer parameter");
    }
    if (n->k == NK::Call && !n->c.empty()) {
      const Node *callee = n->c[0].get();
      if (callee && callee->k == NK::Member && !callee->c.empty() &&
          referencesAny(callee->c[0].get(), readonlyParams))
        failReadonly(n, "readonly contract violation: method calls through a readonly pointer receiver are not yet effect-verified");
      const size_t argc = n->c.size() - 1;
      std::vector<const Node *> callArgs;
      callArgs.reserve(argc);
      for (size_t i = 0; i < argc; ++i) callArgs.push_back(n->c[i + 1].get());
      const auto selected = resolveCallContracts(callee, callArgs, types);
      for (size_t i = 0; i < argc; ++i) {
        if (pointerValueReferencesAny(n->c[i + 1].get(), readonlyParams) &&
            !callParameterReadonly(selected, i, argc))
          failReadonly(n, "readonly contract violation: pointer derived from a readonly parameter is passed to a call without a verified readonly contract");
      }
    }
    if (n->k == NK::Lambda && !n->c.empty() && referencesAny(n->c.back().get(), readonlyParams))
      failReadonly(n, "readonly contract violation: a readonly pointer parameter cannot be captured by a closure");
    for (const auto &child : n->c) inspectReadonlyEffects(child.get(), readonlyParams, pointerLocals, types);
    for (const auto &method : n->methods) inspectReadonlyEffects(method.get(), readonlyParams, pointerLocals, types);
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) inspectReadonlyEffects(value.get(), readonlyParams, pointerLocals, types);
      for (const auto &range : cs.ranges) {
        inspectReadonlyEffects(range.lo.get(), readonlyParams, pointerLocals, types);
        inspectReadonlyEffects(range.hi.get(), readonlyParams, pointerLocals, types);
      }
      inspectReadonlyEffects(cs.guard.get(), readonlyParams, pointerLocals, types);
      inspectReadonlyEffects(cs.body.get(), readonlyParams, pointerLocals, types);
      inspectReadonlyEffects(cs.exprBody.get(), readonlyParams, pointerLocals, types);
    }
    inspectReadonlyEffects(n->deflt.get(), readonlyParams, pointerLocals, types);
  }

  void checkFunction(const Node *fn, const std::string &owner = {}) {
    if (!fn || fn->k != NK::Func) return;
    for (const auto &p : fn->params) {
      if (p.noescape && (p.ref || p.ts.kind != "ptr" || p.variadic || p.def))
        throw CompileError(fn->line, "strict-ownership: invalid noescape parameter declaration");
      if (p.noescape && !fn->isExtern && fn->c.empty() && !fn->isAbstract)
        throw CompileError(fn->line, "strict-ownership: noescape requires a verifiable FAC body, an abstract contract implemented safely, or an explicit extern trust boundary");
      if (p.readonly && (p.ref || p.ts.kind != "ptr" || p.variadic))
        throw CompileError(fn->line, "strict-ownership: invalid readonly parameter declaration");
      if (p.readonly && !fn->isExtern && fn->c.empty() && !fn->isAbstract)
        throw CompileError(fn->line, "strict-ownership: readonly requires a verifiable FAC body, an abstract contract implemented safely, or an explicit extern trust boundary");
    }
    // Foreign bodies are not visible to the compiler. Their noescape contract
    // is an explicit trusted FFI promise, not a statically verified body fact.
    if (fn->c.empty()) return;
    std::set<std::string> readonlyParams;
    std::map<std::string, std::string> parameterTypes;
    for (const Param &p : fn->params) {
      parameterTypes[p.name] = typeKey(p.ts);
      if (p.readonly) readonlyParams.insert(p.name);
    }
    if (!readonlyParams.empty()) {
      std::set<std::string> pointerLocals;
      collectPointerLocalNames(fn->c[0].get(), pointerLocals);
      inspectReadonlyEffects(fn->c[0].get(), readonlyParams, pointerLocals, parameterTypes);
    }
    for (const auto &p : fn->params) {
      if (p.ref && p.def)
        throw CompileError(fn->line, "strict-ownership: ref parameter cannot have a default value; pass an explicit caller-owned variable");
      if (p.ref && p.variadic)
        throw CompileError(fn->line, "strict-ownership: ref parameter cannot be variadic; use an explicit collection or separate ref parameters");
    }
    std::set<std::string> immutableRefs;
    std::map<std::string, std::string> immutableRefTypes;
    for (const auto &p : fn->params) if (p.ref && p.immutableRef) {
      immutableRefs.insert(p.name);
      if (!p.ts.base.empty()) immutableRefTypes[p.name] = p.ts.base;
    }
    // A const-qualified instance method treats its receiver as an immutable borrow.
    // This catches direct field writes, calls to non-const self methods, and passing
    // self to known mutable-ref parameters. Mutations hidden behind raw pointers/FFI
    // remain outside the static proof and are documented explicitly.
    if (fn->isConst && !owner.empty()) {
      immutableRefs.insert("self");
      immutableRefTypes["self"] = owner;
    }
    if (!fn->c.empty() && !immutableRefs.empty())
      inspectImmutableWrites(fn->c[0].get(), immutableRefs, immutableRefTypes, parameterTypes);
    // Mutable/shared overlap checks are needed in all functions, regardless
    // of whether the current function itself declares borrowed parameters.
    for (const auto &body : fn->c) walk(body.get(), parameterTypes);
  }

  void run(const std::vector<std::unique_ptr<Program>> &programs) {
    collect(programs);
    for (const auto &p : programs) {
      for (const auto &f : p->funcs) checkFunction(f.get());
      for (const auto &s : p->structs) {
        for (const auto &m : s->methods) checkFunction(m.get(), s->s);
        for (const auto &c : s->c) checkFunction(c.get(), s->s);
      }
      for (const auto &g : p->globals) walk(g.get());
    }
  }
};

// Local-borrow checker. Local aliases are true storage aliases in codegen;
// this pass tracks their loans over a per-function CFG. V56 resolves alias and
// owner identities to declarations so lexical shadowing cannot merge storage
// regions. This remains a bounded local analysis, not a general lifetime solver.
class FacLocalBorrowChecker {
  using BorrowMode = FacBorrowChecker::BorrowMode;
  struct Loan {
    std::string alias;
    std::string root;
    const Node *rootDecl = nullptr; // exact owner symbol; null only for parameter/receiver roots
    std::string type;
    BorrowMode mode = 0; // 1 shared, 2 mutable
    bool parameter = false;
    const Node *decl = nullptr;
    const Node *parentDecl = nullptr;
    std::string parentAlias;
    // Exact projections are dotted, metadata-validated field paths. Empty +
    // exact denotes the whole root; unknown/indexed/computed paths are inexact.
    std::string projection;
    bool projectionExact = true;
    size_t region = 0;      // lifetime region in which this alias is declared
    size_t rootRegion = 0;  // owner region; must outlive region
  };
  struct PointerOrigin {
    std::string root;
    const Node *rootDecl = nullptr;
    size_t region = 0;
    int line = 0;
    bool fromNoescapeParameter = false;
    const Param *parameter = nullptr;
  };
  struct ConstantArrayIndex {
    int64_t value = 0;
    unsigned bits = 32;
    bool isUnsigned = false;
  };
  struct ConstIntBinding {
    const Node *decl = nullptr;
    ConstantArrayIndex value;
  };
  struct ConstBoolBinding {
    const Node *decl = nullptr;
    bool value = false;
  };
  struct ConstFloatBinding {
    const Node *decl = nullptr;
    double value = 0.0;
    bool isFloat32 = false;
  };
  struct Context {
    std::map<std::string, Loan> aliases;
    std::vector<Loan> loans;
    std::map<std::string, bool> constVars;
    // Initialized local const integer/character declarations are recorded
    // with their FAC storage width and signedness. A separate bounded map
    // retains supported local const float/double values for projection casts
    // and arithmetic; declaration identity prevents shadowed names inheriting values.
    std::map<std::string, ConstIntBinding> constantInts;
    // Proven initialized local `const boolean` bindings used only by the
    // bounded constant-condition evaluator. Declaration identity prevents a
    // shadowed identifier from inheriting an outer predicate value.
    std::map<std::string, ConstBoolBinding> constantBools;
    // Bounded local const floating values retain stored precision for the
    // floating arithmetic/cast subset used by array-borrow projections.
    std::map<std::string, ConstFloatBinding> constantFloats;
    std::map<std::string, std::string> types;
    std::map<std::string, std::string> typeKeys;
    // Statically declared function-value signatures are retained for indirect
    // call checking. An absent entry for a function-typed local is intentionally
    // conservative: its target/effects are not known to this pass.
    std::map<std::string, FacBorrowChecker::CallContract> functionValueContracts;
    std::map<std::string, const Node *> decls; // nullptr marks a tracked parameter/receiver or non-local binding
    std::map<std::string, size_t> symbolRegions; // lifetime region for parameters and synthetic lexical bindings
    std::map<std::string, size_t> frameStorage; // stack/receiver storage region by visible name
    std::set<std::string> pointerVars;
    std::map<std::string, std::vector<PointerOrigin>> pointerOrigins;
    // V226 tracks pointer provenance by aggregate root and exact field path.
    // This enables field-level overwrite/kill instead of a permanent root union.
    std::map<std::string, std::vector<PointerOrigin>> aggregatePointerOriginsByPath;
    size_t region = 0; // current lexical lifetime region
    const Node *functionRoot = nullptr; // owning function, used for bounded closure-use proof
  };

  struct StoragePath {
    std::string root;
    const Node *rootDecl = nullptr;
    std::string projection;
    bool exact = true;
    std::string raw;
    bool throughAlias = false;
    bool crossesManagedObjectBoundary = false;
  };

  const FacBorrowChecker &base;
  struct FieldContract {
    std::string type;
    bool isConst = false;
    // Function-valued aggregate fields retain the signature contract declared
    // at the field, allowing indirect calls through nested member paths to use
    // the same lifetime substitution as local/parameter function values.
    bool hasFunctionContract = false;
    FacBorrowChecker::CallContract functionContract;
  };
  std::map<std::string, std::map<std::string, FieldContract>> fields;
  std::map<std::string, std::vector<std::string>> fieldOrder;
  std::set<std::string> aggregateTypes;
  // Only value `struct` declarations are eligible for the bounded local
  // pointer-field storage contract in V225. Classes/obj handles are shared
  // heap identities and remain outside this stack-region proof.
  std::set<std::string> valueStructTypes;

  static std::string canonicalAggregateType(std::string type) {
    // Field paths may begin at a value aggregate, a managed `obj` handle, or
    // a managed `obj` handle. Normalize the complete type prefix before field
    // metadata lookup so value-field projections such as `actor.stats.health`
    // can retain field-sensitive alias precision instead of degrading to an
    // unknown whole-object path. Weak handles are deliberately not normalized:
    // they do not by themselves prove that the referenced object is alive.
    for (const char *prefix : {"struct ", "class ", "enum ", "obj "}) {
      const std::string p(prefix);
      if (type.compare(0, p.size(), p) == 0) return type.substr(p.size());
    }
    return type;
  }

  const std::map<std::string, FieldContract> *fieldMapFor(const std::string &type) const {
    auto it = fields.find(type);
    if (it == fields.end()) it = fields.find(canonicalAggregateType(type));
    return it == fields.end() ? nullptr : &it->second;
  }

  bool isValueStructTypeKey(const std::string &type) const {
    constexpr const char *prefix = "struct ";
    if (type.compare(0, 7, prefix) != 0) return false;
    return valueStructTypes.count(type.substr(7)) != 0;
  }

  bool isValueStructConstructorCall(const Node *call) const {
    return call && call->k == NK::Call && !call->c.empty() && call->c[0] &&
           call->c[0]->k == NK::Ident && valueStructTypes.count(call->c[0]->s) != 0;
  }

  static bool isNullPointerValue(const Node *expr) {
    return expr && expr->k == NK::NullLit;
  }

  // A pointer local may carry an exact empty provenance fact. This is distinct
  // from a missing map entry: the former proves the value is null, the latter
  // means the analysis cannot establish where the pointer came from.
  bool isVerifiedNullPointerValue(const Node *expr, const Context &ctx) const {
    if (isNullPointerValue(expr)) return true;
    if (!expr) return false;
    if (expr->k == NK::Ident && ctx.pointerVars.count(expr->s)) {
      auto fact = ctx.pointerOrigins.find(expr->s);
      return fact != ctx.pointerOrigins.end() && fact->second.empty();
    }
    if (expr->k == NK::Member && expressionType(expr, ctx).compare(0, 4, "ptr ") == 0) {
      const StoragePath path = resolvedStoragePath(expr, ctx);
      if (!path.exact || path.root.empty() || path.crossesManagedObjectBoundary) return false;
      auto fact = ctx.aggregatePointerOriginsByPath.find(
          aggregateOriginKey(path.root, path.projection));
      return fact != ctx.aggregatePointerOriginsByPath.end() && fact->second.empty();
    }
    return false;
  }

  // V56: local-borrow liveness is keyed by AST declaration identity, not by
  // identifier spelling. The resolver below binds each identifier occurrence
  // to the declaration visible at that point, so a shadowing local cannot
  // accidentally keep an unrelated outer loan alive (or release it early).
  using LoanSymbolSet = std::set<const Node *>;
  using LoanEnv = std::map<std::string, const Node *>; // nullptr means a non-loan shadowing declaration
  struct LoanBlock {
    const Node *syntax = nullptr;
    std::vector<int> succ;
    LoanSymbolSet use, in, out;
  };
  struct FlowTarget {
    std::string label;
    int breakTarget = -1;
    int continueTarget = -1;
    bool isLoop = true;
    size_t finalizerDepth = 0;
  };
  struct ExceptionTarget {
    int handler = -1;
    size_t finalizerDepth = 0;
  };
  struct FlowFinalizer {
    const Node *syntax = nullptr;
    std::vector<ExceptionTarget> outerExceptions;
  };
  struct LifetimeRegion {
    size_t id = 0;
    size_t parent = 0;
    const Node *owner = nullptr;
  };
  struct LifetimeConstraint {
    size_t longer = 0;
    size_t shorter = 0;
    const Node *at = nullptr;
    const Node *ownerDecl = nullptr;
    bool pointerStorage = false;
    bool externalDestination = false;
    std::string destination;
  };
  std::vector<LoanBlock> loanCfg;
  std::unordered_map<const Node *, std::pair<LoanSymbolSet, LoanSymbolSet>> flowAt;
  std::unordered_map<const Node *, const Node *> flowIdentSymbols;
  LoanSymbolSet flowAliasDecls, flowPinned;
  std::vector<FlowFinalizer> flowFinalizers;
  std::vector<ExceptionTarget> flowExceptions;
  mutable std::vector<LifetimeRegion> lifetimeRegions;
  mutable std::unordered_map<const Node *, size_t> lifetimeRegionOfDecl;
  // Re-analysis of loop bodies must reuse the same lexical region for the
  // same syntax node under the same parent. Otherwise each fixed-point pass
  // would manufacture fresh region IDs and pointer-origin facts could never
  // converge.
  mutable std::map<std::pair<size_t, const Node *>, size_t> lifetimeRegionByOwner;
  mutable std::vector<std::pair<size_t, size_t>> lifetimeRegionOutlivesEdges;
  mutable std::unordered_map<int, size_t> functionLifetimeParamRegions;
  mutable std::vector<LifetimeConstraint> lifetimeConstraints;
  mutable size_t functionReturnLifetimeRegion = static_cast<size_t>(-1);
  // Flow-insensitive may-origin facts keyed by pointer-variable declaration.
  // The set is deliberately monotone across branches/blocks to avoid losing
  // provenance when a pointer is assigned on only one control-flow path.
  mutable std::unordered_map<const Node *, std::vector<PointerOrigin>> pointerOriginsByDecl;
  int flowExit = -1;

  [[noreturn]] static void fail(const Node *n, const std::string &message) {
    throw CompileError(n ? n->line : 0, "strict-ownership: " + message);
  }

  // A defer body executes at scope exit, not at its source position. A local
  // loan referenced by defer must therefore stay live until the block ends.
  static bool deferredReferences(const Node *n, const std::string &name) {
    if (!n) return false;
    if (n->k == NK::Defer && !n->c.empty() &&
        FacBorrowChecker::referencesName(n->c[0].get(), name)) return true;
    for (const auto &child : n->c)
      if (deferredReferences(child.get(), name)) return true;
    for (const auto &method : n->methods)
      if (deferredReferences(method.get(), name)) return true;
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals)
        if (deferredReferences(value.get(), name)) return true;
      for (const auto &range : cs.ranges)
        if (deferredReferences(range.lo.get(), name) || deferredReferences(range.hi.get(), name)) return true;
      if (deferredReferences(cs.guard.get(), name) ||
          deferredReferences(cs.body.get(), name) ||
          deferredReferences(cs.exprBody.get(), name)) return true;
    }
    return deferredReferences(n->deflt.get(), name);
  }

  static std::string rawRoot(const Node *n) {
    return FacBorrowChecker::rootOf(n);
  }

  int addLoanBlock(const Node *syntax, std::vector<int> succ = {}) {
    LoanBlock block;
    block.syntax = syntax;
    block.succ = std::move(succ);
    loanCfg.push_back(std::move(block));
    return static_cast<int>(loanCfg.size() - 1);
  }

  // V196: resolve only side-effect-free Boolean forms whose value is explicit
  // in the syntax. This is used solely to prune impossible CFG edges; identifiers,
  // calls, arithmetic and floating-point comparisons remain unknown so the
  // borrow checker never guesses based on runtime state or host FP behavior.
  static bool loanConstantTruth(const Node *condition, bool &value) {
    if (!condition) return false;
    if (condition->k == NK::BoolLit) {
      value = condition->b;
      return true;
    }
    if (condition->k == NK::Unary && condition->s == "!" && condition->c.size() == 1) {
      bool operand = false;
      if (!loanConstantTruth(condition->c[0].get(), operand)) return false;
      value = !operand;
      return true;
    }
    if (condition->k != NK::Binary || condition->c.size() != 2) return false;
    const std::string &op = condition->s;
    if (op == "&&" || op == "||") {
      bool left = false;
      if (!loanConstantTruth(condition->c[0].get(), left)) return false;
      if (op == "&&" && !left) { value = false; return true; }
      if (op == "||" && left) { value = true; return true; }
      bool right = false;
      if (!loanConstantTruth(condition->c[1].get(), right)) return false;
      value = op == "&&" ? (left && right) : (left || right);
      return true;
    }
    const Node *lhs = condition->c[0].get();
    const Node *rhs = condition->c[1].get();
    if (lhs->k == NK::IntLit && rhs->k == NK::IntLit) {
      const int64_t a = lhs->iv, b = rhs->iv;
      if (op == "==") value = a == b;
      else if (op == "!=") value = a != b;
      else if (op == "<") value = a < b;
      else if (op == "<=") value = a <= b;
      else if (op == ">") value = a > b;
      else if (op == ">=") value = a >= b;
      else return false;
      return true;
    }
    if (lhs->k == NK::BoolLit && rhs->k == NK::BoolLit &&
        (op == "==" || op == "!=")) {
      value = op == "==" ? lhs->b == rhs->b : lhs->b != rhs->b;
      return true;
    }
    return false;
  }

  static std::vector<int> loanBranchEdges(const Node *condition, int yes, int no) {
    bool known = false;
    if (loanConstantTruth(condition, known))
      return known ? std::vector<int>{yes} : std::vector<int>{no};
    return {yes, no};
  }

  std::vector<int> withLoanExceptionEdges(std::vector<int> succ,
                                          const std::vector<FlowTarget> &targets) {
    // Calls, allocation and other expression evaluation may raise. The frontend
    // does not yet have per-call `nothrow` effects, so every expression in a
    // protected region gets a conservative exceptional successor.
    if (!flowExceptions.empty()) {
      const ExceptionTarget target = flowExceptions.back();
      const int exceptional = routeLoanFinalizers(target.handler, target.finalizerDepth, targets);
      if (exceptional >= 0 && std::find(succ.begin(), succ.end(), exceptional) == succ.end())
        succ.push_back(exceptional);
    }
    return succ;
  }

  int loanExprBlock(const Node *expr, int next, const std::vector<FlowTarget> &targets) {
    if (!expr) return next;
    std::vector<int> succ;
    if (next >= 0) succ.push_back(next);
    return addLoanBlock(expr, withLoanExceptionEdges(std::move(succ), targets));
  }

  int loanExprBlock(const Node *expr, std::vector<int> succ,
                    const std::vector<FlowTarget> &targets) {
    if (!expr) return succ.empty() ? -1 : succ.front();
    return addLoanBlock(expr, withLoanExceptionEdges(std::move(succ), targets));
  }

  int routeLoanFinalizers(int target, size_t keepDepth,
                          const std::vector<FlowTarget> &targets) {
    int routed = target;
    if (keepDepth > flowFinalizers.size()) keepDepth = flowFinalizers.size();
    for (size_t depth = flowFinalizers.size(); depth > keepDepth; --depth) {
      const FlowFinalizer finalizer = flowFinalizers[depth - 1];
      std::vector<FlowFinalizer> savedFinalizers = flowFinalizers;
      std::vector<ExceptionTarget> savedExceptions = flowExceptions;
      flowFinalizers.resize(depth - 1);
      // An exception raised by a finally body must continue outward; it must
      // not be caught by the try whose finally is currently executing.
      flowExceptions = finalizer.outerExceptions;
      routed = buildLoanStmt(finalizer.syntax, routed, targets);
      flowFinalizers.swap(savedFinalizers);
      flowExceptions.swap(savedExceptions);
    }
    return routed;
  }

  int loanTargetFor(const std::vector<FlowTarget> &targets,
                    const std::string &label, bool wantContinue) {
    for (auto it = targets.rbegin(); it != targets.rend(); ++it) {
      if (!label.empty() && (!it->isLoop || it->label != label)) continue;
      if (wantContinue && !it->isLoop) continue;
      const int target = wantContinue ? it->continueTarget : it->breakTarget;
      if (target >= 0) return routeLoanFinalizers(target, it->finalizerDepth, targets);
    }
    return routeLoanFinalizers(flowExit, 0, targets);
  }

  int buildLoanStmt(const Node *n, int next, std::vector<FlowTarget> targets) {
    if (!n) return next;
    switch (n->k) {
      case NK::Block: {
        int entry = next;
        for (auto it = n->c.rbegin(); it != n->c.rend(); ++it)
          entry = buildLoanStmt(it->get(), entry, targets);
        return entry;
      }
      case NK::VarDecl:
      case NK::ExprStmt:
        return loanExprBlock(n, next, targets);
      case NK::Defer:
        return addLoanBlock(n, {next});
      case NK::If: {
        const int yes = n->c.size() > 1 ? buildLoanStmt(n->c[1].get(), next, targets) : next;
        const int no = n->c.size() > 2 ? buildLoanStmt(n->c[2].get(), next, targets) : next;
        if (n->c.empty()) return addLoanBlock(n, {yes, no});
        return loanExprBlock(n->c[0].get(), loanBranchEdges(n->c[0].get(), yes, no), targets);
      }
      case NK::While: {
        const int cond = addLoanBlock(n->c.empty() ? n : n->c[0].get());
        targets.push_back({n->label, next, cond, true, flowFinalizers.size()});
        const int body = n->c.size() > 1 ? buildLoanStmt(n->c[1].get(), cond, targets) : cond;
        loanCfg[cond].succ = withLoanExceptionEdges(loanBranchEdges(n->c.empty() ? nullptr : n->c[0].get(), body, next), targets);
        return cond;
      }
      case NK::DoWhile: {
        const int cond = addLoanBlock(n->c.size() > 1 ? n->c[1].get() : n);
        targets.push_back({n->label, next, cond, true, flowFinalizers.size()});
        const int body = !n->c.empty() ? buildLoanStmt(n->c[0].get(), cond, targets) : cond;
        loanCfg[cond].succ = withLoanExceptionEdges(loanBranchEdges(n->c.size() > 1 ? n->c[1].get() : nullptr, body, next), targets);
        return body;
      }
      case NK::For: {
        const int cond = addLoanBlock(n->c.size() > 1 && n->c[1] ? n->c[1].get() : n);
        int step = cond;
        if (n->c.size() > 2 && n->c[2]) step = buildLoanStmt(n->c[2].get(), cond, targets);
        targets.push_back({n->label, next, step, true, flowFinalizers.size()});
        const int body = n->c.size() > 3 ? buildLoanStmt(n->c[3].get(), step, targets) : step;
        loanCfg[cond].succ = (n->c.size() > 1 && n->c[1])
          ? withLoanExceptionEdges(loanBranchEdges(n->c[1].get(), body, next), targets)
          : withLoanExceptionEdges(std::vector<int>{body}, targets);
        return n->c.size() > 0 && n->c[0]
          ? buildLoanStmt(n->c[0].get(), cond, targets) : cond;
      }
      case NK::ForPP: case NK::ForEach: {
        const int head = addLoanBlock(n);
        targets.push_back({n->label, next, head, true, flowFinalizers.size()});
        const int body = n->c.size() > 1 ? buildLoanStmt(n->c[1].get(), head, targets) : head;
        loanCfg[head].succ = {body, next};
        return loanExprBlock(n->c.empty() ? nullptr : n->c[0].get(), head, targets);
      }
      case NK::Switch: case NK::Match: {
        std::vector<FlowTarget> branchTargets = targets;
        branchTargets.push_back({{}, next, -1, false, flowFinalizers.size()});
        std::vector<int> entries;
        for (const auto &cs : n->cases) {
          int entry = cs.body ? buildLoanStmt(cs.body.get(), next, branchTargets) : next;
          if (cs.exprBody) entry = loanExprBlock(cs.exprBody.get(), entry, branchTargets);
          if (cs.guard) entry = loanExprBlock(cs.guard.get(), entry, branchTargets);
          std::vector<const Node *> exprs;
          for (const auto &v : cs.vals) exprs.push_back(v.get());
          for (const auto &r : cs.ranges) { exprs.push_back(r.lo.get()); exprs.push_back(r.hi.get()); }
          for (auto it = exprs.rbegin(); it != exprs.rend(); ++it) entry = loanExprBlock(*it, entry, branchTargets);
          entries.push_back(entry);
        }
        entries.push_back(n->deflt ? buildLoanStmt(n->deflt.get(), next, branchTargets) : next);
        const int dispatch = addLoanBlock(n, std::move(entries));
        return loanExprBlock(n->c.empty() ? nullptr : n->c[0].get(), dispatch, targets);
      }
      case NK::Try: {
        const bool hasFinally = n->c.size() > 2 && n->c[2];
        const bool hasCatch = n->c.size() > 1 && n->c[1];
        const size_t outerFinalizerDepth = flowFinalizers.size();
        const ExceptionTarget outerException = flowExceptions.empty()
          ? ExceptionTarget{flowExit, 0} : flowExceptions.back();
        int finalEntry = next;
        if (hasFinally) finalEntry = buildLoanStmt(n->c[2].get(), next, targets);
        if (hasFinally) flowFinalizers.push_back(FlowFinalizer{n->c[2].get(), flowExceptions});

        // Exceptions raised inside a catch are not handled by that same catch;
        // they execute this try's finally and continue to an outer handler.
        const int catcher = hasCatch
          ? buildLoanStmt(n->c[1].get(), finalEntry, targets) : finalEntry;

        if (hasCatch) {
          // Body exceptions enter the catch without running this try's finally;
          // the catch's normal/exceptional exits then pass through finally.
          flowExceptions.push_back(ExceptionTarget{catcher, flowFinalizers.size()});
        } else {
          // A try/finally without catch propagates outward after its cleanup.
          flowExceptions.push_back(ExceptionTarget{outerException.handler, outerFinalizerDepth});
        }
        const int body = n->c.size() > 0 && n->c[0]
          ? buildLoanStmt(n->c[0].get(), finalEntry, targets) : finalEntry;
        flowExceptions.pop_back();
        if (hasFinally) flowFinalizers.pop_back();
        return addLoanBlock(n, hasCatch ? std::vector<int>{body, catcher}
                                        : std::vector<int>{body});
      }
      case NK::Return:
        return loanExprBlock(n, std::vector<int>{routeLoanFinalizers(flowExit, 0, targets)}, targets);
      case NK::Throw: {
        const ExceptionTarget target = flowExceptions.empty()
          ? ExceptionTarget{flowExit, 0} : flowExceptions.back();
        return addLoanBlock(n, {routeLoanFinalizers(target.handler, target.finalizerDepth, targets)});
      }
      case NK::Break:
        return addLoanBlock(n, {loanTargetFor(targets, n->label, false)});
      case NK::Continue:
        return addLoanBlock(n, {loanTargetFor(targets, n->label, true)});
      default:
        return addLoanBlock(n, {next});
    }
  }

  void collectLoanAliases(const Node *n) {
    if (!n) return;
    if (n->k == NK::VarDecl && n->isRef) flowAliasDecls.insert(n);
    for (const auto &child : n->c) collectLoanAliases(child.get());
    for (const auto &method : n->methods) collectLoanAliases(method.get());
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) collectLoanAliases(value.get());
      for (const auto &range : cs.ranges) {
        collectLoanAliases(range.lo.get()); collectLoanAliases(range.hi.get());
      }
      collectLoanAliases(cs.guard.get()); collectLoanAliases(cs.body.get());
      collectLoanAliases(cs.exprBody.get());
    }
    collectLoanAliases(n->deflt.get());
  }

  // Resolve every identifier occurrence against the lexical environment. A
  // null binding is intentional: it records that a non-borrow declaration
  // shadows an outer borrow alias with the same spelling.
  void bindFlowExpr(const Node *n, LoanEnv &env) {
    if (!n) return;
    if (n->k == NK::Ident) {
      auto it = env.find(n->s);
      if (it != env.end() && it->second && flowAliasDecls.count(it->second))
        flowIdentSymbols[n] = it->second;
      return;
    }
    if (n->k == NK::Lambda) {
      LoanEnv local = env;
      for (const auto &param : n->params) {
        if (param.def) bindFlowExpr(param.def.get(), local);
        local[param.name] = nullptr;
      }
      if (!n->c.empty()) bindFlowStmt(n->c.back().get(), local);
      return;
    }
    if (n->k == NK::MatchExpr) {
      if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
      for (const auto &cs : n->cases) {
        LoanEnv branch = env;
        for (const auto &name : cs.bindings) branch[name] = nullptr;
        for (const auto &value : cs.vals) bindFlowExpr(value.get(), branch);
        for (const auto &range : cs.ranges) {
          bindFlowExpr(range.lo.get(), branch); bindFlowExpr(range.hi.get(), branch);
        }
        bindFlowExpr(cs.guard.get(), branch);
        bindFlowExpr(cs.exprBody.get(), branch);
      }
      bindFlowExpr(n->deflt.get(), env);
      return;
    }
    for (const auto &child : n->c) bindFlowExpr(child.get(), env);
    for (const auto &method : n->methods) bindFlowExpr(method.get(), env);
    for (const auto &param : n->params) if (param.def) bindFlowExpr(param.def.get(), env);
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) bindFlowExpr(value.get(), env);
      for (const auto &range : cs.ranges) {
        bindFlowExpr(range.lo.get(), env); bindFlowExpr(range.hi.get(), env);
      }
      bindFlowExpr(cs.guard.get(), env); bindFlowStmt(cs.body.get(), env);
      bindFlowExpr(cs.exprBody.get(), env);
    }
    bindFlowStmt(n->deflt.get(), env);
  }

  void bindFlowStmt(const Node *n, LoanEnv &env) {
    if (!n) return;
    switch (n->k) {
      case NK::Block: {
        LoanEnv local = env;
        for (const auto &child : n->c) bindFlowStmt(child.get(), local);
        return;
      }
      case NK::VarDecl:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env); // initializer sees the previous binding
        env[n->s] = n->isRef ? n : nullptr;
        return;
      case NK::If:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
        if (n->c.size() > 1) { LoanEnv branch = env; bindFlowStmt(n->c[1].get(), branch); }
        if (n->c.size() > 2) { LoanEnv branch = env; bindFlowStmt(n->c[2].get(), branch); }
        return;
      case NK::While:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
        if (n->c.size() > 1) { LoanEnv loop = env; bindFlowStmt(n->c[1].get(), loop); }
        return;
      case NK::DoWhile:
        if (!n->c.empty()) { LoanEnv loop = env; bindFlowStmt(n->c[0].get(), loop); }
        if (n->c.size() > 1) bindFlowExpr(n->c[1].get(), env);
        return;
      case NK::For: {
        LoanEnv loop = env;
        if (n->c.size() > 0 && n->c[0]) bindFlowStmt(n->c[0].get(), loop);
        if (n->c.size() > 1) bindFlowExpr(n->c[1].get(), loop);
        if (n->c.size() > 2) bindFlowStmt(n->c[2].get(), loop);
        if (n->c.size() > 3) bindFlowStmt(n->c[3].get(), loop);
        return;
      }
      case NK::ForPP:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
        if (n->c.size() > 1) { LoanEnv loop = env; bindFlowStmt(n->c[1].get(), loop); }
        return;
      case NK::ForEach:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
        if (n->c.size() > 1) {
          LoanEnv loop = env;
          loop[n->s] = nullptr; // foreach iteration variable shadows outer names
          bindFlowStmt(n->c[1].get(), loop);
        }
        return;
      case NK::Switch: case NK::Match:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
        for (const auto &cs : n->cases) {
          LoanEnv branch = env;
          for (const auto &name : cs.bindings) branch[name] = nullptr;
          for (const auto &value : cs.vals) bindFlowExpr(value.get(), branch);
          for (const auto &range : cs.ranges) {
            bindFlowExpr(range.lo.get(), branch); bindFlowExpr(range.hi.get(), branch);
          }
          bindFlowExpr(cs.guard.get(), branch); bindFlowStmt(cs.body.get(), branch);
          bindFlowExpr(cs.exprBody.get(), branch);
        }
        if (n->deflt) { LoanEnv branch = env; bindFlowStmt(n->deflt.get(), branch); }
        return;
      case NK::Try:
        if (n->c.size() > 0 && n->c[0]) { LoanEnv branch = env; bindFlowStmt(n->c[0].get(), branch); }
        if (n->c.size() > 1 && n->c[1]) {
          LoanEnv catcher = env;
          if (!n->s.empty()) catcher[n->s] = nullptr;
          bindFlowStmt(n->c[1].get(), catcher);
        }
        if (n->c.size() > 2 && n->c[2]) { LoanEnv finalizer = env; bindFlowStmt(n->c[2].get(), finalizer); }
        return;
      case NK::Defer:
        if (!n->c.empty()) { LoanEnv deferred = env; bindFlowStmt(n->c[0].get(), deferred); }
        return;
      case NK::Return: case NK::Throw: case NK::ExprStmt:
        if (!n->c.empty()) bindFlowExpr(n->c[0].get(), env);
        return;
      default:
        bindFlowExpr(n, env);
        return;
    }
  }

  void collectResolvedLoanUses(const Node *n, LoanSymbolSet &out) const {
    if (!n) return;
    if (n->k == NK::Ident) {
      auto it = flowIdentSymbols.find(n);
      if (it != flowIdentSymbols.end()) out.insert(it->second);
      return;
    }
    for (const auto &child : n->c) collectResolvedLoanUses(child.get(), out);
    for (const auto &method : n->methods) collectResolvedLoanUses(method.get(), out);
    for (const auto &param : n->params) if (param.def) collectResolvedLoanUses(param.def.get(), out);
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) collectResolvedLoanUses(value.get(), out);
      for (const auto &range : cs.ranges) {
        collectResolvedLoanUses(range.lo.get(), out); collectResolvedLoanUses(range.hi.get(), out);
      }
      collectResolvedLoanUses(cs.guard.get(), out);
      collectResolvedLoanUses(cs.body.get(), out);
      collectResolvedLoanUses(cs.exprBody.get(), out);
    }
    collectResolvedLoanUses(n->deflt.get(), out);
  }

  void pinComplexFlowUses(const Node *n, const std::set<const Node *> &reachableSyntax) {
    if (!n) return;
    // Defer executes at lexical scope exit and remains conservatively pinned,
    // but an unreachable defer cannot extend a loan. Try/catch/finally uses
    // are represented by explicit exceptional CFG edges.
    if (n->k == NK::Defer && reachableSyntax.count(n))
      collectResolvedLoanUses(n, flowPinned);
    for (const auto &child : n->c) pinComplexFlowUses(child.get(), reachableSyntax);
    for (const auto &method : n->methods) pinComplexFlowUses(method.get(), reachableSyntax);
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) pinComplexFlowUses(value.get(), reachableSyntax);
      for (const auto &range : cs.ranges) {
        pinComplexFlowUses(range.lo.get(), reachableSyntax);
        pinComplexFlowUses(range.hi.get(), reachableSyntax);
      }
      pinComplexFlowUses(cs.guard.get(), reachableSyntax);
      pinComplexFlowUses(cs.body.get(), reachableSyntax);
      pinComplexFlowUses(cs.exprBody.get(), reachableSyntax);
    }
    pinComplexFlowUses(n->deflt.get(), reachableSyntax);
  }

  void prepareLoanFlow(const Node *fn) {
    loanCfg.clear(); flowAt.clear(); flowIdentSymbols.clear(); flowAliasDecls.clear();
    flowPinned.clear(); flowFinalizers.clear(); flowExceptions.clear();
    collectLoanAliases(fn->c[0].get());
    if (flowAliasDecls.empty()) return;
    LoanEnv env;
    for (const Param &param : fn->params) env[param.name] = nullptr;
    env["self"] = nullptr;
    bindFlowStmt(fn->c[0].get(), env);

    loanCfg.push_back(LoanBlock{}); // exit sink
    flowExit = 0;
    const int entry = buildLoanStmt(fn->c[0].get(), flowExit, {});
    if (entry < 0) return;

    // Determine actual CFG reachability before solving backward liveness.
    // Without this pass, dead branches still contributed uses to their own
    // blocks and could keep a loan alive while the AST checker visited code
    // that can never execute (for example the else arm of `if (true)`).
    std::vector<bool> reachable(loanCfg.size(), false);
    std::deque<int> reachWork;
    if (entry >= 0 && static_cast<size_t>(entry) < loanCfg.size()) {
      reachable[entry] = true;
      reachWork.push_back(entry);
    }
    while (!reachWork.empty()) {
      const int id = reachWork.front();
      reachWork.pop_front();
      for (int succ : loanCfg[id].succ) {
        if (succ < 0 || static_cast<size_t>(succ) >= loanCfg.size() || reachable[succ]) continue;
        reachable[succ] = true;
        reachWork.push_back(succ);
      }
    }

    std::set<const Node *> reachableSyntax;
    std::vector<std::vector<int>> pred(loanCfg.size());
    for (size_t i = 0; i < loanCfg.size(); ++i) {
      LoanBlock &block = loanCfg[i];
      if (!reachable[i]) continue;
      if (block.syntax) {
        reachableSyntax.insert(block.syntax);
        collectResolvedLoanUses(block.syntax, block.use);
      }
      for (int succ : block.succ)
        if (succ >= 0 && static_cast<size_t>(succ) < pred.size() && reachable[succ])
          pred[succ].push_back(static_cast<int>(i));
    }
    pinComplexFlowUses(fn->c[0].get(), reachableSyntax);

    std::deque<int> work;
    std::vector<bool> queued(loanCfg.size(), false);
    for (size_t i = 0; i < loanCfg.size(); ++i) {
      if (!reachable[i]) continue;
      queued[i] = true;
      work.push_back(static_cast<int>(i));
    }
    while (!work.empty()) {
      const int id = work.front(); work.pop_front(); queued[id] = false;
      LoanSymbolSet out;
      for (int succ : loanCfg[id].succ)
        if (succ >= 0 && static_cast<size_t>(succ) < loanCfg.size() && reachable[succ])
          out.insert(loanCfg[succ].in.begin(), loanCfg[succ].in.end());
      LoanSymbolSet in = loanCfg[id].use;
      in.insert(out.begin(), out.end());
      if (out != loanCfg[id].out || in != loanCfg[id].in) {
        loanCfg[id].out.swap(out); loanCfg[id].in.swap(in);
        for (int p : pred[id]) if (!queued[p]) { queued[p] = true; work.push_back(p); }
      }
    }
    for (size_t i = 0; i < loanCfg.size(); ++i) {
      const LoanBlock &block = loanCfg[i];
      if (!block.syntax) continue;
      // Record empty flow facts for unreachable syntax nodes. The statement
      // checker still type-checks their contents, but no unreachable use or
      // defer may keep a runtime loan alive or trigger a borrow conflict.
      auto &entrySets = flowAt[block.syntax];
      if (reachable[i]) {
        entrySets.first.insert(block.in.begin(), block.in.end());
        entrySets.second.insert(block.out.begin(), block.out.end());
      }
    }
  }

  void pruneLoansAt(const Node *n, Context &ctx) const {
    auto flow = flowAt.find(n);
    if (flow == flowAt.end()) return;
    LoanSymbolSet active = flow->second.first;
    active.insert(flow->second.second.begin(), flow->second.second.end());
    std::set<const Node *> keepDecls;
    for (const Loan &loan : ctx.loans)
      if (loan.parameter || flowPinned.count(loan.decl) || active.count(loan.decl))
        if (loan.decl) keepDecls.insert(loan.decl);
    // A child loan keeps each ancestor loan record alive even when the parent
    // alias itself has no future direct use; the parent is suspended meanwhile.
    bool changed = true;
    while (changed) {
      changed = false;
      for (const Loan &loan : ctx.loans) {
        if (loan.decl && keepDecls.count(loan.decl) && loan.parentDecl &&
            !keepDecls.count(loan.parentDecl)) {
          keepDecls.insert(loan.parentDecl); changed = true;
        }
      }
    }
    for (auto it = ctx.loans.begin(); it != ctx.loans.end();) {
      const bool keep = it->parameter || flowPinned.count(it->decl) ||
                        active.count(it->decl) || (it->decl && keepDecls.count(it->decl));
      if (!keep) {
        auto alias = ctx.aliases.find(it->alias);
        if (alias != ctx.aliases.end() && alias->second.decl == it->decl)
          ctx.aliases.erase(alias);
        it = ctx.loans.erase(it);
      } else ++it;
    }
  }

  static bool sameLoan(const Loan &a, const Loan &b) {
    return a.alias == b.alias && a.decl == b.decl && a.parameter == b.parameter;
  }

  static const Loan *parentLoan(const Loan &child, const Context &ctx) {
    if (child.parentAlias.empty()) return nullptr;
    for (const Loan &candidate : ctx.loans) {
      if (candidate.alias != child.parentAlias) continue;
      if (candidate.decl == child.parentDecl && candidate.parameter == (child.parentDecl == nullptr))
        return &candidate;
    }
    return nullptr;
  }

  static bool isAncestorLoan(const Loan &candidate, const Loan &parent, const Context &ctx) {
    const Loan *cursor = &parent;
    std::set<std::pair<const Node *, std::string>> visited;
    while (cursor) {
      if (sameLoan(candidate, *cursor)) return true;
      auto key = std::make_pair(cursor->decl, cursor->alias);
      if (!visited.insert(key).second) break;
      cursor = parentLoan(*cursor, ctx);
    }
    return false;
  }

  // V227 treats nested local reborrows as an explicit aggregate-loan graph.
  // Every edge must preserve the original storage identity and remain inside
  // the parent's metadata-validated projection. A partial child projection is
  // permitted when it is still rooted at the parent's exact path (for example,
  // a dynamic array index); overlap remains conservative for that child.
  static bool projectionContains(const std::string &parent,
                                 const std::string &child) {
    if (parent.empty() || parent == child) return true;
    if (child.size() <= parent.size() ||
        child.compare(0, parent.size(), parent) != 0) return false;
    const char boundary = child[parent.size()];
    return boundary == '.' || boundary == '[';
  }

  void validateReborrowGraphEdge(const Node *at, const Loan &parent,
                                 const Loan &child, const Context &ctx) const {
    if (!sameStorage(parent, child))
      fail(at, "nested borrow graph invariant failed: reborrow changed its original storage owner");
    if (parent.projectionExact && !projectionContains(parent.projection, child.projection))
      fail(at, "nested borrow graph invariant failed: reborrow escaped its parent field projection");
    if (!regionOutlives(parent.region, child.region))
      fail(at, "nested borrow graph invariant failed: parent loan does not outlive its child reborrow");

    // Declaration-order parent links should always form a DAG. Validate the
    // existing chain before adding the child so a stale/shadowed alias cannot
    // silently create an orphan or cyclic loan record.
    const Loan *cursor = &parent;
    std::set<std::pair<const Node *, std::string>> visited;
    while (cursor) {
      if (sameLoan(*cursor, child))
        fail(at, "nested borrow graph invariant failed: reborrow would create a cycle");
      const auto key = std::make_pair(cursor->decl, cursor->alias);
      if (!visited.insert(key).second)
        fail(at, "nested borrow graph invariant failed: existing parent chain contains a cycle");
      const Loan *next = parentLoan(*cursor, ctx);
      if (cursor->parentDecl || !cursor->parentAlias.empty()) {
        if (!next)
          fail(at, "nested borrow graph invariant failed: parent loan is no longer available");
      }
      cursor = next;
    }
  }

  static size_t loanDepthFromAncestor(const Loan &ancestor, const Loan &descendant,
                                      const Context &ctx) {
    const Loan *cursor = &descendant;
    std::set<std::pair<const Node *, std::string>> visited;
    size_t depth = 0;
    while (cursor) {
      if (sameLoan(ancestor, *cursor)) return depth;
      auto key = std::make_pair(cursor->decl, cursor->alias);
      if (!visited.insert(key).second) break;
      cursor = parentLoan(*cursor, ctx);
      ++depth;
    }
    return 0;
  }

  // A parent is suspended while any live descendant loan exists, not only
  // while its immediate child is directly used. Loan records normally retain
  // their ancestors during NLL pruning; resolve ancestry by declaration
  // identity and report the deepest retained descendant as the blocker.
  static const Loan *activeDescendantLoan(const Context &ctx, const Loan &ancestor) {
    const Loan *deepest = nullptr;
    size_t deepestDepth = 0;
    for (const Loan &candidate : ctx.loans) {
      if (sameLoan(candidate, ancestor)) continue;
      const size_t depth = loanDepthFromAncestor(ancestor, candidate, ctx);
      if (depth > deepestDepth) {
        deepest = &candidate;
        deepestDepth = depth;
      }
    }
    return deepest;
  }

  static bool hasActiveDescendant(const Context &ctx, const Loan &ancestor) {
    return activeDescendantLoan(ctx, ancestor) != nullptr;
  }

  // Borrow diagnostics name the loan that keeps an owner/parent inaccessible.
  // This is intentionally diagnostic-only: it does not change loan liveness or
  // conflict decisions, and remains useful when aliases are shadowed by name.
  static std::string loanOriginNote(const Loan &loan) {
    const std::string mode = loan.mode == 1 ? "shared" : "mutable";
    if (loan.decl)
      return "; conflicting " + mode + " local borrow '" + loan.alias +
             "' declared at line " + std::to_string(loan.decl->line);
    if (loan.parameter)
      return "; conflicting " + mode + " ref parameter '" + loan.alias + "' declared in the function signature";
    return "; conflicting " + mode + " borrow '" + loan.alias + "'";
  }

  static std::pair<std::string, const Node *> rootIdentityForName(const std::string &raw,
                                                                      const Context &ctx) {
    auto alias = ctx.aliases.find(raw);
    if (alias != ctx.aliases.end()) return {alias->second.root, alias->second.rootDecl};
    auto decl = ctx.decls.find(raw);
    return {raw, decl == ctx.decls.end() ? nullptr : decl->second};
  }

  static std::pair<std::string, const Node *> resolvedRootIdentity(const Node *n,
                                                                    const Context &ctx) {
    return rootIdentityForName(rawRoot(n), ctx);
  }

  static std::string resolvedRoot(const Node *n, const Context &ctx) {
    return resolvedRootIdentity(n, ctx).first;
  }

  static const Loan *aliasFor(const Node *n, const Context &ctx) {
    const std::string raw = rawRoot(n);
    auto it = ctx.aliases.find(raw);
    return it == ctx.aliases.end() ? nullptr : &it->second;
  }

  static bool sameStorage(const Loan &loan, const std::string &root,
                          const Node *rootDecl) {
    if (loan.rootDecl || rootDecl) return loan.rootDecl && rootDecl && loan.rootDecl == rootDecl;
    return loan.root == root;
  }

  static bool sameStorage(const Loan &a, const Loan &b) {
    return sameStorage(a, b.root, b.rootDecl);
  }

  static bool projectionsOverlap(const std::string &a, bool aExact,
                                 const std::string &b, bool bExact) {
    if (!aExact || !bExact) return true;
    if (a.empty() || b.empty()) return true; // whole-root access overlaps every projection
    if (a == b) return true;
    // A projection overlaps its descendants (e.g. `inner`, `inner.left`,
    // `items[2]`, `items[2].value`, `matrix[1][3]`). A field or index is a
    // segment boundary; numeric prefixes such as [1] and [10] are distinct.
    const auto isPrefix = [](const std::string &prefix, const std::string &path) {
      if (path.size() <= prefix.size() || path.compare(0, prefix.size(), prefix) != 0)
        return false;
      const char boundary = path[prefix.size()];
      return boundary == '.' || boundary == '[';
    };
    return isPrefix(a, b) || isPrefix(b, a);
  }

  static bool overlaps(const Loan &loan, const StoragePath &path) {
    return sameStorage(loan, path.root, path.rootDecl) &&
           projectionsOverlap(loan.projection, loan.projectionExact,
                              path.projection, path.exact);
  }

  static bool overlaps(const Loan &a, const Loan &b) {
    return sameStorage(a, b) &&
           projectionsOverlap(a.projection, a.projectionExact,
                              b.projection, b.projectionExact);
  }

  static bool hasLoan(const Context &ctx, const std::string &root,
                      const Node *rootDecl, BorrowMode mode = 0) {
    for (const Loan &loan : ctx.loans)
      if (sameStorage(loan, root, rootDecl) && (!mode || loan.mode == mode)) return true;
    return false;
  }

  static const Loan *findLoan(const Context &ctx, const std::string &root,
                              const Node *rootDecl) {
    for (const Loan &loan : ctx.loans)
      if (sameStorage(loan, root, rootDecl)) return &loan;
    return nullptr;
  }

  static bool fitsSignedBits(int64_t value, unsigned bits) {
    switch (bits) {
      case 8: return value >= INT8_MIN && value <= INT8_MAX;
      case 16: return value >= INT16_MIN && value <= INT16_MAX;
      case 32: return value >= INT32_MIN && value <= INT32_MAX;
      case 64: return true;
      default: return false;
    }
  }

  static bool fitsUnsignedBits(int64_t value, unsigned bits) {
    if (value < 0) return false;
    switch (bits) {
      case 8: return static_cast<uint64_t>(value) <= UINT8_MAX;
      case 16: return static_cast<uint64_t>(value) <= UINT16_MAX;
      case 32: return static_cast<uint64_t>(value) <= UINT32_MAX;
      // The evaluator stores indexes in int64_t, so every non-negative value
      // representable here is also representable by an unsigned 64-bit integer.
      case 64: return true;
      default: return false;
    }
  }

  static unsigned signedIntegerWidth(const std::string &type) {
    if (type == "byte") return 8;
    if (type == "short") return 16;
    if (type == "int") return 32;
    if (type == "long") return 64;
    return 0;
  }

  static unsigned unsignedIntegerWidth(const std::string &type) {
    if (type == "ubyte") return 8;
    if (type == "ushort") return 16;
    if (type == "uint") return 32;
    if (type == "ulong") return 64;
    return 0;
  }

  static bool constantArrayCastTarget(const std::string &type, unsigned &bits,
                                      bool &isUnsigned, bool &isBoolean) {
    isBoolean = type == "Boolean";
    if (isBoolean) {
      bits = 8;
      isUnsigned = true;
      return true;
    }
    const std::string lower = type == "Char" ? "char" :
        type == "Unichar" ? "unichar" : std::string();
    if (!lower.empty()) {
      bits = lower == "char" ? 8u : 32u;
      isUnsigned = true;
      return true;
    }
    bits = signedIntegerWidth(type == "Byte" ? "byte" :
        type == "Short" ? "short" : type == "Int" ? "int" :
        type == "Long" ? "long" : std::string());
    isUnsigned = false;
    if (bits) return true;
    bits = unsignedIntegerWidth(type == "Ubyte" ? "ubyte" :
        type == "Ushort" ? "ushort" : type == "Uint" ? "uint" :
        type == "Ulong" ? "ulong" : std::string());
    isUnsigned = true;
    return bits != 0;
  }

  static ConstantArrayIndex promoteConstantArrayIndex(ConstantArrayIndex value) {
    // Match FAC's integer promotion: byte/short and their unsigned variants
    // promote to signed int because all of their values fit in 32 bits.
    if (value.bits < 32) {
      value.bits = 32;
      value.isUnsigned = false;
    }
    return value;
  }

  static ConstantArrayIndex commonConstantArrayIndex(ConstantArrayIndex left,
                                                       ConstantArrayIndex right) {
    left = promoteConstantArrayIndex(left);
    right = promoteConstantArrayIndex(right);
    ConstantArrayIndex result;
    result.bits = std::max(left.bits, right.bits);
    if (left.bits == right.bits)
      result.isUnsigned = left.isUnsigned || right.isUnsigned;
    else
      result.isUnsigned = left.bits > right.bits ? left.isUnsigned : right.isUnsigned;
    return result;
  }

  static bool constantArrayIndexFromBits(uint64_t bits, unsigned width,
                                         bool isUnsigned, int64_t &value) {
    if (width != 8 && width != 16 && width != 32 && width != 64) return false;
    if (width < 64) {
      const uint64_t modulus = UINT64_C(1) << width;
      bits &= modulus - 1;
      if (!isUnsigned && (bits & (UINT64_C(1) << (width - 1))))
        value = -static_cast<int64_t>(modulus - bits);
      else
        value = static_cast<int64_t>(bits);
      return true;
    }
    if (isUnsigned && bits > static_cast<uint64_t>(INT64_MAX)) return false;
    if (bits <= static_cast<uint64_t>(INT64_MAX)) value = static_cast<int64_t>(bits);
    else value = -1 - static_cast<int64_t>(~bits);
    return true;
  }

  static bool evalConstantArrayFloat(const Node *expr, double &out, unsigned &outKind,
                                     size_t &visited, const Context *ctx) {
    // outKind: 0 = integer/boolean/character source, 1 = FAC float32, 2 = FAC float64.
    // Keep the representation alongside the value so mixed float/double
    // expressions follow commonT() rather than silently doing every operation
    // at host double precision.
    if (!expr || ++visited > 64) return false;
    if (expr->k == NK::FloatLit) { out = expr->dv; outKind = 2; return true; }
    if (expr->k == NK::IntLit) { out = static_cast<double>(expr->iv); outKind = 0; return true; }
    if (expr->k == NK::BoolLit) { out = expr->b ? 1.0 : 0.0; outKind = 0; return true; }
    if (expr->k == NK::CharLit) { out = static_cast<double>(expr->iv); outKind = 0; return true; }
    if (expr->k == NK::Ident && ctx) {
      const auto floatIt = ctx->constantFloats.find(expr->s);
      const auto intIt = ctx->constantInts.find(expr->s);
      const auto declIt = ctx->decls.find(expr->s);
      const auto constIt = ctx->constVars.find(expr->s);
      if (declIt == ctx->decls.end() || constIt == ctx->constVars.end() ||
          !constIt->second || !declIt->second) return false;
      if (floatIt != ctx->constantFloats.end() &&
          declIt->second == floatIt->second.decl) {
        out = floatIt->second.value;
        outKind = floatIt->second.isFloat32 ? 1u : 2u;
        return true;
      }
      if (intIt != ctx->constantInts.end() && declIt->second == intIt->second.decl) {
        out = static_cast<double>(intIt->second.value.value);
        outKind = 0;
        return true;
      }
      return false;
    }
    if (expr->k == NK::Unary && expr->c.size() == 1 &&
        (expr->s == "+" || expr->s == "-")) {
      if (!evalConstantArrayFloat(expr->c[0].get(), out, outKind, visited, ctx)) return false;
      if (expr->s == "-") out = -out;
      return true;
    }
    if (expr->k == NK::Call && expr->c.size() == 3 && expr->c[0] &&
        expr->c[0]->k == NK::Ident && expr->c[0]->s == "cast" &&
        expr->c[1] && expr->c[1]->k == NK::Ident &&
        (expr->c[1]->s == "Float" || expr->c[1]->s == "Double")) {
      if (!evalConstantArrayFloat(expr->c[2].get(), out, outKind, visited, ctx)) return false;
      if (expr->c[1]->s == "Float") {
        out = static_cast<double>(static_cast<float>(out));
        outKind = 1;
      } else {
        outKind = 2;
      }
      return true;
    }
    if (expr->k == NK::Binary && expr->c.size() == 2 &&
        (expr->s == "+" || expr->s == "-" || expr->s == "*" ||
         expr->s == "/" || expr->s == "%")) {
      double left = 0.0, right = 0.0;
      unsigned leftKind = 0, rightKind = 0;
      if (!evalConstantArrayFloat(expr->c[0].get(), left, leftKind, visited, ctx) ||
          !evalConstantArrayFloat(expr->c[1].get(), right, rightKind, visited, ctx))
        return false;
      // Only fold expressions that actually have a floating operand. Pure
      // integer constant evaluation remains owned by evalConstantArrayIndex().
      const unsigned resultKind = std::max(leftKind, rightKind);
      if (resultKind == 0 || !std::isfinite(left) || !std::isfinite(right)) return false;
      // Division/remainder by zero is left unknown. This avoids relying on
      // host-specific floating exception modes while preserving a conservative
      // may-alias result for the borrow checker.
      if ((expr->s == "/" || expr->s == "%") && right == 0.0) return false;
      if (resultKind == 1) {
        // FAC commonT() selects float32 when at least one operand is float and
        // neither is double. Volatile stores force an IEEE single-precision
        // rounding after this operation, matching LLVM's `f* float` result.
        volatile float a = static_cast<float>(left);
        volatile float b = static_cast<float>(right);
        volatile float result = 0.0f;
        if (expr->s == "+") result = a + b;
        else if (expr->s == "-") result = a - b;
        else if (expr->s == "*") result = a * b;
        else if (expr->s == "/") result = a / b;
        else result = std::fmod(static_cast<float>(a), static_cast<float>(b));
        out = static_cast<double>(result);
      } else {
        // FAC double expressions use LLVM fadd/fsub/fmul/fdiv/frem. Keep each
        // operation separate; do not reassociate or fold exponentiation here.
        volatile double result = 0.0;
        if (expr->s == "+") result = left + right;
        else if (expr->s == "-") result = left - right;
        else if (expr->s == "*") result = left * right;
        else if (expr->s == "/") result = left / right;
        else result = std::fmod(left, right);
        out = result;
      }
      if (!std::isfinite(out)) return false;
      outKind = resultKind;
      return true;
    }
    return false;
  }

  // Resolve a deliberately bounded pure integer expression. In addition to
  // literal arithmetic, a visible initialized local const integer may be
  // substituted only when the current binding still has the same declaration
  // identity. Unknown identifiers and all side-effecting expressions remain
  // conservative may-alias paths.
  static bool evalConstantArrayIndex(const Node *expr, ConstantArrayIndex &out,
                                    size_t &visited, const Context *ctx) {
    if (!expr || ++visited > 64) return false;
    if (expr->k == NK::IfV) {
      // `ifv(cond){value} eiv(cond){value} elv{value}` is an integer constant
      // only when its conditions can be decided and every result arm is a
      // supported constant with the same integer representation. Requiring
      // matching width/signedness avoids guessing the type-join rules here.
      if (expr->c.size() < 3 || (expr->c.size() % 2) == 0) return false;
      const size_t elseIndex = expr->c.size() - 1;
      size_t selectedIndex = elseIndex;
      for (size_t i = 0; i + 1 < elseIndex; i += 2) {
        bool condition = false;
        if (!evalConstantArrayCondition(expr->c[i].get(), condition, visited, ctx))
          return false;
        if (condition) { selectedIndex = i + 1; break; }
      }
      ConstantArrayIndex selected;
      bool haveRepresentation = false;
      for (size_t i = 1; i < expr->c.size(); i += 2) {
        ConstantArrayIndex branch;
        if (!evalConstantArrayIndex(expr->c[i].get(), branch, visited, ctx)) return false;
        if (!haveRepresentation) {
          selected = branch;
          haveRepresentation = true;
        } else if (branch.bits != selected.bits ||
                   branch.isUnsigned != selected.isUnsigned) {
          return false;
        }
        if (i == selectedIndex) selected = branch;
      }
      ConstantArrayIndex elseValue;
      if (!evalConstantArrayIndex(expr->c[elseIndex].get(), elseValue, visited, ctx))
        return false;
      if (haveRepresentation &&
          (elseValue.bits != selected.bits || elseValue.isUnsigned != selected.isUnsigned))
        return false;
      out = selectedIndex == elseIndex ? elseValue : selected;
      return true;
    }
    if (expr->k == NK::IntLit) {
      out.value = expr->iv;
      out.bits = (expr->iv >= INT32_MIN && expr->iv <= INT32_MAX) ? 32u : 64u;
      out.isUnsigned = false;
      return true;
    }
    if (expr->k == NK::BoolLit) {
      out.value = expr->b ? 1 : 0;
      out.bits = 8;
      out.isUnsigned = true;
      return true;
    }
    if (expr->k == NK::CharLit) {
      out.value = expr->iv;
      out.bits = expr->iv < 128 ? 8u : 32u;
      out.isUnsigned = true;
      return true;
    }
    if (expr->k == NK::Call && expr->c.size() == 3 && expr->c[0] &&
        expr->c[0]->k == NK::Ident && expr->c[0]->s == "cast" &&
        expr->c[1] && expr->c[1]->k == NK::Ident) {
      // Explicit primitive integer casts have fixed, source-visible
      // conversion semantics. Fold only scalar integer-like sources and
      // primitive integer/boolean/character targets; float, pointer, enum,
      // class and arbitrary cast calls remain conservative.
      unsigned targetBits = 0;
      bool targetUnsigned = false, targetBoolean = false;
      if (!constantArrayCastTarget(expr->c[1]->s, targetBits,
                                   targetUnsigned, targetBoolean)) return false;
      ConstantArrayIndex source;
      if (evalConstantArrayIndex(expr->c[2].get(), source, visited, ctx)) {
        if (targetBoolean) {
          out.value = source.value != 0 ? 1 : 0;
          out.bits = 8;
          out.isUnsigned = true;
          return true;
        }
        if (source.bits != 8 && source.bits != 16 &&
            source.bits != 32 && source.bits != 64) return false;
        uint64_t raw = static_cast<uint64_t>(source.value);
        if (source.bits < 64) {
          const uint64_t sourceMask = (UINT64_C(1) << source.bits) - 1;
          raw &= sourceMask;
          if (!source.isUnsigned && targetBits > source.bits &&
              (raw & (UINT64_C(1) << (source.bits - 1))))
            raw |= ~sourceMask;
        }
        if (targetBits < 64) raw &= (UINT64_C(1) << targetBits) - 1;
        int64_t converted = 0;
        if (!constantArrayIndexFromBits(raw, targetBits, targetUnsigned, converted))
          return false;
        out.value = converted;
        out.bits = targetBits;
        out.isUnsigned = targetUnsigned;
        return true;
      }
      // LLVM's FAC conversion path uses saturating float-to-integer
      // intrinsics. Fold only statically known float/double expressions and
      // mirror their NaN, truncation and saturation rules. Values outside the
      // checker projection's signed-64 range remain conservative.
      double floatingSource = 0.0;
      unsigned floatingSourceKind = 0;
      if (!evalConstantArrayFloat(expr->c[2].get(), floatingSource,
                                  floatingSourceKind, visited, ctx))
        return false;
      if (targetBoolean) {
        out.value = floatingSource != 0.0 ? 1 : 0; // NaN is true for fcmp une
        out.bits = 8;
        out.isUnsigned = true;
        return true;
      }
      if (std::isnan(floatingSource)) floatingSource = 0.0;
      int64_t converted = 0;
      if (targetUnsigned) {
        if (floatingSource <= 0.0) {
          converted = 0;
        } else if (targetBits < 64) {
          const double upperExclusive = std::ldexp(1.0, static_cast<int>(targetBits));
          if (floatingSource >= upperExclusive)
            converted = static_cast<int64_t>((UINT64_C(1) << targetBits) - 1);
          else
            converted = static_cast<int64_t>(std::trunc(floatingSource));
        } else {
          // The static borrow projection is int64-based; do not claim an exact
          // projection for unsigned-64 results above INT64_MAX.
          if (floatingSource >= std::ldexp(1.0, 63)) return false;
          converted = static_cast<int64_t>(std::trunc(floatingSource));
        }
      } else {
        const double signedLimit = std::ldexp(1.0, static_cast<int>(targetBits - 1));
        if (floatingSource <= -signedLimit) {
          converted = targetBits == 64 ? INT64_MIN :
              -static_cast<int64_t>(UINT64_C(1) << (targetBits - 1));
        } else if (floatingSource >= signedLimit) {
          converted = targetBits == 64 ? INT64_MAX :
              static_cast<int64_t>((UINT64_C(1) << (targetBits - 1)) - 1);
        } else {
          converted = static_cast<int64_t>(std::trunc(floatingSource));
        }
      }
      out.value = converted;
      out.bits = targetBits;
      out.isUnsigned = targetUnsigned;
      return true;
    }
    if (expr->k == NK::Ident && ctx) {
      const auto valueIt = ctx->constantInts.find(expr->s);
      const auto declIt = ctx->decls.find(expr->s);
      const auto constIt = ctx->constVars.find(expr->s);
      if (valueIt == ctx->constantInts.end() || declIt == ctx->decls.end() ||
          constIt == ctx->constVars.end() || !constIt->second ||
          declIt->second != valueIt->second.decl || !valueIt->second.decl)
        return false;
      out = valueIt->second.value;
      return true;
    }
    if (expr->k == NK::Unary && expr->c.size() == 1 &&
        (expr->s == "+" || expr->s == "-" || expr->s == "~")) {
      ConstantArrayIndex operand;
      if (!evalConstantArrayIndex(expr->c[0].get(), operand, visited, ctx)) return false;
      out = operand;
      if (expr->s == "-") {
        // Negating an unsigned value depends on the language's integer
        // promotion/conversion rules. Keep this case conservative rather than
        // guessing a wrapped projection.
        if (operand.isUnsigned || operand.value == INT64_MIN) return false;
        out.value = -operand.value;
      } else if (expr->s == "~") {
        out = promoteConstantArrayIndex(out);
        const uint64_t mask = out.bits == 64
            ? UINT64_MAX : ((UINT64_C(1) << out.bits) - 1);
        if (!constantArrayIndexFromBits((~static_cast<uint64_t>(out.value)) & mask,
                                        out.bits, out.isUnsigned, out.value)) return false;
      }
      return out.isUnsigned ? fitsUnsignedBits(out.value, out.bits)
                            : fitsSignedBits(out.value, out.bits);
    }
    if (expr->k != NK::Binary || expr->c.size() != 2 ||
        (expr->s != "+" && expr->s != "-" && expr->s != "*" &&
         expr->s != "/" && expr->s != "%" && expr->s != "&" &&
         expr->s != "|" && expr->s != "^" && expr->s != "<<" &&
         expr->s != ">>")) return false;

    ConstantArrayIndex left, right;
    if (!evalConstantArrayIndex(expr->c[0].get(), left, visited, ctx) ||
        !evalConstantArrayIndex(expr->c[1].get(), right, visited, ctx)) return false;
    const ConstantArrayIndex common = commonConstantArrayIndex(left, right);
    const unsigned resultBits = common.bits;
    const bool resultUnsigned = common.isUnsigned;
    // FAC promotes narrow integer operands before binary operations. Apply
    // those promotions before performing bitwise/shift folding so the borrow
    // projection matches the type width used by LLVM code generation.
    left = promoteConstantArrayIndex(left);
    right = promoteConstantArrayIndex(right);
    int64_t value = 0;
    if (expr->s == "&" || expr->s == "|" || expr->s == "^") {
      const uint64_t a = static_cast<uint64_t>(left.value);
      const uint64_t b = static_cast<uint64_t>(right.value);
      const uint64_t bits = expr->s == "&" ? (a & b)
          : expr->s == "|" ? (a | b) : (a ^ b);
      if (!constantArrayIndexFromBits(bits, resultBits, resultUnsigned, value)) return false;
    } else if (expr->s == "<<" || expr->s == ">>") {
      const unsigned shift = static_cast<unsigned>(static_cast<uint64_t>(right.value) & (resultBits - 1));
      const uint64_t widthMask = resultBits == 64
          ? UINT64_MAX : ((UINT64_C(1) << resultBits) - 1);
      uint64_t bits = static_cast<uint64_t>(left.value) & widthMask;
      if (expr->s == "<<") {
        bits <<= shift;
      } else if (resultUnsigned) {
        bits >>= shift;
      } else if (shift != 0) {
        // Arithmetic right shift with floor rounding, independent of the
        // host compiler's implementation-defined negative signed shift.
        const uint64_t signBit = UINT64_C(1) << (resultBits - 1);
        if (bits & signBit) {
          const uint64_t magnitude = ((~bits) & widthMask) + 1;
          const uint64_t divisorMask = (UINT64_C(1) << shift) - 1;
          uint64_t quotient = magnitude >> shift;
          if ((magnitude & divisorMask) != 0) ++quotient;
          bits = (quotient == signBit) ? signBit : ((~quotient + 1) & widthMask);
        } else {
          bits >>= shift;
        }
      }
      if (!constantArrayIndexFromBits(bits, resultBits, resultUnsigned, value)) return false;
    } else if (expr->s == "+") {
      if ((right.value > 0 && left.value > INT64_MAX - right.value) ||
          (right.value < 0 && left.value < INT64_MIN - right.value)) return false;
      value = left.value + right.value;
    } else if (expr->s == "-") {
      if ((right.value < 0 && left.value > INT64_MAX + right.value) ||
          (right.value > 0 && left.value < INT64_MIN + right.value)) return false;
      value = left.value - right.value;
    } else if (expr->s == "*") {
      if (left.value != 0 && right.value != 0) {
        if ((left.value == -1 && right.value == INT64_MIN) ||
            (right.value == -1 && left.value == INT64_MIN)) return false;
        if (left.value > 0) {
          if ((right.value > 0 && left.value > INT64_MAX / right.value) ||
              (right.value < 0 && right.value < INT64_MIN / left.value)) return false;
        } else {
          if ((right.value > 0 && left.value < INT64_MIN / right.value) ||
              (right.value < 0 && left.value < INT64_MAX / right.value)) return false;
        }
      }
      value = left.value * right.value;
    } else {
      if (right.value == 0 || (left.value == INT64_MIN && right.value == -1)) return false;
      value = expr->s == "/" ? left.value / right.value : left.value % right.value;
    }
    if (resultUnsigned ? !fitsUnsignedBits(value, resultBits)
                       : !fitsSignedBits(value, resultBits)) return false;
    out.value = value;
    out.bits = resultBits;
    out.isUnsigned = resultUnsigned;
    return true;
  }

  static bool evalConstantArrayCondition(const Node *expr, bool &out,
                                         size_t &visited, const Context *ctx) {
    if (!expr || ++visited > 64) return false;
    if (expr->k == NK::Ident && ctx) {
      const auto valueIt = ctx->constantBools.find(expr->s);
      const auto declIt = ctx->decls.find(expr->s);
      const auto constIt = ctx->constVars.find(expr->s);
      if (valueIt == ctx->constantBools.end() || declIt == ctx->decls.end() ||
          constIt == ctx->constVars.end() || !constIt->second ||
          declIt->second != valueIt->second.decl || !valueIt->second.decl)
        return false;
      out = valueIt->second.value;
      return true;
    }
    if (expr->k == NK::BoolLit) {
      out = expr->b;
      return true;
    }
    if (expr->k == NK::Unary && expr->s == "!" && expr->c.size() == 1) {
      bool operand = false;
      if (!evalConstantArrayCondition(expr->c[0].get(), operand, visited, ctx))
        return false;
      out = !operand;
      return true;
    }
    if (expr->k == NK::Binary && expr->c.size() == 2 &&
        (expr->s == "&&" || expr->s == "||")) {
      bool left = false;
      if (!evalConstantArrayCondition(expr->c[0].get(), left, visited, ctx))
        return false;
      // Preserve FAC short-circuit semantics: the unreachable operand need not
      // be constant because it is not evaluated at runtime either.
      if (expr->s == "&&" && !left) { out = false; return true; }
      if (expr->s == "||" && left) { out = true; return true; }
      bool right = false;
      if (!evalConstantArrayCondition(expr->c[1].get(), right, visited, ctx))
        return false;
      out = right;
      return true;
    }
    if (expr->k == NK::Binary && expr->c.size() == 2 &&
        (expr->s == "==" || expr->s == "!=" || expr->s == "<" ||
         expr->s == "<=" || expr->s == ">" || expr->s == ">=")) {
      ConstantArrayIndex left, right;
      if (!evalConstantArrayIndex(expr->c[0].get(), left, visited, ctx) ||
          !evalConstantArrayIndex(expr->c[1].get(), right, visited, ctx))
        return false;
      const ConstantArrayIndex common = commonConstantArrayIndex(left, right);
      left = promoteConstantArrayIndex(left);
      right = promoteConstantArrayIndex(right);
      bool less = false, equal = false;
      if (common.isUnsigned) {
        const uint64_t mask = common.bits == 64
            ? UINT64_MAX : ((UINT64_C(1) << common.bits) - 1);
        const uint64_t a = static_cast<uint64_t>(left.value) & mask;
        const uint64_t b = static_cast<uint64_t>(right.value) & mask;
        less = a < b;
        equal = a == b;
      } else {
        less = left.value < right.value;
        equal = left.value == right.value;
      }
      if (expr->s == "==") out = equal;
      else if (expr->s == "!=") out = !equal;
      else if (expr->s == "<") out = less;
      else if (expr->s == "<=") out = less || equal;
      else if (expr->s == ">") out = !less && !equal;
      else out = !less;
      return true;
    }
    ConstantArrayIndex integer;
    if (!evalConstantArrayIndex(expr, integer, visited, ctx)) return false;
    out = integer.value != 0;
    return true;
  }

  static bool resolveNonNegativeConstantIndex(const Node *expr, int64_t &index,
                                              const Context &ctx) {
    ConstantArrayIndex result;
    size_t visited = 0;
    if (!evalConstantArrayIndex(expr, result, visited, &ctx) || result.value < 0) return false;
    index = result.value;
    return true;
  }

  bool appendResolvedStorageProjection(const Node *expr, const Context &ctx,
                                      StoragePath &path, std::string &currentType) const {
    if (!expr) return false;
    if (expr->k == NK::Ident) {
      auto typeIt = ctx.typeKeys.find(expr->s);
      if (typeIt != ctx.typeKeys.end()) currentType = typeIt->second;
      else {
        auto legacyType = ctx.types.find(expr->s);
        if (legacyType != ctx.types.end()) currentType = legacyType->second;
      }
      return true;
    }
    if (expr->k == NK::Member && expr->c.size() == 1) {
      if (!appendResolvedStorageProjection(expr->c[0].get(), ctx, path, currentType))
        return false;
      // A direct field of the root `obj` handle is tracked by that handle.
      // Once a field itself contains another managed object reference, however,
      // following another member would cross into a separately shareable heap
      // identity. Treating it as `root.field.child` could miss aliases through
      // a second handle, so this checker rejects borrows across that boundary.
      const bool weakHandle = currentType.compare(0, 9, "weak obj ") == 0;
      const bool nestedManagedHandle = !path.projection.empty() &&
          currentType.compare(0, 4, "obj ") == 0;
      if (weakHandle || nestedManagedHandle) {
        path.crossesManagedObjectBoundary = true;
        path.exact = false;
        return false;
      }
      const auto *typeFields = fieldMapFor(currentType);
      if (!path.exact || !typeFields) { path.exact = false; return false; }
      auto fieldIt = typeFields->find(expr->s);
      if (fieldIt == typeFields->end()) { path.exact = false; return false; }
      if (!path.projection.empty()) path.projection += ".";
      path.projection += expr->s;
      currentType = fieldIt->second.type;
      return true;
    }
    if (expr->k == NK::Index && expr->c.size() == 2) {
      if (!appendResolvedStorageProjection(expr->c[0].get(), ctx, path, currentType))
        return false;
      // Precise disjointness is limited to fixed-size arrays and pure,
      // non-negative integer constant expressions with checked signed
      // byte/short/int/long math.
      // Variables, calls, side effects and unsupported operators remain
      // conservative may-alias paths.
      int64_t constantIndex = 0;
      if (!path.exact || currentType.compare(0, 6, "array ") != 0 ||
          !resolveNonNegativeConstantIndex(expr->c[1].get(), constantIndex, ctx)) {
        path.exact = false;
        return false;
      }
      path.projection += "[" + std::to_string(constantIndex) + "]";
      currentType = currentType.substr(6);
      return true;
    }
    path.exact = false;
    return false;
  }

  StoragePath resolvedStoragePath(const Node *expr, const Context &ctx) const {
    StoragePath path;
    path.raw = rawRoot(expr);
    if (path.raw.empty()) { path.exact = false; return path; }

    const auto alias = ctx.aliases.find(path.raw);
    if (alias != ctx.aliases.end()) {
      path.throughAlias = true;
      path.root = alias->second.root;
      path.rootDecl = alias->second.rootDecl;
      path.projection = alias->second.projection;
      path.exact = alias->second.projectionExact;
    } else {
      const auto identity = resolvedRootIdentity(expr, ctx);
      path.root = identity.first;
      path.rootDecl = identity.second;
    }

    std::string currentType;
    appendResolvedStorageProjection(expr, ctx, path, currentType);
    return path;
  }

  const Loan *findLoanFor(const Context &ctx, const Node *n) const {
    const StoragePath path = resolvedStoragePath(n, ctx);
    for (const Loan &loan : ctx.loans) if (overlaps(loan, path)) return &loan;
    return nullptr;
  }

  static std::string expressionTypeKey(const Node *expr, const Context &ctx,
                                       const std::map<std::string, std::map<std::string, FieldContract>> &fields) {
    if (!expr) return {};
    switch (expr->k) {
      case NK::IntLit: return expr->iv >= INT32_MIN && expr->iv <= INT32_MAX ? "int" : "long";
      case NK::FloatLit: return "double";
      case NK::BoolLit: return "boolean";
      case NK::CharLit: return "char";
      case NK::StrLit: return "string";
      case NK::NullLit: return "null";
      case NK::Call: {
        if (expr->c.size() == 2 && expr->c[0] && expr->c[0]->k == NK::Ident && expr->c[0]->s == "addr") {
          const std::string pointee = expressionTypeKey(expr->c[1].get(), ctx, fields);
          return pointee.empty() ? std::string{} : "ptr " + pointee;
        }
        return {};
      }
      case NK::Ident: {
        auto it = ctx.typeKeys.find(expr->s);
        if (it != ctx.typeKeys.end()) return it->second;
        auto old = ctx.types.find(expr->s);
        return old == ctx.types.end() ? std::string{} : old->second;
      }
      case NK::Member: {
        if (expr->c.empty()) return {};
        const std::string parent = expressionTypeKey(expr->c[0].get(), ctx, fields);
        std::string owner = parent;
        for (const char *prefix : {"struct ", "class ", "obj ", "weak obj "}) {
          const std::string p(prefix);
          if (owner.compare(0, p.size(), p) == 0) owner = owner.substr(p.size());
        }
        auto ft = fields.find(owner);
        if (ft == fields.end()) return {};
        auto field = ft->second.find(expr->s);
        return field == ft->second.end() ? std::string{} : field->second.type;
      }
      case NK::Index: {
        if (expr->c.size() != 2) return {};
        const std::string baseType = expressionTypeKey(expr->c[0].get(), ctx, fields);
        if (baseType.compare(0, 6, "array ") == 0) return baseType.substr(6);
        return {};
      }
      default: return {};
    }
  }

  static int contractTypeScore(const std::string &actual, const std::string &required) {
    if (actual.empty()) return 0; // unknown expression: retain candidate, fail closed on effect
    if (actual == required) return 4;
    if (actual == "null" && required.compare(0, 4, "ptr ") == 0) return 1;
    const bool actualPtr = actual.compare(0, 4, "ptr ") == 0;
    const bool requiredPtr = required.compare(0, 4, "ptr ") == 0;
    if (actualPtr && requiredPtr) return 2; // generic pointer compatibility; exact pointee match wins
    auto numeric = [](const std::string &t) {
      return t == "byte" || t == "short" || t == "int" || t == "long" ||
             t == "ubyte" || t == "ushort" || t == "uint" || t == "ulong" ||
             t == "float" || t == "double" || t == "boolean" || t == "char" || t == "unichar";
    };
    if (numeric(actual) && numeric(required)) return 1;
    return -1;
  }

  const FieldContract *functionFieldContract(const Node *member, const Context &ctx) const {
    if (!member || member->k != NK::Member || member->c.empty()) return nullptr;
    const std::string parentType = expressionTypeKey(member->c[0].get(), ctx, fields);
    std::string owner = parentType;
    for (const char *prefix : {"struct ", "class ", "obj ", "weak obj "}) {
      const std::string p(prefix);
      if (owner.compare(0, p.size(), p) == 0) { owner = owner.substr(p.size()); break; }
    }
    const auto *fieldMap = fieldMapFor(owner);
    if (!fieldMap) return nullptr;
    auto field = fieldMap->find(member->s);
    if (field == fieldMap->end() || !field->second.hasFunctionContract) return nullptr;
    return &field->second;
  }

  bool isIndirectFunctionValue(const Node *callee, const Context &ctx) const {
    if (!callee) return false;
    if (callee->k == NK::Ident) {
      auto type = ctx.typeKeys.find(callee->s);
      return type != ctx.typeKeys.end() && type->second == "function";
    }
    if (callee->k == NK::Member)
      return expressionTypeKey(callee, ctx, fields) == "function";
    return false;
  }

  std::vector<const FacBorrowChecker::CallContract *> effectiveCallContracts(
      const Node *callee, const std::vector<const Node *> &args, const Context &ctx) const {
    if (callee && callee->k == NK::Ident && isIndirectFunctionValue(callee, ctx)) {
      auto contract = ctx.functionValueContracts.find(callee->s);
      if (contract != ctx.functionValueContracts.end()) return {&contract->second};
      // This identifier is a function value, not a direct global symbol.
      // Do not accidentally borrow an unrelated same-name global contract.
      return {};
    }
    if (callee && callee->k == NK::Member && isIndirectFunctionValue(callee, ctx)) {
      const FieldContract *field = functionFieldContract(callee, ctx);
      if (field) return {&field->functionContract};
      // Untyped/legacy function-valued fields still fail closed: no target
      // body or named-lifetime contract can be inferred from the member alone.
      return {};
    }
    return selectedCallContracts(callee, args, ctx);
  }

  std::vector<const FacBorrowChecker::CallContract *> selectedCallContracts(
      const Node *callee, const std::vector<const Node *> &args, const Context &ctx) const {
    if (!callee) return {};
    std::string key;
    if (callee->k == NK::Member && !callee->c.empty()) {
      std::string receiverType = methodType(callee->c[0].get(), ctx);
      for (const char *prefix : {"struct ", "class ", "obj ", "weak obj "}) {
        const std::string p(prefix);
        if (receiverType.compare(0, p.size(), p) == 0) receiverType = receiverType.substr(p.size());
      }
      key = receiverType.empty() ? callee->s : receiverType + "::" + callee->s;
    } else key = FacBorrowChecker::directCalleeName(callee);
    auto found = base.callContracts.find(key);
    if (key.empty() || found == base.callContracts.end()) return {};

    int bestScore = -1000000;
    bool hasUnknownArgumentType = false;
    std::vector<const FacBorrowChecker::CallContract *> best;
    for (const auto &candidate : found->second) {
      const size_t np = candidate.params.size();
      const size_t fixed = !candidate.params.empty() && candidate.params.back().variadic ? np - 1 : np;
      size_t minArgs = 0;
      for (size_t i = 0; i < fixed; ++i)
        if (!candidate.params[i].hasDefault) minArgs = i + 1;
      if (args.size() < minArgs || (args.size() > fixed && fixed == np)) continue;
      int score = candidate.generic ? -50 : 0;
      bool viable = true;
      for (size_t i = 0; i < args.size(); ++i) {
        const auto &param = candidate.params[i < fixed ? i : np - 1];
        const std::string actual = expressionTypeKey(args[i], ctx, fields);
        if (actual.empty()) hasUnknownArgumentType = true;
        const std::string required = param.variadic && param.type.compare(0, 6, "array ") == 0
            ? param.type.substr(6) : param.type;
        const int part = contractTypeScore(actual, required);
        if (part < 0) { viable = false; break; }
        score += part;
      }
      if (!viable) continue;
      if (score > bestScore) { bestScore = score; best.clear(); best.push_back(&candidate); }
      else if (score == bestScore) best.push_back(&candidate);
    }
    // Unknown argument types can change the final overload winner. Keep all
    // arity-compatible contracts and require consensus on security effects.
    if (hasUnknownArgumentType) best.clear();
    if (best.empty()) {
      for (const auto &candidate : found->second) {
        const size_t np = candidate.params.size();
        const size_t fixed = !candidate.params.empty() && candidate.params.back().variadic ? np - 1 : np;
        size_t minArgs = 0;
        for (size_t i = 0; i < fixed; ++i) if (!candidate.params[i].hasDefault) minArgs = i + 1;
        if (args.size() >= minArgs && (args.size() <= fixed || fixed != np)) best.push_back(&candidate);
      }
    }
    return best;
  }

  static std::string methodType(const Node *receiver, const Context &ctx) {
    const std::string raw = rawRoot(receiver);
    auto alias = ctx.aliases.find(raw);
    if (alias != ctx.aliases.end() && !alias->second.type.empty()) return alias->second.type;
    const std::string root = resolvedRoot(receiver, ctx);
    auto type = ctx.types.find(root);
    return type == ctx.types.end() ? std::string{} : type->second;
  }

  std::string expressionType(const Node *expr, const Context &ctx) const {
    if (!expr) return {};
    if (expr->k == NK::Ident) {
      auto it = ctx.types.find(expr->s);
      return it == ctx.types.end() ? std::string{} : it->second;
    }
    if (expr->k == NK::Member && !expr->c.empty()) {
      const std::string parent = expressionType(expr->c[0].get(), ctx);
      const auto *typeFields = fieldMapFor(parent);
      if (!typeFields) return {};
      auto fieldIt = typeFields->find(expr->s);
      return fieldIt == typeFields->end() ? std::string{} : fieldIt->second.type;
    }
    if (expr->k == NK::Index && expr->c.size() == 2) {
      const std::string baseType = expressionTypeKey(expr->c[0].get(), ctx, fields);
      if (baseType.compare(0, 6, "array ") == 0) return baseType.substr(6);
    }
    return {};
  }

  // A mutable local borrow is allowed only when the source's mutability is
  // known. Unknown roots/types fail closed instead of silently assuming that
  // a global, static field, FFI-backed location, or unmodeled field is mutable.
  bool sourceIsConstOrUnknown(const Node *source, const Context &ctx) const {
    if (!source) return true;
    if (source->k == NK::Ident) {
      auto it = ctx.constVars.find(source->s);
      return it == ctx.constVars.end() || it->second;
    }
    if (source->k == NK::Member && !source->c.empty()) {
      if (sourceIsConstOrUnknown(source->c[0].get(), ctx)) return true;
      const std::string parent = expressionType(source->c[0].get(), ctx);
      const auto *typeFields = fieldMapFor(parent);
      if (!typeFields) return true;
      auto fieldIt = typeFields->find(source->s);
      return fieldIt == typeFields->end() || fieldIt->second.isConst;
    }
    if (source->k == NK::Index && !source->c.empty())
      return sourceIsConstOrUnknown(source->c[0].get(), ctx);
    return true;
  }

  bool isConstMethod(const Node *receiver, const std::string &method,
                     const Context &ctx) const {
    const std::string type = methodType(receiver, ctx);
    if (type.empty()) return false;
    auto it = base.constMethods.find(type + "::" + method);
    return it != base.constMethods.end() && it->second;
  }

  void checkWrite(const Node *lhs, const Context &ctx) const {
    const StoragePath path = resolvedStoragePath(lhs, ctx);
    if (path.root.empty()) return;
    if (path.throughAlias) {
      auto alias = ctx.aliases.find(path.raw);
      if (alias != ctx.aliases.end()) {
        if (alias->second.mode == 1)
          fail(lhs, "cannot modify through shared local borrow '" + path.raw + "' (ref const)");
        if (const Loan *child = activeDescendantLoan(ctx, alias->second))
          fail(lhs, "cannot access parent mutable borrow '" + path.raw + "' while a reborrow is active" +
               loanOriginNote(*child));
        return;
      }
    }
    for (const Loan &loan : ctx.loans) {
      if (overlaps(loan, path))
        fail(lhs, "cannot modify owner '" + path.root + "' while an overlapping local borrow is active" +
             loanOriginNote(loan) + "; use the borrow alias or a disjoint field");
    }
  }

  void checkMemberRead(const Node *member, const Context &ctx) const {
    const StoragePath path = resolvedStoragePath(member, ctx);
    if (path.root.empty()) return;
    if (path.throughAlias) {
      auto alias = ctx.aliases.find(path.raw);
      if (alias != ctx.aliases.end() && alias->second.mode == 2) {
        if (const Loan *child = activeDescendantLoan(ctx, alias->second))
          fail(member, "cannot access parent mutable borrow '" + path.raw + "' while a reborrow is active" +
               loanOriginNote(*child));
      }
      return;
    }
    for (const Loan &loan : ctx.loans)
      if (loan.mode == 2 && overlaps(loan, path))
        fail(member, "cannot read owner storage of '" + path.root + "' while an overlapping exclusive local borrow is active" +
              loanOriginNote(loan));
  }

  void checkRead(const Node *ident, const Context &ctx) const {
    if (!ident || ident->k != NK::Ident) return;
    auto alias = ctx.aliases.find(ident->s);
    if (alias != ctx.aliases.end()) {
      if (alias->second.mode == 2) {
        if (const Loan *child = activeDescendantLoan(ctx, alias->second))
          fail(ident, "cannot access parent mutable borrow '" + ident->s + "' while a reborrow is active" +
               loanOriginNote(*child));
      }
      return;
    }
    auto decl = ctx.decls.find(ident->s);
    const Node *declId = decl == ctx.decls.end() ? nullptr : decl->second;
    for (const Loan &loan : ctx.loans) {
      if (loan.mode == 2 && sameStorage(loan, ident->s, declId))
        fail(ident, "cannot access owner '" + ident->s + "' while an exclusive local borrow is active" +
              loanOriginNote(loan) + "; use its mutable alias");
    }
  }

  void checkStoragePathOperands(const Node *expr, Context &ctx) const {
    if (!expr || expr->k == NK::Ident) return;
    if (expr->k == NK::Member && expr->c.size() == 1) {
      checkStoragePathOperands(expr->c[0].get(), ctx);
      return;
    }
    if (expr->k == NK::Index && expr->c.size() == 2) {
      checkStoragePathOperands(expr->c[0].get(), ctx);
      checkExpr(expr->c[1].get(), ctx);
      return;
    }
    // Computed bases still need their ordinary expression checks. The
    // storage projection itself remains inexact and therefore conservative.
    checkExpr(expr, ctx);
  }

  bool callParameterNoescape(const std::vector<const FacBorrowChecker::CallContract *> &selected,
                             size_t argumentIndex, size_t argc) const {
    if (selected.empty()) return false;
    for (const auto *contract : selected) {
      if (!contract) return false;
      const size_t np = contract->params.size();
      const size_t fixed = !contract->params.empty() && contract->params.back().variadic ? np - 1 : np;
      if (argumentIndex >= argc || argumentIndex >= fixed || argumentIndex >= np ||
          !contract->params[argumentIndex].noescape) return false;
    }
    return true;
  }

  // A lifetime contract is usable only when overload resolution has produced
  // one unambiguous lifetime shape. If several overloads remain possible, the
  // caller keeps the older conservative pointer-origin treatment.
  const FacBorrowChecker::CallContract *commonLifetimeContract(
      const std::vector<const FacBorrowChecker::CallContract *> &selected) const {
    if (selected.empty() || !selected.front()) return nullptr;
    const auto *first = selected.front();
    if (first->lifetimeParamCount == 0) return nullptr;
    for (const auto *candidate : selected) {
      if (!candidate || candidate->lifetimeParamCount != first->lifetimeParamCount ||
          candidate->lifetimeNames != first->lifetimeNames ||
          candidate->returnLifetimeParamIndex != first->returnLifetimeParamIndex ||
          candidate->lifetimeOutlives != first->lifetimeOutlives ||
          candidate->params.size() != first->params.size()) return nullptr;
      for (size_t i = 0; i < first->params.size(); ++i)
        if (candidate->params[i].lifetimeParamIndex != first->params[i].lifetimeParamIndex)
          return nullptr;
    }
    return first;
  }

  static bool callContractOutlives(const FacBorrowChecker::CallContract &contract,
                                   int longer, int shorter) {
    if (longer < 0 || shorter < 0 ||
        static_cast<size_t>(longer) >= contract.lifetimeParamCount ||
        static_cast<size_t>(shorter) >= contract.lifetimeParamCount) return false;
    if (longer == shorter) return true;
    std::vector<int> pending{longer};
    std::vector<bool> visited(contract.lifetimeParamCount, false);
    visited[static_cast<size_t>(longer)] = true;
    for (size_t cursor = 0; cursor < pending.size(); ++cursor) {
      const int current = pending[cursor];
      for (const auto &edge : contract.lifetimeOutlives) {
        if (edge.first != current || edge.second < 0 ||
            static_cast<size_t>(edge.second) >= visited.size() ||
            visited[static_cast<size_t>(edge.second)]) continue;
        if (edge.second == shorter) return true;
        visited[static_cast<size_t>(edge.second)] = true;
        pending.push_back(edge.second);
      }
    }
    return false;
  }

  bool callParameterLifetimeBound(
      const FacBorrowChecker::CallContract *contract,
      size_t argumentIndex, size_t argc) const {
    if (!contract || argumentIndex >= argc) return false;
    const size_t np = contract->params.size();
    const size_t fixed = !contract->params.empty() && contract->params.back().variadic ? np - 1 : np;
    if (argumentIndex >= fixed || argumentIndex >= np) return false;
    return contract->params[argumentIndex].lifetimeParamIndex >= 0;
  }

  bool inferCallLifetimeRegion(const Node *callArg, const Context &ctx,
                               size_t &region) const {
    if (callArg && callArg->k == NK::NullLit) {
      region = 0; // null has no referent and is valid for every inferred lifetime
      return true;
    }
    std::vector<PointerOrigin> origins;
    collectPointerOrigins(callArg, ctx, origins);
    if (origins.empty()) return false;

    // A lifetime shared by multiple arguments is their common valid interval.
    // This bounded solver can represent it when one known region is no longer
    // than every possible origin. Incomparable regions fail closed.
    for (const PointerOrigin &candidate : origins) {
      bool common = true;
      for (const PointerOrigin &origin : origins) {
        if (!regionOutlives(origin.region, candidate.region)) {
          common = false;
          break;
        }
      }
      if (common) {
        region = candidate.region;
        return true;
      }
    }
    return false;
  }

  void validateCallLifetime(const Node *call,
                            const FacBorrowChecker::CallContract &contract,
                            const Context &ctx) const {
    std::vector<std::vector<size_t>> actualRegions(contract.lifetimeParamCount);
    const size_t argc = call->c.size() - 1;
    for (size_t i = 0; i < contract.params.size() && i < argc; ++i) {
      const int lifetime = contract.params[i].lifetimeParamIndex;
      if (lifetime < 0) continue;
      if (static_cast<size_t>(lifetime) >= actualRegions.size())
        fail(call, "invalid lifetime parameter index in selected call contract");
      size_t region = 0;
      if (!inferCallLifetimeRegion(call->c[i + 1].get(), ctx, region)) {
        const std::string name = "'" + std::to_string(i + 1) + "'";
        fail(call, "cannot infer the actual lifetime for pointer argument " + name +
             "; pass a pointer with tracked provenance or annotate the caller's pointer parameter");
      }
      actualRegions[static_cast<size_t>(lifetime)].push_back(region);
    }

    std::vector<size_t> inferred(contract.lifetimeParamCount, static_cast<size_t>(-1));
    for (size_t lifetime = 0; lifetime < actualRegions.size(); ++lifetime) {
      const auto &regions = actualRegions[lifetime];
      if (regions.empty()) continue;
      for (size_t candidate : regions) {
        bool common = true;
        for (size_t origin : regions) {
          if (!regionOutlives(origin, candidate)) {
            common = false;
            break;
          }
        }
        if (common) {
          inferred[lifetime] = candidate;
          break;
        }
      }
      if (inferred[lifetime] == static_cast<size_t>(-1)) {
        const std::string name = lifetime < contract.lifetimeNames.size()
            ? contract.lifetimeNames[lifetime] : std::to_string(lifetime);
        fail(call, "cannot unify pointer origins for named lifetime '" + name +
             "'; the origins do not share a provable lifetime region");
      }
    }

    for (const auto &edge : contract.lifetimeOutlives) {
      if (edge.first < 0 || edge.second < 0 ||
          static_cast<size_t>(edge.first) >= inferred.size() ||
          static_cast<size_t>(edge.second) >= inferred.size())
        fail(call, "invalid where relationship in selected lifetime contract");
      const size_t longer = inferred[static_cast<size_t>(edge.first)];
      const size_t shorter = inferred[static_cast<size_t>(edge.second)];
      // An unreferenced lifetime parameter has no caller-side region to
      // instantiate; only relationships grounded in actual pointer arguments
      // are obligations at this call site.
      if (longer == static_cast<size_t>(-1) || shorter == static_cast<size_t>(-1)) continue;
      if (!regionOutlives(longer, shorter)) {
        const std::string longerName = static_cast<size_t>(edge.first) < contract.lifetimeNames.size()
            ? contract.lifetimeNames[static_cast<size_t>(edge.first)] : std::to_string(edge.first);
        const std::string shorterName = static_cast<size_t>(edge.second) < contract.lifetimeNames.size()
            ? contract.lifetimeNames[static_cast<size_t>(edge.second)] : std::to_string(edge.second);
        fail(call, "lifetime contract violation at call site: actual lifetime '" + longerName +
             "' does not outlive '" + shorterName + "' as required by where");
      }
    }
  }

  void checkCall(const Node *call, Context &ctx) const {
    if (!call || call->k != NK::Call || call->c.empty()) return;
    const Node *callee = call->c[0].get();
    // move(value) is a language intrinsic, not an escaping user function call.
    // Its source is still visited by checkExpr and its active-loan prohibition
    // is enforced by the caller immediately after checkCall returns.
    if (callee && callee->k == NK::Ident && callee->s == "move") return;
    const std::string qualifiedCallee = FacBorrowChecker::qualifiedCallPath(callee);
    if (callee && callee->k == NK::Member) {
      static const std::set<std::string> retainingMutators = {
        "add", "addFirst", "addLast", "addEdge", "append", "emplace",
        "enqueue", "insert", "push", "pushBack", "pushFront", "put", "set"
      };
      if (retainingMutators.count(callee->s)) {
        for (size_t i = 1; i < call->c.size(); ++i) {
          std::vector<PointerOrigin> origins;
          collectPointerOrigins(call->c[i].get(), ctx, origins);
          if (!origins.empty())
            fail(call, "dangling-pointer risk: container/mutator '" + callee->s +
                 "' may retain a pointer derived from function-frame storage");
        }
      }
    }
    if (callee && callee->k == NK::Member && !callee->c.empty()) {
      const Node *receiver = callee->c[0].get();
      const std::string raw = rawRoot(receiver);
      auto alias = ctx.aliases.find(raw);
      if (alias != ctx.aliases.end()) {
        if (alias->second.mode == 1 && !isConstMethod(receiver, callee->s, ctx))
          fail(call, "cannot call non-const method '" + callee->s + "' through shared local borrow '" + raw + "'");
        if (alias->second.mode == 2) {
          if (const Loan *child = activeDescendantLoan(ctx, alias->second))
            fail(call, "cannot use parent mutable borrow '" + raw + "' while a reborrow is active" +
                 loanOriginNote(*child));
        }
      } else {
        const StoragePath path = resolvedStoragePath(receiver, ctx);
        const std::string &root = path.root;
        bool blocked = false;
        for (const Loan &loan : ctx.loans)
          if (overlaps(loan, path) &&
              (loan.mode == 2 || !isConstMethod(receiver, callee->s, ctx))) { blocked = true; break; }
        if (blocked)
          fail(call, "cannot call method '" + callee->s + "' through owner '" + root + "' while an overlapping local borrow is active");
      }
    }

    const std::string name = FacBorrowChecker::directCalleeName(callee);
    auto sig = base.signatures.find(name);
    const bool indirectFunctionValue = isIndirectFunctionValue(callee, ctx);
    if (indirectFunctionValue) sig = base.signatures.end();
    const size_t argc = call->c.size() - 1;
    std::vector<const Node *> callArgs;
    callArgs.reserve(argc);
    for (size_t i = 0; i < argc; ++i) callArgs.push_back(call->c[i + 1].get());
    const auto selected = effectiveCallContracts(callee, callArgs, ctx);
    const auto *lifetimeContract = commonLifetimeContract(selected);
    if (lifetimeContract) validateCallLifetime(call, *lifetimeContract, ctx);
    const bool valueStructConstructor = isValueStructConstructorCall(call);
    for (size_t i = 0; i < argc; ++i) {
      const Node *arg = call->c[i + 1].get();
      const Node *valueArgument = arg;
      // move(value) preserves the static type of its operand for aggregate
      // provenance checks at this call boundary.
      if (arg && arg->k == NK::Call && arg->c.size() == 2 && arg->c[0] &&
          FacBorrowChecker::qualifiedCallPath(arg->c[0].get()) == "move")
        valueArgument = arg->c[1].get();
      const std::string argumentTypeKey = expressionTypeKey(valueArgument, ctx, fields);
      const bool argumentIsValueStruct = isValueStructTypeKey(argumentTypeKey);
      if (argumentIsValueStruct && !hasCompleteAggregatePointerFacts(valueArgument, ctx))
        fail(call, "cannot pass value struct with pointer fields because one or more field lifetimes have no verified provenance");
      std::vector<PointerOrigin> pointerOrigins;
      // thread.join's single `ptr thread` argument is a consumed opaque handle,
      // not a pointer retained by the callee. Its source may be a value-struct
      // parameter field whose external provenance is intentionally not known
      // inside this function body; the builtin contract consumes the value.
      const bool directThreadJoinConsumesHandle = qualifiedCallee == "thread.join" && i == 0 &&
          argumentTypeKey == "ptr thread";
      // A direct, uniquely-resolved helper may receive the opaque thread handle
      // only when every selected overload's checked body uses that exact
      // ptr thread parameter exclusively as thread.join's argument. This is
      // not a general noescape rule and does not authorize unknown helpers.
      const bool helperThreadJoinOnly = argumentTypeKey == "ptr thread" &&
          !selected.empty() && std::all_of(selected.begin(), selected.end(), [i](
              const FacBorrowChecker::CallContract *contract) {
            return contract && i < contract->params.size() &&
                   contract->params[i].threadHandleJoinOnly;
          });
      const bool helperStructThreadJoinOnly = argumentIsValueStruct && !selected.empty() &&
          std::all_of(selected.begin(), selected.end(), [i](
              const FacBorrowChecker::CallContract *contract) {
            return contract && i < contract->params.size() &&
                   contract->params[i].threadHandleStructJoinOnly;
          });
      const bool helperStructPointerNoescape = argumentIsValueStruct && !selected.empty() &&
          std::all_of(selected.begin(), selected.end(), [i](
              const FacBorrowChecker::CallContract *contract) {
            return contract && i < contract->params.size() &&
                   contract->params[i].aggregatePointerFieldsNoescape;
          });
      const bool consumesThreadHandle = directThreadJoinConsumesHandle || helperThreadJoinOnly;
      if (!consumesThreadHandle && !helperStructThreadJoinOnly &&
          !helperStructPointerNoescape)
        collectPointerOrigins(arg, ctx, pointerOrigins);
      const bool lifetimeBound = callParameterLifetimeBound(lifetimeContract, i, argc);
      // A value-struct constructor transfers its arguments into the returned
      // value; its destination lifetime is checked at the enclosing local
      // declaration/assignment/return, not as an escaping function call. A
      // non-null raw pointer with no tracked lifetime is still rejected.
      if (valueStructConstructor && expressionTypeKey(arg, ctx, fields).compare(0, 4, "ptr ") == 0 &&
          pointerOrigins.empty() && !isNullPointerValue(arg))
        fail(call, "cannot store an untracked pointer in a value-struct field; use a tracked local address or verified named lifetime (noescape values cannot be retained)");
      if (!valueStructConstructor && !pointerOrigins.empty() && !callParameterNoescape(selected, i, argc) && !lifetimeBound && !consumesThreadHandle) {
        const PointerOrigin &origin = pointerOrigins.front();
        fail(call, "dangling-pointer risk: pointer derived from '" + origin.root +
             "' is passed to a parameter without a verified noescape or named-lifetime contract");
      }
      const std::string raw = rawRoot(arg);
      if (raw.empty()) continue;
      auto alias = ctx.aliases.find(raw);
      bool hasCandidate = false, definitelyBorrowed = true, mayBeMutable = false;
      if (!selected.empty()) {
        for (const auto *contract : selected) {
          if (!contract || i >= contract->params.size()) continue;
          hasCandidate = true;
          const auto &param = contract->params[i];
          const BorrowMode mode = !param.ref ? 0 : (param.immutableRef ? 1 : 2);
          if (mode == 0) definitelyBorrowed = false;
          if (mode == 2) mayBeMutable = true;
        }
      } else if (sig != base.signatures.end()) {
        for (const auto &mask : sig->second) {
          if (mask.size() != argc) continue;
          hasCandidate = true;
          if (mask[i] == 0) definitelyBorrowed = false;
          if (mask[i] == 2) mayBeMutable = true;
        }
      }
      if (alias != ctx.aliases.end()) {
        if (alias->second.mode == 1 && mayBeMutable)
          fail(call, "cannot pass shared local borrow '" + raw + "' to a call that may require mutable ref access");
        if (alias->second.mode == 2 && hasActiveDescendant(ctx, alias->second))
          fail(call, "cannot pass parent mutable borrow '" + raw + "' while a reborrow is active");
        // A class/struct alias passed by value can be retained by an ordinary
        // callee and later mutate the same identity after this lexical loan
        // ends. Permit it only when every selected direct-call contract marks
        // the parameter as borrowed; unresolved/indirect calls fail closed.
        if (aggregateTypes.count(expressionType(arg, ctx))) {
          bool mayPassByValue = sig == base.signatures.end() || !hasCandidate;
          if (hasCandidate) {
            if (!selected.empty()) {
              for (const auto *contract : selected)
                if (contract && i < contract->params.size() && !contract->params[i].ref) mayPassByValue = true;
            } else {
              for (const auto &mask : sig->second)
                if (mask.size() == argc && mask[i] == 0) mayPassByValue = true;
            }
          }
          if (mayPassByValue)
            fail(call, "cannot pass aggregate local borrow alias '" + raw + "' by value or to an unverified call; it may escape the lexical loan");
        }
        continue; // a verified ref call is a temporary reborrow of this alias
      }
      if (sig == base.signatures.end() || !hasCandidate) continue;
      const Loan *loan = findLoanFor(ctx, arg);
      if (loan && (mayBeMutable || (definitelyBorrowed && loan->mode == 2)))
        fail(call, "ref argument '" + raw + "' conflicts with an active local borrow");
    }
  }

  size_t makeLifetimeRegion(size_t parent, const Node *owner) const {
    const auto key = std::make_pair(parent, owner);
    auto known = lifetimeRegionByOwner.find(key);
    if (known != lifetimeRegionByOwner.end()) return known->second;
    const size_t id = lifetimeRegions.size();
    lifetimeRegions.push_back(LifetimeRegion{id, parent, owner});
    lifetimeRegionByOwner.emplace(key, id);
    // A lexical parent outlives every child region. Retain that relation as an
    // edge so concrete lexical regions and abstract function lifetimes share
    // the same graph-based inference path. Stable owner keys also let repeated
    // loop-analysis passes reuse this exact region and converge.
    lifetimeRegionOutlivesEdges.push_back({parent, id});
    return id;
  }

  bool regionOutlives(size_t longer, size_t shorter) const {
    if (longer >= lifetimeRegions.size() || shorter >= lifetimeRegions.size()) return false;
    if (longer == shorter) return true;
    // Lifetime parameters are abstract regions. Their declared `where`
    // relationships and the guarantee that each input lifetime remains valid
    // for the duration of the function body are represented in this directed
    // graph. BFS computes the transitive closure without relying on declaration
    // order or a tree-shaped approximation of lifetime relationships.
    std::vector<size_t> pending{longer};
    std::vector<bool> visited(lifetimeRegions.size(), false);
    visited[longer] = true;
    for (size_t cursor = 0; cursor < pending.size(); ++cursor) {
      const size_t current = pending[cursor];
      for (const auto &edge : lifetimeRegionOutlivesEdges) {
        if (edge.first != current || edge.second >= visited.size() || visited[edge.second]) continue;
        if (edge.second == shorter) return true;
        visited[edge.second] = true;
        pending.push_back(edge.second);
      }
    }
    return false;
  }

  // V234 extends the bounded local direct-call proof to nested closures. A
  // closure may be created inside another closure only when every enclosing
  // closure is itself bound to a local function variable and used exclusively
  // by immediate direct calls. This keeps nested closure environments inside
  // the already-verified parent lifetime. Copies, returns, argument passing,
  // assignments, self-capture, nested-function references and shadowing remain
  // rejected. A recursion guard makes mutually-referential closure-use proofs
  // fail closed rather than recursing indefinitely.
  bool isLocalDirectCallOnlyClosure(const Node *lambda, const Context &ctx) const {
    if (!lambda || !ctx.functionRoot || ctx.functionRoot->c.empty()) return false;

    std::set<const Node *> activeProofs;
    std::function<bool(const Node *, std::set<const Node *> &)> prove;
    prove = [&](const Node *candidate, std::set<const Node *> &active) -> bool {
      if (!candidate || !active.insert(candidate).second) return false;
      struct ActiveProofGuard {
        std::set<const Node *> &active;
        const Node *node;
        ~ActiveProofGuard() { active.erase(node); }
      } activeGuard{active, candidate};

      const Node *binding = nullptr;
      size_t bindingCount = 0;
      std::function<void(const Node *)> findBinding = [&](const Node *node) {
        if (!node) return;
        if (node->k == NK::VarDecl && node->ts.cat == "func" &&
            node->c.size() == 1 && node->c[0].get() == candidate) {
          binding = node;
          ++bindingCount;
        }
        for (const auto &child : node->c) findBinding(child.get());
        for (const auto &method : node->methods) findBinding(method.get());
        for (const auto &cs : node->cases) {
          for (const auto &value : cs.vals) findBinding(value.get());
          for (const auto &range : cs.ranges) {
            findBinding(range.lo.get());
            findBinding(range.hi.get());
          }
          findBinding(cs.guard.get());
          findBinding(cs.body.get());
          findBinding(cs.exprBody.get());
        }
        findBinding(node->deflt.get());
      };
      findBinding(ctx.functionRoot->c[0].get());
      if (bindingCount != 1 || !binding) return false;

      const std::string name = binding->s;
      for (const Param &param : ctx.functionRoot->params)
        if (param.name == name) return false;

      bool safe = true;
      std::function<void(const Node *, const Node *, const std::vector<const Node *> &, unsigned)> scan =
          [&](const Node *node, const Node *parent,
              const std::vector<const Node *> &enclosingLambdas, unsigned functionDepth) {
        if (!node || !safe) return;
        if (node->k == NK::VarDecl && node != binding && node->s == name) {
          safe = false; // same-spelling shadow/redeclaration: do not guess binding identity
          return;
        }
        if ((node->k == NK::ForEach || node->k == NK::Try) && node->s == name) {
          safe = false; // iteration/catch bindings can shadow the closure value
          return;
        }
        if (node->k == NK::Ident && node->s == name) {
          const bool directCall = parent && parent->k == NK::Call &&
              !parent->c.empty() && parent->c[0].get() == node;
          // A closure cannot invoke itself through a captured variable. Uses
          // from a nested closure are accepted only if every parent closure has
          // an independent local-direct-call-only proof.
          if (!directCall || functionDepth != 0 ||
              std::find(enclosingLambdas.begin(), enclosingLambdas.end(), candidate) != enclosingLambdas.end()) {
            safe = false;
            return;
          }
          for (const Node *parentLambda : enclosingLambdas) {
            if (!prove(parentLambda, active)) {
              safe = false;
              return;
            }
          }
        }

        unsigned childFunctionDepth = functionDepth;
        if (node->k == NK::Func && node != ctx.functionRoot) ++childFunctionDepth;
        std::vector<const Node *> childLambdas = enclosingLambdas;
        if (node->k == NK::Lambda) childLambdas.push_back(node);
        for (const auto &child : node->c) scan(child.get(), node, childLambdas, childFunctionDepth);
        for (const auto &method : node->methods) scan(method.get(), node, childLambdas, childFunctionDepth);
        for (const auto &cs : node->cases) {
          for (const auto &value : cs.vals) scan(value.get(), node, childLambdas, childFunctionDepth);
          for (const auto &range : cs.ranges) {
            scan(range.lo.get(), node, childLambdas, childFunctionDepth);
            scan(range.hi.get(), node, childLambdas, childFunctionDepth);
          }
          if (std::find(cs.bindings.begin(), cs.bindings.end(), name) != cs.bindings.end()) {
            safe = false;
            return;
          }
          scan(cs.guard.get(), node, childLambdas, childFunctionDepth);
          scan(cs.body.get(), node, childLambdas, childFunctionDepth);
          scan(cs.exprBody.get(), node, childLambdas, childFunctionDepth);
        }
        scan(node->deflt.get(), node, childLambdas, childFunctionDepth);
      };
      scan(ctx.functionRoot->c[0].get(), ctx.functionRoot, {}, 0);
      return safe;
    };

    return prove(lambda, activeProofs);
  }

  bool pointerOriginsOutliveRegion(const std::vector<PointerOrigin> &origins,
                                   size_t destinationRegion) const {
    for (const PointerOrigin &origin : origins) {
      if (origin.fromNoescapeParameter || !regionOutlives(origin.region, destinationRegion))
        return false;
    }
    return true;
  }

  void addLifetimeConstraint(size_t longer, size_t shorter,
                             const Node *at, const Node *ownerDecl,
                             bool pointerStorage = false,
                             bool externalDestination = false,
                             const std::string &destination = {}) const {
    for (const LifetimeConstraint &known : lifetimeConstraints) {
      if (known.longer == longer && known.shorter == shorter && known.at == at &&
          known.ownerDecl == ownerDecl && known.pointerStorage == pointerStorage &&
          known.externalDestination == externalDestination && known.destination == destination)
        return;
    }
    lifetimeConstraints.push_back(LifetimeConstraint{
        longer, shorter, at, ownerDecl, pointerStorage, externalDestination, destination});
  }

  void solveLifetimeConstraints() const {
    // Solve every region relationship at the end of the function rather than
    // mixing lexical-region checks into individual syntax visitors. This gives
    // local ref loans and pointer-provenance stores one consistent outlives
    // gate, while keeping pointer escapes distinguishable in diagnostics.
    for (const LifetimeConstraint &constraint : lifetimeConstraints) {
      const bool outlives = !constraint.externalDestination &&
          regionOutlives(constraint.longer, constraint.shorter);
      if (outlives) continue;
      const std::string owner = constraint.ownerDecl ? constraint.ownerDecl->s : std::string("borrow source");
      if (constraint.pointerStorage) {
        const std::string destination = constraint.destination.empty()
            ? std::string("pointer storage") : constraint.destination;
        fail(constraint.at, "dangling-pointer risk: address of local storage '" + owner +
             "' cannot be stored in '" + destination +
             "' because the destination may outlive its owner");
      }
      fail(constraint.at, "lifetime region violation: owner '" + owner +
           "' does not outlive this local borrow; the owner must be declared in the same or an enclosing scope");
    }
  }

  static void appendUniqueOrigin(std::vector<PointerOrigin> &out, const PointerOrigin &origin) {
    for (const PointerOrigin &old : out) {
      if (old.fromNoescapeParameter || origin.fromNoescapeParameter) {
        if (old.fromNoescapeParameter && origin.fromNoescapeParameter && old.parameter == origin.parameter) return;
        continue;
      }
      if ((old.rootDecl && origin.rootDecl && old.rootDecl == origin.rootDecl) ||
          (!old.rootDecl && !origin.rootDecl && old.root == origin.root && old.region == origin.region))
        return;
    }
    out.push_back(origin);
  }

  static std::string aggregateOriginKey(const std::string &root, const std::string &projection) {
    return root + "\x1f" + projection;
  }

  static std::string joinAggregateProjection(const std::string &base, const std::string &field) {
    return base.empty() ? field : base + "." + field;
  }

  void appendAggregateOrigins(const std::string &root, const std::string &projection,
                              bool includeDescendants, const Context &ctx,
                              std::vector<PointerOrigin> &out) const {
    const std::string prefix = root + "\x1f";
    for (const auto &entry : ctx.aggregatePointerOriginsByPath) {
      if (entry.first.compare(0, prefix.size(), prefix) != 0) continue;
      const std::string storedProjection = entry.first.substr(prefix.size());
      const bool wildcard = storedProjection == "*";
      const bool exact = storedProjection == projection;
      const bool descendant = includeDescendants &&
          (projection.empty() || storedProjection.compare(0, projection.size() + 1,
             projection + ".") == 0);
      if (!wildcard && !exact && !descendant) continue;
      for (const PointerOrigin &origin : entry.second) appendUniqueOrigin(out, origin);
    }
  }

  void eraseAggregateOrigins(const std::string &root, const std::string &projection,
                             bool includeDescendants, Context &ctx) const {
    const std::string prefix = root + "\x1f";
    for (auto it = ctx.aggregatePointerOriginsByPath.begin();
         it != ctx.aggregatePointerOriginsByPath.end();) {
      if (it->first.compare(0, prefix.size(), prefix) != 0) { ++it; continue; }
      const std::string storedProjection = it->first.substr(prefix.size());
      const bool exact = storedProjection == projection;
      const bool descendant = includeDescendants &&
          (projection.empty() || storedProjection.compare(0, projection.size() + 1,
             projection + ".") == 0);
      if (exact || descendant || (includeDescendants && storedProjection == "*"))
        it = ctx.aggregatePointerOriginsByPath.erase(it);
      else ++it;
    }
  }


  // Join aggregate pointer provenance at control-flow merge points. A field is
  // considered known after the join only when every reachable predecessor has
  // a fact for that exact path. Origins are unioned (may-origin analysis), so a
  // later return/store must satisfy the lifetime of every possible branch.
  // If a branch shadows the root name, that branch still refers to the outer
  // binding after the branch ends and therefore contributes the base facts.
  void mergeAggregatePointerOrigins(const Context &baseContext,
                                    const std::vector<Context> &branches,
                                    Context &destination) const {
    if (branches.empty()) return;
    auto joined = baseContext.aggregatePointerOriginsByPath;
    std::set<std::string> roots;
    for (const auto &entry : baseContext.typeKeys)
      if (isValueStructTypeKey(entry.second)) roots.insert(entry.first);

    for (const std::string &root : roots) {
      auto baseType = baseContext.typeKeys.find(root);
      auto baseDecl = baseContext.decls.find(root);
      if (baseType == baseContext.typeKeys.end() || baseDecl == baseContext.decls.end()) continue;

      const std::string prefix = root + "\x1f";
      std::set<std::string> paths;
      for (const auto &entry : baseContext.aggregatePointerOriginsByPath)
        if (entry.first.compare(0, prefix.size(), prefix) == 0) paths.insert(entry.first);

      std::vector<const Context *> states;
      states.reserve(branches.size());
      for (const Context &branch : branches) {
        auto branchType = branch.typeKeys.find(root);
        auto branchDecl = branch.decls.find(root);
        const bool sameBinding = branchType != branch.typeKeys.end() &&
            branchDecl != branch.decls.end() && branchType->second == baseType->second &&
            branchDecl->second == baseDecl->second;
        const Context *state = sameBinding ? &branch : &baseContext;
        states.push_back(state);
        if (sameBinding) {
          for (const auto &entry : branch.aggregatePointerOriginsByPath)
            if (entry.first.compare(0, prefix.size(), prefix) == 0) paths.insert(entry.first);
        }
      }

      for (auto it = joined.begin(); it != joined.end();) {
        if (it->first.compare(0, prefix.size(), prefix) == 0) it = joined.erase(it);
        else ++it;
      }

      for (const std::string &path : paths) {
        bool knownOnEveryPath = true;
        std::vector<PointerOrigin> origins;
        for (const Context *state : states) {
          auto fact = state->aggregatePointerOriginsByPath.find(path);
          if (fact == state->aggregatePointerOriginsByPath.end()) {
            knownOnEveryPath = false;
            break;
          }
          for (const PointerOrigin &origin : fact->second) appendUniqueOrigin(origins, origin);
        }
        // Missing is Unknown, not Null. Do not manufacture a known-null fact
        // when even one predecessor lacks verified provenance for this field.
        if (knownOnEveryPath) joined[path] = std::move(origins);
      }
    }
    destination.aggregatePointerOriginsByPath = std::move(joined);

    // Pointer locals can feed aggregate fields later in the same outer scope.
    // Carry their may-origins through the same merge so a block/branch update
    // cannot leave the parent context with a stale, narrower source set.
    auto joinedPointers = baseContext.pointerOrigins;
    for (const std::string &name : baseContext.pointerVars) {
      auto baseDecl = baseContext.decls.find(name);
      if (baseDecl == baseContext.decls.end()) continue;
      std::vector<PointerOrigin> origins;
      bool knownOnEveryPath = true;
      for (const Context &branch : branches) {
        auto branchDecl = branch.decls.find(name);
        const bool sameBinding = branch.pointerVars.count(name) != 0 &&
            branchDecl != branch.decls.end() && branchDecl->second == baseDecl->second;
        const Context &state = sameBinding ? branch : baseContext;
        auto fact = state.pointerOrigins.find(name);
        if (fact == state.pointerOrigins.end()) {
          knownOnEveryPath = false;
          break;
        }
        for (const PointerOrigin &origin : fact->second) appendUniqueOrigin(origins, origin);
      }
      if (knownOnEveryPath) joinedPointers[name] = std::move(origins);
      else joinedPointers.erase(name); // absent means unknown, never verified null
    }
    destination.pointerOrigins = std::move(joinedPointers);
  }

  static bool samePointerOrigins(const std::vector<PointerOrigin> &left,
                                 const std::vector<PointerOrigin> &right) {
    if (left.size() != right.size()) return false;
    for (size_t i = 0; i < left.size(); ++i) {
      const PointerOrigin &a = left[i];
      const PointerOrigin &b = right[i];
      if (a.root != b.root || a.rootDecl != b.rootDecl || a.region != b.region ||
          a.fromNoescapeParameter != b.fromNoescapeParameter || a.parameter != b.parameter)
        return false;
    }
    return true;
  }

  static bool sameOriginMap(const std::map<std::string, std::vector<PointerOrigin>> &left,
                            const std::map<std::string, std::vector<PointerOrigin>> &right) {
    if (left.size() != right.size()) return false;
    auto a = left.begin();
    auto b = right.begin();
    for (; a != left.end(); ++a, ++b) {
      if (a->first != b->first || !samePointerOrigins(a->second, b->second)) return false;
    }
    return true;
  }

  // Compare only pointer facts belonging to bindings visible on loop entry.
  // Loop-local declarations are deliberately excluded from the loop-carried
  // state; their storage ends before control reaches the statement after loop.
  bool sameVisibleLoopPointerFacts(const Context &visible,
                                   const Context &left,
                                   const Context &right) const {
    for (const auto &entry : visible.typeKeys) {
      const std::string &root = entry.first;
      if (!isValueStructTypeKey(entry.second)) continue;
      auto visibleDecl = visible.decls.find(root);
      auto leftDecl = left.decls.find(root);
      auto rightDecl = right.decls.find(root);
      auto leftType = left.typeKeys.find(root);
      auto rightType = right.typeKeys.find(root);
      if (visibleDecl == visible.decls.end() || leftDecl == left.decls.end() ||
          rightDecl == right.decls.end() || leftType == left.typeKeys.end() ||
          rightType == right.typeKeys.end() || leftDecl->second != visibleDecl->second ||
          rightDecl->second != visibleDecl->second || leftType->second != entry.second ||
          rightType->second != entry.second) return false;
      const std::string prefix = root + "\x1f";
      std::map<std::string, std::vector<PointerOrigin>> leftFacts, rightFacts;
      for (const auto &fact : left.aggregatePointerOriginsByPath)
        if (fact.first.compare(0, prefix.size(), prefix) == 0) leftFacts.emplace(fact);
      for (const auto &fact : right.aggregatePointerOriginsByPath)
        if (fact.first.compare(0, prefix.size(), prefix) == 0) rightFacts.emplace(fact);
      if (!sameOriginMap(leftFacts, rightFacts)) return false;
    }
    for (const std::string &name : visible.pointerVars) {
      auto visibleDecl = visible.decls.find(name);
      auto leftDecl = left.decls.find(name);
      auto rightDecl = right.decls.find(name);
      if (visibleDecl == visible.decls.end() || leftDecl == left.decls.end() ||
          rightDecl == right.decls.end() || leftDecl->second != visibleDecl->second ||
          rightDecl->second != visibleDecl->second || !left.pointerVars.count(name) ||
          !right.pointerVars.count(name)) return false;
      auto leftFact = left.pointerOrigins.find(name);
      auto rightFact = right.pointerOrigins.find(name);
      if ((leftFact == left.pointerOrigins.end()) != (rightFact == right.pointerOrigins.end()))
        return false;
      if (leftFact != left.pointerOrigins.end() &&
          !samePointerOrigins(leftFact->second, rightFact->second)) return false;
    }
    return true;
  }

  // Break exits are not yet represented as separate provenance predecessor
  // states in this checker. Keep those loops fail-closed instead of pretending
  // their post-loop state is the ordinary back-edge state. Nested breaks are
  // conservatively included as well; this can reject safe programs but cannot
  // erase a possible source lifetime.
  static bool containsAnyBreak(const Node *node) {
    if (!node) return false;
    if (node->k == NK::Break) return true;
    for (const auto &child : node->c)
      if (containsAnyBreak(child.get())) return true;
    for (const auto &method : node->methods)
      if (containsAnyBreak(method.get())) return true;
    for (const auto &cs : node->cases) {
      if (containsAnyBreak(cs.guard.get()) || containsAnyBreak(cs.body.get()) ||
          containsAnyBreak(cs.exprBody.get())) return true;
    }
    return containsAnyBreak(node->deflt.get());
  }

  // Merge the zero-iteration entry with one back-edge state. Repeating this
  // operation over the transfer function computes the least may-origin fixed
  // point for the visible pointer locals and exact value-struct field paths.
  void joinLoopPointerFacts(const Context &entry, const Context &backedge,
                            Context &joined) const {
    mergeAggregatePointerOrigins(entry, std::vector<Context>{entry, backedge}, joined);
  }

  // A loop may execute zero, one or many times. This pass does not compute a
  // loop fixed point yet; if one pass changes a visible pointer-bearing root or
  // pointer local, invalidate that binding after the loop rather than retaining
  // a pre-loop fact that could miss a later iteration's source.
  void invalidateLoopChangedPointerFacts(const Context &before, const Context &after,
                                         Context &destination) const {
    for (const auto &entry : before.typeKeys) {
      const std::string &root = entry.first;
      if (!isValueStructTypeKey(entry.second)) continue;
      auto beforeDecl = before.decls.find(root);
      auto afterDecl = after.decls.find(root);
      auto afterType = after.typeKeys.find(root);
      if (beforeDecl == before.decls.end() || afterDecl == after.decls.end() ||
          afterType == after.typeKeys.end() || afterDecl->second != beforeDecl->second ||
          afterType->second != entry.second) continue;

      const std::string prefix = root + "\x1f";
      std::set<std::string> paths;
      for (const auto &fact : before.aggregatePointerOriginsByPath)
        if (fact.first.compare(0, prefix.size(), prefix) == 0) paths.insert(fact.first);
      for (const auto &fact : after.aggregatePointerOriginsByPath)
        if (fact.first.compare(0, prefix.size(), prefix) == 0) paths.insert(fact.first);

      bool changed = false;
      for (const std::string &path : paths) {
        auto oldFact = before.aggregatePointerOriginsByPath.find(path);
        auto newFact = after.aggregatePointerOriginsByPath.find(path);
        if (oldFact == before.aggregatePointerOriginsByPath.end() ||
            newFact == after.aggregatePointerOriginsByPath.end() ||
            !samePointerOrigins(oldFact->second, newFact->second)) {
          changed = true;
          break;
        }
      }
      if (changed) {
        for (auto it = destination.aggregatePointerOriginsByPath.begin();
             it != destination.aggregatePointerOriginsByPath.end();) {
          if (it->first.compare(0, prefix.size(), prefix) == 0)
            it = destination.aggregatePointerOriginsByPath.erase(it);
          else ++it;
        }
      }
    }

    for (const std::string &name : before.pointerVars) {
      auto beforeDecl = before.decls.find(name);
      auto afterDecl = after.decls.find(name);
      if (beforeDecl == before.decls.end() || afterDecl == after.decls.end() ||
          afterDecl->second != beforeDecl->second || !after.pointerVars.count(name)) continue;
      auto oldFact = before.pointerOrigins.find(name);
      auto newFact = after.pointerOrigins.find(name);
      const bool changed = oldFact == before.pointerOrigins.end() ||
          newFact == after.pointerOrigins.end() ||
          !samePointerOrigins(oldFact->second, newFact->second);
      if (changed) destination.pointerOrigins.erase(name);
    }
  }

  // Build field-level provenance for a local value-struct initializer or copy.
  // A constructor is mapped using declaration-order fields retained from the AST;
  // a copied aggregate remaps the source's exact subtree to the destination path.
  // Unsupported expressions fall back to a wildcard summary (conservative).
  bool collectAggregatePointerPaths(const Node *expr, const std::string &aggregateType,
                                    const Context &ctx, const std::string &destinationRoot,
                                    const std::string &destinationProjection,
                                    std::map<std::string, std::vector<PointerOrigin>> &out) const {
    if (!expr) return true;
    if (expr->k == NK::Call && expr->c.size() == 2 && expr->c[0] &&
        expr->c[0]->k == NK::Ident && expr->c[0]->s == "move")
      return collectAggregatePointerPaths(expr->c[1].get(), aggregateType, ctx,
                                          destinationRoot, destinationProjection, out);

    if (isValueStructConstructorCall(expr)) {
      const std::string typeName = expr->c[0]->s;
      auto order = fieldOrder.find(typeName);
      auto metadata = fields.find(typeName);
      if (order == fieldOrder.end() || metadata == fields.end()) return false;
      const size_t count = std::min(order->second.size(), expr->c.size() - 1);
      for (size_t i = 0; i < count; ++i) {
        const std::string &field = order->second[i];
        auto fieldInfo = metadata->second.find(field);
        if (fieldInfo == metadata->second.end()) continue;
        const std::string &fieldType = fieldInfo->second.type;
        const std::string targetProjection = joinAggregateProjection(destinationProjection, field);
        const Node *argument = expr->c[i + 1].get();
        if (fieldType.compare(0, 4, "ptr ") == 0) {
          std::vector<PointerOrigin> origins;
          collectPointerOrigins(argument, ctx, origins);
          // An empty vector is meaningful: it records a verified null field,
          // distinct from a missing fact (unknown provenance).
          out[aggregateOriginKey(destinationRoot, targetProjection)] = std::move(origins);
        } else if (isValueStructTypeKey(fieldType)) {
          if (!collectAggregatePointerPaths(argument, fieldType, ctx, destinationRoot,
                                            targetProjection, out)) return false;
        }
      }
      return true;
    }

    const StoragePath source = resolvedStoragePath(expr, ctx);
    if (source.exact && !source.root.empty() && !source.crossesManagedObjectBoundary &&
        isValueStructTypeKey(expressionTypeKey(expr, ctx, fields))) {
      const std::string sourcePrefix = source.root + "\x1f";
      for (const auto &entry : ctx.aggregatePointerOriginsByPath) {
        if (entry.first.compare(0, sourcePrefix.size(), sourcePrefix) != 0) continue;
        const std::string storedProjection = entry.first.substr(sourcePrefix.size());
        std::string suffix;
        if (storedProjection == "*") suffix = "*";
        else if (source.projection.empty()) suffix = storedProjection;
        else if (storedProjection == source.projection) suffix.clear();
        else if (storedProjection.compare(0, source.projection.size() + 1,
                                         source.projection + ".") == 0)
          suffix = storedProjection.substr(source.projection.size() + 1);
        else continue;
        const std::string targetProjection = suffix.empty() ? destinationProjection :
            (destinationProjection.empty() ? suffix : destinationProjection + "." + suffix);
        out[aggregateOriginKey(destinationRoot, targetProjection)] = entry.second;
      }
      return true;
    }

    std::vector<PointerOrigin> fallback;
    collectPointerOrigins(expr, ctx, fallback);
    if (!fallback.empty()) out[aggregateOriginKey(destinationRoot, "*")] = std::move(fallback);
    return true;
  }

  void collectAggregateRootOrigins(const std::string &root, const Context &ctx,
                                   std::vector<PointerOrigin> &out) const {
    appendAggregateOrigins(root, "", true, ctx, out);
  }

  void collectPointerFieldPaths(const std::string &typeKey, const std::string &prefix,
                                std::vector<std::string> &out,
                                std::set<std::string> &active) const {
    if (!isValueStructTypeKey(typeKey)) return;
    const std::string typeName = typeKey.substr(7);
    if (!active.insert(typeName).second) return;
    auto metadata = fields.find(typeName);
    auto order = fieldOrder.find(typeName);
    if (metadata != fields.end() && order != fieldOrder.end()) {
      for (const std::string &field : order->second) {
        auto found = metadata->second.find(field);
        if (found == metadata->second.end()) continue;
        const std::string path = joinAggregateProjection(prefix, field);
        if (found->second.type.compare(0, 4, "ptr ") == 0) out.push_back(path);
        else if (isValueStructTypeKey(found->second.type))
          collectPointerFieldPaths(found->second.type, path, out, active);
      }
    }
    active.erase(typeName);
  }

  std::vector<std::string> pointerFieldPaths(const std::string &typeKey) const {
    std::vector<std::string> paths;
    std::set<std::string> active;
    collectPointerFieldPaths(typeKey, "", paths, active);
    return paths;
  }

  bool hasCompleteAggregatePointerFactsForRoot(const std::string &root,
                                               const std::string &typeKey,
                                               const Context &ctx) const {
    if (!isValueStructTypeKey(typeKey)) return true;
    const std::vector<std::string> required = pointerFieldPaths(typeKey);
    if (required.empty()) return true;
    // A root-level wildcard is deliberately insufficient here: closure capture
    // needs an exact proof for every pointer-bearing field. In particular, an
    // aggregate parameter with no local provenance facts is Unknown, not null.
    for (const std::string &path : required)
      if (!ctx.aggregatePointerOriginsByPath.count(aggregateOriginKey(root, path)))
        return false;
    return true;
  }

  bool hasCompleteAggregatePointerFacts(const Node *expr, const Context &ctx) const {
    const std::string typeKey = expressionTypeKey(expr, ctx, fields);
    if (!isValueStructTypeKey(typeKey)) return true;
    const std::vector<std::string> required = pointerFieldPaths(typeKey);
    if (required.empty()) return true;
    std::map<std::string, std::vector<PointerOrigin>> temporary;
    if (!collectAggregatePointerPaths(expr, typeKey, ctx, "$fac_v226_probe", "", temporary))
      return false;
    for (const std::string &path : required)
      if (!temporary.count(aggregateOriginKey("$fac_v226_probe", path))) return false;
    return true;
  }

  void collectPointerOrigins(const Node *expr, const Context &ctx,
                             std::vector<PointerOrigin> &out) const {
    if (!expr) return;
    // Dereferencing a pointer produces the pointee value, not another pointer
    // carrying the source pointer's escape provenance. A pointer-valued pointee
    // is handled conservatively by the typed storage/effect checks elsewhere.
    if (expr->k == NK::Deref) return;
    // V226: pointer-valued fields resolve to one exact projection. Nested
    // value-struct reads collect only that subtree, so sibling fields no longer
    // contaminate one another's lifetime facts.
    if (expr->k == NK::Member) {
      const std::string memberType = expressionType(expr, ctx);
      if (memberType.compare(0, 4, "ptr ") != 0 && !isValueStructTypeKey(memberType)) return;
      const StoragePath path = resolvedStoragePath(expr, ctx);
      if (!path.exact || path.root.empty() || path.crossesManagedObjectBoundary) return;
      if (memberType.compare(0, 4, "ptr ") == 0) {
        const auto rootType = ctx.typeKeys.find(path.root);
        const std::string exactKey = aggregateOriginKey(path.root, path.projection);
        const bool knownExact = ctx.aggregatePointerOriginsByPath.count(exactKey) != 0;
        const bool knownWildcard = ctx.aggregatePointerOriginsByPath.count(
            aggregateOriginKey(path.root, "*")) != 0;
        if (!knownExact && !knownWildcard && rootType != ctx.typeKeys.end() &&
            isValueStructTypeKey(rootType->second))
          fail(expr, "cannot read pointer field '" + path.projection +
               "' because this aggregate has no verified field provenance; initialize/copy it from a checked value-struct source first");
      }
      appendAggregateOrigins(path.root, path.projection,
                             isValueStructTypeKey(memberType), ctx, out);
      return;
    }
    if (expr->k == NK::Call && expr->c.size() == 2 && expr->c[0] &&
        expr->c[0]->k == NK::Ident && expr->c[0]->s == "addr") {
      const Node *source = expr->c[1].get();
      const std::string root = rawRoot(source);
      auto frame = ctx.frameStorage.find(root);
      if (!root.empty() && frame != ctx.frameStorage.end()) {
        const auto identity = resolvedRootIdentity(source, ctx);
        appendUniqueOrigin(out, PointerOrigin{root, identity.second, frame->second, expr->line});
      }
      return;
    }
    // A value returned by a call cannot inherit provenance from an argument
    // whose selected direct or function-value contract is verified `noescape`: that
    // contract forbids returning or retaining the argument-derived pointer.
    // Keep provenance from all other arguments so unknown/retaining calls
    // remain conservative.
    if (expr->k == NK::Call && !expr->c.empty()) {
      const Node *callee = expr->c[0].get();
      if (FacBorrowChecker::qualifiedCallPath(callee) == "thread.start") {
        // thread.start allocates a ThreadH independently of caller stack
        // storage. Its validity is governed by the owned-handle lifecycle
        // (consumed by thread.join), not by an input pointer lifetime.
        appendUniqueOrigin(out, PointerOrigin{"thread.start owned handle", nullptr,
                                               0, expr->line, false, nullptr});
        return;
      }
      const size_t argc = expr->c.size() - 1;
      std::vector<const Node *> callArgs;
      callArgs.reserve(argc);
      for (size_t i = 0; i < argc; ++i) callArgs.push_back(expr->c[i + 1].get());
      const auto selected = effectiveCallContracts(callee, callArgs, ctx);
      const auto *lifetimeContract = commonLifetimeContract(selected);
      if (lifetimeContract && lifetimeContract->returnLifetimeParamIndex >= 0) {
        // The callee's body checker proves that every returned origin belongs
        // to a parameter whose declared lifetime outlives the return lifetime.
        // At the caller, substitute only those parameter origins instead of
        // treating every pointer argument as a possible return source.
        for (size_t i = 0; i < argc && i < lifetimeContract->params.size(); ++i) {
          const int parameterLifetime = lifetimeContract->params[i].lifetimeParamIndex;
          if (parameterLifetime < 0 ||
              !callContractOutlives(*lifetimeContract, parameterLifetime,
                                    lifetimeContract->returnLifetimeParamIndex) ||
              lifetimeContract->params[i].noescape) continue;
          std::vector<PointerOrigin> argumentOrigins;
          collectPointerOrigins(expr->c[i + 1].get(), ctx, argumentOrigins);
          for (const PointerOrigin &origin : argumentOrigins)
            appendUniqueOrigin(out, origin);
        }
        return;
      }
      for (size_t i = 0; i < argc; ++i) {
        const Node *argument = expr->c[i + 1].get();
        std::vector<PointerOrigin> argumentOrigins;
        collectPointerOrigins(argument, ctx, argumentOrigins);
        const std::string argumentType = expressionTypeKey(argument, ctx, fields);
        const bool aggregateFieldsNoescape = isValueStructTypeKey(argumentType) &&
            !selected.empty() && std::all_of(selected.begin(), selected.end(), [i](
                const FacBorrowChecker::CallContract *contract) {
              return contract && i < contract->params.size() &&
                     contract->params[i].aggregatePointerFieldsNoescape;
            });
        if (!argumentOrigins.empty() &&
            (callParameterNoescape(selected, i, argc) || aggregateFieldsNoescape))
          continue;
        for (const PointerOrigin &origin : argumentOrigins)
          appendUniqueOrigin(out, origin);
      }
      return;
    }
    if (expr->k == NK::IfV) {
      // `ifv/eiv/elv` conditions select a branch but are not part of the
      // pointer value returned by that branch. Collect only result positions.
      if (expr->c.size() < 3 || (expr->c.size() % 2) == 0) return;
      const size_t elseIndex = expr->c.size() - 1;
      for (size_t valueIndex = 1; valueIndex < elseIndex; valueIndex += 2)
        collectPointerOrigins(expr->c[valueIndex].get(), ctx, out);
      collectPointerOrigins(expr->c[elseIndex].get(), ctx, out);
      return;
    }
    if (expr->k == NK::MatchExpr) {
      // Only selected value expressions contribute pointer provenance. The
      // scrutinee, patterns and guards control selection but are not part of
      // the returned pointer value.
      for (const auto &cs : expr->cases) {
        Context branch = ctx;
        const Node *caseOwner = cs.exprBody ? cs.exprBody.get() : expr;
        branch.region = makeLifetimeRegion(ctx.region, caseOwner);
        for (const auto &name : cs.bindings) {
          branch.aliases.erase(name);
          branch.decls[name] = nullptr;
          branch.symbolRegions[name] = branch.region;
          branch.frameStorage[name] = branch.region;
          branch.pointerVars.erase(name);
          branch.pointerOrigins.erase(name);
        }
        collectPointerOrigins(cs.exprBody.get(), branch, out);
      }
      if (expr->deflt) {
        Context branch = ctx;
        branch.region = makeLifetimeRegion(ctx.region, expr->deflt.get());
        collectPointerOrigins(expr->deflt.get(), branch, out);
      }
      return;
    }
    if (expr->k == NK::Ident) {
      auto pointer = ctx.pointerOrigins.find(expr->s);
      if (pointer != ctx.pointerOrigins.end()) {
        // A current flow-sensitive fact supersedes the declaration-wide
        // historical summary. This matters for exact empty Verified-Null facts:
        // an earlier non-null source must not leak back into a closure or
        // aggregate after the pointer has been cleared.
        for (const PointerOrigin &origin : pointer->second) appendUniqueOrigin(out, origin);
        return;
      }
      auto type = ctx.typeKeys.find(expr->s);
      if (type != ctx.typeKeys.end() && isValueStructTypeKey(type->second)) {
        collectAggregateRootOrigins(expr->s, ctx, out);
      } else {
        auto declaration = ctx.decls.find(expr->s);
        if (declaration != ctx.decls.end() && declaration->second) {
          auto byDecl = pointerOriginsByDecl.find(declaration->second);
          if (byDecl != pointerOriginsByDecl.end())
            for (const PointerOrigin &origin : byDecl->second) appendUniqueOrigin(out, origin);
        }
      }
    }
    for (const auto &child : expr->c) collectPointerOrigins(child.get(), ctx, out);
    for (const auto &cs : expr->cases) {
      for (const auto &value : cs.vals) collectPointerOrigins(value.get(), ctx, out);
      for (const auto &range : cs.ranges) {
        collectPointerOrigins(range.lo.get(), ctx, out);
        collectPointerOrigins(range.hi.get(), ctx, out);
      }
      collectPointerOrigins(cs.guard.get(), ctx, out);
      collectPointerOrigins(cs.exprBody.get(), ctx, out);
      collectPointerOrigins(cs.body.get(), ctx, out);
    }
    collectPointerOrigins(expr->deflt.get(), ctx, out);
  }

  void validatePointerOrigins(const Node *at, const std::vector<PointerOrigin> &origins,
                              size_t destinationRegion, bool externalDestination,
                              const std::string &destination) const {
    for (const PointerOrigin &origin : origins) {
      // Pointer assignments/initializers are represented as explicit
      // outlives constraints. The solver checks them together with local ref
      // loans after the function has been visited, so pointer-to-pointer
      // chains and branch-merged provenance share the same validation path.
      addLifetimeConstraint(origin.region, destinationRegion, at, origin.rootDecl,
                            true, externalDestination, destination);
    }
  }

  void validatePointerStore(const Node *lhs, const Node *rhs, Context &ctx) const {
    if (!lhs || !rhs) return;
    std::vector<PointerOrigin> origins;
    collectPointerOrigins(rhs, ctx, origins);

    const std::string destinationRoot = rawRoot(lhs);
    const auto rootType = ctx.typeKeys.find(destinationRoot);
    const auto rootRegion = ctx.frameStorage.find(destinationRoot);
    const auto rootDeclaration = ctx.decls.find(destinationRoot);
    const StoragePath destinationPath = resolvedStoragePath(lhs, ctx);
    const bool trackedValueStructRoot = rootType != ctx.typeKeys.end() &&
        isValueStructTypeKey(rootType->second) && rootRegion != ctx.frameStorage.end() &&
        rootDeclaration != ctx.decls.end() && rootDeclaration->second != nullptr &&
        !destinationPath.throughAlias && !destinationPath.crossesManagedObjectBoundary;
    const std::string lhsType = expressionType(lhs, ctx);
    const bool pointerField = lhs->k == NK::Member && destinationPath.exact &&
        lhsType.compare(0, 4, "ptr ") == 0;
    const bool aggregateField = lhs->k == NK::Member && destinationPath.exact &&
        isValueStructTypeKey(lhsType);
    const bool wholeAggregate = lhs->k == NK::Ident && trackedValueStructRoot;

    // A verified-null value overwrites a local pointer's previous may-origins.
    // Keep an exact empty fact so later closure capture can distinguish null
    // from Unknown (an absent pointerOrigins entry).
    if (lhs->k == NK::Ident && ctx.pointerVars.count(lhs->s)) {
      if (isVerifiedNullPointerValue(rhs, ctx)) {
        ctx.pointerOrigins[lhs->s] = {};
        return;
      }
      if (origins.empty()) {
        // An untracked non-null pointer write invalidates a prior Verified Null
        // fact. Do not leave the destination looking safe after an unknown
        // pointer value has replaced it.
        ctx.pointerOrigins.erase(lhs->s);
        return;
      }
    }

    // Null is a real overwrite: remove the previous origin for this field.
    // V225 accidentally retained the old may-origin fact, creating false
    // positives after a pointer field had been cleared.
    if (origins.empty()) {
      if (trackedValueStructRoot && (pointerField || aggregateField)) {
        const std::string projection = destinationPath.projection;
        if (pointerField && expressionTypeKey(rhs, ctx, fields).compare(0, 4, "ptr ") == 0 &&
            !isNullPointerValue(rhs))
          fail(lhs, "cannot store an untracked pointer in a value-struct field; use a tracked local address or verified named lifetime (noescape values cannot be retained)");
        if (aggregateField && !hasCompleteAggregatePointerFacts(rhs, ctx))
          fail(lhs, "cannot assign value struct with pointer fields because one or more field lifetimes have no verified provenance");
        eraseAggregateOrigins(destinationRoot, projection, aggregateField, ctx);
        if (pointerField && isNullPointerValue(rhs)) {
          // A verified null is different from a missing/unknown provenance fact.
          ctx.aggregatePointerOriginsByPath[aggregateOriginKey(destinationRoot, projection)] = {};
        } else if (aggregateField) {
          // Rebuild every nested pointer-field fact, including known-null leaves.
          collectAggregatePointerPaths(rhs, lhsType, ctx, destinationRoot, projection,
                                       ctx.aggregatePointerOriginsByPath);
        }
        return;
      }
      if (wholeAggregate) {
        if (!hasCompleteAggregatePointerFacts(rhs, ctx))
          fail(lhs, "cannot assign value struct with pointer fields because one or more field lifetimes have no verified provenance");
        eraseAggregateOrigins(destinationRoot, "", true, ctx);
        collectAggregatePointerPaths(rhs, rootType->second, ctx, destinationRoot, "",
                                      ctx.aggregatePointerOriginsByPath);
        return;
      }
      return;
    }

    if (lhs->k == NK::Ident && ctx.pointerVars.count(lhs->s)) {
      auto region = ctx.frameStorage.find(lhs->s);
      if (region == ctx.frameStorage.end())
        validatePointerOrigins(lhs, origins, 0, true, lhs->s);
      else
        validatePointerOrigins(lhs, origins, region->second, false, lhs->s);
      ctx.pointerOrigins[lhs->s] = origins;
      auto declaration = ctx.decls.find(lhs->s);
      if (declaration != ctx.decls.end() && declaration->second) {
        auto &facts = pointerOriginsByDecl[declaration->second];
        for (const PointerOrigin &origin : origins) appendUniqueOrigin(facts, origin);
      }
      return;
    }

    // V226 supports exact field-level writes in local value structs. Each write
    // kills the previous provenance for that path before installing the new
    // source. Replacing a nested value-struct field kills its complete subtree.
    if (trackedValueStructRoot && (pointerField || aggregateField || wholeAggregate)) {
      for (const PointerOrigin &origin : origins) {
        if (origin.fromNoescapeParameter)
          fail(lhs, "noescape contract violation: pointer parameter '" + origin.root +
               "' cannot be stored in a value-struct field or aggregate");
      }
      validatePointerOrigins(lhs, origins, rootRegion->second, false, destinationRoot);
      const std::string projection = wholeAggregate ? std::string{} : destinationPath.projection;
      eraseAggregateOrigins(destinationRoot, projection, wholeAggregate || aggregateField, ctx);
      if (wholeAggregate) {
        collectAggregatePointerPaths(rhs, rootType->second, ctx, destinationRoot, "",
                                      ctx.aggregatePointerOriginsByPath);
      } else if (aggregateField) {
        collectAggregatePointerPaths(rhs, lhsType, ctx, destinationRoot, projection,
                                     ctx.aggregatePointerOriginsByPath);
      } else {
        ctx.aggregatePointerOriginsByPath[aggregateOriginKey(destinationRoot, projection)] = origins;
      }
      return;
    }

    validatePointerOrigins(lhs, origins, 0, true,
                           destinationRoot.empty() ? "aggregate/container storage" : destinationRoot);
  }

  void checkReturnEscape(const Node *n, const Context &ctx) const {
    if (!n || n->c.empty()) return;
    if (isValueStructTypeKey(expressionTypeKey(n->c[0].get(), ctx, fields)) &&
        !hasCompleteAggregatePointerFacts(n->c[0].get(), ctx))
      fail(n, "cannot return value struct with pointer fields because one or more field lifetimes have no verified provenance");

    // Pattern bindings have independent storage. This checker does not yet
    // propagate pointer provenance through enum payload layout, so a pointer
    // return that references such a binding must not be mistaken for an empty
    // (therefore apparently safe) origin set.
    bool pointerBearingReturn = ctx.functionRoot && ctx.functionRoot->ts.kind == "ptr";
    if (!pointerBearingReturn && ctx.functionRoot) {
      const std::string returnType = FacBorrowChecker::typeKey(ctx.functionRoot->ts);
      pointerBearingReturn = isValueStructTypeKey(returnType) &&
                             !pointerFieldPaths(returnType).empty();
    }
    if (pointerBearingReturn) {
      std::string binding;
      if (FacBorrowChecker::findUntrackedMatchPayloadBinding(n->c[0].get(), binding))
        fail(n, "cannot return pointer from match payload binding '" + binding +
             "' because its lifetime provenance is not yet verified");
    } else if (ctx.functionRoot && ctx.functionRoot->ts.base == "auto") {
      // An inferred `auto` return can still resolve to a raw pointer. The
      // parsed function signature does not expose that inferred kind here,
      // so specifically reject direct match/ifv result paths that return an
      // enum's raw pointer payload without provenance tracking.
      std::string binding;
      const std::map<std::string, std::string> noActiveBindings;
      if (FacBorrowChecker::findUntrackedPointerMatchPayloadResult(
              n->c[0].get(), base.enumPayloadTypeKeys, base.fieldTypes,
              noActiveBindings, binding))
        fail(n, "cannot return pointer from match payload binding '" + binding +
             "' because its lifetime provenance is not yet verified (auto return)");
    }

    std::vector<PointerOrigin> origins;
    collectPointerOrigins(n->c[0].get(), ctx, origins);
    for (const PointerOrigin &origin : origins) {
      if (origin.fromNoescapeParameter)
        fail(n, "noescape contract violation: pointer parameter '" + origin.root +
             "' escapes through a return value");
      // A named return lifetime is an explicit promise about the referent,
      // not merely the fact that the pointer value is syntactically a ptr.
      // Every possible branch origin must outlive that promised region.
      if (functionReturnLifetimeRegion != static_cast<size_t>(-1)) {
        addLifetimeConstraint(origin.region, functionReturnLifetimeRegion, n,
                              origin.rootDecl, true, false, "return value");
      } else {
        // Without a named return lifetime there is no external region against
        // which a stack-derived pointer can be proven safe.
        addLifetimeConstraint(origin.region, 0, n, origin.rootDecl,
                              true, true, "return value");
      }
    }
  }

  void checkExpr(const Node *n, Context &ctx) const {
    if (!n) return;
    pruneLoansAt(n, ctx);
    switch (n->k) {
      case NK::Ident:
        checkRead(n, ctx);
        return;
      case NK::Member:
        checkMemberRead(n, ctx);
        checkStoragePathOperands(n, ctx);
        return;
      case NK::Index:
        checkMemberRead(n, ctx);
        checkStoragePathOperands(n, ctx);
        return;
      case NK::Assign:
        if (!n->c.empty()) {
          checkWrite(n->c[0].get(), ctx);
          if (n->s != "=") checkExpr(n->c[0].get(), ctx);
        }
        if (n->c.size() > 1) {
          checkExpr(n->c[1].get(), ctx);
          if (n->s == "=") validatePointerStore(n->c[0].get(), n->c[1].get(), ctx);
        }
        return;
      case NK::PostInc:
        if (!n->c.empty()) checkWrite(n->c[0].get(), ctx);
        return;
      case NK::Unary:
        if ((n->s == "++" || n->s == "--") && !n->c.empty()) {
          checkWrite(n->c[0].get(), ctx);
          return;
        }
        break;
      case NK::Call: {
        checkCall(n, ctx);
        if (!n->c.empty() && n->c[0] && n->c[0]->k == NK::Ident && n->c[0]->s == "move" && n->c.size() == 2) {
          const auto identity = resolvedRootIdentity(n->c[1].get(), ctx);
          const std::string &root = identity.first;
          if (findLoanFor(ctx, n->c[1].get()))
            fail(n, "cannot move owner/field '" + root + "' while an overlapping local borrow is active");
        }
        if (!n->c.empty() && n->c[0] && n->c[0]->k == NK::Ident && n->c[0]->s == "addr" && n->c.size() == 2) {
          const std::string raw = rawRoot(n->c[1].get());
          if (ctx.aliases.count(raw)) fail(n, "addr() cannot expose a pointer from local borrow alias '" + raw + "' (borrow escape is not supported)");
          const auto identity = resolvedRootIdentity(n->c[1].get(), ctx);
          if (findLoanFor(ctx, n->c[1].get()))
            fail(n, "addr() cannot expose owner storage while an overlapping local borrow is active");
        }
        // Do not run the ordinary read check over a member receiver a second
        // time: checkCall above has applied the const-method loan contract.
        for (size_t i = 0; i < n->c.size(); ++i) {
          if (i == 0 && n->c[i] && n->c[i]->k == NK::Member && !n->c[i]->c.empty()) {
            for (size_t j = 1; j < n->c[i]->c.size(); ++j) checkExpr(n->c[i]->c[j].get(), ctx);
          } else if (i != 0) checkExpr(n->c[i].get(), ctx);
          else checkExpr(n->c[i].get(), ctx);
        }
        return;
      }
      case NK::MatchExpr: {
        if (!n->c.empty()) checkExpr(n->c[0].get(), ctx);
        for (const auto &cs : n->cases) {
          Context branch = ctx;
          const Node *caseOwner = cs.body ? cs.body.get() :
                                  (cs.exprBody ? cs.exprBody.get() : n);
          branch.region = makeLifetimeRegion(ctx.region, caseOwner);
          for (const auto &name : cs.bindings) {
            branch.aliases.erase(name);
            branch.decls[name] = nullptr;
            branch.symbolRegions[name] = branch.region;
            branch.frameStorage[name] = branch.region;
            branch.pointerVars.erase(name);
            branch.pointerOrigins.erase(name);
            branch.constVars[name] = false;
          }
          for (const auto &value : cs.vals) checkExpr(value.get(), branch);
          for (const auto &range : cs.ranges) {
            checkExpr(range.lo.get(), branch);
            checkExpr(range.hi.get(), branch);
          }
          checkExpr(cs.guard.get(), branch);
          checkExpr(cs.exprBody.get(), branch);
          checkStmt(cs.body.get(), branch);
        }
        if (n->deflt) {
          Context branch = ctx;
          branch.region = makeLifetimeRegion(ctx.region, n->deflt.get());
          checkStmt(n->deflt.get(), branch);
        }
        return;
      }
      case NK::Lambda: {
        // Lambda parameters shadow captured names. Check the body in a lexical
        // child context so a parameter named like an outer borrow is not
        // mistaken for that captured alias.
        const Node *body = n->c.empty() ? nullptr : n->c.back().get();
        Context lambdaCtx = ctx;
        lambdaCtx.region = makeLifetimeRegion(ctx.region, n);
        std::set<std::string> parameterNames;
        for (const Param &param : n->params) {
          parameterNames.insert(param.name);
          lambdaCtx.aliases.erase(param.name);
          lambdaCtx.decls[param.name] = nullptr;
          lambdaCtx.symbolRegions[param.name] = lambdaCtx.region;
          lambdaCtx.constVars[param.name] = false;
          lambdaCtx.types[param.name] = param.ts.base;
          lambdaCtx.typeKeys[param.name] = FacBorrowChecker::typeKey(param.ts);
          lambdaCtx.functionValueContracts.erase(param.name);
          if (param.ts.cat == "func" && param.ts.hasSig)
            lambdaCtx.functionValueContracts[param.name] = FacBorrowChecker::functionTypeContract(param.ts);
        }
        auto scalarValue = [](const std::string &type) {
          static const std::set<std::string> scalar = {
            "bool", "boolean", "char", "unichar", "short", "ushort", "int", "uint",
            "long", "ulong", "int8", "uint8", "int16", "uint16", "int32", "uint32",
            "int64", "uint64", "byte", "float", "double"
          };
          return scalar.count(type) != 0;
        };
        const bool localDirectCallOnly = isLocalDirectCallOnlyClosure(n, ctx);
        for (const auto &entry : ctx.aliases) {
          if (!parameterNames.count(entry.first) && !scalarValue(entry.second.type) &&
              FacBorrowChecker::referencesName(body, entry.first))
            fail(n, "cannot capture non-scalar local borrow alias '" + entry.first +
                    "' in a closure; its lifetime/escape cannot yet be proven");
        }
        for (const auto &entry : ctx.pointerVars) {
          if (parameterNames.count(entry) || !FacBorrowChecker::referencesName(body, entry)) continue;
          std::vector<PointerOrigin> origins;
          auto local = ctx.pointerOrigins.find(entry);
          if (local != ctx.pointerOrigins.end()) {
            // The current flow-sensitive fact is authoritative. In particular,
            // an exact empty vector means Verified Null and must not be polluted
            // by older declaration-wide origins from before a null overwrite.
            origins = local->second;
            if (origins.empty()) continue;
          } else {
            auto visibleDecl = ctx.decls.find(entry);
            if (visibleDecl != ctx.decls.end() && visibleDecl->second) {
              auto byDecl = pointerOriginsByDecl.find(visibleDecl->second);
              if (byDecl != pointerOriginsByDecl.end()) origins = byDecl->second;
            }
          }
          if (origins.empty())
            fail(n, "cannot capture pointer '" + entry +
                    "' because its provenance/lifetime is unknown; a closure capture requires a verified lifetime that outlives the closure");
          if (!localDirectCallOnly || !pointerOriginsOutliveRegion(origins, ctx.region))
            fail(n, "cannot capture pointer '" + entry +
                    "' because the closure may escape its verified source lifetime; only a local closure used exclusively by direct calls may capture a pointer whose origin outlives the closure scope");
        }
        for (const auto &entry : ctx.decls) {
          if (parameterNames.count(entry.first)) continue;
          auto type = ctx.typeKeys.find(entry.first);
          if (type == ctx.typeKeys.end() || !isValueStructTypeKey(type->second) ||
              !FacBorrowChecker::referencesName(body, entry.first)) continue;
          if (!hasCompleteAggregatePointerFactsForRoot(entry.first, type->second, ctx))
            fail(n, "cannot capture aggregate '" + entry.first +
                    "' because one or more pointer fields have unknown provenance; closure escape lifetime cannot be proven");
          std::vector<PointerOrigin> origins;
          collectAggregateRootOrigins(entry.first, ctx, origins);
          if (!origins.empty() &&
              (!localDirectCallOnly || !pointerOriginsOutliveRegion(origins, ctx.region)))
            fail(n, "cannot capture aggregate '" + entry.first +
                    "' because a pointer field may outlive the closure's verified local use scope");
        }
        // The block visitor processes local borrows declared inside the lambda
        // and retains captured outer loans through the lambda's lexical body.
        if (body) checkStmt(body, lambdaCtx);
        return;
      }
      default:
        break;
    }
    for (const auto &child : n->c) checkExpr(child.get(), ctx);
    for (const auto &cs : n->cases) {
      for (const auto &value : cs.vals) checkExpr(value.get(), ctx);
      for (const auto &range : cs.ranges) { checkExpr(range.lo.get(), ctx); checkExpr(range.hi.get(), ctx); }
      checkExpr(cs.guard.get(), ctx); checkExpr(cs.exprBody.get(), ctx);
    }
    checkExpr(n->deflt.get(), ctx);
  }

  void checkStmt(const Node *n, Context &ctx) const {
    if (!n) return;
    pruneLoansAt(n, ctx);
    switch (n->k) {
      case NK::Block: {
        Context local = ctx;
        local.region = makeLifetimeRegion(ctx.region, n);
        for (const auto &statement : n->c) checkStmt(statement.get(), local);
        // Lexical declarations remain scoped to the block, but writes to an
        // outer value aggregate persist after the block. Propagate only facts
        // whose root declaration is the same binding as the incoming context.
        mergeAggregatePointerOrigins(ctx, std::vector<Context>{std::move(local)}, ctx);
        return;
      }
      case NK::VarDecl: {
        if (!n->c.empty()) {
          // A direct lvalue borrow initializer is validated by the projection-
          // aware loan conflict pass below. Do not first treat it as an ordinary
          // parent read: disjoint sibling reborrows from one mutable struct
          // parent are intentionally allowed.
          const Node *init = n->c[0].get();
          const bool directBorrowLvalue = n->isRef &&
              (init->k == NK::Ident ||
               (init->k == NK::Member && init->c.size() == 1 && init->c[0] &&
                init->c[0]->k == NK::Ident));
          if (!directBorrowLvalue) checkExpr(init, ctx);
        } // initializer executes before the new name shadows
        lifetimeRegionOfDecl[n] = ctx.region;
        ctx.symbolRegions[n->s] = ctx.region;
        ctx.frameStorage[n->s] = ctx.region;
        if (n->ts.kind == "ptr") {
          ctx.pointerVars.insert(n->s);
          ctx.pointerOrigins.erase(n->s);
          if (!n->c.empty()) {
            std::vector<PointerOrigin> origins;
            collectPointerOrigins(n->c[0].get(), ctx, origins);
            validatePointerOrigins(n, origins, ctx.region, false, n->s);
            if (isVerifiedNullPointerValue(n->c[0].get(), ctx)) {
              ctx.pointerOrigins[n->s] = {};
            } else if (!origins.empty()) {
              ctx.pointerOrigins[n->s] = origins;
              auto &facts = pointerOriginsByDecl[n];
              for (const PointerOrigin &origin : origins) appendUniqueOrigin(facts, origin);
            }
          }
        } else {
          ctx.pointerVars.erase(n->s);
          ctx.pointerOrigins.erase(n->s);
          eraseAggregateOrigins(n->s, "", true, ctx);
          if (!n->c.empty() &&
              (!n->ts.cat.empty() || aggregateTypes.count(n->ts.base))) {
            std::vector<PointerOrigin> origins;
            collectPointerOrigins(n->c[0].get(), ctx, origins);
            const bool localValueStruct = n->ts.cat == "struct" &&
                valueStructTypes.count(n->ts.base) != 0;
            const std::string declaredTypeKey = FacBorrowChecker::typeKey(n->ts);
            if (localValueStruct) {
              if (!hasCompleteAggregatePointerFacts(n->c[0].get(), ctx)) {
                // The source may be a checked constructor/copy or an opaque
                // aggregate parameter. Missing field facts must never be treated
                // as a safe null pointer.
                const std::vector<std::string> required = pointerFieldPaths(declaredTypeKey);
                if (!required.empty())
                  fail(n, "cannot initialize local value struct from a source whose pointer-field provenance is not fully verified");
              }
              for (const PointerOrigin &origin : origins) {
                if (origin.fromNoescapeParameter)
                  fail(n, "noescape contract violation: pointer parameter '" + origin.root +
                       "' cannot be stored in a value-struct field or aggregate");
              }
              validatePointerOrigins(n, origins, ctx.region, false, n->s);
              // Record empty entries too: they prove that a pointer field is
              // intentionally null rather than lacking provenance metadata.
              if (!collectAggregatePointerPaths(n->c[0].get(), declaredTypeKey,
                                                ctx, n->s, "", ctx.aggregatePointerOriginsByPath))
                ctx.aggregatePointerOriginsByPath[aggregateOriginKey(n->s, "*")] = origins;
            } else if (!origins.empty()) {
              fail(n, "dangling-pointer risk: aggregate/container initializer '" + n->s +
                   "' contains a pointer derived from function-frame storage; only local value-struct pointer fields have a checked lifetime contract");
            }
          }
        }
        if (n->isRef) {
          if (n->c.empty()) fail(n, "local ref borrow requires an lvalue initializer");
          const std::string raw = rawRoot(n->c[0].get());
          if (raw.empty()) fail(n, "local ref borrow source must be a named variable/field/index lvalue");
          if (n->isImmutableRef && n->isConst) fail(n, "do not combine ref const with a second const modifier");
          const BorrowMode mode = n->isImmutableRef ? 1 : 2;
          const StoragePath sourcePath = resolvedStoragePath(n->c[0].get(), ctx);
          if (sourcePath.crossesManagedObjectBoundary)
            fail(n, "local borrow cannot cross a nested/weak managed-object reference boundary; borrow from a tracked strong obj handle or a value field instead");
          const auto parentIt = ctx.aliases.find(raw); // keep the old binding visible to its own initializer
          std::string root = sourcePath.root.empty() ? raw : sourcePath.root;
          const Node *rootDecl = sourcePath.rootDecl;
          const Loan *parent = nullptr;
          const Node *parentDecl = nullptr;
          std::string parentAlias;
          size_t rootRegion = 0; // parameters and receiver roots live for the function region
          if (parentIt != ctx.aliases.end()) {
            parent = &parentIt->second;
            root = parent->root;
            rootDecl = parent->rootDecl;
            rootRegion = parent->rootRegion;
            parentDecl = parent->decl;
            parentAlias = parent->alias;
            if (mode == 2 && parent->mode == 1)
              fail(n, "cannot create mutable reborrow from shared borrow '" + raw + "'");
            // Multiple child reborrows from one mutable parent are allowed
            // only when their metadata-validated field projections are disjoint.
            // The overlap test below rejects the same field/whole-parent cases;
            // ordinary parent access remains suspended while any child lives.
          } else {
            auto sourceDecl = ctx.decls.find(raw);
            if (!ctx.types.count(raw) || sourceDecl == ctx.decls.end())
              fail(n, "local ref borrow source '" + raw + "' is not a tracked local/parameter/receiver; globals, statics and unmodeled roots are not supported yet");
            rootDecl = sourceDecl->second;
            if (rootDecl) {
              auto regionIt = lifetimeRegionOfDecl.find(rootDecl);
              if (regionIt == lifetimeRegionOfDecl.end())
                fail(n, "lifetime region for owner '" + raw + "' is not available; borrow source must be declared before the borrow");
              rootRegion = regionIt->second;
            } else {
              auto symbolRegion = ctx.symbolRegions.find(raw);
              if (symbolRegion != ctx.symbolRegions.end()) rootRegion = symbolRegion->second;
            }
          }
          if (!n->isImmutableRef && sourceIsConstOrUnknown(n->c[0].get(), ctx))
            fail(n, "cannot create mutable local borrow from const or unverified storage '" + raw + "'");
          for (const Loan &active : ctx.loans) {
            if (!overlaps(active, sourcePath)) continue;
            if (parent && isAncestorLoan(active, *parent, ctx)) continue;
            if (mode == 2 || active.mode == 2)
              fail(n, "local borrow conflict for '" + root + "': a mutable borrow overlaps active storage" +
                   loanOriginNote(active) + "; disjoint validated field paths may be borrowed independently");
          }
          ctx.aliases.erase(n->s);
          ctx.constantInts.erase(n->s);
          ctx.constantBools.erase(n->s);
          ctx.constantFloats.erase(n->s);
          Loan loan; loan.alias = n->s; loan.root = root; loan.rootDecl = rootDecl; loan.type = n->ts.base;
          loan.projection = sourcePath.projection; loan.projectionExact = sourcePath.exact;
          loan.mode = mode; loan.decl = n;
          loan.region = ctx.region; loan.rootRegion = rootRegion;
          addLifetimeConstraint(rootRegion, ctx.region, n, rootDecl);
          if (parent) addLifetimeConstraint(parent->region, ctx.region, n, parent->decl);
          if (parentDecl || !parentAlias.empty()) {
            loan.parentDecl = parentDecl; loan.parentAlias = parentAlias;
          }
          if (parent) validateReborrowGraphEdge(n, *parent, loan, ctx);
          ctx.aliases[n->s] = loan;
          ctx.loans.push_back(loan);
          ctx.constVars[n->s] = mode == 1;
          ctx.types[n->s] = n->ts.base;
          ctx.typeKeys[n->s] = FacBorrowChecker::typeKey(n->ts);
          ctx.decls[n->s] = n;
        } else {
          // Capture the initializer against the pre-declaration environment:
          // in `const int item = item`, the initializer still refers to an
          // outer item when one is visible, just like ordinary name lookup.
          ConstantArrayIndex constValue;
          bool hasConstValue = false;
          bool constBoolValue = false;
          bool hasConstBoolValue = false;
          double constFloatValue = 0.0;
          unsigned constFloatKind = 0;
          bool hasConstFloatValue = false;
          const unsigned signedBits = signedIntegerWidth(n->ts.base);
          const unsigned unsignedBits = unsignedIntegerWidth(n->ts.base);
          const bool scalarChar = n->ts.base == "char";
          const bool scalarUnichar = n->ts.base == "unichar";
          const bool declaredUnsigned = unsignedBits != 0 || scalarChar || scalarUnichar;
          const unsigned declaredBits = unsignedBits ? unsignedBits : signedBits ? signedBits :
              scalarChar ? 8u : scalarUnichar ? 32u : 0u;
          const bool scalarInteger = n->ts.cat.empty() && declaredBits != 0 &&
              (n->ts.kind.empty() || n->ts.kind == "var");
          if (n->isConst && scalarInteger && n->c.size() == 1) {
            size_t visited = 0;
            if (evalConstantArrayIndex(n->c[0].get(), constValue, visited, &ctx)) {
              hasConstValue = declaredUnsigned
                  ? fitsUnsignedBits(constValue.value, declaredBits)
                  : fitsSignedBits(constValue.value, declaredBits);
              if (hasConstValue) {
                constValue.bits = declaredBits;
                constValue.isUnsigned = declaredUnsigned;
              }
            }
          }
          const bool scalarFloating = n->ts.cat.empty() &&
              (n->ts.base == "float" || n->ts.base == "double") &&
              (n->ts.kind.empty() || n->ts.kind == "var");
          if (n->isConst && scalarFloating && n->c.size() == 1) {
            size_t visited = 0;
            hasConstFloatValue = evalConstantArrayFloat(n->c[0].get(), constFloatValue,
                                                        constFloatKind, visited, &ctx);
            if (hasConstFloatValue && n->ts.base == "float")
              constFloatValue = static_cast<double>(static_cast<float>(constFloatValue));
          }
          const bool scalarBoolean = n->ts.cat.empty() && n->ts.base == "boolean" &&
              (n->ts.kind.empty() || n->ts.kind == "var");
          if (n->isConst && scalarBoolean && n->c.size() == 1) {
            size_t visited = 0;
            hasConstBoolValue = evalConstantArrayCondition(n->c[0].get(), constBoolValue,
                                                            visited, &ctx);
          }
          ctx.aliases.erase(n->s);
          ctx.constantInts.erase(n->s);
          ctx.constantBools.erase(n->s);
          ctx.constantFloats.erase(n->s);
          ctx.constVars[n->s] = n->isConst;
          ctx.types[n->s] = n->ts.base;
          ctx.typeKeys[n->s] = FacBorrowChecker::typeKey(n->ts);
          ctx.decls[n->s] = n;
          if (hasConstValue) ctx.constantInts[n->s] = ConstIntBinding{n, constValue};
          if (hasConstBoolValue) ctx.constantBools[n->s] = ConstBoolBinding{n, constBoolValue};
          if (hasConstFloatValue) ctx.constantFloats[n->s] = ConstFloatBinding{n, constFloatValue, n->ts.base == "float"};
        }
        ctx.functionValueContracts.erase(n->s);
        if (!n->isRef && n->ts.cat == "func" && n->ts.hasSig)
          ctx.functionValueContracts[n->s] = FacBorrowChecker::functionTypeContract(n->ts);
        return;
      }
      case NK::If: {
        if (!n->c.empty()) checkExpr(n->c[0].get(), ctx);
        // Each arm is an implicit lexical lifetime scope, even when its
        // statement is not wrapped in an explicit Block. A declaration or
        // address originating in one arm must not be treated as function- or
        // parent-scope storage merely because the arm has no braces.
        std::vector<Context> branches;
        if (n->c.size() > 1) {
          Context branch = ctx;
          branch.region = makeLifetimeRegion(ctx.region, n->c[1].get());
          checkStmt(n->c[1].get(), branch);
          branches.push_back(std::move(branch));
        }
        if (n->c.size() > 2) {
          Context branch = ctx;
          branch.region = makeLifetimeRegion(ctx.region, n->c[2].get());
          checkStmt(n->c[2].get(), branch);
          branches.push_back(std::move(branch));
        } else {
          // The condition may be false, so the unmodified incoming state is
          // also a possible predecessor of the merge point.
          branches.push_back(ctx);
        }
        mergeAggregatePointerOrigins(ctx, branches, ctx);
        return;
      }
      case NK::While: case NK::DoWhile: case NK::For: case NK::ForPP: case NK::ForEach: {
        const Context beforeLoop = ctx;
        Context loopEntry = ctx; // for-init / iteration bindings live only in this region
        loopEntry.region = makeLifetimeRegion(ctx.region, n);

        // Initializers and iterable expressions execute exactly once before
        // the first loop-header transfer.
        if (n->k == NK::For) {
          if (!n->c.empty() && n->c[0]) checkStmt(n->c[0].get(), loopEntry);
        } else if (n->k == NK::ForEach) {
          if (!n->c.empty() && n->c[0]) checkExpr(n->c[0].get(), loopEntry);
          loopEntry.aliases.erase(n->s);
          loopEntry.decls[n->s] = n;
          lifetimeRegionOfDecl[n] = loopEntry.region;
          loopEntry.symbolRegions[n->s] = loopEntry.region;
          loopEntry.frameStorage[n->s] = loopEntry.region;
          loopEntry.pointerVars.erase(n->s);
          loopEntry.pointerOrigins.erase(n->s);
          loopEntry.constVars[n->s] = false;
          loopEntry.types[n->s] = n->ts.base;
          loopEntry.typeKeys[n->s] = FacBorrowChecker::typeKey(n->ts);
        }

        const Node *body = nullptr;
        const Node *condition = nullptr;
        const Node *step = nullptr;
        switch (n->k) {
          case NK::While:
            condition = n->c.empty() ? nullptr : n->c[0].get();
            body = n->c.size() > 1 ? n->c[1].get() : nullptr;
            break;
          case NK::DoWhile:
            body = n->c.empty() ? nullptr : n->c[0].get();
            condition = n->c.size() > 1 ? n->c[1].get() : nullptr;
            break;
          case NK::For:
            condition = n->c.size() > 1 ? n->c[1].get() : nullptr;
            step = n->c.size() > 2 ? n->c[2].get() : nullptr;
            body = n->c.size() > 3 ? n->c[3].get() : nullptr;
            break;
          case NK::ForPP: case NK::ForEach:
            body = n->c.size() > 1 ? n->c[1].get() : nullptr;
            break;
          default: break;
        }

        // Break statements have distinct exits which are not yet modelled as
        // CFG provenance predecessors. Preserve the old fail-closed behavior
        // for those loops. Ordinary loops use a bounded monotone fixed-point.
        if (containsAnyBreak(body)) {
          Context onePass = loopEntry;
          if (n->k == NK::While) {
            if (condition) checkExpr(condition, onePass);
            if (body) checkStmt(body, onePass);
          } else if (n->k == NK::DoWhile) {
            if (body) checkStmt(body, onePass);
            if (condition) checkExpr(condition, onePass);
          } else if (n->k == NK::For) {
            if (condition) checkExpr(condition, onePass);
            if (body) checkStmt(body, onePass);
            if (step) checkStmt(step, onePass);
          } else {
            if (n->k == NK::ForPP && !n->c.empty() && n->c[0]) checkExpr(n->c[0].get(), onePass);
            if (body) checkStmt(body, onePass);
          }
          invalidateLoopChangedPointerFacts(beforeLoop, onePass, ctx);
          return;
        }

        Context header = loopEntry;
        Context finalExit = loopEntry;
        bool converged = false;
        constexpr size_t kMaxLoopProvenanceIterations = 32;
        for (size_t iterationIndex = 0; iterationIndex < kMaxLoopProvenanceIterations;
             ++iterationIndex) {
          Context conditionState = header;
          Context backedge = header;
          if (n->k == NK::DoWhile) {
            if (body) checkStmt(body, backedge);
            if (condition) checkExpr(condition, backedge);
            conditionState = backedge;
          } else {
            if (n->k == NK::While || n->k == NK::For) {
              if (condition) checkExpr(condition, conditionState);
            } else if (n->k == NK::ForPP && !n->c.empty() && n->c[0]) {
              // The compact pre/post-increment loop form carries its control
              // expression at the loop head, so re-evaluate it on each pass.
              checkExpr(n->c[0].get(), conditionState);
            }
            backedge = conditionState;
            if (body) checkStmt(body, backedge);
            if (n->k == NK::For && step) checkStmt(step, backedge);
          }

          Context nextHeader = header;
          joinLoopPointerFacts(loopEntry, backedge, nextHeader);
          if (sameVisibleLoopPointerFacts(loopEntry, header, nextHeader)) {
            converged = true;
            if (n->k == NK::While || n->k == NK::For || n->k == NK::DoWhile)
              finalExit = conditionState;
            else
              finalExit = nextHeader; // zero or more foreach/ForPP iterations
            break;
          }
          header = std::move(nextHeader);
          if (iterationIndex + 1 == kMaxLoopProvenanceIterations) {
            finalExit = backedge;
          }
        }

        if (!converged) {
          // A non-convergent abstract state must never retain a possibly stale
          // source. Fall back to invalidating only the visible roots that the
          // last transfer changed, as older releases did for all changed loops.
          invalidateLoopChangedPointerFacts(beforeLoop, finalExit, ctx);
        } else {
          // Project only bindings that existed before the loop. Loop-local
          // declarations and for-init variables cannot escape their region.
          mergeAggregatePointerOrigins(beforeLoop, std::vector<Context>{finalExit}, ctx);
        }
        return;
      }
      case NK::Switch: case NK::Match: {
        if (!n->c.empty()) checkExpr(n->c[0].get(), ctx);
        std::vector<Context> branches;
        for (const auto &cs : n->cases) {
          Context branch = ctx;
          const Node *caseOwner = cs.body ? cs.body.get() :
                                  (cs.exprBody ? cs.exprBody.get() : n);
          branch.region = makeLifetimeRegion(ctx.region, caseOwner);
          for (const auto &name : cs.bindings) {
            branch.aliases.erase(name); branch.decls[name] = nullptr;
            branch.symbolRegions[name] = branch.region;
            branch.frameStorage[name] = branch.region;
            branch.pointerVars.erase(name); branch.pointerOrigins.erase(name);
            branch.constVars[name] = false;
          }
          for (const auto &v : cs.vals) checkExpr(v.get(), branch);
          for (const auto &r : cs.ranges) { checkExpr(r.lo.get(), branch); checkExpr(r.hi.get(), branch); }
          checkExpr(cs.guard.get(), branch); checkStmt(cs.body.get(), branch); checkStmt(cs.exprBody.get(), branch);
          branches.push_back(std::move(branch));
        }
        if (n->deflt) {
          Context branch = ctx;
          branch.region = makeLifetimeRegion(ctx.region, n->deflt.get());
          checkStmt(n->deflt.get(), branch);
          branches.push_back(std::move(branch));
        } else {
          // Without an exhaustive/default arm, no case may match.
          branches.push_back(ctx);
        }
        mergeAggregatePointerOrigins(ctx, branches, ctx);
        return;
      }
      case NK::Try: {
        std::vector<Context> branches;
        if (!n->c.empty()) {
          Context branch = ctx;
          branch.region = makeLifetimeRegion(ctx.region, n->c[0].get());
          checkStmt(n->c[0].get(), branch);
          branches.push_back(std::move(branch));
        }
        if (n->c.size() > 1) {
          Context branch = ctx;
          branch.region = makeLifetimeRegion(ctx.region, n->c[1].get());
          if (!n->s.empty()) {
            branch.aliases.erase(n->s); branch.decls[n->s] = nullptr;
            branch.symbolRegions[n->s] = makeLifetimeRegion(branch.region, n->c[1].get());
            branch.frameStorage[n->s] = branch.symbolRegions[n->s];
            branch.pointerVars.erase(n->s); branch.pointerOrigins.erase(n->s);
            branch.constVars[n->s] = false; branch.types[n->s] = n->ts.base;
            branch.typeKeys[n->s] = FacBorrowChecker::typeKey(n->ts);
          }
          checkStmt(n->c[1].get(), branch);
          branches.push_back(std::move(branch));
        } else {
          branches.push_back(ctx);
        }
        Context afterTry = ctx;
        mergeAggregatePointerOrigins(ctx, branches, afterTry);
        if (n->c.size() > 2) {
          afterTry.region = makeLifetimeRegion(ctx.region, n->c[2].get());
          checkStmt(n->c[2].get(), afterTry);
        }
        ctx.aggregatePointerOriginsByPath = std::move(afterTry.aggregatePointerOriginsByPath);
        ctx.pointerOrigins = std::move(afterTry.pointerOrigins);
        return;
      }
      case NK::Defer:
        if (!n->c.empty()) { Context deferred = ctx; checkStmt(n->c[0].get(), deferred); }
        return;
      case NK::Return:
        if (!n->c.empty()) {
          checkExpr(n->c[0].get(), ctx);
          checkReturnEscape(n, ctx);
        }
        return;
      case NK::Throw: case NK::ExprStmt:
        if (!n->c.empty()) checkExpr(n->c[0].get(), ctx);
        return;
      default:
        checkExpr(n, ctx);
        return;
    }
  }

public:
  explicit FacLocalBorrowChecker(const FacBorrowChecker &checker) : base(checker) {}

  const FacBorrowChecker::CallContract *contractForDefinition(const Node *fn) const {
    if (!fn) return nullptr;
    for (const auto &entry : base.callContracts)
      for (const FacBorrowChecker::CallContract &contract : entry.second)
        if (contract.definition == fn) return &contract;
    return nullptr;
  }

  void checkFunction(const Node *fn, const std::string &owner = {}) {
    if (!fn || fn->k != NK::Func || fn->c.empty()) return;
    prepareLoanFlow(fn);
    lifetimeRegions.clear();
    lifetimeRegionOfDecl.clear();
    lifetimeRegionByOwner.clear();
    lifetimeRegionOutlivesEdges.clear();
    functionLifetimeParamRegions.clear();
    lifetimeConstraints.clear();
    pointerOriginsByDecl.clear();
    lifetimeRegions.push_back(LifetimeRegion{0, 0, fn}); // function/parameter region
    // Named parameter lifetimes are abstract input regions. Each outlives the
    // function-call region (and therefore its lexical descendants); explicit
    // `where longer: shorter` clauses add edges among these abstract regions.
    for (size_t i = 0; i < fn->lifetimeParams.size(); ++i) {
      const size_t id = lifetimeRegions.size();
      lifetimeRegions.push_back(LifetimeRegion{id, id, fn});
      functionLifetimeParamRegions[static_cast<int>(i)] = id;
      lifetimeRegionOutlivesEdges.push_back({id, 0});
    }
    const int elidedReturnParameter = FacBorrowChecker::inferredReturnLifetimeParamIndex(fn);
    if (elidedReturnParameter >= 0) {
      const size_t id = lifetimeRegions.size();
      lifetimeRegions.push_back(LifetimeRegion{id, id, fn});
      functionLifetimeParamRegions[0] = id;
      lifetimeRegionOutlivesEdges.push_back({id, 0});
    }
    for (const auto &relationship : fn->lifetimeOutlives) {
      auto longer = functionLifetimeParamRegions.find(relationship.first);
      auto shorter = functionLifetimeParamRegions.find(relationship.second);
      if (longer != functionLifetimeParamRegions.end() && shorter != functionLifetimeParamRegions.end())
        lifetimeRegionOutlivesEdges.push_back({longer->second, shorter->second});
    }
    functionReturnLifetimeRegion = static_cast<size_t>(-1);
    int returnLifetimeParameter = fn->ts.kind == "ptr" ? fn->ts.lifetimeParamIndex : -1;
    if (returnLifetimeParameter < 0 && elidedReturnParameter >= 0) returnLifetimeParameter = 0;
    if (returnLifetimeParameter >= 0) {
      auto ret = functionLifetimeParamRegions.find(returnLifetimeParameter);
      if (ret != functionLifetimeParamRegions.end()) functionReturnLifetimeRegion = ret->second;
    }
    Context ctx;
    ctx.region = 0;
    ctx.functionRoot = fn;
    const FacBorrowChecker::CallContract *functionContract = contractForDefinition(fn);
    size_t parameterIndex = 0;
    for (const Param &p : fn->params) {
      ctx.constVars[p.name] = p.immutableRef;
      ctx.types[p.name] = p.ts.base;
      ctx.typeKeys[p.name] = FacBorrowChecker::typeKey(p.ts);
      ctx.functionValueContracts.erase(p.name);
      if (p.ts.cat == "func" && p.ts.hasSig)
        ctx.functionValueContracts[p.name] = FacBorrowChecker::functionTypeContract(p.ts);
      ctx.decls[p.name] = nullptr;
      ctx.symbolRegions[p.name] = 0;
      ctx.frameStorage[p.name] = 0;
      // A body-verified aggregate noescape summary lets this function read its
      // pointer-bearing value-struct parameter only through exact noescape
      // forwarding calls. Seed known-empty local origins for those exact paths;
      // the summary scanner rejects every other use before this body is checked.
      if (functionContract && parameterIndex < functionContract->params.size() &&
          functionContract->params[parameterIndex].aggregatePointerFieldsNoescape) {
        for (const std::string &path : pointerFieldPaths(FacBorrowChecker::typeKey(p.ts)))
          ctx.aggregatePointerOriginsByPath[aggregateOriginKey(p.name, path)] = {};
      }
      if (p.ts.kind == "ptr") {
        ctx.pointerVars.insert(p.name);
        // Seed pointer provenance from an explicitly named input lifetime, or
        // from the single-parameter elision rule above. Subsequent local
        // assignments, branch merges and returns carry this origin through
        // the same provenance analysis.
        int parameterLifetime = p.ts.lifetimeParamIndex;
        if (parameterLifetime < 0 && static_cast<int>(parameterIndex) == elidedReturnParameter)
          parameterLifetime = 0;
        if (parameterLifetime >= 0) {
          auto lifetime = functionLifetimeParamRegions.find(parameterLifetime);
          if (lifetime != functionLifetimeParamRegions.end()) {
            ctx.pointerOrigins[p.name].push_back(
                PointerOrigin{p.name, nullptr, lifetime->second, fn->line, false, &p});
          }
        }
      }
      if (p.noescape) {
        ctx.pointerOrigins[p.name].push_back(PointerOrigin{p.name, nullptr, 0, fn->line, true, &p});
      }
      if (p.ref) {
        Loan loan; loan.alias = p.name; loan.root = p.name;
        loan.type = p.ts.base; loan.mode = p.immutableRef ? 1 : 2; loan.parameter = true;
        ctx.aliases[p.name] = loan;
        ctx.loans.push_back(loan);
      }
      ++parameterIndex;
    }
    if (!owner.empty() && !fn->isStatic) {
      ctx.constVars["self"] = fn->isConst;
      ctx.types["self"] = owner;
      ctx.typeKeys["self"] = "struct " + owner;
      ctx.decls["self"] = nullptr;
      ctx.symbolRegions["self"] = 0;
      ctx.frameStorage["self"] = 0;
    }
    checkStmt(fn->c[0].get(), ctx);
    solveLifetimeConstraints();
  }

  void run(const std::vector<std::unique_ptr<Program>> &programs) {
    fields.clear();
    fieldOrder.clear();
    aggregateTypes.clear();
    valueStructTypes.clear();
    for (const auto &program : programs) {
      for (const auto &type : program->structs) {
        if (!type) continue;
        aggregateTypes.insert(type->s);
        if (!type->isClass && !type->isInterface) valueStructTypes.insert(type->s);
        for (const auto &field : type->c) {
          if (!field || field->k != NK::VarDecl) continue;
          FieldContract contract;
          contract.type = FacBorrowChecker::typeKey(field->ts);
          contract.isConst = field->isConst;
          if (field->ts.cat == "func" && field->ts.hasSig) {
            contract.hasFunctionContract = true;
            contract.functionContract = FacBorrowChecker::functionTypeContract(field->ts);
          }
          fields[type->s][field->s] = std::move(contract);
          fieldOrder[type->s].push_back(field->s);
        }
      }
    }
    for (const auto &program : programs) {
      for (const auto &fn : program->funcs) checkFunction(fn.get());
      for (const auto &type : program->structs) {
        for (const auto &method : type->methods) checkFunction(method.get(), type->s);
        for (const auto &method : type->c) checkFunction(method.get(), type->s);
      }
    }
  }
};

inline bool hasOwnershipEffectContracts(const std::vector<std::unique_ptr<Program>> &programs) {
  auto has = [](const Node *fn) {
    if (!fn || fn->k != NK::Func) return false;
    for (const Param &param : fn->params) if (param.noescape || param.readonly) return true;
    return false;
  };
  for (const auto &program : programs) {
    for (const auto &fn : program->funcs) if (has(fn.get())) return true;
    for (const auto &type : program->structs) {
      for (const auto &method : type->methods) if (has(method.get())) return true;
      for (const auto &member : type->c) if (has(member.get())) return true;
    }
  }
  return false;
}

inline void checkStrictOwnership(const std::vector<std::unique_ptr<Program>> &programs) {
  FacBorrowChecker checker;
  checker.run(programs);
  FacLocalBorrowChecker localChecker(checker);
  localChecker.run(programs);
}

inline bool hasNoescapeContracts(const std::vector<std::unique_ptr<Program>> &programs) {
  return hasOwnershipEffectContracts(programs);
}
