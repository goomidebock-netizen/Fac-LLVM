// CFG-based, flow-sensitive checker for explicit managed-value moves.
// Moves are tracked as a may-be-moved dataflow fact over control-flow edges.
// The analysis is deliberately conservative for closures, defer and indirect aliases.
#pragma once
#include "ast.hpp"
#include "lexer.hpp"
#include <algorithm>
#include <deque>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

class FacMoveChecker {
  using Symbol = int;
  using State = std::set<Symbol>;
  using Env = std::map<std::string, Symbol>;

  enum class Action { Nop, Expr, Decl, Defer, MarkMoved };
  struct BasicBlock {
    const Node *syntax = nullptr;
    Action action = Action::Nop;
    std::vector<int> succ;
    std::vector<Symbol> marked;
  };
  struct LoopTarget {
    std::string label;
    int breakTarget = -1;
    int continueTarget = -1;
    bool isLoop = true;
    size_t finalizerDepth = 0;
  };

  std::vector<BasicBlock> cfg;
  std::unordered_map<const Node *, Symbol> identSymbols;
  std::unordered_map<const Node *, Symbol> declSymbols;
  std::unordered_map<const Node *, std::vector<Symbol>> lambdaCaptures;
  std::unordered_map<const Node *, std::vector<Symbol>> deferCaptures;
  std::map<Symbol, std::string> symbolNames;
  // Partial moves are tracked per (local declaration, metadata-validated
  // dotted field projection). Runtime storage uses null/zero sentinels; this
  // per-projection state drives use-after-move and reinitialization checks.
  std::map<std::pair<Symbol, std::string>, Symbol> fieldSymbols;
  std::map<Symbol, Symbol> partialRootSymbols;
  std::map<Symbol, std::set<Symbol>> fieldsByRoot;
  std::set<Symbol> fieldSymbolIds;
  std::set<Symbol> partialRootSymbolIds;
  std::set<Symbol> deferredUses;
  Symbol nextSymbol = 1;
  int exitBlock = -1;
  std::vector<const Node *> activeFinalizers;

  [[noreturn]] static void fail(const Node *n, const std::string &what) {
    throw CompileError(n ? n->line : 0, "strict-move: " + what);
  }

  static bool isMoveCall(const Node *n) {
    return n && n->k == NK::Call && !n->c.empty() && n->c[0] &&
           n->c[0]->k == NK::Ident && n->c[0]->s == "move";
  }

  static void collectNames(const Node *n, std::set<std::string> &out) {
    if (!n) return;
    if (n->k == NK::Ident) out.insert(n->s);
    for (const auto &c : n->c) collectNames(c.get(), out);
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) collectNames(v.get(), out);
      for (const auto &r : cs.ranges) {
        collectNames(r.lo.get(), out); collectNames(r.hi.get(), out);
      }
      collectNames(cs.guard.get(), out); collectNames(cs.body.get(), out);
      collectNames(cs.exprBody.get(), out);
    }
    collectNames(n->deflt.get(), out);
    for (const auto &p : n->params) if (p.def) collectNames(p.def.get(), out);
  }

  static bool containsMove(const Node *n) {
    if (!n) return false;
    if (isMoveCall(n)) return true;
    for (const auto &c : n->c) if (containsMove(c.get())) return true;
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) if (containsMove(v.get())) return true;
      for (const auto &r : cs.ranges)
        if (containsMove(r.lo.get()) || containsMove(r.hi.get())) return true;
      if (containsMove(cs.guard.get()) || containsMove(cs.body.get()) ||
          containsMove(cs.exprBody.get())) return true;
    }
    return containsMove(n->deflt.get());
  }

  Symbol newSymbol(const std::string &name) {
    const Symbol id = nextSymbol++;
    symbolNames[id] = name;
    return id;
  }

  Symbol fieldSymbol(Symbol root, const std::string &projection) {
    const auto key = std::make_pair(root, projection);
    auto it = fieldSymbols.find(key);
    if (it != fieldSymbols.end()) return it->second;
    const Symbol id = newSymbol(symbolNames[root] + "." + projection);
    fieldSymbols.emplace(key, id);
    fieldsByRoot[root].insert(id);
    fieldSymbolIds.insert(id);
    return id;
  }

  static bool pathPrefix(const std::string &prefix, const std::string &path) {
    return path.size() > prefix.size() &&
           path.compare(0, prefix.size(), prefix) == 0 &&
           path[prefix.size()] == '.';
  }

  static bool pathsOverlap(const std::string &a, const std::string &b) {
    return a == b || pathPrefix(a, b) || pathPrefix(b, a);
  }

  static bool memberPath(const Node *n, const Node *&base,
                         std::vector<std::string> &segments) {
    segments.clear();
    const Node *cur = n;
    while (cur && cur->k == NK::Member && cur->c.size() == 1) {
      if (cur->s.empty()) return false;
      segments.push_back(cur->s);
      cur = cur->c[0].get();
    }
    if (!cur || cur->k != NK::Ident || segments.empty()) return false;
    std::reverse(segments.begin(), segments.end());
    base = cur;
    return true;
  }

  bool localProjection(const Node *n, Symbol &root, std::string &projection,
                       const Node **baseOut = nullptr) const {
    const Node *base = nullptr;
    std::vector<std::string> segments;
    if (!memberPath(n, base, segments)) return false;
    auto it = identSymbols.find(base);
    if (it == identSymbols.end()) return false;
    root = it->second;
    projection.clear();
    for (const std::string &segment : segments) {
      if (!projection.empty()) projection += ".";
      projection += segment;
    }
    if (baseOut) *baseOut = base;
    return true;
  }

  bool movedProjectionOverlaps(Symbol root, const std::string &projection,
                               const State &state) const {
    auto it = fieldSymbols.lower_bound({root, std::string{}});
    for (; it != fieldSymbols.end() && it->first.first == root; ++it)
      if (state.count(it->second) && pathsOverlap(it->first.second, projection)) return true;
    return false;
  }

  Symbol partialRootSymbol(Symbol root) {
    auto it = partialRootSymbols.find(root);
    if (it != partialRootSymbols.end()) return it->second;
    const Symbol id = newSymbol(symbolNames[root] + "{partial}");
    partialRootSymbols.emplace(root, id);
    partialRootSymbolIds.insert(id);
    return id;
  }

  bool isPartialRoot(Symbol id) const { return partialRootSymbolIds.count(id) != 0; }
  bool isFieldSymbol(Symbol id) const { return fieldSymbolIds.count(id) != 0; }

  bool hasMovedField(Symbol root, const State &state) const {
    auto it = fieldsByRoot.find(root);
    if (it == fieldsByRoot.end()) return false;
    for (Symbol field : it->second) if (state.count(field)) return true;
    return false;
  }

  void clearPartialProjection(Symbol root, const std::string &projection, State &state) const {
    // Replacing a complete sub-aggregate restores every moved descendant.
    // Replacing a leaf clears only that leaf; sibling moves remain active.
    auto it = fieldSymbols.lower_bound({root, std::string{}});
    for (; it != fieldSymbols.end() && it->first.first == root; ++it) {
      if (it->first.second == projection || pathPrefix(projection, it->first.second))
        state.erase(it->second);
    }
    if (!hasMovedField(root, state)) {
      auto marker = partialRootSymbols.find(root);
      if (marker != partialRootSymbols.end()) state.erase(marker->second);
    }
  }

  void bindExpr(const Node *n, Env &env) {
    if (!n) return;
    if (n->k == NK::Ident) {
      auto it = env.find(n->s);
      if (it != env.end()) identSymbols[n] = it->second;
      return;
    }
    if (n->k == NK::Member) {
      const Node *base = nullptr;
      std::vector<std::string> segments;
      if (memberPath(n, base, segments)) {
        auto root = env.find(base->s);
        if (root != env.end()) {
          std::string projection;
          for (const std::string &segment : segments) {
            if (!projection.empty()) projection += ".";
            projection += segment;
            fieldSymbol(root->second, projection); // register every prefix
          }
          partialRootSymbol(root->second);
          bindExpr(base, env);
          return;
        }
      }
    }
    if (n->k == NK::Lambda) {
      std::set<std::string> names;
      collectNames(n->c.empty() ? nullptr : n->c[0].get(), names);
      for (const auto &p : n->params) names.erase(p.name);
      std::vector<Symbol> captures;
      for (const auto &name : names) {
        auto it = env.find(name);
        if (it != env.end()) captures.push_back(it->second);
      }
      std::sort(captures.begin(), captures.end());
      captures.erase(std::unique(captures.begin(), captures.end()), captures.end());
      lambdaCaptures[n] = std::move(captures);
      Env local = env;
      for (const auto &p : n->params) {
        if (p.def) bindExpr(p.def.get(), local);
        local[p.name] = newSymbol(p.name);
      }
      if (!n->c.empty()) bindStmt(n->c[0].get(), local);
      return;
    }
    if (n->k == NK::MatchExpr) {
      if (!n->c.empty()) bindExpr(n->c[0].get(), env);
      for (const auto &cs : n->cases) {
        Env branch = env;
        for (const auto &name : cs.bindings) branch[name] = newSymbol(name);
        for (const auto &v : cs.vals) bindExpr(v.get(), branch);
        for (const auto &r : cs.ranges) {
          bindExpr(r.lo.get(), branch); bindExpr(r.hi.get(), branch);
        }
        bindExpr(cs.guard.get(), branch); bindExpr(cs.exprBody.get(), branch);
      }
      bindExpr(n->deflt.get(), env);
      return;
    }
    for (const auto &c : n->c) bindExpr(c.get(), env);
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) bindExpr(v.get(), env);
      for (const auto &r : cs.ranges) {
        bindExpr(r.lo.get(), env); bindExpr(r.hi.get(), env);
      }
      bindExpr(cs.guard.get(), env); bindExpr(cs.body.get(), env);
      bindExpr(cs.exprBody.get(), env);
    }
    bindExpr(n->deflt.get(), env);
  }

  void bindStmt(const Node *n, Env &env) {
    if (!n) return;
    switch (n->k) {
      case NK::Block: {
        Env local = env;
        for (const auto &child : n->c) bindStmt(child.get(), local);
        return;
      }
      case NK::VarDecl: {
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        const Symbol id = newSymbol(n->s);
        declSymbols[n] = id;
        env[n->s] = id;
        return;
      }
      case NK::If: {
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        if (n->c.size() > 1) { Env branch = env; bindStmt(n->c[1].get(), branch); }
        if (n->c.size() > 2) { Env branch = env; bindStmt(n->c[2].get(), branch); }
        return;
      }
      case NK::While: {
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        if (n->c.size() > 1) { Env loop = env; bindStmt(n->c[1].get(), loop); }
        return;
      }
      case NK::DoWhile: {
        if (!n->c.empty()) { Env loop = env; bindStmt(n->c[0].get(), loop); }
        if (n->c.size() > 1) bindExpr(n->c[1].get(), env);
        return;
      }
      case NK::For: {
        Env loop = env;
        if (n->c.size() > 0) bindStmt(n->c[0].get(), loop);
        if (n->c.size() > 1) bindExpr(n->c[1].get(), loop);
        if (n->c.size() > 2) bindStmt(n->c[2].get(), loop);
        if (n->c.size() > 3) bindStmt(n->c[3].get(), loop);
        return;
      }
      case NK::ForPP: {
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        if (n->c.size() > 1) { Env loop = env; bindStmt(n->c[1].get(), loop); }
        return;
      }
      case NK::ForEach: {
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        if (n->c.size() > 1) {
          Env loop = env;
          loop[n->s] = newSymbol(n->s);
          bindStmt(n->c[1].get(), loop);
        }
        return;
      }
      case NK::Switch: case NK::Match: {
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        for (const auto &cs : n->cases) {
          Env branch = env;
          for (const auto &name : cs.bindings) branch[name] = newSymbol(name);
          for (const auto &v : cs.vals) bindExpr(v.get(), branch);
          for (const auto &r : cs.ranges) {
            bindExpr(r.lo.get(), branch); bindExpr(r.hi.get(), branch);
          }
          bindExpr(cs.guard.get(), branch); bindStmt(cs.body.get(), branch);
          bindStmt(cs.exprBody.get(), branch);
        }
        bindStmt(n->deflt.get(), env);
        return;
      }
      case NK::Try: {
        if (n->c.size() > 0) { Env branch = env; bindStmt(n->c[0].get(), branch); }
        if (n->c.size() > 1 && n->c[1]) {
          Env catcher = env;
          if (!n->s.empty()) catcher[n->s] = newSymbol(n->s);
          bindStmt(n->c[1].get(), catcher);
        }
        if (n->c.size() > 2) { Env fin = env; bindStmt(n->c[2].get(), fin); }
        return;
      }
      case NK::Defer: {
        std::set<std::string> names;
        if (!n->c.empty()) collectNames(n->c[0].get(), names);
        std::vector<Symbol> captures;
        for (const auto &name : names) {
          auto it = env.find(name);
          if (it != env.end()) captures.push_back(it->second);
        }
        deferCaptures[n] = captures;
        deferredUses.insert(captures.begin(), captures.end());
        if (!n->c.empty()) { Env deferred = env; bindStmt(n->c[0].get(), deferred); }
        return;
      }
      case NK::Return: case NK::Throw: case NK::ExprStmt:
        if (!n->c.empty()) bindExpr(n->c[0].get(), env);
        return;
      default:
        bindExpr(n, env);
        return;
    }
  }

  int addBlock(const Node *syntax, Action action, std::vector<int> succ = {},
               std::vector<Symbol> marked = {}) {
    BasicBlock block;
    block.syntax = syntax; block.action = action; block.succ = std::move(succ);
    block.marked = std::move(marked);
    cfg.push_back(std::move(block));
    return static_cast<int>(cfg.size() - 1);
  }

  void collectPotentialMoves(const Node *n, std::vector<Symbol> &out) const {
    if (!n) return;
    if (n->k == NK::Lambda || n->k == NK::Defer) return;
    if (isMoveCall(n) && n->c.size() == 2 && n->c[1]) {
      if (n->c[1]->k == NK::Ident) {
        auto it = identSymbols.find(n->c[1].get());
        if (it != identSymbols.end()) out.push_back(it->second);
        return;
      }
      Symbol root = 0; std::string projection;
      if (localProjection(n->c[1].get(), root, projection)) {
        auto field = fieldSymbols.find({root, projection});
        if (field != fieldSymbols.end()) out.push_back(field->second);
        auto marker = partialRootSymbols.find(root);
        if (marker != partialRootSymbols.end()) out.push_back(marker->second);
        return;
      }
    }
    for (const auto &c : n->c) collectPotentialMoves(c.get(), out);
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) collectPotentialMoves(v.get(), out);
      for (const auto &r : cs.ranges) {
        collectPotentialMoves(r.lo.get(), out); collectPotentialMoves(r.hi.get(), out);
      }
      collectPotentialMoves(cs.guard.get(), out);
      collectPotentialMoves(cs.body.get(), out);
      collectPotentialMoves(cs.exprBody.get(), out);
    }
    collectPotentialMoves(n->deflt.get(), out);
  }

  int exprBlock(const Node *expr, int next) {
    if (!expr) return next;
    return addBlock(expr, Action::Expr, next >= 0 ? std::vector<int>{next} : std::vector<int>{});
  }

  static std::vector<int> branchEdges(const Node *condition, int yes, int no) {
    if (condition && condition->k == NK::BoolLit) return condition->b ? std::vector<int>{yes} : std::vector<int>{no};
    return {yes, no};
  }

  int sequenceExprs(const std::vector<const Node *> &exprs, int next) {
    int entry = next;
    for (auto it = exprs.rbegin(); it != exprs.rend(); ++it) entry = exprBlock(*it, entry);
    return entry;
  }

  int routeFinalizers(int target, size_t keepDepth, const std::vector<LoopTarget> &targets) {
    int routed = target;
    if (keepDepth > activeFinalizers.size()) keepDepth = activeFinalizers.size();
    for (size_t depth = activeFinalizers.size(); depth > keepDepth; --depth) {
      const Node *finalizer = activeFinalizers[depth - 1];
      std::vector<const Node *> saved = activeFinalizers;
      activeFinalizers.resize(depth - 1);
      routed = buildStmt(finalizer, routed, targets);
      activeFinalizers.swap(saved);
    }
    return routed;
  }

  int targetFor(const std::vector<LoopTarget> &targets, const std::string &label,
                bool wantContinue) {
    for (auto it = targets.rbegin(); it != targets.rend(); ++it) {
      if (!label.empty()) {
        if (!it->isLoop || it->label != label) continue;
        const int target = wantContinue ? it->continueTarget : it->breakTarget;
        return routeFinalizers(target, it->finalizerDepth, targets);
      }
      if (wantContinue && !it->isLoop) continue;
      const int target = wantContinue ? it->continueTarget : it->breakTarget;
      return routeFinalizers(target, it->finalizerDepth, targets);
    }
    return routeFinalizers(exitBlock, 0, targets);
  }

  int buildStmt(const Node *n, int next, std::vector<LoopTarget> targets) {
    if (!n) return next;
    switch (n->k) {
      case NK::Block: {
        int entry = next;
        for (auto it = n->c.rbegin(); it != n->c.rend(); ++it)
          entry = buildStmt(it->get(), entry, targets);
        return entry;
      }
      case NK::VarDecl:
        return addBlock(n, Action::Decl, {next});
      case NK::ExprStmt:
        return exprBlock(n->c.empty() ? nullptr : n->c[0].get(), next);
      case NK::If: {
        const int thenEntry = n->c.size() > 1 ? buildStmt(n->c[1].get(), next, targets) : next;
        const int elseEntry = n->c.size() > 2 ? buildStmt(n->c[2].get(), next, targets) : next;
        if (n->c.empty()) return addBlock(n, Action::Nop, {thenEntry, elseEntry});
        return addBlock(n->c[0].get(), Action::Expr, branchEdges(n->c[0].get(), thenEntry, elseEntry));
      }
      case NK::While: {
        const int cond = addBlock(n->c.empty() ? n : n->c[0].get(),
                                  n->c.empty() ? Action::Nop : Action::Expr);
        targets.push_back({n->label, next, cond, true, activeFinalizers.size()});
        const int body = n->c.size() > 1 ? buildStmt(n->c[1].get(), cond, targets) : cond;
        cfg[cond].succ = branchEdges(n->c.empty() ? nullptr : n->c[0].get(), body, next);
        return cond;
      }
      case NK::DoWhile: {
        const int cond = addBlock(n->c.size() > 1 ? n->c[1].get() : n,
                                  n->c.size() > 1 ? Action::Expr : Action::Nop);
        targets.push_back({n->label, next, cond, true, activeFinalizers.size()});
        const int body = !n->c.empty() ? buildStmt(n->c[0].get(), cond, targets) : cond;
        cfg[cond].succ = branchEdges(n->c.size() > 1 ? n->c[1].get() : nullptr, body, next);
        return body;
      }
      case NK::For: {
        const int cond = addBlock(n->c.size() > 1 ? n->c[1].get() : n,
                                  n->c.size() > 1 && n->c[1] ? Action::Expr : Action::Nop);
        int step = cond;
        if (n->c.size() > 2 && n->c[2]) step = buildStmt(n->c[2].get(), cond, targets);
        targets.push_back({n->label, next, step, true, activeFinalizers.size()});
        const int body = n->c.size() > 3 ? buildStmt(n->c[3].get(), step, targets) : step;
        cfg[cond].succ = (n->c.size() > 1 && n->c[1])
          ? branchEdges(n->c[1].get(), body, next) : std::vector<int>{body};
        if (n->c.size() > 0 && n->c[0]) return buildStmt(n->c[0].get(), cond, targets);
        return cond;
      }
      case NK::ForPP: case NK::ForEach: {
        const int head = addBlock(n, Action::Nop);
        targets.push_back({n->label, next, head, true, activeFinalizers.size()});
        const int body = n->c.size() > 1 ? buildStmt(n->c[1].get(), head, targets) : head;
        cfg[head].succ = {body, next};
        if (n->k == NK::ForPP) return exprBlock(n->c.empty() ? nullptr : n->c[0].get(), head);
        return exprBlock(n->c.empty() ? nullptr : n->c[0].get(), head);
      }
      case NK::Switch: case NK::Match: {
        std::vector<LoopTarget> branchTargets = targets;
        branchTargets.push_back({{}, next, -1, false, activeFinalizers.size()});
        std::vector<int> entries;
        for (const auto &cs : n->cases) {
          int entry = cs.body ? buildStmt(cs.body.get(), next, branchTargets) : next;
          if (cs.exprBody) entry = exprBlock(cs.exprBody.get(), entry);
          if (cs.guard) entry = exprBlock(cs.guard.get(), entry);
          std::vector<const Node *> caseExprs;
          for (const auto &v : cs.vals) caseExprs.push_back(v.get());
          for (const auto &r : cs.ranges) { caseExprs.push_back(r.lo.get()); caseExprs.push_back(r.hi.get()); }
          entry = sequenceExprs(caseExprs, entry);
          entries.push_back(entry);
        }
        entries.push_back(n->deflt ? buildStmt(n->deflt.get(), next, branchTargets) : next);
        int dispatch = addBlock(n, Action::Nop, std::move(entries));
        return exprBlock(n->c.empty() ? nullptr : n->c[0].get(), dispatch);
      }
      case NK::Try: {
        const bool hasFinally = n->c.size() > 2 && n->c[2];
        int finalEntry = next;
        if (hasFinally) finalEntry = buildStmt(n->c[2].get(), next, targets);
        // A return/break/continue from the protected region must execute this
        // finally block too. The finalizer is pushed only while its try/catch
        // bodies are being built, so it is not recursively applied to itself.
        if (hasFinally) activeFinalizers.push_back(n->c[2].get());
        const int body = n->c.size() > 0 && n->c[0] ? buildStmt(n->c[0].get(), finalEntry, targets) : finalEntry;
        std::vector<Symbol> mayMove;
        if (n->c.size() > 0) collectPotentialMoves(n->c[0].get(), mayMove);
        std::sort(mayMove.begin(), mayMove.end());
        mayMove.erase(std::unique(mayMove.begin(), mayMove.end()), mayMove.end());
        int exceptionalTarget = finalEntry;
        if (n->c.size() > 1 && n->c[1]) {
          const int catcher = buildStmt(n->c[1].get(), finalEntry, targets);
          std::vector<Symbol> catchMayMove;
          collectPotentialMoves(n->c[1].get(), catchMayMove);
          std::sort(catchMayMove.begin(), catchMayMove.end());
          catchMayMove.erase(std::unique(catchMayMove.begin(), catchMayMove.end()), catchMayMove.end());
          // A catch body can itself throw after moving a local. Model a
          // possible exceptional exit through finally (or an outer handler).
          const int catchExceptional = addBlock(n, Action::MarkMoved, {finalEntry}, std::move(catchMayMove));
          exceptionalTarget = addBlock(n, Action::Nop, {catcher, catchExceptional});
        }
        // Any operation in the try body may throw after a move. Feed an
        // over-approximation of those moved values into catch/finally so an
        // exceptional edge cannot silently forget an ownership transfer.
        const int exceptional = addBlock(n, Action::MarkMoved, {exceptionalTarget}, std::move(mayMove));
        if (hasFinally) activeFinalizers.pop_back();
        return addBlock(n, Action::Nop, {body, exceptional});
      }
      case NK::Defer:
        return addBlock(n, Action::Defer, {next});
      case NK::Return:
        return addBlock(n, Action::Expr, {routeFinalizers(exitBlock, 0, targets)});
      case NK::Throw:
        return addBlock(n, Action::Expr, {});
      case NK::Break:
        return addBlock(n, Action::Nop, {targetFor(targets, n->label, false)});
      case NK::Continue:
        return addBlock(n, Action::Nop, {targetFor(targets, n->label, true)});
      default:
        return exprBlock(n, next);
    }
  }

  void transferExpr(const Node *n, State &state) const {
    if (!n) return;
    switch (n->k) {
      case NK::Ident: {
        auto it = identSymbols.find(n);
        if (it != identSymbols.end()) {
          if (state.count(it->second))
            fail(n, "use of moved value '" + symbolNames.at(it->second) + "'");
          auto partial = partialRootSymbols.find(it->second);
          if (partial != partialRootSymbols.end() && state.count(partial->second))
            fail(n, "use of partially moved aggregate '" + symbolNames.at(it->second) + "'; reinitialize moved fields before using the whole value");
        }
        return;
      }
      case NK::Member: {
        Symbol root = 0; std::string projection;
        if (localProjection(n, root, projection)) {
          if (state.count(root))
            fail(n, "use of moved aggregate '" + symbolNames.at(root) + "'");
          if (movedProjectionOverlaps(root, projection, state))
            fail(n, "use of moved or partially moved field path '" +
                    symbolNames.at(root) + "." + projection + "'");
          return; // treat the whole member chain as one projection
        }
        for (const auto &c : n->c) transferExpr(c.get(), state);
        return;
      }
      case NK::Lambda: {
        auto it = lambdaCaptures.find(n);
        if (it != lambdaCaptures.end()) for (Symbol id : it->second) {
          auto partial = partialRootSymbols.find(id);
          if (state.count(id) || (partial != partialRootSymbols.end() && state.count(partial->second)))
            fail(n, "lambda captures moved or partially moved value '" + symbolNames.at(id) + "'");
        }
        if (!n->c.empty() && containsMove(n->c[0].get()))
          fail(n, "move inside lambda is not supported; move the value before creating the closure or use a dedicated owner function");
        return;
      }
      case NK::Call:
        if (isMoveCall(n)) {
          if (n->c.size() != 2 || !n->c[1])
            fail(n, "move() ต้องรับ local variable หรือ named struct field path เช่น move(value) หรือ move(record.inner.payload)");
          if (n->c[1]->k == NK::Ident) {
            auto it = identSymbols.find(n->c[1].get());
            if (it == identSymbols.end())
              fail(n, "move() currently requires a local variable, not a global or unresolved name: '" + n->c[1]->s + "'");
            const Symbol id = it->second;
            const std::string &name = symbolNames.at(id);
            if (state.count(id)) fail(n, "value '" + name + "' is moved more than once or is still moved on a loop back-edge");
            auto partial = partialRootSymbols.find(id);
            if (partial != partialRootSymbols.end() && state.count(partial->second))
              fail(n, "cannot move whole value '" + name + "' while one or more fields are moved");
            if (deferredUses.count(id)) fail(n, "cannot move '" + name + "' because a defer block may use it later");
            state.insert(id);
            return;
          }
          Symbol rootId = 0; std::string projection;
          if (localProjection(n->c[1].get(), rootId, projection)) {
            auto field = fieldSymbols.find({rootId, projection});
            if (field == fieldSymbols.end()) fail(n, "internal: missing field-path identity for partial move");
            if (state.count(rootId)) fail(n, "cannot move field from already moved value '" + symbolNames.at(rootId) + "'");
            if (movedProjectionOverlaps(rootId, projection, state))
              fail(n, "field path '" + symbolNames.at(rootId) + "." + projection + "' overlaps a field path that is already moved");
            if (deferredUses.count(rootId)) fail(n, "cannot partially move '" + symbolNames.at(rootId) + "' because a defer block may use it later");
            state.insert(field->second);
            auto marker = partialRootSymbols.find(rootId);
            if (marker == partialRootSymbols.end()) fail(n, "internal: missing partial-move root identity");
            state.insert(marker->second);
            return;
          }
          fail(n, "partial move requires a direct named field path rooted at a local value struct");
          return;
        }
        if (!n->c.empty() && n->c[0] && n->c[0]->k == NK::Member &&
            !n->c[0]->c.empty()) {
          Symbol root = 0; std::string receiverPath;
          const Node *receiver = n->c[0]->c[0].get();
          if (receiver && receiver->k == NK::Ident) {
            auto rootIt = identSymbols.find(receiver);
            if (rootIt != identSymbols.end()) {
              root = rootIt->second;
              receiverPath.clear();
              if (hasMovedField(root, state))
                fail(n, "cannot call a method or callable member on partially moved aggregate '" + symbolNames.at(root) + "'");
            }
          } else if (localProjection(receiver, root, receiverPath)) {
            // receiver is itself a nested projection (e.g. outer.inner).
          }
          if (root) {
            if (state.count(root) || movedProjectionOverlaps(root, receiverPath, state))
              fail(n, "cannot call a method or callable member on moved/partially moved aggregate '" + symbolNames.at(root) + "'");
          }
        }
        for (const auto &c : n->c) transferExpr(c.get(), state);
        return;
      case NK::Assign: {
        const Node *lhs = n->c.size() > 0 ? n->c[0].get() : nullptr;
        const Node *rhs = n->c.size() > 1 ? n->c[1].get() : nullptr;
        if (n->s == "=" && lhs && lhs->k == NK::Ident) {
          transferExpr(rhs, state);
          auto it = identSymbols.find(lhs);
          if (it != identSymbols.end()) {
            state.erase(it->second);
            auto fields = fieldsByRoot.find(it->second);
            if (fields != fieldsByRoot.end()) for (Symbol field : fields->second) state.erase(field);
            auto marker = partialRootSymbols.find(it->second);
            if (marker != partialRootSymbols.end()) state.erase(marker->second);
          }
        } else if (n->s == "=") {
          Symbol root = 0; std::string projection;
          if (localProjection(lhs, root, projection)) {
            if (state.count(root)) fail(lhs, "cannot initialize a field of an already moved aggregate '" + symbolNames.at(root) + "'");
            // Writing through a moved ancestor is invalid. Replacing an ancestor
            // of moved descendants is valid: its recursive drop sees sentinels.
            for (auto it = fieldSymbols.lower_bound({root, std::string{}});
                 it != fieldSymbols.end() && it->first.first == root; ++it) {
              if (state.count(it->second) && pathPrefix(it->first.second, projection))
                fail(lhs, "cannot write through moved field path '" + symbolNames.at(it->second) + "'");
            }
            transferExpr(rhs, state);
            clearPartialProjection(root, projection, state);
          } else { transferExpr(lhs, state); transferExpr(rhs, state); }
        } else {
          transferExpr(lhs, state); transferExpr(rhs, state);
          if (lhs && lhs->k == NK::Ident) {
            auto it = identSymbols.find(lhs);
            if (it != identSymbols.end()) state.erase(it->second);
          }
        }
        return;
      }
      case NK::IfV: {
        if (n->c.size() < 3) { for (const auto &c : n->c) transferExpr(c.get(), state); return; }
        State tests = state, joined;
        for (size_t i = 0; i + 1 < n->c.size() - 1; i += 2) {
          transferExpr(n->c[i].get(), tests);
          State branch = tests; transferExpr(n->c[i + 1].get(), branch);
          joined.insert(branch.begin(), branch.end());
        }
        transferExpr(n->c.back().get(), tests);
        joined.insert(tests.begin(), tests.end());
        state.swap(joined);
        return;
      }
      case NK::MatchExpr: {
        if (!n->c.empty()) transferExpr(n->c[0].get(), state);
        State joined;
        for (const auto &cs : n->cases) {
          State branch = state;
          for (const auto &v : cs.vals) transferExpr(v.get(), branch);
          for (const auto &r : cs.ranges) {
            transferExpr(r.lo.get(), branch); transferExpr(r.hi.get(), branch);
          }
          transferExpr(cs.guard.get(), branch); transferExpr(cs.exprBody.get(), branch);
          joined.insert(branch.begin(), branch.end());
        }
        if (n->deflt) { State branch = state; transferExpr(n->deflt.get(), branch); joined.insert(branch.begin(), branch.end()); }
        else joined.insert(state.begin(), state.end());
        state.swap(joined);
        return;
      }
      default:
        break;
    }
    for (const auto &c : n->c) transferExpr(c.get(), state);
    for (const auto &cs : n->cases) {
      for (const auto &v : cs.vals) transferExpr(v.get(), state);
      for (const auto &r : cs.ranges) {
        transferExpr(r.lo.get(), state); transferExpr(r.hi.get(), state);
      }
      transferExpr(cs.guard.get(), state); transferExpr(cs.exprBody.get(), state);
      transferExpr(cs.body.get(), state);
    }
    transferExpr(n->deflt.get(), state);
  }

  void transfer(const BasicBlock &block, State &state) const {
    const Node *n = block.syntax;
    if (!n || block.action == Action::Nop) return;
    switch (block.action) {
      case Action::Expr:
        if (n->k == NK::Return || n->k == NK::Throw || n->k == NK::ExprStmt) {
          if (!n->c.empty()) transferExpr(n->c[0].get(), state);
        } else transferExpr(n, state);
        return;
      case Action::Decl:
        if (!n->c.empty()) transferExpr(n->c[0].get(), state);
        if (declSymbols.count(n)) state.erase(declSymbols.at(n));
        return;
      case Action::Defer: {
        if (!n->c.empty() && containsMove(n->c[0].get())) fail(n, "move inside defer is not supported");
        auto it = deferCaptures.find(n);
        if (it != deferCaptures.end()) for (Symbol id : it->second) {
          auto partial = partialRootSymbols.find(id);
          if (state.count(id) || (partial != partialRootSymbols.end() && state.count(partial->second)))
            fail(n, "defer may use moved or partially moved value '" + symbolNames.at(id) + "'");
        }
        if (!n->c.empty()) transferExpr(n->c[0].get(), state);
        return;
      }
      case Action::MarkMoved:
        state.insert(block.marked.begin(), block.marked.end());
        return;
      case Action::Nop:
        return;
    }
  }

  void checkFunction(const Node *fn) {
    if (!fn || fn->k != NK::Func || fn->c.empty()) return;
    cfg.clear(); identSymbols.clear(); declSymbols.clear(); lambdaCaptures.clear();
    deferCaptures.clear(); symbolNames.clear(); deferredUses.clear(); nextSymbol = 1;
    fieldSymbols.clear(); partialRootSymbols.clear(); fieldsByRoot.clear();
    fieldSymbolIds.clear(); partialRootSymbolIds.clear();
    activeFinalizers.clear();
    Env env;
    for (const auto &p : fn->params) env[p.name] = newSymbol(p.name);
    bindStmt(fn->c[0].get(), env);

    cfg.push_back(BasicBlock{}); // exit sink, intentionally has no transfer or successors
    exitBlock = 0;
    const int entry = buildStmt(fn->c[0].get(), exitBlock, {});
    if (entry < 0) return;

    std::vector<State> in(cfg.size());
    std::vector<bool> reached(cfg.size(), false), queued(cfg.size(), false);
    std::deque<int> work;
    reached[entry] = true; queued[entry] = true; work.push_back(entry);
    while (!work.empty()) {
      const int id = work.front(); work.pop_front(); queued[id] = false;
      State out = in[id];
      transfer(cfg[id], out);
      for (int succ : cfg[id].succ) {
        if (succ < 0 || static_cast<size_t>(succ) >= cfg.size()) continue;
        State merged = in[succ];
        merged.insert(out.begin(), out.end());
        if (!reached[succ] || merged != in[succ]) {
          in[succ].swap(merged); reached[succ] = true;
          if (!queued[succ]) { queued[succ] = true; work.push_back(succ); }
        }
      }
    }
  }

 public:
  void run(const std::vector<std::unique_ptr<Program>> &programs) {
    for (const auto &p : programs) {
      for (const auto &f : p->funcs) checkFunction(f.get());
      for (const auto &s : p->structs) {
        for (const auto &m : s->methods) checkFunction(m.get());
        for (const auto &c : s->c) checkFunction(c.get());
      }
    }
  }
};

inline void checkStrictMove(const std::vector<std::unique_ptr<Program>> &programs) {
  FacMoveChecker checker;
  checker.run(programs);
}
