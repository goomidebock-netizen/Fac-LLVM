// ---- (included inside class Gen) calls & builtins ----
std::set<std::string> curImports;

int enumIdx(const std::string &e, const std::string &m) {
  auto it = enums.find(e); if (it == enums.end()) return -1;
  for (size_t i = 0; i < it->second.mem.size(); i++) if (it->second.mem[i].name == m) return (int)i;
  return -1;
}
std::string enumSlotAddr(const std::string &enumName, const std::string &addr, size_t slot) {
  return def("getelementptr inbounds " + llty(tEnum(enumName, true)) + ", ptr " + addr + ", i32 0, i32 1, i64 " + std::to_string(slot));
}
std::string encodeEnumPayload(V value, const T &target, int line) {
  auto pointerManaged = [&](const T &t) {
    return t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == OBJ || t->k == WEAK;
  };
  auto boxDrop = [&](const T &t) {
    if (t->k == STRUCT) return std::string("@drop.box.struct.") + t->name;
    if (t->k == ENUM && t->payloadEnum) return std::string("@drop.box.enum.") + t->name;
    return std::string("null");
  };
  if (target->k == STRUCT || (target->k == ENUM && target->payloadEnum)) {
    if (value.t->k != target->k || value.t->name != target->name)
      err("payload enum ต้องการ " + tname(target) + " แต่ได้รับ " + tname(value.t), line);
    // Aggregate payloads live in a separately allocated box because each enum
    // payload slot is one machine word. The box is deep-copied, so the source
    // retains its own independent lifetime.
    borrow(value);
    const std::string box = def("call ptr @fac_alloc(i64 " + std::to_string(sizeOf(target)) + ")");
    ins("call void @fac_tmp_push_drop(ptr " + box + ", ptr " + boxDrop(target) + ")");
    if (target->k == STRUCT) ins("call void @copy." + target->name + "(ptr " + box + ", ptr " + value.v + ")");
    else ins("call void @copy.enum." + target->name + "(ptr " + box + ", ptr " + value.v + ")");
    ins("call void @fac_tmp_pop(ptr " + box + ")");
    return def("ptrtoint ptr " + box + " to i64");
  }
  if (pointerManaged(target)) {
    bool compatible = false;
    if (target->k == STR) compatible = value.t->k == STR || value.t->k == NULLT;
    else if (target->k == LIST) compatible = (value.t->k == LIST && sameT(value.t, target)) || value.t->k == NULLT;
    else if (target->k == DSK) compatible = (value.t->k == DSK && value.t->name == target->name) || value.t->k == NULLT;
    else if (target->k == FUNC) compatible = value.t->k == FUNC || value.t->k == NULLT;
    else if (target->k == OBJ) compatible = (value.t->k == OBJ && isSubclass(value.t->name, target->name)) || value.t->k == NULLT;
    else if (target->k == WEAK) compatible = (value.t->k == WEAK && isSubclass(value.t->name, target->name)) || value.t->k == NULLT;
    if (!compatible) err("payload enum ต้องการ " + tname(target) + " แต่ได้รับ " + tname(value.t), line);
    V owned = value.t->k == NULLT ? value : ownV(value);
    if (owned.t->k != NULLT) {
      borrow(owned);
      transferTemp(owned); // ownership is now stored in the enum payload slot
      return def("ptrtoint ptr " + owned.v + " to i64");
    }
    return "0";
  }
  checkImplicit(value, target, line);
  if (target->k == F64) return def("bitcast double " + conv(value, target, line) + " to i64");
  if (target->k == F32) {
    std::string d = def("fpext float " + conv(value, target, line) + " to double");
    return def("bitcast double " + d + " to i64");
  }
  if (target->k == PTR || target->k == OPAQUE) return def("ptrtoint ptr " + conv(value, target, line) + " to i64");
  if (target->k == ENUM && !target->payloadEnum) {
    std::string x = conv(value, target, line);
    return def("sext i32 " + x + " to i64");
  }
  std::string x = conv(value, target, line), ty = llty(target);
  if (ty == "i64") return x;
  if (ty == "i8" || ty == "i16" || ty == "i32")
    return def(std::string(signedOf(target) ? "sext " : "zext ") + ty + " " + x + " to i64");
  err("payload enum ไม่รองรับ payload ชนิด " + tname(target), line);
}
V decodeEnumPayload(const std::string &enumName, const std::string &addr, size_t slot, const T &target) {
  std::string raw = def("load i64, ptr " + enumSlotAddr(enumName, addr, slot));
  V value; value.t = target;
  if (target->k == F64) value.v = def("bitcast i64 " + raw + " to double");
  else if (target->k == F32) {
    std::string d = def("bitcast i64 " + raw + " to double"); value.v = def("fptrunc double " + d + " to float");
  } else if (target->k == PTR || target->k == OPAQUE || target->k == STR || target->k == LIST || target->k == DSK || target->k == FUNC || target->k == OBJ || target->k == WEAK || target->k == STRUCT || (target->k == ENUM && target->payloadEnum)) {
    value.v = def("inttoptr i64 " + raw + " to ptr");
  } else {
    std::string ty = llty(target);
    value.v = ty == "i64" ? raw : def("trunc i64 " + raw + " to " + ty);
  }
  return value;
}
V enumV(const std::string &e, const std::string &m) {
  auto it = enums.find(e); if (it == enums.end()) err("ไม่รู้จัก enum '" + e + "'");
  int idx = enumIdx(e, m); if (idx < 0) err("enum " + e + " ไม่มี variant '" + m + "'");
  EnumInfo &info = it->second; V r; r.t = tEnum(e, info.hasPayload);
  if (!info.hasPayload) { r.v = std::to_string(idx); return r; }
  if (!info.payloadTypes[(size_t)idx].empty()) err("enum variant " + e + "." + m + " ต้องส่ง payload ด้วยวงเล็บ");
  r.v = alloca_(r.t);
  ins("store " + llty(r.t) + " zeroinitializer, ptr " + r.v);
  std::string tag = def("getelementptr inbounds " + llty(r.t) + ", ptr " + r.v + ", i32 0, i32 0");
  ins("store i32 " + std::to_string(idx) + ", ptr " + tag);
  r.owned = needsFree(r.t); borrow(r);
  return r;
}
V enumVariantCall(const std::string &enumName, const std::string &variant, const std::vector<Node *> &args, Node *call) {
  auto it = enums.find(enumName); if (it == enums.end()) err("ไม่รู้จัก enum '" + enumName + "'", call->line);
  EnumInfo &info = it->second;
  size_t idx = 0; const EnumMember *member = enumMember(info, variant, &idx);
  if (!member) err("enum " + enumName + " ไม่มี variant '" + variant + "'", call->line);
  if (!info.hasPayload) err("enum " + enumName + " ไม่มี payload variant", call->line);
  const std::vector<T> &types = info.payloadTypes[idx];
  if (args.size() != types.size()) err("enum variant " + enumName + "." + variant + " ต้องการ " + std::to_string(types.size()) + " payload แต่ได้รับ " + std::to_string(args.size()), call->line);
  V result; result.t = tEnum(enumName, true); result.v = alloca_(result.t);
  ins("store " + llty(result.t) + " zeroinitializer, ptr " + result.v);
  std::string tag = def("getelementptr inbounds " + llty(result.t) + ", ptr " + result.v + ", i32 0, i32 0");
  ins("store i32 " + std::to_string(idx) + ", ptr " + tag);
  result.owned = needsFree(result.t);
  borrow(result); // partial payloads are released if a later argument throws
  for (size_t i = 0; i < args.size(); ++i) {
    V value = expr(args[i]);
    std::string encoded = encodeEnumPayload(value, types[i], args[i]->line);
    ins("store i64 " + encoded + ", ptr " + enumSlotAddr(enumName, result.v, i));
  }
  return result;
}
bool tryEnumVariantCall(const std::string &path, const std::vector<Node *> &args, Node *call, V &out) {
  std::vector<std::string> parts; std::string part;
  for (char ch : path) { if (ch == '.') { if (!part.empty()) parts.push_back(part); part.clear(); } else part += ch; }
  if (!part.empty()) parts.push_back(part);
  if (parts.size() < 2) return false;
  std::string enumName = parts[parts.size() - 2], variant = parts.back();
  if (!enums.count(enumName) || !enums[enumName].hasPayload) return false;
  std::string rawTypePath;
  for (size_t i = 0; i + 1 < parts.size(); ++i) rawTypePath += (i ? "." : "") + parts[i];
  requireTypeAccess(rawTypePath, enumName, enums[enumName].module, enums[enumName].isPublic, call->line);
  out = enumVariantCall(enumName, variant, args, call);
  return true;
}

void seqParts(const V &a, std::string &data, std::string &len, T &el, int line) {
  if (a.t->k == ARR) { data = a.v; len = a.len; el = a.t->el; }
  else if (a.t->k == LIST) { data = listField(a.v, 0, "ptr"); len = listField(a.v, 1, "i64"); el = a.t->el; }
  else err("ต้องเป็น array หรือ list (เจอ " + tname(a.t) + ")", line);
}

// ---------------------------------------------------------------- print
void printVal(const V &a0, int line) {
  V a = a0;
  switch (a.t->k) {
    case INT:
      if (a.t->sg) ins("call void @fac_print_i64(i64 " + conv(a, T_long) + ")");
      else ins("call void @fac_print_u64(i64 " + conv(a, T_ulong) + ")");
      break;
    case BOOL: ins("call void @fac_print_bool(i32 " + def("zext i8 " + a.v + " to i32") + ")"); break;
    case CHAR: case UNI: ins("call void @fac_print_char(i32 " + conv(a, T_uni) + ")"); break;
    case ENUM: { V s = enumConv(a, true); ins("call void @fac_print_str(ptr " + s.v + ")"); break; }
    case F32: ins("call void @fac_print_f32(float " + a.v + ")"); break;
    case F64: ins("call void @fac_print_f64(double " + a.v + ")"); break;
    case STR: ins("call void @fac_print_str(ptr " + a.v + ")"); break;
    case PTR: case OPAQUE: case NULLT: ins("call void @fac_print_ptr(ptr " + a.v + ")"); break;
    case ARR: case LIST: {
      std::string d, l; T el; seqParts(a, d, l, el, line);
      ins("call void @fac_print_seq(ptr " + d + ", i64 " + l + ", i32 " + std::to_string(tcode(el)) + ")");
      break;
    }
    case STRUCT:
      if (isVecT(a.t)) { ins("call void @fac_print_vec(ptr " + a.v + ", i32 " + std::to_string(vecN(a.t->name)) + ")"); break; }
      if (isMatT(a.t)) { ins("call void @fac_print_mat4(ptr " + a.v + ")"); break; }
      err("พิมพ์ " + tname(a.t) + " โดยตรงไม่ได้ (พิมพ์ทีละ field)", line);
    default: err("พิมพ์ " + tname(a.t) + " โดยตรงไม่ได้ (พิมพ์ทีละ field)", line);
  }
}
V printCall(const std::vector<Node *> &args, bool nl, bool toErr, int line) {
  if (toErr) ins("call void @fac_use(i32 2)");
  for (Node *a : args) { V v = expr(a); borrow(v); printVal(v, line); }
  if (nl) ins("call void @fac_print_nl()");
  if (toErr) ins("call void @fac_use(i32 1)");
  return V();
}

V scannerCall(const std::vector<Node *> &args, int line) {
  if (args.empty() || args[0]->k != NK::Ident) err("Scanner(Type) ต้องระบุ type เช่น Scanner(Int)", line);
  const std::string &nm = args[0]->s;
  if (nm == "Array") err("Scanner(Array, Char) ยังไม่รองรับ (ใช้ Scanner(String) หรือ readline())", line);
  T t = typeFromName(nm);
  if (!t) err("Scanner: ไม่รู้จัก type '" + nm + "'", line);
  V r;
  if (t->k == STR) { r.t = T_str; r.owned = true; r.v = def("call ptr @fac_scan_str()"); return r; }
  if (isFlt(t)) { V x; x.t = T_double; x.v = def("call double @fac_scan_f64()"); return cv(x, t); }
  if (t->k == BOOL) { V x; x.t = T_int; x.v = def("call i32 @fac_scan_bool()"); return cv(x, T_bool); }
  if (t->k == CHAR || t->k == UNI) { V x; x.t = T_uni; x.v = def("call i32 @fac_scan_char()"); return cv(x, t); }
  if (t->k == INT) { V x; x.t = T_long; x.v = def("call i64 @fac_scan_i64()"); return cv(x, t); }
  err("Scanner ไม่รองรับ type " + nm, line);
}

// ---------------------------------------------------------------- user functions
V makeTempArrayN(const std::vector<Node *> &items, const T &el, int line) {
  size_t n = items.size(), cnt = std::max<size_t>(n, 1);
  std::string a = alloca_(el, (int64_t)cnt);
  ins("call void @llvm.memset.p0.i64(ptr " + a + ", i8 0, i64 " + std::to_string(cnt * sizeOf(el)) + ", i1 false)");
  for (size_t i = 0; i < n; i++) {
    V v = expr(items[i]);
    std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + a + ", i64 " + std::to_string(i));
    ins("store " + llty(el) + " " + conv(v, el, line) + ", ptr " + p);
  }
  V r; r.t = tArr(el, (int64_t)n); r.v = a; r.len = std::to_string(n); return r;
}
V makeTempArray(Node *init, const T &el, int line) {
  std::vector<Node *> v; for (auto &c : init->c) v.push_back(c.get());
  return makeTempArrayN(v, el, line);
}

int scoreArg(const T &a, const T &p) {
  if (p->k == FUNC) return (a->k == FUNC || a->k == NULLT) ? 3 : -1;
  if (a->k == NULLT) return (isPtrish(p) || p->k == ARR) ? 1 : -1;
  if (p->k == ARR || p->k == LIST) return (a->k == ARR || a->k == LIST) ? (a->k == p->k ? 3 : 2) : -1;
  if (a->k == FUNC) return -1;
  if (sameT(a, p) && a->k != PTR) return 3;
  if (p->k == PTR && a->k == PTR) {
    // Prefer an exact pointee overload. Keep generic pointer compatibility at
    // a lower score so `ptr int` and `ptr long` overloads are deterministic.
    if (a->el && p->el && sameFunctionValueType(a->el, p->el)) return 4;
    return 2;
  }
  if (p->k == PTR && a->k == OPAQUE) return 2;
  if (isNum(a) && isNum(p)) return isFlt(a) == isFlt(p) ? 2 : 1;
  return -1;
}

FuncInfo *pickFunc(const std::string &key, const std::vector<Node *> &args, int line) {
  auto it = funcs.find(key);
  if (it == funcs.end()) return nullptr;
  std::vector<FuncInfo *> cands = overloads.count(key) ? overloads[key] : std::vector<FuncInfo *>{&it->second};
  if (cands.size() == 1) return cands[0];
  FuncInfo *best = nullptr; int bs = -1000000; bool tie = false;
  for (FuncInfo *c : cands) {
    size_t np = c->pt.size(), fixed = c->variadic ? np - 1 : np, minA = 0;
    for (size_t i = 0; i < fixed; i++) if (!(i < c->pdef.size() && c->pdef[i])) minA = i + 1;
    if (args.size() < minA || (!c->variadic && args.size() > np)) continue;
    int sc = 0; bool ok = true;
    for (size_t i = 0; i < args.size() && ok; i++) {
      if (c->generic) continue;
      T pt = i < fixed ? c->pt[i] : c->pt[np - 1]->el;
      int s2 = scoreArg(dryType(args[i]), pt);
      if (s2 < 0) ok = false; else sc += s2;
    }
    if (!ok) continue;
    if (c->generic) sc -= 50;
    if (sc > bs) { best = c; bs = sc; tie = false; } else if (sc == bs) tie = true;
  }
  if (!best) err("ไม่มี overload ของ '" + it->second.name + "' ที่รับ argument ชุดนี้", line);
  if (tie) err("เรียก '" + it->second.name + "' กำกวม (มีหลาย overload ที่เหมาะสมเท่ากัน)", line);
  return best;
}

void emitNested(FuncInfo &f) {  // emit function ระหว่างที่กำลัง emit อีก function (generic instantiation)
  std::string sb = std::move(body), sa = std::move(allocas), sbb = curBB, smod = curModule;
  bool st = term; int sl = curLine; FuncInfo *scf = cf;
  auto ssc = std::move(scopes); auto slp = std::move(loops); auto stm = std::move(temps); auto simp = curImports;
  body.clear(); allocas.clear(); scopes.clear(); loops.clear(); temps.clear();
  emitFunc(f);
  body = std::move(sb); allocas = std::move(sa); curBB = sbb; curModule = smod; term = st; curLine = sl; cf = scf;
  scopes = std::move(ssc); loops = std::move(slp); temps = std::move(stm); curImports = simp;
}

bool runtimeTypeSpec(const T &type, TypeSpec &result, unsigned depth = 0) {
  if (!type || depth > 16) return false;
  result = TypeSpec{};
  switch (type->k) {
    case VOID: result.base = "void"; return true;
    case INT:
      result.base = type->bits == 8 ? (type->sg ? "byte" : "ubyte") :
                    type->bits == 16 ? (type->sg ? "short" : "ushort") :
                    type->bits == 32 ? (type->sg ? "int" : "uint") :
                                       (type->sg ? "long" : "ulong");
      return true;
    case F32: result.base = "float"; return true;
    case F64: result.base = "double"; return true;
    case BOOL: result.base = "boolean"; return true;
    case CHAR: result.base = "char"; return true;
    case UNI: result.base = "unichar"; return true;
    case STR: result.base = "string"; return true;
    case STRUCT: result.cat = "struct"; result.base = type->name; return !type->name.empty();
    case OBJ: result.cat = "obj"; result.base = type->name; return !type->name.empty();
    case WEAK: result.cat = "weakobj"; result.base = type->name; return !type->name.empty();
    case ENUM: result.cat = "enum"; result.base = type->name; return !type->name.empty();
    case PTR: {
      if (!runtimeTypeSpec(type->el, result, depth + 1)) return false;
      result.kind = "ptr";
      result.isVolatile = type->isVolatile;
      return true;
    }
    case LIST: {
      TypeSpec element;
      if (!runtimeTypeSpec(type->el, element, depth + 1)) return false;
      result.cat = "list";
      if (element.cat == "obj") {
        result.kind = "dyn";
        result.elemObj = true;
        result.base = element.base;
      } else if (element.cat.empty() && element.kind.empty()) {
        result.base = element.base;
      } else {
        return false;
      }
      return true;
    }
    case ARR: {
      TypeSpec element;
      if (!runtimeTypeSpec(type->el, element, depth + 1) ||
          !element.cat.empty() || !element.kind.empty()) return false;
      result.cat = "array";
      result.base = element.base;
      return true;
    }
    case TUPLE:
      result.cat = "tuple";
      for (const T &item : type->ps) {
        TypeSpec element;
        if (!runtimeTypeSpec(item, element, depth + 1) ||
            !(element.cat.empty() || element.kind == "ptr")) return false;
        result.sig.push_back(std::move(element));
      }
      return result.sig.size() >= 2;
    case FUNC: {
      result.cat = "func";
      result.hasSig = true;
      TypeSpec returned;
      if (!runtimeTypeSpec(type->el, returned, depth + 1)) return false;
      result.sigReturnType = std::make_shared<TypeSpec>(std::move(returned));
      for (const T &parameter : type->ps) {
        TypeSpec item;
        if (!runtimeTypeSpec(parameter, item, depth + 1)) return false;
        result.sig.push_back(std::move(item));
      }
      result.sigNoescape = type->noescape;
      result.sigReadonly = type->readonly;
      result.sigLifetimeParams = type->lifetimeNames;
      result.sigLifetimeOutlives = type->lifetimeOutlives;
      return true;
    }
    default:
      // Null, opaque handles, dynamic data structures and auto have no
      // stable source TypeSpec representation for generic substitution yet.
      return false;
  }
}

bool bindInferredFunctionType(const std::string &name, const T &actual,
                              std::map<std::string, TypeSpec> &bindings,
                              std::map<std::string, T> &concreteTypes,
                              int line) {
  if (name.empty() || !actual || actual->k == NULLT || actual->k == AUTOT)
    return false;
  auto existing = concreteTypes.find(name);
  if (existing != concreteTypes.end()) {
    if (sameT(existing->second, actual)) return true;
    err("generic function type parameter '" + name +
        "' inferred as conflicting types " + tname(existing->second) +
        " and " + tname(actual), line);
  }
  TypeSpec actualSpec;
  if (!runtimeTypeSpec(actual, actualSpec)) return false;
  concreteTypes.emplace(name, actual);
  bindings.emplace(name, std::move(actualSpec));
  return true;
}

bool inferFreeFunctionTypeParameter(const TypeSpec &pattern, const T &actual,
                                    const std::set<std::string> &genericNames,
                                    std::map<std::string, TypeSpec> &bindings,
                                    std::map<std::string, T> &concreteTypes,
                                    int line) {
  if (pattern.cat.empty() && pattern.kind.empty() &&
      genericNames.count(pattern.base))
    return bindInferredFunctionType(pattern.base, actual, bindings, concreteTypes, line);
  if (pattern.kind == "ptr" && pattern.cat.empty() &&
      genericNames.count(pattern.base) && actual && actual->k == PTR)
    return bindInferredFunctionType(pattern.base, actual->el, bindings, concreteTypes, line);
  if ((pattern.cat == "list" || pattern.cat == "array") &&
      genericNames.count(pattern.base) && actual &&
      ((pattern.cat == "list" && actual->k == LIST) ||
       (pattern.cat == "array" && (actual->k == ARR || actual->k == LIST))))
    return bindInferredFunctionType(pattern.base, actual->el, bindings, concreteTypes, line);
  return false;
}

// Infer a const generic value only from a statically known fixed-array extent
// explicitly named by the parameter's type shape, e.g. `array T values[N]`.
// Runtime lengths, lists, slices and arbitrary integer arguments are not used as
// evidence because they do not establish a compile-time value.
bool inferFreeFunctionConstParameter(const TypeSpec &pattern, const T &actual,
                                     const std::set<std::string> &constGenericNames,
                                     std::map<std::string, int64_t> &constBindings,
                                     const std::string &functionName, size_t argumentIndex,
                                     int line) {
  if (pattern.cat != "array" || !pattern.hasSize || !pattern.size ||
      pattern.size->k != NK::Ident ||
      !constGenericNames.count(pattern.size->s))
    return false;

  const std::string &parameter = pattern.size->s;
  if (!actual || actual->k != ARR || actual->n < 0)
    err("generic function '" + functionName + "' cannot infer const generic parameter '" +
        parameter + "' from argument " + std::to_string(argumentIndex + 1) +
        ": ต้องส่ง fixed-size array ที่ทราบขนาดตอน compile time", line);

  auto existing = constBindings.find(parameter);
  if (existing != constBindings.end() && existing->second != actual->n)
    err("generic function const parameter '" + parameter +
        "' inferred as conflicting values " + std::to_string(existing->second) +
        " and " + std::to_string(actual->n), line);
  constBindings.emplace(parameter, actual->n);
  return true;
}

FuncInfo *instantiate(FuncInfo *g, const std::vector<Node *> &args, Node *n,
                      const std::vector<TypeSpec> *explicitTypes = nullptr) {
  Node *sourceFn = g->node;
  std::vector<TypeSpec> orderedExplicitTypes;
  std::vector<bool> explicitlySupplied;
  const std::vector<TypeSpec> *effectiveExplicitTypes = nullptr;
  const bool hasWrittenGenericArguments = explicitTypes && !explicitTypes->empty();
  const bool mustUseExplicitOrDefaults = !g->structName.empty();
  if (hasWrittenGenericArguments || mustUseExplicitOrDefaults) {
    if (hasWrittenGenericArguments) {
      orderedExplicitTypes.reserve(explicitTypes->size());
      for (const TypeSpec &argument : *explicitTypes)
        orderedExplicitTypes.push_back(cloneTypeSpec(argument));
    }
    std::vector<bool> hasDefaults = sourceFn->genericHasDefault;
    if (hasDefaults.size() != sourceFn->typeParams.size())
      hasDefaults.assign(sourceFn->typeParams.size(), false);
    std::string diagnostic;
    if (!orderNamedGenericArgumentsWithDefaults(orderedExplicitTypes,
            sourceFn->typeParams, hasDefaults, explicitlySupplied, diagnostic))
      err("generic " + std::string(g->structName.empty() ? "function" : "method") +
          " '" + sourceFn->s + "': " + diagnostic, n->line);
    effectiveExplicitTypes = &orderedExplicitTypes;
  }
  std::vector<T> ats; std::string key = g->sym + "|";
  for (Node *a : args) { ats.push_back(dryType(a)); key += tname(ats.back()) + ";"; }
  std::map<std::string, TypeSpec> bindings;
  std::map<std::string, int64_t> constBindings;
  if (!sourceFn->typeParams.empty()) {
    std::vector<T> concreteTypes;
    concreteTypes.reserve(sourceFn->typeParams.size());
    const std::set<std::string> constParameterNames(
        sourceFn->constGenericParams.begin(), sourceFn->constGenericParams.end());
    const bool hasConstParameters = !constParameterNames.empty();
    const bool inferFreeFunction = g->structName.empty() && !effectiveExplicitTypes;
    auto hasGenericDefault = [&](size_t index) {
      return index < sourceFn->genericHasDefault.size() &&
             sourceFn->genericHasDefault[index] && index < sourceFn->genericDefaults.size();
    };
    std::function<void(Node *)> substituteDefaultConstExpr = [&](Node *expression) {
      if (!expression) return;
      if (expression->k == NK::Ident) {
        auto value = constBindings.find(expression->s);
        if (value != constBindings.end()) {
          expression->k = NK::IntLit; expression->iv = value->second; expression->s.clear();
          expression->c.clear(); return;
        }
      }
      for (auto &child : expression->c) substituteDefaultConstExpr(child.get());
    };
    std::function<void(TypeSpec &)> substituteDefaultConstType = [&](TypeSpec &type) {
      substituteDefaultConstExpr(type.size.get());
      substituteDefaultConstExpr(type.size2.get());
      for (auto &argument : type.genericArgs) substituteDefaultConstType(argument);
      for (auto &parameter : type.sig) substituteDefaultConstType(parameter);
      if (type.sigReturnType) substituteDefaultConstType(*type.sigReturnType);
      if (type.constExpr) substituteDefaultConstExpr(type.constExpr.get());
    };
    std::function<void(TypeSpec &)> substituteDefaultType = [&](TypeSpec &type) {
      for (auto &argument : type.sig) substituteDefaultType(argument);
      if (type.sigReturnType) substituteDefaultType(*type.sigReturnType);
      for (auto &argument : type.genericArgs) substituteDefaultType(argument);
      auto binding = bindings.find(type.base);
      if (binding != bindings.end()) {
        TypeSpec actual = cloneTypeSpec(binding->second);
        if (type.cat == "list" || type.cat == "array" || type.cat == "arraylist" ||
            type.cat == "hashmap" || type.cat == "hashset" || type.cat == "tree" ||
            type.cat == "graph" || type.cat == "linked" || type.cat == "stack" ||
            type.cat == "queue" || type.cat == "heap" || type.cat == "maxheap" || type.cat == "trie") {
          if (actual.cat == "obj") { type.elemObj = true; type.base = actual.base; }
          else { type.base = actual.base; if (!actual.kind.empty() && (type.kind.empty() || type.kind == "var")) type.kind = actual.kind; }
        } else if (type.kind == "ptr" && type.cat.empty()) {
          type.base = actual.base;
          if (!actual.cat.empty()) type.cat = actual.cat;
        } else {
          const std::string declaredKind = type.kind;
          type = std::move(actual);
          if (!declaredKind.empty() && declaredKind != "var" &&
              (type.kind.empty() || type.kind == "var")) type.kind = declaredKind;
        }
      }
      auto valueBinding = bindings.find(type.base2);
      if (valueBinding != bindings.end()) {
        if (!valueBinding->second.cat.empty())
          err("generic hashmap key/value ต้องใช้ type argument ที่ไม่ใช่ obj/struct wrapper", n->line);
        type.base2 = valueBinding->second.base;
      }
    };
    auto resolveConstArgument = [&](TypeSpec actual, const std::string &parameter,
                                    bool useDefault) -> int64_t {
      if (useDefault && actual.constExpr) substituteDefaultConstExpr(actual.constExpr.get());
      int64_t value = 0;
      if (actual.constExpr) {
        if (!constEval(actual.constExpr.get(), value))
          err("const generic argument/default ของ '" + parameter +
              "' ต้องเป็น integer constant expression ที่ประเมินได้โดยไม่มี overflow หรือ undefined operation", n->line);
      } else if (actual.isConstValue) {
        value = actual.constValue;
      } else {
        err("generic parameter '" + parameter + "' ต้องเป็น const int value argument เช่น (2 * 8)", n->line);
      }
      return value;
    };
    auto resolveTypeArgument = [&](TypeSpec actual, const std::string &parameter,
                                   bool useDefault) -> T {
      if (useDefault) {
        substituteDefaultType(actual);
        substituteDefaultConstType(actual);
      }
      if (actual.isConstValue || actual.constExpr)
        err("generic parameter '" + parameter + "' ต้องเป็น type argument ไม่ใช่ const value", n->line);
      if (actual.base.empty() || actual.base == "void" || actual.base == "auto" || actual.base == "null" || actual.cat == "tuple" || actual.cat == "func")
        err(std::string(g->structName.empty() ? "generic function" : "generic method") +
            " type argument ต้องเป็น concrete type", n->line);
      T actualType = resolveType(actual, n->line);
      bindings[parameter] = std::move(actual);
      return actualType;
    };

    if (inferFreeFunction) {
      std::set<std::string> genericTypeNames;
      for (const std::string &parameter : sourceFn->typeParams)
        if (!constParameterNames.count(parameter)) genericTypeNames.insert(parameter);
      const std::set<std::string> constGenericNames(
          sourceFn->constGenericParams.begin(), sourceFn->constGenericParams.end());
      std::map<std::string, T> inferredTypes;
      for (size_t index = 0; index < args.size() && index < sourceFn->params.size(); ++index) {
        const T actual = index < ats.size() ? ats[index] : nullptr;
        const TypeSpec &pattern = sourceFn->params[index].ts;
        const bool inferredType = inferFreeFunctionTypeParameter(
            pattern, actual, genericTypeNames, bindings, inferredTypes, n->line);
        (void)inferFreeFunctionConstParameter(
            pattern, actual, constGenericNames, constBindings, sourceFn->s, index, n->line);
        if (!inferredType && genericTypeNames.count(pattern.base) &&
            !inferredTypes.count(pattern.base) && !hasGenericDefault(
                static_cast<size_t>(std::distance(sourceFn->typeParams.begin(),
                  std::find(sourceFn->typeParams.begin(), sourceFn->typeParams.end(), pattern.base)))))
          err("generic function '" + sourceFn->s + "' cannot infer type parameter '" +
              pattern.base + "' from argument " + std::to_string(index + 1), n->line);
      }
      for (size_t i = 0; i < sourceFn->typeParams.size(); ++i) {
        const std::string &parameter = sourceFn->typeParams[i];
        if (constParameterNames.count(parameter)) {
          auto inferred = constBindings.find(parameter);
          if (inferred == constBindings.end()) {
            if (!hasGenericDefault(i))
              err("generic function '" + sourceFn->s + "' cannot infer const generic parameter '" +
                  parameter + "': ต้องประกาศขนาด fixed array หรือกำหนด default/ระบุ generic argument", n->line);
            TypeSpec defaultValue = cloneTypeSpec(sourceFn->genericDefaults[i]);
            constBindings[parameter] = resolveConstArgument(std::move(defaultValue), parameter, true);
          }
          concreteTypes.push_back(nullptr);
          key += "<const_i64_" + std::to_string(constBindings[parameter]) + ">";
          continue;
        }
        auto inferred = inferredTypes.find(parameter);
        if (inferred == inferredTypes.end()) {
          if (!hasGenericDefault(i))
            err("generic function '" + sourceFn->s + "' cannot infer type parameter '" +
                parameter + "' from its arguments", n->line);
          TypeSpec defaultValue = cloneTypeSpec(sourceFn->genericDefaults[i]);
          T defaultType = resolveTypeArgument(std::move(defaultValue), parameter, true);
          inferred = inferredTypes.emplace(parameter, defaultType).first;
        }
        concreteTypes.push_back(inferred->second);
        key += "<" + tname(inferred->second) + ">";
      }
    } else {
      if (!effectiveExplicitTypes || effectiveExplicitTypes->size() != sourceFn->typeParams.size())
        err(std::string(g->structName.empty() ? "generic function" : "generic method") +
            " '" + sourceFn->s + "' ต้องระบุ generic arguments หรือประกาศ default ให้ครบ", n->line);
      for (size_t i = 0; i < sourceFn->typeParams.size(); i++) {
        const std::string &parameter = sourceFn->typeParams[i];
        const bool useDefault = i >= explicitlySupplied.size() || !explicitlySupplied[i];
        TypeSpec actual = useDefault ? cloneTypeSpec(sourceFn->genericDefaults[i])
                                     : cloneTypeSpec((*effectiveExplicitTypes)[i]);
        if (constParameterNames.count(parameter)) {
          if (useDefault && !hasGenericDefault(i))
            err("generic parameter '" + parameter + "' ไม่มี default", n->line);
          const int64_t value = resolveConstArgument(std::move(actual), parameter, useDefault);
          constBindings[parameter] = value;
          concreteTypes.push_back(nullptr);
          key += "<const_i64_" + std::to_string(value) + ">";
          continue;
        }
        if (useDefault && !hasGenericDefault(i))
          err("generic parameter '" + parameter + "' ไม่มี default", n->line);
        T actualType = resolveTypeArgument(std::move(actual), parameter, useDefault);
        concreteTypes.push_back(actualType);
        key += "<" + tname(actualType) + ">";
      }
    }

    // Generic constraints are checked at each specialization boundary.
    // Multiple entries for one parameter represent an intersection (AND),
    // matching the `T: BoundA & BoundB` declaration syntax.
    struct ModuleContextRestore {
      Gen &gen; std::string module; std::set<std::string> imports;
      explicit ModuleContextRestore(Gen &g) : gen(g), module(g.curModule), imports(g.curImports) {}
      ~ModuleContextRestore() { gen.curModule = std::move(module); gen.curImports = std::move(imports); }
    } restore(*this);
    curModule = g->module;
    curImports = modImports[curModule];

    std::function<bool(const std::string &, const std::string &, std::set<std::string> &)> implementsBound;
    implementsBound = [&](const std::string &actual, const std::string &bound, std::set<std::string> &seen) {
      if (actual == bound) return true;
      if (!seen.insert(actual).second || !structs.count(actual)) return false;
      const StructInfo &si = structs.at(actual);
      for (const std::string &in : si.impls) {
        if (in == bound) return true;
        if (implementsBound(in, bound, seen)) return true;
      }
      return !si.parent.empty() && implementsBound(si.parent, bound, seen);
    };
    for (const GenericBound &gb : sourceFn->genericBounds) {
      auto pi = std::find(sourceFn->typeParams.begin(), sourceFn->typeParams.end(), gb.param);
      if (pi == sourceFn->typeParams.end()) err(std::string(g->structName.empty() ? "generic function" : "generic method") +
          " constraint อ้าง parameter ที่ไม่มี: " + gb.param, n->line);
      const size_t ix = (size_t)std::distance(sourceFn->typeParams.begin(), pi);
      if (ix >= concreteTypes.size()) err("ภายใน compiler: generic type arguments ไม่ครบ", n->line);
      const T &actualTy = concreteTypes[ix];
      if (constParameterNames.count(gb.param)) {
        auto valueIt = constBindings.find(gb.param);
        if (valueIt == constBindings.end())
          err("ภายใน compiler: const generic argument ของ '" + gb.param + "' หายไป", n->line);
        const int64_t value = valueIt->second;
        if (!satisfiesConstGenericConstraint(gb.bound.base, value))
          err("const generic constraint " + gb.param + ": " + gb.bound.base +
              " ไม่ผ่านสำหรับค่า " + std::to_string(value), n->line);
        continue;
      }
      if (!actualTy) err("ภายใน compiler: generic type argument ไม่พร้อมสำหรับ constraint", n->line);
      const std::string boundRaw = gb.bound.base;
      if (boundRaw == "numeric" || boundRaw == "integral" || boundRaw == "reference" || boundRaw == "value") {
        const bool ok = boundRaw == "numeric" ? isNum(actualTy) :
                        boundRaw == "integral" ? actualTy->k == INT :
                        boundRaw == "reference" ? (actualTy->k == OBJ || actualTy->k == WEAK || actualTy->k == PTR) :
                        (isNum(actualTy) || actualTy->k == ENUM || actualTy->k == STRUCT || actualTy->k == PTR);
        if (!ok) err("generic constraint " + gb.param + ": " + boundRaw + " ไม่รับ type " + tname(actualTy), n->line);
        continue;
      }
      const std::string canonicalBound = canonicalModulePath(boundRaw);
      const size_t dot = canonicalBound.rfind('.');
      const std::string boundName = dot == std::string::npos ? canonicalBound : canonicalBound.substr(dot + 1);
      auto bi = structs.find(boundName);
      if (bi == structs.end()) err("generic constraint ไม่พบ class/interface/struct '" + boundRaw + "'", n->line);
      requireTypeAccess(canonicalBound, boundName, bi->second.module, bi->second.isPublic, n->line);
      bool ok = false;
      if (bi->second.isInterface) {
        if (actualTy->k == OBJ) { std::set<std::string> seen; ok = implementsBound(actualTy->name, boundName, seen); }
      } else if (bi->second.isClass) {
        ok = actualTy->k == OBJ && isSubclass(actualTy->name, boundName);
      } else {
        ok = actualTy->k == STRUCT && actualTy->name == boundName;
      }
      if (!ok) err("generic constraint " + gb.param + " ต้องเป็น " + boundName + " แต่ได้รับ " + tname(actualTy), n->line);
    }
  } else if (effectiveExplicitTypes && !effectiveExplicitTypes->empty()) {
    err("method '" + sourceFn->s + "' ไม่ได้ประกาศ generic type parameter", n->line);
  }
  auto hit = genCache.find(key);
  if (hit != genCache.end()) return hit->second;

  NP specializedNode = cloneNode(sourceFn);
  specializedNode->typeParams.clear();
  specializedNode->constGenericParams.clear();
  std::function<void(TypeSpec &)> subType = [&](TypeSpec &ts) {
    for (auto &a : ts.sig) subType(a);
    if (ts.sigReturnType) subType(*ts.sigReturnType);
    for (auto &a : ts.genericArgs) subType(a);
    auto it = bindings.find(ts.base);
    if (it != bindings.end()) {
      TypeSpec actual = cloneTypeSpec(it->second);
      if (ts.cat == "list" || ts.cat == "array" || ts.cat == "arraylist" || ts.cat == "hashmap" ||
          ts.cat == "hashset" || ts.cat == "tree" || ts.cat == "graph" || ts.cat == "linked" ||
          ts.cat == "stack" || ts.cat == "queue" || ts.cat == "heap" || ts.cat == "maxheap" ||
          ts.cat == "trie" || ts.cat == "matrix") {
        if (actual.cat == "obj") { ts.elemObj = true; ts.base = actual.base; }
        else { ts.base = actual.base; if (!actual.kind.empty() && (ts.kind.empty() || ts.kind == "var")) ts.kind = actual.kind; }
      } else if (ts.kind == "ptr" && ts.cat.empty()) {
        ts.base = actual.base; if (!actual.cat.empty()) ts.cat = actual.cat;
      } else {
        std::string declaredKind = ts.kind;
        ts = std::move(actual);
        if (!declaredKind.empty() && declaredKind != "var" && (ts.kind.empty() || ts.kind == "var")) ts.kind = declaredKind;
      }
    }
    auto it2 = bindings.find(ts.base2);
    if (it2 != bindings.end()) {
      if (!it2->second.cat.empty()) err("generic hashmap key/value ต้องใช้ type argument ที่ไม่ใช่ obj/struct wrapper", n->line);
      ts.base2 = it2->second.base;
    }
  };
  std::function<void(TypeSpec &)> substituteConstType;
  std::function<void(Node *)> substituteConstExpr = [&](Node *x) {
    if (!x) return;
    if (x->k == NK::Ident) {
      auto value = constBindings.find(x->s);
      if (value != constBindings.end()) {
        x->k = NK::IntLit; x->iv = value->second; x->s.clear();
        x->c.clear(); x->params.clear(); x->members.clear(); x->cases.clear();
        x->deflt.reset(); x->methods.clear();
        return;
      }
    }
    substituteConstType(x->ts);
    substituteConstType(x->parentType);
    for (auto &type : x->implTypeSpecs) substituteConstType(type);
    for (auto &type : x->explicitTypeArgs) substituteConstType(type);
    for (auto &bound : x->genericBounds) {
      if (std::find(x->constGenericParams.begin(), x->constGenericParams.end(), bound.param) == x->constGenericParams.end())
        substituteConstType(bound.bound);
    }
    for (auto &param : x->params) { substituteConstType(param.ts); substituteConstExpr(param.def.get()); }
    for (auto &member : x->members)
      for (auto &payload : member.payloadTypes) substituteConstType(payload);
    for (auto &child : x->c) substituteConstExpr(child.get());
    for (auto &method : x->methods) substituteConstExpr(method.get());
    for (auto &cs : x->cases) {
      for (auto &value : cs.vals) substituteConstExpr(value.get());
      substituteConstExpr(cs.guard.get()); substituteConstExpr(cs.body.get());
      substituteConstExpr(cs.exprBody.get());
    }
    substituteConstExpr(x->deflt.get());
  };
  substituteConstType = [&](TypeSpec &type) {
    substituteConstExpr(type.size.get());
    substituteConstExpr(type.size2.get());
    if (type.constExpr) substituteConstExpr(type.constExpr.get());
    for (auto &arg : type.genericArgs) substituteConstType(arg);
    for (auto &param : type.sig) substituteConstType(param);
    if (type.sigReturnType) substituteConstType(*type.sigReturnType);
  };
  // Replace const parameter identifiers throughout expressions, statements,
  // array dimensions and deferred const arguments before type substitution.
  substituteConstExpr(specializedNode.get());
  std::function<void(Node *)> subNode = [&](Node *x) {
    if (!x) return;
    substituteConstType(x->ts);
    substituteConstType(x->parentType);
    for (auto &type : x->implTypeSpecs) substituteConstType(type);
    for (auto &a : x->explicitTypeArgs) substituteConstType(a);
    for (auto &b : x->genericBounds) {
      if (std::find(x->constGenericParams.begin(), x->constGenericParams.end(), b.param) == x->constGenericParams.end())
        substituteConstType(b.bound);
    }
    subType(x->ts); subType(x->parentType);
    for (auto &a : x->explicitTypeArgs) subType(a);
    for (auto &b : x->genericBounds) {
      if (std::find(x->constGenericParams.begin(), x->constGenericParams.end(), b.param) == x->constGenericParams.end())
        subType(b.bound);
    }
    for (auto &p : x->params) { substituteConstType(p.ts); subType(p.ts); subNode(p.def.get()); }
    for (auto &c : x->c) subNode(c.get());
    for (auto &m : x->methods) subNode(m.get());
    for (auto &cs : x->cases) {
      for (auto &v : cs.vals) subNode(v.get());
      subNode(cs.guard.get()); subNode(cs.body.get()); subNode(cs.exprBody.get());
    }
    subNode(x->deflt.get());
  };
  subNode(specializedNode.get());
  // Substitution may have made dependent generic record arguments concrete.
  // Run the ordinary normalizer in the declaration module so those records
  // enter the same cache/layout checks as source-level concrete instantiations.
  if (normalizeGenericNode) {
    const std::string savedModule = curModule;
    const auto savedImports = curImports;
    curModule = g->module;
    curImports = modImports[curModule];
    normalizeGenericNode(specializedNode.get(), n->line);
    curModule = savedModule;
    curImports = savedImports;
  }
  Node *fn = specializedNode.get();
  FuncInfo inst = *g; inst.node = fn; inst.generic = false; inst.sym = g->sym + "$g" + std::to_string(++ngen);
  inst.pt.clear();
  for (size_t i = 0; i < fn->params.size(); i++) {
    const TypeSpec &ps = fn->params[i].ts; T at = i < ats.size() ? ats[i] : nullptr; T pt;
    if (ps.base == "auto" && (ps.cat.empty() || ps.cat == "func")) {
      if (!at) err("generic: ไม่มี argument ให้อนุมาน type ของ '" + fn->params[i].name + "'", n->line);
      pt = at->k == ARR ? tArr(at->el, -1) : at;
    } else if (ps.base == "auto") {
      if (!at || (at->k != LIST && at->k != ARR)) err("generic: argument '" + fn->params[i].name + "' ต้องเป็น list/array", n->line);
      pt = ps.cat == "list" ? tList(at->el) : tArr(at->el, -1);
    } else {
      pt = resolveType(ps, n->line);
      if (ps.cat.empty() && ps.kind == "ptr") pt = tPtr(baseType(ps.base, n->line));
    }
    inst.pt.push_back(pt);
  }
  if (fn->ts.base == "auto" && fn->ts.cat.empty()) inst.ret = T_auto;
  else if (fn->ts.base == "void" && fn->ts.cat.empty()) inst.ret = T_void;
  else { inst.ret = resolveType(fn->ts, n->line); if (inst.ret->k == ARR) inst.ret = tList(inst.ret->el); }
  genericNodeStorage.push_back(std::move(specializedNode));
  extraFuncs.push_back(inst);
  FuncInfo *ip = &extraFuncs.back();
  genCache[key] = ip;
  emitNested(*ip);
  return ip;
}

V callExtern(FuncInfo &f, const std::vector<Node *> &args, Node *n) {
  size_t np = f.pt.size();
  if (args.size() < np || (!f.cvar && args.size() > np)) err("extern '" + f.name + "' ต้องการ " + std::to_string(np) + (f.cvar ? "+" : "") + " argument แต่ส่งมา " + std::to_string(args.size()), n->line);
  std::string al, tl;
  for (size_t i = 0; i < args.size(); i++) {
    V a = expr(args[i]); borrow(a);
    std::string ty, val;
    auto cstrOf = [&]() { return def("call ptr @fac_cstr(ptr " + (a.t->k == NULLT ? std::string("null") : a.v) + ")"); };
    if (i < np) {
      T pt = f.pt[i];
      if (pt->k == STR || ((pt->k == PTR || pt->k == OPAQUE) && a.t->k == STR)) { if (a.t->k != STR && a.t->k != NULLT) err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น string", n->line); ty = "ptr"; val = cstrOf(); }
      else if (pt->k == ARR) { ty = "ptr"; if (a.t->k == ARR) val = a.v; else if (a.t->k == LIST) val = listField(a.v, 0, "ptr"); else err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น array/list", n->line); }
      else { if (pt->k == ENUM && pt->payloadEnum) err("extern/FFI ไม่รองรับ payload enum", n->line); ty = llty(pt); val = conv(a, pt, n->line); }
      tl += (i ? ", " : "") + (pt->k == STR || pt->k == ARR ? std::string("ptr") : llty(pt));
    } else {  // C variadic: default argument promotion
      switch (a.t->k) {
        case STR: case NULLT: ty = "ptr"; val = cstrOf(); break;
        case F32: case F64: ty = "double"; val = conv(a, T_double); break;
        case INT: if (a.t->bits >= 32) { ty = llty(a.t); val = a.v; } else { ty = "i32"; val = conv(a, T_int); } break;
        case BOOL: case CHAR: case UNI: ty = "i32"; val = conv(a, T_int); break;
        case ENUM: if (a.t->payloadEnum) err("C variadic ไม่รองรับ payload enum", n->line); ty = "i32"; val = conv(a, T_int); break;
        case PTR: case OPAQUE: case FUNC: ty = "ptr"; val = a.v; break;
        case ARR: ty = "ptr"; val = a.v; break;
        default: err("ส่ง " + tname(a.t) + " เป็น argument ของ C variadic ไม่ได้", n->line);
      }
    }
    if (!al.empty()) al += ", ";
    al += ty + " " + val;
  }
  std::string rt = llty(f.ret), sig = f.cvar ? " (" + tl + (tl.empty() ? "" : ", ") + "...)" : "";
  V r; r.t = f.ret;
  if (f.ret->k == VOID) { ins("call void" + sig + " " + f.sym + "(" + al + ")"); return r; }
  r.v = def("call " + rt + sig + " " + f.sym + "(" + al + ")");
  return r;
}

V callUser(FuncInfo &f, const std::vector<Node *> &args0, V *self, Node *n) {
  if (f.isExtern) { requireUnsafe("การเรียก extern function '" + f.name + "' (FFI)", n->line); return callExtern(f, args0, n); }
  if (f.node && f.node->isUnsafe) requireUnsafe("การเรียก unsafe function '" + f.name + "'", n->line);
  size_t np = f.pt.size(), fixed = f.variadic ? np - 1 : np;
  if (args0.size() > np && !f.variadic) err("function '" + f.name + "' ต้องการ " + std::to_string(np) + " argument แต่ส่งมา " + std::to_string(args0.size()), n->line);
  std::vector<Node *> A, extra;
  for (size_t i = 0; i < args0.size(); i++) (i < fixed ? A : extra).push_back(args0[i]);
  bool usedDefault = false;
  for (size_t i = A.size(); i < fixed; i++) {
    Node *d = i < f.pdef.size() ? f.pdef[i] : nullptr;
    if (!d) err("function '" + f.name + "' ต้องการอย่างน้อย " + std::to_string(i + 1) + " argument แต่ส่งมา " + std::to_string(args0.size()), n->line);
    A.push_back(d); usedDefault = true;
  }
  DefaultArgGuard defaultGuard(*this, usedDefault, f.name, n->line);
  std::string al;
  auto add = [&](const std::string &s) { if (!al.empty()) al += ", "; al += s; };
  if (self) add("ptr " + self->v);
  for (size_t i = 0; i < np; i++) {
    T pt = f.pt[i]; Node *an = i < fixed ? A[i] : nullptr;
    if (pt->k == ARR) {
      V a;
      if (i >= fixed) {
        if (extra.size() == 1 && extra[0]->k == NK::InitList) a = makeTempArray(extra[0], pt->el, n->line);
        else if (extra.size() == 1 && (dryType(extra[0])->k == ARR || dryType(extra[0])->k == LIST)) a = expr(extra[0]);
        else a = makeTempArrayN(extra, pt->el, n->line);
      } else a = an->k == NK::InitList ? makeTempArray(an, pt->el, n->line) : expr(an);
      if (a.t->k == ARR) { add("ptr " + a.v); add("i64 " + a.len); }
      else if (a.t->k == LIST) {
        borrow(a); std::string d, l; T el; seqParts(a, d, l, el, n->line); add("ptr " + d); add("i64 " + l);
      } else err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น array/list", n->line);
    } else if (pt->k == STRUCT || (pt->k == ENUM && pt->payloadEnum)) {
      V a = expr(an);
      if (a.t->k != pt->k || a.t->name != pt->name) err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น " + tname(pt), n->line);
      if (f.pref[i]) { borrow(a); add("ptr " + a.v); }
      else if (pt->k == ENUM) {
        borrow(a);
        std::string copy = alloca_(pt);
        ins("store " + llty(pt) + " zeroinitializer, ptr " + copy);
        if (needsFree(pt)) ins("call void @fac_tmp_push_drop(ptr " + copy + ", ptr @drop.enum." + pt->name + ")");
        ins("call void @copy.enum." + pt->name + "(ptr " + copy + ", ptr " + a.v + ")");
        if (needsFree(pt)) ins("call void @fac_tmp_pop(ptr " + copy + ")");
        V copied; copied.t = pt; copied.v = copy; copied.owned = needsFree(pt); borrow(copied);
        add("ptr " + copy);
      }
      else if (a.owned) { borrow(a); add("ptr " + a.v); }
      else {  // by value: ทำสำเนาจริงเสมอ เพื่อให้ callee แก้แล้วไม่กระทบผู้เรียก
        V c; c.t = a.t; c.owned = true; c.v = alloca_(a.t);
        ins("call void @copy." + a.t->name + "(ptr " + c.v + ", ptr " + a.v + ")");
        borrow(c); add("ptr " + c.v);
      }
    } else if (f.pref[i]) {
      LV l = lval(an);
      if (!sameT(l.ty, pt)) err("ref argument ที่ " + std::to_string(i + 1) + " ชนิดไม่ตรง", n->line);
      add("ptr " + l.addr);
    } else {
      if (pt->k == FUNC) lamExpect = pt;
      V a = expr(an); lamExpect = nullptr; borrow(a);
      if (pt->k == STR && a.t->k != STR && a.t->k != NULLT) err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น string", n->line);
      if (pt->k == LIST && a.t->k != LIST && a.t->k != NULLT) err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น list", n->line);
      if (pt->k == FUNC && a.t->k != FUNC && a.t->k != NULLT) err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น function", n->line);
      if (pt->k == DSK && !(a.t->k == DSK && a.t->name == pt->name) && a.t->k != NULLT) err("argument ที่ " + std::to_string(i + 1) + " ต้องเป็น " + pt->name, n->line);
      checkImplicit(a, pt, n->line);
      add(llty(pt) + " " + conv(a, pt, n->line));
    }
  }
  std::string c = "call " + llty(f.ret) + " " + f.sym + "(" + al + ")";
  V r; r.t = f.ret;
  if (f.ret->k == VOID) { ins(c); return r; }
  std::string x = def(c);
  if (f.ret->k == STRUCT || (f.ret->k == ENUM && f.ret->payloadEnum)) { std::string t = alloca_(f.ret); ins("store " + llty(f.ret) + " " + x + ", ptr " + t); r.v = t; r.owned = needsFree(f.ret); }
  else { r.v = x; r.owned = needsFree(f.ret); }
  return r;
}

V invoke(FuncInfo *f, const std::vector<Node *> &args, V *self, Node *n,
         const std::vector<TypeSpec> *explicitTypes = nullptr) {
  if (f->generic) f = instantiate(f, args, n, explicitTypes);
  else if (explicitTypes && !explicitTypes->empty()) err("method ไม่ได้ประกาศ generic type parameter", n->line);
  return callUser(*f, args, self, n);
}

V callFuncValue(const V &fv, const std::vector<Node *> &args, Node *n) {
  if (fv.t->k != FUNC) err("เรียกค่าที่ไม่ใช่ function", n->line);
  FuncInfo fi; fi.name = "(function value)"; fi.ret = fv.t->el; fi.pt = fv.t->ps; fi.pref.assign(fi.pt.size(), false); fi.pnoescape = fv.t->noescape; fi.preadonly = fv.t->readonly;
  fi.sym = def("load ptr, ptr " + fv.v);  // word แรกของ closure = function pointer ; ส่ง closure เป็น env (argument แรก)
  V envv; envv.v = fv.v;
  return callUser(fi, args, &envv, n);
}

void initStructDefaults(const std::string &addr, StructInfo &si, size_t from) {
  ins("store %S." + si.name + " zeroinitializer, ptr " + addr);
  for (size_t i = from; i < si.fields.size(); i++) {
    T ft = si.fields[i].ty;
    std::string p = def("getelementptr inbounds %S." + si.name + ", ptr " + addr + ", i32 0, i32 " + std::to_string(i));
    if (ft->k == LIST) { std::string l = def("call ptr @fac_list_new(i32 " + std::to_string(sizeOf(ft->el)) + ", i32 " + std::to_string(ekOf(ft->el)) + ")"); setListOps(ft->el, l); ins("store ptr " + l + ", ptr " + p); }
    else if (ft->k == DSK) { std::string d = dsNew(ft); ins("store ptr " + d + ", ptr " + p); }
    else if (ft->k == STRUCT) initStructDefaults(p, structInfo(ft->name, curLine), 0);
  }
}

V ctorCall(StructInfo &si, const std::vector<Node *> &args, Node *n) {
  if (args.size() > si.fields.size()) err("struct " + si.name + " มี " + std::to_string(si.fields.size()) + " field แต่ส่งมา " + std::to_string(args.size()), n->line);
  std::string a = alloca_(tStruct(si.name));
  initStructDefaults(a, si, args.size());
  for (size_t i = 0; i < args.size(); i++) {
    T ft = si.fields[i].ty;
    if (ft->k == ARR) {  // array field: ใส่ค่าด้วย {a, b, c}
      if (args[i]->k != NK::InitList) err("field array '" + si.fields[i].name + "' ต้องกำหนดด้วย {...}", n->line);
      if ((int64_t)args[i]->c.size() > ft->n) err("ค่าเริ่มต้นเกินขนาด array ของ field '" + si.fields[i].name + "'", n->line);
      std::string base = def("getelementptr inbounds %S." + si.name + ", ptr " + a + ", i32 0, i32 " + std::to_string(i));
      for (size_t k = 0; k < args[i]->c.size(); k++) {
        V ev = expr(args[i]->c[k].get());
        ins("store " + llty(ft->el) + " " + conv(ev, ft->el, n->line) + ", ptr " + def("getelementptr inbounds " + llty(ft->el) + ", ptr " + base + ", i64 " + std::to_string(k)));
      }
      continue;
    }
    V v = expr(args[i]);
    if (ft->k == STR && v.t->k != STR && v.t->k != NULLT) err("field '" + si.fields[i].name + "' ต้องเป็น string", n->line);
    std::string p = def("getelementptr inbounds %S." + si.name + ", ptr " + a + ", i32 0, i32 " + std::to_string(i));
    storeRaw(p, ft, v);
  }
  V r; r.t = tStruct(si.name); r.v = a; r.owned = true; return r;
}

// ---------------------------------------------------------------- list methods
V listMethod(V ov, const std::string &m, const std::vector<Node *> &args, Node *n) {
  borrow(ov);
  T el = ov.t->el; std::string l = ov.v;
  auto need = [&](size_t k) { if (args.size() != k) err("list." + m + " ต้องการ " + std::to_string(k) + " argument", n->line); };
  auto checkObjElem = [&](const V &v) {   // list ของ obj: ใส่ได้เฉพาะ object ที่เป็นชนิดเดียวกันหรือ implements/extends ชนิดของ element (หรือ null)
    if (v.t->k == NULLT) return;
    if (v.t->k != OBJ || !isSubclass(v.t->name, el->name)) err("list ของ obj " + el->name + " ใส่ค่าชนิด " + tname(v.t) + " ไม่ได้", n->line);
  };
  auto objSlotInsert = [&](const std::string &idx, V val) {   // ใส่ผ่าน fac_list_insert + hook retain (ไม่ retain ซ้ำ)
    checkObjElem(val);
    std::string t = alloca_(el); ins("store ptr " + val.v + ", ptr " + t);
    borrow(val); // register an owned temporary before a retain callback can throw
    ins("call void @fac_list_insert(ptr " + l + ", i64 " + idx + ", ptr " + t + ")");
  };
  if (m == "add") {
    need(1);
    V val = expr(args[0]);
    if (el->k == OBJ) { objSlotInsert(listField(l, 1, "i64"), val); return V(); }
    if (el->k == STR) {
      if (val.t->k != STR) err("list ของ string เพิ่มได้เฉพาะ string", n->line);
      V owned = ownV(val); borrow(owned);
      std::string len = listField(l, 1, "i64"), slot = alloca_(el);
      ins("store ptr " + owned.v + ", ptr " + slot);
      ins("call void @fac_list_insert(ptr " + l + ", i64 " + len + ", ptr " + slot + ")");
      transferTemp(owned); // transfer the owned string into the list slot
      return V();
    }
    if (el->k == STRUCT || (el->k == ENUM && el->payloadEnum && needsFree(el))) {
      if (!sameT(val.t, el)) err("list.add ต้องใช้ " + tname(el), n->line);
      std::string len = listField(l, 1, "i64");
      borrow(val); // ensure source aggregate is unwound if the list copy throws
      ins("call void @fac_list_insert(ptr " + l + ", i64 " + len + ", ptr " + val.v + ")");
      return V();
    }
    std::string len = listField(l, 1, "i64"), cap = listField(l, 2, "i64");
    std::string full = def("icmp eq i64 " + len + ", " + cap);
    std::string g = lbl("grow"), c = lbl("cont");
    cbr(full, g, c, true);
    placeLabel(g); ins("call void @fac_list_grow(ptr " + l + ")"); br(c);
    placeLabel(c);
    std::string data = listField(l, 0, "ptr");
    std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + len);
    storeRaw(p, el, val);
    std::string nl_ = def("add i64 " + len + ", 1");
    std::string lp = def("getelementptr inbounds %FacList, ptr " + l + ", i32 0, i32 1");
    ins("store i64 " + nl_ + ", ptr " + lp);
    return V();
  }
  if (m == "insert") {
    need(2);
    V ix = expr(args[0]); V val = expr(args[1]);
    if (el->k == OBJ) { objSlotInsert(toI64(ix), val); return V(); }
    if (el->k == STRUCT || (el->k == ENUM && el->payloadEnum && needsFree(el))) {
      if (!sameT(val.t, el)) err("list.insert ต้องใช้ " + tname(el), n->line);
      borrow(val); // register the source before the list's managed-field copy can throw
      ins("call void @fac_list_insert(ptr " + l + ", i64 " + toI64(ix) + ", ptr " + val.v + ")");
      return V();
    }
    if (el->k == STR) {
      if (val.t->k != STR) err("list ของ string แทรกได้เฉพาะ string", n->line);
      V owned = ownV(val); borrow(owned);
      std::string t = alloca_(el);
      ins("store ptr " + owned.v + ", ptr " + t);
      ins("call void @fac_list_insert(ptr " + l + ", i64 " + toI64(ix) + ", ptr " + t + ")");
      transferTemp(owned);
      return V();
    }
    std::string t = alloca_(el);
    storeRaw(t, el, val);
    ins("call void @fac_list_insert(ptr " + l + ", i64 " + toI64(ix) + ", ptr " + t + ")");
    return V();
  }
  if (m == "remove") {
    std::string idx = "-1";
    if (args.size() == 1) { V ix = expr(args[0]); idx = toI64(ix); } else need(0);
    ins("call void @fac_list_remove(ptr " + l + ", i64 " + idx + ")");
    return V();
  }
  if (m == "clear") { need(0); ins("call void @fac_list_clear(ptr " + l + ")"); return V(); }
  if (m == "get" || m == "set") {
    need(m == "get" ? 1 : 2);
    V ix = expr(args[0]); std::string idx = toI64(ix);
    std::string data = listField(l, 0, "ptr"), len = listField(l, 1, "i64");
    boundsCheck(idx, len);
    std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + idx);
    if (m == "get") {
      V r; r.t = el;
      if (el->k == STRUCT || (el->k == ENUM && el->payloadEnum)) {
        r.v = alloca_(el);
        ins("call void @" + std::string(el->k == ENUM ? "copy.enum." : "copy.") + el->name + "(ptr " + r.v + ", ptr " + p + ")");
        r.owned = needsFree(el); borrow(r);
      } else r.v = def("load " + llty(el) + ", ptr " + p);
      return r;
    }
    V val = expr(args[1]);
    if (el->k == OBJ) checkObjElem(val);
    storeAssign(p, el, val, true); return V();
  }
  if (m == "size" || m == "length") { need(0); V r; r.t = T_int; r.v = def("trunc i64 " + listField(l, 1, "i64") + " to i32"); return r; }
  if (m == "first" || m == "last") {
    need(0); std::string len = listField(l, 1, "i64");
    std::string empty = def("icmp eq i64 " + len + ", 0");
    std::string bad = lbl("list_empty"), good = lbl("list_nonempty");
    cbr(empty, bad, good, true); placeLabel(bad); ins("call void @fac_throw(ptr " + strLit("list is empty") + ", i32 8)"); ins("unreachable"); placeLabel(good);
    std::string ix = m == "first" ? "0" : def("sub i64 " + len + ", 1");
    std::string data = listField(l, 0, "ptr"); std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + ix);
    V r; r.t = el;
    if (el->k == STRUCT || (el->k == ENUM && el->payloadEnum)) {
      r.v = alloca_(el);
      ins("call void @" + std::string(el->k == ENUM ? "copy.enum." : "copy.") + el->name + "(ptr " + r.v + ", ptr " + p + ")");
      r.owned = needsFree(el); borrow(r);
    } else r.v = def("load " + llty(el) + ", ptr " + p);
    return r;
  }
  if (m == "capacity") { need(0); V r; r.t = T_long; r.v = listField(l, 2, "i64"); return cv(r, T_int); }
  if (m == "reserve") { need(1); V a = expr(args[0]); ins("call void @fac_list_reserve(ptr " + l + ", i64 " + conv(a, T_long) + ")"); return V(); }
  if (m == "shrink") { need(0); ins("call void @fac_list_shrink(ptr " + l + ")"); return V(); }
  if (m == "isEmpty") { need(0); return boolV(def("icmp eq i64 " + listField(l, 1, "i64") + ", 0")); }
  err("list ไม่มี method '" + m + "'", n->line);
}

bool isDirectSuperCall(Node *n) {
  return n && n->k == NK::Call && !n->c.empty() &&
         n->c[0]->k == NK::Ident && n->c[0]->s == "super";
}

size_t countSuperCalls(Node *n) {
  if (!n) return 0;
  size_t count = isDirectSuperCall(n) ? 1 : 0;
  for (auto &c : n->c) count += countSuperCalls(c.get());
  for (auto &cs : n->cases) {
    for (auto &v : cs.vals) count += countSuperCalls(v.get());
    count += countSuperCalls(cs.body.get());
  }
  count += countSuperCalls(n->deflt.get());
  return count;
}

bool constructorHasLeadingSuper(FuncInfo *ctor, int line) {
  if (!ctor || !ctor->node || ctor->node->c.empty()) return false;
  Node *bodyNode = ctor->node->c[0].get();
  bool any = countSuperCalls(bodyNode) != 0;
  if (!any) return false;
  bool first = bodyNode && bodyNode->k == NK::Block && !bodyNode->c.empty() &&
               bodyNode->c[0]->k == NK::ExprStmt &&
               !bodyNode->c[0]->c.empty() &&
               isDirectSuperCall(bodyNode->c[0]->c[0].get());
  if (!first) err("super(...) ต้องเป็นคำสั่งแรกใน constructor", line);
  if (countSuperCalls(bodyNode) != 1) err("constructor เรียก super(...) ได้เพียงครั้งเดียว", line);
  return true;
}

V constructClass(const std::string &inputPath, const std::vector<Node *> &args, Node *n) {
  std::string path = canonicalModulePath(inputPath);
  std::string simple = path; size_t dot = simple.rfind('.');
  std::string ownerModule;
  if (dot != std::string::npos) { ownerModule = simple.substr(0, dot); simple = simple.substr(dot + 1); }
  auto it = structs.find(simple);
  if (it == structs.end() || !it->second.isClass) err("new ต้องตามด้วยชื่อ class ที่รู้จัก: " + inputPath, n->line);
  StructInfo &si = it->second;
  if (si.isInterface) err("new ใช้กับ interface ไม่ได้: " + si.name + " (ต้อง new class ที่ implement มัน)", n->line);
  if (si.isAbstract) err("new ใช้กับ abstract class ไม่ได้: " + si.name, n->line);
  requireTypeAccess(path, si.name, si.module, si.isPublic, n->line);
  if (!si.module.empty() && si.module != curModule && !ownerModule.empty() && ownerModule != si.module)
    err("ชื่อ qualified class ไม่ตรงกับ module: " + inputPath, n->line);
  T objectTy = tObj(si.name);
  std::string ptr = def("call ptr @fac_obj_new(i64 " + std::to_string(sizeOf(tStruct(si.name))) + ", ptr @drop." + si.name + ", ptr @vtbl." + si.name + ", ptr @trace." + si.name + ", ptr @finalize." + si.name + ")");
  std::string tempSlot = alloca_(objectTy);
  ins("store ptr " + ptr + ", ptr " + tempSlot);
  // Keep the new object on the runtime cleanup stack until its constructor completes;
  // a thrown exception therefore releases partially initialized fields/object storage.
  ins("call void @fac_cleanup_push(ptr " + tempSlot + ", i32 6, ptr null)");
  initStructDefaults(ptr, si, 0);
  V self; self.t = tStruct(si.name); self.v = ptr;
  auto ci = si.methods.find("__ctor");
  if (ci != si.methods.end() && (ci->second->isPrivate || ci->second->isProtected) &&
      !canAccessMember(ci->second->structName, ci->second->isPrivate, ci->second->isProtected))
    err("constructor ของ class " + si.name + " ไม่ใช่ public", n->line);
  bool explicitSuper = ci != si.methods.end() && constructorHasLeadingSuper(ci->second, n->line);
  if (!si.parent.empty() && !explicitSuper) {
    StructInfo &parent = structInfo(si.parent, n->line);
    auto pit = parent.methods.find("__ctor");
    if (pit != parent.methods.end()) {
      if (pit->second->isPrivate || (pit->second->isProtected && !isSubclassOf(si.name, parent.name)))
        err("constructor ของ class แม่ " + parent.name + " ไม่มีสิทธิ์ให้ " + si.name + " เรียก", n->line);
      if (!pit->second->pt.empty()) err("class " + si.name + " extends " + parent.name + " ต้องเรียก super(args) เป็นคำสั่งแรกใน constructor", n->line);
      callUser(*pit->second, {}, &self, n);
    }
  }
  if (ci == si.methods.end()) {
    if (!args.empty()) err("class " + si.name + " ไม่มี constructor จึงห้ามส่ง argument", n->line);
  } else callUser(*ci->second, args, &self, n);
  ins("call void @fac_cleanup_pop()");
  V r; r.t = objectTy; r.v = ptr; r.owned = true; return r;
}

// super.method(args): เรียก implementation ของ class แม่โดยตรง (ไม่ผ่าน virtual) บน this -- ใช้ต่อยอดพฤติกรรมของ method ที่ override
V superMethodCall(const std::string &m, const std::vector<Node *> &args, Node *n,
                  const std::vector<TypeSpec> *explicitTypes = nullptr) {
  if (!cf || cf->structName.empty() || cf->isStatic) err("super." + m + "() ใช้ได้เฉพาะใน instance method ของ class", n->line);
  StructInfo &cur = structInfo(cf->structName, n->line);
  if (cur.parent.empty()) err("class " + cur.name + " ไม่มี class แม่สำหรับ super." + m + "()", n->line);
  StructInfo &par = structInfo(cur.parent, n->line);
  auto it = par.methods.find(m);
  if (it == par.methods.end() || it->first == "__ctor") err("class แม่ " + par.name + " ไม่มี method '" + m + "'", n->line);
  FuncInfo *method = it->second;
  if (method->isAbstract) err("super." + m + "() เรียก abstract method ไม่ได้ (ไม่มี implementation)", n->line);
  if (method->isStatic) err("super." + m + "() เป็น static method: เรียกด้วยชื่อ class", n->line);
  if ((method->isPrivate || method->isProtected) && !canAccessMember(method->structName, method->isPrivate, method->isProtected))
    err("method '" + m + "' ไม่มีสิทธิ์เข้าถึงจาก class " + cf->structName, n->line);
  Node thisNode(NK::Ident, n->line); thisNode.s = "self";
  V ov = expr(&thisNode);
  if (ov.t->k == OBJ) ov.t = tStruct(ov.t->name);
  return invoke(method, args, &ov, n, explicitTypes);
}

V methodCall(Node *callee, const std::vector<Node *> &args, Node *n) {
  Node *base = callee->c[0].get(); const std::string &m = callee->s;
  if (base->k == NK::Ident && base->s == "super") return superMethodCall(m, args, n, &callee->explicitTypeArgs);
  V ov = expr(base);
  if (ov.t->k == OBJ) { borrow(ov); ov.t = tStruct(ov.t->name); }
  if (ov.t->k == STRUCT) {
    borrow(ov);
    StructInfo &si = structInfo(ov.t->name, n->line);
    auto it = si.methods.find(m);
    if (it == si.methods.end()) err((si.isClass ? "class " : "struct ") + si.name + " ไม่มี method '" + m + "'", n->line);
    FuncInfo *method = it->second;
    if (method->isStatic) err("static method ต้องเรียกผ่านชื่อ class เช่น " + si.name + "." + m + "()", n->line);
    if ((method->isPrivate || method->isProtected) && !canAccessMember(method->structName, method->isPrivate, method->isProtected))
      err("method '" + m + "' ไม่มีสิทธิ์เข้าถึงจากภายนอก class " + method->structName, n->line);
    // virtual dispatch: method ของ interface/abstract หรือที่ class ลูกหลานประกาศซ้ำ ต้องเลือก implementation จาก vtable ของ "ชนิดจริง" ของ object
    // (ที่เหลือเรียกตรงเหมือนเดิม ไม่มีค่าใช้จ่ายเพิ่ม)
    if (si.isClass && (method->isAbstract || overriddenKeys.count(si.name + "::" + m))) {
      std::string fp = def("call ptr @fac_vcall(ptr " + ov.v + ", i64 " + std::to_string(selectorOf(*method)) + ")");
      FuncInfo vf = *method; vf.sym = fp;
      return callUser(vf, args, &ov, n);
    }
    if (method->generic) return invoke(method, args, &ov, n, &callee->explicitTypeArgs);
    return callUser(*method, args, &ov, n);
  }
  if (ov.t->k == LIST) return listMethod(ov, m, args, n);
  if (ov.t->k == DSK) return dsMethod(ov, m, args, n);
  if (ov.t->k == ENUM && (m == "toString" || m == "toInt")) return enumConv(ov, m == "toString");
  err("ไม่มี method '" + m + "' บน " + tname(ov.t), n->line);
}

// ---------------------------------------------------------------- import/global name resolution
std::string canonicalModulePath(const std::string &path) {
  size_t dot = path.find('.');
  std::string root = path.substr(0, dot);
  auto it = modImportAliases[curModule].find(root);
  if (it == modImportAliases[curModule].end()) return path;
  return it->second + (dot == std::string::npos ? std::string() : path.substr(dot));
}
bool importNameMatches(const std::set<std::string> &names, const std::string &suffix) {
  if (names.count(suffix)) return true;
  size_t d = suffix.rfind('.');
  std::string leaf = d == std::string::npos ? suffix : suffix.substr(d + 1);
  if (names.count(leaf)) return true;
  for (const std::string &name : names) if (suffix.size() > name.size() && suffix.compare(0, name.size(), name) == 0 && suffix[name.size()] == '.') return true;
  return false;
}
bool moduleImportAllows(const std::string &module, const std::string &suffix) {
  if (module == curModule) return true;
  auto ji = modImportJust[curModule].find(module);
  if (ji != modImportJust[curModule].end() && !importNameMatches(ji->second, suffix)) return false;
  auto wi = modImportWithout[curModule].find(module);
  if (wi != modImportWithout[curModule].end() && importNameMatches(wi->second, suffix)) return false;
  return true;
}

// User-defined types follow the same import selection and visibility rules as module functions.
void requireTypeAccess(const std::string &rawPath, const std::string &typeName,
                       const std::string &provider, bool isPublic, int line) {
  if (provider.empty() || provider == curModule) return;
  std::string path = canonicalModulePath(rawPath);
  size_t dot = path.find('.');
  if (dot != std::string::npos && path.substr(0, dot) != provider)
    err("ชื่อ qualified type '" + rawPath + "' ไม่ตรงกับ module " + provider, line);
  if (!curImports.count(provider) && !modGlobalImports[curModule].count(provider))
    err("ต้อง import " + provider + ".fac ก่อนใช้ type " + typeName, line);
  if (!isPublic) err("type '" + typeName + "' เป็น private ของ module " + provider, line);
  std::string importName = typeName;
  auto genericOrigin = genericOrigins.find(typeName);
  if (genericOrigin != genericOrigins.end()) importName = genericOrigin->second;
  if (!moduleImportAllows(provider, importName))
    err("type '" + typeName + "' ถูกจำกัดด้วย just/without ใน import " + provider + ".fac", line);
}

bool isSubclassOf(const std::string &child, const std::string &ancestor) const {
  // Protected-member access follows class inheritance only (not implemented interfaces).
  // A bounded parent walk is equivalent to the former visited-set loop without per-check allocations.
  std::string cur = child;
  size_t remaining = structs.size() + 1;
  while (!cur.empty() && remaining--) {
    auto it = structs.find(cur);
    if (it == structs.end()) break;
    if (cur == ancestor) return true;
    cur = it->second.parent;
  }
  return false;
}
bool canAccessMember(const std::string &owner, bool isPrivate, bool isProtected) const {
  if (!cf || cf->structName.empty()) return false;
  if (cf->structName == owner) return true;
  return !isPrivate && isProtected && isSubclassOf(cf->structName, owner);
}

std::set<std::string> globalRootsFor(const std::string &mod) {
  std::set<std::string> roots;
  for (const BI *b = BTAB; b->q; ++b) {
    std::string q = b->q; size_t d = q.find('.');
    if (d == std::string::npos || q.substr(0, d) != mod) continue;
    std::string suffix = q.substr(d + 1); size_t sub = suffix.find('.');
    roots.insert(suffix.substr(0, sub));
  }
  if (mod == "terminal") roots.insert({"out", "err", "in"});
  if (mod == "math") roots.insert({"abs", "min", "max", "PI", "INF", "NAN", "TAU", "E"});
  if (mod == "random") roots.insert({"shuffle", "choice", "uniform", "weighted", "markov"});
  if (mod == "json") roots.insert({"encode", "decode"});
  if (mod == "memory") roots.insert({"sizeof", "weak", "weakAlive", "weakLock"});
  if (mod == "bit") roots.insert({"count", "get", "set", "clear", "rotl", "rotr"});
  if (mod == "thread") roots.insert("mutex");
  if (userModules.count(mod)) {
    for (FuncInfo *f : allFuncs)
      if (f && f->module == mod && !f->isMethod && f->node && f->node->isPublic) roots.insert(f->name);
    for (Program *p : progs) if (p && p->module == mod)
      for (const auto &g : p->globals) if (g && g->isPublic) roots.insert(g->s);
  }
  return roots;
}

bool globalSuffixExists(const std::string &mod, const std::string &suffix) {
  if (!moduleImportAllows(mod, suffix)) return false;
  if (userModules.count(mod)) {
    std::string key = mod + "." + suffix;
    auto it = funcs.find(key);
    if (it == funcs.end()) return false;
    if (it->second.node && it->second.node->isPublic) return true;
    auto oi = overloads.find(key);
    if (oi != overloads.end()) for (FuncInfo *f : oi->second) if (f->node && f->node->isPublic) return true;
    return false;
  }
  for (const BI *b = BTAB; b->q; ++b) {
    std::string q = b->q; size_t d = q.find('.');
    if (d != std::string::npos && q.substr(0, d) == mod && q.substr(d + 1) == suffix) return true;
  }
  if (mod == "terminal" && (suffix == "out.println" || suffix == "out.print" || suffix == "err.println" || suffix == "err.print" || suffix == "in.readline" || suffix == "in.readLine" || suffix == "in.Scanner" || suffix == "out.answer" || suffix == "out.anwser")) return true;
  if (mod == "math" && (suffix == "abs" || suffix == "min" || suffix == "max")) return true;
  if (mod == "random" && (suffix == "shuffle" || suffix == "choice" || suffix == "uniform" || suffix == "weighted" || suffix == "markov")) return true;
  if (mod == "json" && (suffix == "encode" || suffix == "decode")) return true;
  if (mod == "memory" && (suffix == "sizeof" || suffix == "weak" || suffix == "weakAlive" || suffix == "weakLock")) return true;
  if (mod == "bit" && (suffix == "count" || suffix == "get" || suffix == "set" || suffix == "clear" || suffix == "rotl" || suffix == "rotr")) return true;
  return false;
}

std::vector<std::string> globalCallCandidates(const std::string &suffix) {
  std::vector<std::string> candidates;
  auto it = modGlobalImports.find(curModule);
  if (it == modGlobalImports.end()) return candidates;
  for (const std::string &mod : it->second)
    if (globalSuffixExists(mod, suffix)) candidates.push_back(mod + "." + suffix);
  return candidates;
}

void validateGlobalImportNames(const std::vector<Program *> &ps) {
  static const std::set<std::string> builtinNames = {"addr", "cstr", "cfn", "alloc", "realloc", "free", "type", "typeof", "kindof", "DSof", "size", "sizeof", "strcmp", "cast", "parse", "str", "assert", "sort", "reverse", "find", "fill", "copy"};
  for (Program *p : ps) {
    std::map<std::string, std::string> owners;
    auto bind = [&](const std::string &name, const std::string &origin, int line) {
      auto hit = owners.find(name);
      if (hit != owners.end() && hit->second != origin)
        err("global import ชื่อ '" + name + "' ชนกันระหว่าง " + hit->second + " และ " + origin + " (ใช้ import แบบ as <name> แทน)", line);
      if (builtinNames.count(name))
        err("global import ชื่อ '" + name + "' ชนกับ built-in ของ FAC (ใช้ import แบบ as <name> แทน)", line);
      owners[name] = origin;
    };
    for (const ImportSpec &spec : p->importSpecs) {
      if (spec.global) {
        for (const std::string &name : globalRootsFor(spec.module)) {
          bool selectedRoot = spec.names.count(name) != 0;
          for (const std::string &entry : spec.names)
            if (entry.size() > name.size() && entry.compare(0, name.size(), name) == 0 && entry[name.size()] == '.') selectedRoot = true;
          bool allowed = spec.selection == 0 || (spec.selection == 1 ? selectedRoot : !spec.names.count(name));
          if (allowed) bind(name, spec.module + ".fac global", spec.line);
        }
      }
      if (!spec.alias.empty()) bind(spec.alias, spec.module + ".fac as " + spec.alias, spec.line);
    }
    // Avoid confusing an imported global API with a name declared in the current source module.
    for (const auto &f : p->funcs) {
      if (!f->s.empty() && owners.count(f->s)) err("ชื่อ function '" + f->s + "' ชนกับ import global จาก " + owners[f->s], f->line);
    }
    for (const auto &g : p->globals) {
      if (!g->s.empty() && owners.count(g->s)) err("ชื่อตัวแปร global '" + g->s + "' ชนกับ import global จาก " + owners[g->s], g->line);
    }
    for (const auto &st : p->structs) if (owners.count(st->s)) err("ชื่อ struct '" + st->s + "' ชนกับ import global จาก " + owners[st->s], st->line);
    for (const auto &en : p->enums) if (owners.count(en->s)) err("ชื่อ enum '" + en->s + "' ชนกับ import global จาก " + owners[en->s], en->line);
  }
}

// ---------------------------------------------------------------- module / table calls
V tableCall(const BI &b, const std::vector<Node *> &args, Node *n) {
  std::string params = b.params;
  if (args.size() != params.size()) err(std::string(b.q) + " ต้องการ " + std::to_string(params.size()) + " argument", n->line);
  std::string al; bool args32 = true;
  for (size_t i = 0; i < params.size(); i++) {
    if (params[i] == 'f') lamExpect = tFunc(T_void, {});
    if (params[i] == 'g') lamExpect = tFunc(T_void, {T_int});
    V a = expr(args[i]); lamExpect = nullptr; borrow(a);
    if ((params[i] == 'f' || params[i] == 'g') && std::string(b.q).rfind("thread.", 0) == 0) checkThreadIsolation(b.q, args[i], n);   // --safe: whole-program worker registry + isolation
    if (isIntLike(a.t) && bitsOf(a.t) > 32) args32 = false;
    std::string ty, val;
    switch (params[i]) {
      case 'S': if (a.t->k != STR && a.t->k != NULLT) err(std::string(b.q) + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็น string", n->line); ty = "ptr"; val = a.t->k == NULLT ? "null" : a.v; break;
      case 'L': if (a.t->k != LIST) err(std::string(b.q) + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็น list", n->line); ty = "ptr"; val = a.v; break;
      case 'Y': if (a.t->k != LIST || !sameT(a.t->el, T_int)) err(std::string(b.q) + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็น list dyn int", n->line); ty = "ptr"; val = a.v; break;
      case 'M': if (a.t->k != DSK || a.t->name != "mutex") err(std::string(b.q) + ": ต้องเป็น mutex", n->line); ty = "ptr"; val = a.v; break;
      case 'g': if (a.t->k != FUNC) err(std::string(b.q) + ": ต้องเป็น function(int i)", n->line); ty = "ptr"; val = a.v; break;
      case 'f': if (a.t->k != FUNC) err(std::string(b.q) + ": ต้องเป็น function", n->line); ty = "ptr"; val = a.v; break;
      case 'i': ty = "i32"; val = conv(a, T_int, n->line); break;
      case 'l': ty = "i64"; val = conv(a, T_long, n->line); break;
      case 'd': ty = "double"; val = conv(a, T_double, n->line); break;
      case 'c': ty = "i32"; val = conv(a, T_uni, n->line); break;
      default: ty = "ptr"; val = conv(a, T_opaque, n->line); break;
    }
    if (!al.empty()) al += ", ";
    al += ty + " " + val;
  }
  auto cl = [&](const std::string &rt) { return "call " + rt + " @" + b.sym + "(" + al + ")"; };
  V r;
  switch (b.ret) {
    case 'v': ins(cl("void")); return r;
    case 'i': r.t = T_int; r.v = def(cl("i32")); return r;
    case 'l': r.t = T_long; r.v = def(cl("i64")); return r;
    case 'n': r.t = T_long; r.v = def(cl("i64")); return args32 ? cv(r, T_int) : r;  // random.int: เป็น int ถ้า argument พอดี int
    case 'u': r.t = T_ulong; r.v = def(cl("i64")); return r;
    case 'U': r.t = T_uint; r.v = def(cl("i32")); return r;
    case 'c': r.t = T_uni; r.v = def(cl("i32")); return r;
    case 'd': r.t = T_double; r.v = def(cl("double")); return r;
    case 'b': { std::string x = def(cl("i32")); return boolV(def("icmp ne i32 " + x + ", 0")); }
    case 'S': r.t = T_str; r.owned = true; r.v = def(cl("ptr")); return r;
    case 'B': r.t = tList(T_int); r.owned = true; r.v = def(cl("ptr")); return r;
    case 'L': r.t = tList(T_str); r.owned = true; r.v = def(cl("ptr")); return r;
    default: r.t = tPtr(T_void); r.v = def(cl("ptr")); return r;
  }
}

V mathMinMaxAbs(const std::string &fn, const std::vector<Node *> &args, Node *n) {
  if (fn == "abs") {
    if (args.size() != 1) err("math.abs ต้องการ 1 argument", n->line);
    V a = expr(args[0]); if (!isNum(a.t)) err("math.abs ต้องเป็นตัวเลข", n->line);
    T t = promote(a.t); std::string x = conv(a, t), ty = llty(t);
    if (isFlt(t)) { std::string c = def("fcmp olt " + ty + " " + x + ", 0.0"); std::string ng = def("fneg " + ty + " " + x); V r; r.t = t; r.v = def("select i1 " + c + ", " + ty + " " + ng + ", " + ty + " " + x); return r; }
    std::string c = def("icmp slt " + ty + " " + x + ", 0"); std::string ng = def("sub " + ty + " 0, " + x);
    V r; r.t = t; r.v = def("select i1 " + c + ", " + ty + " " + ng + ", " + ty + " " + x); return r;
  }
  if (args.size() != 2) err("math." + fn + " ต้องการ 2 argument", n->line);
  V a = expr(args[0]), b = expr(args[1]);
  if (!isNum(a.t) || !isNum(b.t)) err("math." + fn + " ต้องเป็นตัวเลข", n->line);
  T t = commonT(a.t, b.t); std::string x = conv(a, t), y = conv(b, t), ty = llty(t), c;
  bool lt = fn == "min";
  if (isFlt(t)) c = def(std::string("fcmp ") + (lt ? "olt " : "ogt ") + ty + " " + x + ", " + y);
  else c = def(std::string("icmp ") + (lt ? (t->sg ? "slt " : "ult ") : (t->sg ? "sgt " : "ugt ")) + ty + " " + x + ", " + y);
  V r; r.t = t; r.v = def("select i1 " + c + ", " + ty + " " + x + ", " + ty + " " + y); return r;
}

V moduleCall(const std::string &inputPath, const std::vector<Node *> &args, Node *n) {
  const std::string path = canonicalModulePath(inputPath);
  size_t dot = path.find('.');
  std::string mod = path.substr(0, dot);
  std::string suffix = path.substr(dot + 1);
  // Some builtin APIs live in a shared source module: char/unichar -> string,
  // mutex -> thread, and mat4 -> math. Validate the actual provider module first.
  std::string need = (mod == "char" || mod == "unichar") ? "string" : mod == "mutex" ? "thread" : mod == "mat4" ? "math" : mod;
  if (!curImports.count(need)) err("ใช้ " + path + " โดยไม่ได้ import " + need + ".fac", n->line);
  if (!moduleImportAllows(need, suffix)) err("ใช้ '" + path + "' ไม่ได้ เพราะถูกจำกัดด้วย just/without ใน import", n->line);
  if (userModules.count(mod)) {
    FuncInfo *pf = pickFunc(path, args, n->line);
    if (!pf) err("module " + mod + " ไม่มี function '" + path.substr(dot + 1) + "'", n->line);
    if (!pf->node->isPublic) err("function '" + path + "' ไม่ใช่ public", n->line);
    return invoke(pf, args, nullptr, n);
  }
  if (path == "terminal.out.println") return printCall(args, true, false, n->line);
  if (path == "terminal.out.print") return printCall(args, false, false, n->line);
  if (path == "terminal.err.println") return printCall(args, true, true, n->line);
  if (path == "terminal.err.print") return printCall(args, false, true, n->line);
  if (path == "terminal.out.answer" || path == "terminal.out.anwser") {
    if (args.size() != 2) err(path + " ต้องการ 2 argument: answer(ข้อความ prompt, Type)", n->line);
    printCall({args[0]}, false, false, n->line);
    if (args[1]->k != NK::Ident || args[1]->s != "String") return scannerCall({args[1]}, n->line);
    V r; r.t = T_str; r.owned = true; r.v = def("call ptr @fac_readline()"); return r;
  }
  if (path == "terminal.in.readline" || path == "terminal.in.readLine") { V r; r.t = T_str; r.owned = true; r.v = def("call ptr @fac_readline()"); return r; }
  if (path == "terminal.in.Scanner") return scannerCall(args, n->line);
  if (path == "math.abs" || path == "math.min" || path == "math.max") return mathMinMaxAbs(path.substr(5), args, n);
  if (path == "random.uniform") {
    if (args.size() != 2) err("random.uniform ต้องการ 2 argument: min, max", n->line);
    V a = expr(args[0]), b = expr(args[1]);
    if (!isNum(a.t) || !isNum(b.t)) err("random.uniform ต้องรับตัวเลขหรือ boolean", n->line);
    borrow(a); borrow(b);
    if (a.t->k == BOOL && b.t->k == BOOL) {
      std::string same = def("icmp eq i8 " + a.v + ", " + b.v);
      std::string pick = def("call i32 @fac_rand_bool()");
      std::string bit = def("trunc i32 " + pick + " to i8");
      V r; r.t = T_bool; r.v = def("select i1 " + same + ", i8 " + a.v + ", i8 " + bit); return r;
    }
    T rt = commonT(a.t, b.t);
    if (isFlt(rt)) {
      std::string lo = conv(a, T_double, n->line), hi = conv(b, T_double, n->line);
      V raw; raw.t = T_double; raw.v = def("call double @fac_rand_uniform_f64(double " + lo + ", double " + hi + ")");
      return cv(raw, rt, n->line);
    }
    if (rt->k != INT) err("random.uniform ใช้ได้กับ integer, unsigned, float, double หรือ boolean", n->line);
    bool uns = !rt->sg;
    T wide = uns ? T_ulong : T_long;
    std::string lo = conv(a, wide, n->line), hi = conv(b, wide, n->line);
    V raw; raw.t = wide;
    raw.v = def(std::string("call i64 @") + (uns ? "fac_rand_uint" : "fac_rand_int") + "(i64 " + lo + ", i64 " + hi + ")");
    return cv(raw, rt, n->line);
  }
  if (path == "random.normal" || path == "random.triangular" || path == "random.exponential") {
    const size_t want = path == "random.triangular" ? 3 : path == "random.exponential" ? 1 : 2;
    if (args.size() != want)
      err(path + (want == 1 ? " ต้องการ 1 argument" : want == 2 ? " ต้องการ 2 argument" : " ต้องการ 3 argument"), n->line);
    std::vector<V> values; values.reserve(args.size());
    for (Node *arg : args) {
      V v = expr(arg);
      if (!isNum(v.t) || v.t->k == BOOL) err(path + " ต้องรับ numeric type (integer/unsigned/float/double) เท่านั้น", n->line);
      borrow(v); values.push_back(v);
    }
    T rt = values[0].t;
    for (size_t i = 1; i < values.size(); ++i) rt = commonT(rt, values[i].t);
    std::string call;
    if (path == "random.normal") {
      call = "call double @fac_rand_normal(double " + conv(values[0], T_double, n->line) + ", double " + conv(values[1], T_double, n->line) + ")";
    } else if (path == "random.triangular") {
      call = "call double @fac_rand_triangular(double " + conv(values[0], T_double, n->line) + ", double " + conv(values[1], T_double, n->line) + ", double " + conv(values[2], T_double, n->line) + ")";
    } else {
      rt = values[0].t;
      call = "call double @fac_rand_exponential(double " + conv(values[0], T_double, n->line) + ")";
    }
    V raw; raw.t = T_double; raw.v = def(call); return cv(raw, rt, n->line);
  }
  if (path == "random.weighted") {
    if (args.size() != 2) err("random.weighted ต้องการ 2 argument: values, weights", n->line);
    V values = expr(args[0]), weights = expr(args[1]); borrow(values); borrow(weights);
    std::string vd, vl, wd, wl; T ve, we;
    seqParts(values, vd, vl, ve, n->line); seqParts(weights, wd, wl, we, n->line);
    auto supported = [](const T &t) { return t->k == BOOL || t->k == INT || t->k == F32 || t->k == F64 || t->k == CHAR || t->k == UNI; };
    if (!supported(ve)) err("random.weighted values ต้องเป็น sequence ของ integer, unsigned, boolean, float หรือ double", n->line);
    if (!supported(we)) err("random.weighted weights ต้องเป็น sequence ของ numeric type", n->line);
    int kind = isFlt(we) ? 1 : 0;
    int bits = we->k == F32 ? 32 : we->k == F64 ? 64 : bitsOf(we);
    int sign = signedOf(we) ? 1 : 0;
    std::string index = def("call i64 @fac_rand_weighted_index(ptr " + wd + ", i64 " + wl + ", i64 " + vl + ", i32 " + std::to_string(kind) + ", i32 " + std::to_string(bits) + ", i32 " + std::to_string(sign) + ")");
    V r; r.t = ve; r.v = def("load " + llty(ve) + ", ptr " + def("getelementptr inbounds " + llty(ve) + ", ptr " + vd + ", i64 " + index)); return r;
  }
  if (path == "random.markov") {
    if (args.size() != 3) err("random.markov ต้องการ 3 argument: currentStateIndex, transitionMatrix, stateCount", n->line);
    V current = expr(args[0]), matrix = expr(args[1]), count = expr(args[2]);
    if (!isIntLike(current.t) || current.t->k == BOOL) err("random.markov currentStateIndex ต้องเป็น integer", n->line);
    if (!isIntLike(count.t) || count.t->k == BOOL) err("random.markov stateCount ต้องเป็น integer", n->line);
    borrow(matrix);
    std::string data, len; T el; seqParts(matrix, data, len, el, n->line);
    if (!(el->k == BOOL || el->k == INT || el->k == F32 || el->k == F64 || el->k == CHAR || el->k == UNI))
      err("random.markov transitionMatrix ต้องเป็น sequence ของ numeric weights", n->line);
    int kind = isFlt(el) ? 1 : 0;
    int bits = el->k == F32 ? 32 : el->k == F64 ? 64 : bitsOf(el);
    int sign = signedOf(el) ? 1 : 0;
    std::string cur = conv(current, T_long, n->line), nstates = conv(count, T_long, n->line);
    V r; r.t = T_long;
    r.v = def("call i64 @fac_rand_markov_index(ptr " + data + ", i64 " + len + ", i64 " + cur + ", i64 " + nstates + ", i32 " + std::to_string(kind) + ", i32 " + std::to_string(bits) + ", i32 " + std::to_string(sign) + ")");
    return r;
  }
  if (path == "random.shuffle" || path == "random.choice") {
    if (args.size() != 1) err(path + " ต้องการ 1 argument", n->line);
    V a = expr(args[0]); borrow(a); std::string d, l; T el; seqParts(a, d, l, el, n->line);
    if (path == "random.shuffle") { ins("call void @fac_shuffle(ptr " + d + ", i64 " + l + ", i32 " + std::to_string(sizeOf(el)) + ")"); return V(); }
    std::string ix = def("call i64 @fac_rand_index(i64 " + l + ")");
    V r; r.t = el; r.v = def("load " + llty(el) + ", ptr " + def("getelementptr inbounds " + llty(el) + ", ptr " + d + ", i64 " + ix)); return r;
  }
  if (mod == "mat4") return mat4Call(path.substr(5), args, n);
  if (mod == "math" && !args.empty() && args[0]->k != NK::StrLit) {
    static const std::set<std::string> vf = {"dot", "cross", "length", "lengthSq", "distance", "normalize", "lerp", "reflect"};
    std::string fnm = path.substr(5);
    if (vf.count(fnm) && isVecT(dryType(args[0]))) return vecFunc(fnm, args, n);
  }
  if (mod == "bit") return bitCall(path.substr(4), args, n);
  if (path == "json.encode") return jsonEncode(args, n);
  if (path == "json.decode") return jsonDecode(args, n);
  if (path == "memory.weak") {
    if (args.size() != 1) err("memory.weak ต้องการ 1 argument", n->line);
    V a = expr(args[0]);
    if (a.t->k != OBJ) err("memory.weak ต้องรับ obj Class เท่านั้น", n->line);
    borrow(a);
    V r; r.t = tWeak(a.t); r.v = def("call ptr @fac_obj_weak(ptr " + a.v + ")"); r.owned = true; return r;
  }
  if (path == "memory.weakAlive") {
    if (args.size() != 1) err("memory.weakAlive ต้องการ 1 argument", n->line);
    V a = expr(args[0]);
    if (a.t->k != WEAK) err("memory.weakAlive ต้องรับ weak obj Class", n->line);
    borrow(a);
    std::string alive = def("call i32 @fac_obj_weak_alive(ptr " + a.v + ")");
    return boolV(def("icmp ne i32 " + alive + ", 0"));
  }
  if (path == "memory.weakLock") {
    if (args.size() != 1) err("memory.weakLock ต้องการ 1 argument", n->line);
    V a = expr(args[0]);
    if (a.t->k != WEAK) err("memory.weakLock ต้องรับ weak obj Class", n->line);
    borrow(a);
    V r; r.t = tObj(a.t->name); r.v = def("call ptr @fac_obj_weak_lock(ptr " + a.v + ")"); r.owned = true; return r;
  }
  if (path == "memory.sizeof") {
    if (args.size() != 1) err("memory.sizeof ต้องการ 1 argument", n->line);
    V a = expr(args[0]);
    if (a.t->k == ARR) { std::string x = def("mul i64 " + a.len + ", " + std::to_string(sizeOf(a.t->el))); V r; r.t = T_long; r.v = x; return cv(r, T_int); }
    return constInt(sizeOf(a.t));
  }
  bool nameFound = false;
  for (const BI *b = BTAB; b->q; b++) if (path == b->q) { nameFound = true; if (strlen(b->params) == args.size()) return tableCall(*b, args, n); }
  if (nameFound) err(path + " ใช้จำนวน argument ไม่ตรง", n->line);
  err("ไม่รู้จัก '" + path + "'", n->line);
}

// ---------------------------------------------------------------- built-ins (ไม่ต้อง import)
V strOf(V a, int line) {  // แปลง string / char[] / unichar[] เป็น FacStr* (borrowed)
  if (a.t->k == STR) { borrow(a); return a; }
  if (a.t->k == ARR && (a.t->el->k == CHAR || a.t->el->k == UNI)) {
    V r; r.t = T_str; r.owned = true;
    r.v = def(std::string("call ptr @") + (a.t->el->k == CHAR ? "fac_str_from_chars" : "fac_str_from_unichars") + "(ptr " + a.v + ", i64 " + a.len + ")");
    borrow(r); return r;
  }
  err("ต้องเป็น string หรือ array ของ char/unichar", line);
}

bool builtinFree(const std::string &name, const std::vector<Node *> &args, Node *n, V &out) {
  int line = n->line;
  auto need = [&](size_t k) { if (args.size() != k) err(name + " ต้องการ " + std::to_string(k) + " argument", line); };
  if (name == "addr") {  // address ของตัวแปร/สมาชิก ส่งให้ C
    need(1);
    if (args[0]->k == NK::Ident) { Var *v = findVar(args[0]->s); if (v && v->ty->k == ARR) { out.t = tPtr(v->ty->el); out.v = varAddr(*v); return true; } }
    LV l = lval(args[0]); out.t = tPtr(l.ty); out.v = l.addr; return true;
  }
  if (name == "cstr") {  // char* -> string (copy)
    need(1); V a = expr(args[0]);
    if (a.t->k != PTR && a.t->k != OPAQUE) err("cstr(ptr char)", line);
    out.t = T_str; out.owned = true; out.v = def("call ptr @fac_cstr_new(ptr " + a.v + ")"); return true;
  }
  if (name == "cfn") {  // function pointer ดิบสำหรับ callback ของ C (function ธรรมดาที่ parameter เข้ากับ C ได้)
    need(1);
    if (args[0]->k != NK::Ident) err("cfn(ชื่อ function)", line);
    auto it = funcs.find(curModule + "." + args[0]->s);
    if (it == funcs.end() || it->second.generic || overloads.count(it->first)) err("cfn: ไม่พบ function '" + args[0]->s + "' (ต้องไม่ใช่ generic/overload)", line);
    out.t = tPtr(T_void); out.v = it->second.sym; return true;
  }
  if (name == "alloc") {
    requireUnsafe("alloc(...)", line);
    need(1); V a = expr(args[0]); borrow(a);
    out.t = tPtr(T_void); out.v = def("call ptr @fac_alloc(i64 " + conv(a, T_long, line) + ")"); return true;
  }
  if (name == "realloc") {
    requireUnsafe("realloc(...)", line);
    need(2); V p = expr(args[0]); V sz = expr(args[1]);
    out.t = p.t; out.v = def("call ptr @fac_realloc(ptr " + conv(p, T_opaque, line) + ", i64 " + conv(sz, T_long, line) + ")"); return true;
  }
  if (name == "free") {
    for (Node *a : args) {
      if (a->k != NK::Ident) err("free(...) ต้องเป็นชื่อตัวแปร", line);
      Var *v = findVar(a->s); if (!v) err("ไม่รู้จักตัวแปร '" + a->s + "'", line);
      if (v->ty->k == ARR) {
        if (v->kind == "var") err("array var อยู่บน stack ไม่ต้อง free", line);
        requireUnsafe("free(" + a->s + ") ของ heap array", line);
        ins("call void @fac_free(ptr " + varAddr(*v) + ")");
      } else if (v->ty->k == STR || v->ty->k == LIST || v->ty->k == DSK) {
        std::string x = def("load ptr, ptr " + v->slot); freeVal(v->ty, x); ins("store ptr null, ptr " + v->slot);
      } else if (v->ty->k == PTR || v->ty->k == OPAQUE) {
        requireUnsafe("free(" + a->s + ") ของ ptr ดิบ", line);
        std::string x = def("load ptr, ptr " + v->slot); ins("call void @fac_free(ptr " + x + ")"); ins("store ptr null, ptr " + v->slot);
      } else if (v->indirect) {
        requireUnsafe("free(" + a->s + ") ของ heap variable", line);
        std::string x = def("load ptr, ptr " + v->slot); ins("call void @fac_free(ptr " + x + ")"); ins("store ptr null, ptr " + v->slot);
      } else err("free(" + a->s + "): ตัวแปรนี้ไม่ใช่ ptr/heap (var/dyn ตายเองเมื่อจบ scope)", line);
    }
    return true;
  }
  if (name == "type") {
    need(1); Node *a = args[0];
    if (a->k == NK::Ident) { T t = typeFromName(a->s); if (!t) err("type(" + a->s + "): ไม่รู้จัก type", line); out = constInt(sizeOf(t)); return true; }
    if (a->k == NK::Call && a->c[0]->k == NK::Ident && a->c[0]->s == "typeof" && a->c.size() == 2) {
      T t = dryExpr(a->c[1].get()).t;
      if (t->k == ARR || t->k == PTR || t->k == LIST) t = t->el;
      out = constInt(sizeOf(t)); return true;
    }
    err("type(...) ต้องเป็นชื่อ type เช่น type(Int)", line);
  }
  if (name == "typeof") {
    need(1); T t = dryExpr(args[0]).t;
    if (t->k == ARR || t->k == LIST) t = t->el;
    std::string nm;
    switch (t->k) {
      case INT: nm = tname(t); nm[0] = (char)toupper(nm[0]); break;
      case F32: nm = "Float"; break; case F64: nm = "Double"; break; case BOOL: nm = "Boolean"; break; case CHAR: nm = "Char"; break;
      case UNI: nm = "Unichar"; break; case STR: nm = "String"; break; case STRUCT: nm = "Struct"; break; case ENUM: nm = "Enum"; break;
      case PTR: case OPAQUE: nm = "Ptr"; break; default: nm = "None";
    }
    out = enumV("Type", nm); return true;
  }
  if (name == "kindof") {
    need(1);
    if (args[0]->k != NK::Ident) err("kindof(ตัวแปร)", line);
    Var *v = findVar(args[0]->s); if (!v) err("ไม่รู้จักตัวแปร '" + args[0]->s + "'", line);
    std::string k = v->kind; if (k.empty()) k = "var"; k[0] = (char)toupper(k[0]);
    out = enumV("Kind", k); return true;
  }
  if (name == "DSof") {
    need(1); T t = dryExpr(args[0]).t;
    std::string d = t->k == ARR ? "Array" : t->k == LIST ? (t->name == "arraylist" ? "Arraylist" : "List") : t->k == DSK ?
      (t->name == "linked" ? "Linked" : t->name == "hashmap" ? "Hashmap" : t->name == "hashset" ? "Hashset" :
       t->name == "graph" ? "Graph" : t->name == "tree" ? "Tree" : t->name == "stack" ? "Stack" :
       t->name == "queue" ? "Queue" : t->name == "heap" ? "Heap" : t->name == "maxheap" ? "Maxheap" :
       t->name == "trie" ? "Trie" : t->name == "matrix" ? "Matrix" : "None") : t->k == STRUCT ? "Struct" : t->k == ENUM ? "Enum" : "None";
    out = enumV("DS", d); return true;
  }
  if (name == "size" || name == "sizeof") {
    need(1); V a = expr(args[0]); borrow(a);
    if (a.t->k == ARR) { if (isLit(a.len)) out = constInt(atoll(a.len.c_str())); else { V r; r.t = T_long; r.v = a.len; out = cv(r, T_int); } return true; }
    if (a.t->k == LIST) { V r; r.t = T_long; r.v = listField(a.v, 1, "i64"); out = cv(r, T_int); return true; }
    if (a.t->k == DSK) { V r; r.t = T_long; r.v = def("call i64 @fac_ds_len(ptr " + a.v + ")"); out = cv(r, T_int); return true; }
    if (a.t->k == STR) { out.t = T_int; out.v = def("call i32 @fac_str_len(ptr " + a.v + ")"); return true; }
    err("sizeof ใช้กับ array/list/data structure/string เท่านั้น", line);
  }
  if (name == "strcmp") {
    need(2); V a = strOf(expr(args[0]), line), b = strOf(expr(args[1]), line);
    out.t = T_int; out.v = def("call i32 @fac_str_cmp(ptr " + a.v + ", ptr " + b.v + ")"); return true;
  }
  if (name == "cast") {
    need(2); if (args[0]->k != NK::Ident) err("cast(Type, v)", line);
    { auto ci = structs.find(args[0]->s);
      if (ci != structs.end() && ci->second.isClass) {   // cast(Class, obj): downcast แบบตรวจชนิดตอนรัน (ไม่ตรง -> throw Error code 7; null ผ่านเป็น null)
        const std::string tn = ci->second.name;
        V a = expr(args[1]); if (a.t->k != OBJ && a.t->k != NULLT) err("cast(" + tn + ", v): v ต้องเป็น obj", line);
        borrow(a);
        out = a; out.owned = false; out.t = tObj(tn);
        if (a.t->k == NULLT || isSubclass(a.t->name, tn)) return true;   // upcast / null ไม่ต้องตรวจ
        std::string isnull = def("icmp eq ptr " + a.v + ", null");
        std::string ok = def("or i1 " + isnull + ", " + vtblMatch(a.v, concreteSubtypes(tn)));
        std::string good = lbl("cast.ok"), bad = lbl("cast.fail");
        cbr(ok, good, bad, false);
        placeLabel(bad); ins("call void @fac_cast_fail(ptr " + strLit(tn) + ")"); ins("unreachable"); term = true;
        placeLabel(good);
        return true;
      } }
    T t = typeFromName(args[0]->s); if (!t) err("cast: ไม่รู้จัก type '" + args[0]->s + "'", line);
    V a = expr(args[1]); borrow(a); out = cv(a, t, line); out.owned = false; return true;
  }
  if (name == "parse") {
    need(2); if (args[0]->k != NK::Ident) err("parse(Type, s)", line);
    T t = typeFromName(args[0]->s); if (!t) err("parse: ไม่รู้จัก type '" + args[0]->s + "'", line);
    V s = strOf(expr(args[1]), line);
    if (isFlt(t)) { V x; x.t = T_double; x.v = def("call double @fac_parse_f64(ptr " + s.v + ")"); out = cv(x, t); return true; }
    if (t->k == BOOL) { V x; x.t = T_int; x.v = def("call i32 @fac_parse_bool(ptr " + s.v + ")"); out = cv(x, T_bool); return true; }
    if (t->k == INT) { V x; x.t = T_long; x.v = def("call i64 @fac_parse_i64(ptr " + s.v + ")"); out = cv(x, t); return true; }
    err("parse ไม่รองรับ type " + args[0]->s, line);
  }
  if (name == "str") {
    need(1); V a = expr(args[0]);
    out.t = T_str; out.owned = true;
    if (isVecT(a.t)) { out.v = def("call ptr @fac_vec_str(ptr " + a.v + ", i32 " + std::to_string(vecN(a.t->name)) + ")"); return true; }
    if (isMatT(a.t)) { out.v = def("call ptr @fac_mat4_str(ptr " + a.v + ")"); return true; }
    switch (a.t->k) {
      case INT: out.v = a.t->sg ? def("call ptr @fac_str_from_i64(i64 " + conv(a, T_long) + ")") : def("call ptr @fac_str_from_u64(i64 " + conv(a, T_ulong) + ")"); break;
      case BOOL: out.v = def("call ptr @fac_str_from_bool(i32 " + def("zext i8 " + a.v + " to i32") + ")"); break;
      case CHAR: case UNI: out.v = def("call ptr @fac_str_from_char(i32 " + conv(a, T_uni) + ")"); break;
      case F32: out.v = def("call ptr @fac_str_from_f32(float " + a.v + ")"); break;
      case F64: out.v = def("call ptr @fac_str_from_f64(double " + a.v + ")"); break;
      case ENUM: { V s = enumConv(a, true); out = ownV(s); break; }
      case STR: out = ownV(a); break;
      default: err("str() ไม่รองรับ " + tname(a.t), line);
    }
    return true;
  }
  if (name == "assert") {
    if (args.size() < 1 || args.size() > 2) err("assert(cond, msg)", line);
    V c = expr(args[0]); std::string cd = condOf(c);
    V m; if (args.size() == 2) m = expr(args[1]); else { m.t = T_str; m.v = strLit("assertion failed"); }
    borrow(m);
    std::string ok = lbl("assert.ok"), bad = lbl("assert.fail");
    cbr(cd, ok, bad, true);
    placeLabel(bad); ins("call void @fac_assert_fail(ptr " + m.v + ")"); ins("unreachable"); term = true;
    placeLabel(ok);
    return true;
  }
  if (name == "sort" || name == "reverse" || name == "find" || name == "fill" || name == "copy") {
    if (args.empty()) err(name + " ต้องการ argument", line);
    V a = expr(args[0]); borrow(a);
    if (name == "copy" && a.t->k == DSK) { out.t = a.t; out.owned = true; out.v = def("call ptr @fac_ds_copy(ptr " + a.v + ")"); return true; }
    std::string d, l; T el; seqParts(a, d, l, el, line);
    std::string esz = std::to_string(sizeOf(el));
    if (name == "sort" && args.size() == 2) {  // sort(xs, function int cmp(T a, T b)) : เรียงแบบคงลำดับเดิม (stable)
      lamExpect = tFunc(T_int, {el, el});
      V cmp = expr(args[1]); lamExpect = nullptr; borrow(cmp);
      if (cmp.t->k != FUNC || cmp.t->ps.size() != 2) err("sort: ตัวเปรียบเทียบต้องเป็น function ที่รับ 2 argument", line);
      if (!(isIntLike(cmp.t->el) && cmp.t->el->k != BOOL)) err("sort: ตัวเปรียบเทียบต้องคืน int (ลบ = น้อยกว่า, 0 = เท่ากัน, บวก = มากกว่า)", line);
      std::string w = "@cmpw." + std::to_string(++ngen), lt = llty(el), cvt = cmp.t->ps[0]->k == STRUCT ? "ptr" : llty(cmp.t->ps[0]);
      std::string va = el->k == STRUCT ? "%a" : "%va", vb = el->k == STRUCT ? "%b" : "%vb";
      std::string wd = "define internal i32 @" + w.substr(1) + "(ptr %ctx, ptr %a, ptr %b) nounwind {\nentry:\n";
      if (el->k != STRUCT) wd += "  %va = load " + lt + ", ptr %a\n  %vb = load " + lt + ", ptr %b\n";
      wd += "  %fn = load ptr, ptr %ctx\n  %r = call " + llty(cmp.t->el) + " %fn(ptr %ctx, " + cvt + " " + va + ", " + cvt + " " + vb + ")\n";
      int rb = bitsOf(cmp.t->el);
      if (rb == 32) wd += "  ret i32 %r\n}\n\n";
      else if (rb > 32) wd += "  %s = icmp sgt i64 %r, 0\n  %q = icmp slt i64 %r, 0\n  %s1 = zext i1 %s to i32\n  %q1 = zext i1 %q to i32\n  %o = sub i32 %s1, %q1\n  ret i32 %o\n}\n\n";
      else wd += "  %o = sext " + llty(cmp.t->el) + " %r to i32\n  ret i32 %o\n}\n\n";
      globals += wd;
      ins("call void @fac_sort_cmp(ptr " + d + ", i64 " + l + ", i64 " + esz + ", ptr " + cmp.v + ", ptr @" + w.substr(1) + ")");
      return true;
    }
    if (name == "sort") {
      need(1);
      if (args.size() != 1) err("sort รับได้ 1 argument หรือ 2 argument เมื่อระบุตัวเปรียบเทียบ", line);
      if (!(el->k == INT || el->k == F32 || el->k == F64 || el->k == BOOL || el->k == CHAR || el->k == UNI || el->k == STR || el->k == ENUM))
        err("sort แบบไม่ระบุตัวเปรียบเทียบรองรับเฉพาะชนิดพื้นฐาน; ชนิดที่กำหนดเองให้ส่ง comparator", line);
      ins("call void @fac_sort(ptr " + d + ", i64 " + l + ", i32 " + std::to_string(tcode(el)) + ")"); return true;
    }
    if (name == "reverse") { need(1); ins("call void @fac_reverse(ptr " + d + ", i64 " + l + ", i32 " + esz + ")"); return true; }
    if (name == "copy") {
      need(1); out.t = tList(el); out.owned = true;
      out.v = def("call ptr @fac_list_from(ptr " + d + ", i64 " + l + ", i32 " + esz + ", i32 " + std::to_string(ekOf(el)) + ")"); return true;
    }
    need(2); V v = expr(args[1]);
    std::string t = alloca_(el); storeRaw(t, el, v);
    if (name == "find") {
      if (!(el->k == INT || el->k == F32 || el->k == F64 || el->k == BOOL || el->k == CHAR || el->k == UNI || el->k == STR || el->k == ENUM))
        err("find รองรับเฉพาะชนิดพื้นฐานและ string", line);
      borrow(v); out.t = T_int; out.v = def("call i32 @fac_find(ptr " + d + ", i64 " + l + ", i32 " + esz + ", i32 " + std::to_string(tcode(el)) + ", ptr " + t + ")"); return true;
    }
    if (containsManagedValue(el)) err("fill รองรับเฉพาะชนิดที่คัดลอก byte ได้โดยไม่มี ownership", line);
    ins("call void @fac_fill(ptr " + d + ", i64 " + l + ", i32 " + esz + ", ptr " + t + ")"); return true;
  }
  return false;
}

bool tryImportedTypeCall(const std::string &inputPath, const std::vector<Node *> &args, Node *n, V &out) {
  std::string path = canonicalModulePath(inputPath);
  size_t dot = path.find('.'); if (dot == std::string::npos) return false;
  std::string module = path.substr(0, dot), typeName = path.substr(path.rfind('.') + 1);
  if (!userModules.count(module) || !structs.count(typeName)) return false;
  StructInfo &si = structs[typeName];
  if (si.module != module) return false;
  requireTypeAccess(path, typeName, si.module, si.isPublic, n->line);
  if (si.isClass) err("สร้าง class ต้องใช้ new " + path + "(...)", n->line);
  out = ctorCall(si, args, n); return true;
}

bool tryStaticClassCall(const std::string &inputPath, const std::vector<Node *> &args, Node *n, V &out,
                        const std::vector<TypeSpec> *explicitTypes = nullptr) {
  std::string path = canonicalModulePath(inputPath);
  std::vector<std::string> parts; std::string part;
  for (char ch : path) { if (ch == '.') { if (!part.empty()) parts.push_back(part); part.clear(); } else part += ch; }
  if (!part.empty()) parts.push_back(part);
  std::string className, methodName, module;
  if (parts.size() == 2 && structs.count(parts[0]) && structs[parts[0]].isClass) {
    className = parts[0]; methodName = parts[1]; module = structs[className].module;
  } else if (parts.size() >= 3 && userModules.count(parts[0])) {
    module = parts[0]; className = parts[1]; methodName = parts[2];
    if (!structs.count(className) || !structs[className].isClass || structs[className].module != module) return false;
    if (parts.size() != 3) return false;
  } else return false;
  StructInfo &si = structs[className];
  if (si.module != curModule) {
    if (!curImports.count(si.module) && !modGlobalImports[curModule].count(si.module)) return false;
    requireTypeAccess(path, className, si.module, si.isPublic, n->line);
  }
  auto it = si.methods.find(methodName); if (it == si.methods.end() || !it->second->isStatic) return false;
  if ((it->second->isPrivate || it->second->isProtected) && !canAccessMember(it->second->structName, it->second->isPrivate, it->second->isProtected))
    err("static method '" + methodName + "' ไม่มีสิทธิ์เข้าถึงจากภายนอก class " + it->second->structName, n->line);
  out = invoke(it->second, args, nullptr, n, explicitTypes); return true;
}

V callExpr(Node *n) {
  Node *callee = n->c[0].get();
  std::vector<Node *> args;
  for (size_t i = 1; i < n->c.size(); i++) args.push_back(n->c[i].get());
  curLine = n->line;
  if (callee->k == NK::Member) {
    std::string root = rootIdent(callee), path;
    flatten(callee, path);
    V staticResult;
    if (tryEnumVariantCall(path, args, n, staticResult)) return staticResult;
    if (tryStaticClassCall(path, args, n, staticResult, &callee->explicitTypeArgs)) return staticResult;
    if (tryImportedTypeCall(path, args, n, staticResult)) return staticResult;
    if (!root.empty() && isModuleName(root)) return moduleCall(canonicalModulePath(path), args, n);
    // In global import mode, keep nested API roots such as out.println and in.readline.
    std::vector<std::string> candidates = globalCallCandidates(path);
    if (candidates.size() > 1) {
      std::string msg = "เรียก '" + path + "' กำกวมจาก global import: ";
      for (size_t i = 0; i < candidates.size(); i++) msg += (i ? ", " : "") + candidates[i];
      err(msg + " (ใช้ import แบบ as <name> แทน)", n->line);
    }
    if (candidates.size() == 1) return moduleCall(candidates[0], args, n);

    // A callable aggregate field is a function value stored in the receiver,
    // not an instance method. Resolve the receiver's static aggregate type and
    // dispatch through the normal closure ABI when the named field is FUNC.
    // Keep ordinary method resolution unchanged for every other member call.
    if (callee->c.size() == 1 && callee->c[0] &&
        !(callee->c[0]->k == NK::Ident && callee->c[0]->s == "super")) {
      V receiverType = dryExpr(callee->c[0].get());
      T aggregate = receiverType.t;
      if (aggregate && (aggregate->k == STRUCT || aggregate->k == OBJ)) {
        StructInfo &si = structInfo(aggregate->name, n->line);
        auto field = std::find_if(si.fields.begin(), si.fields.end(), [&](const FieldInfo &candidate) {
          return candidate.name == callee->s;
        });
        if (field != si.fields.end() && field->ty && field->ty->k == FUNC) {
          V functionValue = memberExpr(callee);
          return callFuncValue(functionValue, args, n);
        }
      }
    }
    return methodCall(callee, args, n);
  }
  if (callee->k == NK::Ident) {
    const std::string &name = callee->s;
    if (name == "super") {
      if (!cf || !cf->isConstructor || cf->structName.empty())
        err("super(...) ใช้ได้เฉพาะใน constructor ของ class ลูก", n->line);
      StructInfo &child = structInfo(cf->structName, n->line);
      if (child.parent.empty()) err("class " + child.name + " ไม่มี parent ให้เรียก super(...)", n->line);
      StructInfo &parent = structInfo(child.parent, n->line);
      auto pit = parent.methods.find("__ctor");
      if (pit == parent.methods.end()) {
        if (!args.empty()) err("parent class " + parent.name + " ไม่มี constructor ที่รับ argument", n->line);
        return V();
      }
      if (pit->second->isPrivate) err("constructor ของ class แม่ " + parent.name + " เป็น private", n->line);
      Var *selfVar = findVar("self");
      if (!selfVar) err("ภายใน compiler: ไม่พบ receiver ของ constructor", n->line);
      V self; self.t = tStruct(cf->structName); self.v = selfVar->slot;
      return callUser(*pit->second, args, &self, n);
    }
    Var *fvar = findVar(name);
    if (fvar && fvar->ty->k == FUNC) return callFuncValue(identExpr(callee), args, n);
    FuncInfo *pf = pickFunc(curModule + "." + name, args, n->line);
    if (pf) return invoke(pf, args, nullptr, n,
                          callee->explicitTypeArgs.empty() ? nullptr : &callee->explicitTypeArgs);
    if (isVecName(name) && structs.count(name) && !structs[name].isClass && structs[name].fields.size() == (size_t)vecN(name)) return vecCtor(name, args, n);
    if (structs.count(name)) {
      if (structs[name].isClass) err("สร้าง object ของ class ต้องใช้ new " + name + "(...)", n->line);
      return ctorCall(structs[name], args, n);
    }
    V r;
    if (builtinFree(name, args, n, r)) return r;
    std::vector<std::string> candidates = globalCallCandidates(name);
    if (candidates.size() > 1) {
      std::string msg = "เรียก '" + name + "' กำกวมจาก global import: ";
      for (size_t i = 0; i < candidates.size(); i++) msg += (i ? ", " : "") + candidates[i];
      err(msg + " (ใช้ import แบบ as <name> แทน)", n->line);
    }
    if (candidates.size() == 1) return moduleCall(candidates[0], args, n);
    err("ไม่รู้จัก function '" + name + "'", n->line);
  }
  err("เรียก function แบบนี้ไม่ได้", n->line);
}
