// ---- (included inside class Gen) statements, functions, module assembly ----
std::string funcOut, helperOut;
std::set<std::string> enumBoxDropWrappersEmitted;

void brLoop(const std::string &l) {
  int id = 10 + (++nloop);
  loopMd += "!" + std::to_string(id) + " = distinct !{!" + std::to_string(id) + ", !2}\n";
  ins("br label %" + l + ", !llvm.loop !" + std::to_string(id));
  term = true;
}

void listPush(const std::string &l, const T &el, const V &val) {
  if (el->k == STRUCT || (el->k == ENUM && el->payloadEnum && needsFree(el))) {
    std::string len = listField(l, 1, "i64");
    borrow(val); // protect an owned aggregate if its copy callback throws
    ins("call void @fac_list_insert(ptr " + l + ", i64 " + len + ", ptr " + val.v + ")");
    return;
  }
  if (el->k == STR) {
    V owned = ownV(val); borrow(owned);
    std::string len = listField(l, 1, "i64"), slot = alloca_(el);
    ins("store ptr " + owned.v + ", ptr " + slot);
    ins("call void @fac_list_insert(ptr " + l + ", i64 " + len + ", ptr " + slot + ")");
    transferTemp(owned); // list now owns this reference
    return;
  }
  if (el->k == OBJ) {
    if (val.t->k != NULLT && (val.t->k != OBJ || !isSubclass(val.t->name, el->name)))
      err("list ของ obj " + el->name + " ใส่ค่าชนิด " + tname(val.t) + " ไม่ได้");
    std::string len = listField(l, 1, "i64"), slot = alloca_(el);
    ins("store ptr " + val.v + ", ptr " + slot);
    borrow(val); // list copy retains the object; protect an owned source if retain fails
    ins("call void @fac_list_insert(ptr " + l + ", i64 " + len + ", ptr " + slot + ")");
    return;
  }
  std::string len = listField(l, 1, "i64"), cap = listField(l, 2, "i64");
  std::string full = def("icmp eq i64 " + len + ", " + cap);
  std::string g = lbl("grow"), c = lbl("cont");
  cbr(full, g, c, true);
  placeLabel(g); ins("call void @fac_list_grow(ptr " + l + ")"); br(c);
  placeLabel(c);
  std::string data = listField(l, 0, "ptr");
  std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + len);
  storeRaw(p, el, val);
  std::string nl_ = def("add i64 " + len + ", 1");
  ins("store i64 " + nl_ + ", ptr " + def("getelementptr inbounds %FacList, ptr " + l + ", i32 0, i32 1"));
}

bool mutates(Node *n, const std::string &name) {
  if (!n) return false;
  if (n->k == NK::Assign && rootIdent(n->c[0].get()) == name) return true;
  if (((n->k == NK::Unary && (n->s == "++" || n->s == "--")) || n->k == NK::PostInc) && rootIdent(n->c[0].get()) == name) return true;
  if (n->k == NK::Call && n->c[0]->k == NK::Ident && (n->c[0]->s == "sort" || n->c[0]->s == "reverse" || n->c[0]->s == "fill") && n->c.size() > 1 && rootIdent(n->c[1].get()) == name) return true;
  for (auto &c : n->c) if (mutates(c.get(), name)) return true;
  for (auto &cs : n->cases) {
    for (auto &v : cs.vals) if (mutates(v.get(), name)) return true;
    for (auto &r : cs.ranges) if (mutates(r.lo.get(), name) || mutates(r.hi.get(), name)) return true;
    if (mutates(cs.guard.get(), name) || mutates(cs.body.get(), name) || mutates(cs.exprBody.get(), name)) return true;
  }
  return mutates(n->deflt.get(), name);
}

// ---- วิเคราะห์ว่า statement นี้ "จบด้วย return/throw เสมอ" หรือไม่ (ใช้เช็ก function ที่ลืม return)
bool hasLabeledBreak(Node *n) {   // break <label> ที่อาจพาออกจาก loop ภายนอก
  if (!n) return false;
  if (n->k == NK::Break && !n->label.empty()) return true;
  for (auto &c : n->c) if (hasLabeledBreak(c.get())) return true;
  for (auto &cs : n->cases) {
    for (auto &r : cs.ranges) if (hasLabeledBreak(r.lo.get()) || hasLabeledBreak(r.hi.get())) return true;
    if (hasLabeledBreak(cs.guard.get()) || hasLabeledBreak(cs.body.get()) || hasLabeledBreak(cs.exprBody.get())) return true;
  }
  return hasLabeledBreak(n->deflt.get());
}
bool hasBreak(Node *n, bool top = false) {
  if (!n) return false;
  if (n->k == NK::Break) return true;
  if (!top && (n->k == NK::While || n->k == NK::For || n->k == NK::ForPP || n->k == NK::Switch || n->k == NK::Match || n->k == NK::DoWhile || n->k == NK::ForEach)) return hasLabeledBreak(n);
  for (auto &c : n->c) if (hasBreak(c.get())) return true;
  for (auto &cs : n->cases) if (hasBreak(cs.guard.get()) || hasBreak(cs.body.get()) || hasBreak(cs.exprBody.get())) return true;
  return hasBreak(n->deflt.get());
}
bool alwaysEnds(Node *n) {
  if (!n) return false;
  switch (n->k) {
    case NK::Return: case NK::Throw: return true;
    case NK::Block: for (auto &c : n->c) if (alwaysEnds(c.get())) return true; return false;
    case NK::If: return n->c.size() > 2 && alwaysEnds(n->c[1].get()) && alwaysEnds(n->c[2].get());
    case NK::While: return n->c[0]->k == NK::BoolLit && (n->b ? !n->c[0]->b : n->c[0]->b) && !hasBreak(n, true);
    case NK::DoWhile: return alwaysEnds(n->c[0].get()) || (n->c[1]->k == NK::BoolLit && (n->b ? !n->c[1]->b : n->c[1]->b) && !hasBreak(n, true));
    case NK::For: return (!n->c[1] || (n->c[1]->k == NK::BoolLit && n->c[1]->b)) && !hasBreak(n, true);
    case NK::Switch: case NK::Match: {
      if (!n->deflt || !alwaysEnds(n->deflt.get()) || hasBreak(n, true)) return false;
      for (auto &cs : n->cases) if (!alwaysEnds(cs.body.get())) return false;
      return true;
    }
    case NK::Try: {
      if (n->c[2] && alwaysEnds(n->c[2].get())) return true;
      return alwaysEnds(n->c[0].get()) && (!n->c[1] || alwaysEnds(n->c[1].get()));
    }
    case NK::ExprStmt: { std::string p; Node *e = n->c[0].get(); return e->k == NK::Call && flatten(e->c[0].get(), p) && p == "sys.exit"; }
    default: return false;
  }
}

// Guard's failure branch must leave the current path. A break/continue is
// accepted only when it targets a control construct surrounding the guard,
// never a loop/switch nested inside the failure block.
bool guardExits(Node *n, int nestedLoops = 0, int nestedBreakTargets = 0) {
  if (!n) return false;
  switch (n->k) {
    case NK::Return: case NK::Throw: return true;
    case NK::Break: return nestedLoops == 0 && nestedBreakTargets == 0;
    case NK::Continue: return nestedLoops == 0;
    case NK::Block:
      for (const auto &child : n->c) if (guardExits(child.get(), nestedLoops, nestedBreakTargets)) return true;
      return false;
    case NK::If:
      return n->c.size() > 2 && guardExits(n->c[1].get(), nestedLoops, nestedBreakTargets) &&
             guardExits(n->c[2].get(), nestedLoops, nestedBreakTargets);
    case NK::While: case NK::DoWhile: case NK::For: case NK::ForPP: case NK::ForEach:
      return false; // a break inside this nested loop does not exit the guard's path
    case NK::Switch: case NK::Match: {
      if (!n->deflt || !guardExits(n->deflt.get(), nestedLoops, nestedBreakTargets + 1)) return false;
      for (const auto &cs : n->cases)
        if (!guardExits(cs.body.get(), nestedLoops, nestedBreakTargets + 1)) return false;
      return true;
    }
    case NK::Try:
      if (n->c.size() > 2 && n->c[2] && guardExits(n->c[2].get(), nestedLoops, nestedBreakTargets)) return true;
      return n->c.size() > 0 && guardExits(n->c[0].get(), nestedLoops, nestedBreakTargets) &&
             (n->c.size() < 2 || !n->c[1] || guardExits(n->c[1].get(), nestedLoops, nestedBreakTargets));
    default: return false;
  }
}

// ---------------------------------------------------------------- declarations
void declStmt(Node *n) {
  curLine = n->line;
  TypeSpec &ts = n->ts;
  Node *init = n->c.empty() ? nullptr : n->c[0].get();
  const std::string &kind = ts.kind;
  if (ts.cat == "tuple") { if (n->alignment || n->isVolatile) err("tuple ไม่รองรับ align/volatile", n->line); return tupleDecl(n); }
  if (ts.cat == "func") { if (n->alignment || n->isVolatile) err("function variable ไม่รองรับ align/volatile", n->line); return funcDecl(n); }
  if (ts.base == "mutex" && ts.cat.empty()) return mutexDecl(n);
  if (ts.cat == "array") return arrayDecl(n);
  if (ts.cat == "list" || ts.cat == "arraylist") { if (n->alignment || n->isVolatile) err("list ไม่รองรับ align/volatile", n->line); return dsOrList(n); }
  if (ts.cat == "matrix") { if (n->alignment || n->isVolatile) err("matrix ไม่รองรับ align/volatile", n->line); return matrixDecl(n); }
  if (ts.cat == "linked" || ts.cat == "hashmap" || ts.cat == "hashset" || ts.cat == "tree" || ts.cat == "graph" ||
      ts.cat == "stack" || ts.cat == "queue" || ts.cat == "heap" || ts.cat == "maxheap" || ts.cat == "trie") {
    if (n->alignment || n->isVolatile) err("data structure ไม่รองรับ align/volatile", n->line); return dsDecl(n);
  }
  T t; V iv; bool haveInit = false;
  if (n->isRef) {
    if (!opt.strictOwnership) err("local ref borrow ต้องเปิด --strict-ownership หรือ --secure เพื่อให้ตรวจ loan lifetime", n->line);
    if (n->isConst || n->isVolatile || n->alignment) err("local ref borrow ไม่รองรับ const/volatile/align modifier เพิ่มเติม; ใช้ ref const สำหรับ shared borrow", n->line);
    if (!init) err("local ref borrow ต้องกำหนด lvalue ต้นทาง เช่น ref const var int view = value", n->line);
    if (kind == "heap") err("local ref borrow ไม่สามารถใช้ kind heap ได้", n->line);
    if (kind == "dyn" && ts.base != "string") err("kind dyn ใช้กับ local ref borrow ได้เฉพาะ dyn string", n->line);
    if (ts.cat == "array" || ts.cat == "list" || ts.cat == "matrix" || ts.cat == "arraylist" ||
        ts.cat == "linked" || ts.cat == "hashmap" || ts.cat == "hashset" || ts.cat == "tree" ||
        ts.cat == "graph" || ts.cat == "stack" || ts.cat == "queue" || ts.cat == "trie")
      err("local ref borrow รุ่นนี้ยังไม่รองรับการ alias data structure/array ทั้งก้อน; ให้ borrow element หรือ field ที่เป็น lvalue", n->line);
    if (ts.cat == "obj" || ts.cat == "weakobj") t = resolveType(ts, n->line);
    else t = baseType(ts.base, n->line);
    if (ts.cat == "struct" && t->k != STRUCT) err(ts.base + " ไม่ใช่ struct", n->line);
    if (ts.cat == "enum" && t->k != ENUM) err(ts.base + " ไม่ใช่ enum", n->line);
    if (kind == "ptr") t = tPtr(t);
    if (ts.base == "auto" || t->k == VOID || t->k == ARR)
      err("local ref borrow ต้องระบุชนิดที่ชัดเจนและไม่ใช่ void/array/auto", n->line);
    if (t->k == STR && kind != "dyn") err("string local borrow ต้องเขียน ref [const] dyn string name", n->line);
    LV source = lval(init);
    if (!sameT(t, source.ty)) err("ชนิดของ local ref borrow ไม่ตรงกับ lvalue ต้นทาง (" + tname(source.ty) + " -> " + tname(t) + ")", n->line);
    Var &alias = declVar(n->s, t, kind);
    alias.slot = source.addr;
    alias.isConst = n->isImmutableRef;
    alias.isBorrowedAlias = true;
    alias.isVolatile = source.isVolatile;
    return; // aliases never register an independent owner cleanup
  }
  if (n->alignment && kind != "var") err("align(...) ใช้ได้กับ storage แบบ var เท่านั้นในรุ่นนี้", n->line);
  if (ts.base == "auto" && ts.cat.empty()) {
    if (!init) err("auto ต้องมีค่าเริ่มต้น", n->line);
    iv = expr(init); haveInit = true; t = iv.t;
    if (t->k == NULLT || t->k == VOID || t->k == ARR) err("auto: อนุมาน type จากค่านี้ไม่ได้", n->line);
    if (kind == "ptr" && t->k != PTR) err("ptr auto ต้องกำหนดด้วย ptr", n->line);
  } else {
    if (ts.cat == "obj" || ts.cat == "weakobj") t = resolveType(ts, n->line);
    else t = baseType(ts.base, n->line);
    if (ts.isVolatile) t = qualifyVolatile(t);
    if (ts.cat == "struct" && t->k != STRUCT) err(ts.base + " ไม่ใช่ struct", n->line);
    if (ts.cat == "enum" && t->k == ENUM && t->payloadEnum && ts.kind == "ptr") err("payload enum ใช้กับ ptr storage ไม่ได้", n->line);
    if (ts.cat == "enum" && t->k != ENUM) err(ts.base + " ไม่ใช่ enum", n->line);
    if (kind == "ptr") t = tPtr(t);
  }
  if (t->k == STR && kind != "dyn") err("string ใช้ได้กับ dyn เท่านั้น (dyn string " + n->s + ")", n->line);
  bool volStorage = n->isVolatile || (ts.isVolatile && kind != "ptr");
  if (volStorage && !(isNum(t) || t->k == PTR)) err("volatile รองรับเฉพาะ scalar และ pointer (ไม่รองรับ string/list/struct/object)", n->line);
  if (volStorage && kind != "var") err("volatile storage ใช้กับ kind var เท่านั้น; สำหรับ memory-mapped I/O ใช้ ptr volatile TYPE", n->line);
  if (kind == "heap") {
    if (t->k == STR || t->k == LIST) err("heap ใช้กับ string/list ไม่ได้ (ใช้ dyn)", n->line);
    std::string p = def("call ptr @fac_alloc(i64 " + std::to_string(std::max<int64_t>(sizeOf(t), 1)) + ")");
    std::string slot = alloca_(T_opaque); ins("store ptr " + p + ", ptr " + slot);
    if (t->k == STRUCT) initStructDefaults(p, structInfo(t->name, n->line), 0);
    if (init || haveInit) { if (!haveInit) iv = expr(init); storeRaw(p, t, iv); }
    Var &v = declVar(n->s, t, kind); v.slot = slot; v.indirect = true; v.isConst = n->isConst;
    return;
  }
  std::string slot = alloca_(t, -1, n->alignment);
  if (init || haveInit) {
    if (!haveInit) iv = expr(init);
    if (t->k == STR && iv.t->k != STR && iv.t->k != NULLT) err("กำหนด " + tname(iv.t) + " ให้ string ไม่ได้ (ใช้ str(x))", n->line);
    if (t->k == STRUCT && !(iv.t->k == STRUCT && iv.t->name == t->name)) err("ชนิด struct ไม่ตรงกัน", n->line);
    if (t->k == ENUM && t->payloadEnum && !(iv.t->k == ENUM && iv.t->payloadEnum && iv.t->name == t->name)) err("ชนิด payload enum ไม่ตรงกัน", n->line);
    if (t->k == OBJ && !(iv.t->k == OBJ && isSubclass(iv.t->name, t->name)) && iv.t->k != NULLT) err("ชนิด obj ไม่ตรงกัน: ต้องเป็น " + tname(t), n->line);
    if (t->k == WEAK && !(iv.t->k == WEAK && isSubclass(iv.t->name, t->name)) && iv.t->k != NULLT) err("ชนิด weak reference ไม่ตรงกัน: ต้องเป็น " + tname(t) + " (ใช้ memory.weak(obj))", n->line);
    if (t->k == LIST && iv.t->k != LIST) err("list ต้องกำหนดด้วย list", n->line);
    if (iv.t->k == NULLT && t->k == STR) iv.v = "null";
    storeRaw(slot, t, iv, true, volStorage);
  } else if (t->k == STRUCT) initStructDefaults(slot, structInfo(t->name, n->line), 0);
  else ins(std::string("store ") + (volStorage ? "volatile " : "") + llty(t) + " " + llzero(t) + ", ptr " + slot);
  Var &v = declVar(n->s, t, kind); v.slot = slot; v.isConst = n->isConst; v.isVolatile = volStorage;
  regCleanup(v);
}

void tupleDecl(Node *n) {  // var (int a, dyn string s) = f()
  if (n->c.empty()) err("tuple ต้องมีค่าเริ่มต้น เช่น var (int a, int b) = f()", n->line);
  size_t cnt = n->params.size();
  std::vector<T> vt;
  for (auto &p : n->params) {
    T t = resolveType(p.ts, n->line);
    if (t->k == STR && p.ts.kind != "dyn") err("string ใน tuple ต้องเป็น dyn string (" + p.name + ")", n->line);
    if (!(isNum(t) || t->k == STR || t->k == PTR)) err("ตัวแปร '" + p.name + "' ชนิด " + tname(t) + " ใช้กับ tuple ไม่ได้", n->line);
    vt.push_back(t);
  }
  Node *init = n->c[0].get();
  std::vector<V> vals;
  if (init->k == NK::TupleLit) {
    if (init->c.size() != cnt) err("tuple มี " + std::to_string(init->c.size()) + " ค่า แต่ประกาศ " + std::to_string(cnt) + " ตัวแปร", n->line);
    for (size_t i = 0; i < cnt; i++) {
      V e = expr(init->c[i].get());
      if (vt[i]->k == STR) {
        if (e.t->k != STR && e.t->k != NULLT) err("'" + n->params[i].name + "' ต้องเป็น string", n->line);
        if (e.t->k == STR) { e = ownV(e); borrow(e); }
      }
      else { checkImplicit(e, vt[i], n->line); e = cv(e, vt[i], n->line); }
      vals.push_back(e);
    }
  } else {
    V tv = expr(init);
    if (tv.t->k != TUPLE || tv.t->ps.size() != cnt) err("ค่าที่กำหนดต้องเป็น tuple ขนาด " + std::to_string(cnt), n->line);
    for (size_t i = 0; i < cnt; i++) {
      V e; e.t = tv.t->ps[i]; e.v = def("extractvalue " + llty(tv.t) + " " + tv.v + ", " + std::to_string(i)); e.owned = tv.owned && e.t->k == STR;
      if (vt[i]->k == STR) { if (e.t->k != STR) err("'" + n->params[i].name + "' ต้องเป็น string", n->line); if (e.owned) borrow(e); }
      else { checkImplicit(e, vt[i], n->line); e = cv(e, vt[i], n->line); }
      vals.push_back(e);
    }
  }
  for (size_t i = 0; i < cnt; i++) {
    std::string slot = alloca_(vt[i]);
    storeRaw(slot, vt[i], vals[i]);
    Var &v = declVar(n->params[i].name, vt[i], n->params[i].ts.kind.empty() ? "var" : n->params[i].ts.kind); v.slot = slot; v.isConst = n->isConst;
    if (vals[i].t->k == STR && vals[i].owned) transferTemp(vals[i]);
    regCleanup(v);
  }
}

void funcDecl(Node *n) {
  TypeSpec &ts = n->ts;
  if (n->c.empty()) err("function ต้องกำหนดค่าเริ่มต้น (lambda หรือชื่อ function)", n->line);
  T t = resolveType(ts, n->line);
  lamExpect = t;
  V v = expr(n->c[0].get());
  lamExpect = nullptr;
  if (v.t->k != FUNC) err("ต้องกำหนด function ให้ตัวแปรชนิด function", n->line);
  if (ts.hasSig && !functionTypeSatisfies(v.t, t)) err("function value ไม่ตรงกับ function type ที่ประกาศ (ชนิดผลลัพธ์/parameter ไม่ตรง หรือ implementation ทำ effect contract อ่อนกว่า)", n->line);
  if (!ts.hasSig) t = v.t;
  std::string slot = alloca_(T_opaque); storeRaw(slot, t, v);
  Var &var = declVar(n->s, t, ts.kind); var.slot = slot; var.isConst = n->isConst; regCleanup(var);
}

void matrixDecl(Node *n) {
  TypeSpec &ts = n->ts;
  if (ts.kind == "ptr") err("matrix ใช้ kind ptr ไม่ได้", n->line);
  if (!ts.hasSize || !ts.hasSize2) err("matrix ต้องระบุจำนวนแถวและคอลัมน์ เช่น matrix var int m[3][4]", n->line);
  T el = baseType(ts.base, n->line);
  if (!(isNum(el) || el->k == CHAR || el->k == UNI || el->k == ENUM || el->k == STR))
    err("matrix รองรับสมาชิกเป็น scalar/string/enum เท่านั้น", n->line);
  int64_t rows = 0, cols = 0;
  if (!constEval(ts.size.get(), rows) || !constEval(ts.size2.get(), cols) || rows <= 0 || cols <= 0)
    err("matrix dimensions ต้องเป็นค่าคงที่มากกว่า 0", n->line);
  if (rows > INT32_MAX || cols > INT32_MAX || rows > INT64_MAX / cols || rows * cols > INT32_MAX)
    err("ขนาด matrix ใหญ่เกินไป", n->line);
  std::string m = def("call ptr @fac_mx_new(i64 " + std::to_string(rows) + ", i64 " + std::to_string(cols) +
                       ", i32 " + std::to_string(tcode(el)) + ", i32 " + std::to_string(sizeOf(el)) + ")");
  Node *init = n->c.empty() ? nullptr : n->c[0].get();
  if (init && init->k != NK::InitList) err("matrix initializer ต้องเป็น {{...}, {...}}", n->line);
  if (init) {
    if ((int64_t)init->c.size() > rows) err("จำนวนแถวเริ่มต้นเกิน matrix", n->line);
    for (size_t r = 0; r < init->c.size(); r++) {
      Node *row = init->c[r].get();
      if (row->k != NK::InitList) err("แต่ละแถวของ matrix ต้องใช้ {...}", row->line);
      if ((int64_t)row->c.size() > cols) err("จำนวนคอลัมน์เริ่มต้นเกิน matrix", row->line);
      for (size_t c = 0; c < row->c.size(); c++) {
        V v = expr(row->c[c].get());
        std::string slot = alloca_(el);
        storeRaw(slot, el, v);
        ins("call void @fac_mx_set(ptr " + m + ", i64 " + std::to_string(r) + ", i64 " + std::to_string(c) + ", ptr " + slot + ")");
      }
    }
  }
  T t = tDS("matrix", el, el);
  std::string slot = alloca_(t); ins("store ptr " + m + ", ptr " + slot);
  Var &v = declVar(n->s, t, ts.kind); v.slot = slot;
  if (ts.kind != "heap") regCleanup(v);
}

void dsOrList(Node *n) { listDecl(n); }

void listDecl(Node *n) {
  TypeSpec &ts = n->ts;
  if (ts.kind == "ptr") err("list ใช้ kind ptr ไม่ได้", n->line);
  T el = ts.elemObj ? resolveType(ts, n->line)->el : baseType(ts.base, n->line), t = tList(el);
  if (ts.cat == "arraylist") t->name = "arraylist";
  if (el->k == LIST) err("list ของ list ยังไม่รองรับ", n->line);
  Node *init = n->c.empty() ? nullptr : n->c[0].get();
  std::string l;
  auto mkNew = [&]() {
    std::string q = def("call ptr @fac_list_new(i32 " + std::to_string(sizeOf(el)) + ", i32 " + std::to_string(ekOf(el)) + ")");
    setListOps(el, q);
    return q;
  };
  if (!init) l = mkNew();
  else if (init->k == NK::InitList) { l = mkNew(); for (auto &e : init->c) { V v = expr(e.get()); listPush(l, el, v); } }
  else {
    V v = expr(init);
    if (v.t->k == LIST) { if (!sameT(v.t->el, el)) err("ชนิดสมาชิกของ list ไม่ตรงกัน", n->line); V owned = ownV(v); l = owned.v; transferTemp(owned); }
    else if (v.t->k == ARR) { std::string d, len; T e2; seqParts(v, d, len, e2, n->line); l = def("call ptr @fac_list_from(ptr " + d + ", i64 " + len + ", i32 " + std::to_string(sizeOf(el)) + ", i32 " + std::to_string(ekOf(el)) + ")"); }
    else if (el->k == STR && v.t->k == STR) { l = mkNew(); listPush(l, el, v); }
    else if (isNum(v.t) && isNum(el)) { l = mkNew(); listPush(l, el, v); }
    else err("กำหนด " + tname(v.t) + " ให้ list ไม่ได้", n->line);
  }
  std::string slot = alloca_(t); ins("store ptr " + l + ", ptr " + slot);
  Var &v = declVar(n->s, t, ts.kind); v.slot = slot;
  if (ts.kind != "heap") regCleanup(v);
}

void arrayDecl(Node *n) {
  TypeSpec &ts = n->ts;
  if (n->isVolatile) err("volatile สำหรับ array ทั้งก้อนยังไม่รองรับ; ใช้ ptr volatile TYPE สำหรับ MMIO", n->line);
  if (n->alignment && ts.kind != "var") err("align(...) กับ array ใช้ได้เฉพาะ array var", n->line);
  T el = baseType(ts.base, n->line);
  if (ts.isVolatile) err("volatile array element ยังไม่รองรับ; ใช้ ptr volatile TYPE สำหรับ MMIO", n->line);
  if (el->k == STR || el->k == STRUCT || el->k == LIST) err("array ของ " + tname(el) + " ยังไม่รองรับ (ใช้ list)", n->line);
  const std::string &kind = ts.kind;
  if (kind == "dyn") err("array ใช้ kind dyn ไม่ได้ (ใช้ var/ptr/heap)", n->line);
  Node *init = n->c.empty() ? nullptr : n->c[0].get();
  int64_t N = -1; std::string nlen;
  if (ts.hasSize) {
    if (constEval(ts.size.get(), N)) nlen = std::to_string(N);
    else if (kind == "heap") { V s = expr(ts.size.get()); nlen = conv(s, T_long); }
    else err("ขนาด array ต้องเป็นค่าคงที่ (ใช้ array heap สำหรับขนาดที่รู้ตอนรัน)", n->line);
  } else if (init && init->k == NK::InitList) { N = (int64_t)init->c.size(); nlen = std::to_string(N); }
  else if (init && init->k == NK::StrLit && (el->k == CHAR || el->k == UNI)) { N = (int64_t)init->s.size() + 1; nlen = std::to_string(N); }
  else err("array ต้องระบุขนาด [n]", n->line);
  if (N == 0) err("ขนาด array ต้องมากกว่า 0", n->line);
  if (N > 0) {   // N * sizeOf(el) ต้องไม่ล้นช่วง; array var อยู่บน stack จึงต้องไม่ใหญ่เกินไป
    int64_t bytesTotal;
    if (__builtin_mul_overflow(N, (int64_t)sizeOf(el), &bytesTotal) || bytesTotal > (int64_t(1) << 40)) err("array ใหญ่เกินไป (เกิน 1 TiB หรือ N * ขนาด element ล้นช่วง)", n->line);
    if (kind == "var" && bytesTotal > (int64_t(1) << 30)) err("array var ใหญ่เกินไปสำหรับ stack (" + std::to_string(bytesTotal) + " bytes) ใช้ array heap แทน", n->line);
  }
  std::string esz = std::to_string(sizeOf(el)), data, slot;
  bool ind = false;
  if (kind == "var") {
    if (N < 0) err("array var ต้องมีขนาดคงที่", n->line);
    slot = data = alloca_(el, N, n->alignment);
    ins("call void @llvm.memset.p0.i64(ptr " + data + ", i8 0, i64 " + std::to_string(N * sizeOf(el)) + ", i1 false)");
  } else if (kind == "heap") {
    std::string bytes = N >= 0 ? std::to_string(N * sizeOf(el)) : def("mul i64 " + nlen + ", " + esz);
    data = def("call ptr @fac_alloc(i64 " + bytes + ")");
    slot = alloca_(T_opaque); ins("store ptr " + data + ", ptr " + slot); ind = true;
  } else {  // ptr: array ชี้ memory ที่ผู้ใช้ alloc เอง
    if (!init || init->k == NK::InitList) err("array ptr ต้องกำหนดด้วย alloc(...) หรือ ptr", n->line);
    if (N < 0) err("array ptr ต้องมีขนาดคงที่", n->line);
    V pv = expr(init);
    data = conv(pv, T_opaque, n->line);
    slot = alloca_(T_opaque); ins("store ptr " + data + ", ptr " + slot); ind = true; init = nullptr;
  }
  if (init) {
    if (init->k == NK::InitList) {
      if (N >= 0 && (int64_t)init->c.size() > N) err("ค่าเริ่มต้น " + std::to_string(init->c.size()) + " ตัว เกินขนาด array " + std::to_string(N), n->line);
      for (size_t i = 0; i < init->c.size(); i++) {
        V v = expr(init->c[i].get());
        std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + std::to_string(i));
        checkImplicit(v, el, n->line);
        ins("store " + llty(el) + " " + conv(v, el, n->line) + ", ptr " + p);
      }
    } else if (init->k == NK::StrLit && (el->k == CHAR || el->k == UNI)) {
      std::vector<uint32_t> cps;
      if (el->k == CHAR) for (unsigned char c : init->s) cps.push_back(c);
      else { size_t i = 0; while (i < init->s.size()) { uint32_t cp = utf8dec(init->s, i); if (cp == kBadUtf8) err("string literal ไม่ใช่ UTF-8 ที่ถูกต้อง จึงใส่ array unichar ไม่ได้", n->line); cps.push_back(cp); } }
      if (N >= 0 && (int64_t)cps.size() > N) err("string ยาวเกินขนาด array " + std::to_string(N), n->line);
      for (size_t i = 0; i < cps.size(); i++) {
        std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + std::to_string(i));
        ins("store " + llty(el) + " " + std::to_string(el->k == CHAR ? (int)(int8_t)cps[i] : (int64_t)cps[i]) + ", ptr " + p);
      }
    } else {
      V a = expr(init); borrow(a);
      std::string d, len; T e2; seqParts(a, d, len, e2, n->line);
      if (!sameT(e2, el)) err("ชนิดสมาชิกของ array ไม่ตรงกัน", n->line);
      std::string cap = N >= 0 ? std::to_string(N) : nlen;
      std::string lt = def("icmp ult i64 " + len + ", " + cap);
      std::string cnt = def("select i1 " + lt + ", i64 " + len + ", i64 " + cap);
      std::string bytes = def("mul i64 " + cnt + ", " + esz);
      ins("call void @llvm.memcpy.p0.p0.i64(ptr " + data + ", ptr " + d + ", i64 " + bytes + ", i1 false)");
    }
  }
  Var &v = declVar(n->s, tArr(el, N), kind); v.slot = slot; v.indirect = ind; v.len = nlen; v.isConst = n->isConst;
}

// ---------------------------------------------------------------- statements
void stmtBlock(Node *b, bool newScope = true) {
  if (b->isUnsafe) unsafeDepth++;   // unsafe { ... }
  if (newScope) pushScope();
  for (auto &s : b->c) stmt(s.get());
  if (newScope) popScope();
  if (b->isUnsafe) unsafeDepth--;
}

void stmtReturn(Node *n) {
  if (cf->ret->k == AUTOT) {  // generic: อนุมาน return type จาก return แรก
    if (n->c.empty()) cf->ret = T_void;
    else {
      T t = dryType(n->c[0].get());
      if (t->k == ARR) t = tList(t->el);
      if (t->k == NULLT || t->k == VOID) err("return: อนุมาน type ไม่ได้", n->line);
      cf->ret = t;
    }
  }
  T rt = cf->ret; Var *skip = nullptr; std::string val; bool have = false;
  if (n->c.empty()) { if (rt->k != VOID) err("function ที่คืนค่าต้อง return ค่า (return เปล่าใช้ได้เฉพาะ function void)", n->line); }
  else {
    if (rt->k == VOID) err("function void คืนค่าไม่ได้", n->line);
    Node *e = n->c[0].get();
    bool returningCapture = false;
    if (cf && cf->isLambda && e->k == NK::Ident) {
      for (const auto &cap : cf->caps) if (cap.name == e->s) { returningCapture = true; break; }
    }
    // Captured managed values are borrowed from the environment; copy them on
    // return rather than transferring the environment's ownership to the caller.
    if (!returningCapture && e->k == NK::Ident && (rt->k == STR || rt->k == LIST || rt->k == DSK || rt->k == STRUCT || (rt->k == ENUM && rt->payloadEnum) || rt->k == OBJ || rt->k == WEAK)) {
      Var *v = findVar(e->s);
      if (v && !v->isParam && !v->indirect && v->ty->k == rt->k && (rt->k != STRUCT && rt->k != OBJ && rt->k != WEAK && !(rt->k == ENUM && rt->payloadEnum) || v->ty->name == rt->name) && v->slot != "%self" && v->slot.compare(0, 2, "%p") != 0) {
        skip = v;
        val = def("load " + llty(rt) + ", ptr " + v->slot); have = true;
      }
    }
    if (!have && rt->k == TUPLE) {
      V r = e->k == NK::TupleLit ? tupleLit(e, rt) : expr(e);
      if (r.t->k != TUPLE || !sameT(r.t, rt)) err("return ต้องเป็น tuple " + tname(rt) + " (เจอ " + tname(r.t) + ")", n->line);
      val = r.v; have = true;
    }
    if (!have) {
      V r = expr(e);
      if (rt->k == STR) {
        if (r.t->k != STR && r.t->k != NULLT) err("return ต้องเป็น string", n->line);
        if (r.t->k == NULLT) val = "null";
        else { V owned = ownV(r); borrow(owned); val = owned.v; transferTemp(owned); }
      } else if (rt->k == DSK) {
        if (r.t->k != DSK || r.t->name != rt->name) err("return ต้องเป็น " + rt->name, n->line);
        V owned = ownV(r); borrow(owned); val = owned.v; transferTemp(owned);
      } else if (rt->k == LIST) {
        V owned;
        if (r.t->k == LIST) owned = ownV(r);
        else if (r.t->k == ARR) { std::string d, len; T el; seqParts(r, d, len, el, n->line); owned.t = rt; owned.v = def("call ptr @fac_list_from(ptr " + d + ", i64 " + len + ", i32 " + std::to_string(sizeOf(el)) + ", i32 " + std::to_string(ekOf(el)) + ")"); owned.owned = true; }
        else err("return ต้องเป็น array/list", n->line);
        borrow(owned); val = owned.v; transferTemp(owned);
      } else if (rt->k == STRUCT || (rt->k == ENUM && rt->payloadEnum)) {
        if (r.t->k != rt->k || r.t->name != rt->name) err("return ต้องเป็น " + tname(rt), n->line);
        V owned = ownV(r); borrow(owned);
        val = def("load " + llty(rt) + ", ptr " + owned.v);
        transferTemp(owned);
      } else if (rt->k == FUNC) {
        if (r.t->k != FUNC && r.t->k != NULLT) err("return ต้องเป็น function", n->line);
        if (r.t->k == NULLT) val = "null";
        else { V owned = ownV(r); borrow(owned); val = owned.v; transferTemp(owned); }
      } else if (rt->k == OBJ) {
        if (r.t->k != OBJ && r.t->k != NULLT) err("return ต้องเป็น obj " + rt->name, n->line);
        if (r.t->k == OBJ && !isSubclass(r.t->name, rt->name)) err("return ต้องเป็น obj " + rt->name, n->line);
        if (r.t->k == NULLT) val = "null";
        else { V owned = ownV(r); borrow(owned); val = owned.v; transferTemp(owned); }
      } else if (rt->k == WEAK) {
        if (r.t->k != WEAK && r.t->k != NULLT) err("return ต้องเป็น " + tname(rt), n->line);
        if (r.t->k == WEAK && !isSubclass(r.t->name, rt->name)) err("return ต้องเป็น " + tname(rt), n->line);
        if (r.t->k == NULLT) val = "null";
        else { V owned = ownV(r); borrow(owned); val = owned.v; transferTemp(owned); }
      } else { checkImplicit(r, rt, n->line); val = conv(r, rt, n->line); }
    }
  }
  flushTemps(0, false);
  cleanupAll(0, skip);
  emitRecursionLeave();
  if (rt->k == VOID) ins("ret void"); else ins("ret " + llty(rt) + " " + val);
  term = true;
}

void stmtTry(Node *n) {
  Node *fb = n->c[2].get();
  if (!fb) { tryCore(n); return; }
  // try ... finally: finally ถูกลงทะเบียนเป็น "งานท้าย scope" (รันตอนจบปกติ / return / break / continue)
  // และมี handler ดักทุก error เพื่อรัน finally แล้ว throw ต่อ
  std::string endL = lbl("fin.end"), bodyL = lbl("fin.body"), reL = lbl("fin.rethrow");
  pushScope();
  scopes.back().cl.push_back({"", false, fb});
  std::string jb = alloca_(T_opaque, 5);
  ins("call void @fac_try_enter(ptr " + jb + ")");
  ins("store ptr " + def("call ptr @llvm.frameaddress.p0(i32 0)") + ", ptr " + jb);
  ins("store ptr " + def("call ptr @llvm.stacksave.p0()") + ", ptr " + def("getelementptr inbounds ptr, ptr " + jb + ", i32 2"));
  std::string r = def("call i32 @llvm.eh.sjlj.setjmp(ptr " + jb + ") returns_twice");
  cbr(def("icmp eq i32 " + r + ", 0"), bodyL, reL);
  placeLabel(bodyL);
  pushScope(); scopes.back().cl.push_back({"", true});
  tryCore(n);
  popScope();
  if (!term) br(endL);
  placeLabel(reL);
  std::string em = def("call ptr @fac_err_msg()"), ec = def("call i32 @fac_err_code()");
  stmt(fb);
  if (!term) { ins("call void @fac_throw(ptr " + em + ", i32 " + ec + ")"); ins("unreachable"); term = true; }
  placeLabel(endL);
  popScope();
}

void tryCore(Node *n) {
  Node *tb = n->c[0].get(), *cb = n->c[1].get();
  std::string endL = lbl("try.end");
  if (cb) {
    if (n->ts.base != "Error") err("catch รองรับเฉพาะ catch(Error e)", n->line);
    std::string jb = alloca_(T_opaque, 5);
    std::string bodyL = lbl("try.body"), catchL = lbl("try.catch");
    ins("call void @fac_try_enter(ptr " + jb + ")");
    // เหมือน clang __builtin_setjmp: buf[0]=frame pointer, buf[2]=stack pointer, buf[1] ให้ intrinsic ใส่ที่อยู่กลับ
    ins("store ptr " + def("call ptr @llvm.frameaddress.p0(i32 0)") + ", ptr " + jb);
    ins("store ptr " + def("call ptr @llvm.stacksave.p0()") + ", ptr " + def("getelementptr inbounds ptr, ptr " + jb + ", i32 2"));
    std::string r = def("call i32 @llvm.eh.sjlj.setjmp(ptr " + jb + ") returns_twice");
    cbr(def("icmp eq i32 " + r + ", 0"), bodyL, catchL);
    placeLabel(bodyL);
    pushScope(); scopes.back().cl.push_back({"", true});
    stmtBlock(tb, false);
    popScope();
    if (!term) br(endL);
    placeLabel(catchL);
    pushScope();
    T et = tStruct("Error");
    std::string slot = alloca_(et);
    ins("store ptr " + def("call ptr @fac_err_msg()") + ", ptr " + def("getelementptr inbounds %S.Error, ptr " + slot + ", i32 0, i32 0"));
    ins("store i32 " + def("call i32 @fac_err_code()") + ", ptr " + def("getelementptr inbounds %S.Error, ptr " + slot + ", i32 0, i32 1"));
    Var &v = declVar(n->s, et, "var"); v.slot = slot; regCleanup(v);
    stmtBlock(cb, false);
    popScope();
    if (!term) br(endL);
  } else {
    stmtBlock(tb);
    if (!term) br(endL);
  }
  placeLabel(endL);
}

void stmt(Node *n) {
  curLine = n->line;
  switch (n->k) {
    case NK::Block: stmtBlock(n); break;
    case NK::VarDecl: declStmt(n); flushTemps(0); break;
    case NK::ExprStmt: { V r = expr(n->c[0].get()); borrow(r); flushTemps(0); break; }
    case NK::If: {
      V c = expr(n->c[0].get()); std::string cd = condOf(c); flushTemps(0);
      if (n->b) { // guard(condition) else { ... }: success falls through, failure must exit
        if (n->c.size() < 2 || !guardExits(n->c[1].get()))
          err("guard else block ต้องออกจากเส้นทางด้วย return, throw, break หรือ continue ทุกกรณี", n->line);
        std::string failL = lbl("guard.fail"), okL = lbl("guard.ok");
        cbr(cd, okL, failL);
        placeLabel(failL); stmtBlock(n->c[1].get());
        if (!term) err("guard else block ยังมีเส้นทางที่ทำงานต่อได้", n->line);
        placeLabel(okL);
        break;
      }
      bool hasElse = n->c.size() > 2;
      std::string th = lbl("if.then"), el = lbl("if.else"), en = lbl("if.end");
      cbr(cd, th, hasElse ? el : en);
      placeLabel(th); stmtBlock(n->c[1].get()); if (!term) br(en);
      if (hasElse) { placeLabel(el); stmt(n->c[2].get()); if (!term) br(en); }
      placeLabel(en);
      break;
    }
    case NK::While: {
      std::string cl = lbl("while.cond"), bd = lbl("while.body"), en = lbl("while.end");
      label(cl);
      V c = expr(n->c[0].get()); std::string cd = condOf(c); flushTemps(0);
      if (n->b) cd = def("xor i1 " + cd + ", true"); // until(condition) is while(!condition)
      cbr(cd, bd, en);
      placeLabel(bd);
      loops.push_back({en, cl, scopes.size(), "", true, false, false}); loops.back().name = n->label;
      stmtBlock(n->c[1].get());
      loops.pop_back();
      if (!term) brLoop(cl);
      placeLabel(en);
      break;
    }
    case NK::For: {
      pushScope();
      if (n->c[0]) stmt(n->c[0].get());
      std::string cl = lbl("for.cond"), bd = lbl("for.body"), up = lbl("for.upd"), en = lbl("for.end");
      label(cl);
      if (n->c[1]) { V c = expr(n->c[1].get()); std::string cd = condOf(c); flushTemps(0); cbr(cd, bd, en); }
      else br(bd);
      placeLabel(bd);
      loops.push_back({en, up, scopes.size(), "", true, false, false}); loops.back().name = n->label;
      stmtBlock(n->c[3].get());
      loops.pop_back();
      label(up);
      if (n->c[2]) stmt(n->c[2].get());
      if (!term) brLoop(cl);
      placeLabel(en);
      popScope();
      break;
    }
    case NK::ForPP: {
      bool up = n->b;
      V cnt = expr(n->c[0].get()); std::string cnt32 = conv(cnt, T_int, n->line); flushTemps(0);
      std::string slot = alloca_(T_int);
      ins("store i32 " + (up ? std::string("0") : def("sub i32 " + cnt32 + ", 1")) + ", ptr " + slot);
      std::string hd = lbl("pp.head"), bd = lbl("pp.body"), lt = lbl("pp.latch"), en = lbl("pp.end");
      label(hd);
      std::string i = def("load i32, ptr " + slot);
      cbr(def(up ? "icmp slt i32 " + i + ", " + cnt32 : "icmp sge i32 " + i + ", 0"), bd, en);
      placeLabel(bd);
      loops.push_back({en, lt, scopes.size(), slot, true, true, up}); loops.back().name = n->label;
      stmtBlock(n->c[1].get());
      loops.pop_back();
      label(lt);
      std::string i2 = def("load i32, ptr " + slot);
      ins("store i32 " + def(up ? "add nuw nsw i32 " + i2 + ", 1" : "sub nsw i32 " + i2 + ", 1") + ", ptr " + slot);
      brLoop(hd);
      placeLabel(en);
      break;
    }
    case NK::DoWhile: {
      std::string bd = lbl("do.body"), cl = lbl("do.cond"), en = lbl("do.end");
      label(bd);
      loops.push_back({en, cl, scopes.size(), "", true, false, false}); loops.back().name = n->label;
      stmtBlock(n->c[0].get());
      loops.pop_back();
      label(cl);
      V c = expr(n->c[1].get()); std::string cd = condOf(c); flushTemps(0);
      if (n->b) cd = def("xor i1 " + cd + ", true"); // do ... until(condition)
      cbr(cd, bd, en);
      placeLabel(en);
      break;
    }
    case NK::ForEach: stmtForEach(n); break;
    case NK::Switch: stmtSwitch(n); break;
    case NK::Match: stmtMatch(n); break;
    case NK::Break: {
      if (!n->label.empty()) {
        for (size_t i = loops.size(); i > 0; i--) if (loops[i - 1].isLoop && loops[i - 1].name == n->label) { cleanupAll(loops[i - 1].depth, nullptr); br(loops[i - 1].brk); return; }
        err("break " + n->label + ": ไม่พบ label นี้ใน loop ที่ครอบอยู่", n->line);
      }
      if (loops.empty()) err("break อยู่นอก loop/switch", n->line);
      cleanupAll(loops.back().depth, nullptr); br(loops.back().brk); break;
    }
    case NK::Continue: {
      if (!n->label.empty()) {
        for (size_t i = loops.size(); i > 0; i--) if (loops[i - 1].isLoop && loops[i - 1].name == n->label) { cleanupAll(loops[i - 1].depth, nullptr); br(loops[i - 1].cont); return; }
        err("continue " + n->label + ": ไม่พบ label นี้ใน loop ที่ครอบอยู่", n->line);
      }
      for (size_t i = loops.size(); i > 0; i--) if (loops[i - 1].isLoop) { cleanupAll(loops[i - 1].depth, nullptr); br(loops[i - 1].cont); return; }
      err("continue อยู่นอก loop", n->line);
    }
    case NK::Return: stmtReturn(n); break;
    case NK::Throw: {
      if (cf && cf->isDestructor) err("destructor ห้าม throw เพราะถูกเรียกจากระบบ release object", n->line);
      size_t tmk = temps.size();   // temp ของ expression ที่ใช้สร้าง Error: โค้ดหลัง throw ไม่มีทางรันถึง -> ห้าม flush ทีหลัง (เคยทำให้ IR ผิด: pop/free ไปอยู่ในบล็อก catch)
      V v = expr(n->c[0].get());
      if (v.t->k == STRUCT && v.t->name == "Error") {
        std::string m = def("load ptr, ptr " + def("getelementptr inbounds %S.Error, ptr " + v.v + ", i32 0, i32 0"));
        std::string c = def("load i32, ptr " + def("getelementptr inbounds %S.Error, ptr " + v.v + ", i32 0, i32 1"));
        ins(std::string("call void @fac_throw") + (v.owned ? "_owned" : "") + "(ptr " + m + ", i32 " + c + ")");
      } else if (v.t->k == STR) ins(std::string("call void @fac_throw") + (v.owned ? "_owned" : "") + "(ptr " + v.v + ", i32 1)");
      else err("throw ต้องเป็น Error(...) หรือ string", n->line);
      ins("unreachable"); term = true;
      temps.resize(tmk);   // runtime ปล่อยค่าที่ลงทะเบียนไว้ใน temp stack ให้เองตอน unwind
      break;
    }
    case NK::Try: stmtTry(n); break;
    case NK::Defer: scopes.back().cl.push_back({"", false, n->c[0].get()}); break;
    case NK::StructDef: case NK::EnumDef: err("struct/enum ต้องประกาศระดับบนสุดของไฟล์", n->line);
    default: err("statement นี้ยังไม่รองรับ", n->line);
  }
}

void stmtForEach(Node *n) {  // for(var int v : xs) { ... }   xs = array | list | string
  pushScope();  // เจ้าของ iterable ชั่วคราว (เช่น m.keys()) ให้ถูก free ตอนจบ loop / break / return
  V it = expr(n->c[0].get());
  bool isStr = it.t->k == STR, isList = it.t->k == LIST, isArr = it.t->k == ARR;
  if (!isStr && !isList && !isArr) err("for(... : x) ใช้กับ array / list / string เท่านั้น (เจอ " + tname(it.t) + ")", n->line);
  if (it.owned && needsFree(it.t)) {
    std::string hs = alloca_(T_opaque); ins("store ptr " + it.v + ", ptr " + hs);
    Var &hv = declVar("$foreach" + std::to_string(++nl), it.t, "var"); hv.slot = hs; regCleanup(hv);
  }
  flushTemps(0);
  T el = isStr ? T_uni : it.t->el;
  T vt = n->ts.base == "auto" ? el : baseType(n->ts.base, n->line);
  if (n->ts.kind == "ptr" || n->ts.kind == "heap") err("ตัวแปรของ for(... : ...) ใช้ได้เฉพาะ var / dyn", n->line);
  if (vt->k == STR && n->ts.kind != "dyn") err("string ใช้ได้กับ dyn เท่านั้น (for(dyn string s : xs))", n->line);
  std::string idx = alloca_(T_long); ins("store i64 0, ptr " + idx);
  std::string hd = lbl("fe.head"), bd = lbl("fe.body"), lt = lbl("fe.latch"), en = lbl("fe.end");
  label(hd);
  std::string i = def("load i64, ptr " + idx);
  std::string len = isArr ? it.len : isList ? listField(it.v, 1, "i64") : def("sext i32 " + def("call i32 @fac_str_len(ptr " + it.v + ")") + " to i64");
  cbr(def("icmp slt i64 " + i + ", " + len), bd, en);
  placeLabel(bd);
  loops.push_back({en, lt, scopes.size(), "", true, false, false}); loops.back().name = n->label;
  pushScope();
  V ev; ev.t = el;
  if (isStr) ev.v = def("call i32 @fac_str_at(ptr " + it.v + ", i64 " + i + ")");
  else {
    std::string data = isArr ? it.v : listField(it.v, 0, "ptr");
    std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + i);
    if (el->k == STRUCT) ev.v = p; else ev.v = def("load " + llty(el) + ", ptr " + p);
  }
  std::string slot = alloca_(vt);
  storeRaw(slot, vt, ev);
  Var &v = declVar(n->s, vt, n->ts.kind); v.slot = slot; regCleanup(v);
  stmtBlock(n->c[1].get());
  popScope();
  loops.pop_back();
  label(lt);
  std::string i2 = def("load i64, ptr " + idx);
  ins("store i64 " + def("add nuw nsw i64 " + i2 + ", 1") + ", ptr " + idx);
  brLoop(hd);
  placeLabel(en);
  popScope();
}

bool isMatchLiteral(Node *n) {
  if (!n) return false;
  if (n->k == NK::IntLit || n->k == NK::FloatLit || n->k == NK::CharLit || n->k == NK::BoolLit || n->k == NK::StrLit) return true;
  int64_t value = 0;
  return constEval(n, value); // enum member or compile-time const
}

std::string matchSimpleEnumName(const std::string &name) {
  size_t dot = name.rfind('.');
  return dot == std::string::npos ? name : name.substr(dot + 1);
}

std::string matchEnumNameForSelector(const std::string &patternPath, const T &selector, int line) {
  if (!selector || selector->k != ENUM || !enums.count(selector->name))
    err("pattern enum ใช้กับ selector ที่ไม่ใช่ enum", line);
  EnumInfo &ei = enums[selector->name];
  const std::string requested = matchSimpleEnumName(patternPath);
  const std::string origin = ei.genericOrigin.empty() ? ei.name : ei.genericOrigin;
  if (requested != ei.name && requested != origin)
    err("pattern " + patternPath + " ใช้กับ enum " + ei.name + " ไม่ได้", line);
  requireTypeAccess(patternPath, ei.name, ei.module, ei.isPublic, line);
  return ei.name;
}

void validateMatchCoverage(Node *n, const T &selector, bool required, bool expression = false) {
  if (!required || n->deflt) return;
  for (const auto &cs : n->cases) if (cs.wildcard && !cs.guard) return;
  if (selector->k == ENUM) {
    const EnumInfo &ei = enums.at(selector->name);
    std::set<std::string> covered;
    for (const auto &cs : n->cases) {
      if (!cs.guard && !cs.variantName.empty()) {
        const EnumInfo &ei = enums.at(selector->name);
        const std::string patternName = matchSimpleEnumName(cs.variantEnum);
        if (patternName == ei.name || patternName == ei.genericOrigin) covered.insert(cs.variantName);
      }
    }
    for (const auto &m : ei.mem) {
      if (!covered.count(m.name))
        err("match ไม่ครอบคลุม enum variant '" + selector->name + "." + m.name + "'; เพิ่ม case หรือ default", n->line);
    }
    return;
  }
  if (selector->k == BOOL) {
    bool hasFalse = false, hasTrue = false;
    for (const auto &cs : n->cases) if (!cs.guard) {
      for (const auto &v : cs.vals) {
        int64_t x = 0;
        if (constEval(v.get(), x)) { if (x == 0) hasFalse = true; if (x == 1) hasTrue = true; }
      }
    }
    if (!hasFalse || !hasTrue) err(expression ? "match expression ที่ใช้ boolean ต้องครอบคลุม true และ false หรือมี default" : "match ที่ใช้ boolean ต้องครอบคลุม true และ false หรือมี default", n->line);
    return;
  }
  err("match expression ต้องครอบคลุมทุกกรณี หรือมี default", n->line);
}

void emitMatchBindings(const Case &cs, const V &selector) {
  if (cs.variantName.empty()) return;
  std::string enumName = matchEnumNameForSelector(cs.variantEnum, selector.t, curLine);
  size_t variantIndex = 0;
  enumMember(enums[enumName], cs.variantName, &variantIndex);
  const auto &types = enums[enumName].payloadTypes[variantIndex];
  for (size_t bi = 0; bi < types.size(); ++bi) {
    const std::string &binding = cs.bindings[bi];
    if (binding == "_") continue;
    V value = decodeEnumPayload(enumName, selector.v, bi, types[bi]);
    std::string slot = alloca_(types[bi]);
    storeRaw(slot, types[bi], value);
    Var &v = declVar(binding, types[bi], "var"); v.slot = slot; regCleanup(v);
  }
}

T validateMatchPatterns(Node *n, const V &sel) {
  const bool payloadEnum = sel.t->k == ENUM && sel.t->payloadEnum;
  if (!(isNum(sel.t) || sel.t->k == STR || sel.t->k == ENUM))
    err("match รองรับ selector เป็น scalar, enum หรือ string", n->line);
  struct MatchInterval { int64_t lo, hi; bool guarded; };
  std::vector<MatchInterval> integerIntervals;
  // Repeated patterns are useful when earlier alternatives have guards. An
  // earlier unguarded alternative, however, makes every later copy unreachable.
  std::map<std::string, bool> stringPatterns, enumVariants;
  bool sawUnconditionalWildcard = false;
  for (const auto &cs : n->cases) {
    const bool guarded = static_cast<bool>(cs.guard);
    if (sawUnconditionalWildcard)
      err("match case หลัง unguarded wildcard (_) ไม่สามารถเข้าถึงได้", n->line);
    if (cs.wildcard) {
      if (!cs.variantName.empty() || !cs.vals.empty() || !cs.ranges.empty())
        err("wildcard (_) ห้ามผสมกับ pattern อื่นใน case เดียวกัน", n->line);
      if (!guarded) sawUnconditionalWildcard = true;
      continue;
    }
    if (!cs.variantName.empty()) {
      if (sel.t->k != ENUM) err("enum variant pattern ต้องใช้กับ selector ที่เป็น enum", n->line);
      std::string enumName = matchEnumNameForSelector(cs.variantEnum, sel.t, n->line);
      EnumInfo &ei = enums[enumName];
      size_t variantIndex = 0;
      const EnumMember *em = enumMember(ei, cs.variantName, &variantIndex);
      if (!em) err("enum " + enumName + " ไม่มี variant '" + cs.variantName + "'", n->line);
      const std::string key = enumName + "." + cs.variantName;
      auto prior = enumVariants.find(key);
      if (prior != enumVariants.end() && !prior->second) {
        if (!guarded) err("match มี enum variant ซ้ำ: " + key, n->line);
        err("match มี enum variant ที่ไม่สามารถเข้าถึงได้หลัง unguarded case: " + key, n->line);
      }
      enumVariants[key] = guarded;
      const auto &pt = ei.payloadTypes[variantIndex];
      if (cs.bindings.size() != pt.size()) err("pattern " + enumName + "." + cs.variantName + " ต้องมี binding " + std::to_string(pt.size()) + " ตัว แต่ได้รับ " + std::to_string(cs.bindings.size()), n->line);
      std::set<std::string> names;
      for (const auto &binding : cs.bindings) if (binding != "_" && !names.insert(binding).second)
        err("ชื่อ binding ซ้ำใน enum pattern: " + binding, n->line);
      if (!cs.vals.empty() || !cs.ranges.empty()) err("enum variant pattern ห้ามผสมกับ literal/range ใน case เดียวกัน", n->line);
      continue;
    }
    if (payloadEnum) err("payload enum ต้อง match ด้วย variant pattern เช่น case(Choice.Some(value))", n->line);
    for (const auto &v : cs.vals) {
      if (!isMatchLiteral(v.get())) err("match case ต้องเป็น literal, enum member หรือ const ที่ compile-time ประเมินได้", v ? v->line : n->line);
      if (v->k == NK::StrLit) {
        auto prior = stringPatterns.find(v->s);
        if (prior != stringPatterns.end() && !prior->second) {
          if (!guarded) err("match มี string pattern ซ้ำ: \"" + v->s + "\"", v->line);
          err("match มี string pattern ที่ไม่สามารถเข้าถึงได้หลัง unguarded case: \"" + v->s + "\"", v->line);
        }
        stringPatterns[v->s] = guarded;
      } else {
        int64_t x = 0;
        if (constEval(v.get(), x) && (sel.t->k == INT || sel.t->k == CHAR || sel.t->k == UNI || sel.t->k == ENUM || sel.t->k == BOOL)) {
          for (const auto &iv : integerIntervals) if (!iv.guarded && x >= iv.lo && x <= iv.hi) {
            if (!guarded) err("match มี pattern ตัวเลขซ้ำหรือทับซ้อน", v->line);
            err("match มี pattern ตัวเลขที่ไม่สามารถเข้าถึงได้หลัง unguarded case", v->line);
          }
          integerIntervals.push_back({x, x, guarded});
        }
      }
    }
    for (const auto &r : cs.ranges) {
      if (!(sel.t->k == INT || sel.t->k == CHAR || sel.t->k == UNI)) err("match range ใช้ได้กับ integer/char/unichar selector เท่านั้น", r.lo ? r.lo->line : n->line);
      int64_t lo = 0, hi = 0;
      if (!constEval(r.lo.get(), lo) || !constEval(r.hi.get(), hi)) err("ขอบเขต match range ต้องเป็น integer constant", r.lo ? r.lo->line : n->line);
      if (lo > hi) err("match range ต้องเรียงจากค่าน้อยไปมาก (low..high)", r.lo->line);
      for (const auto &iv : integerIntervals) if (!iv.guarded && lo <= iv.hi && iv.lo <= hi) {
        if (!guarded) err("match มี range/pattern ตัวเลขทับซ้อนกัน", r.lo->line);
        err("match มี range/pattern ที่ไม่สามารถเข้าถึงได้หลัง unguarded case", r.lo->line);
      }
      integerIntervals.push_back({lo, hi, guarded});
    }
  }
  if (sawUnconditionalWildcard && n->deflt)
    err("match default หลัง unguarded wildcard (_) ไม่สามารถเข้าถึงได้", n->line);
  return sel.t;
}

void stmtMatch(Node *n) {
  V sel = expr(n->c[0].get());
  borrow(sel); // keep an owned selector alive across the decision chain
  const bool payloadEnum = sel.t->k == ENUM && sel.t->payloadEnum;
  validateMatchPatterns(n, sel);
  // Enum and boolean selectors have finite domains. Require all variants/
  // boolean values unless a default branch is provided. Integral/string matches
  // retain their optional-default fall-through behavior for compatibility.
  if (sel.t->k == ENUM || sel.t->k == BOOL) validateMatchCoverage(n, sel.t, true);

  std::string en = lbl("match.end");
  std::vector<std::string> caseL(n->cases.size()), testL(n->cases.size());
  for (size_t i = 0; i < n->cases.size(); ++i) { caseL[i] = lbl("match.case"); testL[i] = lbl("match.test"); }
  std::string defL = n->deflt ? lbl("match.default") : en;
  if (!testL.empty()) br(testL[0]); else br(defL);

  for (size_t i = 0; i < n->cases.size(); ++i) {
    placeLabel(testL[i]);
    const Case &cs = n->cases[i];
    std::string fall = (i + 1 < n->cases.size()) ? testL[i + 1] : defL;
    if (cs.wildcard) { br(caseL[i]); continue; }
    if (!cs.variantName.empty()) {
      std::string enumName = matchEnumNameForSelector(cs.variantEnum, sel.t, n->line);
      size_t variantIndex = 0; enumMember(enums[enumName], cs.variantName, &variantIndex);
      std::string tagValue;
      if (payloadEnum) {
        std::string tagAddr = def("getelementptr inbounds " + llty(sel.t) + ", ptr " + sel.v + ", i32 0, i32 0");
        tagValue = def("load i32, ptr " + tagAddr);
      } else tagValue = sel.v;
      std::string cond = def("icmp eq i32 " + tagValue + ", " + std::to_string(variantIndex));
      flushTemps(0); std::string nx = lbl("match.next"); cbr(cond, caseL[i], nx); placeLabel(nx); br(fall);
      continue;
    }
    for (const auto &v : cs.vals) {
      V pv = expr(v.get()); V eq = binop("==", sel, pv, v->line);
      std::string cond = condOf(eq); flushTemps(0);
      std::string nx = lbl("match.next"); cbr(cond, caseL[i], nx); placeLabel(nx);
    }
    for (const auto &r : cs.ranges) {
      V lo = expr(r.lo.get()); V ge = binop(">=", sel, lo, r.lo->line);
      std::string geCond = condOf(ge); flushTemps(0);
      std::string upper = lbl("match.upper"), nx = lbl("match.next"); cbr(geCond, upper, nx); placeLabel(upper);
      V hi = expr(r.hi.get()); V le = binop("<=", sel, hi, r.hi->line);
      std::string leCond = condOf(le); flushTemps(0); cbr(leCond, caseL[i], nx); placeLabel(nx);
    }
    br(fall);
  }

  for (size_t i = 0; i < n->cases.size(); ++i) {
    placeLabel(caseL[i]);
    std::string fall = (i + 1 < n->cases.size()) ? testL[i + 1] : defL;
    loops.push_back({en, "", scopes.size(), "", false, false, false});
    bool hasBindings = !n->cases[i].variantName.empty();
    if (hasBindings) { pushScope(); emitMatchBindings(n->cases[i], sel); }
    if (n->cases[i].guard) {
      size_t guardTemps = temps.size();
      V guard = expr(n->cases[i].guard.get()); std::string gc = condOf(guard);
      flushTemps(guardTemps);
      std::string bodyL = lbl("match.guard.ok"); cbr(gc, bodyL, fall); placeLabel(bodyL);
    }
    stmtBlock(n->cases[i].body.get());
    if (hasBindings) popScope();
    loops.pop_back();
    if (!term) br(en);
  }
  if (n->deflt) {
    placeLabel(defL); loops.push_back({en, "", scopes.size(), "", false, false, false});
    stmtBlock(n->deflt.get()); loops.pop_back(); if (!term) br(en);
  }
  placeLabel(en); flushTemps(0);
}

V matchExpr(Node *n) {
  size_t entryTemps = temps.size();
  V sel = expr(n->c[0].get());
  borrow(sel);
  const size_t selectorTemps = temps.size();
  validateMatchPatterns(n, sel);
  validateMatchCoverage(n, sel.t, true, true);
  const bool payloadEnum = sel.t->k == ENUM && sel.t->payloadEnum;

  std::string endL = lbl("match.expr.end");
  std::vector<std::string> caseL(n->cases.size()), testL(n->cases.size());
  for (size_t i = 0; i < n->cases.size(); ++i) { caseL[i] = lbl("match.expr.case"); testL[i] = lbl("match.expr.test"); }
  std::string defaultL = n->deflt ? lbl("match.expr.default") : lbl("match.expr.invalid");
  if (!testL.empty()) br(testL[0]); else br(defaultL);

  for (size_t i = 0; i < n->cases.size(); ++i) {
    placeLabel(testL[i]);
    const Case &cs = n->cases[i];
    std::string fall = (i + 1 < n->cases.size()) ? testL[i + 1] : defaultL;
    if (cs.wildcard) { br(caseL[i]); continue; }
    if (!cs.variantName.empty()) {
      std::string enumName = matchEnumNameForSelector(cs.variantEnum, sel.t, n->line);
      size_t variantIndex = 0; enumMember(enums[enumName], cs.variantName, &variantIndex);
      std::string tagValue;
      if (payloadEnum) {
        std::string tagAddr = def("getelementptr inbounds " + llty(sel.t) + ", ptr " + sel.v + ", i32 0, i32 0");
        tagValue = def("load i32, ptr " + tagAddr);
      } else tagValue = sel.v;
      std::string cond = def("icmp eq i32 " + tagValue + ", " + std::to_string(variantIndex));
      flushTemps(selectorTemps); std::string nx = lbl("match.expr.next"); cbr(cond, caseL[i], nx); placeLabel(nx); br(fall);
      continue;
    }
    for (const auto &v : cs.vals) {
      V pv = expr(v.get()); V eq = binop("==", sel, pv, v->line);
      std::string cond = condOf(eq); flushTemps(selectorTemps);
      std::string nx = lbl("match.expr.next"); cbr(cond, caseL[i], nx); placeLabel(nx);
    }
    for (const auto &r : cs.ranges) {
      V lo = expr(r.lo.get()); V ge = binop(">=", sel, lo, r.lo->line);
      std::string geCond = condOf(ge); flushTemps(selectorTemps);
      std::string upper = lbl("match.expr.upper"), nx = lbl("match.expr.next"); cbr(geCond, upper, nx); placeLabel(upper);
      V hi = expr(r.hi.get()); V le = binop("<=", sel, hi, r.hi->line);
      std::string leCond = condOf(le); flushTemps(selectorTemps); cbr(leCond, caseL[i], nx); placeLabel(nx);
    }
    br(fall);
  }

  T resultType = nullptr;
  std::string resultSlot;
  auto emitResult = [&](Node *valueNode, bool closeBindings = false) {
    V value = expr(valueNode);
    if (!value.t || value.t->k == VOID || value.t->k == NULLT)
      err("match expression branch ต้องคืนค่าที่มีชนิดชัดเจน", valueNode ? valueNode->line : n->line);
    if (!resultType) { resultType = value.t; resultSlot = alloca_(resultType); }
    else if (!sameT(resultType, value.t))
      err("ชนิดค่าที่คืนจาก match expression ต้องตรงกันทุก branch (เจอ " + tname(resultType) + " และ " + tname(value.t) + ")", valueNode ? valueNode->line : n->line);
    if (needsFree(resultType)) {
      V owned = ownV(value); borrow(owned);
      storeRaw(resultSlot, resultType, owned);
      transferTemp(owned);
    } else storeRaw(resultSlot, resultType, value);
    flushTemps(selectorTemps);
    // The result is now safely stored. Close destructured bindings before the
    // branch terminates; popScope() after the branch would skip cleanup because
    // the current block is already terminated.
    if (closeBindings) {
      emitScopeCleanup(scopes.size() - 1, nullptr);
      scopes.pop_back();
    }
    br(endL);
  };

  for (size_t i = 0; i < n->cases.size(); ++i) {
    placeLabel(caseL[i]);
    const Case &cs = n->cases[i];
    std::string fall = (i + 1 < n->cases.size()) ? testL[i + 1] : defaultL;
    bool hasBindings = !cs.variantName.empty();
    Scope bindingScopeSnapshot;
    if (hasBindings) { pushScope(); emitMatchBindings(cs, sel); bindingScopeSnapshot = scopes.back(); }
    if (cs.guard) {
      size_t guardTemps = temps.size(); V guard = expr(cs.guard.get()); std::string gc = condOf(guard);
      flushTemps(guardTemps);
      std::string bodyL = lbl("match.expr.guard.ok"), guardFailL = lbl("match.expr.guard.fail");
      cbr(gc, bodyL, guardFailL);
      placeLabel(bodyL);
      emitResult(cs.exprBody.get(), hasBindings);
      // A false guard also exits the pattern-binding scope. Recreate its
      // compile-time cleanup description for this alternate CFG edge.
      placeLabel(guardFailL);
      if (hasBindings) {
        scopes.push_back(bindingScopeSnapshot);
        emitScopeCleanup(scopes.size() - 1, nullptr);
        scopes.pop_back();
      }
      br(fall);
    } else {
      emitResult(cs.exprBody.get(), hasBindings);
    }
  }
  if (n->deflt) { placeLabel(defaultL); emitResult(n->deflt.get()); }
  else { placeLabel(defaultL); ins("unreachable"); term = true; }

  placeLabel(endL);
  if (!resultType) err("match expression ไม่มี branch ที่คืนค่า", n->line);
  V out; out.t = resultType;
  if (resultType->k == STRUCT || (resultType->k == ENUM && resultType->payloadEnum)) { out.v = resultSlot; out.owned = needsFree(resultType); }
  else if (needsFree(resultType)) { out.v = def("load ptr, ptr " + resultSlot); out.owned = true; }
  else out.v = def("load " + llty(resultType) + ", ptr " + resultSlot);
  flushTemps(entryTemps);
  borrow(out);
  return out;
}

void stmtSwitch(Node *n) {
  V sel = expr(n->c[0].get()); borrow(sel);
  if (sel.t->k == ENUM && sel.t->payloadEnum)
    err("switch ไม่รองรับ payload enum; ใช้ match กับ variant pattern", n->line);
  std::string en = lbl("sw.end");
  size_t nc = n->cases.size();
  std::vector<std::string> cl(nc);
  for (size_t i = 0; i < nc; i++) cl[i] = lbl("sw.case");
  std::string defL = n->deflt ? lbl("sw.default") : en;
  bool allConst = isIntLike(sel.t) && sel.t->k != BOOL;
  std::vector<std::vector<int64_t>> cv_(nc);
  if (allConst) for (size_t i = 0; i < nc && allConst; i++) for (auto &v : n->cases[i].vals) { int64_t x; if (!constEval(v.get(), x)) { allConst = false; break; } cv_[i].push_back(x); }
  if (allConst) {
    bool w64 = bitsOf(sel.t) == 64;
    T st = w64 ? T_long : T_int;
    std::string sv = conv(sel, st), ty = llty(st), items;
    for (size_t i = 0; i < nc; i++) for (int64_t x : cv_[i]) items += " " + ty + " " + std::to_string(x) + ", label %" + cl[i] + "\n  ";
    ins("switch " + ty + " " + sv + ", label %" + defL + " [\n  " + items + "]");
    term = true;
  } else {
    for (size_t i = 0; i < nc; i++) for (auto &v : n->cases[i].vals) {
      std::string nx = lbl("sw.next");
      V e = binop("==", sel, expr(v.get()), n->line);
      cbr(condOf(e), cl[i], nx);
      placeLabel(nx);
    }
    br(defL);
  }
  for (size_t i = 0; i < nc; i++) {
    placeLabel(cl[i]);
    loops.push_back({en, "", scopes.size(), "", false, false, false});
    stmtBlock(n->cases[i].body.get());
    loops.pop_back();
    if (!term) br(en);
  }
  if (n->deflt) {
    placeLabel(defL);
    loops.push_back({en, "", scopes.size(), "", false, false, false});
    stmtBlock(n->deflt.get());
    loops.pop_back();
    if (!term) br(en);
  }
  placeLabel(en);
  flushTemps(0);
}

// ---------------------------------------------------------------- functions
void emitFunc(FuncInfo &f) {
  if (f.isConstructor) {
    bool hasSuper = constructorHasLeadingSuper(&f, f.node ? f.node->line : 0);
    if (hasSuper) {
      StructInfo &child = structInfo(f.structName, f.node ? f.node->line : 0);
      if (child.parent.empty()) err("class " + child.name + " ไม่มี parent ให้เรียก super(...) ", f.node ? f.node->line : 0);
    }
  }
  cf = &f; body.clear(); allocas.clear(); term = false; curBB = "entry";
  emitRecursionEnter();
  concatTreeCache.clear();   // types are per-instantiation; see isStringConcatTree()
  unsafeDepth = (f.node && f.node->isUnsafe) ? 1 : 0;   // unsafe function = ทั้ง body เป็น unsafe context
  curImports = modImports[f.module];
  scopes.clear(); loops.clear(); temps.clear();
  curModule = f.module;
  Node *fn = f.node;
  curLine = fn->line;
  pushScope();
  std::string params;
  auto addp = [&](const std::string &s) { if (!params.empty()) params += ", "; params += s; };
  if (f.isLambda) {
    addp("ptr %env");
    for (size_t ci = 0; ci < f.caps.size(); ci++) {
      std::string cp = def("getelementptr inbounds " + f.envTy + ", ptr %env, i32 0, i32 " + std::to_string(ci + 3));
      Var &cvv = declVar(f.caps[ci].name, f.caps[ci].ty, "var"); cvv.slot = cp;
    }
  }
  if (f.isMethod && !f.isStatic) {
    addp("ptr %self");
    Var &v = declVar("self", tStruct(f.structName), "var"); v.slot = "%self";
  }
  for (size_t i = 0; i < f.pt.size(); i++) {
    T pt = f.pt[i]; Param &p = fn->params[i];
    std::string nm = "%p" + std::to_string(i);
    if (pt->k == ARR) {
      addp("ptr " + nm + ".d"); addp("i64 " + nm + ".n");
      Var &v = declVar(p.name, pt, "var"); v.slot = nm + ".d"; v.len = nm + ".n";
      if (!f.pref[i] && mutates(fn->c[0].get(), p.name)) {  // ส่งแบบ copy: เขียน array ใน function ต้องไม่กระทบของผู้เรียก
        std::string by = "%pb" + std::to_string(i), cp = "%pc" + std::to_string(i);
        allocas.append("  ").append(by).append(" = mul i64 ").append(nm).append(".n, ")
               .append(std::to_string(sizeOf(pt->el))).append("\n  ").append(cp)
               .append(" = alloca i8, i64 ").append(by).append(", align 16\n");
        ins("call void @llvm.memcpy.p0.p0.i64(ptr " + cp + ", ptr " + nm + ".d, i64 " + by + ", i1 false)");
        v.slot = cp;
      }
    } else if (f.pref[i] || pt->k == STRUCT || (pt->k == ENUM && pt->payloadEnum)) {
      addp("ptr " + nm);
      Var &v = declVar(p.name, pt, "var"); v.slot = nm; v.isParam = true;
    } else {
      addp(llty(pt) + " " + nm);
      std::string slot = alloca_(pt); ins("store " + llty(pt) + " " + nm + ", ptr " + slot);
      Var &v = declVar(p.name, pt, "var"); v.slot = slot; v.isParam = (pt->k == STR || pt->k == LIST || pt->k == DSK || pt->k == FUNC || pt->k == OBJ || pt->k == WEAK);
    }
  }
  bool wasAuto = f.ret->k == AUTOT;
  stmtBlock(fn->c[0].get(), false);
  if (f.ret->k == AUTOT) f.ret = T_void;
  if (!wasAuto && f.ret->k != VOID && !alwaysEnds(fn->c[0].get()))
    err("function '" + f.name + "' ต้อง return ค่า แต่บางเส้นทางจบโดยไม่ return (เพิ่ม return ท้าย function หรือใน else)", fn->line);
  if (!term) {
    flushTemps(0, false); cleanupAll(0, nullptr);
    emitRecursionLeave();
    if (f.ret->k == VOID) ins("ret void"); else ins("ret " + llty(f.ret) + " " + llzero(f.ret));
    term = true;
  }
  scopes.pop_back();
  funcOut.append("define ").append(f.exported ? "" : "internal ").append(llty(f.ret)).append(" ")
          .append(f.sym).append("(").append(params).append(") nounwind {\nentry:\n")
          .append(allocas).append(body).append("}\n\n");
}

void emitStructHelpers(StructInfo &si) {
  std::string st = "%S." + si.name, d, c, f;
  int k = 0;
  auto nm = [&]() { return "%h" + std::to_string(++k); };
  d += "define internal void @drop." + si.name + "(ptr %p) nounwind {\n";
  c += "define internal void @copy." + si.name + "(ptr %d, ptr %s) nounwind {\n";
  c += "  %whole = load " + st + ", ptr %s\n  store " + st + " %whole, ptr %d\n";
  // User destructors are emitted separately from field release. This lets the
  // cycle collector run every destructor before releasing any peer's fields.
  f += "define internal void @finalize." + si.name + "(ptr %p) {\nentry:\n";
  if (si.isClass) {
    for (std::string cls = si.name; !cls.empty() && structs.count(cls); cls = structs[cls].parent) {
      FuncInfo *dtor = structs[cls].destructor;
      if (dtor) f += "  call void " + dtor->sym + "(ptr %p)\n";
    }
  }
  f += "  ret void\n}\n\n";
  // Clear every managed destination before performing any retain/copy that may throw.
  // This makes drop.Struct safe even when a later field copy aborts part-way through.
  for (size_t i = 0; i < si.fields.size(); i++) {
    T ft = si.fields[i].ty; if (!isManaged(ft)) continue;
    std::string pd = nm();
    c += "  " + pd + " = getelementptr inbounds " + st + ", ptr %d, i32 0, i32 " + std::to_string(i) + "\n";
    if (ft->k == STRUCT || (ft->k == ENUM && ft->payloadEnum)) c += "  store " + llty(ft) + " zeroinitializer, ptr " + pd + "\n";
    else c += "  store ptr null, ptr " + pd + "\n";
  }
  for (size_t i = 0; i < si.fields.size(); i++) {
    T ft = si.fields[i].ty; if (!isManaged(ft)) continue;
    std::string idx = std::to_string(i), pd = nm(), ps = nm(), pp = nm();
    d += "  " + pp + " = getelementptr inbounds " + st + ", ptr %p, i32 0, i32 " + idx + "\n";
    c += "  " + pd + " = getelementptr inbounds " + st + ", ptr %d, i32 0, i32 " + idx + "\n  " + ps + " = getelementptr inbounds " + st + ", ptr %s, i32 0, i32 " + idx + "\n";
    if (ft->k == STR || ft->k == LIST || ft->k == DSK) {
      std::string x = nm(), y = nm(), z = nm(); bool s = ft->k == STR, ds = ft->k == DSK;
      d += "  " + x + " = load ptr, ptr " + pp + "\n  call void @" + (s ? "fac_str_free" : ds ? "fac_ds_free" : "fac_list_free") + "(ptr " + x + ")\n";
      c += "  " + y + " = load ptr, ptr " + ps + "\n  " + z + " = call ptr @" + (s ? "fac_str_dup" : ds ? "fac_ds_copy" : "fac_list_copy") + "(ptr " + y + ")\n  store ptr " + z + ", ptr " + pd + "\n";
    } else if (ft->k == OBJ || ft->k == FUNC || ft->k == WEAK) {
      std::string x = nm(), y = nm();
      const char *releaseFn = ft->k == OBJ ? "fac_obj_release" : ft->k == WEAK ? "fac_obj_weak_release" : "fac_closure_release";
      const char *retainFn = ft->k == OBJ ? "fac_obj_retain" : ft->k == WEAK ? "fac_obj_weak_retain" : "fac_closure_retain";
      d += "  " + x + " = load ptr, ptr " + pp + "\n  call void @" + releaseFn + "(ptr " + x + ")\n";
      c += "  " + y + " = load ptr, ptr " + ps + "\n  call void @" + retainFn + "(ptr " + y + ")\n  store ptr " + y + ", ptr " + pd + "\n";
    } else if (ft->k == ENUM && ft->payloadEnum) {
      d += "  call void @drop.enum." + ft->name + "(ptr " + pp + ")\n";
      c += "  call void @copy.enum." + ft->name + "(ptr " + pd + ", ptr " + ps + ")\n";
    } else {
      d += "  call void @drop." + ft->name + "(ptr " + pp + ")\n";
      c += "  call void @copy." + ft->name + "(ptr " + pd + ", ptr " + ps + ")\n";
    }
  }
  d += "  ret void\n}\n\n"; c += "  ret void\n}\n\n";
  // Trace only strong object references stored in class fields. Nested structs
  // are traversed recursively; list/closure/foreign references remain roots.
  std::string tr = "define internal void @trace." + si.name + "(ptr %p) {\nentry:\n";
  for (size_t i = 0; i < si.fields.size(); i++) {
    T ft = si.fields[i].ty;
    if (ft->k != OBJ && ft->k != STRUCT && !(ft->k == ENUM && ft->payloadEnum)) continue;
    std::string pp = nm();
    tr += "  " + pp + " = getelementptr inbounds " + st + ", ptr %p, i32 0, i32 " + std::to_string(i) + "\n";
    if (ft->k == OBJ) {
      std::string v = nm();
      tr += "  " + v + " = load ptr, ptr " + pp + "\n  call void @fac_cycle_visit(ptr " + v + ")\n";
    } else if (ft->k == STRUCT) {
      tr += "  call void @trace." + ft->name + "(ptr " + pp + ")\n";
    } else {
      tr += "  call void @trace.enum." + ft->name + "(ptr " + pp + ")\n";
    }
  }
  tr += "  ret void\n}\n\n";
  helperOut += d + c + f + tr;
}

void emitEnumHelpers(EnumInfo &ei) {
  if (!ei.hasPayload) return;
  const std::string ll = "%E." + ei.name;
  std::string d = "define internal void @drop.enum." + ei.name + "(ptr %p) nounwind {\nentry:\n";
  std::string c = "define internal void @copy.enum." + ei.name + "(ptr %d, ptr %s) {\nentry:\n";
  std::string tr = "define internal void @trace.enum." + ei.name + "(ptr %p) {\nentry:\n";
  int id = 0;
  auto nm = [&]() { return "%e" + std::to_string(++id); };
  auto slot = [&](const std::string &addr, size_t i) { return "getelementptr inbounds " + ll + ", ptr " + addr + ", i32 0, i32 1, i64 " + std::to_string(i); };
  auto isPtrManaged = [](const T &t) { return t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == OBJ || t->k == WEAK; };
  auto releaseFn = [](const T &t) -> const char * {
    switch (t->k) { case STR: return "fac_str_free"; case LIST: return "fac_list_free"; case DSK: return "fac_ds_free";
      case FUNC: return "fac_closure_release"; case OBJ: return "fac_obj_release"; case WEAK: return "fac_obj_weak_release"; default: return ""; }
  };
  auto cloneFn = [](const T &t) -> const char * {
    switch (t->k) { case STR: return "fac_str_dup"; case LIST: return "fac_list_copy"; case DSK: return "fac_ds_copy"; default: return ""; }
  };
  auto boxDrop = [](const T &t) { return t->k == STRUCT ? std::string("@drop.box.struct.") + t->name : std::string("@drop.box.enum.") + t->name; };
  auto boxCopy = [](const T &t) { return t->k == STRUCT ? std::string("@copy.") + t->name : std::string("@copy.enum.") + t->name; };

  std::string tagp = nm(), tag = nm();
  d += "  " + tagp + " = getelementptr inbounds " + ll + ", ptr %p, i32 0, i32 0\n  " + tag + " = load i32, ptr " + tagp + "\n";
  d += "  switch i32 " + tag + ", label %drop.done [";
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) d += " i32 " + std::to_string(vi) + ", label %drop.v" + std::to_string(vi);
  d += " ]\n";
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) {
    d += "drop.v" + std::to_string(vi) + ":\n";
    for (size_t pi = 0; pi < ei.payloadTypes[vi].size(); ++pi) {
      const T &pt = ei.payloadTypes[vi][pi];
      if (!isManaged(pt) && pt->k != STRUCT && !(pt->k == ENUM && pt->payloadEnum)) continue;
      std::string sp = nm(), raw = nm(), ptr = nm();
      d += "  " + sp + " = " + slot("%p", pi) + "\n  " + raw + " = load i64, ptr " + sp + "\n  " + ptr + " = inttoptr i64 " + raw + " to ptr\n";
      if (isPtrManaged(pt)) d += "  call void @" + std::string(releaseFn(pt)) + "(ptr " + ptr + ")\n";
      else if (pt->k == STRUCT || (pt->k == ENUM && pt->payloadEnum)) {
        std::string isnull = nm(), doDrop = "drop.box." + std::to_string(vi) + "." + std::to_string(pi), next = "drop.next." + std::to_string(vi) + "." + std::to_string(pi);
        d += "  " + isnull + " = icmp eq ptr " + ptr + ", null\n  br i1 " + isnull + ", label %" + next + ", label %" + doDrop + "\n";
        d += doDrop + ":\n  call void " + boxDrop(pt) + "(ptr " + ptr + ")\n  br label %" + next + "\n" + next + ":\n";
      }
    }
    d += "  br label %drop.done\n";
  }
  d += "drop.done:\n  store i32 -1, ptr " + tagp + "\n  ret void\n}\n\n";

  std::string stp = nm(), st = nm(), dtp = nm();
  c += "  " + stp + " = getelementptr inbounds " + ll + ", ptr %s, i32 0, i32 0\n  " + st + " = load i32, ptr " + stp + "\n  " + dtp + " = getelementptr inbounds " + ll + ", ptr %d, i32 0, i32 0\n  store i32 " + st + ", ptr " + dtp + "\n";
  for (size_t pi = 0; pi < ei.maxPayload; ++pi) { std::string dp = nm(); c += "  " + dp + " = " + slot("%d", pi) + "\n  store i64 0, ptr " + dp + "\n"; }
  c += "  switch i32 " + st + ", label %copy.done [";
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) c += " i32 " + std::to_string(vi) + ", label %copy.v" + std::to_string(vi);
  c += " ]\n";
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) {
    c += "copy.v" + std::to_string(vi) + ":\n";
    for (size_t pi = 0; pi < ei.payloadTypes[vi].size(); ++pi) {
      const T &pt = ei.payloadTypes[vi][pi];
      std::string sp = nm(), dp = nm(), raw = nm();
      c += "  " + sp + " = " + slot("%s", pi) + "\n  " + dp + " = " + slot("%d", pi) + "\n  " + raw + " = load i64, ptr " + sp + "\n";
      if (isPtrManaged(pt)) {
        std::string ptr = nm(), cp = nm(), enc = nm();
        c += "  " + ptr + " = inttoptr i64 " + raw + " to ptr\n";
        if (pt->k == STR || pt->k == LIST || pt->k == DSK) c += "  " + cp + " = call ptr @" + std::string(cloneFn(pt)) + "(ptr " + ptr + ")\n";
        else {
          c += "  call void @" + std::string(pt->k == OBJ ? "fac_obj_retain" : pt->k == WEAK ? "fac_obj_weak_retain" : "fac_closure_retain") + "(ptr " + ptr + ")\n";
          c += "  " + cp + " = select i1 true, ptr " + ptr + ", ptr null\n";
        }
        c += "  " + enc + " = ptrtoint ptr " + cp + " to i64\n  store i64 " + enc + ", ptr " + dp + "\n";
      } else if (pt->k == STRUCT || (pt->k == ENUM && pt->payloadEnum)) {
        std::string ptr = nm(), isnull = nm(), box = nm(), enc = nm();
        std::string doCopy = "copy.box." + std::to_string(vi) + "." + std::to_string(pi), next = "copy.next." + std::to_string(vi) + "." + std::to_string(pi);
        c += "  " + ptr + " = inttoptr i64 " + raw + " to ptr\n  " + isnull + " = icmp eq ptr " + ptr + ", null\n  br i1 " + isnull + ", label %" + next + ", label %" + doCopy + "\n";
        c += doCopy + ":\n  " + box + " = call ptr @fac_alloc(i64 " + std::to_string(sizeOf(pt)) + ")\n";
        c += "  call void @fac_tmp_push_drop(ptr " + box + ", ptr " + boxDrop(pt) + ")\n  call void " + boxCopy(pt) + "(ptr " + box + ", ptr " + ptr + ")\n  call void @fac_tmp_pop(ptr " + box + ")\n";
        c += "  " + enc + " = ptrtoint ptr " + box + " to i64\n  store i64 " + enc + ", ptr " + dp + "\n  br label %" + next + "\n" + next + ":\n";
      } else c += "  store i64 " + raw + ", ptr " + dp + "\n";
    }
    c += "  br label %copy.done\n";
  }
  c += "copy.done:\n  ret void\n}\n\n";

  std::string ttp = nm(), tt = nm();
  tr += "  " + ttp + " = getelementptr inbounds " + ll + ", ptr %p, i32 0, i32 0\n  " + tt + " = load i32, ptr " + ttp + "\n  switch i32 " + tt + ", label %trace.done [";
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) tr += " i32 " + std::to_string(vi) + ", label %trace.v" + std::to_string(vi);
  tr += " ]\n";
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) {
    tr += "trace.v" + std::to_string(vi) + ":\n";
    for (size_t pi = 0; pi < ei.payloadTypes[vi].size(); ++pi) {
      const T &pt = ei.payloadTypes[vi][pi];
      if (pt->k != OBJ && pt->k != STRUCT && !(pt->k == ENUM && pt->payloadEnum)) continue;
      std::string sp = nm(), raw = nm(), ptr = nm();
      tr += "  " + sp + " = " + slot("%p", pi) + "\n  " + raw + " = load i64, ptr " + sp + "\n  " + ptr + " = inttoptr i64 " + raw + " to ptr\n";
      if (pt->k == OBJ) tr += "  call void @fac_cycle_visit(ptr " + ptr + ")\n";
      else {
        std::string isnull = nm(), visit = "trace.box." + std::to_string(vi) + "." + std::to_string(pi), next = "trace.next." + std::to_string(vi) + "." + std::to_string(pi);
        tr += "  " + isnull + " = icmp eq ptr " + ptr + ", null\n  br i1 " + isnull + ", label %" + next + ", label %" + visit + "\n";
        tr += visit + ":\n  call void " + (pt->k == STRUCT ? "@trace." : "@trace.enum.") + pt->name + "(ptr " + ptr + ")\n  br label %" + next + "\n" + next + ":\n";
      }
    }
    tr += "  br label %trace.done\n";
  }
  tr += "trace.done:\n  ret void\n}\n\n";

  helperOut += d + c + tr;
  for (size_t vi = 0; vi < ei.mem.size(); ++vi) for (const T &pt : ei.payloadTypes[vi]) {
    std::string wrapper;
    if (pt->k == STRUCT) wrapper = "struct." + pt->name;
    else if (pt->k == ENUM && pt->payloadEnum) wrapper = "enum." + pt->name;
    if (wrapper.empty() || !enumBoxDropWrappersEmitted.insert(wrapper).second) continue;
    if (pt->k == STRUCT) helperOut += "define internal void @drop.box.struct." + pt->name + "(ptr %p) {\nentry:\n  call void @drop." + pt->name + "(ptr %p)\n  call void @fac_free(ptr %p)\n  ret void\n}\n\n";
    else helperOut += "define internal void @drop.box.enum." + pt->name + "(ptr %p) {\nentry:\n  call void @drop.enum." + pt->name + "(ptr %p)\n  call void @fac_free(ptr %p)\n  ret void\n}\n\n";
  }
}

// ---------------------------------------------------------------- module
void registerFunc(Node *f, const std::string &module, const std::string &structName) {
  FuncInfo fi; fi.name = f->s; fi.module = module; fi.node = f; fi.structName = structName; fi.isMethod = !structName.empty(); fi.isStatic = f->isStatic; fi.isPrivate = f->isPrivate; fi.isProtected = f->isProtected; fi.isFinal = f->isFinal; fi.isConstructor = f->isConstructor; fi.isDestructor = f->isDestructor; fi.isConst = f->isConst; fi.isConsteval = f->isConsteval;
  fi.sym = structName.empty() ? "@fac." + module + "." + f->s : "@fac.m." + structName + "." + f->s;
  fi.isAbstract = f->isAbstract;
  if (f->isAbstract && structName.empty()) err("abstract ใช้ได้เฉพาะ method ใน class", f->line);
  if (fi.isConsteval && !structName.empty()) err("consteval รุ่น V220 รองรับเฉพาะ free function ไม่รองรับ method", f->line);
  if (fi.isConsteval && (f->isUnsafe || f->isAbstract || f->isExport || f->isConstructor || f->isDestructor)) err("consteval ห้ามใช้ร่วมกับ unsafe/abstract/export/constructor/destructor", f->line);
  if (f->isConst && structName.empty()) err("const method qualifier ใช้ได้เฉพาะ instance method ใน class/interface", f->line);
  if (f->isConst && f->isStatic) err("const method ไม่สามารถเป็น static ได้", f->line);
  curLine = f->line;
  bool gen = f->ts.base == "auto" || !f->typeParams.empty();
  for (auto &p : f->params) if (p.ts.base == "auto") gen = true;
  if (gen) {
    if (fi.isConsteval) err("consteval รุ่น V220 ยังไม่รองรับ generic parameters หรือ auto type", f->line);
    if (!structName.empty() && structs[structName].isInterface) err("generic interface method ยังไม่รองรับ", f->line);
    if (f->isOverride || f->isAbstract) err("generic method ไม่รองรับ override/abstract; ใช้ method ปกติสำหรับ virtual dispatch", f->line);
    fi.generic = true; fi.ret = T_void;
    for (auto &p : f->params) { fi.pt.push_back(T_auto); fi.pref.push_back(p.ref); fi.pn.push_back(p.name); fi.pdef.push_back(p.def.get()); fi.pnoescape.push_back(p.noescape); fi.preadonly.push_back(p.readonly); if (p.variadic) fi.variadic = true; }
    std::string gkey = structName.empty() ? module + "." + f->s : structName + "::" + f->s;
    if (funcs.count(gkey)) err(std::string(structName.empty() ? "generic function '" : "generic method '") + f->s + "' ประกาศซ้ำ", f->line);
    funcs[gkey] = fi; allFuncs.push_back(&funcs[gkey]);
    if (!structName.empty()) structs[structName].methods[f->s] = &funcs[gkey];
    return;
  }
  T r = f->ts.base == "void" && f->ts.cat.empty() ? T_void : resolveType(f->ts, f->line);
  if (r->k == ARR) r = tList(r->el);
  fi.ret = r;
  for (auto &p : f->params) {
    T pt = resolveType(p.ts, f->line);
    fi.pt.push_back(pt); fi.pref.push_back(p.ref); fi.pn.push_back(p.name); fi.pdef.push_back(p.def.get()); fi.pnoescape.push_back(p.noescape); fi.preadonly.push_back(p.readonly);
    if (p.variadic) fi.variadic = true;
  }
  if (fi.isConsteval) {
    if (!isIntLike(fi.ret)) err("consteval return type ต้องเป็น integer/boolean/char/unichar/enum แบบ scalar", f->line);
    if (f->c.empty() || f->params.size() != fi.pt.size()) err("consteval ต้องมี function body และ parameter แบบ scalar", f->line);
    for (size_t i = 0; i < f->params.size(); ++i) {
      const Param &param = f->params[i];
      if (!isIntLike(fi.pt[i]) || param.ref || param.immutableRef || param.variadic || param.def || param.noescape || param.readonly)
        err("consteval parameter '" + param.name + "' ต้องเป็น scalar integer/bool แบบ value และไม่มี default/ref/variadic", f->line);
    }
  }
  if (f->isExport) {  // export: ชื่อ symbol ตรงๆ ให้ C/C++ เรียก Fac ได้
    auto okT = [&](const T &t) { return t->k == INT || t->k == F32 || t->k == F64 || t->k == BOOL || t->k == CHAR || t->k == UNI || t->k == ENUM || t->k == PTR || t->k == OPAQUE; };
    if (!structName.empty() || fi.generic) err("export ใช้กับ function ธรรมดาเท่านั้น", f->line);
    if (fi.ret->k == ENUM && fi.ret->payloadEnum) err("export: payload enum ยังไม่มี C ABI representation", f->line);
    if (!(okT(fi.ret) || fi.ret->k == VOID)) err("export: return type ต้องเป็นตัวเลข/ptr/void (เจอ " + tname(fi.ret) + ")", f->line);
    for (size_t i = 0; i < fi.pt.size(); i++) if ((fi.pt[i]->k == ENUM && fi.pt[i]->payloadEnum) || !okT(fi.pt[i]) || fi.pref[i]) err("export: parameter '" + fi.pn[i] + "' ต้องเป็นตัวเลข/ptr (เจอ " + tname(fi.pt[i]) + ")", f->line);
    fi.exported = true; fi.sym = "@" + f->s;
    for (FuncInfo *e : exportFuncs) if (e->sym == fi.sym) err("export '" + f->s + "' ซ้ำ", f->line);
  }
  if (f->isExtern) {  // FFI: เรียก C/C++ (extern "C") ตรงๆ
    fi.isExtern = true; fi.cvar = f->cvar; fi.sym = "@" + f->csym;
    std::string d = "declare " + (fi.ret->k == STR ? std::string("ptr") : llty(fi.ret)) + " @" + f->csym + "(";
    if (fi.ret->k == STR || fi.ret->k == STRUCT || fi.ret->k == LIST || fi.ret->k == ARR) err("extern: return type ใช้ " + tname(fi.ret) + " ไม่ได้ (ใช้ ptr char แล้วแปลงด้วย cstr(...))", f->line);
    for (size_t i = 0; i < fi.pt.size(); i++) {
      T t = fi.pt[i];
      if (t->k == STRUCT || t->k == FUNC || t->k == LIST || t->k == DSK) err("extern: parameter '" + fi.pn[i] + "' ชนิด " + tname(t) + " ไม่รองรับ (struct ส่งเป็น ptr ด้วย addr(x); callback ใช้ ptr + cfn(f))", f->line);
      d += (i ? ", " : "") + (t->k == STR || t->k == ARR ? std::string("ptr") : llty(t));
    }
    if (fi.cvar) d += fi.pt.empty() ? "..." : ", ...";
    d += ")\n";
    if (std::string(RT_DECLS).find("@" + f->csym + "(") == std::string::npos && !extraDecls.count("@" + f->csym)) { extraDecls.insert("@" + f->csym); globals += d; }
  }
  std::string key = structName.empty() ? module + "." + f->s : structName + "::" + f->s;
  if (funcs.count(key)) {
    if (!structName.empty()) err("method '" + f->s + "' ประกาศซ้ำ", f->line);
    FuncInfo &first = funcs[key];
    if (fi.isConsteval || first.isConsteval)
      err("consteval function ยังไม่รองรับ overload; ใช้ชื่อ function แยกกัน", f->line);
    for (FuncInfo *o : overloads.count(key) ? overloads[key] : std::vector<FuncInfo *>{&first}) {
      bool same = o->pt.size() == fi.pt.size() && o->generic == fi.generic;
      for (size_t i = 0; same && i < fi.pt.size(); i++) if (!fi.generic && !(sameOverloadParamType(o->pt[i], fi.pt[i]) && o->pt[i]->k == fi.pt[i]->k)) same = false;
      if (same) err("function '" + f->s + "' ประกาศซ้ำ (parameter เหมือนกัน)", f->line);
    }
    // Generated external declarations already carry a unique stable C symbol.
    // Do not append the internal FAC overload suffix to that external name.
    const bool generatedExternal = fi.isExtern && f->csym.rfind("facgen_", 0) == 0;
    if (!generatedExternal) fi.sym += "$" + std::to_string(++novl);
    extraFuncs.push_back(fi);
    FuncInfo *np2 = &extraFuncs.back();
    if (!overloads.count(key)) overloads[key].push_back(&first);
    overloads[key].push_back(np2);
    allFuncs.push_back(np2);
    return;
  }
  funcs[key] = fi;
  allFuncs.push_back(&funcs[key]);
  if (fi.exported) exportFuncs.push_back(&funcs[key]);
  if (!structName.empty()) {
    if (f->isDestructor) {
      if (!structs[structName].isClass) err("destructor ใช้ได้เฉพาะใน class", f->line);
      if (funcs[key].isStatic || !funcs[key].pt.empty() || funcs[key].ret->k != VOID) err("destructor ต้องเป็น instance method แบบ void และไม่มี parameter", f->line);
      if (structs[structName].destructor) err("class " + structName + " มี destructor ซ้ำ", f->line);
      structs[structName].destructor = &funcs[key];
    } else structs[structName].methods[f->s] = &funcs[key];
  }
}

std::string ctypeOf(const T &t) {
  switch (t->k) {
    case VOID: return "void"; case F32: return "float"; case F64: return "double"; case BOOL: return "uint8_t"; case CHAR: return "char"; case UNI: return "uint32_t"; case ENUM: return "int32_t";
    case INT: return std::string(t->sg ? "int" : "uint") + std::to_string(t->bits) + "_t";
    default: return "void*";
  }
}
std::string makeHeader(const std::string &guard) {
  std::string h = "/* สร้างโดย facc --emit-header */\n#ifndef " + guard + "\n#define " + guard + "\n#include <stdint.h>\n#ifdef __cplusplus\nextern \"C\" {\n#endif\n";
  h += "void fac_lib_init(void);      /* เรียกก่อนใช้ function อื่น */\nvoid fac_lib_shutdown(void);  /* flush output ก่อนจบ */\n";
  for (FuncInfo *f : exportFuncs) {
    h += ctypeOf(f->ret) + " " + f->node->s + "(";
    for (size_t i = 0; i < f->pt.size(); i++) h += (i ? ", " : "") + ctypeOf(f->pt[i]) + " " + f->pn[i];
    if (f->pt.empty()) h += "void";
    h += ");\n";
  }
  return h + "#ifdef __cplusplus\n}\n#endif\n#endif\n";
}

std::string generate(std::vector<Program *> ps, const std::string &mainModule, bool *hasMain,
                     const fac_hir::SemanticModel *hirModel = nullptr) {
  // HIR-generated declarations are projected into short-lived synthetic AST
  // programs. This keeps the parser-owned source AST immutable while reusing
  // the normal record layout, function registration and LLVM declaration
  // paths. The synthetic Programs and Nodes live until this function returns.
  generatedFunctionSymbols.clear();
  generatedStructNames.clear();
  generatedDeclarationIR.clear();
  std::map<std::string, std::unique_ptr<Program>> generatedProgramStorage;
  if (hirModel) {
    if (!hirModel->validate()) err("internal error: generated declarations require a valid SemanticModel", 0);

    std::map<std::string, Program *> sourcePrograms;
    for (Program *program : ps) {
      if (!program) err("internal error: null Program passed to Codegen", 0);
      if (!sourcePrograms.emplace(program->module, program).second)
        err("generated declaration lowering requires one source Program per module: " + program->module, 0);
    }
    auto generatedProgramFor = [&](const std::string &moduleName) -> Program & {
      auto found = generatedProgramStorage.find(moduleName);
      if (found != generatedProgramStorage.end()) return *found->second;
      auto source = sourcePrograms.find(moduleName);
      if (source == sourcePrograms.end())
        err("generated declaration belongs to a module without a source Program: " + moduleName, 0);
      auto generated = std::make_unique<Program>();
      generated->module = moduleName;
      generated->file = "<generated:" + moduleName + ">";
      generated->imports = source->second->imports;
      generated->importSpecs = source->second->importSpecs;
      generated->aliases = source->second->aliases;
      generated->links = source->second->links;
      Program *raw = generated.get();
      generatedProgramStorage.emplace(moduleName, std::move(generated));
      return *raw;
    };

    std::function<TypeSpec(fac_hir::TypeId, unsigned)> typeSpecFromDescriptor;
    typeSpecFromDescriptor = [&](fac_hir::TypeId typeId, unsigned depth) -> TypeSpec {
      if (typeId == fac_hir::kInvalidType || typeId > hirModel->types.size() || depth > 48)
        err("generated declaration contains an invalid or excessively nested TypeId", 0);
      const fac_hir::TypeDescriptor &descriptor = hirModel->types.get(typeId);
      if (descriptor.hasSize || descriptor.hasSize2)
        err("generated declaration Codegen currently requires explicit fixed-size expressions to be supplied through source AST", 0);
      if (descriptor.category == fac_hir::TypeCategory::Unknown ||
          descriptor.category == fac_hir::TypeCategory::Other ||
          descriptor.category == fac_hir::TypeCategory::Heap)
        err("generated declaration Codegen does not support HIR type category for '" + descriptor.base + "'", 0);
      TypeSpec result;
      result.cat = descriptor.cat;
      result.kind = descriptor.kind;
      // HIR canonicalizes boolean scalars as `bool`; the source parser/backend
      // spelling used by the FAC runtime is `boolean`.
      result.base = descriptor.base == "bool" ? "boolean" : descriptor.base;
      result.base2 = descriptor.base2;
      result.elemObj = descriptor.elemObj;
      result.isVolatile = descriptor.isVolatile;
      result.hasSig = descriptor.hasSignature;
      if (descriptor.category == fac_hir::TypeCategory::Tuple && result.cat.empty()) result.cat = "tuple";
      if (descriptor.category == fac_hir::TypeCategory::Function && result.cat.empty()) result.cat = "func";
      result.genericArgs.reserve(descriptor.genericArguments.size());
      for (fac_hir::TypeId argument : descriptor.genericArguments)
        result.genericArgs.push_back(typeSpecFromDescriptor(argument, depth + 1));
      result.sig.reserve(descriptor.parameters.size());
      for (fac_hir::TypeId parameter : descriptor.parameters)
        result.sig.push_back(typeSpecFromDescriptor(parameter, depth + 1));
      result.sigNoescape = descriptor.noescape;
      result.sigReadonly = descriptor.readonly;
      result.sigLifetimeParams = descriptor.lifetimeParameters;
      result.sigLifetimeOutlives = descriptor.lifetimeOutlives;
      if (descriptor.returnType != fac_hir::kInvalidType)
        result.sigReturnType = std::make_shared<TypeSpec>(typeSpecFromDescriptor(descriptor.returnType, depth + 1));
      return result;
    };
    auto typeSpecFromUse = [&](const fac_hir::TypeUse &use, int line) -> TypeSpec {
      TypeSpec result = typeSpecFromDescriptor(use.type, 0);
      const fac_hir::TypeDescriptor &descriptor = hirModel->types.get(use.type);
      if (descriptor.category == fac_hir::TypeCategory::Named && use.resolvedSymbol != fac_hir::kInvalidSymbol) {
        if (use.resolvedSymbol >= hirModel->declarations.size())
          err("generated declaration has an invalid resolved type SymbolId", line);
        const fac_hir::Declaration &target = hirModel->symbol(use.resolvedSymbol);
        result.base = target.name;
        switch (target.kind) {
          case fac_hir::SymbolKind::Struct: result.cat = "struct"; break;
          case fac_hir::SymbolKind::Class:
          case fac_hir::SymbolKind::Interface: result.cat = "obj"; break;
          case fac_hir::SymbolKind::Enum: result.cat = "enum"; break;
          default: err("generated declaration TypeId does not resolve to a type declaration", line);
        }
      }
      return result;
    };
    auto visibilityFlags = [](const fac_hir::Declaration &declaration, Node &node) {
      node.isPublic = declaration.isPublic;
      node.isPrivate = declaration.isPrivate;
      node.isProtected = declaration.isProtected;
    };
    auto fieldVisibilityFlags = [](const fac_hir::Field &field, Node &node) {
      node.isPublic = field.isPublic;
      node.isPrivate = field.isPrivate;
      node.isProtected = field.isProtected;
      node.isStatic = field.isStatic;
    };
    auto safeManglePart = [](const std::string &value) {
      std::string result;
      for (unsigned char ch : value) result.push_back(std::isalnum(ch) || ch == '_' ? static_cast<char>(ch) : '_');
      while (result.find("__") != std::string::npos) result.replace(result.find("__"), 2, "_");
      if (result.empty()) result = "unnamed";
      if (result.size() > 48) result.resize(48);
      return result;
    };
    auto generatedExternalSymbol = [&](const fac_hir::Declaration &declaration) {
      std::string signature = declaration.module + "::" + declaration.name + "->";
      auto appendTypeKey = [&](auto &&self, fac_hir::TypeId id, unsigned depth) -> void {
        if (id == fac_hir::kInvalidType || id > hirModel->types.size() || depth > 48) {
          signature += "<invalid>";
          return;
        }
        const fac_hir::TypeDescriptor &type = hirModel->types.get(id);
        signature += "{" + std::to_string(static_cast<unsigned>(type.category)) + ":" +
            type.cat + ":" + type.kind + ":" + type.base + ":" + type.base2 + ":";
        for (fac_hir::TypeId argument : type.genericArguments) self(self, argument, depth + 1);
        signature += "|";
        for (fac_hir::TypeId parameter : type.parameters) self(self, parameter, depth + 1);
        signature += "|";
        if (type.returnType != fac_hir::kInvalidType) self(self, type.returnType, depth + 1);
        signature += "}";
      };
      appendTypeKey(appendTypeKey, declaration.returnType.type, 0);
      for (const fac_hir::Parameter &parameter : declaration.parameters) {
        signature += parameter.ref ? "&" : "_";
        signature += parameter.immutableRef ? "c" : "_";
        signature += parameter.variadic ? "v" : "_";
        appendTypeKey(appendTypeKey, parameter.type.type, 0);
      }
      uint64_t hash = UINT64_C(1469598103934665603);
      for (unsigned char ch : signature) { hash ^= ch; hash *= UINT64_C(1099511628211); }
      return "facgen_" + safeManglePart(declaration.module) + "_" +
             safeManglePart(declaration.name) + "_" + std::to_string(hash);
    };

    // Project already-validated immutable typed expressions into ordinary FAC
    // expression AST nodes. This is a structural conversion (never source
    // string parsing); the normal backend type checks still run on the result.
    std::function<NP(const fac_hir::TypedAstRef &, const fac_hir::Declaration &, unsigned)>
        generatedExpressionNode;
    generatedExpressionNode = [&](const fac_hir::TypedAstRef &expression,
                                   const fac_hir::Declaration &owner,
                                   unsigned depth) -> NP {
      if (!expression || depth > 64 || expression->origin != fac_hir::TypedAstOrigin::Generated)
        err("generated function body contains an invalid typed expression", std::max(1, owner.location.line));
      const int line = std::max(1, expression->location.line > 0 ? expression->location.line : owner.location.line);
      auto child = [&](size_t index) -> NP {
        if (index >= expression->children.size())
          err("generated typed expression has an invalid child index", line);
        return generatedExpressionNode(expression->children[index], owner, depth + 1);
      };
      switch (expression->kind) {
        case fac_hir::TypedAstKind::IntLiteral: {
          NP node = std::make_unique<Node>(NK::IntLit, line);
          try { node->iv = std::stoll(expression->spelling); }
          catch (...) { err("generated integer literal is outside the supported range", line); }
          return node;
        }
        case fac_hir::TypedAstKind::FloatLiteral: {
          NP node = std::make_unique<Node>(NK::FloatLit, line);
          try { node->dv = std::stod(expression->spelling); }
          catch (...) { err("generated floating literal is invalid", line); }
          return node;
        }
        case fac_hir::TypedAstKind::CharLiteral: {
          NP node = std::make_unique<Node>(NK::CharLit, line);
          try { node->iv = std::stoll(expression->spelling); }
          catch (...) { err("generated character literal is invalid", line); }
          return node;
        }
        case fac_hir::TypedAstKind::BoolLiteral: {
          NP node = std::make_unique<Node>(NK::BoolLit, line);
          node->b = expression->spelling == "true";
          return node;
        }
        case fac_hir::TypedAstKind::Identifier: {
          if (expression->bindingFunction == fac_hir::kInvalidSymbol ||
              expression->bindingFunction >= hirModel->declarations.size() ||
              expression->bindingFunction != owner.id)
            err("generated identifier is not bound to its owning function", line);
          NP node = std::make_unique<Node>(NK::Ident, line);
          node->s = expression->spelling;
          return node;
        }
        case fac_hir::TypedAstKind::Unary: {
          NP node = std::make_unique<Node>(NK::Unary, line);
          node->s = expression->spelling;
          node->c.push_back(child(0));
          return node;
        }
        case fac_hir::TypedAstKind::Binary: {
          NP node = std::make_unique<Node>(NK::Binary, line);
          node->s = expression->spelling;
          node->c.push_back(child(0));
          node->c.push_back(child(1));
          return node;
        }
        case fac_hir::TypedAstKind::Call: {
          if (expression->resolvedCallee >= hirModel->declarations.size())
            err("generated call has an invalid resolved SymbolId", line);
          const fac_hir::Declaration &callee = hirModel->symbol(expression->resolvedCallee);
          if (callee.module != owner.module || callee.kind != fac_hir::SymbolKind::Function)
            err("generated function bodies currently call functions in the same module only", line);
          NP node = std::make_unique<Node>(NK::Call, line);
          NP calleeName = std::make_unique<Node>(NK::Ident, line);
          calleeName->s = callee.name;
          node->c.push_back(std::move(calleeName));
          for (size_t i = 0; i < expression->children.size(); ++i) node->c.push_back(child(i));
          return node;
        }
        default:
          err("generated function body Codegen V220 does not support this typed-expression kind", line);
      }
      return nullptr;
    };

    // Project the deliberately small generated statement model into normal
    // FAC statement AST nodes. This keeps branch lowering on the existing
    // backend path (including its block scopes and LLVM basic-block logic).
    std::function<NP(const fac_hir::GeneratedFunctionStatement &,
                     const fac_hir::Declaration &, const fac_hir::GeneratedFunctionBody &,
                     unsigned)> generatedStatementNode;
    generatedStatementNode = [&](const fac_hir::GeneratedFunctionStatement &statement,
                                 const fac_hir::Declaration &owner,
                                 const fac_hir::GeneratedFunctionBody &body,
                                 unsigned depth) -> NP {
      const int line = std::max(1, statement.location.line > 0
                                      ? statement.location.line : owner.location.line);
      if (depth > 64)
        err("generated function statement nesting exceeds Codegen V220 limit", line);
      if (statement.kind == fac_hir::GeneratedFunctionStatementKind::AssignLocal) {
        if (statement.localIndex >= body.locals.size())
          err("generated assignment refers to an invalid local index", line);
        NP expressionStatement = std::make_unique<Node>(NK::ExprStmt, line);
        NP assignment = std::make_unique<Node>(NK::Assign, line);
        assignment->s = "=";
        NP target = std::make_unique<Node>(NK::Ident, line);
        target->s = body.locals[statement.localIndex].name;
        assignment->c.push_back(std::move(target));
        assignment->c.push_back(generatedExpressionNode(statement.expression, owner, 0));
        expressionStatement->c.push_back(std::move(assignment));
        return expressionStatement;
      }
      if (statement.kind == fac_hir::GeneratedFunctionStatementKind::IfElse) {
        if (!statement.hasElse)
          err("generated if statement is missing its else branch", line);
        NP conditional = std::make_unique<Node>(NK::If, line);
        conditional->c.push_back(generatedExpressionNode(statement.condition, owner, 0));
        NP thenBlock = std::make_unique<Node>(NK::Block, line);
        for (const fac_hir::GeneratedFunctionStatement &child : statement.thenStatements)
          thenBlock->c.push_back(generatedStatementNode(child, owner, body, depth + 1));
        NP elseBlock = std::make_unique<Node>(NK::Block, line);
        for (const fac_hir::GeneratedFunctionStatement &child : statement.elseStatements)
          elseBlock->c.push_back(generatedStatementNode(child, owner, body, depth + 1));
        conditional->c.push_back(std::move(thenBlock));
        conditional->c.push_back(std::move(elseBlock));
        return conditional;
      }
      err("generated function body contains an unsupported statement kind", line);
      return nullptr;
    };

    std::set<std::string> generatedExternalSymbols;
    for (const fac_hir::Declaration &declaration : hirModel->declarations) {
      if (declaration.origin != fac_hir::DeclarationOrigin::Generated) continue;
      Program &generatedProgram = generatedProgramFor(declaration.module);
      const int line = std::max(1, declaration.location.line);
      if (declaration.kind == fac_hir::SymbolKind::Struct) {
        NP record = std::make_unique<Node>(NK::StructDef, line);
        record->s = declaration.name;
        record->module = declaration.module;
        visibilityFlags(declaration, *record);
        for (const fac_hir::Field &field : declaration.fields) {
          if (field.isStatic)
            err("generated struct Codegen V220 does not support static fields yet: " + declaration.qualifiedName + "." + field.name, line);
          if (field.isProtected)
            err("generated struct Codegen V220 does not support protected fields: " + declaration.qualifiedName + "." + field.name, line);
          NP generatedField = std::make_unique<Node>(NK::VarDecl,
              std::max(1, field.location.line > 0 ? field.location.line : line));
          generatedField->s = field.name;
          generatedField->ts = typeSpecFromUse(field.type, line);
          generatedField->isConst = field.isConst;
          generatedField->isVolatile = hirModel->types.get(field.type.type).isVolatile;
          fieldVisibilityFlags(field, *generatedField);
          if (generatedField->ts.cat == "array")
            err("generated struct field arrays require a source size expression and are not lowered by this V220 backend", generatedField->line);
          record->c.push_back(std::move(generatedField));
        }
        generatedStructNames.push_back(declaration.name);
        generatedProgram.structs.push_back(std::move(record));
        generatedDeclarationIR += "; generated struct " + declaration.qualifiedName + "\n";
      } else if (declaration.kind == fac_hir::SymbolKind::Function) {
        if (declaration.name == "main")
          err("generated function 'main' cannot replace the FAC source entry point", line);
        if (declaration.isProtected)
          err("generated free functions do not support protected visibility", line);
        NP function = std::make_unique<Node>(NK::Func, line);
        function->s = declaration.name;
        function->module = declaration.module;
        function->ts = typeSpecFromUse(declaration.returnType, line);
        function->isPublic = declaration.isPublic;
        function->isPrivate = declaration.isPrivate;
        function->isProtected = declaration.isProtected;
        for (const fac_hir::Parameter &parameter : declaration.parameters) {
          if (parameter.ref || parameter.immutableRef || parameter.variadic ||
              parameter.noescape || parameter.readonly || parameter.hasDefault)
            err("generated function parameters currently require plain value arguments: " + declaration.qualifiedName, line);
          Param generatedParameter;
          generatedParameter.name = parameter.name;
          generatedParameter.ts = typeSpecFromUse(parameter.type, line);
          function->params.push_back(std::move(generatedParameter));
        }
        auto generatedBody = hirModel->generatedFunctionBodies.find(declaration.id);
        if (generatedBody != hirModel->generatedFunctionBodies.end()) {
          function->isExtern = false;
          NP block = std::make_unique<Node>(NK::Block, line);
          for (const fac_hir::GeneratedFunctionLocal &local : generatedBody->second.locals) {
            NP generatedLocal = std::make_unique<Node>(NK::VarDecl,
                std::max(1, local.location.line > 0 ? local.location.line : line));
            generatedLocal->s = local.name;
            generatedLocal->ts = typeSpecFromDescriptor(local.type, 0);
            generatedLocal->ts.kind = "var";
            generatedLocal->isConst = !local.isMutable;
            generatedLocal->c.push_back(generatedExpressionNode(local.initializer, declaration, 0));
            block->c.push_back(std::move(generatedLocal));
          }
          for (const fac_hir::GeneratedFunctionStatement &statement : generatedBody->second.statements)
            block->c.push_back(generatedStatementNode(statement, declaration, generatedBody->second, 0));
          NP returned = std::make_unique<Node>(NK::Return,
              std::max(1, generatedBody->second.location.line > 0 ? generatedBody->second.location.line : line));
          if (generatedBody->second.returnValue)
            returned->c.push_back(generatedExpressionNode(generatedBody->second.returnValue, declaration, 0));
          block->c.push_back(std::move(returned));
          function->c.push_back(std::move(block));
          generatedDeclarationIR += "; generated function body " + declaration.qualifiedName + "\n";
        } else {
          function->isExtern = true;
          const std::string externalSymbol = generatedExternalSymbol(declaration);
          if (!generatedExternalSymbols.insert(externalSymbol).second)
            err("generated external function symbol hash collision: " + externalSymbol, line);
          function->csym = externalSymbol;
          generatedFunctionSymbols[declaration.id] = "@" + externalSymbol;
          generatedDeclarationIR += "; generated external function " + declaration.qualifiedName + " -> @" + externalSymbol + "\n";
        }
        generatedProgram.funcs.push_back(std::move(function));
      } else {
        err("generated declaration kind is not supported by Codegen V220: " + declaration.qualifiedName, line);
      }
    }
    for (auto &entry : generatedProgramStorage) ps.push_back(entry.second.get());
  }

  resetWholeProgramWorkerRegistry();
  progs = ps;
  builtinModules = {"terminal", "string", "math", "random", "time", "memory", "file", "sys", "char", "unichar", "bit", "path", "regex", "json", "thread", "mutex", "crypto", "graphic", "csv", "net", "tls", "three", "gpu", "simd", "audio", "font", "keyboard", "mouse", "mat4", "tensor", "data", "stats", "metrics", "ml", "nn", "optim", "dataframe", "autograd"};
  for (auto *p : ps) if (p->module != mainModule) userModules.insert(p->module);
  for (auto *p : ps) {
    for (auto &a : p->aliases) aliases[a.first] = a.second;
    modImports[p->module] = std::set<std::string>(p->imports.begin(), p->imports.end());
    for (const ImportSpec &spec : p->importSpecs) {
      if (spec.global) modGlobalImports[p->module].insert(spec.module);
      if (spec.selection == 1) modImportJust[p->module][spec.module] = spec.names;
      else if (spec.selection == 2) modImportWithout[p->module][spec.module] = spec.names;
      if (!spec.alias.empty()) {
        auto &am = modImportAliases[p->module];
        auto it = am.find(spec.alias);
        if (it != am.end() && it->second != spec.module)
          err("import alias '" + spec.alias + "' ชนกัน", spec.line);
        am[spec.alias] = spec.module;
      }
    }
  }
  // Generic records and enums are compiled by monomorphization. Each closed
  // argument list becomes a concrete LLVM type; template declarations never
  // reach ordinary type registration.
  struct GenericTemplate { Program *owner = nullptr; Node *node = nullptr; };
  std::unordered_map<std::string, GenericTemplate> genericTemplates;
  std::unordered_map<std::string, std::string> genericInstantiations;
  genericOrigins.clear();
  std::vector<NP> genericTemplateStorage;
  for (Program *p : ps) {
    std::vector<NP> keepStructs; keepStructs.reserve(p->structs.size());
    for (auto &sd : p->structs) {
      if (!sd->typeParams.empty()) {
        if (genericTemplates.count(sd->s)) err("generic type '" + sd->s + "' ประกาศซ้ำ", sd->line);
        sd->module = p->module;
        genericTemplates[sd->s] = {p, sd.get()};
        genericTemplateStorage.push_back(std::move(sd));
      } else keepStructs.push_back(std::move(sd));
    }
    p->structs = std::move(keepStructs);
    std::vector<NP> keepEnums; keepEnums.reserve(p->enums.size());
    for (auto &en : p->enums) {
      if (!en->typeParams.empty()) {
        if (genericTemplates.count(en->s)) err("generic type '" + en->s + "' ประกาศซ้ำ", en->line);
        en->module = p->module;
        genericTemplates[en->s] = {p, en.get()};
        genericTemplateStorage.push_back(std::move(en));
      } else keepEnums.push_back(std::move(en));
    }
    p->enums = std::move(keepEnums);
  }
  for (Program *p : ps) {
    for (const auto &sd : p->structs) if (genericTemplates.count(sd->s)) err("type '" + sd->s + "' ชนกับ generic declaration", sd->line);
    for (const auto &en : p->enums) if (genericTemplates.count(en->s)) err("enum '" + en->s + "' ชนกับ generic declaration", en->line);
  }
  auto cleanMangle = [](std::string x) {
    for (char &ch : x) if (!(std::isalnum((unsigned char)ch) || ch == '_')) ch = '_';
    while (x.find("__") != std::string::npos) x.replace(x.find("__"), 2, "_");
    if (x.empty()) x = "type";
    return x;
  };
  std::function<std::string(const TypeSpec &)> typeSpecMangle = [&](const TypeSpec &ts) {
    if (ts.isConstValue) return std::string("const_i64_") + std::to_string(ts.constValue);
    std::string x;
    if (!ts.cat.empty()) x += ts.cat + "_";
    if (!ts.kind.empty() && ts.kind != "var") x += ts.kind + "_";
    x += ts.base;
    if (!ts.base2.empty()) x += "_" + ts.base2;
    if (ts.sigReturnType) x += "_ret_" + typeSpecMangle(*ts.sigReturnType);
    for (size_t i = 0; i < ts.sig.size(); ++i) {
      x += "_arg_" + typeSpecMangle(ts.sig[i]);
      if (i < ts.sigNoescape.size() && ts.sigNoescape[i]) x += "_noescape";
      if (i < ts.sigReadonly.size() && ts.sigReadonly[i]) x += "_readonly";
    }
    if (!ts.sigLifetimeParams.empty()) {
      x += "_lifetimes_" + std::to_string(ts.sigLifetimeParams.size());
      for (const auto &edge : ts.sigLifetimeOutlives)
        x += "_outlives_" + std::to_string(edge.first) + "_" + std::to_string(edge.second);
      if (ts.sigReturnType) x += "_retlife_" + std::to_string(ts.sigReturnType->lifetimeParamIndex);
      for (const auto &a : ts.sig) x += "_arglife_" + std::to_string(a.lifetimeParamIndex);
    }
    for (const auto &a : ts.genericArgs) x += "_of_" + typeSpecMangle(a);
    return cleanMangle(x);
  };
  std::function<std::string(const std::string &, std::vector<TypeSpec> &, int)> instantiateGeneric;
  std::function<void(TypeSpec &, int)> normalizeTypeSpec;
  std::function<void(Node *, int)> normalizeNode;
  std::function<void(TypeSpec &, const std::map<std::string, TypeSpec> &, int)> substituteType;
  substituteType = [&](TypeSpec &ts, const std::map<std::string, TypeSpec> &bindings, int line) {
    for (auto &a : ts.sig) substituteType(a, bindings, line);
    if (ts.sigReturnType) substituteType(*ts.sigReturnType, bindings, line);
    for (auto &a : ts.genericArgs) substituteType(a, bindings, line);
    auto it = bindings.find(ts.base);
    if (it != bindings.end()) {
      TypeSpec actual = cloneTypeSpec(it->second);
      if (ts.cat == "list" || ts.cat == "array" || ts.cat == "arraylist" || ts.cat == "hashmap" ||
          ts.cat == "hashset" || ts.cat == "tree" || ts.cat == "graph" || ts.cat == "linked" ||
          ts.cat == "stack" || ts.cat == "queue" || ts.cat == "heap" || ts.cat == "maxheap" ||
          ts.cat == "trie" || ts.cat == "matrix") {
        if (actual.cat == "obj") { ts.elemObj = true; ts.base = actual.base; }
        else { ts.base = actual.base; if (!actual.kind.empty() && (ts.kind.empty() || ts.kind == "var")) ts.kind = actual.kind; }
      } else if (ts.kind == "ptr" && ts.cat.empty()) {
        ts.base = actual.base;
        if (!actual.cat.empty()) ts.cat = actual.cat;
      } else {
        std::string declaredKind = ts.kind;
        ts = std::move(actual);
        if (!declaredKind.empty() && declaredKind != "var" && (ts.kind.empty() || ts.kind == "var")) ts.kind = declaredKind;
      }
    }
    auto it2 = bindings.find(ts.base2);
    if (it2 != bindings.end()) {
      if (!it2->second.cat.empty()) err("generic hashmap key/value ต้องใช้ type argument ที่ไม่ใช่ obj/struct wrapper", line);
      ts.base2 = it2->second.base;
    }
  };
  normalizeTypeSpec = [&](TypeSpec &ts, int line) {
    for (auto &a : ts.sig) normalizeTypeSpec(a, line);
    if (ts.sigReturnType) normalizeTypeSpec(*ts.sigReturnType, line);
    for (auto &a : ts.genericArgs) normalizeTypeSpec(a, line);
    if (!ts.genericArgs.empty()) {
      // A generic function template may contain a dependent value argument,
      // e.g. FixedBuffer<int, (N)>. Keep that type expression pending until
      // function specialization substitutes N; concrete call sites still
      // materialize it through instantiateGeneric below.
      bool dependentConstArgument = false;
      for (const TypeSpec &argument : ts.genericArgs) {
        if (argument.constExpr) {
          int64_t ignored = 0;
          if (!constEval(argument.constExpr.get(), ignored)) dependentConstArgument = true;
        }
      }
      if (dependentConstArgument) return;
      std::string concrete = instantiateGeneric(ts.base, ts.genericArgs, line);
      ts.base = concrete; ts.genericArgs.clear();
    } else if (!ts.base.empty()) {
      std::string canonical = canonicalModulePath(ts.base);
      size_t d = canonical.rfind('.');
      std::string simple = d == std::string::npos ? canonical : canonical.substr(d + 1);
      auto gt = genericTemplates.find(simple);
      if (gt != genericTemplates.end()) {
        const Node *genericNode = gt->second.node;
        bool allDefaulted = genericNode &&
            genericNode->genericHasDefault.size() == genericNode->typeParams.size();
        if (allDefaulted)
          for (bool hasDefault : genericNode->genericHasDefault) allDefaulted = allDefaulted && hasDefault;
        if (allDefaulted) {
          std::vector<TypeSpec> defaultArguments;
          ts.base = instantiateGeneric(ts.base, defaultArguments, line);
        } else {
          err("generic type '" + simple + "' ต้องระบุ type argument หรือประกาศ default ให้ครบ เช่น " + simple + "<int>", line);
        }
      }
    }
  };
  normalizeNode = [&](Node *n, int line) {
    if (!n) return;
    if (n->k == NK::Call && !n->c.empty()) {
      Node *callee = n->c[0].get();
      if (callee && callee->k == NK::Ident && !callee->ts.genericArgs.empty()) {
        // These compiler intrinsics take a type argument rather than a runtime
        // value. Preserve the argument on the call node so the same resolved
        // TypeSpec is visible to code generation and the constant evaluator.
        const bool isTypeQuery = callee->s == "typeOf" || callee->s == "sizeof" || callee->s == "alignof" ||
                                 callee->s == "fieldCount" || callee->s == "fieldName" ||
                                 callee->s == "fieldType" || callee->s == "fieldOffset";
        bool namesGenericFunction = false;
        if (!isTypeQuery) {
          for (Program *program : ps) {
            if (program->module != curModule) continue;
            for (const auto &function : program->funcs) {
              if (function->s == callee->s && !function->typeParams.empty()) {
                namesGenericFunction = true;
                break;
              }
            }
            if (namesGenericFunction) break;
          }
        }
        if (isTypeQuery || namesGenericFunction) {
          if (!callee->explicitTypeArgs.empty()) err("generic/type-query arguments ระบุซ้ำ", n->line);
          callee->explicitTypeArgs = std::move(callee->ts.genericArgs);
          callee->ts.genericArgs.clear();
        }
      }
    }
    bool wasGenericTypeName = !n->ts.genericArgs.empty();
    normalizeTypeSpec(n->ts, n->line ? n->line : line);
    if (wasGenericTypeName && (n->k == NK::Ident || n->k == NK::Member)) {
      // Collapse `Module.Generic<T>` to its specialized type symbol before
      // the following `.Variant(...)` / `.staticMethod(...)` postfix is emitted.
      n->k = NK::Ident; n->s = n->ts.base; n->c.clear();
    }
    normalizeTypeSpec(n->parentType, n->line ? n->line : line);
    for (auto &it : n->implTypeSpecs) normalizeTypeSpec(it, n->line ? n->line : line);
    for (auto &arg : n->explicitTypeArgs) normalizeTypeSpec(arg, n->line ? n->line : line);
    for (auto &bound : n->genericBounds) {
      if (std::find(n->constGenericParams.begin(), n->constGenericParams.end(), bound.param) == n->constGenericParams.end())
        normalizeTypeSpec(bound.bound, n->line ? n->line : line);
    }
    if (!n->implTypeSpecs.empty()) {
      n->impls.clear();
      for (const auto &it : n->implTypeSpecs) n->impls.push_back(it.base);
    }
    if (!n->parentType.base.empty()) n->parent = n->parentType.base;
    if (n->k == NK::New && !n->ts.base.empty()) n->s = n->ts.base;
    for (auto &pa : n->params) { normalizeTypeSpec(pa.ts, n->line ? n->line : line); normalizeNode(pa.def.get(), line); }
    for (auto &c : n->c) normalizeNode(c.get(), line);
    for (auto &m : n->methods) normalizeNode(m.get(), line);
    for (auto &cs : n->cases) { for (auto &v : cs.vals) normalizeNode(v.get(), line); normalizeNode(cs.body.get(), line); }
    normalizeNode(n->deflt.get(), line);
  };
  normalizeGenericNode = normalizeNode;
  // Box<T> whose field is Box<Box<T>> expands forever (Box<int> -> Box<Box<int>> -> ...): bound the nesting of type arguments and the
  // number of instantiations, like C++'s template depth limit, instead of overflowing the compiler's stack
  std::function<int(const TypeSpec &)> typeSpecDepth = [&](const TypeSpec &t) -> int {
    int d = 0; for (auto &g : t.genericArgs) d = std::max(d, typeSpecDepth(g)); return d + 1;
  };
  int genericInstantiationCount = 0, genericNesting = 0;
  struct NestCount { int &c; explicit NestCount(int &x) : c(x) { ++c; } ~NestCount() { --c; } };
  instantiateGeneric = [&](const std::string &rawBase, std::vector<TypeSpec> &args, int line) -> std::string {
    // Specializations are published under a mangled name (Box$Box$int) and their fields refer to that name, so the *argument* depth stays 1:
    // the real recursion is instantiate -> resolve fields -> instantiate ..., which is what the nesting counter bounds.
    NestCount nesting(genericNesting);
    {
      int depth = 0; for (auto &a : args) depth = std::max(depth, typeSpecDepth(a));
      if (depth > 24 || genericNesting > 64)
        err("generic '" + rawBase + "' ขยายไม่รู้จบหรือซ้อนลึกเกินไป (ซ้อนเกิน 64 ชั้น หรือ instantiate เกิน 5000 แบบ): เช็กว่า field/method ไม่สร้าง generic type ที่ใหญ่ขึ้นเรื่อย ๆ เช่น Box<T> ที่มี Box<Box<T>>", line);
    }
    std::string savedModule = curModule; auto savedImports = curImports;
    std::string canonical = canonicalModulePath(rawBase);
    size_t dot = canonical.rfind('.');
    std::string base = dot == std::string::npos ? canonical : canonical.substr(dot + 1);
    auto ti = genericTemplates.find(base);
    if (ti == genericTemplates.end()) err("ไม่พบ generic type '" + rawBase + "'", line);
    GenericTemplate templ = ti->second;
    if (dot != std::string::npos && canonical.substr(0, dot) != templ.owner->module)
      err("generic type '" + rawBase + "' ไม่ตรงกับ module " + templ.owner->module, line);
    curModule = templ.owner->module; curImports = modImports[curModule];
    std::vector<bool> hasDefaults = templ.node->genericHasDefault;
    if (hasDefaults.size() != templ.node->typeParams.size())
      hasDefaults.assign(templ.node->typeParams.size(), false);
    std::vector<bool> supplied;
    std::string namedArgumentDiagnostic;
    if (!orderNamedGenericArgumentsWithDefaults(args, templ.node->typeParams,
                                                 hasDefaults, supplied,
                                                 namedArgumentDiagnostic))
      err("generic type '" + base + "': " + namedArgumentDiagnostic, line);
    const std::set<std::string> constParamNames(templ.node->constGenericParams.begin(),
                                                templ.node->constGenericParams.end());
    std::map<std::string, TypeSpec> defaultTypeBindings;
    std::map<std::string, int64_t> defaultConstBindings;
    std::function<void(Node *)> substituteDefaultConstExpr = [&](Node *expression) {
      if (!expression) return;
      if (expression->k == NK::Ident) {
        auto value = defaultConstBindings.find(expression->s);
        if (value != defaultConstBindings.end()) {
          expression->k = NK::IntLit; expression->iv = value->second; expression->s.clear();
          expression->c.clear(); return;
        }
      }
      for (auto &child : expression->c) substituteDefaultConstExpr(child.get());
    };
    std::function<void(TypeSpec &)> substituteDefaultConstType = [&](TypeSpec &type) {
      substituteDefaultConstExpr(type.size.get());
      substituteDefaultConstExpr(type.size2.get());
      for (auto &argument : type.genericArgs) substituteDefaultConstType(argument);
      for (auto &parameter : type.sig) substituteDefaultConstType(parameter);
      if (type.sigReturnType) substituteDefaultConstType(*type.sigReturnType);
      if (type.constExpr) substituteDefaultConstExpr(type.constExpr.get());
    };
    for (size_t i = 0; i < args.size(); ++i) {
      const std::string &parameter = templ.node->typeParams[i];
      const bool expectsConst = constParamNames.count(parameter) != 0;
      TypeSpec &argument = args[i];
      if (!supplied[i]) {
        if (!hasDefaults[i])
          err("generic type '" + base + "' ไม่มี default สำหรับ parameter '" + parameter + "'", line);
        argument = cloneTypeSpec(templ.node->genericDefaults[i]);
        if (expectsConst) {
          if (argument.constExpr) substituteDefaultConstExpr(argument.constExpr.get());
        } else {
          substituteType(argument, defaultTypeBindings, line);
          substituteDefaultConstType(argument);
          normalizeTypeSpec(argument, line);
        }
      }
      if (expectsConst) {
        if (!argument.isConstValue && argument.constExpr) {
          int64_t evaluated = 0;
          substituteDefaultConstExpr(argument.constExpr.get());
          if (!constEval(argument.constExpr.get(), evaluated))
            err("const generic argument/default ต้องเป็น integer constant expression ที่ประเมินได้โดยไม่มี overflow หรือ undefined operation", line);
          argument.isConstValue = true;
          argument.constValue = evaluated;
          argument.constExpr.reset();
        }
        if (!argument.isConstValue)
          err("generic parameter '" + parameter + "' ต้องเป็น const int argument เช่น " + base + "<int, (2 * 8)>", line);
        for (const GenericBound &bound : templ.node->genericBounds) {
          if (bound.param != parameter) continue;
          if (!satisfiesConstGenericConstraint(bound.bound.base, argument.constValue))
            err("const generic constraint " + bound.param + ": " + bound.bound.base +
                " ไม่ผ่านสำหรับค่า " + std::to_string(argument.constValue), line);
        }
        defaultConstBindings[parameter] = argument.constValue;
        continue;
      }
      if (argument.isConstValue || argument.constExpr)
        err("generic parameter '" + parameter + "' ต้องเป็น type argument ไม่ใช่ const value", line);
      normalizeTypeSpec(argument, line);
      if (argument.base.empty() || argument.base == "void" || argument.base == "auto" || argument.base == "null" || argument.cat == "tuple" || argument.cat == "func")
        err("generic type argument ต้องเป็น concrete value type (ห้ามใช้ void/auto/null/function/tuple)", line);
      defaultTypeBindings[parameter] = cloneTypeSpec(argument);
    }
    std::string key = base + "<";
    for (size_t i = 0; i < args.size(); i++) key += (i ? "," : "") + typeSpecMangle(args[i]);
    key += ">";
    auto hit = genericInstantiations.find(key);
    if (hit != genericInstantiations.end()) { curModule = savedModule; curImports = std::move(savedImports); return hit->second; }
    // The 5,000 ceiling limits distinct materialized specializations, not
    // references to a specialization already present in the cache.
    if (genericInstantiationCount >= 5000)
      err("generic '" + rawBase + "' ขยายไม่รู้จบหรือซ้อนลึกเกินไป (ซ้อนเกิน 64 ชั้น หรือ instantiate เกิน 5000 แบบ): เช็กว่า field/method ไม่สร้าง generic type ที่ใหญ่ขึ้นเรื่อย ๆ เช่น Box<T> ที่มี Box<Box<T>>", line);
    ++genericInstantiationCount;
    std::string specName = base + "$";
    for (size_t i = 0; i < args.size(); i++) specName += (i ? "$" : "") + typeSpecMangle(args[i]);
    if (structs.count(specName)) err("ชื่อ generic specialization ชนกับ type ที่มีอยู่: " + specName, line);
    genericInstantiations[key] = specName; // publish before walking recursive fields/methods
    genericOrigins[specName] = base;
    NP clone = cloneNode(templ.node);
    clone->s = specName; clone->module = templ.owner->module;
    clone->genericAppliedNames = templ.node->typeParams;
    clone->genericAppliedArgs.clear();
    for (const auto &a : args) clone->genericAppliedArgs.push_back(cloneTypeSpec(a));
    clone->typeParams.clear();
    clone->constGenericParams.clear();
    std::map<std::string, TypeSpec> bindings;
    std::map<std::string, int64_t> constBindings;
    for (size_t i = 0; i < args.size(); i++) {
      const std::string &parameter = templ.node->typeParams[i];
      if (constParamNames.count(parameter)) constBindings[parameter] = args[i].constValue;
      else bindings[parameter] = cloneTypeSpec(args[i]);
    }
    // Substitute const parameters in every expression-bearing part of the
    // cloned declaration before resolving fields/layout. The evaluator then
    // sees ordinary integer literals and retains its overflow/bounds checks.
    std::function<void(TypeSpec &)> substituteConstType;
    std::function<void(Node *)> substituteConstExpr = [&](Node *x) {
      if (!x) return;
      if (x->k == NK::Ident) {
        auto value = constBindings.find(x->s);
        if (value != constBindings.end()) {
          x->k = NK::IntLit; x->iv = value->second; x->s.clear();
          x->c.clear(); x->params.clear(); x->members.clear(); x->cases.clear();
          x->deflt.reset(); x->methods.clear();
          return;
        }
      }
      substituteConstType(x->ts);
      substituteConstType(x->parentType);
      for (auto &it : x->implTypeSpecs) substituteConstType(it);
      for (auto &arg : x->explicitTypeArgs) substituteConstType(arg);
      for (auto &bound : x->genericBounds) {
        if (std::find(x->constGenericParams.begin(), x->constGenericParams.end(), bound.param) == x->constGenericParams.end())
          substituteConstType(bound.bound);
      }
      for (auto &param : x->params) {
        substituteConstType(param.ts);
        substituteConstExpr(param.def.get());
      }
      for (auto &member : x->members)
        for (auto &payload : member.payloadTypes) substituteConstType(payload);
      for (auto &child : x->c) substituteConstExpr(child.get());
      for (auto &method : x->methods) substituteConstExpr(method.get());
      for (auto &cs : x->cases) {
        for (auto &value : cs.vals) substituteConstExpr(value.get());
        substituteConstExpr(cs.guard.get());
        substituteConstExpr(cs.body.get());
        substituteConstExpr(cs.exprBody.get());
      }
      substituteConstExpr(x->deflt.get());
    };
    substituteConstType = [&](TypeSpec &type) {
      substituteConstExpr(type.size.get());
      substituteConstExpr(type.size2.get());
      for (auto &arg : type.genericArgs) substituteConstType(arg);
      for (auto &param : type.sig) substituteConstType(param);
      if (type.sigReturnType) substituteConstType(*type.sigReturnType);
    };
    substituteConstExpr(clone.get());
    std::function<void(Node *)> substituteNode = [&](Node *x) {
      if (!x) return;
      if (bindings.count(x->ts.base) || bindings.count(x->ts.base2)) x->genericSubstituted = true;
      substituteType(x->ts, bindings, x->line);
      substituteType(x->parentType, bindings, x->line);
      for (auto &it : x->implTypeSpecs) substituteType(it, bindings, x->line);
      for (auto &bound : x->genericBounds) {
        if (std::find(x->constGenericParams.begin(), x->constGenericParams.end(), bound.param) == x->constGenericParams.end())
          substituteType(bound.bound, bindings, x->line);
      }
      for (auto &arg : x->explicitTypeArgs) substituteType(arg, bindings, x->line);
      for (auto &pa : x->params) { substituteType(pa.ts, bindings, x->line); substituteNode(pa.def.get()); }
      for (auto &member : x->members) for (auto &payload : member.payloadTypes) substituteType(payload, bindings, x->line);
      for (auto &c : x->c) substituteNode(c.get());
      for (auto &m : x->methods) substituteNode(m.get());
      for (auto &cs : x->cases) { for (auto &v : cs.vals) substituteNode(v.get()); substituteNode(cs.body.get()); }
      substituteNode(x->deflt.get());
    };
    substituteNode(clone.get());
    Node *specialized = clone.get();
    if (specialized->k == NK::EnumDef) {
      // Payload type arguments may themselves be aliases or closed generic types.
      for (auto &member : specialized->members)
        for (auto &payload : member.payloadTypes) normalizeTypeSpec(payload, line);
      templ.owner->enums.push_back(std::move(clone));
    } else {
      templ.owner->structs.push_back(std::move(clone));
      normalizeNode(specialized, line); // also materializes generic interfaces and generic parents
    }
    curModule = savedModule; curImports = std::move(savedImports);
    return specName;
  };
  // Lift generic declarations out of the ordinary records, then normalize all
  // concrete type uses found in fields, method signatures/bodies, globals and functions.
  std::vector<std::pair<Program *, Node *>> roots;
  for (Program *p : ps) {
    for (auto &s : p->structs) roots.push_back({p, s.get()});
    for (auto &f : p->funcs) roots.push_back({p, f.get()});
    for (auto &g : p->globals) roots.push_back({p, g.get()});
  }
  for (const auto &root : roots) {
    curModule = root.first->module; curImports = modImports[curModule];
    normalizeNode(root.second, root.second->line);
  }
  auto addEnum = [&](const std::string &name, const std::vector<EnumMember> &m, const std::string &module = std::string(), bool isPublic = true, const Node *sourceNode = nullptr) {
    EnumInfo e; e.name = name; e.module = module; e.isPublic = isPublic;
    auto origin = genericOrigins.find(name);
    if (origin != genericOrigins.end()) e.genericOrigin = origin->second;
    if (sourceNode) for (const auto &a : sourceNode->genericAppliedArgs) e.genericAppliedArgs.push_back(cloneTypeSpec(a));
    for (const auto &source : m) { EnumMember copy; copy.name = source.name; copy.val = source.val; copy.str = source.str; for (const auto &pt : source.payloadTypes) copy.payloadTypes.push_back(cloneTypeSpec(pt)); e.mem.push_back(std::move(copy)); }
    enums[name] = std::move(e);
  };
  auto mem = [](std::initializer_list<const char *> l) { std::vector<EnumMember> v; int64_t i = 0; for (auto s : l) v.push_back({s, i++, s, {}}); return v; };
  addEnum("Type", mem({"Byte", "Short", "Int", "Long", "Ubyte", "Ushort", "Uint", "Ulong", "Float", "Double", "Boolean", "Char", "Unichar", "String", "Ptr", "Struct", "Enum", "None"}));
  addEnum("Kind", mem({"Var", "Ptr", "Dyn", "Heap"}));
  addEnum("DS", mem({"Array", "List", "Arraylist", "Linked", "Hashmap", "Hashset", "Graph", "Tree", "None", "Obj", "Struct", "Enum", "Stack", "Queue", "Heap", "Maxheap", "Trie", "Matrix"}));
  // Normalize generic types nested in enum payloads (for example
  // `enum Envelope { Items(list Option<string>) }`) before resolving layouts.
  // Generic enum specializations created here normalize their own payloads in
  // instantiateGeneric(), so iterate only the declarations present at entry.
  for (Program *p : ps) {
    curModule = p->module; curImports = modImports[curModule];
    const size_t declaredEnums = p->enums.size();
    for (size_t ei = 0; ei < declaredEnums; ++ei)
      for (auto &member : p->enums[ei]->members)
        for (auto &payload : member.payloadTypes) normalizeTypeSpec(payload, p->enums[ei]->line);
  }
  // Predeclare record names and built-in payload records before resolving
  // enum payloads. This permits forward references such as `enum E { Item(P) }`
  // and the standard `Result<T, Error>` while actual field layouts are resolved
  // after every enum's payload shape is known.
  for (const char *vn : {"vec2", "vec3", "vec4"}) {  // type เวกเตอร์ในตัวภาษา (float, layout ตรงกับ C: float[N])
    StructInfo &vs = structs[vn]; vs.name = vn;
    const char *cn[] = {"x", "y", "z", "w"};
    for (int i = 0; i < vecN(vn); i++) vs.fields.push_back({cn[i], T_float, true, vn});
  }
  structs["mat4"].name = "mat4"; structs["mat4"].fields.push_back({"m", tArr(T_float, 16), true, "mat4"});
  structs["Error"].name = "Error";
  structs["Error"].fields = {{"msg", T_str, true, "Error"}, {"code", T_int, true, "Error"}};
  std::map<std::string, Node *> recordNodes;
  for (auto *p : ps) for (auto &s : p->structs) {
    if (structs.count(s->s)) err("struct/class '" + s->s + "' ประกาศซ้ำ (ชื่อภายในต้องไม่ซ้ำข้าม module ในรุ่นนี้)", s->line);
    s->module = p->module;
    StructInfo &si = structs[s->s]; si.name = s->s; si.isClass = s->isClass; si.module = p->module;
    si.isInterface = s->isInterface; si.isAbstract = s->isAbstract; si.isPublic = s->isPublic; si.isFinal = s->isFinal;
    for (auto &in : s->impls) { std::string nm = in; size_t d = nm.rfind('.'); if (d != std::string::npos) nm = nm.substr(d + 1); si.impls.push_back(nm); }
    si.parent = s->parent; if (!si.parent.empty()) { size_t pd = si.parent.rfind('.'); if (pd != std::string::npos) si.parent = si.parent.substr(pd + 1); }
    recordNodes[s->s] = s.get();
  }
  // Register every enum name before resolving payload types so variants may
  // refer to previously declared unit enums regardless of source order.
  for (auto *p : ps) for (auto &e : p->enums) {
    if (enums.count(e->s)) err("enum '" + e->s + "' ประกาศซ้ำ", e->line);
    if (e->members.empty()) err("enum " + e->s + " ต้องมีสมาชิกอย่างน้อยหนึ่งตัว", e->line);
    { std::set<std::string> names; for (const auto &m : e->members) if (!names.insert(m.name).second) err("enum " + e->s + " มี member ซ้ำ: " + m.name, e->line); }
    addEnum(e->s, e->members, p->module, e->isPublic, e.get());
  }
  // Publish payload-enum representation metadata before resolving nested
  // payload types. Otherwise an enum encountered earlier in map order could
  // observe a later generic enum as a unit enum and produce an incompatible
  // Type (i32 versus %E.*) for the same specialized name.
  for (auto &kv : enums) {
    EnumInfo &ei = kv.second;
    ei.hasPayload = false; ei.maxPayload = 0;
    for (size_t vi = 0; vi < ei.mem.size(); ++vi) {
      if (!ei.mem[vi].payloadTypes.empty()) ei.hasPayload = true;
      ei.maxPayload = std::max(ei.maxPayload, ei.mem[vi].payloadTypes.size());
    }
  }
  // Resolve every payload type first. A referenced enum may itself be a
  // payload enum declared later (or earlier) in the module, so nested payload
  // validation must run only after every enum's hasPayload flag is known.
  for (auto &kv : enums) {
    std::string savedModule = curModule; auto savedImports = curImports;
    EnumInfo &ei = kv.second;
    if (!ei.module.empty()) { curModule = ei.module; curImports = modImports[curModule]; }
    auto savedGenericArgs = genericTypeArgsBeingResolved;
    for (const auto &arg : ei.genericAppliedArgs) {
      if (arg.isConstValue) continue;
      std::string n = arg.base; size_t dot = n.rfind('.'); if (dot != std::string::npos) n = n.substr(dot + 1);
      if (!n.empty()) genericTypeArgsBeingResolved.insert(n);
    }
    ei.payloadTypes.resize(ei.mem.size());
    for (size_t vi = 0; vi < ei.mem.size(); ++vi) {
      for (const TypeSpec &pspec : ei.mem[vi].payloadTypes) {
        T pt = resolveType(pspec, 0);
        ei.payloadTypes[vi].push_back(pt);
      }
      if (!ei.payloadTypes[vi].empty()) ei.hasPayload = true;
      ei.maxPayload = std::max(ei.maxPayload, ei.payloadTypes[vi].size());
    }
    genericTypeArgsBeingResolved = std::move(savedGenericArgs);
    curModule = savedModule; curImports = std::move(savedImports);
  }
  for (auto &kv : enums) {
    EnumInfo &ei = kv.second;
    for (size_t vi = 0; vi < ei.payloadTypes.size(); ++vi) {
      for (const T &pt : ei.payloadTypes[vi]) {
        if (pt->k == VOID || pt->k == ARR || pt->k == TUPLE || pt->k == NULLT)
          err("payload enum " + ei.name + "." + ei.mem[vi].name + " ไม่รองรับ " + tname(pt));
        if (!(isNum(pt) || pt->k == PTR || pt->k == OPAQUE || pt->k == ENUM || pt->k == STRUCT || pt->k == STR || pt->k == LIST || pt->k == DSK || pt->k == FUNC || pt->k == OBJ || pt->k == WEAK))
          err("payload enum " + ei.name + "." + ei.mem[vi].name + " ไม่รองรับ payload ชนิด " + tname(pt));
      }
    }
  }
  bool managedChanged = true;
  while (managedChanged) {
    managedChanged = false;
    for (auto &kv : enums) {
      EnumInfo &ei = kv.second;
      if (ei.managed) continue;
      bool managed = false;
      for (const auto &variant : ei.payloadTypes) for (const T &pt : variant) {
        if (pt->k == STR || pt->k == LIST || pt->k == DSK || pt->k == FUNC || pt->k == OBJ || pt->k == WEAK || pt->k == STRUCT ||
            (pt->k == ENUM && pt->payloadEnum && enums.count(pt->name) && enums.at(pt->name).managed)) managed = true;
      }
      if (managed) { ei.managed = true; managedChanged = true; }
    }
  }
  std::set<std::string> resolvingRecords, resolvedRecords;
  std::function<void(Node *)> resolveRecord = [&](Node *s) {
    std::string savedModule = curModule; auto savedImports = curImports;
    if (!s->module.empty()) { curModule = s->module; curImports = modImports[curModule]; }
    StructInfo &si = structs[s->s];
    auto savedGenericArgs = genericTypeArgsBeingResolved;
    for (const auto &arg : s->genericAppliedArgs) {
      if (arg.isConstValue) continue;
      std::string n = arg.base; size_t dot = n.rfind('.'); if (dot != std::string::npos) n = n.substr(dot + 1);
      if (!n.empty()) genericTypeArgsBeingResolved.insert(n);
    }
    auto genericOriginIt = genericOrigins.find(s->s);
    if (genericOriginIt != genericOrigins.end()) si.genericOrigin = genericOriginIt->second;
    if (resolvedRecords.count(s->s)) {
      genericTypeArgsBeingResolved = std::move(savedGenericArgs);
      curModule = savedModule; curImports = std::move(savedImports);
      return;
    }
    if (!resolvingRecords.insert(s->s).second) err("class/struct มี inheritance หรือ field cycle ที่จัด layout ไม่ได้: " + s->s, s->line);
    if (!si.parent.empty()) {
      if (!si.isClass) err("เฉพาะ class เท่านั้นที่สืบทอดได้", s->line);
      auto pi = recordNodes.find(si.parent);
      if (pi == recordNodes.end() || !structs[si.parent].isClass) err("extends ต้องระบุ class ที่มีอยู่: " + si.parent, s->line);
      requireTypeAccess(s->parent, si.parent, structs[si.parent].module, structs[si.parent].isPublic, s->line);
      if (structs[si.parent].isFinal) err("ไม่สามารถ extends final class " + si.parent + " ได้", s->line);
      resolveRecord(pi->second);
      si.fields = structs[si.parent].fields;
    }
    for (size_t inx = 0; inx < si.impls.size(); inx++) {
      const std::string &iname = si.impls[inx];
      auto ii = structs.find(iname);
      if (ii == structs.end() || !ii->second.isInterface) err(std::string(si.isInterface ? "interface extends" : "implements") + " ต้องเป็น interface ที่รู้จัก: " + iname, s->line);
      requireTypeAccess(s->impls[inx], iname, ii->second.module, ii->second.isPublic, s->line);
      if (iname == si.name) err("interface ห้าม extends ตัวเอง: " + iname, s->line);
    }
    for (auto &fd : s->c) {
      curLine = fd->line; T t;
      if (fd->ts.cat == "array") {
        int64_t N = 0; T el = baseType(fd->ts.base, fd->line);
        if (!fd->ts.hasSize || !constEval(fd->ts.size.get(), N) || N <= 0) err("field array ต้องมีขนาดคงที่ เช่น array var float m[16]", fd->line);
        if (!(el->k == INT || el->k == F32 || el->k == F64 || el->k == BOOL || el->k == CHAR || el->k == UNI || el->k == ENUM)) err("field array รองรับเฉพาะตัวเลข/char/boolean/enum", fd->line);
        t = tArr(el, N);
      } else t = resolveType(fd->ts, fd->line);
      if (fd->isVolatile) { if (!(isNum(t) || t->k == PTR)) err("volatile field รองรับเฉพาะ scalar/pointer", fd->line); t = qualifyVolatile(t); }
      // A generic T field is ownership-aware after specialization; when T becomes
      // string, the generated record helpers retain/drop it like a dyn string field.
      if (t->k == STR && fd->ts.kind != "dyn" && !fd->genericSubstituted) err("field string ต้องเป็น dyn string", fd->line);
      for (auto &oldf : si.fields) if (oldf.name == fd->s) err("field '" + fd->s + "' ชนกับ field ที่มีอยู่/สืบทอดมา", fd->line);
      for (auto &oldf : si.staticFields) if (oldf.name == fd->s) err("static field '" + fd->s + "' ชนกับ field ที่มีอยู่", fd->line);
      FieldInfo fi; fi.name = fd->s; fi.ty = t; fi.isPublic = fd->isPublic; fi.isPrivate = fd->isPrivate;
      fi.isProtected = fd->isProtected; fi.owner = s->s; fi.isStatic = fd->isStatic; fi.isConst = fd->isConst;
      if (fd->isStatic) {
        if (!si.isClass || si.isInterface) err("static field ใช้ได้เฉพาะใน class", fd->line);
        if (!(isNum(t) || t->k == PTR)) err("static field รองรับเฉพาะ scalar/enum/pointer ในรุ่นนี้", fd->line);
        if (fi.isConst && fd->c.empty()) err("const static field ต้องมีค่าเริ่มต้น", fd->line);
        fi.sym = "@fac.static." + s->s + "." + fd->s;
        si.staticFields.push_back(fi);
      } else {
        si.fields.push_back(fi);
      }
    }
    resolvingRecords.erase(s->s); resolvedRecords.insert(s->s); si.resolved = true;
    genericTypeArgsBeingResolved = std::move(savedGenericArgs);
    curModule = savedModule; curImports = std::move(savedImports);
  };
  for (auto *p : ps) for (auto &s : p->structs) {
    curModule = p->module; curImports = modImports[curModule];
    resolveRecord(s.get());
  }
  // Validate generic constraints after all concrete specializations have been
  // materialized and their inheritance/interface graph is available.
  auto genericTypeName = [](const TypeSpec &ts) {
    std::string n = ts.base; size_t d = n.rfind('.');
    return d == std::string::npos ? n : n.substr(d + 1);
  };
  std::function<bool(const std::string &, const std::string &, std::set<std::string> &)> implementsBound;
  implementsBound = [&](const std::string &actual, const std::string &bound, std::set<std::string> &seen) {
    if (actual == bound) return true;
    if (!seen.insert(actual).second || !structs.count(actual)) return false;
    const StructInfo &si = structs.at(actual);
    for (const std::string &in : si.impls) {
      if (in == bound) return true;
      if (implementsBound(in, bound, seen)) return true;
    }
    if (!si.parent.empty() && implementsBound(si.parent, bound, seen)) return true;
    return false;
  };
  for (auto *p : ps) for (auto &s : p->structs) if (!s->genericAppliedNames.empty()) {
    curModule = p->module; curImports = modImports[curModule];
    for (const GenericBound &gb : s->genericBounds) {
      auto pi = std::find(s->genericAppliedNames.begin(), s->genericAppliedNames.end(), gb.param);
      if (pi == s->genericAppliedNames.end()) err("generic constraint อ้าง parameter ที่ไม่มี: " + gb.param, s->line);
      size_t ix = (size_t)std::distance(s->genericAppliedNames.begin(), pi);
      if (ix >= s->genericAppliedArgs.size()) err("ภายใน compiler: generic arguments ไม่ครบ", s->line);
      const TypeSpec &actualSpec = s->genericAppliedArgs[ix];
      // The specialized clone has already cleared its active generic parameter
      // list; the concrete argument kind is therefore the authoritative marker.
      const bool isConstParameter = actualSpec.isConstValue;
      if (isConstParameter) {
        if (!actualSpec.isConstValue)
          err("ภายใน compiler: const generic argument ของ '" + gb.param + "' ไม่ใช่ค่า integer", s->line);
        if (!satisfiesConstGenericConstraint(gb.bound.base, actualSpec.constValue))
          err("const generic constraint " + gb.param + ": " + gb.bound.base +
              " ไม่ผ่านสำหรับค่า " + std::to_string(actualSpec.constValue), s->line);
        continue;
      }
      T actualTy = resolveType(actualSpec, s->line);
      const std::string boundRaw = gb.bound.base;
      if (boundRaw == "numeric" || boundRaw == "integral" || boundRaw == "reference" || boundRaw == "value") {
        bool ok = boundRaw == "numeric" ? isNum(actualTy) :
                  boundRaw == "integral" ? actualTy->k == INT :
                  boundRaw == "reference" ? (actualTy->k == OBJ || actualTy->k == WEAK || actualTy->k == PTR) :
                  (isNum(actualTy) || actualTy->k == ENUM || actualTy->k == STRUCT || actualTy->k == PTR);
        if (!ok) err("generic constraint " + gb.param + ": " + boundRaw + " ไม่รับ type " + tname(actualTy), s->line);
        continue;
      }
      std::string canonicalBound = canonicalModulePath(boundRaw);
      TypeSpec boundNameSpec; boundNameSpec.base = canonicalBound;
      std::string boundName = genericTypeName(boundNameSpec);
      auto bi = structs.find(boundName);
      if (bi == structs.end()) err("generic constraint ไม่พบ class/interface/struct '" + boundRaw + "'", s->line);
      requireTypeAccess(canonicalBound, boundName, bi->second.module, bi->second.isPublic, s->line);
      bool ok = false;
      if (bi->second.isInterface) {
        if (actualTy->k == OBJ) { std::set<std::string> seen; ok = implementsBound(actualTy->name, boundName, seen); }
      } else if (bi->second.isClass) {
        ok = actualTy->k == OBJ && isSubclass(actualTy->name, boundName);
      } else {
        ok = actualTy->k == STRUCT && actualTy->name == boundName;
      }
      if (!ok) err("generic constraint " + gb.param + " ต้องเป็น " + boundName + " แต่ได้รับ " + tname(actualTy), s->line);
    }
  }
  for (auto *p : ps) {
    curModule = p->module; curImports = modImports[curModule];
    for (auto &s : p->structs) for (auto &m : s->methods) registerFunc(m.get(), p->module, s->s);
  }
  // interface ทั้งหมดที่ class/interface นี้ผูกอยู่ (implements/extends ผ่านทุกชั้น รวมของ parent)
  std::function<std::set<std::string>(const std::string &)> ifaceClosure = [&](const std::string &cls) {
    std::set<std::string> out, seen; std::vector<std::string> work{cls};
    while (!work.empty()) {
      std::string cur = work.back(); work.pop_back();
      if (!seen.insert(cur).second) continue;
      auto it = structs.find(cur); if (it == structs.end()) continue;
      for (auto &i : it->second.impls) { out.insert(i); work.push_back(i); }
      if (!it->second.parent.empty()) work.push_back(it->second.parent);
    }
    return out;
  };
  // `override`: ต้องมี method ชื่อเดียวกันใน parent หรือใน interface ที่ implement (static/instance ต้องตรงกัน); ตรวจ signature ด้านล่าง
  for (auto *p : ps) for (auto &s : p->structs) if (s->isClass) {
    StructInfo &si = structs[s->s];
    for (auto &m : s->methods) if (m->isOverride) {
      bool ifaceHas = false;
      for (auto &in : ifaceClosure(si.name)) if (structs[in].methods.count(m->s)) ifaceHas = true;
      std::map<std::string, FuncInfo *>::iterator pit;
      bool parentHas = !si.parent.empty() && (pit = structs[si.parent].methods.find(m->s)) != structs[si.parent].methods.end() && pit->first != "__ctor" && !pit->second->isPrivate;
      if (!parentHas && !ifaceHas) {
        if (si.parent.empty()) err("override ใช้ได้เฉพาะ method ที่มีใน parent class หรือใน interface ที่ implement", m->line);
        err("override method '" + m->s + "' ไม่พบ method ชื่อเดียวกันใน class แม่ " + si.parent + " และไม่พบใน interface ที่ implement", m->line);
      }
      if (parentHas && pit->second->isStatic != m->isStatic)
        err("override ต้องตรงกันเรื่อง static/instance กับ method ใน class แม่: " + m->s, m->line);
    }
  }
  // Inherited methods are visible to subclasses unless overridden. Method bodies keep their declaring class context.
  std::set<std::string> inheritedDone;
  std::function<void(const std::string &)> injectInterfaceMethods;
  std::function<void(const std::string &)> inheritMethods = [&](const std::string &name) {
    if (!inheritedDone.insert(name).second) return;
    StructInfo &si = structs[name];
    if (si.parent.empty()) { injectInterfaceMethods(name); return; }
    inheritMethods(si.parent);
    for (auto &m : structs[si.parent].methods) if (m.first != "__ctor" && !si.methods.count(m.first)) si.methods[m.first] = m.second;
    injectInterfaceMethods(name);
  };
  // method ของ interface ที่ class ผูกอยู่ แต่ยังไม่มี implementation จะปรากฏใน class เป็น abstract method (เรียกผ่าน this ใน template method ได้;
  // class จริงที่ไม่ implement จะถูกตรวจจับทีหลัง, abstract class ปล่อยให้ลูก implement)
  injectInterfaceMethods = [&](const std::string &name) {
    StructInfo &si = structs[name]; if (!si.isClass) return;
    auto interfaceExtends = [&](const std::string &child, const std::string &ancestor) {
      std::set<std::string> seen;
      std::function<bool(const std::string &)> visit = [&](const std::string &cur) {
        if (cur == ancestor) return true;
        if (!seen.insert(cur).second || !structs.count(cur)) return false;
        for (const std::string &parent : structs[cur].impls)
          if (structs.count(parent) && structs[parent].isInterface && visit(parent)) return true;
        return false;
      };
      return visit(child);
    };
    std::map<std::string, FuncInfo *> selected;
    for (auto &in : ifaceClosure(name)) for (auto &im : structs[in].methods) {
      auto it = selected.find(im.first);
      if (it == selected.end()) { selected[im.first] = im.second; continue; }
      FuncInfo *prior = it->second, *next = im.second;
      bool priorDefault = !prior->isAbstract, nextDefault = !next->isAbstract;
      if (prior->structName != next->structName) {
        bool nextIsMoreSpecific = interfaceExtends(next->structName, prior->structName);
        bool priorIsMoreSpecific = interfaceExtends(prior->structName, next->structName);
        if (nextIsMoreSpecific) { it->second = next; continue; }
        if (priorIsMoreSpecific) continue;
      }
      if (priorDefault && nextDefault && prior != next) {
        bool classOwns = si.methods.count(im.first) && !structs[si.methods[im.first]->structName].isInterface;
        if (!classOwns) err("class " + name + " ได้ default method '" + im.first + "' ซ้ำจาก interface " + prior->structName + " และ " + next->structName + "; ให้ override method นี้ใน class", recordNodes[name]->line);
      }
      if (!priorDefault && nextDefault) it->second = next;
    }
    for (auto &im : selected) if (!si.methods.count(im.first)) si.methods[im.first] = im.second;
  };
  for (auto &kv : structs) if (kv.second.isClass) inheritMethods(kv.first);
  // ---- OOP: interface/abstract/override signature + virtual table ----
  {
    std::function<void(const std::string &, std::set<std::string> &)> cyc = [&](const std::string &n, std::set<std::string> &path) {
      if (!path.insert(n).second) err("interface extends วนเป็นวงกลม: " + n, recordNodes[n]->line);
      for (auto &i : structs[n].impls) if (structs[i].isInterface) cyc(i, path);
      path.erase(n);
    };
    for (auto &kv : structs) if (kv.second.isInterface) { std::set<std::string> path; cyc(kv.first, path); }
    auto verifyParameterEffects = [&](FuncInfo *contract, FuncInfo *implementation,
                                      const std::string &where) {
      if (!contract || !implementation || !contract->node || !implementation->node) return;
      const auto &required = contract->node->params;
      const auto &provided = implementation->node->params;
      if (required.size() != provided.size()) return; // ordinary signature diagnostic handles arity
      for (size_t i = 0; i < required.size(); ++i) {
        if (required[i].noescape && !provided[i].noescape)
          err(where + " weakens noescape contract for parameter '" + required[i].name + "'", implementation->node->line);
        if (required[i].readonly && !provided[i].readonly)
          err(where + " weakens readonly contract for parameter '" + required[i].name + "'", implementation->node->line);
      }
    };
    for (auto &kv : structs) {   // override: signature ต้องตรงกับของ parent; จดว่า method ไหนถูก override (ต้องเรียกแบบ virtual)
      StructInfo &si = kv.second; if (!si.isClass || si.isInterface) continue;
      for (auto &m : si.methods) {
        FuncInfo *fi = m.second; if (m.first == "__ctor" || fi->structName != si.name) continue;
        if (fi->isAbstract && !si.isAbstract) err("abstract method '" + m.first + "' ต้องอยู่ใน abstract class", fi->node->line);
        if (si.parent.empty()) continue;
        auto pit = structs[si.parent].methods.find(m.first);
        if (pit != structs[si.parent].methods.end() && (fi->generic || pit->second->generic))
          err("generic method '" + m.first + "' ไม่รองรับ override/hiding ข้าม class", fi->node->line);
        if (fi->isStatic) continue;
        if (pit == structs[si.parent].methods.end() || pit->second->isStatic || pit->second->isPrivate) continue;
        if (pit->second->isFinal) err("ไม่สามารถ override final method '" + m.first + "' จาก class " + si.parent + " ได้", fi->node->line);
        if (pit->second->node->isPublic && (fi->isPrivate || fi->isProtected)) err("override method '" + m.first + "' ห้ามลดสิทธิ์จาก public", fi->node->line);
        if (pit->second->isProtected && fi->isPrivate) err("override method '" + m.first + "' ห้ามลดสิทธิ์จาก protected เป็น private", fi->node->line);
        if (sigKey(*pit->second) != sigKey(*fi)) err("method '" + m.first + "' ของ class " + si.name + " มี signature (" + sigKey(*fi) + ") ไม่ตรงกับของ class แม่ " + si.parent + " (" + sigKey(*pit->second) + ")", fi->node->line);
        verifyParameterEffects(pit->second, fi, "override method '" + m.first + "' in class " + si.name);
        for (std::string anc = si.parent; !anc.empty(); anc = structs[anc].parent) if (structs[anc].methods.count(m.first)) overriddenKeys.insert(anc + "::" + m.first);
      }
    }
    for (auto &kv : structs) {   // class จริง (ไม่ abstract) ต้อง implement ครบทุก abstract method และทุก method ของ interface
      StructInfo &si = kv.second; if (!si.isClass || si.isInterface || si.isAbstract) continue;
      int line = recordNodes.count(si.name) ? recordNodes[si.name]->line : 0;
      for (auto &in : ifaceClosure(si.name)) for (auto &im : structs[in].methods) {
        auto it = si.methods.find(im.first);
        if (it == si.methods.end() || it->second->isAbstract) err("class " + si.name + " ต้อง implement method '" + im.first + "' ของ interface " + in, line);
        if (it->second->isStatic || it->second->isPrivate) err("method '" + im.first + "' ที่ implement interface " + in + " ต้องเป็น public instance method", it->second->node->line);
        if (sigKey(*it->second) != sigKey(*im.second)) err("method '" + im.first + "' ของ class " + si.name + " มี signature (" + sigKey(*it->second) + ") ไม่ตรงกับ interface " + in + " (ต้องเป็น " + sigKey(*im.second) + ")", it->second->node->line);
        verifyParameterEffects(im.second, it->second, "interface implementation '" + im.first + "' in class " + si.name);
      }
      for (auto &m : si.methods) if (m.second->isAbstract)
        err("class " + si.name + " ต้อง implement abstract method '" + m.first + "' (ประกาศใน " + m.second->structName + ")", line);
      std::vector<std::pair<int, std::string>> ent;   // vtable: (selector, function) ของ method instance ที่เรียกได้จากภายนอก
      for (auto &m : si.methods) {
        FuncInfo *fi = m.second;
        if (m.first == "__ctor" || fi->isStatic || fi->isPrivate || fi->isAbstract || fi->generic) continue;
        ent.push_back({selectorOf(*fi), fi->sym});
      }
      std::string v = "@vtbl." + si.name + " = internal constant [" + std::to_string(1 + 2 * ent.size()) + " x ptr] [ptr " + (ent.empty() ? std::string("null") : "inttoptr (i64 " + std::to_string(ent.size()) + " to ptr)");
      for (auto &e : ent) v += ", ptr inttoptr (i64 " + std::to_string(e.first) + " to ptr), ptr " + e.second;
      globals += v + "]\n";
    }
  }
  for (auto *p : ps) {
    curModule = p->module; curImports = modImports[curModule];
    for (auto &f : p->funcs) registerFunc(f.get(), p->module, "");
  }
  validateGlobalImportNames(ps);

  // Static fields have process lifetime and are initialized from the owning module initializer.
  for (auto &kv : structs) for (const FieldInfo &sf : kv.second.staticFields)
    globals += sf.sym + " = internal global " + llty(sf.ty) + " zeroinitializer, align " + std::to_string(alignOf(sf.ty)) + "\n";

  // ---- ตัวแปร global และ static field: initializer ของแต่ละ module รันใน @fac.init.<module>
  std::vector<std::string> initCalls;
  for (size_t pi = ps.size(); pi > 0; pi--) {
    Program *p = ps[pi - 1];
    bool hasStaticFields = false;
    for (auto &sd : p->structs) if (structs[sd->s].staticFields.size()) { hasStaticFields = true; break; }
    if (p->globals.empty() && !hasStaticFields) continue;
    curModule = p->module; curFile = p->file; curImports.clear(); for (auto &i : p->imports) curImports.insert(i);
    body.clear(); allocas.clear(); term = false; curBB = "entry"; scopes.clear(); loops.clear(); temps.clear();
    FuncInfo initF; initF.name = "__init"; initF.module = p->module; initF.ret = T_void; cf = &initF;
    inGlobalInit = true; pushScope();
    for (auto &g : p->globals) {
      curLine = g->line;
      if (globalVars[p->module].count(g->s)) err("ตัวแปร global '" + g->s + "' ประกาศซ้ำ", g->line);
      declStmt(g.get()); flushTemps(0);
      auto vit = scopes.back().vars.find(g->s);
      if (vit == scopes.back().vars.end()) err("ประกาศตัวแปร global '" + g->s + "' ไม่ได้", g->line);
      globalVars[p->module][g->s] = vit->second; scopes.back().vars.erase(vit);
      globalPublic[p->module + "." + g->s] = g->isPublic;
      int64_t cvv;
      if (g->isConst && g->ts.cat.empty() && !g->c.empty() && constEval(g->c[0].get(), cvv)) constGlobals[p->module + "." + g->s] = cvv;
    }
    // Class static initializers run after module-level globals, in class/field declaration order.
    for (auto &sd : p->structs) {
      StructInfo &si = structs[sd->s];
      FuncInfo staticContext; staticContext.name = "__static_init"; staticContext.module = p->module;
      staticContext.structName = sd->s; staticContext.isMethod = true; staticContext.isStatic = true;
      cf = &staticContext;
      for (auto &fd : sd->c) if (fd->isStatic) {
        curLine = fd->line;
        auto fit = std::find_if(si.staticFields.begin(), si.staticFields.end(), [&](const FieldInfo &f) { return f.name == fd->s; });
        if (fit == si.staticFields.end()) err("ภายใน compiler: ไม่พบ metadata ของ static field " + fd->s, fd->line);
        if (!fd->c.empty()) {
          V value = expr(fd->c[0].get());
          checkImplicit(value, fit->ty, fd->line);
          storeRaw(fit->sym, fit->ty, value, true, fit->ty->isVolatile);
          flushTemps(0);
        }
      }
    }
    cf = &initF;
    inGlobalInit = false; scopes.clear(); temps.clear();
    std::string isym = "@fac.init." + p->module;
    initOut += "define internal void " + isym + "() nounwind {\nentry:\n" + allocas + body + "  ret void\n}\n\n";
    initCalls.push_back(isym);
    body.clear(); allocas.clear(); term = false;
  }

  // All modules, globals, functions and methods are registered now. Build the
  // V71 whole-program worker graph before normal function emission.
  if (safeEnforced()) buildWholeProgramWorkerRegistry();

  // Evaluate explicit compile-time assertions only after all module constants
  // have been registered. The evaluator is intentionally side-effect-free and
  // bounded to the compiler's integer constant-expression subset.
  for (Program *p : ps) {
    curModule = p->module;
    for (const StaticAssertion &assertion : p->staticAssertions) {
      int64_t value = 0;
      if (!assertion.expr || !constEval(assertion.expr.get(), value))
        err("static_assert expression ต้องเป็น integer/bool constant expression ที่ประเมินได้โดยไม่มี overflow หรือ undefined operation", assertion.line);
      if (!value)
        err("static_assert failed: " + assertion.message, assertion.line);
    }
  }

  std::string types;
  for (auto &kv : structs) {
    sizeOf(tStruct(kv.first));   // ตรวจขนาดของทุก struct ที่ประกาศ (ล้นช่วง/ใหญ่เกิน 1 TiB = error) แม้ยังไม่ถูกใช้
    types += "%S." + kv.first + " = type {";
    for (size_t i = 0; i < kv.second.fields.size(); i++) types += (i ? ", " : " ") + llty(kv.second.fields[i].ty);
    types += kv.second.fields.empty() ? "}\n" : " }\n";
  }
  for (const auto &kv : enums) if (kv.second.hasPayload) {
    types += "%E." + kv.first + " = type { i32, [" + std::to_string(kv.second.maxPayload) + " x i64] }\n";
  }
  // A generated declaration projection may add a second Program object for an
  // already existing module.  Function emission is module-scoped, so visit
  // each module exactly once while retaining every Program's declarations
  // for the earlier registration/layout passes.
  std::set<std::string> emittedFunctionModules;
  for (auto *p : ps) {
    if (!emittedFunctionModules.insert(p->module).second) continue;
    curImports.clear(); for (auto &i : p->imports) curImports.insert(i);
    curFile = p->file;
    for (size_t i = 0; i < allFuncs.size(); i++) if (allFuncs[i]->module == p->module && !allFuncs[i]->generic && !allFuncs[i]->isExtern && !allFuncs[i]->isAbstract && !allFuncs[i]->isConsteval) emitFunc(*allFuncs[i]);
    while (lamDone < lambdas.size()) { FuncInfo &lf = lambdas[lamDone++]; emitFunc(lf); }
  }
  emitStructHelpers(structs["Error"]);
  for (const char *vn : {"vec2", "vec3", "vec4", "mat4"}) emitStructHelpers(structs[vn]);
  for (auto *p : ps) for (auto &s : p->structs) emitStructHelpers(structs[s->s]);
  for (auto &kv : enums) if (kv.second.hasPayload) emitEnumHelpers(kv.second);
  auto mi = funcs.find(mainModule + ".main");
  std::string mainFn;

  // Java-style application entry point:
  //   public class App {
  //     public static function void main(list dyn string args) { ... }
  //   }
  // The lexer already represents language words as identifiers and the parser
  // already parses class modifiers, static methods and `list dyn string` types.
  // Keep entry-point selection here so the existing source grammar stays
  // backwards-compatible and ordinary classes may still define other methods.
  FuncInfo *classMain = nullptr;
  StructInfo *classMainOwner = nullptr;
  for (auto &entry : structs) {
    StructInfo &si = entry.second;
    if (!si.isClass || si.isInterface || si.module != mainModule) continue;
    auto method = si.methods.find("main");
    if (method == si.methods.end()) continue;
    FuncInfo *candidate = method->second;
    // Do not treat an inherited static method as the program's entry point.
    if (!candidate || candidate->structName != si.name) continue;
    if (classMain) err("พบ class entry point มากกว่าหนึ่งตัว (static main); ให้เหลือเพียง class เดียว", candidate->node ? candidate->node->line : 0);
    classMain = candidate;
    classMainOwner = &si;
  }

  if (mi != funcs.end() && classMain)
    err("พบ entry point ซ้ำกัน: top-level main และ class static main; ให้เลือกใช้รูปแบบเดียว", classMain->node ? classMain->node->line : 0);

  *hasMain = mi != funcs.end() || classMain != nullptr;
  if (*hasMain) {
    mainFn = "define i32 @main(i32 %argc, ptr %argv) {\n  call void @fac_init(i32 %argc, ptr %argv)\n";
    if (opt.debug) mainFn += "  call void @fac_set_debug(i32 1)\n";
    for (auto &ic : initCalls) mainFn += "  call void " + ic + "()\n";

    if (mi != funcs.end()) {
      // Legacy FAC entry point remains unchanged: public function void main().
      FuncInfo &m = mi->second;
      if (!m.pt.empty()) err("main ต้องไม่มี parameter", m.node->line);
      if (m.ret->k == VOID) mainFn += "  call void " + m.sym + "()\n  call void @fac_shutdown()\n  ret i32 0\n}\n";
      else mainFn += "  %r = call " + llty(m.ret) + " " + m.sym + "()\n  call void @fac_shutdown()\n  ret i32 " + (m.ret->k == INT && m.ret->bits == 32 ? "%r" : "0") + "\n}\n";
    } else {
      FuncInfo &m = *classMain;
      const int line = m.node ? m.node->line : 0;
      if (!classMainOwner || !classMainOwner->isPublic)
        err("class ที่ประกาศ static main ต้องเป็น public", line);
      if (!m.isStatic)
        err("Java-style entry point ต้องเป็น static method: public static function void main(...) ", line);
      if (!m.node || !m.node->isPublic || m.isPrivate || m.isProtected)
        err("Java-style entry point ต้องเป็น public method", line);
      if (m.generic || m.isAbstract || m.isConstructor || m.isDestructor)
        err("Java-style entry point ต้องเป็น method ปกติที่ไม่ใช่ generic/abstract", line);
      if (m.ret->k != VOID)
        err("Java-style entry point ต้อง return void", line);
      if (m.pt.size() > 1)
        err("Java-style main รับได้ 0 parameter หรือ list dyn string args เพียง 1 parameter", line);
      bool takesArgs = false;
      if (m.pt.size() == 1) {
        const Param &pa = m.node->params[0];
        takesArgs = pa.ts.cat == "list" && pa.ts.kind == "dyn" && pa.ts.base == "string" &&
                    !pa.ref && !pa.immutableRef && !pa.variadic && !pa.def &&
                    m.pt[0]->k == LIST && m.pt[0]->el && m.pt[0]->el->k == STR;
        if (!takesArgs)
          err("parameter ของ Java-style main ต้องเป็น `list dyn string args` (หรือไม่รับ parameter)", line);
      }
      if (takesArgs) {
        mainFn += "  %fac.args = call ptr @fac_args()\n";
        mainFn += "  call void " + m.sym + "(ptr %fac.args)\n";
      } else {
        mainFn += "  call void " + m.sym + "()\n";
      }
      mainFn += "  call void @fac_shutdown()\n  ret i32 0\n}\n";
    }
  }
  if (!*hasMain && !exportFuncs.empty()) {  // โหมด library: C เรียก fac_lib_init() ก่อน แล้วค่อยเรียก function ที่ export
    mainFn = "define void @fac_lib_init() {\n  call void @fac_init(i32 0, ptr null)\n";
    for (auto &ic : initCalls) mainFn += "  call void " + ic + "()\n";
    mainFn += "  ret void\n}\ndefine void @fac_lib_shutdown() {\n  call void @fac_shutdown()\n  ret void\n}\n";
  }
  return std::string("; Fac -> LLVM IR (facc)\n") + RT_DECLS + types + globals + "\n" + initOut + funcOut + helperOut + mainFn + loopMd;
}
