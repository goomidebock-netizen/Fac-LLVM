// ---- (included inside class Gen) §19 libraries: bit, json, mutex ----
void declIntr(const std::string &name, const std::string &sig) {
  if (extraDecls.count(name)) return;
  extraDecls.insert(name);
  globals += "declare " + sig + "\n";
}

V bitCall(const std::string &fn, const std::vector<Node *> &args, Node *n) {
  size_t want = fn == "count" ? 1 : 2;
  if (fn != "count" && fn != "get" && fn != "set" && fn != "clear" && fn != "rotl" && fn != "rotr") err("ไม่รู้จัก bit." + fn, n->line);
  if (args.size() != want) err("bit." + fn + " ต้องการ " + std::to_string(want) + " argument", n->line);
  V x = expr(args[0]);
  if (x.t->k != INT) err("bit." + fn + ": argument แรกต้องเป็นจำนวนเต็ม (เจอ " + tname(x.t) + ")", n->line);
  T t = x.t; std::string ty = llty(t);
  if (fn == "count") {
    std::string in = "llvm.ctpop." + ty; declIntr(in, ty + " @" + in + "(" + ty + ")");
    V r; r.t = t; r.v = def("call " + ty + " @" + in + "(" + ty + " " + x.v + ")"); return cv(r, T_int);
  }
  V i = expr(args[1]);
  std::string m = def("and " + ty + " " + conv(i, t, n->line) + ", " + std::to_string(t->bits - 1));
  V r; r.t = t;
  if (fn == "get") { std::string sh = def("lshr " + ty + " " + x.v + ", " + m), b = def("and " + ty + " " + sh + ", 1"); return boolV(def("icmp ne " + ty + " " + b + ", 0")); }
  if (fn == "set" || fn == "clear") {
    std::string one = def("shl " + ty + " 1, " + m);
    if (fn == "set") r.v = def("or " + ty + " " + x.v + ", " + one);
    else { std::string inv = def("xor " + ty + " " + one + ", -1"); r.v = def("and " + ty + " " + x.v + ", " + inv); }
    return r;
  }
  std::string in = std::string("llvm.") + (fn == "rotl" ? "fshl." : "fshr.") + ty;
  declIntr(in, ty + " @" + in + "(" + ty + ", " + ty + ", " + ty + ")");
  r.v = def("call " + ty + " @" + in + "(" + ty + " " + x.v + ", " + ty + " " + x.v + ", " + ty + " " + m + ")");
  return r;
}

void mutexDecl(Node *n) {
  if (n->ts.kind == "ptr" || n->ts.kind == "heap") err("mutex ใช้ได้กับ var/dyn", n->line);
  T t = tDS("mutex", T_int, T_int);
  std::string slot = alloca_(t); ins("store ptr " + def("call ptr @fac_mutex_new()") + ", ptr " + slot);
  Var &v = declVar(n->s, t, n->ts.kind); v.slot = slot; regCleanup(v);
}

// ---------------- JSON
std::string jsonKey(const std::string &name) {
  std::string o = "\"";
  for (char c : name) { if (c == '"' || c == '\\') o += '\\'; o += c; }
  return o + "\":";
}
void jsonEnc(const std::string &b, const T &t, const std::string &v, int line) {
  auto raw = [&](const std::string &s) { ins("call void @fac_jb_raw(ptr " + b + ", ptr " + strLit(s) + ")"); };
  V x; x.t = t; x.v = v;
  switch (t->k) {
    case INT:
      if (t->sg) ins("call void @fac_jb_i64(ptr " + b + ", i64 " + conv(x, T_long) + ")");
      else ins("call void @fac_jb_u64(ptr " + b + ", i64 " + conv(x, T_ulong) + ")");
      break;
    case F32: case F64: ins("call void @fac_jb_f64(ptr " + b + ", double " + conv(x, T_double) + ")"); break;
    case BOOL: ins("call void @fac_jb_bool(ptr " + b + ", i32 " + def("zext i8 " + v + " to i32") + ")"); break;
    case CHAR: case UNI: ins("call void @fac_jb_char(ptr " + b + ", i32 " + conv(x, T_uni) + ")"); break;
    case STR: ins("call void @fac_jb_str(ptr " + b + ", ptr " + v + ")"); break;
    case ENUM: { V s = enumConv(x, true); ins("call void @fac_jb_str(ptr " + b + ", ptr " + s.v + ")"); break; }
    case LIST: {
      std::string d = listField(v, 0, "ptr"), l = listField(v, 1, "i64");
      ins("call void @fac_jb_seq(ptr " + b + ", ptr " + d + ", i64 " + l + ", i32 " + std::to_string(tcode(t->el)) + ")");
      break;
    }
    case ARR: ins("call void @fac_jb_seq(ptr " + b + ", ptr " + v + ", i64 " + std::to_string(t->n) + ", i32 " + std::to_string(tcode(t->el)) + ")"); break;
    case DSK: ins("call void @fac_jb_ds(ptr " + b + ", ptr " + v + ")"); break;
    case STRUCT: {
      StructInfo &si = structInfo(t->name, line);
      raw("{");
      for (size_t i = 0; i < si.fields.size(); i++) {
        if (i) raw(",");
        raw(jsonKey(si.fields[i].name));
        T ft = si.fields[i].ty;
        std::string p = def("getelementptr inbounds %S." + si.name + ", ptr " + v + ", i32 0, i32 " + std::to_string(i));
        if (ft->k == STRUCT || ft->k == ARR) jsonEnc(b, ft, p, line);
        else jsonEnc(b, ft, def("load " + llty(ft) + ", ptr " + p), line);
      }
      raw("}");
      break;
    }
    default: err("json.encode ไม่รองรับ " + tname(t), line);
  }
}
V jsonEncode(const std::vector<Node *> &args, Node *n) {
  if (args.size() != 1) err("json.encode ต้องการ 1 argument", n->line);
  V v = expr(args[0]); borrow(v);
  std::string b = def("call ptr @fac_jb_new()");
  if (v.t->k == ARR) ins("call void @fac_jb_seq(ptr " + b + ", ptr " + v.v + ", i64 " + v.len + ", i32 " + std::to_string(tcode(v.t->el)) + ")");
  else jsonEnc(b, v.t, v.v, n->line);
  V r; r.t = T_str; r.owned = true; r.v = def("call ptr @fac_jb_finish(ptr " + b + ")"); return r;
}
void jsonDecInto(const std::string &addr, StructInfo &si, const std::string &node, int line) {
  for (size_t i = 0; i < si.fields.size(); i++) {
    T ft = si.fields[i].ty;
    std::string p = def("getelementptr inbounds %S." + si.name + ", ptr " + addr + ", i32 0, i32 " + std::to_string(i));
    std::string nd = def("call ptr @fac_jd_get(ptr " + node + ", ptr " + strLit(si.fields[i].name) + ")");
    switch (ft->k) {
      case STR: { std::string old = def("load ptr, ptr " + p); freeVal(T_str, old); ins("store ptr " + def("call ptr @fac_jd_str(ptr " + nd + ")") + ", ptr " + p); break; }
      case INT: { V x; x.t = T_long; x.v = def("call i64 @fac_jd_i64(ptr " + nd + ")"); ins("store " + llty(ft) + " " + conv(x, ft) + ", ptr " + p); break; }
      case F32: case F64: { V x; x.t = T_double; x.v = def("call double @fac_jd_f64(ptr " + nd + ")"); ins("store " + llty(ft) + " " + conv(x, ft) + ", ptr " + p); break; }
      case BOOL: { V x; x.t = T_int; x.v = def("call i32 @fac_jd_bool(ptr " + nd + ")"); ins("store i8 " + conv(x, T_bool) + ", ptr " + p); break; }
      case ENUM: {
        EnumInfo &e = enums[ft->name];
        ins("store i32 " + def("call i32 @fac_jd_enum(ptr " + nd + ", ptr " + enumTable(ft->name, true) + ", i32 " + std::to_string(e.mem.size()) + ")") + ", ptr " + p);
        break;
      }
      case LIST: {
        std::string old = def("load ptr, ptr " + p); freeVal(ft, old);
        ins("store ptr " + def("call ptr @fac_jd_list(ptr " + nd + ", i32 " + std::to_string(tcode(ft->el)) + ", i32 " + std::to_string(sizeOf(ft->el)) + ")") + ", ptr " + p);
        break;
      }
      case STRUCT: jsonDecInto(p, structInfo(ft->name, line), nd, line); break;
      default: err("json.decode ไม่รองรับ field '" + si.fields[i].name + "' ชนิด " + tname(ft), line);
    }
  }
}
V jsonDecode(const std::vector<Node *> &args, Node *n) {
  if (args.size() != 2 || args[0]->k != NK::Ident) err("json.decode(Type, string)", n->line);
  T t = typeFromName(args[0]->s);
  if (!t) err("json.decode: ไม่รู้จัก type '" + args[0]->s + "'", n->line);
  V s = expr(args[1]);
  if (s.t->k != STR) err("json.decode: argument ที่ 2 ต้องเป็น string", n->line);
  borrow(s);
  std::string root = def("call ptr @fac_jd_parse(ptr " + s.v + ")");
  ins("call void @fac_tmp_push(ptr " + root + ", i32 7)");   // ถ้า decode ล้มเหลว (throw) runtime ปล่อยต้นไม้ JSON ให้
  V r; r.t = t;
  if (t->k == STRUCT) {
    std::string tmpA = alloca_(t);
    initStructDefaults(tmpA, structInfo(t->name, n->line), 0);
    ins("call void @fac_tmp_push_drop(ptr " + tmpA + ", ptr @drop." + t->name + ")");   // struct ที่สร้างค้างกลางทางก็ต้องถูกปล่อยเมื่อ throw
    jsonDecInto(tmpA, structInfo(t->name, n->line), root, n->line);
    ins("call void @fac_tmp_pop(ptr " + tmpA + ")");   // สำเร็จ: ความเป็นเจ้าของส่งต่อให้ผู้เรียก
    r.v = tmpA; r.owned = true;
  } else if (t->k == STR) { r.v = def("call ptr @fac_jd_str(ptr " + root + ")"); r.owned = true; }
  else if (isFlt(t)) { V x; x.t = T_double; x.v = def("call double @fac_jd_f64(ptr " + root + ")"); r = cv(x, t); }
  else if (t->k == BOOL) { V x; x.t = T_int; x.v = def("call i32 @fac_jd_bool(ptr " + root + ")"); r = cv(x, T_bool); }
  else if (t->k == INT) { V x; x.t = T_long; x.v = def("call i64 @fac_jd_i64(ptr " + root + ")"); r = cv(x, t); }
  else err("json.decode ไม่รองรับ type " + args[0]->s, n->line);
  ins("call void @fac_tmp_pop(ptr " + root + ")");
  ins("call void @fac_jd_free(ptr " + root + ")");
  return r;
}
