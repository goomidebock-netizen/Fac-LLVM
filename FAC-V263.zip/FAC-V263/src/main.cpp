// facc -- Fac compiler driver
//   facc prog.fac [-o out] [-O0|-O1|-O2|-O3] [--emit-ll] [--no-bounds-check] [--no-div-check] [--allow-capture-write] [--run]
#include "codegen.hpp"
#include "parser.hpp"
#include "ownership.hpp"
#include "move.hpp"
#include "hir.hpp"
#include "memory_safe.hpp"
#include "../include/fac/version.h"
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <vector>
#include <cerrno>
#if defined(__GLIBC__)
#include <malloc.h>
#endif
#include <sys/stat.h>
#ifndef _WIN32
#include <unistd.h>
#include <sys/wait.h>
#else
#include <windows.h>
#include <process.h>
#endif

#ifdef _WIN32
#define WINLIBS " -lws2_32 -lgdi32 -luser32 -lwinmm"
#elif defined(__APPLE__)
#define WINLIBS ""         /* dlopen is provided by libSystem */
#elif defined(__linux__)
#define WINLIBS " -ldl"    /* dlopen on Linux */
#else
#define WINLIBS ""         /* BSD-family systems normally provide dlopen in libc */
#endif
static const char *VERSION = FAC_COMPILER_VERSION;

// Source files must be regular files of reasonable size: `import zero.fac` where zero.fac is a symlink to /dev/zero (or a FIFO, or a
// file that keeps growing) used to be read without limit until memory ran out.
static constexpr size_t kMaxSourceBytes = size_t(64) << 20;   // 64 MiB per source unit
static constexpr size_t kMaxCompilationSourceBytes = size_t(128) << 20; // bound the complete imported source graph
static bool readFile(const std::string &p, std::string &out, std::string *why = nullptr,
                     size_t maxBytes = kMaxSourceBytes, const char *limitMessage = "ไฟล์ใหญ่เกิน 64 MiB") {
  struct stat st;
  if (stat(p.c_str(), &st) != 0) { if (why) *why = "ไม่พบไฟล์หรืออ่านไม่ได้"; return false; }
  if (!S_ISREG(st.st_mode)) { if (why) *why = "ไม่ใช่ไฟล์ปกติ (device / pipe / directory)"; return false; }
  if ((uintmax_t)st.st_size > maxBytes) { if (why) *why = limitMessage; return false; }
  std::ifstream f(p, std::ios::binary);
  if (!f) { if (why) *why = "เปิดไม่ได้"; return false; }
  out.clear(); char buf[65536];
  while (f.read(buf, sizeof buf) || f.gcount() > 0) {   // read in chunks so a file that grows while we read still hits the cap
    out.append(buf, (size_t)f.gcount());
    if (out.size() > maxBytes) { if (why) *why = limitMessage; out.clear(); return false; }
  }
  return true;
}
static std::string dirOf(const std::string &p) { size_t i = p.find_last_of("/\\"); return i == std::string::npos ? "." : p.substr(0, i); }
static std::string stemOf(const std::string &p) {
  size_t i = p.find_last_of("/\\"); std::string f = i == std::string::npos ? p : p.substr(i + 1);
  size_t d = f.rfind('.'); return d == std::string::npos ? f : f.substr(0, d);
}
static bool exists(const std::string &p) { struct stat st; return stat(p.c_str(), &st) == 0; }
static std::string selfDir(const char *argv0) {
#ifdef _WIN32
  char b[MAX_PATH]; DWORD n = GetModuleFileNameA(nullptr, b, MAX_PATH); if (n) return dirOf(std::string(b, n));
#else
  char b[4096]; ssize_t n = readlink("/proc/self/exe", b, sizeof b - 1);
  if (n > 0) { b[n] = 0; return dirOf(b); }
#endif
  return dirOf(argv0);
}
static bool safeToken(const std::string &x, const std::string &allowed) {
  if (x.empty()) return false;
  for (unsigned char c : x) if (!(std::isalnum(c) || allowed.find((char)c) != std::string::npos)) return false;
  return true;
}
static std::string displayArg(const std::string &s) {
  // Only for -v diagnostics; arguments are never passed through a shell.
  if (!s.empty() && s.find_first_of(" \t\n\"'\\") == std::string::npos) return s;
  std::string r = "'";
  for (char c : s) { if (c == '\'') r += "'\\''"; else r += c; }
  return r + "'";
}
static int run(const std::vector<std::string> &args, bool verbose) {
  if (args.empty() || args[0].empty()) return 127;
  if (verbose) {
    std::cerr << "+";
    for (const auto &a : args) std::cerr << " " << displayArg(a);
    std::cerr << "\n";
  }
#ifdef _WIN32
  std::vector<const char *> av; av.reserve(args.size() + 1);
  for (const auto &a : args) av.push_back(a.c_str());
  av.push_back(nullptr);
  intptr_t rc = _spawnvp(_P_WAIT, args[0].c_str(), av.data());
  if (rc == -1) { std::cerr << "facc: เรียกโปรแกรมไม่ได้: " << args[0] << " (errno=" << errno << ")\n"; return 127; }
  return (int)rc;
#else
  pid_t pid = fork();
  if (pid < 0) { std::cerr << "facc: fork failed: " << std::strerror(errno) << "\n"; return 127; }
  if (pid == 0) {
    std::vector<char *> av; av.reserve(args.size() + 1);
    for (const auto &a : args) av.push_back(const_cast<char *>(a.c_str()));
    av.push_back(nullptr);
    execvp(av[0], av.data());
    _exit(errno == ENOENT ? 127 : 126);
  }
  int status = 0;
  while (waitpid(pid, &status, 0) < 0) {
    if (errno == EINTR) continue;
    std::cerr << "facc: waitpid failed: " << std::strerror(errno) << "\n";
    return 127;
  }
  if (WIFEXITED(status)) return WEXITSTATUS(status);
  if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
  return 127;
#endif
}
static bool splitPkgFlags(const std::string &src, std::vector<std::string> &out) {
  std::string cur; char quote = 0; bool escape = false, active = false;
  for (char c : src) {
    if (escape) { cur += c; escape = false; active = true; continue; }
    if (c == '\\' && quote != '\'') { escape = true; active = true; continue; }
    if (quote) { if (c == quote) quote = 0; else cur += c; active = true; continue; }
    if (c == '\'' || c == '\"') { quote = c; active = true; continue; }
    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
      if (active) { out.push_back(cur); cur.clear(); active = false; }
      continue;
    }
    cur += c; active = true;
  }
  if (escape || quote) return false;
  if (active) out.push_back(cur);
  return true;
}

static const std::set<std::string> BUILTIN_MODS = {"terminal", "string", "math", "random", "time", "memory", "file", "sys", "bit", "path", "json", "regex", "thread", "crypto", "graphic", "csv", "net", "tls", "three", "gpu", "simd", "audio", "font", "keyboard", "mouse", "tensor", "data", "stats", "metrics", "ml", "nn", "optim", "dataframe", "autograd"};
static const std::set<std::string> FUTURE_MODS = {"zzz_none"};

struct Loader {
  static constexpr size_t kMaxSourceUnits = 4096;
  static constexpr size_t kMaxImportDepth = 128;
  std::vector<std::unique_ptr<Program>> progs;
  std::set<std::string> seen;
  size_t totalSourceBytes = 0;
  size_t totalTokens = 0;
  void load(const std::string &path, const std::string &module, const std::string &searchDir,
            const std::string &stdDir, size_t depth = 0) {
    if (depth >= kMaxImportDepth)
      throw CompileError(0, path + ": import ซ้อนลึกเกิน 128 ระดับ -- แยก dependency เป็นโมดูลย่อย");
    if (progs.size() >= kMaxSourceUnits)
      throw CompileError(0, path + ": จำนวน source modules เกิน 4,096 ต่อ compilation -- ลดจำนวนโมดูลหรือแยก build");

    const size_t remainingBytes = kMaxCompilationSourceBytes - totalSourceBytes;
    const size_t allowedBytes = remainingBytes < kMaxSourceBytes ? remainingBytes : kMaxSourceBytes;
    const char *sizeError = remainingBytes < kMaxSourceBytes
      ? "ขนาด source รวมเกิน 128 MiB ต่อ compilation"
      : "ไฟล์ใหญ่เกิน 64 MiB";
    std::string src;
    std::string why;
    if (!readFile(path, src, &why, allowedBytes, sizeError))
      throw CompileError(0, "เปิดไฟล์ไม่ได้: " + path + " (" + why + ")");
    totalSourceBytes += src.size();

    std::unique_ptr<Program> p;
    try {
      Parser ps; ps.tokenBudgetUsed = &totalTokens; ps.t = lex(src, &totalTokens);
      p = std::make_unique<Program>(ps.parseProgram(path));
    } catch (CompileError &e) { throw CompileError(e.line, path + ":" + std::to_string(e.line) + (e.column > 0 ? ":" + std::to_string(e.column) : std::string()) + ": error: " + e.what(), e.column); }
    // The AST now owns the parsed program; do not retain each source buffer
    // across recursive import loading, or a deep graph multiplies peak memory.
    std::string().swap(src);
    p->module = p->module.empty() ? module : p->module;
    if (!module.empty() && p->module != module) p->module = module;
    // Program objects are individually heap-owned by unique_ptr. Keep a pointer
    // to the stable Program object so recursive loads can grow `progs` without
    // copying its import list (or invalidating the Program itself).
    Program *loaded = p.get();
    progs.push_back(std::move(p));
    for (const auto &i : loaded->imports) {
      if (BUILTIN_MODS.count(i) || seen.count(i)) continue;
      if (FUTURE_MODS.count(i)) throw CompileError(0, path + ": library '" + i + ".fac' ยังไม่รองรับในเวอร์ชันนี้");
      std::string f = searchDir + "/" + i + ".fac";
      if (!exists(f)) f = stdDir + "/" + i + ".fac";
      if (!exists(f)) throw CompileError(0, path + ": หาไฟล์ import '" + i + ".fac' ไม่เจอ (ค้นใน " + searchDir + " และ " + stdDir + ")");
      seen.insert(i);
      load(f, i, searchDir, stdDir, depth + 1);
    }
  }
};

int main(int argc, char **argv) {
  std::string input, output, opt = "-O2";
  bool emitLL = false, runAfter = false, verbose = false, libMode = false, objOnly = false, shared = false;
  std::string headerPath;
  std::string target, cpu, features, sysroot;
  bool lto = false, strictOwnership = false, strictMove = false, memorySafeProfile = false;
  std::vector<std::string> extras, flags, packages;
  Opts o;
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    if (a == "-o" && i + 1 < argc) output = argv[++i];
    else if (a == "-O0" || a == "-O1" || a == "-O2" || a == "-O3") opt = a;
    else if (a == "--emit-ll" || a == "-S") emitLL = true;
    else if (a == "--no-bounds-check") o.bounds = false;
    else if (a == "--no-div-check") o.divcheck = false;
    else if (a == "--unsafe-fast") { o.bounds = false; o.divcheck = false; }
    else if (a == "--lax-conv") o.strict = false;
    else if (a == "--allow-capture-write") o.captureWrite = true;   // lambda เขียนตัวแปรที่จับได้ (สถานะส่วนตัวของ closure)
    else if (a == "--debug") o.debug = true;
    else if (a == "--check-overflow") o.overflow = true;
    else if (a == "--no-trust-stdlib") o.trustStdlib = false;
    else if (a == "--warn-unsafe") o.warnUnsafe = true;   // รายงานจุดที่ --safe จะปฏิเสธ เป็น warning
    else if (a == "--safe") o.safe = true;   // ptr ดิบ/FFI ต้องอยู่ใน unsafe { } หรือ unsafe function
    else if (a == "--strict-safe") { o.safe = true; o.strictSafe = true; } // --safe + reject unverified indirect thread calls
    else if (a == "--secure") { o.safe = true; o.strictSafe = true; strictOwnership = true; o.strictOwnership = true; strictMove = true; o.strictMove = true; } // best-available general safety profile
    else if (a == "--memory-safe") { memorySafeProfile = true; o.safe = true; o.strictSafe = true; o.strictOwnership = true; strictOwnership = true; o.strictMove = true; strictMove = true; o.trustStdlib = false; o.overflow = true; } // fail-closed safe subset: no raw pointers/FFI/unsafe; ref borrows require strict proof
    else if (a == "--strict-ownership") { strictOwnership = true; o.strictOwnership = true; } // check immutable ref writes and direct borrow aliasing
    else if (a == "--strict-move") { strictMove = true; o.strictMove = true; } // enable explicit move(x) + use-after-move flow checks
    else if (a == "--target" && i + 1 < argc) target = argv[++i];
    else if (a == "--cpu" && i + 1 < argc) cpu = argv[++i];
    else if (a == "--features" && i + 1 < argc) features = argv[++i];
    else if (a == "--sysroot" && i + 1 < argc) sysroot = argv[++i];
    else if (a == "--lto") lto = true;
    else if (a == "--run") runAfter = true;
    else if (a == "--lib") libMode = true;
    else if (a == "--obj") objOnly = true;
    else if (a == "--shared") { shared = true; libMode = true; }
    else if (a == "--emit-header" && i + 1 < argc) headerPath = argv[++i];
    else if (a == "-v") verbose = true;
    else if (a == "--version") { std::cout << "facc " << VERSION << " (FAC " << FAC_RELEASE_VERSION << "; Core " << FAC_CORE_VERSION << "; Lib " << FAC_LIB_VERSION << "; API " << FAC_API_VERSION << "; Lang " << FAC_LANG_VERSION << "; Runtime " << FAC_RUNTIME_VERSION << "; Stdlib " << FAC_STDLIB_VERSION << ")\n"; return 0; }
    else if (a == "-h" || a == "--help") {
      std::cout << "facc " << VERSION << " - Fac compiler (LLVM)\n"
                   "ใช้: facc prog.fac [-o out] [-O0|-O1|-O2|-O3] [--emit-ll] [--run]\n"
                   "     --no-bounds-check   ปิดการเช็กขอบ array/list (เร็วขึ้น ปลอดภัยน้อยลง)\n"
                   "     --no-div-check      ปิดการเช็กหารด้วยศูนย์\n"
                   "     --unsafe-fast       ปิดทั้งสองอย่าง\n"
                   "     --lax-conv          อนุญาตการแปลงชนิดตัวเลขที่ทำให้ค่าถูกตัดโดยไม่ต้อง cast (พฤติกรรมเก่า)\n"
                   "     --check-overflow    เช็ก integer overflow ของ + - * (throw Error) ช้าลงเล็กน้อย\n"
                   "     --no-trust-stdlib   ตรวจ stdlib เหมือนโค้ดผู้ใช้ (ใช้คู่กับ --warn-unsafe เพื่อ audit stdlib)\n"
                   "     --warn-unsafe       แค่เตือน (warning) ตรงจุดที่ --safe จะปฏิเสธ ไม่หยุด compile: ใช้ย้ายโค้ดเดิมไป --safe ทีละส่วน\n"
                   "     --safe              ptr ดิบ (deref [..], ptr + n, alloc/realloc/free) และ FFI ต้องอยู่ใน unsafe { } หรือ unsafe function\n"
                   "     --strict-safe       เหมือน --safe และปฏิเสธ indirect function calls ที่ตรวจ target ไม่ได้ใน thread closures\n"
                   "     --secure            โปรไฟล์เข้มงวดทั่วไป: --safe + --strict-safe + --strict-ownership + --strict-move\n"
                   "     --memory-safe       subset แบบ fail-closed: ห้าม ptr/heap/FFI/unsafe/link; ref ต้องผ่าน ownership checker และเปิด overflow checks\n"
                   "     --strict-ownership  ตรวจ ref/ref const, local borrow lifetime, pointer escape และ noescape/readonly effects ใน direct calls\n"
                   "     --strict-move       เปิด move(x) สำหรับ managed local และตรวจ use-after-move / double-move\n"
                   "     --target TRIPLE     ระบุ LLVM target เช่น x86_64-unknown-linux-gnu / aarch64-unknown-linux-gnu\n"
                   "     --cpu NAME          ระบุ CPU เช่น generic / native / haswell / cortex-a76\n"
                   "     --features LIST     เปิด LLVM target features เช่น +sse4.2,+avx2 (ต้องรองรับโดย CPU)\n"
                   "     --sysroot PATH      sysroot สำหรับ cross-link\n"
                   "     --lto               เปิด ThinLTO ผ่าน LLD (ต้องติดตั้ง lld)\n"
                   "     --debug             เช็ก null deref และ free ซ้ำ ตอนรัน\n"
                   "env: FAC_CC=clang++  FAC_RT=path/to/libfacrt.a  FAC_BACKEND=llcheck (ทดสอบโดยไม่มี clang)\n";
      return 0;
    }
    else if (a == "--pkg" && i + 1 < argc) packages.push_back(argv[++i]);
    else if (a.size() > 2 && (a.compare(0, 2, "-l") == 0 || a.compare(0, 2, "-L") == 0 || a.compare(0, 2, "-I") == 0 || a.compare(0, 2, "-D") == 0 || a.compare(0, 2, "-W") == 0)) flags.push_back(a);
    else if (a == "-framework" && i + 1 < argc) { flags.push_back(a); flags.push_back(argv[++i]); }
    else if (a.size() > 2 && a.compare(a.size() - 2, 2, ".c") == 0) extras.insert(extras.end(), {"-x", "c", a, "-x", "none"});
    else if ((a.size() > 4 && (a.compare(a.size() - 4, 4, ".cpp") == 0 || a.compare(a.size() - 4, 4, ".cxx") == 0)) || (a.size() > 3 && a.compare(a.size() - 3, 3, ".cc") == 0)) extras.insert(extras.end(), {"-x", "c++", a, "-x", "none"});
    else if (a.size() > 2 && (a.compare(a.size() - 2, 2, ".o") == 0 || a.compare(a.size() - 2, 2, ".a") == 0 || (a.size() > 4 && (a.compare(a.size() - 4, 4, ".obj") == 0 || a.compare(a.size() - 4, 4, ".lib") == 0 || a.compare(a.size() - 3, 3, ".so") == 0)))) extras.push_back(a);
    else if (!a.empty() && a[0] == '-') { std::cerr << "ไม่รู้จัก option: " << a << "\n"; return 2; }
    else input = a;
  }
  if (input.empty()) { std::cerr << "ใช้: facc prog.fac [-o out]   (facc --help)\n"; return 2; }
  if (o.safe && (!o.bounds || !o.divcheck)) { std::cerr << "--safe ใช้ร่วมกับ --no-bounds-check / --no-div-check / --unsafe-fast ไม่ได้ (ปิดการตรวจจะทำลายการรับประกันของโหมดปลอดภัย)\n"; return 2; }
  // The fail-closed memory-safe subset must not be escaped through native
  // object files, foreign compiler inputs, linker flags, libraries or shared
  // library/header generation supplied on the command line.
  if (memorySafeProfile && (!extras.empty() || !flags.empty() || !packages.empty() || libMode || objOnly || shared || !headerPath.empty())) {
    std::cerr << "--memory-safe ไม่อนุญาต native objects/sources, external linker flags/packages หรือการสร้าง native library/header\n";
    return 2;
  }
  std::string home = selfDir(argv[0]);
  std::string stdDir = home + "/../stdlib";
  if (const char *h = getenv("FAC_HOME")) stdDir = std::string(h) + "/stdlib";

  o.lib = libMode;
  std::vector<std::string> extraLinks;
  std::string ir, generatedHeader;
  bool hasMain = false, hasExports = false;
  bool trimFrontendHeap = false;
  int warningCount = 0;
  std::string mainMod = stemOf(input);
  try {
    // Frontend state can be very large (all imported ASTs, symbol/type maps,
    // generic specializations and codegen buffers). The backend only consumes
    // the completed IR and optional C header, so release that state before
    // starting clang/llcheck. Keep this scope explicit to make the lifetime
    // boundary visible and reliable on every return path.
    {
      Loader ld;
      Gen g; g.opt = o;
      ld.load(input, mainMod, dirOf(input), stdDir);
      if (memorySafeProfile) fac_memory_safe::check(ld.progs);
      if (hasNoescapeContracts(ld.progs) && !strictOwnership)
        throw CompileError(0, "ownership effect contracts (`noescape` / `readonly`) require --strict-ownership or --secure so the compiler can check FAC bodies and call sites (extern contracts are trusted FFI promises)");
      if (strictOwnership || strictMove) checkStrictOwnership(ld.progs);
      if (strictMove) checkStrictMove(ld.progs);
      for (auto &p : ld.progs) for (auto &l : p->links) {
        if (!safeToken(l, "_+.-") || l[0] == '-') throw CompileError(0, "ชื่อ link library มีอักขระที่ไม่รองรับ: " + l);
        extraLinks.push_back("-l" + l);
      }
      std::vector<Program *> ps; ps.reserve(ld.progs.size());
      for (auto &p : ld.progs) ps.push_back(p.get());
      if (ps.empty()) throw CompileError(0, "ไม่มี source module ให้ compile");
      mainMod = ps[0]->module;
      for (auto *pp : ps) if (pp->file.rfind(stdDir + "/", 0) == 0) { g.stdlibModules.insert(pp->module); if (o.trustStdlib) g.trustedModules.insert(pp->module); }   // stdlib ใช้ ptr ดิบภายในได้ใน --safe
      // Build declaration/name/type HIR, source-mapped expressions and lexical
      // local bindings, then record conservative free-function overload and
      // generic type-inference facts with structured provisional diagnostics.
      // Codegen remains authoritative for emitted diagnostics, specialization,
      // method semantics, ownership and LLVM lowering during this migration.
      const fac_hir::SemanticModel hirModel = fac_hir::analyze(ps);
      if (hirModel.modules.size() != ps.size() || !hirModel.validate())
        throw CompileError(0, "internal error: FAC semantic HIR invariant failed");
      ir = g.generate(ps, mainMod, &hasMain, &hirModel);
      hasExports = !g.exportFuncs.empty();
      warningCount = g.nwarn;
      if (!hasMain && libMode && hasExports && !headerPath.empty())
        generatedHeader = g.makeHeader("FAC_" + stemOf(input) + "_H");
      // Avoid allocator trimming overhead for small builds. Large module graphs
      // or source sets are the cases where frontend release can return pages.
      trimFrontendHeap = ld.progs.size() >= 32 || ld.totalSourceBytes >= (size_t(4) << 20);
    }
#if defined(__GLIBC__)
    // glibc may retain freed frontend arenas in the process heap. Ask it to
    // return fully free pages before launching the memory-hungry LLVM backend.
    // This is best-effort and has no effect on non-glibc platforms/allocators.
    if (trimFrontendHeap) (void)malloc_trim(0);
#endif
    if (warningCount) std::cerr << "facc: " << warningCount << " จุดที่ --safe จะปฏิเสธ (ครอบด้วย unsafe { ... } หรือย้ายไปไว้ใน unsafe function)\n";
  } catch (CompileError &e) {
    std::string m = e.what();
    if (m.find(".fac:") != std::string::npos) std::cerr << m << "\n";
    else std::cerr << input << ":" << e.line << (e.column > 0 ? ":" + std::to_string(e.column) : std::string()) << ": error: " << m << "\n";
    return 1;
  }
  if (!hasMain && libMode && hasExports) {
    if (!headerPath.empty()) { std::ofstream hf(headerPath); hf << generatedHeader; }
  } else if (!hasMain) { std::cerr << input << ": error: ไม่พบ entry point: ใช้ 'public function void main()' หรือ 'public class App { public static function void main(...) }'\n"; return 1; }

  if (output.empty()) output = stemOf(input) + (emitLL ? ".ll" : "");
#ifdef _WIN32
  if (!emitLL && output.size() < 4) output += ".exe";
  else if (!emitLL && output.substr(output.size() - 4) != ".exe") output += ".exe";
#endif
  if (emitLL) { std::ofstream f(output); if (!f) { std::cerr << "facc: เขียนไฟล์ไม่ได้: " << output << "\n"; return 1; } f << ir; return f.good() ? 0 : 1; }
  if (libMode && objOnly && output.find('.') == std::string::npos) output += ".o";
  if (shared && output.find('.') == std::string::npos) {
#ifdef _WIN32
    output += ".dll";
#else
    output += ".so";
#endif
  }
  std::string ll = output + ".ll";
  { std::ofstream f(ll); if (!f) { std::cerr << "facc: เขียนไฟล์ LLVM IR ไม่ได้: " << ll << "\n"; return 1; } f << ir; if (!f.good()) { std::cerr << "facc: เขียนไฟล์ LLVM IR ไม่สำเร็จ: " << ll << "\n"; return 1; } }

  std::string rt = home + "/libfacrt.a";
  if (const char *r = getenv("FAC_RT")) rt = r;
  const char *be = getenv("FAC_BACKEND");
  const char *cc = getenv("FAC_CC");
  if (!target.empty() && !safeToken(target, "_-.+")) { std::cerr << "facc: --target มีอักขระที่ไม่รองรับ\n"; return 2; }
  if (!cpu.empty() && !safeToken(cpu, "_-.+")) { std::cerr << "facc: --cpu มีอักขระที่ไม่รองรับ\n"; return 2; }
  // FAC V16's runtime and data layout currently assume 64-bit pointers.
  if (!target.empty()) {
    std::string arch = target.substr(0, target.find('-'));
    std::transform(arch.begin(), arch.end(), arch.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    static const std::set<std::string> supported64 = {
      "x86_64", "amd64", "aarch64", "arm64", "riscv64", "ppc64", "ppc64le",
      "powerpc64", "powerpc64le", "s390x", "loongarch64"
    };
    if (!supported64.count(arch)) {
      std::cerr << "facc: target architecture '" << arch
                << "' อยู่นอก allowlist 64-bit architecture ของ FAC V16; 32-bit/wasm32/microcontroller ยังไม่รองรับ\n";
      return 2;
    }
  }
  std::vector<std::string> targetFlags;
  if (!target.empty()) targetFlags.push_back("--target=" + target);
  if (!cpu.empty()) targetFlags.push_back("-mcpu=" + cpu);
  if (!sysroot.empty()) { targetFlags.push_back("--sysroot=" + sysroot); }
  if (!features.empty()) {
    size_t at = 0;
    while (at < features.size()) {
      size_t comma = features.find(',', at);
      std::string f = features.substr(at, comma == std::string::npos ? std::string::npos : comma - at);
      if (f.size() < 2 || (f[0] != '+' && f[0] != '-') || !safeToken(f, "_-.+")) {
        std::cerr << "facc: --features ต้องเป็นรายการ +feature/-feature คั่นด้วย comma\n"; return 2;
      }
      targetFlags.insert(targetFlags.end(), {"-Xclang", "-target-feature", "-Xclang", f});
      if (comma == std::string::npos) break;
      at = comma + 1;
    }
  }
  if (lto) targetFlags.insert(targetFlags.end(), {"-flto=thin", "-fuse-ld=lld"});
  if (be && std::string(be) == "llcheck" && (!target.empty() || !cpu.empty() || !features.empty() || !sysroot.empty() || lto)) {
    std::cerr << "facc: --target/--cpu/--features/--sysroot/--lto ต้องใช้ clang backend (ไม่ใช่ FAC_BACKEND=llcheck)\n"; return 2;
  }
  // Select system libraries for the *target*, not the host facc executable.
  // The runtime currently uses dlopen on Unix-like targets and Win32 APIs on Windows.
  std::string targetSyslibs = WINLIBS;
  if (!target.empty()) {
    std::string t = target;
    std::transform(t.begin(), t.end(), t.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    if (t.find("windows") != std::string::npos || t.find("mingw") != std::string::npos || t.find("msvc") != std::string::npos)
      targetSyslibs = " -lws2_32 -lgdi32 -luser32 -lwinmm";
    else if (t.find("darwin") != std::string::npos || t.find("apple") != std::string::npos)
      targetSyslibs = ""; // dlopen is provided by libSystem
    else if (t.find("linux") != std::string::npos)
      targetSyslibs = " -ldl";
    else {
      std::cerr << "facc: ยังไม่มี system-library profile สำหรับ target '" << target
                << "'; เพิ่ม libraries เองด้วย -l / -L / --pkg\n";
      targetSyslibs = "";
    }
  }
  // Resolve pkg-config names without allowing shell metacharacters. Compiler/linker
  // invocations below use argv + exec/spawn and never pass through a command shell.
  for (const auto &pk : packages) {
    if (!safeToken(pk, "_.+-") || pk[0] == '-') {
      std::cerr << "facc: ชื่อ package ใน --pkg มีอักขระที่ไม่รองรับ\n"; return 2;
    }
#ifdef _WIN32
    FILE *pf = _popen(("pkg-config --cflags --libs " + pk).c_str(), "r");
#else
    FILE *pf = popen(("pkg-config --cflags --libs " + pk).c_str(), "r");
#endif
    if (!pf) { std::cerr << "facc: เรียก pkg-config ไม่ได้\n"; return 1; }
    std::string outputFlags; char buf[1024]; size_t nr;
    while ((nr = fread(buf, 1, sizeof(buf), pf)) != 0) outputFlags.append(buf, nr);
#ifdef _WIN32
    int prc = _pclose(pf);
#else
    int prc = pclose(pf);
#endif
    if (prc != 0) { std::cerr << "facc: pkg-config ล้มเหลวสำหรับ " << pk << "\n"; return 1; }
    if (!splitPkgFlags(outputFlags, flags)) { std::cerr << "facc: output จาก pkg-config มี quoting ผิดรูปแบบ\n"; return 1; }
  }
  int rc = 0;
  const std::string compiler = (cc && *cc) ? cc : (be && std::string(be) == "llcheck" ? "g++" : "clang++");
  if (be && std::string(be) == "llcheck") {  // ทดสอบ: ผ่าน LLVM C API ตรงๆ (ไม่ต้องมี clang)
    std::string lc = home + "/llcheck", obj = objOnly ? output : output + ".o";
    std::string lvl = opt.substr(1);
    rc = run({lc, ll, obj, lvl}, verbose);
    if (rc == 0 && objOnly) { if (!getenv("FAC_KEEP_LL")) remove(ll.c_str()); return 0; }
    if (rc == 0) {
      std::vector<std::string> cmd{compiler};
      cmd.insert(cmd.end(), targetFlags.begin(), targetFlags.end());
      if (shared) cmd.insert(cmd.end(), {"-shared", "-fPIC"});
      cmd.push_back(obj); cmd.insert(cmd.end(), extras.begin(), extras.end()); cmd.push_back(rt);
      cmd.insert(cmd.end(), flags.begin(), flags.end()); cmd.insert(cmd.end(), extraLinks.begin(), extraLinks.end());
      cmd.insert(cmd.end(), {"-lm", "-pthread"});
      if (!targetSyslibs.empty()) { std::istringstream is(targetSyslibs); std::string x; while (is >> x) cmd.push_back(x); }
      cmd.insert(cmd.end(), {"-o", output});
      rc = run(cmd, verbose);
    }
    remove(obj.c_str());
  } else {
    std::vector<std::string> cmd{compiler};
    cmd.insert(cmd.end(), targetFlags.begin(), targetFlags.end());
    cmd.push_back(opt);
    if (objOnly) cmd.insert(cmd.end(), {"-c", "-fPIC"});
    else if (shared) cmd.insert(cmd.end(), {"-shared", "-fPIC"});
    cmd.insert(cmd.end(), {"-Wno-override-module", "-x", "ir", ll, "-x", "none"});
    cmd.insert(cmd.end(), extras.begin(), extras.end()); cmd.push_back(rt);
    cmd.insert(cmd.end(), flags.begin(), flags.end()); cmd.insert(cmd.end(), extraLinks.begin(), extraLinks.end());
    cmd.insert(cmd.end(), {"-lm", "-pthread"});
    if (!targetSyslibs.empty()) { std::istringstream is(targetSyslibs); std::string x; while (is >> x) cmd.push_back(x); }
    cmd.insert(cmd.end(), {"-o", output});
    rc = run(cmd, verbose);
  }
  if (!getenv("FAC_KEEP_LL")) remove(ll.c_str());
  if (rc != 0) { std::cerr << "facc: backend ล้มเหลว (ตั้ง FAC_KEEP_LL=1 เพื่อเก็บไฟล์ .ll ดู)\n"; return 1; }
  if (runAfter) {
#ifdef _WIN32
    return run({(output.find_first_of("/\\") == std::string::npos) ? ".\\" + output : output}, verbose);
#else
    return run({output.find('/') == std::string::npos ? "./" + output : output}, verbose);
#endif
  }
  return 0;
}
