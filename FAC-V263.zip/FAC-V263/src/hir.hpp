#pragma once

// FAC declaration, typed expression, lexical scope, and conservative overload HIR.
// Resolution metadata is additive: Codegen remains authoritative for language
// diagnostics and lowering until each semantic rule has been migrated fully.
#include "ast.hpp"
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <functional>
#include <iomanip>
#include <limits>
#include <map>
#include <stdexcept>
#include <sstream>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace fac_hir {

using TypeId = uint32_t;
using SymbolId = uint32_t;
using ScopeId = uint32_t;
using LocalSymbolId = uint32_t;
static constexpr ScopeId kInvalidScope = std::numeric_limits<ScopeId>::max();
static constexpr LocalSymbolId kInvalidLocal = std::numeric_limits<LocalSymbolId>::max();
static constexpr TypeId kInvalidType = 0;
static constexpr SymbolId kInvalidSymbol = std::numeric_limits<SymbolId>::max();

enum class NameResolutionKind : uint8_t {
  NotApplicable,
  Builtin,
  GenericParameter,
  Resolved,
  NotFound,
  Ambiguous,
  NotImported,
  Private,
  Filtered,
  AliasCycle
};

enum class TypeResolutionKind : uint8_t {
  NotApplicable,
  Builtin,
  GenericParameter,
  Struct,
  Class,
  Interface,
  Enum,
  Unresolved
};

struct ResolvedName {
  TypeId type = kInvalidType;
  std::string spelling;
  std::string canonicalName;
  SymbolId symbol = kInvalidSymbol;
  NameResolutionKind kind = NameResolutionKind::NotApplicable;
  TypeResolutionKind typeKind = TypeResolutionKind::NotApplicable;
};

enum class TypeCategory : uint8_t {
  Unknown,
  Builtin,
  Named,
  Pointer,
  Heap,
  Dynamic,
  Array,
  List,
  Map,
  Container,
  Matrix,
  Function,
  Tuple,
  Other
};

enum class SymbolKind : uint8_t {
  Function,
  Struct,
  Class,
  Interface,
  Enum,
  Global
};

enum class DeclarationOrigin : uint8_t { Source, Generated };

struct TypeDescriptor {
  TypeCategory category = TypeCategory::Unknown;
  std::string cat;
  std::string kind;
  std::string base;
  std::string base2;
  bool isConstValue = false;
  int64_t constValue = 0;
  bool isConstExpression = false;
  std::string constExpressionKey;
  std::string lifetime;
  int lifetimeParamIndex = -1;
  bool elemObj = false;
  bool isVolatile = false;
  bool hasSize = false;
  bool hasSize2 = false;
  bool hasSignature = false;
  std::vector<TypeId> genericArguments;
  std::vector<TypeId> parameters;
  TypeId returnType = kInvalidType;
  std::vector<bool> noescape;
  std::vector<bool> readonly;
  std::vector<std::string> lifetimeParameters;
  std::vector<std::pair<int, int>> lifetimeOutlives;
};

// A TypeId identifies the structural type. Array dimensions remain attached
// to each use-site because their expressions belong to the source AST and
// must not be lost when structurally equal types are interned.
struct TypeUse {
  TypeId type = kInvalidType;
  const Node *sizeExpression = nullptr;
  const Node *secondSizeExpression = nullptr;
  bool hasSize = false;
  bool hasSecondSize = false;
  // Resolution is use-site scoped: the same interned TypeId can name different
  // declarations in different importing modules. Nested generic/function
  // references are retained in `names` in deterministic depth-first order.
  SymbolId resolvedSymbol = kInvalidSymbol;
  NameResolutionKind resolution = NameResolutionKind::NotApplicable;
  TypeResolutionKind resolvedTypeKind = TypeResolutionKind::NotApplicable;
  std::vector<ResolvedName> names;
};

class TypeArena {
 public:
  TypeArena() {
    // Type zero is a stable sentinel for an absent/unknown type.
    types_.push_back(TypeDescriptor{});
  }

  TypeId intern(const TypeSpec &spec) {
    const std::string key = canonicalKey(spec);
    auto found = canonical_.find(key);
    if (found != canonical_.end()) return found->second;

    if (types_.size() >= static_cast<size_t>(std::numeric_limits<TypeId>::max()))
      throw std::overflow_error("FAC HIR type table exhausted TypeId space");

    TypeDescriptor descriptor;
    descriptor.category = classify(spec);
    descriptor.cat = spec.cat;
    descriptor.kind = spec.kind;
    descriptor.base = spec.base;
    descriptor.base2 = spec.base2;
    descriptor.isConstValue = spec.isConstValue;
    descriptor.constValue = spec.constValue;
    descriptor.isConstExpression = static_cast<bool>(spec.constExpr);
    if (spec.constExpr) appendConstExpression(descriptor.constExpressionKey, spec.constExpr.get());
    descriptor.lifetime = spec.lifetime;
    descriptor.lifetimeParamIndex = spec.lifetimeParamIndex;
    descriptor.elemObj = spec.elemObj;
    descriptor.isVolatile = spec.isVolatile;
    descriptor.hasSize = spec.hasSize;
    descriptor.hasSize2 = spec.hasSize2;
    descriptor.hasSignature = spec.hasSig;
    descriptor.noescape = spec.sigNoescape;
    descriptor.readonly = spec.sigReadonly;
    descriptor.lifetimeParameters = spec.sigLifetimeParams;
    descriptor.lifetimeOutlives = spec.sigLifetimeOutlives;
    descriptor.genericArguments.reserve(spec.genericArgs.size());
    for (const TypeSpec &arg : spec.genericArgs)
      descriptor.genericArguments.push_back(intern(arg));
    descriptor.parameters.reserve(spec.sig.size());
    for (const TypeSpec &param : spec.sig)
      descriptor.parameters.push_back(intern(param));
    if (spec.sigReturnType) descriptor.returnType = intern(*spec.sigReturnType);

    const TypeId id = static_cast<TypeId>(types_.size());
    types_.push_back(std::move(descriptor));
    canonical_.emplace(key, id);
    return id;
  }

  TypeUse use(const TypeSpec &spec) {
    TypeUse result;
    result.type = intern(spec);
    result.sizeExpression = spec.size.get();
    result.secondSizeExpression = spec.size2.get();
    result.hasSize = spec.hasSize;
    result.hasSecondSize = spec.hasSize2;
    return result;
  }

  const TypeDescriptor &get(TypeId id) const {
    if (id >= types_.size()) throw std::out_of_range("invalid FAC HIR TypeId");
    return types_[id];
  }

  size_t size() const { return types_.size() - 1; }

  // Intern expression-only composite shapes that do not originate from a
  // TypeSpec (for example tuple literals). The key is namespaced separately
  // from source TypeSpec keys so the two representations cannot collide.
  TypeId internComposite(TypeCategory category, const std::vector<TypeId> &components,
                         TypeId returnType = kInvalidType) {
    std::string key = "@composite:" + std::to_string(static_cast<unsigned>(category)) + ":";
    key += std::to_string(returnType) + ":[";
    for (TypeId component : components) {
      if (component == kInvalidType || component >= types_.size())
        throw std::out_of_range("invalid component TypeId in FAC HIR composite");
      key += std::to_string(component) + ",";
    }
    key += "]";
    auto found = canonical_.find(key);
    if (found != canonical_.end()) return found->second;
    if (types_.size() >= static_cast<size_t>(std::numeric_limits<TypeId>::max()))
      throw std::overflow_error("FAC HIR type table exhausted TypeId space");
    TypeDescriptor descriptor;
    descriptor.category = category;
    descriptor.cat = category == TypeCategory::Tuple ? "tuple" :
                     category == TypeCategory::Function ? "func" : "composite";
    if (category == TypeCategory::Tuple) descriptor.genericArguments = components;
    else descriptor.parameters = components;
    descriptor.returnType = returnType;
    descriptor.hasSignature = category == TypeCategory::Function;
    const TypeId id = static_cast<TypeId>(types_.size());
    types_.push_back(std::move(descriptor));
    canonical_.emplace(std::move(key), id);
    return id;
  }


  // Intern a structurally substituted descriptor. The key uses the same
  // recursive representation as TypeSpec so a substituted type reuses an
  // existing canonical TypeId whenever its complete shape already exists.
  TypeId internDescriptor(const TypeDescriptor &descriptor) {
    std::string key;
    appendDescriptor(key, descriptor);
    auto found = canonical_.find(key);
    if (found != canonical_.end()) return found->second;
    if (types_.size() >= static_cast<size_t>(std::numeric_limits<TypeId>::max()))
      throw std::overflow_error("FAC HIR type table exhausted TypeId space");
    validateDescriptor(descriptor);
    const TypeId id = static_cast<TypeId>(types_.size());
    types_.push_back(descriptor);
    canonical_.emplace(std::move(key), id);
    return id;
  }

 private:
  static TypeCategory classify(const TypeSpec &spec) {
    if (spec.isConstValue || spec.constExpr) return TypeCategory::Other;
    if (spec.cat == "array") return TypeCategory::Array;
    if (spec.cat == "list") return TypeCategory::List;
    if (spec.cat == "hashmap" || spec.cat == "map") return TypeCategory::Map;
    if (spec.cat == "matrix") return TypeCategory::Matrix;
    if (spec.cat == "arraylist" || spec.cat == "linked" || spec.cat == "hashset" ||
        spec.cat == "tree" || spec.cat == "graph" || spec.cat == "stack" ||
        spec.cat == "queue" || spec.cat == "heap" || spec.cat == "maxheap" ||
        spec.cat == "trie") return TypeCategory::Container;
    if (spec.cat == "tuple") return TypeCategory::Tuple;
    if (spec.cat == "func" || spec.hasSig) return TypeCategory::Function;
    if (spec.kind == "ptr") return TypeCategory::Pointer;
    if (spec.kind == "heap") return TypeCategory::Heap;
    if (spec.kind == "dyn") return TypeCategory::Dynamic;
    if (spec.cat == "obj" || spec.cat == "weakobj" ||
        spec.cat == "struct" || spec.cat == "enum") return TypeCategory::Named;
    if (spec.base.empty()) return TypeCategory::Unknown;
    static const char *const builtins[] = {
      "void", "bool", "boolean", "byte", "ubyte", "short", "ushort",
      "int", "uint", "long", "ulong", "float", "double", "char",
      "unichar", "string", "auto", "ptr", "weak", "null"
    };
    for (const char *builtin : builtins) if (spec.base == builtin) return TypeCategory::Builtin;
    if (spec.base == "obj" || spec.base == "weak") return TypeCategory::Named;
    return TypeCategory::Other;
  }

  static void appendPart(std::string &out, const std::string &part) {
    out += std::to_string(part.size());
    out.push_back(':');
    out += part;
    out.push_back(';');
  }

  static void appendConstExpression(std::string &out, const Node *expression,
                                    unsigned depth = 0) {
    if (!expression || depth > 128) { appendPart(out, "<invalid-const-expr>"); return; }
    out += std::to_string(static_cast<unsigned>(expression->k));
    out.push_back(':');
    appendPart(out, expression->s);
    out += std::to_string(expression->iv); out.push_back(';');
    out += expression->b ? "1;" : "0;";
    out += std::to_string(expression->c.size()); out.push_back('[');
    for (const auto &child : expression->c)
      appendConstExpression(out, child.get(), depth + 1);
    out.push_back(']');
  }

  static void appendType(std::string &out, const TypeSpec &spec) {
    appendPart(out, spec.cat);
    appendPart(out, spec.kind);
    appendPart(out, spec.base);
    appendPart(out, spec.base2);
    out += spec.isConstValue ? "C" : "T";
    out += std::to_string(spec.constValue);
    out.push_back(';');
    out += spec.constExpr ? "E" : "e";
    if (spec.constExpr) appendConstExpression(out, spec.constExpr.get());
    out.push_back(';');
    appendPart(out, spec.lifetime);
    out += spec.elemObj ? "1" : "0";
    out += spec.isVolatile ? "1" : "0";
    out += spec.hasSize ? "1" : "0";
    out += spec.hasSize2 ? "1" : "0";
    out += std::to_string(spec.lifetimeParamIndex);
    out.push_back(';');
    out += spec.hasSig ? "1;" : "0;";

    out += std::to_string(spec.sig.size()); out.push_back('[');
    for (const TypeSpec &parameter : spec.sig) appendType(out, parameter);
    out.push_back(']');
    out += std::to_string(spec.genericArgs.size()); out.push_back('{');
    for (const TypeSpec &argument : spec.genericArgs) appendType(out, argument);
    out.push_back('}');
    if (spec.sigReturnType) { out.push_back('R'); appendType(out, *spec.sigReturnType); }
    else out.push_back('r');

    out += std::to_string(spec.sigNoescape.size()); out.push_back('N');
    for (bool value : spec.sigNoescape) out += value ? '1' : '0';
    out += std::to_string(spec.sigReadonly.size()); out.push_back('D');
    for (bool value : spec.sigReadonly) out += value ? '1' : '0';
    out += std::to_string(spec.sigLifetimeParams.size()); out.push_back('L');
    for (const std::string &name : spec.sigLifetimeParams) appendPart(out, name);
    out += std::to_string(spec.sigLifetimeOutlives.size()); out.push_back('O');
    for (const auto &edge : spec.sigLifetimeOutlives) {
      out += std::to_string(edge.first); out.push_back(',');
      out += std::to_string(edge.second); out.push_back(';');
    }
  }

  static std::string canonicalKey(const TypeSpec &spec) {
    std::string key;
    appendType(key, spec);
    return key;
  }

  void appendDescriptor(std::string &out, const TypeDescriptor &descriptor) const {
    appendPart(out, descriptor.cat);
    appendPart(out, descriptor.kind);
    appendPart(out, descriptor.base);
    appendPart(out, descriptor.base2);
    out += descriptor.isConstValue ? "C" : "T";
    out += std::to_string(descriptor.constValue);
    out.push_back(';');
    out += descriptor.isConstExpression ? "E" : "e";
    if (descriptor.isConstExpression) out += descriptor.constExpressionKey;
    out.push_back(';');
    appendPart(out, descriptor.lifetime);
    out += descriptor.elemObj ? "1" : "0";
    out += descriptor.isVolatile ? "1" : "0";
    out += descriptor.hasSize ? "1" : "0";
    out += descriptor.hasSize2 ? "1" : "0";
    out += std::to_string(descriptor.lifetimeParamIndex);
    out.push_back(';');
    out += descriptor.hasSignature ? "1;" : "0;";

    out += std::to_string(descriptor.parameters.size()); out.push_back('[');
    for (TypeId parameter : descriptor.parameters) {
      if (parameter >= types_.size()) throw std::out_of_range("invalid parameter TypeId");
      appendDescriptor(out, types_[parameter]);
    }
    out.push_back(']');
    out += std::to_string(descriptor.genericArguments.size()); out.push_back('{');
    for (TypeId argument : descriptor.genericArguments) {
      if (argument >= types_.size()) throw std::out_of_range("invalid generic argument TypeId");
      appendDescriptor(out, types_[argument]);
    }
    out.push_back('}');
    if (descriptor.returnType != kInvalidType) {
      if (descriptor.returnType >= types_.size()) throw std::out_of_range("invalid return TypeId");
      out.push_back('R'); appendDescriptor(out, types_[descriptor.returnType]);
    } else out.push_back('r');

    out += std::to_string(descriptor.noescape.size()); out.push_back('N');
    for (bool value : descriptor.noescape) out += value ? '1' : '0';
    out += std::to_string(descriptor.readonly.size()); out.push_back('D');
    for (bool value : descriptor.readonly) out += value ? '1' : '0';
    out += std::to_string(descriptor.lifetimeParameters.size()); out.push_back('L');
    for (const std::string &name : descriptor.lifetimeParameters) appendPart(out, name);
    out += std::to_string(descriptor.lifetimeOutlives.size()); out.push_back('O');
    for (const auto &edge : descriptor.lifetimeOutlives) {
      out += std::to_string(edge.first); out.push_back(',');
      out += std::to_string(edge.second); out.push_back(';');
    }
  }

  void validateDescriptor(const TypeDescriptor &descriptor) const {
    auto valid = [&](TypeId id) { return id == kInvalidType || id < types_.size(); };
    for (TypeId id : descriptor.parameters)
      if (!valid(id)) throw std::out_of_range("invalid parameter TypeId");
    for (TypeId id : descriptor.genericArguments)
      if (!valid(id)) throw std::out_of_range("invalid generic argument TypeId");
    if (!valid(descriptor.returnType)) throw std::out_of_range("invalid return TypeId");
  }

  std::vector<TypeDescriptor> types_;
  std::unordered_map<std::string, TypeId> canonical_;
};

struct SourceLocation {
  std::string file;
  std::string module;
  int line = 0;
};

struct Parameter {
  std::string name;
  TypeUse type;
  bool ref = false;
  bool immutableRef = false;
  bool variadic = false;
  bool noescape = false;
  bool readonly = false;
  bool hasDefault = false;
};

struct Field {
  std::string name;
  TypeUse type;
  SourceLocation location;
  bool isPublic = false;
  bool isPrivate = false;
  bool isProtected = false;
  bool isStatic = false;
  bool isConst = false;
};

struct EnumVariant {
  std::string name;
  int64_t value = 0;
  std::string stringValue;
  std::vector<TypeUse> payload;
};

struct GenericConstraint {
  std::string parameter;
  TypeUse bound;
  // Value predicates constrain a const int generic parameter and therefore
  // have no TypeUse. The codegen specialization pass evaluates them against
  // the concrete integer argument; HIR preserves the predicate as metadata.
  std::string valuePredicate;
  bool isConstValuePredicate = false;
};

struct Declaration {
  SymbolId id = kInvalidSymbol;
  DeclarationOrigin origin = DeclarationOrigin::Source;
  // Non-owning source node; the parsed Program owns this tree for the whole
  // semantic/codegen phase. It is used to build source-mapped expression HIR.
  const Node *sourceNode = nullptr;
  SymbolKind kind = SymbolKind::Function;
  std::string module;
  std::string owner;
  std::string name;
  std::string qualifiedName;
  SourceLocation location;
  TypeUse declaredType;
  TypeUse returnType;
  std::vector<Parameter> parameters;
  std::vector<Field> fields;
  std::vector<EnumVariant> variants;
  std::vector<SymbolId> methods;
  std::vector<std::string> typeParameters;
  std::vector<std::string> constTypeParameters;
  std::vector<bool> genericHasDefault;
  std::vector<std::string> lifetimeParameters;
  std::vector<std::pair<int, int>> lifetimeOutlives;
  std::vector<GenericConstraint> genericBounds;
  TypeUse parentType;
  std::vector<TypeUse> implementedTypes;
  std::string parentName;
  bool isPublic = false;
  bool isPrivate = false;
  bool isProtected = false;
  bool isStatic = false;
  bool isConst = false;
  bool isUnsafe = false;
  bool isExtern = false;
  bool isExport = false;
  bool isAbstract = false;
  bool isFinal = false;
  bool isClass = false;
  bool isInterface = false;
  bool isConstructor = false;
  bool isDestructor = false;
  bool isGeneric = false;
};

struct ImportBinding {
  std::string module;
  std::string alias;
  bool global = false;
  int line = 0;
  int selection = 0;
  std::vector<std::string> names;
};

struct StaticAssertionInfo {
  const Node *expression = nullptr;
  std::string message;
  int line = 0;
};

struct Module {
  std::string name;
  std::string file;
  std::vector<std::string> imports;
  std::vector<ImportBinding> importBindings;
  std::vector<std::pair<std::string, std::string>> aliases;
  std::vector<std::string> links;
  std::vector<StaticAssertionInfo> staticAssertions;
  std::vector<SymbolId> declarations;
};

struct NameResolutionSummary {
  size_t references = 0;
  size_t resolved = 0;
  size_t builtins = 0;
  size_t genericParameters = 0;
  size_t notFound = 0;
  size_t ambiguous = 0;
  size_t accessDenied = 0;
  size_t aliasCycles = 0;
};

struct TypeResolutionSummary {
  size_t references = 0;
  size_t builtins = 0;
  size_t genericParameters = 0;
  size_t structs = 0;
  size_t classes = 0;
  size_t interfaces = 0;
  size_t enums = 0;
  size_t unresolved = 0;
};

using ExprId = uint32_t;
static constexpr ExprId kInvalidExpr = std::numeric_limits<ExprId>::max();

enum class ExprTypeState : uint8_t { Unresolved, Known, Dependent };
enum class ExprTypeOrigin : uint8_t { None, Literal, OperatorRule, BuiltinContract, ExplicitSyntax, LocalBinding, OverloadResolution };

enum class ScopeKind : uint8_t { Module, Function, Block, Loop, Lambda, Catch, MatchArm };

struct LocalSymbol {
  LocalSymbolId id = kInvalidLocal;
  std::string name;
  TypeId type = kInvalidType;
  ScopeId scope = kInvalidScope;
  SymbolId owner = kInvalidSymbol;
  std::string module;
  SourceLocation location;
  uint64_t sourceOrder = 0;
  const Node *declaration = nullptr;
  bool isParameter = false;
  bool isConst = false;
  bool isReference = false;
  bool isImmutableReference = false;
  bool isInferred = false;
};

struct LexicalScope {
  ScopeId id = kInvalidScope;
  ScopeId parent = kInvalidScope;
  ScopeKind kind = ScopeKind::Block;
  SymbolId owner = kInvalidSymbol;
  std::string module;
  std::map<std::string, LocalSymbolId> names;
  std::vector<LocalSymbolId> locals;
};

enum class CallResolutionState : uint8_t {
  NotApplicable, Deferred, LocalCallable, NoCandidates, NoViableCandidate,
  Ambiguous, Resolved, UnsupportedMemberCall
};

enum class GenericInferenceState : uint8_t {
  NotGeneric, ExplicitArguments, InferredFromArguments, Deferred, ConstraintFailure
};

enum class SemanticDiagnosticSeverity : uint8_t { Note, Warning, Error };

struct SemanticDiagnostic {
  std::string code;
  SemanticDiagnosticSeverity severity = SemanticDiagnosticSeverity::Note;
  std::string message;
  SourceLocation location;
  ExprId expression = kInvalidExpr;
};

struct SemanticDiagnosticSummary {
  size_t notes = 0;
  size_t warnings = 0;
  size_t errors = 0;
};

struct CallResolution {
  CallResolutionState state = CallResolutionState::NotApplicable;
  GenericInferenceState genericState = GenericInferenceState::NotGeneric;
  std::string calleePath;
  std::vector<SymbolId> candidates;
  SymbolId selected = kInvalidSymbol;
  int conversionCost = -1;
  std::map<std::string, TypeId> substitutions;
  std::vector<TypeId> explicitTypeArguments;
  bool isMethodCall = false;
};

struct Expression {
  ExprId id = kInvalidExpr;
  ExprId parent = kInvalidExpr;
  std::vector<ExprId> children;
  const Node *source = nullptr;
  SymbolId owner = kInvalidSymbol;
  ScopeId lexicalScope = kInvalidScope;
  LocalSymbolId localBinding = kInvalidLocal;
  CallResolution call;
  std::string module;
  std::string file;
  uint64_t sourceOrder = 0;
  int line = 0;
  TypeId type = kInvalidType;
  ExprTypeState typeState = ExprTypeState::Unresolved;
  ExprTypeOrigin typeOrigin = ExprTypeOrigin::None;
  bool potentialLValue = false;
  bool hasSideEffects = false;
};

struct ExpressionHirSummary {
  size_t expressions = 0;
  size_t typed = 0;
  size_t unresolved = 0;
  size_t dependent = 0;
  size_t literals = 0;
  size_t operators = 0;
  size_t calls = 0;
};

// Immutable, source-mapped typed-expression nodes. These nodes are a
// conservative projection of expression HIR: only expressions with a known
// TypeId and fully materialized typed children are admitted. The source AST
// remains the parser/codegen representation; this layer is the typed view
// consumed by future compile-time tooling.
using TypedAstId = uint32_t;
static constexpr TypedAstId kInvalidTypedAst = std::numeric_limits<TypedAstId>::max();

enum class TypedAstKind : uint8_t {
  IntLiteral, FloatLiteral, CharLiteral, StringLiteral, BoolLiteral, NullLiteral,
  Identifier, Unary, Postfix, Binary, Call, NewObject, Tuple
};

enum class TypedAstOrigin : uint8_t { Source, Generated };
enum class GeneratedBindingKind : uint8_t { None, Parameter, Local };
static constexpr uint32_t kInvalidGeneratedBinding = std::numeric_limits<uint32_t>::max();

inline bool typedAstIntegerType(const TypeDescriptor &type) {
  static const std::set<std::string> names = {
    "byte", "short", "int", "long", "ubyte", "ushort", "uint", "ulong",
    "char", "unichar", "enum"
  };
  return names.count(type.base) != 0;
}

inline bool typedAstNumericType(const TypeDescriptor &type) {
  return typedAstIntegerType(type) || type.base == "float" || type.base == "double";
}

inline bool typedAstArithmeticType(const TypeDescriptor &type) {
  return (typedAstIntegerType(type) && type.base != "enum") ||
         type.base == "float" || type.base == "double";
}

inline bool typedAstIntegerLiteralFits(int64_t value, const TypeDescriptor &type) {
  const std::string &name = type.base;
  if (name == "byte" || name == "char")
    return value >= std::numeric_limits<int8_t>::min() &&
           value <= std::numeric_limits<int8_t>::max();
  if (name == "ubyte") return value >= 0 && value <= std::numeric_limits<uint8_t>::max();
  if (name == "short")
    return value >= std::numeric_limits<int16_t>::min() &&
           value <= std::numeric_limits<int16_t>::max();
  if (name == "ushort") return value >= 0 && value <= std::numeric_limits<uint16_t>::max();
  if (name == "int")
    return value >= std::numeric_limits<int32_t>::min() &&
           value <= std::numeric_limits<int32_t>::max();
  if (name == "uint") return value >= 0 && static_cast<uint64_t>(value) <= std::numeric_limits<uint32_t>::max();
  if (name == "long") return true;
  if (name == "ulong") return value >= 0;
  if (name == "unichar") return value >= 0 && value <= 0x10FFFF;
  return false;
}

inline bool typedAstCharacterLiteralFits(int64_t value, const TypeDescriptor &type) {
  if (type.base == "char") return value >= 0 && value <= std::numeric_limits<uint8_t>::max();
  if (type.base == "unichar") return value >= 0 && value <= 0x10FFFF;
  return false;
}

inline bool typedAstSameTypeShape(const TypeArena &types, TypeId left, TypeId right) {
  if (left == kInvalidType || right == kInvalidType ||
      left > types.size() || right > types.size()) return false;
  const TypeDescriptor &a = types.get(left), &b = types.get(right);
  return a.category == b.category && a.cat == b.cat && a.kind == b.kind &&
         a.base == b.base && a.base2 == b.base2 && a.genericArguments == b.genericArguments;
}

inline bool typedAstUnaryContract(const TypeArena &types, const std::string &op,
                                  TypeId operandType, TypeId resultType) {
  if (operandType == kInvalidType || resultType == kInvalidType ||
      operandType > types.size() || resultType > types.size()) return false;
  const TypeDescriptor &operand = types.get(operandType);
  const TypeDescriptor &result = types.get(resultType);
  if (op == "!") return operand.base == "bool" && result.base == "bool";
  if (op == "~")
    return typedAstIntegerType(operand) && operand.base != "enum" &&
           typedAstSameTypeShape(types, operandType, resultType);
  if (op == "+" || op == "-")
    return typedAstArithmeticType(operand) && typedAstSameTypeShape(types, operandType, resultType);
  return false;
}

inline bool typedAstBinaryContract(const TypeArena &types, const std::string &op,
                                   TypeId lhsType, TypeId rhsType, TypeId resultType) {
  if (lhsType == kInvalidType || rhsType == kInvalidType || resultType == kInvalidType ||
      lhsType > types.size() || rhsType > types.size() || resultType > types.size()) return false;
  const TypeDescriptor &lhs = types.get(lhsType);
  const TypeDescriptor &rhs = types.get(rhsType);
  const TypeDescriptor &result = types.get(resultType);
  const bool sameOperands = typedAstSameTypeShape(types, lhsType, rhsType);
  if (op == "&&" || op == "||")
    return lhs.base == "bool" && rhs.base == "bool" && result.base == "bool";
  if (op == "==" || op == "!=") {
    const bool comparable = typedAstArithmeticType(lhs) || lhs.base == "bool" ||
        lhs.base == "string" || lhs.category == TypeCategory::Pointer ||
        lhs.category == TypeCategory::Heap;
    return sameOperands && comparable && result.base == "bool";
  }
  if (op == "<" || op == "<=" || op == ">" || op == ">=")
    return sameOperands && (typedAstArithmeticType(lhs) || lhs.base == "string") &&
           result.base == "bool";
  if (op == "+" && lhs.base == "string" && rhs.base == "string")
    return result.base == "string";
  if (op == "<<" || op == ">>" || op == "%" || op == "&" || op == "|" || op == "^")
    return sameOperands && typedAstIntegerType(lhs) && lhs.base != "enum" &&
           typedAstSameTypeShape(types, lhsType, resultType);
  if (op == "+" || op == "-" || op == "*" || op == "/" || op == "**")
    return sameOperands && typedAstArithmeticType(lhs) &&
           typedAstSameTypeShape(types, lhsType, resultType);
  return false;
}

struct TypedAstNode;
using TypedAstRef = std::shared_ptr<const TypedAstNode>;

struct TypedAstNode {
  const TypedAstId id;
  const TypedAstKind kind;
  const TypedAstOrigin origin;
  const TypeId type;
  const ExprId sourceExpression;
  const SourceLocation location;
  const std::string spelling;
  const std::vector<TypedAstRef> children;
  const bool hasSideEffects;
  const SymbolId resolvedCallee;
  // Generated identifiers are bound to a parameter or a previously declared
  // local in one generated function. Source identifiers keep these fields at
  // their invalid defaults and retain the ordinary source-HIR binding path.
  const SymbolId bindingFunction;
  const GeneratedBindingKind bindingKind;
  const uint32_t bindingIndex;

  TypedAstNode(TypedAstId nodeId, TypedAstKind nodeKind, TypeId nodeType,
               ExprId sourceId, SourceLocation sourceLocation,
               std::string nodeSpelling, std::vector<TypedAstRef> nodeChildren,
               bool sideEffects, TypedAstOrigin nodeOrigin = TypedAstOrigin::Source,
               SymbolId callee = kInvalidSymbol,
               SymbolId boundFunction = kInvalidSymbol,
               GeneratedBindingKind boundKind = GeneratedBindingKind::None,
               uint32_t boundIndex = kInvalidGeneratedBinding)
      : id(nodeId), kind(nodeKind), origin(nodeOrigin), type(nodeType), sourceExpression(sourceId),
        location(std::move(sourceLocation)), spelling(std::move(nodeSpelling)),
        children(std::move(nodeChildren)), hasSideEffects(sideEffects), resolvedCallee(callee),
        bindingFunction(boundFunction), bindingKind(boundKind), bindingIndex(boundIndex) {}
};

struct TypedAstSummary {
  size_t nodes = 0;
  size_t roots = 0;
  size_t literals = 0;
  size_t operators = 0;
  size_t calls = 0;
  size_t identifiers = 0;
  size_t skippedUnresolved = 0;
  size_t skippedUnsupported = 0;
  size_t generatedNodes = 0;
};

struct TypedAstModel {
  // Nodes are stored in deterministic child-before-parent construction order.
  // `expressions` maps source HIR ExprIds to immutable typed nodes.
  std::vector<TypedAstRef> nodes;
  std::vector<TypedAstRef> roots;
  std::unordered_map<ExprId, TypedAstRef> expressions;
  TypedAstSummary summary;

  bool validate(const TypeArena &types, size_t sourceExpressionCount) const {
    if (summary.nodes != nodes.size() || summary.roots != roots.size() ||
        expressions.size() > nodes.size()) return false;
    std::set<ExprId> seenSources;
    size_t generatedCount = 0;
    for (size_t i = 0; i < nodes.size(); ++i) {
      const TypedAstRef &node = nodes[i];
      if (!node || node->id != i || node->type == kInvalidType || node->type > types.size())
        return false;
      if (node->origin == TypedAstOrigin::Source) {
        if (node->sourceExpression >= sourceExpressionCount ||
            !seenSources.insert(node->sourceExpression).second) return false;
        auto mapped = expressions.find(node->sourceExpression);
        if (mapped == expressions.end() || mapped->second.get() != node.get()) return false;
      } else {
        ++generatedCount;
        if (node->sourceExpression != kInvalidExpr) return false;
        if (node->kind == TypedAstKind::Call && node->resolvedCallee == kInvalidSymbol) return false;
      }
      for (const TypedAstRef &child : node->children) {
        if (!child || child->id >= node->id || child->id >= nodes.size() ||
            nodes[child->id].get() != child.get()) return false;
      }
      switch (node->kind) {
        case TypedAstKind::IntLiteral:
          if (node->origin == TypedAstOrigin::Generated) {
            const TypeDescriptor &literalType = types.get(node->type);
            if (literalType.category != TypeCategory::Builtin ||
                !typedAstIntegerType(literalType) || literalType.base == "enum") return false;
            try {
              size_t used = 0;
              const int64_t value = std::stoll(node->spelling, &used, 10);
              if (used != node->spelling.size() || !typedAstIntegerLiteralFits(value, literalType))
                return false;
            } catch (...) { return false; }
          }
          break;
        case TypedAstKind::FloatLiteral:
          if (node->origin == TypedAstOrigin::Generated &&
              types.get(node->type).base != "float" && types.get(node->type).base != "double")
            return false;
          break;
        case TypedAstKind::CharLiteral:
          if (node->origin == TypedAstOrigin::Generated) {
            const TypeDescriptor &literalType = types.get(node->type);
            try {
              size_t used = 0;
              const int64_t value = std::stoll(node->spelling, &used, 10);
              if (used != node->spelling.size() ||
                  !typedAstCharacterLiteralFits(value, literalType)) return false;
            } catch (...) { return false; }
          }
          break;
        case TypedAstKind::BoolLiteral:
          if (node->origin == TypedAstOrigin::Generated &&
              (types.get(node->type).base != "bool" ||
               (node->spelling != "true" && node->spelling != "false"))) return false;
          break;
        case TypedAstKind::StringLiteral:
          if (node->origin == TypedAstOrigin::Generated && types.get(node->type).base != "string")
            return false;
          break;
        case TypedAstKind::NullLiteral:
          if (node->origin == TypedAstOrigin::Generated) {
            const TypeDescriptor &nullType = types.get(node->type);
            if (nullType.base != "null" && nullType.category != TypeCategory::Pointer &&
                nullType.category != TypeCategory::Heap) return false;
          }
          break;
        case TypedAstKind::Unary:
          if (node->children.size() != 1) return false;
          if (node->origin == TypedAstOrigin::Generated &&
              !typedAstUnaryContract(types, node->spelling, node->children[0]->type, node->type))
            return false;
          break;
        case TypedAstKind::Postfix:
          if (node->children.size() != 1) return false;
          break;
        case TypedAstKind::Binary:
          if (node->children.size() != 2) return false;
          if (node->origin == TypedAstOrigin::Generated &&
              !typedAstBinaryContract(types, node->spelling, node->children[0]->type,
                                      node->children[1]->type, node->type)) return false;
          break;
        case TypedAstKind::Tuple: {
          const TypeDescriptor &tupleType = types.get(node->type);
          if (tupleType.category != TypeCategory::Tuple ||
              tupleType.genericArguments.size() != node->children.size()) return false;
          for (size_t child = 0; child < node->children.size(); ++child)
            if (tupleType.genericArguments[child] != node->children[child]->type) return false;
          break;
        }
        case TypedAstKind::Identifier:
          if (node->origin == TypedAstOrigin::Generated &&
              (node->bindingFunction == kInvalidSymbol ||
               node->bindingKind == GeneratedBindingKind::None ||
               node->bindingIndex == kInvalidGeneratedBinding)) return false;
          break;
        default: break;
      }
    }
    if (seenSources.size() != expressions.size() || generatedCount != summary.generatedNodes)
      return false;
    std::set<TypedAstId> seenRoots;
    for (const TypedAstRef &root : roots) {
      if (!root || root->id >= nodes.size() || nodes[root->id].get() != root.get() ||
          !seenRoots.insert(root->id).second) return false;
    }
    return true;
  }
};

// V220 generated function bodies use a small structured statement model.
// Expressions remain immutable TypedAst nodes; mutation is represented only
// by explicit, type-checked local-assignment statements. The first control-
// flow milestone supports nested if/else regions with a single terminal return.
struct GeneratedFunctionLocal {
  std::string name;
  TypeId type = kInvalidType;
  TypedAstRef initializer;
  SourceLocation location;
  bool isMutable = false;
};

enum class GeneratedFunctionStatementKind : uint8_t { AssignLocal, IfElse };

struct GeneratedFunctionStatement {
  GeneratedFunctionStatementKind kind = GeneratedFunctionStatementKind::AssignLocal;
  uint32_t localIndex = kInvalidGeneratedBinding;
  TypedAstRef expression;
  TypedAstRef condition;
  std::vector<GeneratedFunctionStatement> thenStatements;
  std::vector<GeneratedFunctionStatement> elseStatements;
  bool hasElse = false;
  SourceLocation location;
};

struct GeneratedFunctionBody {
  SymbolId function = kInvalidSymbol;
  std::vector<GeneratedFunctionLocal> locals;
  std::vector<GeneratedFunctionStatement> statements;
  TypedAstRef returnValue;
  bool returnsVoid = false;
  SourceLocation location;
};

struct SemanticModel {
  TypeArena types;
  std::vector<Module> modules;
  std::vector<Declaration> declarations;
  std::map<std::string, std::vector<SymbolId>> symbolsByQualifiedName;
  NameResolutionSummary nameResolution;
  TypeResolutionSummary typeResolution;
  std::vector<Expression> expressions;
  std::unordered_map<const Node *, ExprId> expressionIds;
  ExpressionHirSummary expressionSummary;
  TypedAstModel typedAst;
  std::map<SymbolId, GeneratedFunctionBody> generatedFunctionBodies;
  std::vector<LexicalScope> scopes;
  std::vector<LocalSymbol> locals;
  // Structured, source-mapped HIR diagnostics are provisional during the
  // migration. Codegen remains authoritative until a diagnostic rule has
  // differential coverage and is explicitly promoted to a frontend error.
  std::vector<SemanticDiagnostic> diagnostics;
  SemanticDiagnosticSummary diagnosticSummary;

  std::vector<SymbolId> find(const std::string &qualifiedName) const {
    auto found = symbolsByQualifiedName.find(qualifiedName);
    return found == symbolsByQualifiedName.end() ? std::vector<SymbolId>{} : found->second;
  }

  const Declaration &symbol(SymbolId id) const {
    if (id >= declarations.size()) throw std::out_of_range("invalid FAC HIR SymbolId");
    return declarations[id];
  }

  bool validate() const {
    if (!typedAst.validate(types, expressions.size())) return false;
    for (const TypedAstRef &node : typedAst.nodes) {
      if (node->origin == TypedAstOrigin::Source && node->kind == TypedAstKind::Call &&
          node->resolvedCallee != kInvalidSymbol) {
        if (node->sourceExpression >= expressions.size() ||
            expressions[node->sourceExpression].call.selected != node->resolvedCallee) return false;
      }
      if (node->origin == TypedAstOrigin::Generated && node->kind == TypedAstKind::Call) {
        if (node->resolvedCallee >= declarations.size()) return false;
        const Declaration &callee = declarations[node->resolvedCallee];
        if (callee.kind != SymbolKind::Function || callee.isGeneric ||
            !callee.typeParameters.empty() || !callee.constTypeParameters.empty() ||
            callee.parameters.size() != node->children.size() ||
            callee.returnType.type != node->type) return false;
        for (size_t i = 0; i < node->children.size(); ++i)
          if (callee.parameters[i].type.type != node->children[i]->type) return false;
      }
      if (node->origin == TypedAstOrigin::Generated && node->kind == TypedAstKind::Identifier) {
        if (node->bindingFunction >= declarations.size()) return false;
        const Declaration &owner = declarations[node->bindingFunction];
        if (owner.origin != DeclarationOrigin::Generated || owner.kind != SymbolKind::Function)
          return false;
        auto body = generatedFunctionBodies.find(node->bindingFunction);
        if (body == generatedFunctionBodies.end()) return false;
        if (node->bindingKind == GeneratedBindingKind::Parameter) {
          if (node->bindingIndex >= owner.parameters.size()) return false;
          const Parameter &parameter = owner.parameters[node->bindingIndex];
          if (parameter.name != node->spelling || parameter.type.type != node->type) return false;
        } else if (node->bindingKind == GeneratedBindingKind::Local) {
          if (node->bindingIndex >= body->second.locals.size()) return false;
          const GeneratedFunctionLocal &local = body->second.locals[node->bindingIndex];
          if (local.name != node->spelling || local.type != node->type) return false;
        } else return false;
      }
    }
    for (size_t i = 0; i < declarations.size(); ++i) {
      if (declarations[i].id != i) return false;
      const Declaration &decl = declarations[i];
      if (decl.origin == DeclarationOrigin::Source && !decl.sourceNode) return false;
      if (decl.origin == DeclarationOrigin::Generated &&
          (decl.sourceNode || !decl.owner.empty() || decl.isGeneric ||
           (decl.kind != SymbolKind::Struct && decl.kind != SymbolKind::Function))) return false;
      if (decl.name.empty() || decl.qualifiedName.empty() || decl.module.empty()) return false;
      const auto ownerModule = std::find_if(modules.begin(), modules.end(),
          [&](const Module &candidate) { return candidate.name == decl.module; });
      if (ownerModule == modules.end() ||
          std::count(ownerModule->declarations.begin(), ownerModule->declarations.end(), decl.id) != 1)
        return false;
      const auto indexed = symbolsByQualifiedName.find(decl.qualifiedName);
      if (indexed == symbolsByQualifiedName.end() ||
          std::count(indexed->second.begin(), indexed->second.end(), decl.id) != 1) return false;
      if (decl.returnType.type > types.size() || decl.declaredType.type > types.size()) return false;
      for (const Parameter &param : decl.parameters)
        if (param.type.type == kInvalidType || param.type.type > types.size()) return false;
      for (const Field &field : decl.fields)
        if (field.type.type == kInvalidType || field.type.type > types.size()) return false;
      for (const EnumVariant &variant : decl.variants)
        for (const TypeUse &payload : variant.payload)
          if (payload.type == kInvalidType || payload.type > types.size()) return false;
      for (const GenericConstraint &bound : decl.genericBounds)
        if (!bound.isConstValuePredicate &&
            (bound.bound.type == kInvalidType || bound.bound.type > types.size())) return false;
      for (const TypeUse &implemented : decl.implementedTypes)
        if (implemented.type == kInvalidType || implemented.type > types.size()) return false;
      if (decl.parentType.type > types.size()) return false;
      auto validUse = [&](const TypeUse &use) {
        if (use.resolvedSymbol != kInvalidSymbol && use.resolvedSymbol >= declarations.size()) return false;
        for (const ResolvedName &name : use.names) {
          if (name.type == kInvalidType || name.type > types.size()) return false;
          if (name.symbol != kInvalidSymbol && name.symbol >= declarations.size()) return false;
        }
        return true;
      };
      if (!validUse(decl.declaredType) || !validUse(decl.returnType) ||
          !validUse(decl.parentType)) return false;
      for (const Parameter &param : decl.parameters) if (!validUse(param.type)) return false;
      for (const Field &field : decl.fields) if (!validUse(field.type)) return false;
      for (const EnumVariant &variant : decl.variants)
        for (const TypeUse &payload : variant.payload) if (!validUse(payload)) return false;
      for (const GenericConstraint &bound : decl.genericBounds)
        if (!bound.isConstValuePredicate && !validUse(bound.bound)) return false;
      for (const TypeUse &implemented : decl.implementedTypes) if (!validUse(implemented)) return false;
      for (SymbolId method : decl.methods) if (method >= declarations.size()) return false;
    }
    auto isGeneratedBodyScalar = [&](TypeId id) {
      if (id == kInvalidType || id > types.size()) return false;
      const TypeDescriptor &type = types.get(id);
      if (type.category != TypeCategory::Builtin) return false;
      return type.base == "byte" || type.base == "ubyte" || type.base == "short" ||
             type.base == "ushort" || type.base == "int" || type.base == "uint" ||
             type.base == "long" || type.base == "ulong" || type.base == "float" ||
             type.base == "double" || type.base == "bool" || type.base == "char" ||
             type.base == "unichar";
    };
    for (const auto &entry : generatedFunctionBodies) {
      const SymbolId functionId = entry.first;
      const GeneratedFunctionBody &body = entry.second;
      if (functionId >= declarations.size() || body.function != functionId) return false;
      const Declaration &function = declarations[functionId];
      if (function.origin != DeclarationOrigin::Generated || function.kind != SymbolKind::Function ||
          function.isGeneric || function.returnType.type == kInvalidType ||
          function.returnType.type > types.size()) return false;
      const bool returnsVoid = types.get(function.returnType.type).category == TypeCategory::Builtin &&
                               types.get(function.returnType.type).base == "void";
      if (body.returnsVoid != returnsVoid || (returnsVoid && body.returnValue) ||
          (!returnsVoid && (!body.returnValue || body.returnValue->type != function.returnType.type)))
        return false;
      for (const Parameter &parameter : function.parameters)
        if (!isGeneratedBodyScalar(parameter.type.type) || parameter.ref || parameter.immutableRef ||
            parameter.variadic || parameter.noescape || parameter.readonly || parameter.hasDefault)
          return false;
      std::set<std::string> localNames;
      for (const Parameter &parameter : function.parameters)
        if (!localNames.insert(parameter.name).second) return false;
      auto validateBodyExpression = [&](auto &&self, const TypedAstRef &expression,
                                        size_t availableLocals, unsigned depth) -> bool {
        if (!expression || depth > 64 || expression->id >= typedAst.nodes.size() ||
            typedAst.nodes[expression->id].get() != expression.get() ||
            expression->origin != TypedAstOrigin::Generated ||
            !isGeneratedBodyScalar(expression->type)) return false;
        switch (expression->kind) {
          case TypedAstKind::IntLiteral:
          case TypedAstKind::FloatLiteral:
          case TypedAstKind::CharLiteral:
          case TypedAstKind::BoolLiteral:
            if (!expression->children.empty()) return false;
            break;
          case TypedAstKind::Identifier:
            if (expression->bindingFunction != functionId) return false;
            if (expression->bindingKind == GeneratedBindingKind::Parameter) {
              if (expression->bindingIndex >= function.parameters.size()) return false;
            } else if (expression->bindingKind == GeneratedBindingKind::Local) {
              if (expression->bindingIndex >= availableLocals) return false;
            } else return false;
            if (!expression->children.empty()) return false;
            break;
          case TypedAstKind::Unary:
            if (expression->children.size() != 1) return false;
            break;
          case TypedAstKind::Binary:
            if (expression->children.size() != 2) return false;
            break;
          case TypedAstKind::Call: {
            if (expression->resolvedCallee >= declarations.size()) return false;
            const Declaration &callee = declarations[expression->resolvedCallee];
            if (callee.kind != SymbolKind::Function || callee.module != function.module ||
                callee.isGeneric || callee.parameters.size() != expression->children.size()) return false;
            break;
          }
          default: return false;
        }
        for (const TypedAstRef &child : expression->children)
          if (!self(self, child, availableLocals, depth + 1)) return false;
        return true;
      };
      for (size_t i = 0; i < body.locals.size(); ++i) {
        const GeneratedFunctionLocal &local = body.locals[i];
        if (local.name.empty() || !localNames.insert(local.name).second ||
            !isGeneratedBodyScalar(local.type) || !local.initializer ||
            local.initializer->type != local.type ||
            !validateBodyExpression(validateBodyExpression, local.initializer, i, 0)) return false;
      }
      size_t generatedStatementCount = 0;
      auto isGeneratedBool = [&](TypeId id) {
        if (id == kInvalidType || id > types.size()) return false;
        const TypeDescriptor &type = types.get(id);
        return type.category == TypeCategory::Builtin && type.base == "bool";
      };
      auto validateGeneratedStatements = [&](auto &&self,
                                             const std::vector<GeneratedFunctionStatement> &statements,
                                             unsigned depth) -> bool {
        if (depth > 64) return false;
        for (const GeneratedFunctionStatement &statement : statements) {
          if (++generatedStatementCount > 10000) return false;
          if (statement.kind == GeneratedFunctionStatementKind::AssignLocal) {
            if (statement.localIndex >= body.locals.size()) return false;
            const GeneratedFunctionLocal &target = body.locals[statement.localIndex];
            if (!target.isMutable || !statement.expression ||
                statement.expression->type != target.type ||
                !validateBodyExpression(validateBodyExpression, statement.expression,
                                        body.locals.size(), 0)) return false;
          } else if (statement.kind == GeneratedFunctionStatementKind::IfElse) {
            if (!statement.hasElse || !statement.condition ||
                !isGeneratedBool(statement.condition->type) ||
                !validateBodyExpression(validateBodyExpression, statement.condition,
                                        body.locals.size(), 0) ||
                !self(self, statement.thenStatements, depth + 1) ||
                !self(self, statement.elseStatements, depth + 1)) return false;
          } else return false;
        }
        return true;
      };
      if (!validateGeneratedStatements(validateGeneratedStatements, body.statements, 0))
        return false;
      if (body.returnValue &&
          !validateBodyExpression(validateBodyExpression, body.returnValue, body.locals.size(), 0))
        return false;
    }
    for (const Module &module : modules) {
      for (SymbolId id : module.declarations)
        if (id >= declarations.size() || declarations[id].module != module.name) return false;
      for (const ImportBinding &binding : module.importBindings)
        if (binding.module.empty() || binding.selection < 0 || binding.selection > 2) return false;
      for (const StaticAssertionInfo &assertion : module.staticAssertions)
        if (!assertion.expression || assertion.line < 0) return false;
    }
    for (const auto &entry : symbolsByQualifiedName)
      for (SymbolId id : entry.second)
        if (id >= declarations.size() || declarations[id].qualifiedName != entry.first) return false;
    for (size_t i = 0; i < scopes.size(); ++i) {
      const LexicalScope &scope = scopes[i];
      if (scope.id != i) return false;
      if (scope.parent != kInvalidScope && scope.parent >= i) return false;
      for (LocalSymbolId local : scope.locals)
        if (local >= locals.size() || locals[local].scope != scope.id) return false;
      for (const auto &entry : scope.names)
        if (entry.second >= locals.size() || locals[entry.second].name != entry.first) return false;
    }
    for (size_t i = 0; i < locals.size(); ++i) {
      const LocalSymbol &local = locals[i];
      if (local.id != i || local.scope >= scopes.size()) return false;
      if (local.owner != kInvalidSymbol && local.owner >= declarations.size()) return false;
      if (local.type > types.size()) return false;
    }
    if (expressionIds.size() != expressions.size()) return false;
    size_t typed = 0, unresolved = 0, dependent = 0;
    for (size_t i = 0; i < expressions.size(); ++i) {
      const Expression &expr = expressions[i];
      if (expr.call.selected != kInvalidSymbol && expr.call.selected >= declarations.size()) return false;
      for (SymbolId candidate : expr.call.candidates)
        if (candidate >= declarations.size()) return false;
      for (const auto &substitution : expr.call.substitutions)
        if (substitution.second == kInvalidType || substitution.second > types.size()) return false;
      for (TypeId argument : expr.call.explicitTypeArguments)
        if (argument == kInvalidType || argument > types.size()) return false;
      if (expr.id != i || !expr.source || expr.line < 0) return false;
      if (expr.owner != kInvalidSymbol && expr.owner >= declarations.size()) return false;
      if (expr.lexicalScope != kInvalidScope && expr.lexicalScope >= scopes.size()) return false;
      if (expr.localBinding != kInvalidLocal && expr.localBinding >= locals.size()) return false;
      if (expr.call.selected != kInvalidSymbol && expr.call.selected >= declarations.size()) return false;
      for (SymbolId candidate : expr.call.candidates)
        if (candidate >= declarations.size()) return false;
      if (expr.call.state == CallResolutionState::Resolved) {
        if (expr.call.selected == kInvalidSymbol || expr.call.conversionCost < 0 ||
            std::find(expr.call.candidates.begin(), expr.call.candidates.end(),
                      expr.call.selected) == expr.call.candidates.end()) return false;
      } else if (expr.call.selected != kInvalidSymbol) return false;
      if (expr.call.state == CallResolutionState::Ambiguous &&
          expr.call.candidates.size() < 2) return false;
      if (expr.type > types.size()) return false;
      if (expr.typeState == ExprTypeState::Known) {
        if (expr.type == kInvalidType) return false;
        ++typed;
      } else if (expr.typeState == ExprTypeState::Dependent) {
        if (expr.type != kInvalidType) return false;
        ++dependent;
      } else {
        if (expr.type != kInvalidType) return false;
        ++unresolved;
      }
      if (expr.parent != kInvalidExpr) {
        if (expr.parent >= i) return false;
        const auto &siblings = expressions[expr.parent].children;
        if (std::find(siblings.begin(), siblings.end(), expr.id) == siblings.end()) return false;
      }
      for (ExprId child : expr.children)
        if (child >= expressions.size() || expressions[child].parent != expr.id) return false;
    }
    if (expressionSummary.expressions != expressions.size() ||
        expressionSummary.typed != typed || expressionSummary.unresolved != unresolved ||
        expressionSummary.dependent != dependent) return false;
    for (const auto &entry : expressionIds)
      if (!entry.first || entry.second >= expressions.size() ||
          expressions[entry.second].source != entry.first) return false;
    SemanticDiagnosticSummary diagnosticCounts;
    for (const SemanticDiagnostic &diagnostic : diagnostics) {
      if (diagnostic.code.empty() || diagnostic.message.empty() || diagnostic.location.line < 0)
        return false;
      if (diagnostic.expression != kInvalidExpr && diagnostic.expression >= expressions.size())
        return false;
      switch (diagnostic.severity) {
        case SemanticDiagnosticSeverity::Note: ++diagnosticCounts.notes; break;
        case SemanticDiagnosticSeverity::Warning: ++diagnosticCounts.warnings; break;
        case SemanticDiagnosticSeverity::Error: ++diagnosticCounts.errors; break;
      }
    }
    if (diagnosticSummary.notes != diagnosticCounts.notes ||
        diagnosticSummary.warnings != diagnosticCounts.warnings ||
        diagnosticSummary.errors != diagnosticCounts.errors) return false;
    return true;
  }
};

// Compiler-internal, staged declaration construction. Generated declarations
// are registered in HIR only; source AST ownership and code generation remain
// unchanged until a later, explicitly validated integration milestone.
enum class GeneratedVisibility : uint8_t { Private, Protected, Public };

struct GeneratedFieldSpec {
  std::string name;
  TypeId type = kInvalidType;
  GeneratedVisibility visibility = GeneratedVisibility::Private;
  bool isStatic = false;
  bool isConst = false;
  SourceLocation location;
};

struct GeneratedParameterSpec {
  std::string name;
  TypeId type = kInvalidType;
  bool ref = false;
  bool immutableRef = false;
  bool variadic = false;
  bool noescape = false;
  bool readonly = false;
};

struct DeclarationBuildResult {
  SymbolId symbol = kInvalidSymbol;
  TypeId declaredType = kInvalidType; // populated for generated struct/class types
};

class TypedDeclarationBuilder {
 public:
  explicit TypedDeclarationBuilder(SemanticModel &model) : model_(model) {
    if (!model_.validate())
      throw std::invalid_argument("TypedDeclarationBuilder requires a valid semantic model");
  }

  DeclarationBuildResult addStruct(const std::string &moduleName,
                                   const std::string &name,
                                   const std::vector<GeneratedFieldSpec> &fields,
                                   GeneratedVisibility visibility = GeneratedVisibility::Public,
                                   SourceLocation location = {}) {
    requireValidModel();
    validateModuleAndName(moduleName, name);
    validateVisibility(visibility);
    if (!model_.find(moduleName + "." + name).empty())
      throw std::invalid_argument("generated struct name already exists: " + moduleName + "." + name);

    std::set<std::string> fieldNames;
    for (const GeneratedFieldSpec &field : fields) {
      validateIdentifier(field.name, "field");
      validateVisibility(field.visibility);
      if (!fieldNames.insert(field.name).second)
        throw std::invalid_argument("duplicate generated field name: " + field.name);
      validateValueType(moduleName, field.type, false, "field " + field.name);
    }

    // Check the symbol table bound before interning the new type.
    const SymbolId newSymbolId = nextSymbolId();
    // Intern the type only after all caller-controlled validation has passed.
    TypeSpec typeSpec;
    typeSpec.cat = "struct";
    typeSpec.base = name;
    const TypeId typeId = model_.types.intern(typeSpec);

    Declaration declaration;
    declaration.id = newSymbolId;
    declaration.origin = DeclarationOrigin::Generated;
    declaration.sourceNode = nullptr;
    declaration.kind = SymbolKind::Struct;
    declaration.module = moduleName;
    declaration.name = name;
    declaration.qualifiedName = moduleName + "." + name;
    declaration.location = std::move(location);
    declaration.declaredType = makeTypeUse(moduleName, typeId);
    declaration.declaredType.resolvedSymbol = declaration.id;
    declaration.declaredType.resolvedTypeKind = TypeResolutionKind::Struct;
    {
      ResolvedName selfType;
      selfType.type = typeId;
      selfType.spelling = name;
      selfType.canonicalName = declaration.qualifiedName;
      selfType.symbol = declaration.id;
      selfType.kind = NameResolutionKind::Resolved;
      selfType.typeKind = TypeResolutionKind::Struct;
      declaration.declaredType.names.push_back(std::move(selfType));
    }
    declaration.isPublic = visibility == GeneratedVisibility::Public;
    declaration.isProtected = visibility == GeneratedVisibility::Protected;
    declaration.isPrivate = visibility == GeneratedVisibility::Private;
    declaration.isGeneric = false;
    declaration.fields.reserve(fields.size());
    for (const GeneratedFieldSpec &sourceField : fields) {
      Field field;
      field.name = sourceField.name;
      field.type = makeTypeUse(moduleName, sourceField.type);
      field.location = sourceField.location.file.empty() && sourceField.location.line == 0
          ? declaration.location : sourceField.location;
      field.isPublic = sourceField.visibility == GeneratedVisibility::Public;
      field.isProtected = sourceField.visibility == GeneratedVisibility::Protected;
      field.isPrivate = sourceField.visibility == GeneratedVisibility::Private;
      field.isStatic = sourceField.isStatic;
      field.isConst = sourceField.isConst;
      declaration.fields.push_back(std::move(field));
    }

    const SymbolId id = declaration.id;
    registerDeclaration(std::move(declaration));
    if (!model_.validate()) {
      rollbackLastDeclaration(id);
      throw std::logic_error("TypedDeclarationBuilder generated an invalid struct declaration");
    }
    return {id, typeId};
  }

  DeclarationBuildResult addFunction(const std::string &moduleName,
                                     const std::string &name,
                                     TypeId returnType,
                                     const std::vector<GeneratedParameterSpec> &parameters,
                                     GeneratedVisibility visibility = GeneratedVisibility::Public,
                                     SourceLocation location = {}) {
    requireValidModel();
    validateModuleAndName(moduleName, name);
    validateVisibility(visibility);
    validateValueType(moduleName, returnType, true, "function return type");

    std::set<std::string> parameterNames;
    bool sawVariadic = false;
    for (size_t i = 0; i < parameters.size(); ++i) {
      const GeneratedParameterSpec &parameter = parameters[i];
      validateIdentifier(parameter.name, "parameter");
      if (!parameterNames.insert(parameter.name).second)
        throw std::invalid_argument("duplicate generated parameter name: " + parameter.name);
      validateValueType(moduleName, parameter.type, false, "parameter " + parameter.name);
      if (sawVariadic)
        throw std::invalid_argument("generated variadic parameter must be last");
      if (parameter.variadic) sawVariadic = true;
      if (parameter.immutableRef && !parameter.ref)
        throw std::invalid_argument("generated immutableRef parameter must also be ref");
      if (parameter.noescape && !parameter.ref)
        throw std::invalid_argument("generated noescape parameter must be ref");
    }

    // FAC overloads are distinguished by their parameter type/ref shape.
    for (SymbolId existingId : model_.find(moduleName + "." + name)) {
      const Declaration &existing = model_.symbol(existingId);
      if (existing.kind != SymbolKind::Function) continue;
      if (sameFunctionSignature(existing, parameters))
        throw std::invalid_argument("generated function signature already exists: " +
                                    existing.qualifiedName);
    }

    Declaration declaration;
    declaration.id = nextSymbolId();
    declaration.origin = DeclarationOrigin::Generated;
    declaration.sourceNode = nullptr;
    declaration.kind = SymbolKind::Function;
    declaration.module = moduleName;
    declaration.name = name;
    declaration.qualifiedName = moduleName + "." + name;
    declaration.location = std::move(location);
    declaration.returnType = makeTypeUse(moduleName, returnType);
    declaration.isPublic = visibility == GeneratedVisibility::Public;
    declaration.isProtected = visibility == GeneratedVisibility::Protected;
    declaration.isPrivate = visibility == GeneratedVisibility::Private;
    declaration.isGeneric = false;
    declaration.parameters.reserve(parameters.size());
    for (const GeneratedParameterSpec &sourceParameter : parameters) {
      Parameter parameter;
      parameter.name = sourceParameter.name;
      parameter.type = makeTypeUse(moduleName, sourceParameter.type);
      parameter.ref = sourceParameter.ref;
      parameter.immutableRef = sourceParameter.immutableRef;
      parameter.variadic = sourceParameter.variadic;
      parameter.noescape = sourceParameter.noescape;
      parameter.readonly = sourceParameter.readonly;
      declaration.parameters.push_back(std::move(parameter));
    }

    const SymbolId id = declaration.id;
    registerDeclaration(std::move(declaration));
    if (!model_.validate()) {
      rollbackLastDeclaration(id);
      throw std::logic_error("TypedDeclarationBuilder generated an invalid function declaration");
    }
    return {id, kInvalidType};
  }

 private:
  SemanticModel &model_;

  static bool isIdentifier(const std::string &name) {
    if (name.empty()) return false;
    const auto first = static_cast<unsigned char>(name.front());
    if (!(std::isalpha(first) || first == '_')) return false;
    for (unsigned char ch : name)
      if (!(std::isalnum(ch) || ch == '_')) return false;
    return true;
  }

  static void validateIdentifier(const std::string &name, const char *what) {
    if (!isIdentifier(name))
      throw std::invalid_argument(std::string("invalid generated ") + what + " identifier: " + name);
  }

  static void validateVisibility(GeneratedVisibility visibility) {
    switch (visibility) {
      case GeneratedVisibility::Private:
      case GeneratedVisibility::Protected:
      case GeneratedVisibility::Public: return;
    }
    throw std::invalid_argument("invalid generated declaration visibility");
  }

  void requireValidModel() const {
    if (!model_.validate())
      throw std::invalid_argument("TypedDeclarationBuilder requires the semantic model to remain valid");
  }

  void validateModuleAndName(const std::string &moduleName, const std::string &name) const {
    if (moduleName.empty()) throw std::invalid_argument("generated declaration requires a module");
    auto module = std::find_if(model_.modules.begin(), model_.modules.end(),
        [&](const Module &candidate) { return candidate.name == moduleName; });
    if (module == model_.modules.end())
      throw std::invalid_argument("generated declaration module does not exist: " + moduleName);
    validateIdentifier(name, "declaration");
  }

  TypeUse makeTypeUse(const std::string &moduleName, TypeId type) const {
    TypeUse use;
    use.type = type;
    const TypeDescriptor &descriptor = model_.types.get(type);
    if (descriptor.category == TypeCategory::Builtin) {
      use.resolvedTypeKind = TypeResolutionKind::Builtin;
      return use;
    }
    if (descriptor.category == TypeCategory::Named) {
      const auto candidates = model_.find(moduleName + "." + descriptor.base);
      for (SymbolId id : candidates) {
        const Declaration &target = model_.symbol(id);
        TypeResolutionKind kind = TypeResolutionKind::Unresolved;
        switch (target.kind) {
          case SymbolKind::Struct: kind = TypeResolutionKind::Struct; break;
          case SymbolKind::Class: kind = TypeResolutionKind::Class; break;
          case SymbolKind::Interface: kind = TypeResolutionKind::Interface; break;
          case SymbolKind::Enum: kind = TypeResolutionKind::Enum; break;
          case SymbolKind::Function:
          case SymbolKind::Global: break;
        }
        if (kind == TypeResolutionKind::Unresolved) continue;
        use.resolvedSymbol = id;
        use.resolvedTypeKind = kind;
        ResolvedName resolved;
        resolved.type = type;
        resolved.spelling = descriptor.base;
        resolved.canonicalName = target.qualifiedName;
        resolved.symbol = id;
        resolved.kind = NameResolutionKind::Resolved;
        resolved.typeKind = kind;
        use.names.push_back(std::move(resolved));
        return use;
      }
    }
    return use;
  }

  void validateValueType(const std::string &moduleName, TypeId type,
                         bool allowVoid, const std::string &what) const {
    if (type == kInvalidType || type > model_.types.size())
      throw std::invalid_argument("generated " + what + " has an invalid TypeId");
    const TypeDescriptor &descriptor = model_.types.get(type);
    if (descriptor.category == TypeCategory::Unknown || descriptor.category == TypeCategory::Other)
      throw std::invalid_argument("generated " + what + " has an unresolved type");
    if (!allowVoid && descriptor.category == TypeCategory::Builtin && descriptor.base == "void")
      throw std::invalid_argument("generated " + what + " cannot have void type");
    if (descriptor.category == TypeCategory::Named) {
      // This initial builder accepts named types already declared in the same
      // module. Cross-module visibility/import checks belong to a later commit
      // API that carries an explicit resolved TypeUse rather than a bare TypeId.
      const auto candidates = model_.find(moduleName + "." + descriptor.base);
      bool found = false;
      for (SymbolId id : candidates) {
        const SymbolKind kind = model_.symbol(id).kind;
        if (kind == SymbolKind::Struct || kind == SymbolKind::Class ||
            kind == SymbolKind::Interface || kind == SymbolKind::Enum) {
          found = true;
          break;
        }
      }
      if (!found)
        throw std::invalid_argument("generated " + what + " references a named type not declared in module " +
                                    moduleName + ": " + descriptor.base);
    }
  }

  static bool sameFunctionSignature(const Declaration &existing,
                                    const std::vector<GeneratedParameterSpec> &parameters) {
    if (existing.parameters.size() != parameters.size()) return false;
    for (size_t i = 0; i < parameters.size(); ++i) {
      const Parameter &a = existing.parameters[i];
      const GeneratedParameterSpec &b = parameters[i];
      if (a.type.type != b.type || a.ref != b.ref || a.immutableRef != b.immutableRef ||
          a.variadic != b.variadic) return false;
    }
    return true;
  }

  SymbolId nextSymbolId() const {
    if (model_.declarations.size() >= static_cast<size_t>(kInvalidSymbol))
      throw std::overflow_error("FAC HIR symbol table exhausted SymbolId space");
    return static_cast<SymbolId>(model_.declarations.size());
  }

  void registerDeclaration(Declaration declaration) {
    const SymbolId id = declaration.id;
    const std::string qualifiedName = declaration.qualifiedName;
    const std::string moduleName = declaration.module;
    auto module = std::find_if(model_.modules.begin(), model_.modules.end(),
        [&](const Module &candidate) { return candidate.name == moduleName; });
    if (module == model_.modules.end())
      throw std::logic_error("generated declaration module disappeared during registration");
    model_.declarations.push_back(std::move(declaration));
    bool moduleRegistered = false;
    try {
      module->declarations.push_back(id);
      moduleRegistered = true;
      model_.symbolsByQualifiedName[qualifiedName].push_back(id);
    } catch (...) {
      auto found = model_.symbolsByQualifiedName.find(qualifiedName);
      if (found != model_.symbolsByQualifiedName.end()) {
        auto &ids = found->second;
        ids.erase(std::remove(ids.begin(), ids.end(), id), ids.end());
        if (ids.empty()) model_.symbolsByQualifiedName.erase(found);
      }
      if (moduleRegistered) {
        auto &ids = module->declarations;
        ids.erase(std::remove(ids.begin(), ids.end(), id), ids.end());
      }
      model_.declarations.pop_back();
      throw;
    }
  }

  void rollbackLastDeclaration(SymbolId id) {
    if (model_.declarations.empty() || model_.declarations.back().id != id) return;
    const Declaration &declaration = model_.declarations.back();
    auto symbol = model_.symbolsByQualifiedName.find(declaration.qualifiedName);
    if (symbol != model_.symbolsByQualifiedName.end()) {
      auto &ids = symbol->second;
      ids.erase(std::remove(ids.begin(), ids.end(), id), ids.end());
      if (ids.empty()) model_.symbolsByQualifiedName.erase(symbol);
    }
    for (Module &module : model_.modules) {
      if (module.name != declaration.module) continue;
      auto &ids = module.declarations;
      ids.erase(std::remove(ids.begin(), ids.end(), id), ids.end());
      break;
    }
    model_.declarations.pop_back();
  }
};

class NameResolver {
 public:
  void resolve(SemanticModel &model) {
    modules_.clear();
    simpleTypes_.clear();
    typeAliases_.clear();
    moduleAliases_.clear();
    for (const Module &module : model.modules) {
      modules_[module.name] = &module;
      for (const auto &alias : module.aliases) typeAliases_[alias.first] = alias.second;
      for (const ImportBinding &binding : module.importBindings) {
        if (!binding.alias.empty()) moduleAliases_[module.name][binding.alias] = binding.module;
      }
    }
    for (const Declaration &decl : model.declarations) {
      if (isTypeDeclaration(decl.kind)) simpleTypes_[decl.name].push_back(decl.id);
    }

    model.nameResolution = NameResolutionSummary{};
    for (Declaration &decl : model.declarations) {
      std::set<std::string> genericParameters(decl.typeParameters.begin(),
                                               decl.typeParameters.end());
      if (!decl.owner.empty()) {
        const std::string ownerKey = decl.module + "." + decl.owner;
        auto owner = model.find(ownerKey);
        for (SymbolId id : owner) {
          const Declaration &ownerDecl = model.symbol(id);
          genericParameters.insert(ownerDecl.typeParameters.begin(),
                                   ownerDecl.typeParameters.end());
        }
      }
      resolveUse(model, decl.module, genericParameters, decl.declaredType);
      resolveUse(model, decl.module, genericParameters, decl.returnType);
      for (Parameter &param : decl.parameters)
        resolveUse(model, decl.module, genericParameters, param.type);
      for (Field &field : decl.fields)
        resolveUse(model, decl.module, genericParameters, field.type);
      for (EnumVariant &variant : decl.variants)
        for (TypeUse &payload : variant.payload)
          resolveUse(model, decl.module, genericParameters, payload);
      for (GenericConstraint &bound : decl.genericBounds)
        if (!bound.isConstValuePredicate)
          resolveUse(model, decl.module, genericParameters, bound.bound);
      resolveUse(model, decl.module, genericParameters, decl.parentType);
      for (TypeUse &implemented : decl.implementedTypes)
        resolveUse(model, decl.module, genericParameters, implemented);
    }
  }

 private:
  std::map<std::string, const Module *> modules_;
  std::map<std::string, std::vector<SymbolId>> simpleTypes_;
  std::map<std::string, std::string> typeAliases_;
  std::map<std::string, std::map<std::string, std::string>> moduleAliases_;

  static bool isTypeDeclaration(SymbolKind kind) {
    return kind == SymbolKind::Struct || kind == SymbolKind::Class ||
           kind == SymbolKind::Interface || kind == SymbolKind::Enum;
  }

  static bool isBuiltinName(const std::string &name) {
    static const std::set<std::string> names = {
      "void", "bool", "boolean", "byte", "ubyte", "short", "ushort",
      "int", "uint", "long", "ulong", "float", "double", "char",
      "unichar", "string", "auto", "ptr", "weak", "numeric", "integer",
      "integral", "floating", "number", "signed", "unsigned",
      "file", "thread", "mutex", "graphic", "socket", "json", "jnode",
      "three", "gpu", "simd", "audio", "font", "keyboard", "mouse",
      "tensor", "data", "ml", "optim", "dataframe", "autograd",
      "vec2", "vec3", "vec4", "mat4", "Error", "Type", "Kind", "DS", "null"
    };
    return names.count(name) != 0;
  }

  static std::string leafName(const std::string &name) {
    const size_t dot = name.rfind('.');
    return dot == std::string::npos ? name : name.substr(dot + 1);
  }

  template <typename Names>
  static bool importNameMatches(const Names &names, const std::string &suffix) {
    if (std::find(names.begin(), names.end(), suffix) != names.end()) return true;
    const std::string leaf = leafName(suffix);
    if (std::find(names.begin(), names.end(), leaf) != names.end()) return true;
    for (const std::string &name : names) {
      if (suffix.size() > name.size() && suffix.compare(0, name.size(), name) == 0 &&
          suffix[name.size()] == '.') return true;
    }
    return false;
  }

  std::string expandTypeAlias(const std::string &source,
                              NameResolutionKind &kind) const {
    std::string current = source;
    std::set<std::string> seen;
    for (size_t depth = 0; depth < 64; ++depth) {
      auto it = typeAliases_.find(current);
      if (it == typeAliases_.end()) return current;
      if (!seen.insert(current).second) {
        kind = NameResolutionKind::AliasCycle;
        return current;
      }
      current = it->second;
    }
    kind = NameResolutionKind::AliasCycle;
    return current;
  }

  std::string canonicalizeModuleAlias(const std::string &sourceModule,
                                      const std::string &path) const {
    const size_t dot = path.find('.');
    const std::string root = path.substr(0, dot);
    auto owner = moduleAliases_.find(sourceModule);
    if (owner == moduleAliases_.end()) return path;
    auto alias = owner->second.find(root);
    if (alias == owner->second.end()) return path;
    return alias->second + (dot == std::string::npos ? std::string() : path.substr(dot));
  }

  bool isImported(const Module &module, const std::string &provider) const {
    if (module.name == provider) return true;
    if (std::find(module.imports.begin(), module.imports.end(), provider) !=
        module.imports.end()) return true;
    for (const ImportBinding &binding : module.importBindings)
      if (binding.module == provider && binding.global) return true;
    return false;
  }

  bool selectionAllows(const Module &module, const std::string &provider,
                       const std::string &name) const {
    // Match Codegen's current import-map semantics: the last `just` and the
    // last `without` declaration for a provider each replace their own map.
    const ImportBinding *just = nullptr;
    const ImportBinding *without = nullptr;
    for (const ImportBinding &binding : module.importBindings) {
      if (binding.module != provider) continue;
      if (binding.selection == 1) just = &binding;
      else if (binding.selection == 2) without = &binding;
    }
    if (just && !importNameMatches(just->names, name)) return false;
    if (without && importNameMatches(without->names, name)) return false;
    return true;
  }

  std::vector<SymbolId> candidatesFor(const SemanticModel &model,
                                      const std::string &sourceModule,
                                      const std::string &path,
                                      bool qualified) const {
    std::vector<SymbolId> result;
    if (!qualified) {
      auto local = model.find(sourceModule + "." + path);
      for (SymbolId id : local)
        if (isTypeDeclaration(model.symbol(id).kind)) result.push_back(id);
      if (!result.empty()) return result;
      auto all = simpleTypes_.find(path);
      if (all != simpleTypes_.end()) result = all->second;
      return result;
    }

    // Module names may contain dots; match the longest known module prefix.
    size_t longest = 0;
    for (const auto &entry : modules_) {
      const std::string prefix = entry.first + ".";
      if (path.compare(0, prefix.size(), prefix) == 0 && entry.first.size() > longest) {
        longest = entry.first.size();
        const std::string typeName = path.substr(prefix.size());
        result.clear();
        auto exact = model.find(entry.first + "." + typeName);
        for (SymbolId id : exact)
          if (isTypeDeclaration(model.symbol(id).kind)) result.push_back(id);
      }
    }
    return result;
  }

  ResolvedName resolveOne(const SemanticModel &model, const std::string &sourceModule,
                          const std::set<std::string> &genericParameters,
                          TypeId type, const std::string &rawName) const {
    ResolvedName result;
    result.type = type;
    result.spelling = rawName;
    if (rawName.empty()) return result;
    if (genericParameters.count(rawName)) {
      result.kind = NameResolutionKind::GenericParameter;
      result.canonicalName = rawName;
      return result;
    }

    NameResolutionKind aliasState = NameResolutionKind::NotApplicable;
    std::string path = expandTypeAlias(rawName, aliasState);
    if (aliasState == NameResolutionKind::AliasCycle) {
      result.kind = aliasState;
      result.canonicalName = path;
      return result;
    }
    if (isBuiltinName(path)) {
      result.kind = NameResolutionKind::Builtin;
      result.canonicalName = path;
      return result;
    }

    path = canonicalizeModuleAlias(sourceModule, path);
    const bool qualified = path.find('.') != std::string::npos;
    std::vector<SymbolId> candidates = candidatesFor(model, sourceModule, path, qualified);
    if (candidates.empty()) {
      result.kind = NameResolutionKind::NotFound;
      result.canonicalName = path;
      return result;
    }
    if (candidates.size() > 1) {
      result.kind = NameResolutionKind::Ambiguous;
      result.canonicalName = path;
      return result;
    }

    const Declaration &target = model.symbol(candidates.front());
    result.canonicalName = target.qualifiedName;
    result.symbol = target.id;
    if (target.module != sourceModule) {
      auto owner = modules_.find(sourceModule);
      if (owner == modules_.end() || !isImported(*owner->second, target.module)) {
        result.kind = NameResolutionKind::NotImported;
        return result;
      }
      if (!target.isPublic) {
        result.kind = NameResolutionKind::Private;
        return result;
      }
      if (!selectionAllows(*owner->second, target.module, target.name)) {
        result.kind = NameResolutionKind::Filtered;
        return result;
      }
      // A qualified path must name the provider module, not an unrelated
      // module that happens to expose a declaration with the same leaf name.
      if (qualified) {
        bool providerMatches = false;
        for (const auto &entry : modules_) {
          const std::string prefix = entry.first + ".";
          if (path.compare(0, prefix.size(), prefix) == 0 && entry.first == target.module)
            providerMatches = true;
        }
        if (!providerMatches) {
          result.kind = NameResolutionKind::NotFound;
          result.symbol = kInvalidSymbol;
          return result;
        }
      }
    }
    result.kind = NameResolutionKind::Resolved;
    return result;
  }

  void resolveUse(SemanticModel &model, const std::string &sourceModule,
                  const std::set<std::string> &genericParameters, TypeUse &use) const {
    use.resolvedSymbol = kInvalidSymbol;
    use.resolution = NameResolutionKind::NotApplicable;
    use.resolvedTypeKind = TypeResolutionKind::NotApplicable;
    use.names.clear();
    if (use.type == kInvalidType) return;

    std::function<void(TypeId, bool)> visit = [&](TypeId type, bool root) {
      const TypeDescriptor &descriptor = model.types.get(type);
      if (!descriptor.base.empty()) {
        ResolvedName name = resolveOne(model, sourceModule, genericParameters,
                                       type, descriptor.base);
        if (root) {
          use.resolvedSymbol = name.symbol;
          use.resolution = name.kind;
        }
        use.names.push_back(name);
        switch (name.kind) {
          case NameResolutionKind::Resolved: ++model.nameResolution.resolved; break;
          case NameResolutionKind::Builtin: ++model.nameResolution.builtins; break;
          case NameResolutionKind::GenericParameter: ++model.nameResolution.genericParameters; break;
          case NameResolutionKind::NotFound: ++model.nameResolution.notFound; break;
          case NameResolutionKind::Ambiguous: ++model.nameResolution.ambiguous; break;
          case NameResolutionKind::NotImported:
          case NameResolutionKind::Private:
          case NameResolutionKind::Filtered: ++model.nameResolution.accessDenied; break;
          case NameResolutionKind::AliasCycle: ++model.nameResolution.aliasCycles; break;
          case NameResolutionKind::NotApplicable: break;
        }
        ++model.nameResolution.references;
      }
      if (!descriptor.base2.empty()) {
        ResolvedName name = resolveOne(model, sourceModule, genericParameters,
                                       type, descriptor.base2);
        use.names.push_back(name);
        ++model.nameResolution.references;
        switch (name.kind) {
          case NameResolutionKind::Resolved: ++model.nameResolution.resolved; break;
          case NameResolutionKind::Builtin: ++model.nameResolution.builtins; break;
          case NameResolutionKind::GenericParameter: ++model.nameResolution.genericParameters; break;
          case NameResolutionKind::NotFound: ++model.nameResolution.notFound; break;
          case NameResolutionKind::Ambiguous: ++model.nameResolution.ambiguous; break;
          case NameResolutionKind::NotImported:
          case NameResolutionKind::Private:
          case NameResolutionKind::Filtered: ++model.nameResolution.accessDenied; break;
          case NameResolutionKind::AliasCycle: ++model.nameResolution.aliasCycles; break;
          case NameResolutionKind::NotApplicable: break;
        }
      }
      for (TypeId argument : descriptor.genericArguments) visit(argument, false);
      for (TypeId parameter : descriptor.parameters) visit(parameter, false);
      if (descriptor.returnType != kInvalidType) visit(descriptor.returnType, false);
    };
    visit(use.type, true);
  }
};

class TypeResolver {
 public:
  void resolve(SemanticModel &model) const {
    NameResolver{}.resolve(model);
    model.typeResolution = TypeResolutionSummary{};
    for (Declaration &decl : model.declarations) {
      resolveUse(model, decl.declaredType);
      resolveUse(model, decl.returnType);
      for (Parameter &param : decl.parameters) resolveUse(model, param.type);
      for (Field &field : decl.fields) resolveUse(model, field.type);
      for (EnumVariant &variant : decl.variants)
        for (TypeUse &payload : variant.payload) resolveUse(model, payload);
      for (GenericConstraint &bound : decl.genericBounds)
        if (!bound.isConstValuePredicate) resolveUse(model, bound.bound);
      resolveUse(model, decl.parentType);
      for (TypeUse &implemented : decl.implementedTypes) resolveUse(model, implemented);
    }
  }

 private:
  static TypeResolutionKind kindFor(const SemanticModel &model,
                                    const ResolvedName &name) {
    switch (name.kind) {
      case NameResolutionKind::Builtin: return TypeResolutionKind::Builtin;
      case NameResolutionKind::GenericParameter: return TypeResolutionKind::GenericParameter;
      case NameResolutionKind::Resolved: {
        if (name.symbol == kInvalidSymbol || name.symbol >= model.declarations.size())
          return TypeResolutionKind::Unresolved;
        switch (model.symbol(name.symbol).kind) {
          case SymbolKind::Struct: return TypeResolutionKind::Struct;
          case SymbolKind::Class: return TypeResolutionKind::Class;
          case SymbolKind::Interface: return TypeResolutionKind::Interface;
          case SymbolKind::Enum: return TypeResolutionKind::Enum;
          case SymbolKind::Function:
          case SymbolKind::Global: return TypeResolutionKind::Unresolved;
        }
        break;
      }
      case NameResolutionKind::NotFound:
      case NameResolutionKind::Ambiguous:
      case NameResolutionKind::NotImported:
      case NameResolutionKind::Private:
      case NameResolutionKind::Filtered:
      case NameResolutionKind::AliasCycle:
        return TypeResolutionKind::Unresolved;
      case NameResolutionKind::NotApplicable:
        return TypeResolutionKind::NotApplicable;
    }
    return TypeResolutionKind::Unresolved;
  }

  static void resolveUse(SemanticModel &model, TypeUse &use) {
    use.resolvedTypeKind = TypeResolutionKind::NotApplicable;
    for (ResolvedName &name : use.names) {
      name.typeKind = kindFor(model, name);
      ++model.typeResolution.references;
      switch (name.typeKind) {
        case TypeResolutionKind::Builtin: ++model.typeResolution.builtins; break;
        case TypeResolutionKind::GenericParameter: ++model.typeResolution.genericParameters; break;
        case TypeResolutionKind::Struct: ++model.typeResolution.structs; break;
        case TypeResolutionKind::Class: ++model.typeResolution.classes; break;
        case TypeResolutionKind::Interface: ++model.typeResolution.interfaces; break;
        case TypeResolutionKind::Enum: ++model.typeResolution.enums; break;
        case TypeResolutionKind::Unresolved: ++model.typeResolution.unresolved; break;
        case TypeResolutionKind::NotApplicable: break;
      }
    }
    if (!use.names.empty()) use.resolvedTypeKind = use.names.front().typeKind;
  }
};

// The expression HIR deliberately records every expression occurrence, but
// only assigns a TypeId when its type is provable from syntax or a fixed
// language/builtin rule. User calls, member/index access, and flow-dependent
// expressions remain unresolved until the dedicated local-scope and overload
// passes are migrated out of Codegen.
class ExpressionHirBuilder {
 public:
  void build(SemanticModel &model) const {
    model.expressions.clear();
    model.expressionIds.clear();
    model.expressionSummary = ExpressionHirSummary{};

    for (const Declaration &decl : model.declarations) {
      const Node *node = decl.sourceNode;
      if (!node) continue;
      if (decl.kind == SymbolKind::Function) {
        for (const Param &param : node->params)
          if (param.def) walk(model, param.def.get(), kInvalidExpr, decl.id, decl.module);
        for (const NP &child : node->c)
          if (child) walk(model, child.get(), kInvalidExpr, decl.id, decl.module);
      } else if (decl.kind == SymbolKind::Global ||
                 decl.kind == SymbolKind::Struct || decl.kind == SymbolKind::Class ||
                 decl.kind == SymbolKind::Interface) {
        for (const NP &child : node->c)
          if (child) walk(model, child.get(), kInvalidExpr, decl.id, decl.module);
      }
    }

    // Static assertions are module roots rather than declaration bodies.
    for (const Module &module : model.modules)
      for (const StaticAssertionInfo &assertion : module.staticAssertions)
        if (assertion.expression)
          walk(model, assertion.expression, kInvalidExpr, kInvalidSymbol, module.name);

    ExpressionHirSummary &summary = model.expressionSummary;
    summary.expressions = model.expressions.size();
    for (const Expression &expr : model.expressions) {
      switch (expr.typeState) {
        case ExprTypeState::Known: ++summary.typed; break;
        case ExprTypeState::Unresolved: ++summary.unresolved; break;
        case ExprTypeState::Dependent: ++summary.dependent; break;
      }
      if (isLiteral(expr.source->k)) ++summary.literals;
      if (expr.source->k == NK::Unary || expr.source->k == NK::Binary ||
          expr.source->k == NK::Assign || expr.source->k == NK::PostInc)
        ++summary.operators;
      if (expr.source->k == NK::Call) ++summary.calls;
    }
  }

  // Re-evaluate expressions after local bindings and overload selections have
  // supplied additional child types. Expr IDs are preorder, so reverse order
  // guarantees child types are available before their parents are revisited.
  void refine(SemanticModel &model) const {
    for (size_t index = model.expressions.size(); index > 0; --index) {
      Expression &expression = model.expressions[index - 1];
      if (expression.localBinding != kInvalidLocal &&
          expression.localBinding < model.locals.size()) {
        const TypeId localType = model.locals[expression.localBinding].type;
        if (localType != kInvalidType) {
          expression.type = localType;
          expression.typeState = ExprTypeState::Known;
          expression.typeOrigin = ExprTypeOrigin::LocalBinding;
          continue;
        }
      }
      ExprTypeOrigin origin = ExprTypeOrigin::None;
      const TypeId inferred = infer(model, expression.source, expression.children, origin);
      if (inferred != kInvalidType) {
        expression.type = inferred;
        expression.typeState = ExprTypeState::Known;
        expression.typeOrigin = origin;
      }
    }
    refreshSummary(model);
  }

  static void refreshSummary(SemanticModel &model) {
    ExpressionHirSummary summary;
    summary.expressions = model.expressions.size();
    for (const Expression &expression : model.expressions) {
      switch (expression.typeState) {
        case ExprTypeState::Known: ++summary.typed; break;
        case ExprTypeState::Unresolved: ++summary.unresolved; break;
        case ExprTypeState::Dependent: ++summary.dependent; break;
      }
      if (isLiteral(expression.source->k)) ++summary.literals;
      if (expression.source->k == NK::Unary || expression.source->k == NK::Binary ||
          expression.source->k == NK::Assign || expression.source->k == NK::PostInc)
        ++summary.operators;
      if (expression.source->k == NK::Call) ++summary.calls;
    }
    model.expressionSummary = summary;
  }

 private:
  static bool isLiteral(NK kind) {
    return kind == NK::IntLit || kind == NK::FloatLit || kind == NK::CharLit ||
           kind == NK::StrLit || kind == NK::BoolLit || kind == NK::NullLit;
  }

  static bool isExpression(NK kind) {
    switch (kind) {
      case NK::IntLit: case NK::FloatLit: case NK::CharLit: case NK::StrLit:
      case NK::BoolLit: case NK::NullLit: case NK::Ident: case NK::Unary:
      case NK::PostInc: case NK::Binary: case NK::Assign: case NK::Call:
      case NK::Member: case NK::Index: case NK::Slice: case NK::Deref:
      case NK::InitList: case NK::IfV: case NK::LoopIdx: case NK::Propagate:
      case NK::New: case NK::Lambda: case NK::MatchExpr: case NK::TupleLit:
        return true;
      default: return false;
    }
  }

  static TypeSpec scalar(const std::string &base, const std::string &kind = "") {
    TypeSpec spec;
    spec.base = base;
    spec.kind = kind;
    return spec;
  }

  static TypeId builtin(SemanticModel &model, const std::string &base,
                        const std::string &kind = "") {
    return model.types.intern(scalar(base, kind));
  }

  static TypeId builtinTypeEnum(SemanticModel &model) {
    TypeSpec spec;
    spec.cat = "enum";
    spec.base = "Type";
    return model.types.intern(spec);
  }

  static bool hasExplicitTypeQueryArguments(const Node *call) {
    if (!call || call->k != NK::Call || call->c.empty() || !call->c[0]) return false;
    const Node *callee = call->c[0].get();
    return !callee->ts.genericArgs.empty() || !callee->explicitTypeArgs.empty();
  }

  static const TypeDescriptor *knownType(const SemanticModel &model, ExprId id) {
    if (id >= model.expressions.size()) return nullptr;
    const Expression &expr = model.expressions[id];
    if (expr.typeState != ExprTypeState::Known || expr.type == kInvalidType) return nullptr;
    return &model.types.get(expr.type);
  }

  static bool integerType(const TypeDescriptor &type) {
    static const std::set<std::string> names = {
      "byte", "ubyte", "short", "ushort", "int", "uint", "long", "ulong",
      "char", "unichar", "bool", "boolean"
    };
    return names.count(type.base) != 0;
  }

  static bool floatingType(const TypeDescriptor &type) {
    return type.base == "float" || type.base == "double";
  }

  static int bitWidth(const TypeDescriptor &type) {
    if (type.base == "byte" || type.base == "ubyte" || type.base == "char" ||
        type.base == "bool" || type.base == "boolean") return 8;
    if (type.base == "short" || type.base == "ushort") return 16;
    if (type.base == "int" || type.base == "uint" || type.base == "unichar") return 32;
    if (type.base == "long" || type.base == "ulong") return 64;
    return 0;
  }

  static bool isSigned(const TypeDescriptor &type) {
    return type.base == "byte" || type.base == "short" || type.base == "int" ||
           type.base == "long" || type.base == "char";
  }

  static std::string integerName(int bits, bool sign) {
    if (bits <= 8) return sign ? "byte" : "ubyte";
    if (bits <= 16) return sign ? "short" : "ushort";
    if (bits <= 32) return sign ? "int" : "uint";
    return sign ? "long" : "ulong";
  }

  static TypeId promoteInteger(SemanticModel &model, const TypeDescriptor &type) {
    if (type.base == "unichar") return builtin(model, "uint");
    const int bits = bitWidth(type);
    if (bits > 0 && bits < 32) return builtin(model, "int");
    if (bits >= 32) return builtin(model, integerName(bits, isSigned(type)));
    return kInvalidType;
  }

  static TypeId commonNumeric(SemanticModel &model, TypeId lhs, TypeId rhs) {
    const TypeDescriptor &a = model.types.get(lhs);
    const TypeDescriptor &b = model.types.get(rhs);
    if (!((integerType(a) || floatingType(a)) &&
          (integerType(b) || floatingType(b)))) return kInvalidType;
    if (a.base == "double" || b.base == "double") return builtin(model, "double");
    if (a.base == "float" || b.base == "float") return builtin(model, "float");
    TypeId pa = promoteInteger(model, a), pb = promoteInteger(model, b);
    if (pa == kInvalidType || pb == kInvalidType) return kInvalidType;
    const TypeDescriptor &promotedA = model.types.get(pa);
    const TypeDescriptor &promotedB = model.types.get(pb);
    const int bitsA = bitWidth(promotedA), bitsB = bitWidth(promotedB);
    const int bits = std::max(bitsA, bitsB);
    const bool sign = bitsA == bitsB ? (isSigned(promotedA) && isSigned(promotedB))
                    : (bitsA > bitsB ? isSigned(promotedA) : isSigned(promotedB));
    return builtin(model, integerName(bits, sign));
  }

  static std::string callPath(const Node *node) {
    if (!node) return {};
    if (node->k == NK::Ident) return node->s;
    if (node->k == NK::Member && !node->c.empty()) {
      const std::string prefix = callPath(node->c[0].get());
      return prefix.empty() ? std::string() : prefix + "." + node->s;
    }
    return {};
  }

  static TypeId infer(SemanticModel &model, const Node *node,
                      const std::vector<ExprId> &children,
                      ExprTypeOrigin &origin) {
    if (!node) return kInvalidType;
    auto child = [&](size_t index) -> const TypeDescriptor * {
      return index < children.size() ? knownType(model, children[index]) : nullptr;
    };
    auto childId = [&](size_t index) -> TypeId {
      return index < children.size() ? model.expressions[children[index]].type : kInvalidType;
    };

    switch (node->k) {
      case NK::IntLit:
        origin = ExprTypeOrigin::Literal;
        return builtin(model, node->iv >= INT32_MIN && node->iv <= INT32_MAX ? "int" : "long");
      case NK::FloatLit:
        origin = ExprTypeOrigin::Literal;
        return builtin(model, "double");
      case NK::CharLit:
        origin = ExprTypeOrigin::Literal;
        return builtin(model, node->iv < 128 ? "char" : "unichar");
      case NK::StrLit:
        origin = ExprTypeOrigin::Literal;
        return builtin(model, "string", "dyn");
      case NK::BoolLit:
        origin = ExprTypeOrigin::Literal;
        return builtin(model, "bool");
      case NK::NullLit:
        origin = ExprTypeOrigin::Literal;
        return builtin(model, "null");
      case NK::Unary: {
        const TypeDescriptor *operand = child(0);
        if (!operand) return kInvalidType;
        if (node->s == "!") { origin = ExprTypeOrigin::OperatorRule; return builtin(model, "bool"); }
        if (node->s == "+") {
          if (integerType(*operand) || floatingType(*operand)) {
            origin = ExprTypeOrigin::OperatorRule;
            return childId(0);
          }
        }
        if (node->s == "++" || node->s == "--") {
          if (integerType(*operand) || floatingType(*operand)) {
            origin = ExprTypeOrigin::OperatorRule;
            return childId(0);
          }
        }
        if (node->s == "-") {
          if (floatingType(*operand)) { origin = ExprTypeOrigin::OperatorRule; return childId(0); }
          if (integerType(*operand)) { origin = ExprTypeOrigin::OperatorRule; return promoteInteger(model, *operand); }
        }
        if (node->s == "~" && integerType(*operand)) {
          origin = ExprTypeOrigin::OperatorRule;
          return promoteInteger(model, *operand);
        }
        return kInvalidType;
      }
      case NK::PostInc: {
        if (!child(0)) return kInvalidType;
        origin = ExprTypeOrigin::OperatorRule;
        return childId(0);
      }
      case NK::Binary: {
        const TypeDescriptor *lhs = child(0), *rhs = child(1);
        if (!lhs || !rhs) return kInvalidType;
        const std::string &op = node->s;
        if (op == "&&" || op == "||" || op == "==" || op == "!=" ||
            op == "<" || op == "<=" || op == ">" || op == ">=" ||
            op == "instanceof") {
          origin = ExprTypeOrigin::OperatorRule;
          return builtin(model, "bool");
        }
        if (op == "+" && lhs->base == "string" && rhs->base == "string") {
          origin = ExprTypeOrigin::OperatorRule;
          return builtin(model, "string", "dyn");
        }
        if (op == "**") {
          if (!((integerType(*lhs) || floatingType(*lhs)) &&
                (integerType(*rhs) || floatingType(*rhs)))) return kInvalidType;
          origin = ExprTypeOrigin::OperatorRule;
          return (floatingType(*lhs) || floatingType(*rhs))
                   ? builtin(model, "double")
                   : commonNumeric(model, childId(0), childId(1));
        }
        if (op == "<<" || op == ">>") {
          if (!integerType(*lhs) || !integerType(*rhs)) return kInvalidType;
          origin = ExprTypeOrigin::OperatorRule;
          return commonNumeric(model, childId(0), childId(1));
        }
        if (op == "%" || op == "&" || op == "|" || op == "^") {
          if (!integerType(*lhs) || !integerType(*rhs)) return kInvalidType;
        } else if (op != "+" && op != "-" && op != "*" && op != "/") {
          return kInvalidType;
        }
        const TypeId result = commonNumeric(model, childId(0), childId(1));
        if (result != kInvalidType) origin = ExprTypeOrigin::OperatorRule;
        return result;
      }
      case NK::Call: {
        if (node->c.empty()) return kInvalidType;
        const std::string path = callPath(node->c[0].get());
        if (node->c.size() == 1 && hasExplicitTypeQueryArguments(node)) {
          if (path == "typeOf" || path == "fieldType") {
            origin = ExprTypeOrigin::BuiltinContract;
            return builtinTypeEnum(model);
          }
          if (path == "fieldName") {
            origin = ExprTypeOrigin::BuiltinContract;
            return builtin(model, "string"); // fieldName materializes a static string literal
          }
          if (path == "sizeof" || path == "alignof" ||
              path == "fieldCount" || path == "fieldOffset") {
            origin = ExprTypeOrigin::BuiltinContract;
            return builtin(model, "int");
          }
        }
        if (path == "str" && node->c.size() == 2) {
          origin = ExprTypeOrigin::BuiltinContract;
          return builtin(model, "string", "dyn");
        }
        if ((path == "size" || path == "sizeof" || path == "strcmp") &&
            ((path == "strcmp" && node->c.size() == 3) ||
             (path != "strcmp" && node->c.size() == 2))) {
          origin = ExprTypeOrigin::BuiltinContract;
          return builtin(model, "int");
        }
        if (path == "math.abs" && node->c.size() == 2 && child(1)) {
          const TypeDescriptor &arg = *child(1);
          if (!integerType(arg) && !floatingType(arg)) return kInvalidType;
          origin = ExprTypeOrigin::BuiltinContract;
          return floatingType(arg) ? childId(1) : promoteInteger(model, arg);
        }
        if ((path == "math.min" || path == "math.max") && node->c.size() == 3 &&
            child(1) && child(2)) {
          const TypeId result = commonNumeric(model, childId(1), childId(2));
          if (result != kInvalidType) origin = ExprTypeOrigin::BuiltinContract;
          return result;
        }
        return kInvalidType;
      }
      case NK::New: {
        if (node->s.empty()) return kInvalidType;
        TypeSpec spec;
        spec.cat = "obj";
        spec.base = node->s;
        origin = ExprTypeOrigin::ExplicitSyntax;
        return model.types.intern(spec);
      }
      case NK::TupleLit: {
        std::vector<TypeId> components;
        components.reserve(children.size());
        for (ExprId id : children) {
          const Expression &component = model.expressions[id];
          if (component.typeState != ExprTypeState::Known || component.type == kInvalidType)
            return kInvalidType;
          components.push_back(component.type);
        }
        origin = ExprTypeOrigin::OperatorRule;
        return model.types.internComposite(TypeCategory::Tuple, components);
      }
      case NK::Lambda: {
        if (node->ts.base.empty()) return kInvalidType;
        TypeSpec signature;
        signature.cat = "func";
        signature.hasSig = true;
        for (const Param &param : node->params) {
          signature.sig.push_back(cloneTypeSpec(param.ts));
          signature.sigNoescape.push_back(param.noescape);
          signature.sigReadonly.push_back(param.readonly);
        }
        signature.sigReturnType = std::make_shared<TypeSpec>(cloneTypeSpec(node->ts));
        signature.sigLifetimeParams = node->lifetimeParams;
        signature.sigLifetimeOutlives = node->lifetimeOutlives;
        origin = ExprTypeOrigin::ExplicitSyntax;
        return model.types.intern(signature);
      }
      default: return kInvalidType;
    }
  }

  static void walk(SemanticModel &model, const Node *node, ExprId parent,
                   SymbolId owner, const std::string &module) {
    if (!node) return;
    ExprId currentParent = kInvalidExpr;
    if (isExpression(node->k)) {
      if (model.expressions.size() >= static_cast<size_t>(kInvalidExpr))
        throw std::overflow_error("FAC HIR expression table exhausted ExprId space");
      Expression expression;
      expression.id = static_cast<ExprId>(model.expressions.size());
      expression.parent = parent;
      expression.source = node;
      expression.owner = owner;
      expression.module = module;
      if (owner != kInvalidSymbol && owner < model.declarations.size()) {
        expression.file = model.declarations[owner].location.file;
      } else {
        for (const Module &candidate : model.modules)
          if (candidate.name == module) { expression.file = candidate.file; break; }
      }
      expression.line = node->line;
      expression.potentialLValue = node->k == NK::Ident || node->k == NK::Member ||
                                   node->k == NK::Index || node->k == NK::Deref;
      expression.hasSideEffects = node->k == NK::Call || node->k == NK::Assign ||
                                  node->k == NK::PostInc || node->k == NK::New ||
                                  node->k == NK::Propagate;
      currentParent = expression.id;
      model.expressionIds.emplace(node, expression.id);
      model.expressions.push_back(std::move(expression));
      if (parent != kInvalidExpr) model.expressions[parent].children.push_back(currentParent);
    }

    const ExprId childParent = isExpression(node->k) ? currentParent : kInvalidExpr;
    for (const NP &child : node->c)
      if (child) walk(model, child.get(), childParent, owner, module);
    if (node->deflt) walk(model, node->deflt.get(), kInvalidExpr, owner, module);
    for (const Param &param : node->params) {
      if (param.def) walk(model, param.def.get(), kInvalidExpr, owner, module);
      if (param.ts.size) walk(model, param.ts.size.get(), kInvalidExpr, owner, module);
      if (param.ts.size2) walk(model, param.ts.size2.get(), kInvalidExpr, owner, module);
    }
    if (node->ts.size) walk(model, node->ts.size.get(), kInvalidExpr, owner, module);
    if (node->ts.size2) walk(model, node->ts.size2.get(), kInvalidExpr, owner, module);
    for (const Case &item : node->cases) {
      for (const NP &value : item.vals)
        if (value) walk(model, value.get(), kInvalidExpr, owner, module);
      for (const CaseRange &range : item.ranges) {
        if (range.lo) walk(model, range.lo.get(), kInvalidExpr, owner, module);
        if (range.hi) walk(model, range.hi.get(), kInvalidExpr, owner, module);
      }
      if (item.guard) walk(model, item.guard.get(), kInvalidExpr, owner, module);
      if (item.body) walk(model, item.body.get(), kInvalidExpr, owner, module);
      if (item.exprBody) walk(model, item.exprBody.get(), childParent, owner, module);
    }

    if (currentParent != kInvalidExpr) {
      Expression &expression = model.expressions[currentParent];
      ExprTypeOrigin origin = ExprTypeOrigin::None;
      expression.type = infer(model, node, expression.children, origin);
      if (expression.type != kInvalidType) {
        expression.typeState = ExprTypeState::Known;
        expression.typeOrigin = origin;
      }
    }
  }
};

// Builds an immutable typed-expression view after local/call refinement. It
// intentionally omits unresolved expressions and language constructs whose
// type/child semantics are not represented completely in the current HIR.
class TypedAstBuilder {
 public:
  TypedAstModel build(const SemanticModel &model) const {
    TypedAstModel result;
    result.expressions.reserve(model.expressions.size());
    result.nodes.reserve(model.expressionSummary.typed);

    // Expression HIR is preorder; reverse iteration ensures every child has
    // already been considered before its parent is materialized.
    for (size_t index = model.expressions.size(); index > 0; --index) {
      const Expression &expression = model.expressions[index - 1];
      if (expression.typeState != ExprTypeState::Known ||
          expression.type == kInvalidType || expression.type > model.types.size()) {
        ++result.summary.skippedUnresolved;
        continue;
      }
      TypedAstKind kind;
      if (!mapKind(expression, kind)) {
        ++result.summary.skippedUnsupported;
        continue;
      }

      std::vector<TypedAstRef> children;
      if (!collectChildren(model, expression, kind, result.expressions, children)) {
        ++result.summary.skippedUnsupported;
        continue;
      }
      if (!validateShape(model, expression, kind, children)) {
        ++result.summary.skippedUnsupported;
        continue;
      }

      const TypedAstId id = static_cast<TypedAstId>(result.nodes.size());
      if (id == kInvalidTypedAst)
        throw std::overflow_error("FAC typed AST exhausted TypedAstId space");
      auto node = std::make_shared<const TypedAstNode>(
          id, kind, expression.type, expression.id,
          SourceLocation{expression.file, expression.module, expression.line},
          spelling(expression), std::move(children), expression.hasSideEffects,
          TypedAstOrigin::Source,
          kind == TypedAstKind::Call ? expression.call.selected : kInvalidSymbol);
      result.nodes.push_back(node);
      result.expressions.emplace(expression.id, std::move(node));

      switch (kind) {
        case TypedAstKind::IntLiteral: case TypedAstKind::FloatLiteral:
        case TypedAstKind::CharLiteral: case TypedAstKind::StringLiteral:
        case TypedAstKind::BoolLiteral: case TypedAstKind::NullLiteral:
          ++result.summary.literals; break;
        case TypedAstKind::Unary: case TypedAstKind::Postfix:
        case TypedAstKind::Binary:
          ++result.summary.operators; break;
        case TypedAstKind::Call: ++result.summary.calls; break;
        case TypedAstKind::Identifier: ++result.summary.identifiers; break;
        default: break;
      }
    }

    // A typed node is a root when its source parent was not materialized or
    // when the parent deliberately excludes it (for example a call's callee).
    for (const TypedAstRef &node : result.nodes) {
      const Expression &source = model.expressions[node->sourceExpression];
      bool attached = false;
      if (source.parent != kInvalidExpr) {
        auto parent = result.expressions.find(source.parent);
        if (parent != result.expressions.end()) {
          for (const TypedAstRef &child : parent->second->children)
            if (child.get() == node.get()) { attached = true; break; }
        }
      }
      if (!attached) result.roots.push_back(node);
    }

    result.summary.nodes = result.nodes.size();
    result.summary.roots = result.roots.size();
    if (!result.validate(model.types, model.expressions.size()))
      throw std::logic_error("FAC typed AST builder produced an invalid immutable tree");
    return result;
  }

 private:
  static bool mapKind(const Expression &expression, TypedAstKind &kind) {
    if (!expression.source) return false;
    switch (expression.source->k) {
      case NK::IntLit: kind = TypedAstKind::IntLiteral; return true;
      case NK::FloatLit: kind = TypedAstKind::FloatLiteral; return true;
      case NK::CharLit: kind = TypedAstKind::CharLiteral; return true;
      case NK::StrLit: kind = TypedAstKind::StringLiteral; return true;
      case NK::BoolLit: kind = TypedAstKind::BoolLiteral; return true;
      case NK::NullLit: kind = TypedAstKind::NullLiteral; return true;
      case NK::Ident:
        if (expression.localBinding == kInvalidLocal) return false;
        kind = TypedAstKind::Identifier; return true;
      case NK::Unary: kind = TypedAstKind::Unary; return true;
      case NK::PostInc: kind = TypedAstKind::Postfix; return true;
      case NK::Binary: kind = TypedAstKind::Binary; return true;
      case NK::Call:
        if (expression.call.state != CallResolutionState::Resolved &&
            expression.call.state != CallResolutionState::LocalCallable &&
            expression.typeOrigin != ExprTypeOrigin::BuiltinContract) return false;
        kind = TypedAstKind::Call; return true;
      case NK::New: kind = TypedAstKind::NewObject; return true;
      case NK::TupleLit: kind = TypedAstKind::Tuple; return true;
      default: return false;
    }
  }

  static bool collectChildren(const SemanticModel &model,
                              const Expression &expression, TypedAstKind kind,
                              const std::unordered_map<ExprId, TypedAstRef> &built,
                              std::vector<TypedAstRef> &children) {
    size_t first = kind == TypedAstKind::Call ? 1 : 0; // callee is stored in spelling/resolution
    if (first > expression.children.size()) return false;
    children.reserve(expression.children.size() - first);
    for (size_t i = first; i < expression.children.size(); ++i) {
      const ExprId childId = expression.children[i];
      if (childId >= model.expressions.size()) return false;
      auto found = built.find(childId);
      if (found == built.end()) return false;
      children.push_back(found->second);
    }
    return true;
  }

  static bool validateShape(const SemanticModel &model,
                            const Expression &expression, TypedAstKind kind,
                            const std::vector<TypedAstRef> &children) {
    const TypeDescriptor &result = model.types.get(expression.type);
    switch (kind) {
      case TypedAstKind::Unary: {
        if (children.size() != 1) return false;
        const TypeDescriptor &operand = model.types.get(children[0]->type);
        const std::string &op = expression.source->s;
        if (op == "!") return result.base == "bool";
        if (op == "~") return integerType(operand) && integerType(result);
        if (op == "+" || op == "-") return numericType(operand) && numericType(result);
        if (op == "++" || op == "--") return numericType(operand) && numericType(result);
        return false;
      }
      case TypedAstKind::Postfix: {
        if (children.size() != 1) return false;
        const TypeDescriptor &operand = model.types.get(children[0]->type);
        return numericType(operand) && sameTypeShape(model.types, children[0]->type, expression.type);
      }
      case TypedAstKind::Binary: {
        if (children.size() != 2) return false;
        const TypeDescriptor &lhs = model.types.get(children[0]->type);
        const TypeDescriptor &rhs = model.types.get(children[1]->type);
        const std::string &op = expression.source->s;
        if (op == "&&" || op == "||" || op == "==" || op == "!=" ||
            op == "<" || op == "<=" || op == ">" || op == ">=" ||
            op == "instanceof") return result.base == "bool";
        if (op == "+" && lhs.base == "string" && rhs.base == "string")
          return result.base == "string";
        if (op == "<<" || op == ">>" || op == "%" || op == "&" ||
            op == "|" || op == "^")
          return integerType(lhs) && integerType(rhs) && integerType(result);
        if (op == "+" || op == "-" || op == "*" || op == "/" || op == "**")
          return numericType(lhs) && numericType(rhs) && numericType(result);
        return false;
      }
      case TypedAstKind::Tuple:
        return result.category == TypeCategory::Tuple &&
               result.genericArguments.size() == children.size();
      case TypedAstKind::Identifier:
        return expression.localBinding != kInvalidLocal &&
               expression.localBinding < model.locals.size() &&
               model.locals[expression.localBinding].type == expression.type;
      case TypedAstKind::Call:
        return expression.call.state == CallResolutionState::Resolved ||
               expression.call.state == CallResolutionState::LocalCallable ||
               expression.typeOrigin == ExprTypeOrigin::BuiltinContract;
      case TypedAstKind::NewObject:
        return result.category == TypeCategory::Named || result.category == TypeCategory::Heap;
      default:
        return true;
    }
  }

  static bool integerType(const TypeDescriptor &type) {
    static const std::set<std::string> names = {
      "byte", "short", "int", "long", "ubyte", "ushort", "uint", "ulong",
      "char", "unichar", "enum"
    };
    return names.count(type.base) != 0;
  }

  static bool numericType(const TypeDescriptor &type) {
    return integerType(type) || type.base == "float" || type.base == "double";
  }

  static bool sameTypeShape(const TypeArena &types, TypeId left, TypeId right) {
    const TypeDescriptor &a = types.get(left), &b = types.get(right);
    return a.category == b.category && a.cat == b.cat && a.kind == b.kind &&
           a.base == b.base && a.base2 == b.base2 && a.genericArguments == b.genericArguments;
  }

  static std::string spelling(const Expression &expression) {
    const Node &node = *expression.source;
    switch (node.k) {
      case NK::IntLit: return std::to_string(node.iv);
      case NK::FloatLit: {
        std::ostringstream out;
        out << std::setprecision(17) << node.dv;
        return out.str();
      }
      case NK::CharLit: return std::to_string(node.iv);
      case NK::StrLit: return node.s;
      case NK::BoolLit: return node.b ? "true" : "false";
      case NK::NullLit: return "null";
      case NK::Ident: return node.s;
      case NK::Unary: case NK::PostInc: case NK::Binary: case NK::New:
        return node.s;
      case NK::Call:
        return expression.call.calleePath.empty() ? "<resolved-call>" : expression.call.calleePath;
      default: return {};
    }
  }
};

// Internal factory for immutable, generated typed-expression nodes. It is
// intentionally narrower than the source language: it accepts only already
// typed children and exact, non-generic function signatures. Generated nodes
// are semantic artifacts; this factory does not rewrite source AST or emit code.
class TypedAstFactory {
 public:
  explicit TypedAstFactory(SemanticModel &model) : model_(model) {
    if (!model_.typedAst.validate(model_.types, model_.expressions.size()))
      throw std::invalid_argument("TypedAstFactory requires a valid semantic typed-AST model");
  }

  TypedAstRef integerLiteral(int64_t value, TypeId type, SourceLocation location = {}) {
    requireBuiltin(type, "integer literal");
    if (!typedAstIntegerType(model_.types.get(type)) || model_.types.get(type).base == "enum" ||
        !typedAstIntegerLiteralFits(value, model_.types.get(type)))
      throw std::invalid_argument("TypedAstFactory integer literal requires an integer builtin TypeId");
    return append(TypedAstKind::IntLiteral, type, std::to_string(value), {}, false,
                  std::move(location));
  }

  TypedAstRef booleanLiteral(bool value, TypeId type, SourceLocation location = {}) {
    requireBuiltin(type, "boolean literal");
    if (model_.types.get(type).base != "bool")
      throw std::invalid_argument("TypedAstFactory boolean literal requires bool TypeId");
    return append(TypedAstKind::BoolLiteral, type, value ? "true" : "false", {}, false,
                  std::move(location));
  }

  TypedAstRef floatingLiteral(double value, TypeId type, SourceLocation location = {}) {
    if (type == kInvalidType || type > model_.types.size() ||
        (model_.types.get(type).base != "float" && model_.types.get(type).base != "double"))
      throw std::invalid_argument("TypedAstFactory floating literal requires float/double TypeId");
    std::ostringstream spelling;
    spelling << std::setprecision(17) << value;
    return append(TypedAstKind::FloatLiteral, type, spelling.str(), {}, false,
                  std::move(location));
  }

  TypedAstRef characterLiteral(int64_t codePoint, TypeId type, SourceLocation location = {}) {
    if (type == kInvalidType || type > model_.types.size() ||
        !typedAstCharacterLiteralFits(codePoint, model_.types.get(type)))
      throw std::invalid_argument("TypedAstFactory character literal requires char/unichar TypeId");
    return append(TypedAstKind::CharLiteral, type, std::to_string(codePoint), {}, false,
                  std::move(location));
  }

  TypedAstRef stringLiteral(std::string value, TypeId type, SourceLocation location = {}) {
    if (type == kInvalidType || type > model_.types.size() ||
        model_.types.get(type).base != "string")
      throw std::invalid_argument("TypedAstFactory string literal requires string TypeId");
    return append(TypedAstKind::StringLiteral, type, std::move(value), {}, false,
                  std::move(location));
  }

  TypedAstRef nullLiteral(TypeId type, SourceLocation location = {}) {
    if (type == kInvalidType || type > model_.types.size())
      throw std::invalid_argument("TypedAstFactory null literal requires a valid TypeId");
    const TypeDescriptor &descriptor = model_.types.get(type);
    if (descriptor.base != "null" && descriptor.category != TypeCategory::Pointer &&
        descriptor.category != TypeCategory::Heap)
      throw std::invalid_argument("TypedAstFactory null literal requires null/pointer/heap TypeId");
    return append(TypedAstKind::NullLiteral, type, "null", {}, false,
                  std::move(location));
  }

  TypedAstRef parameterReference(SymbolId functionId, size_t parameterIndex,
                                 SourceLocation location = {}) {
    const Declaration &function = generatedFunction(functionId);
    if (parameterIndex >= function.parameters.size())
      throw std::out_of_range("TypedAstFactory parameter index is out of range");
    const Parameter &parameter = function.parameters[parameterIndex];
    requireBodyScalar(parameter.type.type, "parameter reference");
    return append(TypedAstKind::Identifier, parameter.type.type, parameter.name, {}, false,
                  std::move(location), kInvalidSymbol, functionId,
                  GeneratedBindingKind::Parameter, static_cast<uint32_t>(parameterIndex));
  }

  TypedAstRef localReference(SymbolId functionId, uint32_t localIndex,
                             const std::string &name, TypeId type,
                             SourceLocation location = {}) {
    (void)generatedFunction(functionId);
    requireBodyScalar(type, "local reference");
    if (name.empty()) throw std::invalid_argument("TypedAstFactory local reference requires a name");
    return append(TypedAstKind::Identifier, type, name, {}, false, std::move(location),
                  kInvalidSymbol, functionId, GeneratedBindingKind::Local, localIndex);
  }

  TypedAstRef unary(std::string op, const TypedAstRef &operand, TypeId resultType,
                    SourceLocation location = {}) {
    requireChild(operand);
    if (!typedAstUnaryContract(model_.types, op, operand->type, resultType))
      throw std::invalid_argument("TypedAstFactory rejected unary operator/type combination: " + op);
    return append(TypedAstKind::Unary, resultType, std::move(op), {operand},
                  operand->hasSideEffects, std::move(location));
  }

  TypedAstRef binary(std::string op, const TypedAstRef &lhs, const TypedAstRef &rhs,
                     TypeId resultType, SourceLocation location = {}) {
    requireChild(lhs);
    requireChild(rhs);
    if (!typedAstBinaryContract(model_.types, op, lhs->type, rhs->type, resultType))
      throw std::invalid_argument("TypedAstFactory rejected binary operator/type combination: " + op);
    return append(TypedAstKind::Binary, resultType, std::move(op), {lhs, rhs},
                  lhs->hasSideEffects || rhs->hasSideEffects, std::move(location));
  }

  TypedAstRef tuple(const std::vector<TypedAstRef> &elements, SourceLocation location = {}) {
    std::vector<TypeId> componentTypes;
    componentTypes.reserve(elements.size());
    for (const TypedAstRef &element : elements) {
      requireChild(element);
      componentTypes.push_back(element->type);
    }
    const TypeId tupleType = model_.types.internComposite(TypeCategory::Tuple, componentTypes);
    bool sideEffects = false;
    for (const TypedAstRef &element : elements) sideEffects = sideEffects || element->hasSideEffects;
    return append(TypedAstKind::Tuple, tupleType, "tuple", elements, sideEffects,
                  std::move(location));
  }

  // Calls require a pre-resolved SymbolId and an exact non-generic signature.
  // Overload selection, visibility and import checks must have happened before
  // this factory is called.
  TypedAstRef call(SymbolId calleeId, const std::vector<TypedAstRef> &arguments,
                   SourceLocation location = {}) {
    if (calleeId >= model_.declarations.size())
      throw std::invalid_argument("TypedAstFactory call requires a valid resolved SymbolId");
    const Declaration &callee = model_.declarations[calleeId];
    if (callee.kind != SymbolKind::Function || callee.isGeneric ||
        !callee.typeParameters.empty() || !callee.constTypeParameters.empty() ||
        callee.parameters.size() != arguments.size() ||
        callee.returnType.type == kInvalidType || callee.returnType.type > model_.types.size())
      throw std::invalid_argument("TypedAstFactory call requires an exact non-generic function signature");
    for (size_t i = 0; i < arguments.size(); ++i) {
      requireChild(arguments[i]);
      if (callee.parameters[i].variadic || callee.parameters[i].type.type != arguments[i]->type)
        throw std::invalid_argument("TypedAstFactory call argument type does not match resolved parameter");
    }
    return append(TypedAstKind::Call, callee.returnType.type, callee.qualifiedName,
                  arguments, true, std::move(location), calleeId);
  }

 private:
  void requireBuiltin(TypeId type, const char *what) const {
    if (type == kInvalidType || type > model_.types.size() ||
        model_.types.get(type).category != TypeCategory::Builtin)
      throw std::invalid_argument(std::string("TypedAstFactory ") + what + " requires a builtin TypeId");
  }

  const Declaration &generatedFunction(SymbolId id) const {
    if (id >= model_.declarations.size())
      throw std::invalid_argument("TypedAstFactory binding requires a valid function SymbolId");
    const Declaration &function = model_.symbol(id);
    if (function.origin != DeclarationOrigin::Generated || function.kind != SymbolKind::Function ||
        function.isGeneric)
      throw std::invalid_argument("TypedAstFactory binding requires a generated non-generic function");
    return function;
  }

  void requireBodyScalar(TypeId type, const char *what) const {
    if (type == kInvalidType || type > model_.types.size())
      throw std::invalid_argument(std::string("TypedAstFactory ") + what + " has invalid TypeId");
    const TypeDescriptor &descriptor = model_.types.get(type);
    const std::string &base = descriptor.base;
    if (descriptor.category != TypeCategory::Builtin ||
        !(base == "byte" || base == "ubyte" || base == "short" || base == "ushort" ||
          base == "int" || base == "uint" || base == "long" || base == "ulong" ||
          base == "float" || base == "double" || base == "bool" || base == "char" ||
          base == "unichar"))
      throw std::invalid_argument(std::string("TypedAstFactory ") + what + " requires a scalar builtin TypeId");
  }

  void requireChild(const TypedAstRef &child) const {
    if (!child || child->id >= model_.typedAst.nodes.size() ||
        model_.typedAst.nodes[child->id].get() != child.get())
      throw std::invalid_argument("TypedAstFactory child must belong to the same typed-AST model");
  }

  TypedAstRef append(TypedAstKind kind, TypeId type, std::string spelling,
                     const std::vector<TypedAstRef> &children, bool sideEffects,
                     SourceLocation location, SymbolId callee = kInvalidSymbol,
                     SymbolId bindingFunction = kInvalidSymbol,
                     GeneratedBindingKind bindingKind = GeneratedBindingKind::None,
                     uint32_t bindingIndex = kInvalidGeneratedBinding) {
    if (type == kInvalidType || type > model_.types.size())
      throw std::invalid_argument("TypedAstFactory requires a valid result TypeId");
    for (const TypedAstRef &child : children) requireChild(child);
    if (model_.typedAst.nodes.size() >= static_cast<size_t>(kInvalidTypedAst))
      throw std::overflow_error("FAC typed AST exhausted TypedAstId space");

    const TypedAstId id = static_cast<TypedAstId>(model_.typedAst.nodes.size());
    auto node = std::make_shared<const TypedAstNode>(
        id, kind, type, kInvalidExpr, std::move(location), std::move(spelling),
        children, sideEffects, TypedAstOrigin::Generated, callee,
        bindingFunction, bindingKind, bindingIndex);
    const std::vector<TypedAstRef> oldRoots = model_.typedAst.roots;
    const TypedAstSummary oldSummary = model_.typedAst.summary;
    model_.typedAst.nodes.push_back(node);
    for (const TypedAstRef &child : children) {
      model_.typedAst.roots.erase(
          std::remove_if(model_.typedAst.roots.begin(), model_.typedAst.roots.end(),
                         [&](const TypedAstRef &root) { return root.get() == child.get(); }),
          model_.typedAst.roots.end());
    }
    model_.typedAst.roots.push_back(node);
    model_.typedAst.summary.nodes = model_.typedAst.nodes.size();
    model_.typedAst.summary.roots = model_.typedAst.roots.size();
    ++model_.typedAst.summary.generatedNodes;
    switch (kind) {
      case TypedAstKind::IntLiteral: case TypedAstKind::FloatLiteral:
      case TypedAstKind::CharLiteral: case TypedAstKind::StringLiteral:
      case TypedAstKind::BoolLiteral: case TypedAstKind::NullLiteral:
        ++model_.typedAst.summary.literals; break;
      case TypedAstKind::Unary: case TypedAstKind::Postfix: case TypedAstKind::Binary:
        ++model_.typedAst.summary.operators; break;
      case TypedAstKind::Call: ++model_.typedAst.summary.calls; break;
      default: break;
    }
    if (!model_.typedAst.validate(model_.types, model_.expressions.size()))
    {
      model_.typedAst.nodes.pop_back();
      model_.typedAst.roots = oldRoots;
      model_.typedAst.summary = oldSummary;
      throw std::logic_error("TypedAstFactory produced an invalid immutable typed-AST node");
    }
    return node;
  }

  SemanticModel &model_;
};

// Builds a validated generated free-function body from scalar locals,
// assignment statements and structured if/else regions, followed by one
// terminal return. It is lowered only after the complete SemanticModel
// validates. No source AST is mutated by this builder.
class TypedFunctionBodyBuilder {
 public:
  TypedFunctionBodyBuilder(SemanticModel &model, TypedAstFactory &expressions,
                           SymbolId functionId)
      : model_(model), expressions_(expressions), functionId_(functionId) {
    if (!model_.validate())
      throw std::invalid_argument("TypedFunctionBodyBuilder requires a valid SemanticModel");
    if (functionId_ >= model_.declarations.size())
      throw std::invalid_argument("generated function body requires a valid SymbolId");
    function_ = &model_.symbol(functionId_);
    if (function_->origin != DeclarationOrigin::Generated ||
        function_->kind != SymbolKind::Function || function_->isGeneric)
      throw std::invalid_argument("generated function body requires a generated non-generic free function");
    if (model_.generatedFunctionBodies.count(functionId_))
      throw std::invalid_argument("generated function already has a body: " + function_->qualifiedName);
    validateScalarSignature();
  }

  TypedAstRef parameter(size_t index, SourceLocation location = {}) {
    requireOpen();
    return expressions_.parameterReference(functionId_, index, std::move(location));
  }

  TypedAstRef localReference(const std::string &name, SourceLocation location = {}) {
    requireOpen();
    for (size_t i = 0; i < locals_.size(); ++i) {
      if (locals_[i].name == name)
        return expressions_.localReference(functionId_, static_cast<uint32_t>(i),
                                            locals_[i].name, locals_[i].type,
                                            std::move(location));
    }
    throw std::invalid_argument("generated function local is not declared yet: " + name);
  }

  void addLocal(const std::string &name, TypeId type, const TypedAstRef &initializer,
                SourceLocation location = {}) {
    addLocalImpl(name, type, initializer, false, std::move(location));
  }

  void addMutableLocal(const std::string &name, TypeId type,
                       const TypedAstRef &initializer, SourceLocation location = {}) {
    addLocalImpl(name, type, initializer, true, std::move(location));
  }

  void assignLocal(const std::string &name, const TypedAstRef &value,
                   SourceLocation location = {}) {
    requireOpen();
    statementStarted_ = true;
    const size_t index = findLocal(name);
    const GeneratedFunctionLocal &local = locals_[index];
    if (!local.isMutable)
      throw std::invalid_argument("cannot assign to immutable generated local: " + name);
    if (!value || value->type != local.type || !validExpression(value, locals_.size(), 0))
      throw std::invalid_argument("generated local assignment must exactly match the target TypeId: " + name);
    GeneratedFunctionStatement statement;
    statement.kind = GeneratedFunctionStatementKind::AssignLocal;
    statement.localIndex = static_cast<uint32_t>(index);
    statement.expression = value;
    statement.location = std::move(location);
    currentStatements().push_back(std::move(statement));
  }

  void beginIf(const TypedAstRef &condition, SourceLocation location = {}) {
    requireOpen();
    statementStarted_ = true;
    if (ifStack_.size() >= 64)
      throw std::invalid_argument("generated if/else nesting exceeds the V220 limit of 64");
    if (!condition || !isBoolType(condition->type) ||
        !validExpression(condition, locals_.size(), 0))
      throw std::invalid_argument("generated if condition must be a typed bool expression");
    GeneratedFunctionStatement statement;
    statement.kind = GeneratedFunctionStatementKind::IfElse;
    statement.condition = condition;
    statement.location = std::move(location);
    std::vector<GeneratedFunctionStatement> &parent = currentStatements();
    const size_t index = parent.size();
    parent.push_back(std::move(statement));
    ifStack_.push_back({index, false});
  }

  void beginElse() {
    requireOpen();
    if (ifStack_.empty() || ifStack_.back().inElse)
      throw std::logic_error("generated else has no unmatched if");
    ifStack_.back().inElse = true;
    currentIf().hasElse = true;
  }

  void endIf() {
    requireOpen();
    if (ifStack_.empty() || !ifStack_.back().inElse)
      throw std::logic_error("generated if/else must contain both branches");
    ifStack_.pop_back();
  }

  void returnValue(const TypedAstRef &value, SourceLocation location = {}) {
    requireOpen();
    requireNoOpenIf();
    if (isVoidReturn())
      throw std::invalid_argument("generated void function cannot return a value");
    if (!value || value->type != function_->returnType.type ||
        !validExpression(value, locals_.size(), 0))
      throw std::invalid_argument("generated return expression must exactly match the function return TypeId");
    returnValue_ = value;
    location_ = std::move(location);
    terminal_ = true;
  }

  void returnVoid(SourceLocation location = {}) {
    requireOpen();
    requireNoOpenIf();
    if (!isVoidReturn())
      throw std::invalid_argument("generated non-void function requires a return value");
    returnsVoid_ = true;
    location_ = std::move(location);
    terminal_ = true;
  }

  void commit() {
    if (committed_)
      throw std::logic_error("generated function body has already been committed");
    if (!terminal_)
      throw std::invalid_argument("generated function body must end with an explicit return");
    requireNoOpenIf();
    GeneratedFunctionBody body;
    body.function = functionId_;
    body.locals = locals_;
    body.statements = statements_;
    body.returnValue = returnValue_;
    body.returnsVoid = returnsVoid_;
    body.location = location_;
    auto inserted = model_.generatedFunctionBodies.emplace(functionId_, std::move(body));
    if (!inserted.second)
      throw std::invalid_argument("generated function already has a body: " + function_->qualifiedName);
    if (!model_.validate()) {
      model_.generatedFunctionBodies.erase(functionId_);
      throw std::logic_error("TypedFunctionBodyBuilder generated an invalid SemanticModel body");
    }
    committed_ = true;
  }

 private:
  struct IfFrame { size_t statementIndex = 0; bool inElse = false; };

  void addLocalImpl(const std::string &name, TypeId type, const TypedAstRef &initializer,
                    bool isMutable, SourceLocation location) {
    requireOpen();
    if (statementStarted_ || !ifStack_.empty())
      throw std::logic_error("generated locals must be declared before generated statements");
    if (!validIdentifier(name))
      throw std::invalid_argument("invalid generated local identifier: " + name);
    for (const Parameter &parameter : function_->parameters)
      if (parameter.name == name)
        throw std::invalid_argument("generated local conflicts with parameter: " + name);
    for (const GeneratedFunctionLocal &local : locals_)
      if (local.name == name) throw std::invalid_argument("duplicate generated local: " + name);
    requireScalar(type, "local " + name);
    if (!initializer || initializer->type != type || !validExpression(initializer, locals_.size(), 0))
      throw std::invalid_argument("generated local initializer must be a same-typed expression using earlier bindings: " + name);
    GeneratedFunctionLocal local;
    local.name = name;
    local.type = type;
    local.initializer = initializer;
    local.location = std::move(location);
    local.isMutable = isMutable;
    locals_.push_back(std::move(local));
  }
  SemanticModel &model_;
  TypedAstFactory &expressions_;
  SymbolId functionId_;
  const Declaration *function_ = nullptr;
  std::vector<GeneratedFunctionLocal> locals_;
  std::vector<GeneratedFunctionStatement> statements_;
  std::vector<IfFrame> ifStack_;
  TypedAstRef returnValue_;
  SourceLocation location_;
  bool statementStarted_ = false;
  bool returnsVoid_ = false;
  bool terminal_ = false;
  bool committed_ = false;

  static bool validIdentifier(const std::string &name) {
    if (name.empty()) return false;
    const unsigned char first = static_cast<unsigned char>(name.front());
    if (!(std::isalpha(first) || first == '_')) return false;
    for (unsigned char ch : name)
      if (!(std::isalnum(ch) || ch == '_')) return false;
    return true;
  }

  bool isVoidReturn() const {
    if (!function_ || function_->returnType.type == kInvalidType ||
        function_->returnType.type > model_.types.size()) return false;
    const TypeDescriptor &type = model_.types.get(function_->returnType.type);
    return type.category == TypeCategory::Builtin && type.base == "void";
  }

  void requireScalar(TypeId type, const std::string &what) const {
    if (type == kInvalidType || type > model_.types.size())
      throw std::invalid_argument("generated " + what + " has invalid TypeId");
    const TypeDescriptor &descriptor = model_.types.get(type);
    const std::string &base = descriptor.base;
    if (descriptor.category != TypeCategory::Builtin ||
        !(base == "byte" || base == "ubyte" || base == "short" || base == "ushort" ||
          base == "int" || base == "uint" || base == "long" || base == "ulong" ||
          base == "float" || base == "double" || base == "bool" || base == "char" ||
          base == "unichar"))
      throw std::invalid_argument("generated " + what + " currently requires a scalar builtin type");
  }

  bool isBoolType(TypeId type) const {
    if (type == kInvalidType || type > model_.types.size()) return false;
    const TypeDescriptor &descriptor = model_.types.get(type);
    return descriptor.category == TypeCategory::Builtin && descriptor.base == "bool";
  }

  size_t findLocal(const std::string &name) const {
    for (size_t i = 0; i < locals_.size(); ++i)
      if (locals_[i].name == name) return i;
    throw std::invalid_argument("generated function local is not declared: " + name);
  }

  std::vector<GeneratedFunctionStatement> &currentStatements() {
    std::vector<GeneratedFunctionStatement> *current = &statements_;
    for (const IfFrame &frame : ifStack_) {
      if (frame.statementIndex >= current->size())
        throw std::logic_error("generated if statement path is invalid");
      GeneratedFunctionStatement &statement = (*current)[frame.statementIndex];
      if (statement.kind != GeneratedFunctionStatementKind::IfElse)
        throw std::logic_error("generated statement path does not reference an if");
      current = frame.inElse ? &statement.elseStatements : &statement.thenStatements;
    }
    return *current;
  }

  GeneratedFunctionStatement &currentIf() {
    if (ifStack_.empty()) throw std::logic_error("generated if stack is empty");
    std::vector<GeneratedFunctionStatement> *current = &statements_;
    for (size_t i = 0; i + 1 < ifStack_.size(); ++i) {
      const IfFrame &frame = ifStack_[i];
      if (frame.statementIndex >= current->size())
        throw std::logic_error("generated if statement path is invalid");
      GeneratedFunctionStatement &statement = (*current)[frame.statementIndex];
      current = frame.inElse ? &statement.elseStatements : &statement.thenStatements;
    }
    IfFrame &last = ifStack_.back();
    if (last.statementIndex >= current->size())
      throw std::logic_error("generated if statement path is invalid");
    return (*current)[last.statementIndex];
  }

  void requireNoOpenIf() const {
    if (!ifStack_.empty())
      throw std::logic_error("generated function has an unterminated if/else region");
  }

  void validateScalarSignature() const {
    if (!isVoidReturn()) requireScalar(function_->returnType.type, "function return type");
    for (const Parameter &parameter : function_->parameters) {
      requireScalar(parameter.type.type, "parameter " + parameter.name);
      if (parameter.ref || parameter.immutableRef || parameter.variadic || parameter.noescape ||
          parameter.readonly || parameter.hasDefault)
        throw std::invalid_argument("generated function body parameters must be plain scalar value parameters");
    }
  }

  bool validExpression(const TypedAstRef &expression, size_t availableLocals,
                       unsigned depth) const {
    if (!expression || depth > 64 || expression->id >= model_.typedAst.nodes.size() ||
        model_.typedAst.nodes[expression->id].get() != expression.get() ||
        expression->origin != TypedAstOrigin::Generated) return false;
    try { requireScalar(expression->type, "expression"); }
    catch (...) { return false; }
    switch (expression->kind) {
      case TypedAstKind::IntLiteral: case TypedAstKind::FloatLiteral:
      case TypedAstKind::CharLiteral: case TypedAstKind::BoolLiteral:
        if (!expression->children.empty()) return false;
        break;
      case TypedAstKind::Identifier:
        if (expression->bindingFunction != functionId_ || !expression->children.empty()) return false;
        if (expression->bindingKind == GeneratedBindingKind::Parameter) {
          if (expression->bindingIndex >= function_->parameters.size()) return false;
        } else if (expression->bindingKind == GeneratedBindingKind::Local) {
          if (expression->bindingIndex >= availableLocals) return false;
        } else return false;
        break;
      case TypedAstKind::Unary:
        if (expression->children.size() != 1) return false;
        break;
      case TypedAstKind::Binary:
        if (expression->children.size() != 2) return false;
        break;
      case TypedAstKind::Call: {
        if (expression->resolvedCallee >= model_.declarations.size()) return false;
        const Declaration &callee = model_.symbol(expression->resolvedCallee);
        if (callee.kind != SymbolKind::Function || callee.module != function_->module ||
            callee.isGeneric || callee.parameters.size() != expression->children.size()) return false;
        break;
      }
      default: return false;
    }
    for (const TypedAstRef &child : expression->children)
      if (!validExpression(child, availableLocals, depth + 1)) return false;
    return true;
  }

  void requireOpen() const {
    if (terminal_ || committed_)
      throw std::logic_error("generated function body is already terminated");
  }
};

class LexicalScopeResolver {
 public:
  void resolve(SemanticModel &model) {
    model.scopes.clear();
    model.locals.clear();
    nextOrder_ = 0;

    std::map<std::string, ScopeId> moduleScopes;
    for (const Module &module : model.modules)
      moduleScopes.emplace(module.name, createScope(model, kInvalidScope,
          ScopeKind::Module, kInvalidSymbol, module.name));

    for (const Declaration &declaration : model.declarations) {
      const Node *source = declaration.sourceNode;
      if (!source) continue;
      if (declaration.kind == SymbolKind::Function) {
        const ScopeId functionScope = createScope(model,
            moduleScopes.at(declaration.module), ScopeKind::Function,
            declaration.id, declaration.module);
        // Default expressions can refer to earlier parameters, but not to the
        // parameter whose default is currently being evaluated.
        for (const Param &parameter : source->params) {
          if (parameter.def)
            visit(model, parameter.def.get(), functionScope, declaration.id,
                  declaration.module);
          addLocal(model, functionScope, declaration.id, declaration.module,
                   parameter.name, parameter.ts, nullptr, true,
                   parameter.ref, parameter.immutableRef, false, nextOrder_++);
        }
        for (const NP &child : source->c)
          if (child) visit(model, child.get(), functionScope, declaration.id,
                           declaration.module);
      } else if (declaration.kind == SymbolKind::Global && !source->c.empty()) {
        const ScopeId moduleScope = moduleScopes.at(declaration.module);
        for (const NP &child : source->c)
          if (child) visit(model, child.get(), moduleScope, declaration.id,
                           declaration.module);
      }
    }

    for (const Module &module : model.modules) {
      const ScopeId moduleScope = moduleScopes.at(module.name);
      for (const StaticAssertionInfo &assertion : module.staticAssertions)
        if (assertion.expression)
          visit(model, assertion.expression, moduleScope, kInvalidSymbol,
                module.name);
    }
  }

  static LocalSymbolId lookupForCall(const SemanticModel &model, ScopeId scope,
                                     const std::string &name, uint64_t sourceOrder) {
    return lookup(model, scope, name, sourceOrder);
  }

  static void refineInferredLocals(SemanticModel &model) {
    for (LocalSymbol &local : model.locals) {
      if (!local.isInferred || !local.declaration || local.declaration->c.empty() ||
          !local.declaration->c[0]) continue;
      auto expression = model.expressionIds.find(local.declaration->c[0].get());
      if (expression == model.expressionIds.end() ||
          expression->second >= model.expressions.size()) continue;
      const Expression &initializer = model.expressions[expression->second];
      if (initializer.typeState == ExprTypeState::Known)
        local.type = initializer.type;
    }
  }

 private:
  uint64_t nextOrder_ = 0;

  static ScopeId createScope(SemanticModel &model, ScopeId parent,
                             ScopeKind kind, SymbolId owner,
                             const std::string &module) {
    if (model.scopes.size() >= static_cast<size_t>(kInvalidScope))
      throw std::overflow_error("FAC HIR scope table exhausted ScopeId space");
    LexicalScope scope;
    scope.id = static_cast<ScopeId>(model.scopes.size());
    scope.parent = parent;
    scope.kind = kind;
    scope.owner = owner;
    scope.module = module;
    model.scopes.push_back(std::move(scope));
    return static_cast<ScopeId>(model.scopes.size() - 1);
  }

  static TypeId declaredType(SemanticModel &model, const TypeSpec &spec) {
    if (spec.base.empty() || spec.base == "auto") return kInvalidType;
    return model.types.intern(spec);
  }

  static LocalSymbolId addLocal(SemanticModel &model, ScopeId scopeId,
                                SymbolId owner, const std::string &module,
                                const std::string &name, const TypeSpec &type,
                                const Node *declaration, bool parameter,
                                bool isReference, bool immutableReference,
                                bool isConst, uint64_t sourceOrder) {
    if (name.empty() || scopeId >= model.scopes.size()) return kInvalidLocal;
    if (model.locals.size() >= static_cast<size_t>(kInvalidLocal))
      throw std::overflow_error("FAC HIR local table exhausted LocalSymbolId space");

    LocalSymbol local;
    local.id = static_cast<LocalSymbolId>(model.locals.size());
    local.name = name;
    local.type = declaredType(model, type);
    local.scope = scopeId;
    local.owner = owner;
    local.module = module;
    local.declaration = declaration;
    local.sourceOrder = sourceOrder;
    local.isParameter = parameter;
    local.isConst = isConst;
    local.isReference = isReference;
    local.isImmutableReference = immutableReference;
    local.isInferred = type.base == "auto" || type.base.empty();
    if (declaration) {
      local.location.file = owner != kInvalidSymbol && owner < model.declarations.size()
          ? model.declarations[owner].location.file : std::string();
      local.location.module = module;
      local.location.line = declaration->line;
    } else if (owner != kInvalidSymbol && owner < model.declarations.size()) {
      local.location = model.declarations[owner].location;
    }

    const LocalSymbolId id = local.id;
    model.locals.push_back(std::move(local));
    LexicalScope &scope = model.scopes[scopeId];
    // A duplicate in one lexical scope is already rejected by the frontend;
    // retaining the first binding keeps the HIR deterministic on bad ASTs.
    if (scope.names.emplace(name, id).second) scope.locals.push_back(id);
    else model.locals.pop_back();
    return id;
  }

  static LocalSymbolId lookup(const SemanticModel &model, ScopeId scope,
                              const std::string &name, uint64_t sourceOrder) {
    while (scope != kInvalidScope && scope < model.scopes.size()) {
      const LexicalScope &current = model.scopes[scope];
      auto found = current.names.find(name);
      if (found != current.names.end() &&
          model.locals[found->second].sourceOrder < sourceOrder)
        return found->second;
      scope = current.parent;
    }
    return kInvalidLocal;
  }

  void annotateExpression(SemanticModel &model, const Node *node,
                          ScopeId scope) {
    auto found = model.expressionIds.find(node);
    if (found == model.expressionIds.end() || found->second >= model.expressions.size())
      return;
    Expression &expression = model.expressions[found->second];
    expression.lexicalScope = scope;
    expression.sourceOrder = nextOrder_++;
    if (node->k == NK::Ident)
      expression.localBinding = lookup(model, scope, node->s, expression.sourceOrder);
  }

  void visitCase(SemanticModel &model, const Case &item,
                        ScopeId parentScope, SymbolId owner,
                        const std::string &module) {
    const ScopeId armScope = createScope(model, parentScope,
        ScopeKind::MatchArm, owner, module);
    for (const std::string &binding : item.bindings) {
      if (binding.empty() || binding == "_") continue;
      TypeSpec unknown;
      addLocal(model, armScope, owner, module, binding, unknown, nullptr,
               false, false, false, false, nextOrder_++);
    }
    for (const NP &value : item.vals)
      if (value) visit(model, value.get(), armScope, owner, module);
    for (const CaseRange &range : item.ranges) {
      if (range.lo) visit(model, range.lo.get(), armScope, owner, module);
      if (range.hi) visit(model, range.hi.get(), armScope, owner, module);
    }
    if (item.guard) visit(model, item.guard.get(), armScope, owner, module);
    if (item.body) visit(model, item.body.get(), armScope, owner, module);
    if (item.exprBody) visit(model, item.exprBody.get(), armScope, owner, module);
  }

  void visit(SemanticModel &model, const Node *node, ScopeId scope,
             SymbolId owner, const std::string &module) {
    if (!node) return;
    annotateExpression(model, node, scope);

    switch (node->k) {
      case NK::Block: {
        const ScopeId blockScope = createScope(model, scope, ScopeKind::Block,
                                               owner, module);
        for (const NP &child : node->c)
          if (child) visit(model, child.get(), blockScope, owner, module);
        return;
      }
      case NK::VarDecl: {
        // The initializer is evaluated before the declared name enters scope.
        for (const NP &child : node->c)
          if (child) visit(model, child.get(), scope, owner, module);
        const LocalSymbolId local = addLocal(model, scope, owner, module,
            node->s, node->ts, node, false, node->isRef,
            node->isImmutableRef, node->isConst, nextOrder_++);
        if (local != kInvalidLocal && model.locals[local].type == kInvalidType &&
            !node->c.empty() && node->c[0]) {
          auto initializer = model.expressionIds.find(node->c[0].get());
          if (initializer != model.expressionIds.end() &&
              initializer->second < model.expressions.size()) {
            const Expression &value = model.expressions[initializer->second];
            if (value.typeState == ExprTypeState::Known)
              model.locals[local].type = value.type;
          }
        }
        return;
      }
      case NK::For: {
        const ScopeId loopScope = createScope(model, scope, ScopeKind::Loop,
                                              owner, module);
        for (const NP &child : node->c)
          if (child) visit(model, child.get(), loopScope, owner, module);
        return;
      }
      case NK::ForPP: {
        const ScopeId loopScope = createScope(model, scope, ScopeKind::Loop,
                                              owner, module);
        for (const NP &child : node->c)
          if (child) visit(model, child.get(), loopScope, owner, module);
        return;
      }
      case NK::ForEach: {
        const ScopeId loopScope = createScope(model, scope, ScopeKind::Loop,
                                              owner, module);
        if (!node->c.empty() && node->c[0])
          visit(model, node->c[0].get(), loopScope, owner, module);
        addLocal(model, loopScope, owner, module, node->s, node->ts, node,
                 false, false, false, false, nextOrder_++);
        for (size_t i = 1; i < node->c.size(); ++i)
          if (node->c[i]) visit(model, node->c[i].get(), loopScope, owner, module);
        return;
      }
      case NK::Try: {
        if (!node->c.empty() && node->c[0])
          visit(model, node->c[0].get(), scope, owner, module);
        if (node->c.size() > 1 && node->c[1]) {
          const ScopeId catchScope = createScope(model, scope, ScopeKind::Catch,
                                                 owner, module);
          TypeSpec catchType;
          catchType.base = node->ts.base;
          addLocal(model, catchScope, owner, module, node->s, catchType,
                   node, false, false, false, true, nextOrder_++);
          visit(model, node->c[1].get(), catchScope, owner, module);
        }
        if (node->c.size() > 2 && node->c[2])
          visit(model, node->c[2].get(), scope, owner, module);
        return;
      }
      case NK::Match: case NK::MatchExpr: {
        if (!node->c.empty() && node->c[0])
          visit(model, node->c[0].get(), scope, owner, module);
        for (const Case &item : node->cases)
          visitCase(model, item, scope, owner, module);
        if (node->deflt) visit(model, node->deflt.get(), scope, owner, module);
        return;
      }
      case NK::Switch: {
        for (const NP &child : node->c)
          if (child) visit(model, child.get(), scope, owner, module);
        for (const Case &item : node->cases)
          visitCase(model, item, scope, owner, module);
        if (node->deflt) visit(model, node->deflt.get(), scope, owner, module);
        return;
      }
      case NK::Lambda: {
        const ScopeId lambdaScope = createScope(model, scope, ScopeKind::Lambda,
                                                owner, module);
        for (const Param &parameter : node->params) {
          if (parameter.def)
            visit(model, parameter.def.get(), lambdaScope, owner, module);
          addLocal(model, lambdaScope, owner, module, parameter.name,
                   parameter.ts, nullptr, true, parameter.ref,
                   parameter.immutableRef, false, nextOrder_++);
        }
        for (const NP &child : node->c)
          if (child) visit(model, child.get(), lambdaScope, owner, module);
        return;
      }
      default:
        break;
    }

    for (const NP &child : node->c)
      if (child) visit(model, child.get(), scope, owner, module);
    if (node->deflt) visit(model, node->deflt.get(), scope, owner, module);
    for (const Param &parameter : node->params) {
      if (parameter.def) visit(model, parameter.def.get(), scope, owner, module);
      if (parameter.ts.size)
        visit(model, parameter.ts.size.get(), scope, owner, module);
      if (parameter.ts.size2)
        visit(model, parameter.ts.size2.get(), scope, owner, module);
    }
    if (node->ts.size) visit(model, node->ts.size.get(), scope, owner, module);
    if (node->ts.size2) visit(model, node->ts.size2.get(), scope, owner, module);
    for (const Case &item : node->cases)
      visitCase(model, item, scope, owner, module);
  }
};

class OverloadResolver {
 public:
  void resolve(SemanticModel &model) const {
    // Calls are considered bottom-up so a nested call can provide the type
    // needed by its parent call in the same pass.
    for (size_t index = model.expressions.size(); index > 0; --index) {
      Expression &expression = model.expressions[index - 1];
      if (!expression.source || expression.source->k != NK::Call) continue;
      expression.call = CallResolution{};
      resolveCall(model, expression);
    }
  }

 private:
  struct Match {
    SymbolId symbol = kInvalidSymbol;
    int cost = 0;
    std::map<std::string, TypeId> substitutions;
    GenericInferenceState genericState = GenericInferenceState::NotGeneric;
    std::vector<TypeId> explicitArguments;
  };

  enum class BoundStatus : uint8_t { Satisfied, Failed, Deferred };

  static bool isImported(const Module &module, const std::string &provider) {
    if (module.name == provider) return true;
    if (std::find(module.imports.begin(), module.imports.end(), provider) !=
        module.imports.end()) return true;
    for (const ImportBinding &binding : module.importBindings)
      if (binding.module == provider) return true;
    return false;
  }

  static bool selectionAllows(const Module &module, const std::string &provider,
                              const std::string &name) {
    const ImportBinding *just = nullptr;
    const ImportBinding *without = nullptr;
    for (const ImportBinding &binding : module.importBindings) {
      if (binding.module != provider) continue;
      if (binding.selection == 1) just = &binding;
      else if (binding.selection == 2) without = &binding;
    }
    if (just && std::find(just->names.begin(), just->names.end(), name) == just->names.end())
      return false;
    if (without && std::find(without->names.begin(), without->names.end(), name) != without->names.end())
      return false;
    return true;
  }

  static std::string callPath(const Node *node) {
    if (!node) return {};
    if (node->k == NK::Ident) return node->s;
    if (node->k == NK::Member && !node->c.empty()) {
      const std::string prefix = callPath(node->c[0].get());
      return prefix.empty() ? std::string() : prefix + "." + node->s;
    }
    return {};
  }

  static std::vector<SymbolId> functionsIn(const SemanticModel &model,
                                           const std::string &module,
                                           const std::string &name) {
    std::vector<SymbolId> result;
    for (SymbolId id : model.find(module + "." + name)) {
      if (id < model.declarations.size()) {
        const Declaration &declaration = model.symbol(id);
        if (declaration.kind == SymbolKind::Function && declaration.owner.empty())
          result.push_back(id);
      }
    }
    return result;
  }

  static bool expandModuleAlias(const Module &source, const std::string &path,
                                std::string &provider, std::string &name) {
    for (const ImportBinding &binding : source.importBindings) {
      if (binding.alias.empty()) continue;
      const std::string prefix = binding.alias + ".";
      if (path.compare(0, prefix.size(), prefix) == 0) {
        provider = binding.module;
        name = path.substr(prefix.size());
        return !name.empty();
      }
    }
    return false;
  }

  static bool splitKnownModule(const SemanticModel &model, const std::string &path,
                               std::string &provider, std::string &name) {
    size_t longest = 0;
    for (const Module &module : model.modules) {
      const std::string prefix = module.name + ".";
      if (path.compare(0, prefix.size(), prefix) == 0 && module.name.size() > longest) {
        longest = module.name.size();
        provider = module.name;
        name = path.substr(prefix.size());
      }
    }
    return longest != 0 && !name.empty();
  }

  static std::vector<SymbolId> candidates(const SemanticModel &model,
                                          const std::string &sourceModule,
                                          const std::string &path,
                                          bool &qualifiedPath) {
    std::vector<SymbolId> result;
    const Module *source = nullptr;
    for (const Module &module : model.modules)
      if (module.name == sourceModule) { source = &module; break; }
    if (!source) return result;

    if (path.find('.') == std::string::npos) {
      result = functionsIn(model, sourceModule, path);
      if (!result.empty()) return result;
      std::set<std::string> providers(source->imports.begin(), source->imports.end());
      for (const ImportBinding &binding : source->importBindings)
        providers.insert(binding.module);
      for (const std::string &provider : providers) {
        if (!isImported(*source, provider) || !selectionAllows(*source, provider, path))
          continue;
        for (SymbolId id : functionsIn(model, provider, path)) {
          const Declaration &target = model.symbol(id);
          if (target.isPublic) result.push_back(id);
        }
      }
      return result;
    }

    std::string provider, name;
    if (!expandModuleAlias(*source, path, provider, name) &&
        !splitKnownModule(model, path, provider, name)) return result;
    qualifiedPath = true;
    if (!isImported(*source, provider)) return result;
    if (!selectionAllows(*source, provider, name)) return result;
    for (SymbolId id : functionsIn(model, provider, name)) {
      const Declaration &target = model.symbol(id);
      if (provider == sourceModule || target.isPublic) result.push_back(id);
    }
    return result;
  }

  static bool numericInfo(const TypeDescriptor &type, bool &floating,
                          int &bits, bool &sign) {
    floating = type.base == "float" || type.base == "double";
    if (floating) {
      bits = type.base == "float" ? 32 : 64;
      sign = true;
      return true;
    }
    static const std::map<std::string, std::pair<int, bool>> integers = {
      {"byte", {8, true}}, {"ubyte", {8, false}}, {"short", {16, true}},
      {"ushort", {16, false}}, {"int", {32, true}}, {"uint", {32, false}},
      {"long", {64, true}}, {"ulong", {64, false}}, {"char", {8, true}},
      {"unichar", {32, false}}
    };
    auto found = integers.find(type.base);
    if (found == integers.end()) return false;
    bits = found->second.first;
    sign = found->second.second;
    return true;
  }

  static bool sameSemanticType(const TypeDescriptor &source,
                               const TypeDescriptor &target) {
    const auto normalizedKind = [](const std::string &kind) -> const std::string & {
      static const std::string empty;
      return kind == "var" ? empty : kind;
    };
    return source.category == target.category && source.cat == target.cat &&
           normalizedKind(source.kind) == normalizedKind(target.kind) &&
           source.base == target.base && source.base2 == target.base2 &&
           source.lifetime == target.lifetime &&
           source.lifetimeParamIndex == target.lifetimeParamIndex &&
           source.elemObj == target.elemObj && source.isVolatile == target.isVolatile &&
           source.hasSize == target.hasSize && source.hasSize2 == target.hasSize2 &&
           source.hasSignature == target.hasSignature &&
           source.genericArguments == target.genericArguments &&
           source.parameters == target.parameters &&
           source.returnType == target.returnType &&
           source.noescape == target.noescape && source.readonly == target.readonly &&
           source.lifetimeParameters == target.lifetimeParameters &&
           source.lifetimeOutlives == target.lifetimeOutlives;
  }

  static int conversionCost(const SemanticModel &model, TypeId from, TypeId to) {
    if (from == kInvalidType || to == kInvalidType) return -1;
    if (from == to || sameSemanticType(model.types.get(from), model.types.get(to)))
      return 0;
    const TypeDescriptor &source = model.types.get(from);
    const TypeDescriptor &target = model.types.get(to);
    bool sourceFloat = false, targetFloat = false;
    int sourceBits = 0, targetBits = 0;
    bool sourceSigned = false, targetSigned = false;
    if (!numericInfo(source, sourceFloat, sourceBits, sourceSigned) ||
        !numericInfo(target, targetFloat, targetBits, targetSigned)) return -1;
    if (sourceFloat) {
      if (!targetFloat || targetBits < sourceBits) return -1;
      return 1 + (targetBits - sourceBits) / 32;
    }
    if (targetFloat) return 16 + targetBits / 32;
    if (targetBits < sourceBits) return -1;
    if (sourceSigned != targetSigned && targetBits == sourceBits) return -1;
    if (sourceSigned != targetSigned && targetBits < sourceBits + 1) return -1;
    return 1 + (targetBits - sourceBits) + (sourceSigned == targetSigned ? 0 : 1);
  }

  static SymbolId findTypeSymbol(const SemanticModel &model,
                                 const std::string &sourceModule,
                                 const std::string &typeName) {
    if (typeName.empty()) return kInvalidSymbol;
    std::vector<SymbolId> local = model.find(sourceModule + "." + typeName);
    for (SymbolId id : local) {
      const SymbolKind kind = model.symbol(id).kind;
      if (kind == SymbolKind::Struct || kind == SymbolKind::Class ||
          kind == SymbolKind::Interface || kind == SymbolKind::Enum) return id;
    }
    if (typeName.find('.') != std::string::npos) {
      std::vector<SymbolId> qualified = model.find(typeName);
      for (SymbolId id : qualified) {
        const SymbolKind kind = model.symbol(id).kind;
        if (kind == SymbolKind::Struct || kind == SymbolKind::Class ||
            kind == SymbolKind::Interface || kind == SymbolKind::Enum) return id;
      }
    }
    SymbolId unique = kInvalidSymbol;
    for (const Declaration &declaration : model.declarations) {
      if (declaration.name != typeName) continue;
      if (declaration.kind != SymbolKind::Struct && declaration.kind != SymbolKind::Class &&
          declaration.kind != SymbolKind::Interface && declaration.kind != SymbolKind::Enum) continue;
      if (unique != kInvalidSymbol) return kInvalidSymbol;
      unique = declaration.id;
    }
    return unique;
  }

  static bool typeIsAccessible(const SemanticModel &model, const std::string &sourceModule,
                               SymbolId typeSymbol) {
    if (typeSymbol == kInvalidSymbol || typeSymbol >= model.declarations.size()) return false;
    const Declaration &target = model.symbol(typeSymbol);
    if (target.module == sourceModule) return true;
    const Module *source = nullptr;
    for (const Module &module : model.modules)
      if (module.name == sourceModule) { source = &module; break; }
    return source && isImported(*source, target.module) && target.isPublic &&
        selectionAllows(*source, target.module, target.name);
  }

  static void normalizeExplicitTypeSpec(SemanticModel &model, const std::string &module,
                                        TypeSpec &type, unsigned depth = 0) {
    if (depth > 32) return;
    for (TypeSpec &argument : type.genericArgs)
      normalizeExplicitTypeSpec(model, module, argument, depth + 1);
    for (TypeSpec &parameter : type.sig)
      normalizeExplicitTypeSpec(model, module, parameter, depth + 1);
    if (type.sigReturnType)
      normalizeExplicitTypeSpec(model, module, *type.sigReturnType, depth + 1);

    if (!type.genericArgs.empty()) {
      const SymbolId genericType = findTypeSymbol(model, module, type.base);
      if (genericType != kInvalidSymbol && genericType < model.declarations.size()) {
        const Declaration &declaration = model.symbol(genericType);
        std::vector<bool> supplied;
        std::vector<bool> effectiveDefaults = declaration.genericHasDefault;
        if (effectiveDefaults.size() != declaration.typeParameters.size())
          effectiveDefaults.assign(declaration.typeParameters.size(), false);
        std::string ignoredDiagnostic;
        (void)orderNamedGenericArgumentsWithDefaults(type.genericArgs,
            declaration.typeParameters, effectiveDefaults,
            supplied, ignoredDiagnostic);
        const Node *genericSource = declaration.sourceNode;
        for (size_t index = 0; index < type.genericArgs.size() &&
             index < supplied.size() && genericSource &&
             index < genericSource->genericDefaults.size(); ++index)
          if (!supplied[index]) type.genericArgs[index] = cloneTypeSpec(genericSource->genericDefaults[index]);
      }
    }

    if (!type.cat.empty() || type.base.empty()) return;
    const SymbolId symbol = findTypeSymbol(model, module, type.base);
    if (!typeIsAccessible(model, module, symbol)) return;
    switch (model.symbol(symbol).kind) {
      case SymbolKind::Struct: type.cat = "struct"; break;
      case SymbolKind::Enum: type.cat = "enum"; break;
      case SymbolKind::Class:
      case SymbolKind::Interface: type.cat = "obj"; break;
      default: break;
    }
  }

  static TypeId internExplicitTypeArgument(SemanticModel &model, const std::string &module,
                                           const TypeSpec &source) {
    TypeSpec normalized = cloneTypeSpec(source);
    normalizeExplicitTypeSpec(model, module, normalized);
    return model.types.intern(normalized);
  }

  static bool internExplicitGenericArguments(SemanticModel &model,
                                              const std::string &module,
                                              const std::vector<TypeSpec> &source,
                                              const std::vector<std::string> &parameters,
                                              const Node *declarationNode,
                                              const std::vector<bool> &hasDefaults,
                                              std::vector<TypeId> &result) {
    std::vector<TypeSpec> ordered;
    ordered.reserve(source.size());
    for (const TypeSpec &argument : source)
      ordered.push_back(cloneTypeSpec(argument));
    std::vector<bool> supplied;
    std::vector<bool> effectiveDefaults = hasDefaults;
    if (effectiveDefaults.size() != parameters.size())
      effectiveDefaults.assign(parameters.size(), false);
    std::string diagnostic;
    if (!orderNamedGenericArgumentsWithDefaults(ordered, parameters,
            effectiveDefaults, supplied, diagnostic)) return false;
    for (size_t index = 0; index < ordered.size(); ++index) {
      if (!supplied[index]) {
        if (!declarationNode || index >= declarationNode->genericDefaults.size()) return false;
        ordered[index] = cloneTypeSpec(declarationNode->genericDefaults[index]);
      }
      normalizeExplicitTypeSpec(model, module, ordered[index]);
    }
    result.clear();
    result.reserve(ordered.size());
    for (const TypeSpec &argument : ordered)
      result.push_back(internExplicitTypeArgument(model, module, argument));
    return true;
  }

  static TypeId normalizeTypeId(SemanticModel &model, const std::string &module,
                                TypeId typeId, unsigned depth = 0) {
    if (typeId == kInvalidType || depth > 32) return typeId;
    TypeDescriptor descriptor = model.types.get(typeId);
    bool changed = false;
    if (descriptor.category == TypeCategory::Other && descriptor.cat.empty() &&
        !descriptor.base.empty()) {
      const SymbolId symbol = findTypeSymbol(model, module, descriptor.base);
      if (typeIsAccessible(model, module, symbol)) {
        switch (model.symbol(symbol).kind) {
          case SymbolKind::Struct:
            descriptor.category = TypeCategory::Named;
            descriptor.cat = "struct";
            changed = true;
            break;
          case SymbolKind::Enum:
            descriptor.category = TypeCategory::Named;
            descriptor.cat = "enum";
            changed = true;
            break;
          case SymbolKind::Class:
          case SymbolKind::Interface:
            descriptor.category = TypeCategory::Named;
            descriptor.cat = "obj";
            changed = true;
            break;
          default:
            break;
        }
      }
    }
    for (TypeId &argument : descriptor.genericArguments) {
      const TypeId normalized = normalizeTypeId(model, module, argument, depth + 1);
      if (normalized != argument) { argument = normalized; changed = true; }
    }
    for (TypeId &parameter : descriptor.parameters) {
      const TypeId normalized = normalizeTypeId(model, module, parameter, depth + 1);
      if (normalized != parameter) { parameter = normalized; changed = true; }
    }
    if (descriptor.returnType != kInvalidType) {
      const TypeId normalized = normalizeTypeId(model, module, descriptor.returnType, depth + 1);
      if (normalized != descriptor.returnType) {
        descriptor.returnType = normalized;
        changed = true;
      }
    }
    return changed ? model.types.internDescriptor(descriptor) : typeId;
  }

  static std::vector<SymbolId> methodCandidates(SemanticModel &model,
                                                const Expression &expression,
                                                const Node *callee,
                                                SymbolId &ownerSymbol,
                                                bool &staticReceiver,
                                                std::vector<TypeId> &ownerArguments,
                                                bool &needsMoreTypeInfo) {
    std::vector<SymbolId> result;
    ownerSymbol = kInvalidSymbol;
    staticReceiver = false;
    ownerArguments.clear();
    if (!callee || callee->k != NK::Member || callee->c.empty() || !callee->c[0])
      return result;

    const Node *receiverNode = callee->c[0].get();
    auto receiverId = model.expressionIds.find(receiverNode);
    if (receiverId != model.expressionIds.end() && receiverId->second < model.expressions.size()) {
      const Expression &receiver = model.expressions[receiverId->second];
      if (receiver.localBinding != kInvalidLocal) {
        if (receiver.typeState != ExprTypeState::Known || receiver.type == kInvalidType) {
          needsMoreTypeInfo = true;
          return result;
        }
        const TypeDescriptor &type = model.types.get(receiver.type);
        if (type.category != TypeCategory::Named || type.base.empty()) return result;
        ownerSymbol = findTypeSymbol(model, expression.module, type.base);
        ownerArguments = type.genericArguments;
        staticReceiver = false;
      } else if (receiver.typeState == ExprTypeState::Known && receiver.type != kInvalidType) {
        const TypeDescriptor &type = model.types.get(receiver.type);
        if (type.category == TypeCategory::Named && !type.base.empty()) {
          ownerSymbol = findTypeSymbol(model, expression.module, type.base);
          ownerArguments = type.genericArguments;
          staticReceiver = false;
        }
      }
    }

    // A bare, unshadowed type name is a static receiver. Generic type syntax
    // (`Box<int>.make`) stores its TypeSpec on the receiver node.
    if (ownerSymbol == kInvalidSymbol && receiverNode->k == NK::Ident) {
      const std::string name = !receiverNode->ts.base.empty()
          ? receiverNode->ts.base : receiverNode->s;
      ownerSymbol = findTypeSymbol(model, expression.module, name);
      if (ownerSymbol != kInvalidSymbol) {
        staticReceiver = true;
        if (ownerSymbol < model.declarations.size()) {
          const Declaration &ownerDeclaration = model.symbol(ownerSymbol);
          if (!internExplicitGenericArguments(model, expression.module,
                  receiverNode->ts.genericArgs, ownerDeclaration.typeParameters,
                  ownerDeclaration.sourceNode, ownerDeclaration.genericHasDefault,
                  ownerArguments)) {
            needsMoreTypeInfo = true;
            return result;
          }
        }
      }
    }
    if (ownerSymbol == kInvalidSymbol) return result;
    for (TypeId &argument : ownerArguments)
      argument = normalizeTypeId(model, expression.module, argument);

    const Declaration &owner = model.symbol(ownerSymbol);
    if (!owner.typeParameters.empty() && ownerArguments.size() != owner.typeParameters.size()) {
      needsMoreTypeInfo = true;
      return result;
    }
    for (SymbolId methodId : owner.methods) {
      if (methodId >= model.declarations.size()) continue;
      const Declaration &method = model.symbol(methodId);
      if (method.name == callee->s && method.kind == SymbolKind::Function &&
          method.isStatic == staticReceiver)
        result.push_back(methodId);
    }
    return result;
  }

  static bool typeNameIn(const std::set<std::string> &names,
                         const TypeDescriptor &descriptor) {
    return !descriptor.base.empty() && names.count(descriptor.base) != 0;
  }

  static bool bindType(const SemanticModel &model, const std::string &name,
                       TypeId actual, std::map<std::string, TypeId> &bindings,
                       int &cost, bool allowInference, bool &needsMoreTypeInfo,
                       bool requireExactBinding = false) {
    if (name.empty() || actual == kInvalidType) {
      needsMoreTypeInfo = true;
      return false;
    }
    auto found = bindings.find(name);
    if (found == bindings.end()) {
      if (!allowInference) {
        needsMoreTypeInfo = true;
        return false;
      }
      bindings.emplace(name, actual);
      return true;
    }
    if (requireExactBinding) {
      const TypeDescriptor &source = model.types.get(actual);
      const TypeDescriptor &target = model.types.get(found->second);
      if (sameSemanticType(source, target)) return true;
      if (source.category == TypeCategory::Unknown || target.category == TypeCategory::Unknown ||
          source.category == TypeCategory::Other || target.category == TypeCategory::Other)
        needsMoreTypeInfo = true;
      return false;
    }
    const int conversion = conversionCost(model, actual, found->second);
    if (conversion < 0) {
      const TypeDescriptor &source = model.types.get(actual);
      const TypeDescriptor &target = model.types.get(found->second);
      if (source.base == target.base &&
          (source.category == TypeCategory::Other || source.category == TypeCategory::Unknown ||
           target.category == TypeCategory::Other || target.category == TypeCategory::Unknown))
        needsMoreTypeInfo = true;
      return false;
    }
    cost += conversion;
    return true;
  }

  static bool isElementContainer(TypeCategory category) {
    return category == TypeCategory::List || category == TypeCategory::Array;
  }

  static TypeId containerElementType(SemanticModel &model, const std::string &module,
                                     const TypeDescriptor &container) {
    if (!isElementContainer(container.category) || container.base.empty())
      return kInvalidType;

    TypeDescriptor element;
    element.base = container.base;
    element.genericArguments = container.genericArguments;
    if (container.elemObj) {
      element.category = TypeCategory::Named;
      element.cat = "obj";
    } else {
      const SymbolId symbol = findTypeSymbol(model, module, container.base);
      if (symbol != kInvalidSymbol) {
        switch (model.symbol(symbol).kind) {
          case SymbolKind::Struct:
            element.category = TypeCategory::Named;
            element.cat = "struct";
            break;
          case SymbolKind::Enum:
            element.category = TypeCategory::Named;
            element.cat = "enum";
            break;
          case SymbolKind::Class:
          case SymbolKind::Interface:
            element.category = TypeCategory::Named;
            element.cat = "obj";
            break;
          default:
            return kInvalidType;
        }
      } else {
        // Only scalar built-ins can be reconstructed without a resolved type
        // declaration. Unknown spellings stay deferred rather than becoming
        // speculative `Other` types.
        static const std::set<std::string> builtins = {
          "void", "bool", "boolean", "byte", "ubyte", "short", "ushort",
          "int", "uint", "long", "ulong", "float", "double", "char",
          "unichar", "string", "null"
        };
        if (!builtins.count(container.base)) return kInvalidType;
        element.category = TypeCategory::Builtin;
      }
    }
    return model.types.internDescriptor(element);
  }

  static bool unifyGenericType(SemanticModel &model, const std::string &module,
                               TypeId patternId, TypeId actualId,
                               const std::set<std::string> &genericNames,
                               std::map<std::string, TypeId> &bindings, int &cost,
                               bool allowNamedInference, bool &needsMoreTypeInfo,
                               unsigned depth = 0) {
    if (patternId == kInvalidType || actualId == kInvalidType || depth > 32) {
      needsMoreTypeInfo = true;
      return false;
    }
    // Copy descriptors: container element inference may intern a new TypeId,
    // which can reallocate the arena's backing vector.
    TypeDescriptor pattern = model.types.get(patternId);
    const TypeDescriptor actual = model.types.get(actualId);

    const bool genericBase = typeNameIn(genericNames, pattern);
    const bool autoBase = pattern.base == "auto";
    bool substitutedContainerBase = false;
    if (genericBase || autoBase) {
      if (isElementContainer(pattern.category) &&
          pattern.category == actual.category && pattern.cat == actual.cat) {
        const TypeId element = containerElementType(model, module, actual);
        if (element == kInvalidType) {
          needsMoreTypeInfo = true;
          return false;
        }
        const std::string bindingName = autoBase ? "@auto" : pattern.base;
        if (!bindType(model, bindingName, element, bindings, cost,
                      allowNamedInference || autoBase, needsMoreTypeInfo,
                      allowNamedInference)) return false;
        pattern.base = actual.base;
        pattern.elemObj = actual.elemObj;
        substitutedContainerBase = true;
      } else if (pattern.category == TypeCategory::Other ||
                 pattern.category == TypeCategory::Unknown ||
                 pattern.category == TypeCategory::Builtin) {
        const std::string bindingName = autoBase ? "@auto" : pattern.base;
        return bindType(model, bindingName, actualId, bindings, cost,
                        allowNamedInference || autoBase, needsMoreTypeInfo,
                        allowNamedInference);
      } else {
        needsMoreTypeInfo = true;
        return false;
      }
    }

    const bool hasNestedParameters = !pattern.genericArguments.empty() ||
        !pattern.parameters.empty() || pattern.returnType != kInvalidType;
    if (pattern.category != actual.category || pattern.cat != actual.cat ||
        (pattern.kind != actual.kind && pattern.kind != "var" && actual.kind != "var") ||
        pattern.base != actual.base || pattern.base2 != actual.base2 ||
        pattern.lifetime != actual.lifetime ||
        pattern.lifetimeParamIndex != actual.lifetimeParamIndex ||
        pattern.elemObj != actual.elemObj || pattern.isVolatile != actual.isVolatile ||
        pattern.hasSignature != actual.hasSignature ||
        pattern.genericArguments.size() != actual.genericArguments.size() ||
        pattern.parameters.size() != actual.parameters.size() ||
        ((pattern.returnType == kInvalidType) != (actual.returnType == kInvalidType)) ||
        pattern.noescape != actual.noescape || pattern.readonly != actual.readonly ||
        pattern.lifetimeParameters != actual.lifetimeParameters ||
        pattern.lifetimeOutlives != actual.lifetimeOutlives) {
      if (!hasNestedParameters && !containsGenericParameter(model, patternId, genericNames)) {
        const int conversion = conversionCost(model, actualId, patternId);
        if (conversion >= 0) { cost += conversion; return true; }
      }
      return false;
    }
    for (size_t i = 0; i < pattern.genericArguments.size(); ++i)
      if (!unifyGenericType(model, module, pattern.genericArguments[i], actual.genericArguments[i],
                            genericNames, bindings, cost, allowNamedInference,
                            needsMoreTypeInfo, depth + 1)) return false;
    for (size_t i = 0; i < pattern.parameters.size(); ++i)
      if (!unifyGenericType(model, module, pattern.parameters[i], actual.parameters[i],
                            genericNames, bindings, cost, allowNamedInference,
                            needsMoreTypeInfo, depth + 1)) return false;
    if (pattern.returnType != kInvalidType &&
        !unifyGenericType(model, module, pattern.returnType, actual.returnType,
                          genericNames, bindings, cost, allowNamedInference,
                          needsMoreTypeInfo, depth + 1)) return false;
    if (patternId != actualId && !hasNestedParameters && !substitutedContainerBase) {
      const int conversion = conversionCost(model, actualId, patternId);
      if (conversion < 0) return false;
      cost += conversion;
    }
    return true;
  }

  static bool containsGenericParameter(const SemanticModel &model, TypeId typeId,
                                       const std::set<std::string> &genericNames,
                                       unsigned depth = 0) {
    if (typeId == kInvalidType || depth > 32) return false;
    const TypeDescriptor &type = model.types.get(typeId);
    if (typeNameIn(genericNames, type) || type.base == "auto") return true;
    for (TypeId child : type.genericArguments)
      if (containsGenericParameter(model, child, genericNames, depth + 1)) return true;
    for (TypeId child : type.parameters)
      if (containsGenericParameter(model, child, genericNames, depth + 1)) return true;
    return type.returnType != kInvalidType &&
        containsGenericParameter(model, type.returnType, genericNames, depth + 1);
  }

  static TypeId substituteType(SemanticModel &model, TypeId typeId,
                               const std::map<std::string, TypeId> &bindings,
                               const std::set<std::string> &genericNames,
                               unsigned depth = 0) {
    if (typeId == kInvalidType || depth > 32) return kInvalidType;
    const TypeDescriptor &source = model.types.get(typeId);
    auto baseBinding = bindings.find(source.base);
    if (baseBinding != bindings.end() && genericNames.count(source.base) &&
        (source.category == TypeCategory::Other || source.category == TypeCategory::Unknown ||
         source.category == TypeCategory::Builtin)) return baseBinding->second;
    if (source.base == "auto" &&
        (source.category == TypeCategory::Builtin || isElementContainer(source.category))) {
      auto automatic = bindings.find("@auto");
      if (automatic == bindings.end()) return kInvalidType;
      if (source.category == TypeCategory::Builtin) return automatic->second;
    }

    TypeDescriptor result = source;
    bool changed = false;
    if (isElementContainer(source.category) &&
        (source.base == "auto" || genericNames.count(source.base))) {
      const std::string bindingName = source.base == "auto" ? "@auto" : source.base;
      auto elementBinding = bindings.find(bindingName);
      if (elementBinding == bindings.end()) return kInvalidType;
      const TypeDescriptor element = model.types.get(elementBinding->second);
      result.base = element.base;
      result.elemObj = element.category == TypeCategory::Named && element.cat == "obj";
      if (element.genericArguments.size() != result.genericArguments.size())
        return kInvalidType;
      result.genericArguments = element.genericArguments;
      changed = true;
    }
    for (TypeId &argument : result.genericArguments) {
      const TypeId replacement = substituteType(model, argument, bindings, genericNames, depth + 1);
      if (replacement == kInvalidType) {
        if (containsGenericParameter(model, argument, genericNames)) return kInvalidType;
      } else if (replacement != argument) { argument = replacement; changed = true; }
    }
    for (TypeId &parameter : result.parameters) {
      const TypeId replacement = substituteType(model, parameter, bindings, genericNames, depth + 1);
      if (replacement == kInvalidType) {
        if (containsGenericParameter(model, parameter, genericNames)) return kInvalidType;
      } else if (replacement != parameter) { parameter = replacement; changed = true; }
    }
    if (result.returnType != kInvalidType) {
      const TypeId replacement = substituteType(model, result.returnType, bindings, genericNames, depth + 1);
      if (replacement == kInvalidType) {
        if (containsGenericParameter(model, result.returnType, genericNames)) return kInvalidType;
      } else if (replacement != result.returnType) { result.returnType = replacement; changed = true; }
    }
    if (!changed) return typeId;
    return model.types.internDescriptor(result);
  }

  static bool numericBound(const TypeDescriptor &type) {
    bool floating = false, sign = false;
    int bits = 0;
    return numericInfo(type, floating, bits, sign);
  }

  static bool integralBound(const TypeDescriptor &type) {
    bool floating = false, sign = false;
    int bits = 0;
    return numericInfo(type, floating, bits, sign) && !floating;
  }

  static SymbolId actualTypeSymbol(const SemanticModel &model, const std::string &module,
                                   TypeId type) {
    if (type == kInvalidType) return kInvalidSymbol;
    const TypeDescriptor &descriptor = model.types.get(type);
    if (descriptor.category != TypeCategory::Named || descriptor.base.empty()) return kInvalidSymbol;
    return findTypeSymbol(model, module, descriptor.base);
  }

  static BoundStatus isSubtypeOf(const SemanticModel &model, SymbolId actual,
                                 SymbolId expected, std::set<SymbolId> &seen) {
    if (actual == expected) return BoundStatus::Satisfied;
    if (actual == kInvalidSymbol || expected == kInvalidSymbol ||
        actual >= model.declarations.size()) return BoundStatus::Deferred;
    if (!seen.insert(actual).second) return BoundStatus::Failed;

    const Declaration &declaration = model.symbol(actual);
    bool deferred = false;
    auto testUse = [&](const TypeUse &use) {
      if (use.resolvedSymbol == kInvalidSymbol && use.names.empty() &&
          (use.type == kInvalidType || model.types.get(use.type).base.empty()))
        return BoundStatus::Failed;
      if (use.resolvedSymbol != kInvalidSymbol)
        return isSubtypeOf(model, use.resolvedSymbol, expected, seen);
      for (const ResolvedName &name : use.names) {
        if (name.symbol != kInvalidSymbol)
          return isSubtypeOf(model, name.symbol, expected, seen);
        if (name.kind == NameResolutionKind::NotFound ||
            name.kind == NameResolutionKind::Ambiguous ||
            name.kind == NameResolutionKind::NotImported ||
            name.kind == NameResolutionKind::Private ||
            name.kind == NameResolutionKind::Filtered ||
            name.kind == NameResolutionKind::AliasCycle)
          return BoundStatus::Deferred;
      }
      return BoundStatus::Deferred;
    };

    BoundStatus parent = testUse(declaration.parentType);
    if (parent == BoundStatus::Satisfied) return parent;
    deferred = deferred || parent == BoundStatus::Deferred;
    for (const TypeUse &implemented : declaration.implementedTypes) {
      const BoundStatus status = testUse(implemented);
      if (status == BoundStatus::Satisfied) return status;
      deferred = deferred || status == BoundStatus::Deferred;
    }
    return deferred ? BoundStatus::Deferred : BoundStatus::Failed;
  }

  static bool unresolvedNamedType(const SemanticModel &model, const std::string &module,
                                  TypeId actualType, const TypeDescriptor &actual) {
    if (actual.category != TypeCategory::Other &&
        actual.category != TypeCategory::Unknown) return false;
    return actualTypeSymbol(model, module, actualType) == kInvalidSymbol;
  }

  static BoundStatus satisfiesBound(const SemanticModel &model, const std::string &module,
                                    TypeId actualType, const GenericConstraint &constraint) {
    if (actualType == kInvalidType || constraint.bound.type == kInvalidType)
      return BoundStatus::Deferred;
    const TypeDescriptor &actual = model.types.get(actualType);
    const TypeDescriptor &bound = model.types.get(constraint.bound.type);
    const bool uncertainNamed = unresolvedNamedType(model, module, actualType, actual);
    if (bound.base == "numeric" || bound.base == "number")
      return numericBound(actual) ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    if (bound.base == "integral" || bound.base == "integer")
      return integralBound(actual) ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    if (bound.base == "floating") {
      const bool matches = actual.base == "float" || actual.base == "double";
      return matches ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    }
    if (bound.base == "signed") {
      const bool matches = actual.base == "byte" || actual.base == "short" ||
          actual.base == "int" || actual.base == "long" || actual.base == "char";
      return matches ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    }
    if (bound.base == "unsigned") {
      const bool matches = actual.base == "ubyte" || actual.base == "ushort" ||
          actual.base == "uint" || actual.base == "ulong" || actual.base == "unichar";
      return matches ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    }
    if (bound.base == "value") {
      const bool matches = actual.category == TypeCategory::Builtin ||
          actual.cat == "struct" || actual.cat == "enum" || actual.category == TypeCategory::Tuple;
      return matches ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    }
    if (bound.base == "reference") {
      const bool matches = actual.cat == "obj" || actual.cat == "weakobj" ||
          actual.category == TypeCategory::Pointer || actual.category == TypeCategory::Heap ||
          actual.category == TypeCategory::Dynamic;
      return matches ? BoundStatus::Satisfied
          : (uncertainNamed ? BoundStatus::Deferred : BoundStatus::Failed);
    }

    SymbolId expected = constraint.bound.resolvedSymbol;
    if (expected == kInvalidSymbol) {
      for (const ResolvedName &name : constraint.bound.names)
        if (name.symbol != kInvalidSymbol) { expected = name.symbol; break; }
    }
    const SymbolId actualSymbol = actualTypeSymbol(model, module, actualType);
    if (expected == kInvalidSymbol || actualSymbol == kInvalidSymbol)
      return BoundStatus::Deferred;
    std::set<SymbolId> seen;
    return isSubtypeOf(model, actualSymbol, expected, seen);
  }

  static bool evaluateArrayExtentConstant(const Node *node, int64_t &value) {
    if (!node) return false;
    switch (node->k) {
      case NK::IntLit: case NK::CharLit:
        value = node->iv;
        return true;
      case NK::BoolLit:
        value = node->b ? 1 : 0;
        return true;
      case NK::Unary: {
        if (node->c.empty()) return false;
        int64_t operand = 0;
        if (!evaluateArrayExtentConstant(node->c[0].get(), operand)) return false;
        if (node->s == "+") { value = operand; return true; }
        if (node->s == "-") {
          if (operand == INT64_MIN) return false;
          value = -operand;
          return true;
        }
        if (node->s == "!") { value = operand == 0; return true; }
        return false;
      }
      case NK::Binary: {
        if (node->c.size() < 2) return false;
        int64_t left = 0, right = 0;
        if (!evaluateArrayExtentConstant(node->c[0].get(), left) ||
            !evaluateArrayExtentConstant(node->c[1].get(), right)) return false;
        if (node->s == "+") return !__builtin_add_overflow(left, right, &value);
        if (node->s == "-") return !__builtin_sub_overflow(left, right, &value);
        if (node->s == "*") return !__builtin_mul_overflow(left, right, &value);
        if (node->s == "/" || node->s == "%") {
          if (right == 0 || (left == INT64_MIN && right == -1)) return false;
          value = node->s == "/" ? left / right : left % right;
          return true;
        }
        return false;
      }
      default:
        return false;
    }
  }

  static bool inferConstArrayValue(SemanticModel &model,
                                   const TypeUse &parameterType,
                                   const Expression &argument,
                                   const std::set<std::string> &constParameterNames,
                                   std::map<std::string, TypeId> &substitutions,
                                   bool &needsMoreTypeInfo,
                                   bool &constraintFailure) {
    const Node *extentPattern = parameterType.sizeExpression;
    if (!parameterType.hasSize || !extentPattern || extentPattern->k != NK::Ident ||
        !constParameterNames.count(extentPattern->s)) return true;

    if (argument.type == kInvalidType ||
        model.types.get(argument.type).category != TypeCategory::Array ||
        argument.localBinding == kInvalidLocal ||
        argument.localBinding >= model.locals.size()) {
      needsMoreTypeInfo = true;
      return false;
    }

    const LocalSymbol &local = model.locals[argument.localBinding];
    const Node *declaration = local.declaration;
    if (!declaration || declaration->k != NK::VarDecl ||
        declaration->ts.cat != "array" || !declaration->ts.hasSize) {
      needsMoreTypeInfo = true;
      return false;
    }
    int64_t value = 0;
    if (!evaluateArrayExtentConstant(declaration->ts.size.get(), value)) {
      needsMoreTypeInfo = true;
      return false;
    }

    TypeSpec constArgument;
    constArgument.isConstValue = true;
    constArgument.constValue = value;
    const TypeId constType = model.types.intern(constArgument);
    auto existing = substitutions.find(extentPattern->s);
    if (existing != substitutions.end()) {
      const TypeDescriptor &previous = model.types.get(existing->second);
      if (!previous.isConstValue || previous.constValue != value) {
        constraintFailure = true;
        return false;
      }
      return true;
    }
    substitutions[extentPattern->s] = constType;
    return true;
  }

  static bool genericMethodCost(SemanticModel &model,
                                const Declaration &candidate,
                                const Declaration &owner,
                                const Node &call, const Node *callee,
                                const std::vector<ExprId> &children,
                                const std::vector<TypeId> &ownerArguments,
                                int &cost, bool &needsMoreTypeInfo,
                                bool &constraintFailure,
                                std::map<std::string, TypeId> &substitutions,
                                GenericInferenceState &genericState,
                                bool inferNamedTypeParameters = false) {
    const std::vector<Parameter> &parameters = candidate.parameters;
    const size_t argumentCount = call.c.empty() ? 0 : call.c.size() - 1;
    const bool variadic = !parameters.empty() && parameters.back().variadic;
    if ((!variadic && argumentCount > parameters.size()) ||
        (variadic && argumentCount + 1 < parameters.size())) return false;
    size_t required = parameters.size();
    while (required > 0 && parameters[required - 1].hasDefault) --required;
    if (argumentCount < required || (!variadic && argumentCount > parameters.size())) return false;

    std::set<std::string> genericNames(owner.typeParameters.begin(), owner.typeParameters.end());
    genericNames.insert(candidate.typeParameters.begin(), candidate.typeParameters.end());
    for (size_t index = 0; index < owner.typeParameters.size(); ++index) {
      if (index >= ownerArguments.size()) { needsMoreTypeInfo = true; return false; }
      substitutions[owner.typeParameters[index]] = ownerArguments[index];
    }

    std::vector<TypeId> explicitArguments;
    if (callee) {
      const std::vector<TypeSpec> *sourceArguments = &callee->explicitTypeArgs;
      // A bare generic free-function call is parsed before declarations are
      // resolved, so its postfix `<...>` list initially lives on ts.genericArgs.
      if (sourceArguments->empty() && callee->k == NK::Ident &&
          candidate.owner.empty() && !callee->ts.genericArgs.empty())
        sourceArguments = &callee->ts.genericArgs;
      const bool hasExplicitSourceArguments = !sourceArguments->empty();
      bool allMethodParametersDefaulted = !candidate.typeParameters.empty() &&
          candidate.genericHasDefault.size() == candidate.typeParameters.size();
      if (allMethodParametersDefaulted)
        for (bool hasDefault : candidate.genericHasDefault)
          allMethodParametersDefaulted = allMethodParametersDefaulted && hasDefault;
      const bool shouldMaterializeDefaults = !hasExplicitSourceArguments &&
          !candidate.owner.empty() && allMethodParametersDefaulted;
      const bool inferFreeFunctionArguments = candidate.owner.empty() && inferNamedTypeParameters;
      if (hasExplicitSourceArguments || shouldMaterializeDefaults) {
        if (!internExplicitGenericArguments(model, candidate.module,
                *sourceArguments, candidate.typeParameters, candidate.sourceNode,
                candidate.genericHasDefault, explicitArguments)) {
          constraintFailure = true;
          genericState = GenericInferenceState::ConstraintFailure;
          return false;
        }
      } else if (!inferFreeFunctionArguments) {
        // Preserve the explicit/deferred generic method rule and the free-
        // function inference path when not every parameter has a default.
      }
    }
    if (!explicitArguments.empty() && explicitArguments.size() != candidate.typeParameters.size())
      return false;
    if (explicitArguments.empty() && !candidate.typeParameters.empty() &&
        !inferNamedTypeParameters) {
      // Generic methods retain the explicit `method<T>(...)` source rule.
      // This opt-in is used only for generic free functions, where the parser
      // already permits ordinary `function<T>` declarations and call syntax
      // remains unambiguous (`identity(value)`).
      needsMoreTypeInfo = true;
      genericState = GenericInferenceState::Deferred;
      return false;
    }
    const std::set<std::string> constParameterNames(candidate.constTypeParameters.begin(),
                                                     candidate.constTypeParameters.end());
    for (size_t index = 0; index < explicitArguments.size(); ++index) {
      const TypeDescriptor &argument = model.types.get(explicitArguments[index]);
      const bool expectsConst = constParameterNames.count(candidate.typeParameters[index]) != 0;
      if (expectsConst != (argument.isConstValue || argument.isConstExpression)) {
        constraintFailure = true;
        genericState = GenericInferenceState::ConstraintFailure;
        return false;
      }
      substitutions[candidate.typeParameters[index]] = explicitArguments[index];
    }

    const bool inferAuto = std::any_of(parameters.begin(), parameters.end(), [&](const Parameter &parameter) {
      return parameter.type.type != kInvalidType &&
          model.types.get(parameter.type.type).base == "auto";
    });
    if (!explicitArguments.empty() || !owner.typeParameters.empty())
      genericState = GenericInferenceState::ExplicitArguments;
    else if (inferAuto || (inferNamedTypeParameters && !candidate.typeParameters.empty()))
      genericState = GenericInferenceState::InferredFromArguments;

    cost = static_cast<int>((parameters.size() - std::min(argumentCount, parameters.size())) * 2);
    for (size_t index = 0; index < argumentCount; ++index) {
      if (index >= parameters.size()) { needsMoreTypeInfo = true; return false; }
      const size_t exprChild = index + 1;
      if (exprChild >= children.size() || children[exprChild] >= model.expressions.size()) {
        needsMoreTypeInfo = true;
        return false;
      }
      const Expression &argument = model.expressions[children[exprChild]];
      if (argument.typeState != ExprTypeState::Known || argument.type == kInvalidType) {
        needsMoreTypeInfo = true;
        return false;
      }
      if (!unifyGenericType(model, candidate.module, parameters[index].type.type,
                            argument.type, genericNames, substitutions, cost,
                            inferNamedTypeParameters, needsMoreTypeInfo)) {
        // An `auto` parameter is the only inference variable accepted here.
        const TypeDescriptor &pattern = model.types.get(parameters[index].type.type);
        if (pattern.category != TypeCategory::Builtin || pattern.base != "auto") return false;
        return false;
      }
      if (explicitArguments.empty() && inferNamedTypeParameters &&
          !candidate.constTypeParameters.empty()) {
        if (!inferConstArrayValue(model, parameters[index].type, argument,
                                  constParameterNames, substitutions,
                                  needsMoreTypeInfo, constraintFailure)) {
          if (constraintFailure) genericState = GenericInferenceState::ConstraintFailure;
          else genericState = GenericInferenceState::Deferred;
          return false;
        }
      }
    }

    if (candidate.owner.empty() && inferNamedTypeParameters && explicitArguments.empty()) {
      for (size_t index = 0; index < candidate.typeParameters.size(); ++index) {
        const std::string &name = candidate.typeParameters[index];
        if (substitutions.count(name)) continue; // inferred from the actual arguments
        if (index >= candidate.genericHasDefault.size() ||
            !candidate.genericHasDefault[index]) {
          needsMoreTypeInfo = true;
          return false;
        }
        if (!candidate.sourceNode || index >= candidate.sourceNode->genericDefaults.size()) {
          needsMoreTypeInfo = true;
          return false;
        }
        TypeId defaultType = internExplicitTypeArgument(
            model, candidate.module, candidate.sourceNode->genericDefaults[index]);
        substitutions[name] = defaultType;
      }
    }

    for (const std::string &name : candidate.typeParameters)
      if (!substitutions.count(name)) { needsMoreTypeInfo = true; return false; }
    for (const std::string &name : owner.typeParameters)
      if (!substitutions.count(name)) { needsMoreTypeInfo = true; return false; }

    auto validateBounds = [&](const Declaration &declaration) {
      for (const GenericConstraint &bound : declaration.genericBounds) {
        auto value = substitutions.find(bound.parameter);
        if (value == substitutions.end()) {
          needsMoreTypeInfo = true;
          return false;
        }
        if (bound.isConstValuePredicate) {
          const TypeDescriptor &constValue = model.types.get(value->second);
          if (!constValue.isConstValue) {
            needsMoreTypeInfo = true;
            return false;
          }
          if (!satisfiesConstGenericConstraint(bound.valuePredicate, constValue.constValue)) {
            constraintFailure = true;
            return false;
          }
          continue;
        }
        const BoundStatus status = satisfiesBound(model, candidate.module, value->second, bound);
        if (status == BoundStatus::Deferred) {
          needsMoreTypeInfo = true;
          return false;
        }
        if (status == BoundStatus::Failed) {
          constraintFailure = true;
          return false;
        }
      }
      return true;
    };
    if (!validateBounds(owner) || !validateBounds(candidate)) {
      genericState = GenericInferenceState::ConstraintFailure;
      return false;
    }
    return true;
  }

  static bool candidateCost(const SemanticModel &model, const Declaration &candidate,
                            const Node &call, const std::vector<ExprId> &children,
                            int &cost, bool &needsMoreTypeInfo) {
    if (candidate.isGeneric || !candidate.sourceNode) {
      needsMoreTypeInfo = true;
      return false;
    }
    const std::vector<Parameter> &parameters = candidate.parameters;
    const size_t argumentCount = call.c.empty() ? 0 : call.c.size() - 1;
    const bool variadic = !parameters.empty() && parameters.back().variadic;
    if ((!variadic && argumentCount > parameters.size()) ||
        (variadic && argumentCount + 1 < parameters.size())) return false;

    size_t required = parameters.size();
    while (required > 0 && parameters[required - 1].hasDefault) --required;
    if (argumentCount < required) return false;
    if (!variadic && argumentCount > parameters.size()) return false;

    cost = static_cast<int>((parameters.size() - std::min(argumentCount, parameters.size())) * 2);
    for (size_t index = 0; index < argumentCount; ++index) {
      if (index >= parameters.size()) {
        // C-style variadic promotion is backend-specific; record a possible
        // candidate but defer its selection until that ABI contract is modeled.
        needsMoreTypeInfo = true;
        return false;
      }
      const size_t exprChild = index + 1;
      if (exprChild >= children.size() || children[exprChild] >= model.expressions.size()) {
        needsMoreTypeInfo = true;
        return false;
      }
      const Expression &argument = model.expressions[children[exprChild]];
      if (argument.typeState != ExprTypeState::Known || argument.type == kInvalidType) {
        needsMoreTypeInfo = true;
        return false;
      }
      const TypeId targetType = parameters[index].type.type;
      const int conversion = conversionCost(model, argument.type, targetType);
      if (conversion < 0) return false;
      cost += conversion;
    }
    if (variadic) cost += 8;
    return true;
  }

  static bool resolveMethodCall(SemanticModel &model, Expression &expression,
                                const Node *callee, const Node &call) {
    SymbolId ownerId = kInvalidSymbol;
    bool staticReceiver = false;
    bool needsMoreTypeInfo = false;
    std::vector<TypeId> ownerArguments;
    std::vector<SymbolId> viableSet = methodCandidates(model, expression, callee,
        ownerId, staticReceiver, ownerArguments, needsMoreTypeInfo);
    expression.call.isMethodCall = true;
    expression.call.candidates = viableSet;
    if (viableSet.empty()) {
      bool receiverIsValue = false;
      if (callee && callee->k == NK::Member && !callee->c.empty() && callee->c[0]) {
        auto receiverId = model.expressionIds.find(callee->c[0].get());
        if (receiverId != model.expressionIds.end() && receiverId->second < model.expressions.size()) {
          const Expression &receiver = model.expressions[receiverId->second];
          receiverIsValue = receiver.localBinding != kInvalidLocal ||
              receiver.typeState == ExprTypeState::Known;
        }
      }
      if (ownerId == kInvalidSymbol && !needsMoreTypeInfo && !receiverIsValue) return false;
      expression.call.state = needsMoreTypeInfo ? CallResolutionState::Deferred
                                                : CallResolutionState::UnsupportedMemberCall;
      return true;
    }

    const Declaration &owner = model.symbol(ownerId);
    std::vector<Match> matches;
    bool deferred = false;
    bool constraintFailure = false;
    for (SymbolId id : viableSet) {
      const Declaration &candidate = model.symbol(id);
      int cost = 0;
      bool missingTypeInfo = false;
      bool candidateConstraintFailure = false;
      std::map<std::string, TypeId> substitutions;
      GenericInferenceState genericState = GenericInferenceState::NotGeneric;
      if (genericMethodCost(model, candidate, owner, call, callee,
                            expression.children, ownerArguments, cost,
                            missingTypeInfo, candidateConstraintFailure,
                            substitutions, genericState)) {
        Match match;
        match.symbol = id;
        match.cost = cost;
        match.substitutions = std::move(substitutions);
        match.genericState = genericState;
        if (callee) {
          const std::vector<TypeSpec> *sourceArguments = &callee->explicitTypeArgs;
          if (sourceArguments->empty() && callee->k == NK::Ident &&
              candidate.owner.empty() && !callee->ts.genericArgs.empty())
            sourceArguments = &callee->ts.genericArgs;
          (void)internExplicitGenericArguments(model, candidate.module,
              *sourceArguments, candidate.typeParameters, candidate.sourceNode,
              candidate.genericHasDefault, match.explicitArguments);
        }
        matches.push_back(std::move(match));
      } else {
        deferred = deferred || missingTypeInfo;
        constraintFailure = constraintFailure || candidateConstraintFailure;
      }
    }
    if (deferred) {
      expression.call.state = CallResolutionState::Deferred;
      expression.call.genericState = GenericInferenceState::Deferred;
      return true;
    }
    if (matches.empty()) {
      expression.call.state = CallResolutionState::NoViableCandidate;
      if (constraintFailure)
        expression.call.genericState = GenericInferenceState::ConstraintFailure;
      return true;
    }
    std::sort(matches.begin(), matches.end(), [](const Match &left, const Match &right) {
      return left.cost != right.cost ? left.cost < right.cost : left.symbol < right.symbol;
    });
    if (matches.size() > 1 && matches[0].cost == matches[1].cost) {
      expression.call.state = CallResolutionState::Ambiguous;
      return true;
    }

    const Match &selected = matches.front();
    expression.call.state = CallResolutionState::Resolved;
    expression.call.selected = selected.symbol;
    expression.call.conversionCost = selected.cost;
    expression.call.substitutions = selected.substitutions;
    expression.call.genericState = selected.genericState;
    expression.call.explicitTypeArguments = selected.explicitArguments;

    const Declaration &method = model.symbol(selected.symbol);
    std::set<std::string> genericNames(owner.typeParameters.begin(), owner.typeParameters.end());
    genericNames.insert(method.typeParameters.begin(), method.typeParameters.end());
    TypeId resultType = substituteType(model, method.returnType.type,
                                       selected.substitutions, genericNames);
    if (resultType != kInvalidType) {
      expression.type = resultType;
      expression.typeState = ExprTypeState::Known;
      expression.typeOrigin = ExprTypeOrigin::OverloadResolution;
    }
    return true;
  }

  static void resolveCall(SemanticModel &model, Expression &expression) {
    const Node *call = expression.source;
    if (!call || call->k != NK::Call || call->c.empty() || !call->c[0]) return;
    const Node *callee = call->c[0].get();
    const std::string path = callPath(callee);
    expression.call.calleePath = path;
    if (path.empty()) {
      expression.call.state = CallResolutionState::Deferred;
      return;
    }
    // These fixed contracts are already typed by ExpressionHirBuilder and are
    // not user-overload candidates in this migration phase.
    if (path == "str" || path == "size" || path == "sizeof" ||
        path == "typeOf" || path == "alignof" || path == "fieldCount" ||
        path == "fieldName" || path == "fieldType" || path == "fieldOffset" ||
        path == "strcmp" || path == "math.abs" || path == "math.min" ||
        path == "math.max") return;

    if (callee->k == NK::Member &&
        resolveMethodCall(model, expression, callee, *call)) return;

    if (callee->k == NK::Ident && expression.lexicalScope != kInvalidScope) {
      const LocalSymbolId local = LexicalScopeResolver::lookupForCall(model,
          expression.lexicalScope, callee->s, expression.sourceOrder);
      if (local != kInvalidLocal) {
        expression.call.state = CallResolutionState::LocalCallable;
        return;
      }
    }

    bool qualified = false;
    std::vector<SymbolId> viableSet = candidates(model, expression.module,
                                                 path, qualified);
    expression.call.candidates = viableSet;
    if (viableSet.empty()) {
      expression.call.state = (callee->k == NK::Member && !qualified)
          ? CallResolutionState::UnsupportedMemberCall
          : CallResolutionState::NoCandidates;
      return;
    }

    std::vector<Match> matches;
    bool deferred = false;
    bool constraintFailure = false;
    for (SymbolId id : viableSet) {
      const Declaration &candidate = model.symbol(id);
      int cost = 0;
      bool missingTypeInfo = false;
      bool candidateConstraintFailure = false;
      if (candidate.isGeneric) {
        Declaration noOwner;
        noOwner.module = candidate.module;
        std::map<std::string, TypeId> substitutions;
        GenericInferenceState genericState = GenericInferenceState::NotGeneric;
        if (genericMethodCost(model, candidate, noOwner, *call, callee,
                              expression.children, {}, cost, missingTypeInfo,
                              candidateConstraintFailure, substitutions,
                              genericState, true)) {
          // Prefer a concrete overload over an otherwise-equivalent generic
          // one. Generic inference is still considered when no concrete
          // candidate is a better match.
          cost += 8;
          Match match;
          match.symbol = id;
          match.cost = cost;
          match.substitutions = std::move(substitutions);
          match.genericState = genericState;
          if (callee) {
            const std::vector<TypeSpec> *sourceArguments = &callee->explicitTypeArgs;
            if (sourceArguments->empty() && callee->k == NK::Ident &&
                candidate.owner.empty() && !callee->ts.genericArgs.empty())
              sourceArguments = &callee->ts.genericArgs;
            (void)internExplicitGenericArguments(model, candidate.module,
                *sourceArguments, candidate.typeParameters, candidate.sourceNode,
              candidate.genericHasDefault, match.explicitArguments);
          }
          matches.push_back(std::move(match));
        } else {
          deferred = deferred || missingTypeInfo;
          constraintFailure = constraintFailure || candidateConstraintFailure;
        }
      } else if (candidateCost(model, candidate, *call, expression.children,
                               cost, missingTypeInfo)) {
        Match match;
        match.symbol = id;
        match.cost = cost;
        matches.push_back(std::move(match));
      } else deferred = deferred || missingTypeInfo;
    }
    // If a generic or incompletely typed candidate remains possible, do not
    // select a non-generic overload prematurely; full inference is a later pass.
    if (deferred) {
      expression.call.state = CallResolutionState::Deferred;
      return;
    }
    if (matches.empty()) {
      expression.call.state = CallResolutionState::NoViableCandidate;
      if (constraintFailure)
        expression.call.genericState = GenericInferenceState::ConstraintFailure;
      return;
    }
    std::sort(matches.begin(), matches.end(), [](const Match &a, const Match &b) {
      return a.cost != b.cost ? a.cost < b.cost : a.symbol < b.symbol;
    });
    if (matches.size() > 1 && matches[0].cost == matches[1].cost) {
      expression.call.state = CallResolutionState::Ambiguous;
      return;
    }
    const Match &selectedMatch = matches.front();
    expression.call.state = CallResolutionState::Resolved;
    expression.call.selected = selectedMatch.symbol;
    expression.call.conversionCost = selectedMatch.cost;
    expression.call.substitutions = selectedMatch.substitutions;
    expression.call.genericState = selectedMatch.genericState;
    expression.call.explicitTypeArguments = selectedMatch.explicitArguments;

    const Declaration &selected = model.symbol(expression.call.selected);
    if (selected.isGeneric) {
      const std::set<std::string> genericNames(selected.typeParameters.begin(),
                                               selected.typeParameters.end());
      const TypeId resultType = substituteType(model, selected.returnType.type,
          selectedMatch.substitutions, genericNames);
      if (resultType != kInvalidType) {
        expression.type = resultType;
        expression.typeState = ExprTypeState::Known;
        expression.typeOrigin = ExprTypeOrigin::OverloadResolution;
      }
    } else {
      const TypeId returnType = selected.returnType.type;
      if (returnType != kInvalidType && !selected.returnType.names.empty()) {
        const TypeDescriptor &type = model.types.get(returnType);
        const ResolvedName &resolved = selected.returnType.names.front();
        const bool canonicalType = resolved.kind == NameResolutionKind::Builtin &&
            resolved.canonicalName == type.base;
        if (canonicalType && !(type.category == TypeCategory::Builtin && type.base == "auto") &&
            type.category != TypeCategory::Unknown) {
          expression.type = returnType;
          expression.typeState = ExprTypeState::Known;
          expression.typeOrigin = ExprTypeOrigin::OverloadResolution;
        }
      }
    }
  }
};

class SemanticDiagnosticEngine {
 public:
  void collect(SemanticModel &model) const {
    model.diagnostics.clear();
    SemanticDiagnosticSummary summary;
    for (const Expression &expression : model.expressions) {
      if (!expression.source || expression.source->k != NK::Call ||
          expression.call.candidates.empty()) continue;
      bool hasGenericFreeFunction = false;
      for (SymbolId candidate : expression.call.candidates) {
        if (candidate >= model.declarations.size()) continue;
        const Declaration &declaration = model.symbol(candidate);
        if (declaration.kind == SymbolKind::Function && declaration.owner.empty() &&
            declaration.isGeneric) {
          hasGenericFreeFunction = true;
          break;
        }
      }
      if (!hasGenericFreeFunction) continue;

      SemanticDiagnostic diagnostic;
      diagnostic.location = SourceLocation{expression.file, expression.module, expression.line};
      diagnostic.expression = expression.id;
      switch (expression.call.state) {
        case CallResolutionState::Resolved:
          if (expression.call.genericState != GenericInferenceState::InferredFromArguments)
            continue;
          diagnostic.code = "FAC-HIR-GEN-INFO-001";
          diagnostic.severity = SemanticDiagnosticSeverity::Note;
          diagnostic.message = "generic free-function type arguments inferred from call arguments";
          break;
        case CallResolutionState::Deferred:
          diagnostic.code = "FAC-HIR-GEN-INFO-002";
          diagnostic.severity = SemanticDiagnosticSeverity::Note;
          diagnostic.message = "generic free-function call deferred because type evidence is incomplete";
          break;
        case CallResolutionState::Ambiguous:
          diagnostic.code = "FAC-HIR-SEM-ERROR-001";
          diagnostic.severity = SemanticDiagnosticSeverity::Error;
          diagnostic.message = "generic free-function call is ambiguous among equally ranked candidates";
          break;
        case CallResolutionState::NoViableCandidate:
          diagnostic.code = expression.call.genericState == GenericInferenceState::ConstraintFailure
              ? "FAC-HIR-GEN-ERROR-001" : "FAC-HIR-SEM-ERROR-002";
          diagnostic.severity = SemanticDiagnosticSeverity::Error;
          diagnostic.message = expression.call.genericState == GenericInferenceState::ConstraintFailure
              ? "generic free-function constraints are not satisfied"
              : "no generic free-function candidate accepts the known argument types";
          break;
        default:
          continue;
      }
      switch (diagnostic.severity) {
        case SemanticDiagnosticSeverity::Note: ++summary.notes; break;
        case SemanticDiagnosticSeverity::Warning: ++summary.warnings; break;
        case SemanticDiagnosticSeverity::Error: ++summary.errors; break;
      }
      model.diagnostics.push_back(std::move(diagnostic));
    }
    model.diagnosticSummary = summary;
  }
};

class SemanticAnalyzer {
 public:
  SemanticModel analyze(const std::vector<Program *> &programs) const {
    SemanticModel model;
    model.modules.reserve(programs.size());
    for (const Program *program : programs) {
      if (!program) continue;
      Module module;
      module.name = program->module;
      module.file = program->file;
      module.imports = program->imports;
      module.aliases = program->aliases;
      module.links = program->links;
      module.staticAssertions.reserve(program->staticAssertions.size());
      for (const ::StaticAssertion &assertion : program->staticAssertions)
        module.staticAssertions.push_back({assertion.expr.get(), assertion.message, assertion.line});
      module.importBindings.reserve(program->importSpecs.size());
      for (const ImportSpec &sourceImport : program->importSpecs) {
        ImportBinding binding;
        binding.module = sourceImport.module;
        binding.alias = sourceImport.alias;
        binding.global = sourceImport.global;
        binding.line = sourceImport.line;
        binding.selection = sourceImport.selection;
        binding.names.assign(sourceImport.names.begin(), sourceImport.names.end());
        module.importBindings.push_back(std::move(binding));
      }
      model.modules.push_back(std::move(module));
      Module &targetModule = model.modules.back();

      for (const auto &type : program->structs) {
        if (!type) continue;
        SymbolKind kind = type->isInterface ? SymbolKind::Interface
          : (type->isClass ? SymbolKind::Class : SymbolKind::Struct);
        const SymbolId typeId = addDeclaration(model, targetModule, *program,
                                                type.get(), kind, "");
        Declaration &typeDecl = model.declarations[typeId];
        typeDecl.typeParameters = type->typeParams;
        typeDecl.constTypeParameters = type->constGenericParams;
        typeDecl.genericHasDefault = type->genericHasDefault;
        typeDecl.parentName = type->parent;
        typeDecl.parentType = model.types.use(type->parentType);
        typeDecl.lifetimeParameters = type->lifetimeParams;
        typeDecl.lifetimeOutlives = type->lifetimeOutlives;
        for (const TypeSpec &implemented : type->implTypeSpecs)
          typeDecl.implementedTypes.push_back(model.types.use(implemented));
        for (const auto &fieldNode : type->c) {
          if (!fieldNode || fieldNode->k != NK::VarDecl) continue;
          Field field;
          field.name = fieldNode->s;
          field.type = model.types.use(fieldNode->ts);
          field.location = location(*program, fieldNode->line);
          field.isPublic = fieldNode->isPublic;
          field.isPrivate = fieldNode->isPrivate;
          field.isProtected = fieldNode->isProtected;
          field.isStatic = fieldNode->isStatic;
          field.isConst = fieldNode->isConst;
          typeDecl.fields.push_back(std::move(field));
        }
        for (const auto &methodNode : type->methods) {
          if (!methodNode) continue;
          const SymbolId methodId = addDeclaration(model, targetModule, *program,
                                                   methodNode.get(), SymbolKind::Function,
                                                   type->s);
          model.declarations[typeId].methods.push_back(methodId);
        }
      }

      for (const auto &type : program->enums) {
        if (!type) continue;
        const SymbolId enumId = addDeclaration(model, targetModule, *program,
                                                type.get(), SymbolKind::Enum, "");
        Declaration &enumDecl = model.declarations[enumId];
        enumDecl.typeParameters = type->typeParams;
        for (const EnumMember &member : type->members) {
          EnumVariant variant;
          variant.name = member.name;
          variant.value = member.val;
          variant.stringValue = member.str;
          for (const TypeSpec &payload : member.payloadTypes)
            variant.payload.push_back(model.types.use(payload));
          enumDecl.variants.push_back(std::move(variant));
        }
      }

      for (const auto &function : program->funcs) {
        if (function) addDeclaration(model, targetModule, *program,
                                     function.get(), SymbolKind::Function, "");
      }
      for (const auto &global : program->globals) {
        if (global) addDeclaration(model, targetModule, *program,
                                   global.get(), SymbolKind::Global, "");
      }
    }
    TypeResolver{}.resolve(model);
    ExpressionHirBuilder expressionBuilder;
    expressionBuilder.build(model);
    LexicalScopeResolver scopeResolver;
    scopeResolver.resolve(model);
    expressionBuilder.refine(model);
    OverloadResolver overloadResolver;
    overloadResolver.resolve(model);
    LexicalScopeResolver::refineInferredLocals(model);
    expressionBuilder.refine(model);
    overloadResolver.resolve(model);
    expressionBuilder.refine(model);
    model.typedAst = TypedAstBuilder{}.build(model);
    SemanticDiagnosticEngine{}.collect(model);
    return model;
  }

 private:
  static SourceLocation location(const Program &program, int line) {
    return SourceLocation{program.file, program.module, line};
  }

  static std::string qualifiedName(const std::string &module,
                                   const std::string &owner,
                                   const std::string &name) {
    if (!owner.empty()) return module + "." + owner + "::" + name;
    return module + "." + name;
  }

  static SymbolId addDeclaration(SemanticModel &model, Module &module,
                                 const Program &program, const Node *node,
                                 SymbolKind kind, const std::string &owner) {
    if (model.declarations.size() >= static_cast<size_t>(kInvalidSymbol))
      throw std::overflow_error("FAC HIR symbol table exhausted SymbolId space");
    Declaration declaration;
    declaration.id = static_cast<SymbolId>(model.declarations.size());
    declaration.sourceNode = node;
    declaration.kind = kind;
    declaration.module = program.module;
    declaration.owner = owner;
    declaration.name = node->s;
    declaration.qualifiedName = qualifiedName(program.module, owner, node->s);
    declaration.location = location(program, node->line);
    declaration.isPublic = node->isPublic;
    declaration.isPrivate = node->isPrivate;
    declaration.isProtected = node->isProtected;
    declaration.isStatic = node->isStatic;
    declaration.isConst = node->isConst;
    declaration.isUnsafe = node->isUnsafe;
    declaration.isExtern = node->isExtern;
    declaration.isExport = node->isExport;
    declaration.isAbstract = node->isAbstract;
    declaration.isFinal = node->isFinal;
    declaration.isClass = node->isClass;
    declaration.isInterface = node->isInterface;
    declaration.isConstructor = node->isConstructor;
    declaration.isDestructor = node->isDestructor;
    declaration.isGeneric = !node->typeParams.empty() || node->ts.base == "auto";
    declaration.typeParameters = node->typeParams;
    declaration.constTypeParameters = node->constGenericParams;
    declaration.genericHasDefault = node->genericHasDefault;
    declaration.lifetimeParameters = node->lifetimeParams;
    declaration.lifetimeOutlives = node->lifetimeOutlives;
    for (const GenericBound &bound : node->genericBounds) {
      const bool isConst = std::find(node->constGenericParams.begin(), node->constGenericParams.end(), bound.param) != node->constGenericParams.end();
      if (isConst) declaration.genericBounds.push_back({bound.param, {}, bound.bound.base, true});
      else declaration.genericBounds.push_back({bound.param, model.types.use(bound.bound), {}, false});
    }

    if (kind == SymbolKind::Function) {
      declaration.returnType = model.types.use(node->ts);
      declaration.parameters.reserve(node->params.size());
      for (const Param &param : node->params) {
        Parameter lowered;
        lowered.name = param.name;
        lowered.type = model.types.use(param.ts);
        lowered.ref = param.ref;
        lowered.immutableRef = param.immutableRef;
        lowered.variadic = param.variadic;
        lowered.noescape = param.noescape;
        lowered.readonly = param.readonly;
        lowered.hasDefault = static_cast<bool>(param.def);
        declaration.parameters.push_back(std::move(lowered));
        if (param.ts.base == "auto") declaration.isGeneric = true;
      }
    } else if (kind == SymbolKind::Global) {
      declaration.declaredType = model.types.use(node->ts);
    }

    const SymbolId id = declaration.id;
    model.declarations.push_back(std::move(declaration));
    module.declarations.push_back(id);
    model.symbolsByQualifiedName[model.declarations.back().qualifiedName].push_back(id);
    return id;
  }
};

inline SemanticModel analyze(const std::vector<Program *> &programs) {
  return SemanticAnalyzer{}.analyze(programs);
}

}  // namespace fac_hir
