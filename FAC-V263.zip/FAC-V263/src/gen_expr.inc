// ---- (included inside class Gen) expressions ----

bool isModuleName(const std::string &n) {
  if (findVar(n)) return false;
  if (builtinModules.count(n) || userModules.count(n)) return true;
  return modImportAliases[curModule].count(n) != 0;
}
bool flatten(Node *n, std::string &out) {
  if (n->k == NK::Ident) { out = n->s; return true; }
  if (n->k == NK::Member && flatten(n->c[0].get(), out)) { out += "." + n->s; return true; }
  return false;
}
std::string rootIdent(Node *n) {
  while (n->k == NK::Member || n->k == NK::Index || n->k == NK::Deref || n->k == NK::Slice) n = n->c[0].get();
  return n->k == NK::Ident ? n->s : "";
}
bool isLvalNode(Node *n) { return n->k == NK::Ident || n->k == NK::Member || n->k == NK::Index || n->k == NK::Deref; }

// Convert an i64 two's-complement bit pattern without relying on an
// implementation-defined uint64_t -> int64_t narrowing conversion.
int64_t constFromBits(uint64_t bits) {
  if (bits <= (uint64_t)INT64_MAX) return (int64_t)bits;
  return -1 - (int64_t)(~bits);
}

bool isStructuralReflectionName(const std::string &name) {
  return name == "fieldCount" || name == "fieldName" ||
         name == "fieldType" || name == "fieldOffset";
}

bool isTypeQueryName(const std::string &name) {
  return name == "typeOf" || name == "sizeof" || name == "alignof" ||
         isStructuralReflectionName(name);
}

const std::vector<TypeSpec> *typeQueryArguments(Node *call) {
  if (!call || call->k != NK::Call || call->c.empty()) return nullptr;
  Node *callee = call->c[0].get();
  if (!callee || callee->k != NK::Ident || !isTypeQueryName(callee->s)) return nullptr;
  if (!callee->explicitTypeArgs.empty()) return &callee->explicitTypeArgs;
  // Compile-time type/layout/field queries embedded in a deferred const-generic
  // expression are not visited by normalizeNode until their owner is materialized.
  // Accept the parser's original storage as well as the normalized call form.
  if (!callee->ts.genericArgs.empty()) return &callee->ts.genericArgs;
  return nullptr;
}

std::string typeQueryCategory(const T &input) {
  if (!input) return "None";
  T type = input;
  // Match the established typeof(value) convention: array/list type queries
  // classify their element type. Container layout is queried separately.
  if (type->k == ARR || type->k == LIST) type = type->el;
  switch (type->k) {
    case INT:
      if (type->bits == 8) return type->sg ? "Byte" : "Ubyte";
      if (type->bits == 16) return type->sg ? "Short" : "Ushort";
      if (type->bits == 32) return type->sg ? "Int" : "Uint";
      return type->sg ? "Long" : "Ulong";
    case F32: return "Float";
    case F64: return "Double";
    case BOOL: return "Boolean";
    case CHAR: return "Char";
    case UNI: return "Unichar";
    case STR: return "String";
    case PTR: case OPAQUE: return "Ptr";
    case STRUCT: return "Struct";
    case ENUM: return "Enum";
    default: return "None";
  }
}

int typeQueryCategoryValue(const std::string &category) {
  // Type is a compiler-provided enum whose declaration order is part of the
  // existing language API. This fixed table is also available while generic
  // const arguments are normalized before built-in enums are registered.
  static const std::vector<std::string> categories = {
    "Byte", "Short", "Int", "Long", "Ubyte", "Ushort", "Uint", "Ulong",
    "Float", "Double", "Boolean", "Char", "Unichar", "String", "Ptr",
    "Struct", "Enum", "None"
  };
  for (size_t i = 0; i < categories.size(); ++i)
    if (categories[i] == category) return static_cast<int>(i);
  return -1;
}

bool resolveTypeQueryTarget(Node *call, T &target) {
  const std::vector<TypeSpec> *arguments = typeQueryArguments(call);
  if (!arguments || arguments->size() != 1 || call->c.size() != 1) return false;
  const TypeSpec &argument = arguments->front();
  if (argument.isConstValue || argument.constExpr || !argument.genericArgName.empty()) return false;
  target = resolveType(argument, call->line);
  return target != nullptr;
}

bool resolveReflectionTarget(Node *call, T &target, StructInfo *&record,
                             int64_t &visibleIndex, bool &hasIndex) {
  if (!call || call->c.size() != 1 || call->c[0]->k != NK::Ident) return false;
  const std::string &name = call->c[0]->s;
  const std::vector<TypeSpec> *arguments = typeQueryArguments(call);
  const bool needsIndex = name == "fieldName" || name == "fieldType" || name == "fieldOffset";
  if (!isStructuralReflectionName(name) || !arguments ||
      arguments->size() != (needsIndex ? 2u : 1u)) return false;
  const TypeSpec &typeArgument = arguments->front();
  if (typeArgument.isConstValue || typeArgument.constExpr ||
      !typeArgument.genericArgName.empty()) return false;
  target = resolveType(typeArgument, call->line);
  if (!target || (target->k != STRUCT && target->k != OBJ)) return false;
  auto found = structs.find(target->name);
  if (found == structs.end() || !found->second.resolved || found->second.isInterface)
    return false;
  record = &found->second;
  hasIndex = needsIndex;
  visibleIndex = 0;
  if (needsIndex) {
    const TypeSpec &indexArgument = (*arguments)[1];
    if (!indexArgument.genericArgName.empty()) return false;
    if (indexArgument.isConstValue) visibleIndex = indexArgument.constValue;
    else if (indexArgument.constExpr) {
      if (!constEval(indexArgument.constExpr.get(), visibleIndex)) return false;
    } else return false;
    if (visibleIndex < 0) return false;
  }
  return true;
}

std::vector<size_t> publicReflectionFieldIndices(const StructInfo &record) {
  std::vector<size_t> indices;
  indices.reserve(record.fields.size());
  for (size_t i = 0; i < record.fields.size(); ++i)
    if (record.fields[i].isPublic && !record.fields[i].isStatic) indices.push_back(i);
  return indices;
}

size_t checkedReflectionFieldIndex(const StructInfo &record, int64_t visibleIndex,
                                   int line, const std::string &query) {
  const std::vector<size_t> visible = publicReflectionFieldIndices(record);
  if (visibleIndex < 0 || static_cast<uint64_t>(visibleIndex) >= visible.size())
    err(query + " index " + std::to_string(visibleIndex) + " อยู่นอกช่วง public instance fields ของ " + record.name,
        line);
  return visible[static_cast<size_t>(visibleIndex)];
}

int64_t reflectedFieldOffset(const StructInfo &record, size_t actualIndex, int line) {
  int64_t offset = 0;
  for (size_t i = 0; i < record.fields.size(); ++i) {
    const FieldInfo &field = record.fields[i];
    const int64_t alignment = alignOf(field.ty);
    const int64_t size = sizeOf(field.ty);
    if (alignment <= 0 || size < 0) err("field layout ไม่ถูกต้องใน " + record.name, line);
    offset = ((offset + alignment - 1) / alignment) * alignment;
    if (i == actualIndex) return offset;
    if (__builtin_add_overflow(offset, size, &offset) || offset > kMaxObjBytes)
      err("field offset เกินขนาดที่รองรับใน " + record.name, line);
  }
  err("internal reflection field index invalid for " + record.name, line);
}

bool constEvalTypeQuery(Node *call, int64_t &out) {
  if (!call || call->c.empty() || call->c[0]->k != NK::Ident) return false;
  const std::string &name = call->c[0]->s;
  if (!isTypeQueryName(name)) return false;
  if (isStructuralReflectionName(name)) {
    if (name == "fieldName") return false; // string literals are materialized by expr(), not scalar consteval
    T target;
    StructInfo *record = nullptr;
    int64_t visibleIndex = 0;
    bool hasIndex = false;
    if (!resolveReflectionTarget(call, target, record, visibleIndex, hasIndex)) return false;
    const std::vector<size_t> visible = publicReflectionFieldIndices(*record);
    if (name == "fieldCount") {
      out = static_cast<int64_t>(visible.size());
      return true;
    }
    const size_t actualIndex = checkedReflectionFieldIndex(*record, visibleIndex, call->line, name);
    if (name == "fieldType") {
      out = typeQueryCategoryValue(typeQueryCategory(record->fields[actualIndex].ty));
      return out >= 0;
    }
    if (name == "fieldOffset") {
      out = reflectedFieldOffset(*record, actualIndex, call->line);
      return true;
    }
    return false;
  }
  T target;
  if (!resolveTypeQueryTarget(call, target)) return false;
  if (name == "typeOf") {
    out = typeQueryCategoryValue(typeQueryCategory(target));
    return out >= 0;
  }
  if (!target || target->k == VOID || target->k == AUTOT || target->k == NULLT ||
      target->k == TUPLE || target->k == FUNC)
    return false;
  if (name == "sizeof" && target->k == ARR) return false; // incomplete array type has no fixed object size
  if (target->k == STRUCT) {
    auto it = structs.find(target->name);
    // During early generic normalization record field layouts may not yet be
    // resolved. Do not observe the temporary empty-field placeholder as size 0.
    if (it == structs.end() || !it->second.resolved) return false;
  }
  out = name == "sizeof" ? sizeOf(target) : alignOf(target);
  return out > 0;
}

bool fitsConstEvalValue(int64_t value, const T &type) {
  if (!type || !isIntLike(type)) return false;
  if (type->k == BOOL) return value == 0 || value == 1;
  if (type->k == CHAR) return value >= 0 && value <= 255;
  if (type->k == UNI) return value >= 0 && value <= INT64_C(0xFFFFFFFF);
  if (type->k == ENUM) return value >= 0 && value <= INT32_MAX;
  const int bits = bitsOf(type);
  if (bits <= 0) return false;
  if (signedOf(type)) {
    if (bits == 64) return true;
    const int64_t hi = (INT64_C(1) << (bits - 1)) - 1;
    const int64_t lo = -(INT64_C(1) << (bits - 1));
    return value >= lo && value <= hi;
  }
  if (value < 0) return false;
  if (bits == 64) return true; // the evaluator's value domain is signed int64
  return (uint64_t)value <= ((UINT64_C(1) << bits) - 1);
}

FuncInfo *findConstevalFunction(Node *call, const std::string &fromModule) {
  if (!call || call->k != NK::Call || call->c.empty()) return nullptr;
  std::string path;
  if (!flatten(call->c[0].get(), path)) return nullptr;
  std::string owner = fromModule;
  std::string functionName = path;
  const size_t dot = path.rfind('.');
  if (dot != std::string::npos) {
    owner = path.substr(0, dot);
    functionName = path.substr(dot + 1);
    auto aliases = modImportAliases.find(fromModule);
    if (aliases != modImportAliases.end()) {
      auto alias = aliases->second.find(owner);
      if (alias != aliases->second.end()) owner = alias->second;
    }
  }
  if (owner != fromModule) {
    auto imports = modImports.find(fromModule);
    if (imports == modImports.end() || !imports->second.count(owner)) return nullptr;
    auto just = modImportJust.find(fromModule);
    if (just != modImportJust.end()) {
      auto selected = just->second.find(owner);
      if (selected != just->second.end() && !selected->second.count(functionName)) return nullptr;
    }
    auto without = modImportWithout.find(fromModule);
    if (without != modImportWithout.end()) {
      auto excluded = without->second.find(owner);
      if (excluded != without->second.end() && excluded->second.count(functionName)) return nullptr;
    }
  }
  const std::string key = owner + "." + functionName;
  auto it = funcs.find(key);
  if (it == funcs.end() || !it->second.isConsteval || !it->second.node) return nullptr;
  if (owner != fromModule && !it->second.node->isPublic) return nullptr;
  if (overloads.count(key)) return nullptr;
  return &it->second;
}

bool constEvalLookupLocal(const ConstEvalFrame &frame, const std::string &name,
                          ConstEvalVariable *&value) {
  for (size_t i = frame.scopes.size(); i > 0; --i) {
    auto it = frame.scopes[i - 1].find(name);
    if (it != frame.scopes[i - 1].end()) { value = const_cast<ConstEvalVariable *>(&it->second); return true; }
  }
  value = nullptr;
  return false;
}

bool constEvalApplyBinary(const std::string &op, int64_t a, int64_t b, int64_t &out) {
  if (op == "+") { if (__builtin_add_overflow(a, b, &out)) return false; }
  else if (op == "-") { if (__builtin_sub_overflow(a, b, &out)) return false; }
  else if (op == "*") { if (__builtin_mul_overflow(a, b, &out)) return false; }
  else if (op == "/" || op == "%") { if (b == 0 || (a == INT64_MIN && b == -1)) return false; out = op == "/" ? a / b : a % b; }
  else if (op == "<<") { if (b < 0 || b > 63) return false; out = constFromBits((uint64_t)a << (unsigned)b); }
  else if (op == ">>") {
    if (b < 0 || b > 63) return false;
    if (b == 0) out = a;
    else if (a >= 0) out = (int64_t)((uint64_t)a >> (unsigned)b);
    else {
      const uint64_t magnitude = (uint64_t)(-(a + 1)) + 1u;
      const uint64_t divisorMask = (UINT64_C(1) << (unsigned)b) - 1u;
      uint64_t quotient = magnitude >> (unsigned)b;
      if ((magnitude & divisorMask) != 0) ++quotient;
      out = quotient == (UINT64_C(1) << 63) ? INT64_MIN : -(int64_t)quotient;
    }
  }
  else if (op == "&") out = constFromBits((uint64_t)a & (uint64_t)b);
  else if (op == "|") out = constFromBits((uint64_t)a | (uint64_t)b);
  else if (op == "^") out = constFromBits((uint64_t)a ^ (uint64_t)b);
  else if (op == "==") out = a == b;
  else if (op == "!=") out = a != b;
  else if (op == "<") out = a < b;
  else if (op == "<=") out = a <= b;
  else if (op == ">") out = a > b;
  else if (op == ">=") out = a >= b;
  else if (op == "&&") out = (a != 0) && (b != 0);
  else if (op == "||") out = (a != 0) || (b != 0);
  else return false;
  return true;
}

bool constEvalCall(Node *call, int64_t &out, ConstEvalFrame &caller,
                   ConstEvalState &state, unsigned depth) {
  if (depth >= 64 || state.callStack.size() >= 64 || ++state.steps > 100000) return false;
  FuncInfo *function = findConstevalFunction(call, caller.module);
  if (!function || !function->node || call->c.size() - 1 != function->pt.size()) return false;
  const std::string identity = function->module + "." + function->name;
  ConstEvalFrame callee; callee.module = function->module; callee.scopes.emplace_back();
  for (size_t i = 0; i < function->pt.size(); ++i) {
    if (!function->pt[i] || !isIntLike(function->pt[i])) return false;
    int64_t value = 0;
    if (!constEvalExpression(call->c[i + 1].get(), value, caller, state, depth + 1) ||
        !fitsConstEvalValue(value, function->pt[i])) return false;
    const Param &parameter = function->node->params[i];
    callee.scopes.back().emplace(parameter.name, ConstEvalVariable{value, false});
  }
  if (function->node->c.empty() || !function->node->c[0] || function->node->c[0]->k != NK::Block)
    return false;
  state.callStack.push_back(identity);
  bool returned = false;
  int64_t returnValue = 0;
  const bool ok = constEvalStatement(function->node->c[0].get(), callee, state,
                                     returned, returnValue, depth + 1);
  state.callStack.pop_back();
  if (!ok || !returned || !fitsConstEvalValue(returnValue, function->ret)) return false;
  out = returnValue;
  return true;
}

bool constEvalExpression(Node *n, int64_t &out, ConstEvalFrame &frame,
                         ConstEvalState &state, unsigned depth) {
  if (!n || depth >= 64 || ++state.steps > 100000) return false;
  switch (n->k) {
    case NK::IntLit: case NK::CharLit: out = n->iv; return true;
    case NK::BoolLit: out = n->b ? 1 : 0; return true;
    case NK::Ident: {
      ConstEvalVariable *local = nullptr;
      if (constEvalLookupLocal(frame, n->s, local)) { out = local->value; return true; }
      auto global = constGlobals.find(frame.module + "." + n->s);
      if (global == constGlobals.end()) return false;
      out = global->second; return true;
    }
    case NK::Member: {
      if (!n->c.empty() && n->c[0]->k == NK::Ident) {
        auto it = enums.find(n->c[0]->s);
        if (it != enums.end()) {
          for (size_t i = 0; i < it->second.mem.size(); ++i)
            if (it->second.mem[i].name == n->s) { out = (int64_t)i; return true; }
        }
      }
      return false;
    }
    case NK::Unary: {
      if (n->c.empty()) return false;
      if (n->s == "++" || n->s == "--") {
        Node *target = n->c[0].get();
        if (!target || target->k != NK::Ident) return false;
        ConstEvalVariable *local = nullptr;
        if (!constEvalLookupLocal(frame, target->s, local) || local->isConst) return false;
        int64_t next = 0;
        if (!constEvalApplyBinary(n->s == "++" ? "+" : "-", local->value, 1, next)) return false;
        local->value = next; out = next; return true;
      }
      int64_t x = 0;
      if (!constEvalExpression(n->c[0].get(), x, frame, state, depth + 1)) return false;
      if (n->s == "+") { out = x; return true; }
      if (n->s == "-") { if (x == INT64_MIN) return false; out = -x; return true; }
      if (n->s == "!") { out = !x; return true; }
      if (n->s == "~") { out = constFromBits(~(uint64_t)x); return true; }
      return false;
    }
    case NK::PostInc: {
      if (n->c.empty() || !n->c[0] || n->c[0]->k != NK::Ident) return false;
      ConstEvalVariable *local = nullptr;
      if (!constEvalLookupLocal(frame, n->c[0]->s, local) || local->isConst) return false;
      out = local->value;
      int64_t next = 0;
      if (!constEvalApplyBinary(n->s == "++" ? "+" : "-", local->value, 1, next)) return false;
      local->value = next; return true;
    }
    case NK::Binary: {
      if (n->c.size() < 2) return false;
      int64_t left = 0, right = 0;
      if (!constEvalExpression(n->c[0].get(), left, frame, state, depth + 1)) return false;
      if (n->s == "&&" && !left) { out = 0; return true; }
      if (n->s == "||" && left) { out = 1; return true; }
      if (!constEvalExpression(n->c[1].get(), right, frame, state, depth + 1)) return false;
      return constEvalApplyBinary(n->s, left, right, out);
    }
    case NK::Assign: {
      if (n->c.size() != 2 || !n->c[0] || n->c[0]->k != NK::Ident) return false;
      ConstEvalVariable *local = nullptr;
      if (!constEvalLookupLocal(frame, n->c[0]->s, local) || local->isConst) return false;
      int64_t rhs = 0;
      if (!constEvalExpression(n->c[1].get(), rhs, frame, state, depth + 1)) return false;
      int64_t value = rhs;
      if (n->s != "=") {
        std::string op = n->s.substr(0, n->s.size() - 1);
        if (!constEvalApplyBinary(op, local->value, rhs, value)) return false;
      }
      local->value = value; out = value; return true;
    }
    case NK::Call:
      if (constEvalTypeQuery(n, out)) return true;
      return constEvalCall(n, out, frame, state, depth + 1);
    default: return false;
  }
}

bool constEvalStatement(Node *n, ConstEvalFrame &frame, ConstEvalState &state,
                        bool &returned, int64_t &returnValue, unsigned depth) {
  if (!n || depth >= 64 || ++state.steps > 100000 || returned) return false;
  switch (n->k) {
    case NK::Block: {
      frame.scopes.emplace_back();
      bool ok = true;
      for (const auto &child : n->c) {
        if (returned) break;
        if (!constEvalStatement(child.get(), frame, state, returned, returnValue, depth + 1)) { ok = false; break; }
      }
      frame.scopes.pop_back();
      return ok;
    }
    case NK::VarDecl: {
      if (!n->ts.cat.empty() || n->ts.kind == "ptr" || n->ts.kind == "dyn" ||
          n->ts.kind == "heap" || !isIntLike(baseType(n->ts.base, n->line)) ||
          n->c.size() != 1 || frame.scopes.empty()) return false;
      int64_t value = 0;
      if (!constEvalExpression(n->c[0].get(), value, frame, state, depth + 1)) return false;
      T declaredType = baseType(n->ts.base, n->line);
      if (!fitsConstEvalValue(value, declaredType)) return false;
      auto &scope = frame.scopes.back();
      if (scope.count(n->s)) return false;
      scope.emplace(n->s, ConstEvalVariable{value, n->isConst});
      return true;
    }
    case NK::If: {
      if (n->b || n->c.size() < 2) return false;
      int64_t condition = 0;
      if (!constEvalExpression(n->c[0].get(), condition, frame, state, depth + 1)) return false;
      Node *branch = condition ? n->c[1].get() : (n->c.size() > 2 ? n->c[2].get() : nullptr);
      if (!branch) return true;
      return constEvalStatement(branch, frame, state, returned, returnValue, depth + 1);
    }
    case NK::Return:
      if (n->c.size() != 1 || !constEvalExpression(n->c[0].get(), returnValue, frame, state, depth + 1)) return false;
      returned = true; return true;
    case NK::ExprStmt: {
      if (n->c.size() != 1) return false;
      int64_t ignored = 0;
      return constEvalExpression(n->c[0].get(), ignored, frame, state, depth + 1);
    }
    default: return false; // loops, I/O, FFI, exceptions and aggregate mutation are outside V220 consteval
  }
}

bool constEval(Node *n, int64_t &out) {
  ConstEvalFrame frame; frame.module = curModule; frame.scopes.emplace_back();
  ConstEvalState state;
  return constEvalExpression(n, out, frame, state, 0);
}

T dryType(Node *n) {
  if (n->k == NK::InitList) return tArr(T_int, -1);
  if (n->k == NK::Lambda) return tFunc(T_void, {});
  return dryExpr(n).t;
}

V lambdaExpr(Node *n) {
  FuncInfo fi; fi.name = "lambda"; fi.module = curModule; fi.node = n;
  fi.sym = "@fac." + curModule + ".lambda" + std::to_string(++nlam);
  T hint = lamExpect; lamExpect = nullptr;
  if (!n->ts.base.empty()) fi.ret = n->ts.base == "void" ? T_void : baseType(n->ts.base, n->line);
  else if (hint && hint->k == FUNC) fi.ret = hint->el;
  else if (lambdaReturnsValue(n->c[0].get())) err("lambda ต้องระบุ return type เช่น function int(int a) {...} หรือกำหนดให้ตัวแปรที่ระบุชนิด", n->line);
  else fi.ret = T_void;
  for (auto &p : n->params) {
    T pt = resolveType(p.ts, n->line);
    if (p.ts.cat.empty() && p.ts.kind == "ptr") pt = tPtr(baseType(p.ts.base, n->line));
    fi.pt.push_back(pt); fi.pref.push_back(p.ref); fi.pn.push_back(p.name); fi.pdef.push_back(p.def.get()); fi.pnoescape.push_back(p.noescape); fi.preadonly.push_back(p.readonly);
    if (p.variadic) fi.variadic = true;
  }
  // ---- จับ (capture) ตัวแปรภายนอกแบบ "by value": copy ค่า ณ ตอนสร้าง lambda ไว้ใน closure (แก้ค่าใน lambda ไม่กระทบตัวเดิม)
  {
    std::set<std::string> pnames, declared, used;
    for (auto &p : n->params) pnames.insert(p.name);
    collectDecls(n->c[0].get(), declared); collectIdents(n->c[0].get(), used);
    for (auto &p : n->params) if (p.def) collectIdents(p.def.get(), used);
    for (auto &nm : used) {
      if (pnames.count(nm) || declared.count(nm)) continue;
      Var *v = findLocal(nm); if (!v) continue;
      TK k = v->ty->k;
      if (!opt.captureWrite) {
        std::string how = captureWrite(n->c[0].get(), nm, k);
        if (!how.empty())
          err("lambda " + how + " ตัวแปร '" + nm + "' ที่จับมา: lambda จับตัวแปรตามค่า (สำเนา) การเขียนจึงไม่กระทบตัวแปรเดิม — ใช้ตัวแปร global, ptr หรือ field ของ object เพื่อแชร์สถานะ "
              "(ถ้าตั้งใจให้ closure มีสถานะส่วนตัวของตัวเอง ใช้ --allow-capture-write)", n->line);
      }
      if (!(isNum(v->ty) || k == PTR || k == OPAQUE || k == FUNC || k == STR || k == LIST || k == DSK || k == STRUCT || k == OBJ || k == WEAK))
        err("lambda จับตัวแปร '" + nm + "' ชนิด " + tname(v->ty) + " ยังไม่ได้ (จับได้: ตัวเลข/boolean/char/enum/ptr/string/function/list/dataset/struct)", n->line);
      fi.caps.push_back({nm, v->ty});
    }
    fi.envTy = "{ ptr, i64, ptr";
    for (auto &c : fi.caps) fi.envTy += ", " + llty(c.ty);
    fi.envTy += " }";
    fi.isLambda = true;
  }
  lambdas.push_back(fi);
  V r; r.t = tFunc(fi.ret, fi.pt, fi.pnoescape, fi.preadonly); setFunctionLifetimeContract(r.t, n);
  if (fi.caps.empty()) { r.v = closureConst(fi.sym); return r; }
  int64_t off = 24, al = 8;
  for (auto &c : fi.caps) { int64_t a = alignOf(c.ty), z = sizeOf(c.ty); off = (off + a - 1) / a * a + z; al = std::max(al, a); }
  int64_t size = (off + al - 1) / al * al;
  std::string clo = def("call ptr @fac_alloc(i64 " + std::to_string(size) + ")");
  ins("store ptr " + fi.sym + ", ptr " + clo);
  std::string rcptr = def("getelementptr inbounds " + fi.envTy + ", ptr " + clo + ", i32 0, i32 1");
  ins("store i64 1, ptr " + rcptr);
  bool hasManagedCaps = false;
  for (auto &cap : fi.caps) if (cap.ty->k == STR || cap.ty->k == LIST || cap.ty->k == DSK || cap.ty->k == FUNC || cap.ty->k == STRUCT || cap.ty->k == OBJ || cap.ty->k == WEAK) hasManagedCaps = true;
  std::string dropSym = "@dropclo" + fi.sym.substr(1);
  std::string dtorVal = "null";
  if (hasManagedCaps) {
    dtorVal = dropSym;
    std::string df = "define internal void " + dropSym + "(ptr %env) nounwind {\nentry:\n";
    for (size_t j = 0; j < fi.caps.size(); j++) {
      TK ck = fi.caps[j].ty->k;
      if (ck != STR && ck != LIST && ck != DSK && ck != FUNC && ck != STRUCT && ck != OBJ && ck != WEAK) continue;
      std::string cp = "%dp" + std::to_string(j), cv = "%dv" + std::to_string(j);
      df += "  " + cp + " = getelementptr inbounds " + fi.envTy + ", ptr %env, i32 0, i32 " + std::to_string(j + 3) + "\n";
      df += "  " + cv + " = load ptr, ptr " + cp + "\n";
      if (ck == STRUCT) df += "  call void @drop." + fi.caps[j].ty->name + "(ptr " + cp + ")\n";
      else { const char *fn = ck == STR ? "fac_str_free" : ck == LIST ? "fac_list_free" : ck == DSK ? "fac_ds_free" : ck == OBJ ? "fac_obj_release" : ck == WEAK ? "fac_obj_weak_release" : "fac_closure_release"; df += "  call void @" + std::string(fn) + "(ptr " + cv + ")\n"; }
    }
    df += "  ret void\n}\n\n";
    globals += df;
  }
  std::string dptr = def("getelementptr inbounds " + fi.envTy + ", ptr " + clo + ", i32 0, i32 2");
  ins("store ptr " + dtorVal + ", ptr " + dptr);
  for (size_t i = 0; i < fi.caps.size(); i++) {
    Var *v = findLocal(fi.caps[i].name);
    std::string val = def("load " + llty(fi.caps[i].ty) + ", ptr " + varAddr(*v));
    if (fi.caps[i].ty->k == STR) val = def("call ptr @fac_str_dup(ptr " + val + ")");
    else if (fi.caps[i].ty->k == LIST) val = def("call ptr @fac_list_copy(ptr " + val + ")");
    else if (fi.caps[i].ty->k == DSK) val = def("call ptr @fac_ds_copy(ptr " + val + ")");
    else if (fi.caps[i].ty->k == FUNC) ins("call void @fac_closure_retain(ptr " + val + ")");
    else if (fi.caps[i].ty->k == OBJ) ins("call void @fac_obj_retain(ptr " + val + ")");
    else if (fi.caps[i].ty->k == WEAK) ins("call void @fac_obj_weak_retain(ptr " + val + ")");   // object แชร์โดยอ้างอิง: lambda ถือ 1 reference
    std::string p = def("getelementptr inbounds " + fi.envTy + ", ptr " + clo + ", i32 0, i32 " + std::to_string(i + 3));
    if (fi.caps[i].ty->k == STRUCT) ins("call void @copy." + fi.caps[i].ty->name + "(ptr " + p + ", ptr " + varAddr(*v) + ")");
    else ins("store " + llty(fi.caps[i].ty) + " " + val + ", ptr " + p);
  }
  r.v = clo; r.owned = true; return r;
}
// lambda เขียนตัวแปร nm (ชนิด k) ที่จับมาหรือไม่: คืนคำอธิบายการเขียน ("" = ไม่เขียน)
// เขียนผ่านการอ้างอิง (field ของ obj, *ptr) ไม่นับ เพราะกระทบตัวจริงตามที่ผู้เขียนตั้งใจ
std::string captureWrite(Node *n, const std::string &nm, TK k) {
  if (!n) return "";
  bool viaRef = (k == OBJ || k == PTR);
  auto target = [&](Node *t) -> std::string { return rootIdent(t) == nm ? (t->k == NK::Ident ? "เขียนทับ" : (viaRef ? "" : "แก้ค่าภายใน")) : ""; };
  if (n->k == NK::Assign) { std::string w = target(n->c[0].get()); if (!w.empty()) return w; }
  if ((n->k == NK::Unary && (n->s == "++" || n->s == "--")) || n->k == NK::PostInc) { std::string w = target(n->c[0].get()); if (!w.empty()) return w; }
  if (n->k == NK::Call && !n->c.empty() && n->c[0]->k == NK::Member && n->c[0]->c[0]->k == NK::Ident && n->c[0]->c[0]->s == nm) {
    const std::string &m = n->c[0]->s;
    if (k == LIST && (m == "add" || m == "insert" || m == "set" || m == "remove" || m == "clear" || m == "reserve" || m == "shrink")) return "แก้ค่าภายใน (." + m + "())";
    if (k == DSK && m == "clear") return "แก้ค่าภายใน (.clear())";
  }
  if (n->k == NK::Call && !n->c.empty() && n->c[0]->k == NK::Ident && (n->c[0]->s == "sort" || n->c[0]->s == "reverse" || n->c[0]->s == "fill") && n->c.size() > 1 && rootIdent(n->c[1].get()) == nm && !viaRef) return "แก้ค่าภายใน (" + n->c[0]->s + ")";
  for (auto &c : n->c) { std::string w = captureWrite(c.get(), nm, k); if (!w.empty()) return w; }
  for (auto &cs : n->cases) {
    for (auto &v : cs.vals) { std::string w = captureWrite(v.get(), nm, k); if (!w.empty()) return w; }
    for (auto &r : cs.ranges) { std::string w = captureWrite(r.lo.get(), nm, k); if (!w.empty()) return w; w = captureWrite(r.hi.get(), nm, k); if (!w.empty()) return w; }
    std::string w = captureWrite(cs.guard.get(), nm, k); if (!w.empty()) return w;
    w = captureWrite(cs.body.get(), nm, k); if (!w.empty()) return w;
    w = captureWrite(cs.exprBody.get(), nm, k); if (!w.empty()) return w;
  }
  return captureWrite(n->deflt.get(), nm, k);
}
void collectCalls(Node *n, std::vector<Node *> &out) {
  if (!n) return;
  if (n->k == NK::Call || n->k == NK::New) out.push_back(n);
  for (auto &c : n->c) collectCalls(c.get(), out);
  for (auto &cs : n->cases) {
    for (auto &v : cs.vals) collectCalls(v.get(), out);
    for (auto &r : cs.ranges) { collectCalls(r.lo.get(), out); collectCalls(r.hi.get(), out); }
    collectCalls(cs.guard.get(), out); collectCalls(cs.body.get(), out); collectCalls(cs.exprBody.get(), out);
  }
  collectCalls(n->deflt.get(), out);
  for (auto &p : n->params) if (p.def) collectCalls(p.def.get(), out);
}
// ---- --safe: thread isolation (กัน data race). closure ที่ส่งเข้า thread.start / thread.parallelFor ต้อง "แยกขาด":
//   (1) จับได้เฉพาะค่าที่ถูกคัดลอก -- ห้าม ptr/opaque/weak/function และ obj (ยกเว้น class ใน module sync ที่ตรวจสอบแล้ว)
//   (2) ตัว closure และฟังก์ชัน (ที่เรียกตามชื่อ) ที่มันเรียกต่อ ห้ามแตะตัวแปร global ที่แก้ค่าได้
//   ตามเข้า: ฟังก์ชันที่เรียกตามชื่อ, method ทุกตัวที่ชื่อตรงกับ method call (รวม virtual), constructor/destructor ของ new X(); ไม่ตามเข้า function value / dyn (ดู docs/SAFETY.md)
std::string sharedCapProblem(const FuncInfo &lam) {
  for (auto &c : lam.caps) {
    TK k = c.ty->k;
    if (k == PTR || k == OPAQUE) return "จับ pointer '" + c.name + "' (ptr ใช้ร่วมกันข้าม thread ได้)";
    if (k == WEAK) return "จับ weak reference '" + c.name + "'";
    if (k == FUNC) return "จับ function/closure '" + c.name + "' (ตรวจสิ่งที่มันจับไว้ไม่ได้)";
    if (k == OBJ) {
      auto it = structs.find(c.ty->name);
      bool ok = it != structs.end() && it->second.module == "sync" && stdlibModules.count("sync");
      if (!ok) return "จับ object '" + c.name + "' ชนิด " + c.ty->name + " (obj ถูกแชร์ ไม่ถูกคัดลอก) — ใช้ class ใน module sync เช่น sync.Atomic";
    }
  }
  return "";
}
// Typed summaries are compiler-only metadata. They intentionally do not change
// the runtime ABI. A global access is classified separately from operations on
// its pointee; lock operations and atomics are recorded as evidence, not treated
// as a complete proof that every access in the whole program is synchronized.
enum class ThreadAccessKind : uint8_t { Read, Write, ReadWrite, Address, AtomicRead, AtomicWrite, AtomicReadWrite };
struct ThreadAtomicEvent {
  uintptr_t site = 0;
  // A worker template is the checked lambda body, not a runtime thread ID.
  // Multiple runtime invocations can still execute the same template.
  uintptr_t workerTemplate = 0;
  // Static thread API call site that instantiates this worker template. A
  // parallelFor site may represent multiple runtime workers executing the
  // same closure body.
  uintptr_t workerSite = 0;
  int line = 0;
  std::string operation, readOrder, writeOrder, failureOrder, callPath;
  bool reads = false, writes = false, rmw = false, compareExchange = false;
};
struct ThreadStorageEffect {
  std::string type, via;
  bool read = false, write = false, alias = false;
  bool atomicRead = false, atomicWrite = false;
  // Per-side memory orders are effect metadata, not proof of a read-from edge.
  std::set<std::string> atomicReadOrders, atomicWriteOrders, atomicCasFailureOrders;
  // Atomic event sites form a bounded per-storage graph. Candidate edges are
  // deliberately not called synchronizes-with: the compiler does not yet know
  // which write an acquire reads from, nor enumerate peer worker executions.
  std::vector<ThreadAtomicEvent> atomicEvents;
  // `locks` is the union of syntactically observed lock names (diagnostic only).
  // `commonLocks` is the intersection across ordinary accesses; it is useful
  // evidence, but never a whole-program proof that other threads use the lock.
  bool hasOrdinaryAccess = false, ordinaryUnprotected = false;
  std::set<std::string> locks, commonLocks;
};
struct ThreadEffectSummary {
  std::map<std::string, ThreadStorageEffect> globals;
  uintptr_t workerTemplate = 0;
  uintptr_t workerSite = 0;
  std::string eventCallPath;
  std::set<std::string> lockAcquires, lockReleases;
  bool unknownAlias = false;
  bool unknownLockFlow = false;
  bool usesAtomic = false;
  void merge(const ThreadEffectSummary &other) {
    for (const auto &entry : other.globals) {
      ThreadStorageEffect &dst = globals[entry.first];
      const ThreadStorageEffect &src = entry.second;
      if (dst.type.empty()) dst.type = src.type;
      if (dst.via.empty()) dst.via = src.via;
      dst.read |= src.read; dst.write |= src.write; dst.alias |= src.alias;
      dst.atomicRead |= src.atomicRead; dst.atomicWrite |= src.atomicWrite;
      dst.atomicReadOrders.insert(src.atomicReadOrders.begin(), src.atomicReadOrders.end());
      dst.atomicWriteOrders.insert(src.atomicWriteOrders.begin(), src.atomicWriteOrders.end());
      dst.atomicCasFailureOrders.insert(src.atomicCasFailureOrders.begin(), src.atomicCasFailureOrders.end());
      for (const auto &event : src.atomicEvents) {
        auto found = std::find_if(dst.atomicEvents.begin(), dst.atomicEvents.end(),
            [&](const ThreadAtomicEvent &old) {
              return old.site == event.site && old.workerTemplate == event.workerTemplate &&
                     old.workerSite == event.workerSite;
            });
        if (found == dst.atomicEvents.end()) dst.atomicEvents.push_back(event);
        else if (found->callPath.empty() && !event.callPath.empty()) found->callPath = event.callPath;
      }
      dst.locks.insert(src.locks.begin(), src.locks.end());
      dst.ordinaryUnprotected |= src.ordinaryUnprotected;
      if (src.hasOrdinaryAccess) {
        if (!dst.hasOrdinaryAccess) dst.commonLocks = src.commonLocks;
        else {
          std::set<std::string> intersection;
          for (const auto &lock : dst.commonLocks)
            if (src.commonLocks.count(lock)) intersection.insert(lock);
          dst.commonLocks = std::move(intersection);
        }
        dst.hasOrdinaryAccess = true;
        dst.ordinaryUnprotected |= src.ordinaryUnprotected;
      }
    }
    lockAcquires.insert(other.lockAcquires.begin(), other.lockAcquires.end());
    lockReleases.insert(other.lockReleases.begin(), other.lockReleases.end());
    unknownAlias |= other.unknownAlias;
    unknownLockFlow |= other.unknownLockFlow;
    usesAtomic |= other.usesAtomic;
  }
};
std::string threadEffectRoot(Node *n) { return n ? rootIdent(n) : std::string{}; }
std::string threadGlobalOwner(const std::string &mod, const std::string &name) {
  auto current = globalVars.find(mod);
  if (current != globalVars.end() && current->second.count(name)) return mod;
  auto imports = modGlobalImports.find(mod);
  if (imports == modGlobalImports.end()) return {};
  std::string provider;
  for (const std::string &candidate : imports->second) {
    auto globals = globalVars.find(candidate);
    if (globals != globalVars.end() && globals->second.count(name)) {
      if (!provider.empty() && provider != candidate) return {}; // ambiguous: do not guess
      provider = candidate;
    }
  }
  return provider;
}
std::pair<std::string, std::string> threadGlobalLocation(const std::string &mod, Node *target) {
  if (!target) return {};
  if (target->k == NK::Ident) {
    const std::string owner = threadGlobalOwner(mod, target->s);
    return owner.empty() ? std::pair<std::string, std::string>{} : std::make_pair(owner, target->s);
  }
  // Explicit module-qualified globals (module.value or importAlias.value).
  // Resolve only a known loaded module/global; never infer arbitrary object fields.
  if (target->k == NK::Member && !target->c.empty() && target->c[0] && target->c[0]->k == NK::Ident) {
    std::string provider = target->c[0]->s;
    auto aliases = modImportAliases.find(mod);
    if (aliases != modImportAliases.end()) {
      auto alias = aliases->second.find(provider);
      if (alias != aliases->second.end()) provider = alias->second;
    }
    auto globals = globalVars.find(provider);
    if (globals != globalVars.end() && globals->second.count(target->s))
      return {provider, target->s};
  }
  return {};
}
std::string threadLockIdentity(const std::string &mod, const std::string &name,
                               const std::set<std::string> &locals, Node *scopeBody) {
  if (locals.count(name)) {
    const auto scope = reinterpret_cast<std::uintptr_t>(scopeBody);
    return "local:" + mod + ":" + std::to_string(scope) + ":" + name;
  }
  const std::string owner = threadGlobalOwner(mod, name);
  if (!owner.empty()) return "global:" + owner + ":" + name;
  const auto scope = reinterpret_cast<std::uintptr_t>(scopeBody);
  return "local:" + mod + ":" + std::to_string(scope) + ":" + name;
}
std::string threadLockDisplayName(const std::string &identity) {
  const size_t pos = identity.rfind(':');
  return pos == std::string::npos ? identity : identity.substr(pos + 1);
}
bool threadLockShadowsName(const std::string &identity, const std::string &name) {
  return threadLockDisplayName(identity) == name;
}
struct ThreadAtomicInfo {
  std::string access, readOrder, writeOrder, failureOrder;
};
ThreadAtomicInfo threadAtomicInfo(const std::string &name) {
  ThreadAtomicInfo info;
  // Legacy names preserve their original sequentially-consistent behavior.
  if (name == "atomicGet" || name == "atomicGetSeqCst") {
    info.access = "read"; info.readOrder = "seq_cst";
  } else if (name == "atomicSet" || name == "atomicSetSeqCst") {
    info.access = "write"; info.writeOrder = "seq_cst";
  } else if (name == "atomicAdd" || name == "atomicAddSeqCst") {
    info.access = "read/write"; info.readOrder = info.writeOrder = "seq_cst";
  } else if (name == "atomicCas" || name == "atomicCasSeqCst") {
    info.access = "read/write"; info.readOrder = info.writeOrder = "seq_cst"; info.failureOrder = "seq_cst";
  } else {
    struct Variant { const char *name; const char *readOrder; const char *writeOrder; const char *failure; const char *access; };
    static const Variant variants[] = {
      {"atomicGetRelaxed", "relaxed", "", "", "read"},
      {"atomicGetAcquire", "acquire", "", "", "read"},
      {"atomicSetRelaxed", "", "relaxed", "", "write"},
      {"atomicSetRelease", "", "release", "", "write"},
      {"atomicAddRelaxed", "relaxed", "relaxed", "", "read/write"},
      {"atomicAddAcquire", "acquire", "relaxed", "", "read/write"},
      {"atomicAddRelease", "relaxed", "release", "", "read/write"},
      {"atomicAddAcqRel", "acq_rel", "acq_rel", "", "read/write"},
      {"atomicCasRelaxed", "relaxed", "relaxed", "relaxed", "read/write"},
      {"atomicCasAcquire", "acquire", "relaxed", "acquire", "read/write"},
      {"atomicCasRelease", "relaxed", "release", "relaxed", "read/write"},
      {"atomicCasAcqRel", "acq_rel", "acq_rel", "acquire", "read/write"},
    };
    for (const Variant &variant : variants) if (name == variant.name) {
      info.access = variant.access;
      info.readOrder = variant.readOrder;
      info.writeOrder = variant.writeOrder;
      info.failureOrder = variant.failure;
      break;
    }
  }
  return info;
}

void noteThreadGlobalEffect(const std::string &mod, const std::string &name,
                            ThreadAccessKind access, ThreadEffectSummary &summary,
                            const std::set<std::string> &locks,
                            const std::string &atomicReadOrder = {},
                            const std::string &atomicWriteOrder = {},
                            const std::string &casFailureOrder = {},
                            const std::string &atomicOperation = {},
                            Node *atomicSite = nullptr) {
  const std::string owner = threadGlobalOwner(mod, name);
  if (owner.empty()) return;
  auto gm = globalVars.find(owner);
  if (gm == globalVars.end()) return;
  auto gv = gm->second.find(name);
  if (gv == gm->second.end()) return;
  const std::string key = owner + "." + name;
  ThreadStorageEffect &effect = summary.globals[key];
  if (effect.type.empty() && gv->second.ty) effect.type = tname(gv->second.ty);
  bool ordinaryAccess = false;
  auto recordAtomicEvent = [&](bool reads, bool writes, bool rmw) {
    if (!atomicSite) return;
    ThreadAtomicEvent event;
    event.site = reinterpret_cast<uintptr_t>(atomicSite);
    event.workerTemplate = summary.workerTemplate;
    event.workerSite = summary.workerSite;
    event.line = atomicSite->line;
    event.operation = atomicOperation;
    event.readOrder = atomicReadOrder;
    event.writeOrder = atomicWriteOrder;
    event.failureOrder = casFailureOrder;
    event.callPath = summary.eventCallPath;
    event.reads = reads;
    event.writes = writes;
    event.rmw = rmw;
    event.compareExchange = atomicOperation.rfind("atomicCas", 0) == 0;
    effect.atomicEvents.push_back(std::move(event));
  };
  switch (access) {
    case ThreadAccessKind::Read: effect.read = true; ordinaryAccess = true; break;
    case ThreadAccessKind::Write: effect.write = true; ordinaryAccess = true; break;
    case ThreadAccessKind::ReadWrite: effect.read = true; effect.write = true; ordinaryAccess = true; break;
    // An escaping address is not protected for its entire lifetime by the
    // lexical lock held at the point where the address was taken.
    case ThreadAccessKind::Address: effect.alias = true; break;
    case ThreadAccessKind::AtomicRead:
      effect.atomicRead = true; summary.usesAtomic = true;
      if (!atomicReadOrder.empty()) effect.atomicReadOrders.insert(atomicReadOrder);
      recordAtomicEvent(true, false, false);
      break;
    case ThreadAccessKind::AtomicWrite:
      effect.atomicWrite = true; summary.usesAtomic = true;
      if (!atomicWriteOrder.empty()) effect.atomicWriteOrders.insert(atomicWriteOrder);
      recordAtomicEvent(false, true, false);
      break;
    case ThreadAccessKind::AtomicReadWrite:
      effect.atomicRead = true; effect.atomicWrite = true; summary.usesAtomic = true;
      if (!atomicReadOrder.empty()) effect.atomicReadOrders.insert(atomicReadOrder);
      if (!atomicWriteOrder.empty()) effect.atomicWriteOrders.insert(atomicWriteOrder);
      if (!casFailureOrder.empty()) effect.atomicCasFailureOrders.insert(casFailureOrder);
      recordAtomicEvent(true, true, true);
      break;
  }
  if (ordinaryAccess) {
    if (!effect.hasOrdinaryAccess) effect.commonLocks = locks;
    else {
      std::set<std::string> intersection;
      for (const auto &lock : effect.commonLocks) if (locks.count(lock)) intersection.insert(lock);
      effect.commonLocks = std::move(intersection);
    }
    effect.hasOrdinaryAccess = true;
    if (locks.empty()) effect.ordinaryUnprotected = true;
  }
  effect.locks.insert(locks.begin(), locks.end());
}
void collectThreadGlobalEffects(Node *n, const std::string &mod,
                                const std::set<std::string> &params,
                                std::set<std::string> &locals,
                                ThreadEffectSummary &summary,
                                ThreadAccessKind access = ThreadAccessKind::Read,
                                std::set<std::string> *locks = nullptr,
                                Node *scopeBody = nullptr) {
  if (!n) return;
  static const std::set<std::string> noLocks;
  const std::set<std::string> &heldLocks = locks ? *locks : noLocks;
  if (n->k == NK::Block) {
    std::set<std::string> scope = locals;
    std::set<std::string> blockLocks = heldLocks;
    std::set<std::string> shadowedLockIds;
    for (auto &child : n->c) {
      if (!child) continue;
      if (child->k == NK::VarDecl) {
        for (const auto &lock : blockLocks) if (threadLockShadowsName(lock, child->s)) {
          shadowedLockIds.insert(lock);
          summary.unknownLockFlow = true;
        }
        for (const auto &lock : shadowedLockIds) blockLocks.erase(lock);
        if (!child->c.empty()) collectThreadGlobalEffects(child->c[0].get(), mod, params, scope, summary, ThreadAccessKind::Read, &blockLocks, scopeBody);
        scope.insert(child->s);
      } else {
        collectThreadGlobalEffects(child.get(), mod, params, scope, summary, ThreadAccessKind::Read, &blockLocks, scopeBody);
      }
    }
    // Restore outer bindings at scope exit. The block is still rejected when
    // a lock name was shadowed because string-only AST bindings cannot prove
    // that a same-spelled local mutex is the same lock object.
    for (const auto &lock : shadowedLockIds) blockLocks.insert(lock);
    if (locks) *locks = blockLocks;
    return;
  }
  if (n->k == NK::If) {
    if (!n->c.empty()) collectThreadGlobalEffects(n->c[0].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
    std::set<std::string> yesLocks = heldLocks, noLocks = heldLocks;
    if (n->c.size() > 1) collectThreadGlobalEffects(n->c[1].get(), mod, params, locals, summary, ThreadAccessKind::Read, &yesLocks, scopeBody);
    if (n->c.size() > 2) collectThreadGlobalEffects(n->c[2].get(), mod, params, locals, summary, ThreadAccessKind::Read, &noLocks, scopeBody);
    std::set<std::string> intersection;
    for (const auto &lock : yesLocks) if (noLocks.count(lock)) intersection.insert(lock);
    if (locks) *locks = std::move(intersection);
    return;
  }
  if (n->k == NK::While || n->k == NK::DoWhile || n->k == NK::For || n->k == NK::ForPP || n->k == NK::ForEach) {
    std::set<std::string> loopLocks = heldLocks;
    std::set<std::string> loopLocals = locals;
    if (n->k == NK::ForEach && !n->s.empty()) {
      for (const auto &lock : loopLocks) if (threadLockShadowsName(lock, n->s)) summary.unknownLockFlow = true;
      loopLocals.insert(n->s);
    }
    for (auto &child : n->c) collectThreadGlobalEffects(child.get(), mod, params, loopLocals, summary, ThreadAccessKind::Read, &loopLocks, scopeBody);
    // A loop may execute zero times; do not let its lock state escape.
    return;
  }
  if (n->k == NK::VarDecl) {
    if (!n->c.empty()) collectThreadGlobalEffects(n->c[0].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
    locals.insert(n->s);
    return;
  }
  if (n->k == NK::Assign && n->c.size() >= 2) {
    const ThreadAccessKind lhs = n->s == "=" ? ThreadAccessKind::Write : ThreadAccessKind::ReadWrite;
    collectThreadGlobalEffects(n->c[0].get(), mod, params, locals, summary, lhs, locks, scopeBody);
    collectThreadGlobalEffects(n->c[1].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
    return;
  }
  if ((n->k == NK::PostInc || (n->k == NK::Unary && (n->s == "++" || n->s == "--"))) && !n->c.empty()) {
    collectThreadGlobalEffects(n->c[0].get(), mod, params, locals, summary, ThreadAccessKind::ReadWrite, locks, scopeBody);
    return;
  }
  if (n->k == NK::Call && !n->c.empty()) {
    Node *callee = n->c[0].get();
    const std::string name = callee ? callee->s : std::string{};
    const bool isMutexLock = callee && callee->k == NK::Member && !callee->c.empty() &&
                             callee->c[0]->k == NK::Ident && callee->c[0]->s == "mutex" &&
                             (name == "lock" || name == "unlock");
    if (isMutexLock && n->c.size() > 1) {
      Node *lockArg = n->c[1].get();
      const std::string lockRoot = lockArg && lockArg->k == NK::Ident ? lockArg->s : std::string{};
      if (!lockRoot.empty()) {
        const std::string lockId = threadLockIdentity(mod, lockRoot, locals, scopeBody);
        if (params.count(lockRoot)) summary.unknownLockFlow = true;
        if (name == "lock") { summary.lockAcquires.insert(lockId); if (locks) locks->insert(lockId); }
        else { summary.lockReleases.insert(lockId); if (locks) locks->erase(lockId); }
      } else summary.unknownLockFlow = true;
      collectThreadGlobalEffects(n->c[1].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
      for (size_t i = 2; i < n->c.size(); ++i)
        collectThreadGlobalEffects(n->c[i].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
      return;
    }
    const bool isAtomic = callee && callee->k == NK::Member && !callee->c.empty() &&
                          callee->c[0]->k == NK::Ident && callee->c[0]->s == "thread";
    const ThreadAtomicInfo atomicInfo = isAtomic ? threadAtomicInfo(name) : ThreadAtomicInfo{};
    if (!atomicInfo.access.empty() && n->c.size() > 1) {
      const ThreadAccessKind atomicAccess = atomicInfo.access == "read" ? ThreadAccessKind::AtomicRead :
          atomicInfo.access == "write" ? ThreadAccessKind::AtomicWrite : ThreadAccessKind::AtomicReadWrite;
      Node *arg = n->c[1].get();
      if (arg && arg->k == NK::Call && !arg->c.empty() && arg->c[0]->k == NK::Ident && arg->c[0]->s == "addr" && arg->c.size() > 1) {
        Node *target = arg->c[1].get();
        const auto location = threadGlobalLocation(mod, target);
        const bool localTarget = target && target->k == NK::Ident &&
                                 (locals.count(target->s) || params.count(target->s));
        if (!location.first.empty() && !localTarget)
          noteThreadGlobalEffect(location.first, location.second, atomicAccess, summary, heldLocks,
                                 atomicInfo.readOrder, atomicInfo.writeOrder, atomicInfo.failureOrder,
                                 name, n);
        else collectThreadGlobalEffects(target, mod, params, locals, summary, atomicAccess, locks, scopeBody);
      } else {
        collectThreadGlobalEffects(arg, mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
      }
      for (size_t i = 2; i < n->c.size(); ++i)
        collectThreadGlobalEffects(n->c[i].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
      return;
    }
    // Taking an address and forwarding it to an unclassified callee creates an
    // alias the current pass cannot summarize. Keep it explicit in the summary.
    for (size_t i = 1; i < n->c.size(); ++i) {
      Node *arg = n->c[i].get();
      if (arg && arg->k == NK::Call && !arg->c.empty() && arg->c[0]->k == NK::Ident &&
          arg->c[0]->s == "addr" && arg->c.size() > 1) {
        Node *target = arg->c[1].get();
        const auto location = threadGlobalLocation(mod, target);
        std::string root = threadEffectRoot(target);
        const bool localTarget = target && target->k == NK::Ident &&
                                 (locals.count(target->s) || params.count(target->s));
        if (!location.first.empty() && !localTarget) {
          summary.unknownAlias = true;
          collectThreadGlobalEffects(target, mod, params, locals, summary, ThreadAccessKind::Address, locks, scopeBody);
        } else if (!root.empty() && !localTarget && !threadGlobalOwner(mod, root).empty()) {
          summary.unknownAlias = true;
          collectThreadGlobalEffects(target, mod, params, locals, summary, ThreadAccessKind::Address, locks, scopeBody);
        } else collectThreadGlobalEffects(arg, mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
      } else collectThreadGlobalEffects(arg, mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
    }
    // Unknown member calls may mutate the receiver's object state.
    if (callee && callee->k == NK::Member && !callee->c.empty())
      collectThreadGlobalEffects(callee->c[0].get(), mod, params, locals, summary, ThreadAccessKind::ReadWrite, locks, scopeBody);
    return;
  }
  if (n->k == NK::Ident) {
    if (!locals.count(n->s) && !params.count(n->s))
      noteThreadGlobalEffect(mod, n->s, access, summary, heldLocks);
    return;
  }
  if (n->k == NK::Member && !n->c.empty()) {
    // A module-qualified global (including an import alias) has one canonical
    // storage identity across every worker/module scan.
    const auto location = threadGlobalLocation(mod, n);
    if (!location.first.empty()) {
      noteThreadGlobalEffect(location.first, location.second, access, summary, heldLocks);
      return;
    }
    collectThreadGlobalEffects(n->c[0].get(), mod, params, locals, summary, access, locks, scopeBody);
    return;
  }
  if (n->k == NK::Index || n->k == NK::Deref || n->k == NK::Slice) {
    if (!n->c.empty()) collectThreadGlobalEffects(n->c[0].get(), mod, params, locals, summary, access, locks, scopeBody);
    for (size_t i = 1; i < n->c.size(); ++i)
      collectThreadGlobalEffects(n->c[i].get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
    return;
  }
  for (auto &c : n->c) collectThreadGlobalEffects(c.get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
  if (!n->cases.empty()) {
    if (n->k == NK::Try && containsDirectThreadMutexOperation(n)) summary.unknownLockFlow = true;
    const std::set<std::string> incomingLocks = heldLocks;
    std::set<std::string> commonLocks = incomingLocks;
    bool firstArm = true;
    for (auto &cs : n->cases) {
      std::set<std::string> armLocks = incomingLocks;
      for (auto &v : cs.vals) collectThreadGlobalEffects(v.get(), mod, params, locals, summary, ThreadAccessKind::Read, &armLocks, scopeBody);
      for (auto &r : cs.ranges) {
        collectThreadGlobalEffects(r.lo.get(), mod, params, locals, summary, ThreadAccessKind::Read, &armLocks, scopeBody);
        collectThreadGlobalEffects(r.hi.get(), mod, params, locals, summary, ThreadAccessKind::Read, &armLocks, scopeBody);
      }
      collectThreadGlobalEffects(cs.guard.get(), mod, params, locals, summary, ThreadAccessKind::Read, &armLocks, scopeBody);
      collectThreadGlobalEffects(cs.body.get(), mod, params, locals, summary, ThreadAccessKind::Read, &armLocks, scopeBody);
      collectThreadGlobalEffects(cs.exprBody.get(), mod, params, locals, summary, ThreadAccessKind::Read, &armLocks, scopeBody);
      if (firstArm) { commonLocks = armLocks; firstArm = false; }
      else {
        std::set<std::string> intersection;
        for (const auto &lock : commonLocks) if (armLocks.count(lock)) intersection.insert(lock);
        commonLocks = std::move(intersection);
      }
    }
    std::set<std::string> defaultLocks = incomingLocks;
    collectThreadGlobalEffects(n->deflt.get(), mod, params, locals, summary, ThreadAccessKind::Read, &defaultLocks, scopeBody);
    std::set<std::string> intersection;
    for (const auto &lock : commonLocks) if (defaultLocks.count(lock)) intersection.insert(lock);
    if (locks) *locks = std::move(intersection);
  } else {
    if (n->k == NK::Try && containsDirectThreadMutexOperation(n)) summary.unknownLockFlow = true;
    collectThreadGlobalEffects(n->deflt.get(), mod, params, locals, summary, ThreadAccessKind::Read, locks, scopeBody);
  }
}
struct ThreadCallSite {
  Node *node = nullptr;
  std::set<std::string> heldLocks;
};
bool containsDirectThreadMutexOperation(Node *n) {
  if (!n) return false;
  if (n->k == NK::Call && !n->c.empty()) {
    Node *callee = n->c[0].get();
    if (callee && callee->k == NK::Member && (callee->s == "lock" || callee->s == "unlock") &&
        !callee->c.empty() && callee->c[0]->k == NK::Ident && callee->c[0]->s == "mutex") return true;
  }
  for (auto &child : n->c) if (containsDirectThreadMutexOperation(child.get())) return true;
  for (auto &cs : n->cases) {
    if (containsDirectThreadMutexOperation(cs.guard.get()) ||
        containsDirectThreadMutexOperation(cs.body.get()) ||
        containsDirectThreadMutexOperation(cs.exprBody.get())) return true;
  }
  return containsDirectThreadMutexOperation(n->deflt.get());
}
bool isThreadMutexCall(Node *call, const std::string &mod,
                       const std::set<std::string> &locals, Node *scopeBody,
                       std::string *operation = nullptr, std::string *lockName = nullptr) {
  if (!call || call->k != NK::Call || call->c.empty()) return false;
  Node *callee = call->c[0].get();
  if (!callee || callee->k != NK::Member || callee->c.empty() ||
      callee->c[0]->k != NK::Ident || callee->c[0]->s != "mutex" ||
      (callee->s != "lock" && callee->s != "unlock") || call->c.size() < 2) return false;
  Node *lockArg = call->c[1].get();
  if (!lockArg || lockArg->k != NK::Ident) return false;
  const std::string root = threadLockIdentity(mod, lockArg->s, locals, scopeBody);
  if (root.empty()) return false;
  if (operation) *operation = callee->s;
  if (lockName) *lockName = root;
  return true;
}
void collectThreadCallSites(Node *n, const std::string &mod, std::set<std::string> &locals,
                            Node *scopeBody, std::set<std::string> &locks,
                            std::vector<ThreadCallSite> &sites, bool &unknownFlow) {
  if (!n) return;
  if (n->k == NK::Block) {
    std::set<std::string> scope = locals;
    const std::set<std::string> outerLocks = locks;
    std::set<std::string> blockLocks = locks;
    std::set<std::string> shadowedLockIds;
    for (auto &child : n->c) {
      if (!child) continue;
      if (child->k == NK::VarDecl) {
        for (const auto &lock : outerLocks) if (threadLockShadowsName(lock, child->s)) {
          shadowedLockIds.insert(lock);
          blockLocks.erase(lock);
          unknownFlow = true;
        }
        if (!child->c.empty()) collectThreadCallSites(child->c[0].get(), mod, scope, scopeBody, blockLocks, sites, unknownFlow);
        scope.insert(child->s);
      } else {
        collectThreadCallSites(child.get(), mod, scope, scopeBody, blockLocks, sites, unknownFlow);
      }
    }
    for (const auto &lock : shadowedLockIds) blockLocks.insert(lock);
    locks = std::move(blockLocks);
    return;
  }
  if (n->k == NK::VarDecl) {
    if (!n->c.empty()) collectThreadCallSites(n->c[0].get(), mod, locals, scopeBody, locks, sites, unknownFlow);
    locals.insert(n->s);
    return;
  }
  if (n->k == NK::Try && containsDirectThreadMutexOperation(n)) unknownFlow = true;
  if (n->k == NK::If) {
    if (!n->c.empty()) collectThreadCallSites(n->c[0].get(), mod, locals, scopeBody, locks, sites, unknownFlow);
    std::set<std::string> yesLocks = locks, noLocks = locks;
    std::set<std::string> yesLocals = locals, noLocals = locals;
    if (n->c.size() > 1) collectThreadCallSites(n->c[1].get(), mod, yesLocals, scopeBody, yesLocks, sites, unknownFlow);
    if (n->c.size() > 2) collectThreadCallSites(n->c[2].get(), mod, noLocals, scopeBody, noLocks, sites, unknownFlow);
    std::set<std::string> intersection;
    for (const auto &lock : yesLocks) if (noLocks.count(lock)) intersection.insert(lock);
    locks = std::move(intersection);
    return;
  }
  if (n->k == NK::While || n->k == NK::DoWhile || n->k == NK::For ||
      n->k == NK::ForPP || n->k == NK::ForEach) {
    std::set<std::string> loopLocks = locks;
    std::set<std::string> loopLocals = locals;
    if (n->k == NK::ForEach && !n->s.empty()) {
      for (const auto &lock : locks) if (threadLockShadowsName(lock, n->s)) unknownFlow = true;
      loopLocals.insert(n->s);
    }
    for (auto &child : n->c) collectThreadCallSites(child.get(), mod, loopLocals, scopeBody, loopLocks, sites, unknownFlow);
    // The loop may execute zero times. A lock-state change in its body cannot
    // be propagated safely to the following statement.
    if (loopLocks != locks) unknownFlow = true;
    return;
  }
  if (n->k == NK::Call) {
    // Evaluate nested calls in the receiver/arguments before recording the
    // outer call. A lock operation itself changes the lexical state here.
    for (size_t i = 0; i < n->c.size(); ++i) {
      if (i == 0) {
        Node *callee = n->c[i].get();
        if (callee && callee->k == NK::Member && !callee->c.empty())
          collectThreadCallSites(callee->c[0].get(), mod, locals, scopeBody, locks, sites, unknownFlow);
      } else collectThreadCallSites(n->c[i].get(), mod, locals, scopeBody, locks, sites, unknownFlow);
    }
    std::string operation, lockName;
    if (isThreadMutexCall(n, mod, locals, scopeBody, &operation, &lockName)) {
      if (operation == "lock") locks.insert(lockName);
      else locks.erase(lockName);
    } else {
      Node *callee = n->c[0].get();
      if (callee && callee->k == NK::Member && callee->s == "lock" &&
          !callee->c.empty() && callee->c[0]->k == NK::Ident && callee->c[0]->s == "mutex")
        unknownFlow = true;
      sites.push_back({n, locks});
    }
    return;
  }
  if (n->k == NK::New) {
    for (auto &child : n->c) collectThreadCallSites(child.get(), mod, locals, scopeBody, locks, sites, unknownFlow);
    sites.push_back({n, locks});
    return;
  }
  for (auto &child : n->c) collectThreadCallSites(child.get(), mod, locals, scopeBody, locks, sites, unknownFlow);
  // Switch/match arms are alternatives. Include the unmatched path when no
  // default arm exists; only locks held on every possible path survive.
  if (!n->cases.empty()) {
    std::set<std::string> common = locks;
    bool first = true;
    for (auto &cs : n->cases) {
      std::set<std::string> armLocks = locks;
      std::set<std::string> armLocals = locals;
      collectThreadCallSites(cs.guard.get(), mod, armLocals, scopeBody, armLocks, sites, unknownFlow);
      collectThreadCallSites(cs.body.get(), mod, armLocals, scopeBody, armLocks, sites, unknownFlow);
      collectThreadCallSites(cs.exprBody.get(), mod, armLocals, scopeBody, armLocks, sites, unknownFlow);
      if (first) { common = armLocks; first = false; }
      else {
        std::set<std::string> intersection;
        for (const auto &lock : common) if (armLocks.count(lock)) intersection.insert(lock);
        common = std::move(intersection);
      }
    }
    std::set<std::string> defaultLocks = locks;
    std::set<std::string> defaultLocals = locals;
    collectThreadCallSites(n->deflt.get(), mod, defaultLocals, scopeBody, defaultLocks, sites, unknownFlow);
    std::set<std::string> intersection;
    for (const auto &lock : common) if (defaultLocks.count(lock)) intersection.insert(lock);
    locks = std::move(intersection);
  } else collectThreadCallSites(n->deflt.get(), mod, locals, scopeBody, locks, sites, unknownFlow);
}
void collectThreadLocalDeclCounts(Node *n, std::map<std::string, size_t> &counts) {
  if (!n) return;
  if ((n->k == NK::VarDecl || n->k == NK::ForEach) && !n->s.empty()) ++counts[n->s];
  for (auto &child : n->c) collectThreadLocalDeclCounts(child.get(), counts);
  for (auto &cs : n->cases) {
    collectThreadLocalDeclCounts(cs.guard.get(), counts);
    collectThreadLocalDeclCounts(cs.body.get(), counts);
    collectThreadLocalDeclCounts(cs.exprBody.get(), counts);
  }
  collectThreadLocalDeclCounts(n->deflt.get(), counts);
}
void collectThreadMutexNames(Node *n, std::set<std::string> &names) {
  if (!n) return;
  if (n->k == NK::Call && !n->c.empty()) {
    Node *callee = n->c[0].get();
    if (callee && callee->k == NK::Member &&
        (callee->s == "lock" || callee->s == "unlock") &&
        !callee->c.empty() && callee->c[0]->k == NK::Ident && callee->c[0]->s == "mutex" &&
        n->c.size() > 1 && n->c[1] && n->c[1]->k == NK::Ident)
      names.insert(n->c[1]->s);
  }
  for (auto &child : n->c) collectThreadMutexNames(child.get(), names);
  for (auto &cs : n->cases) {
    collectThreadMutexNames(cs.guard.get(), names);
    collectThreadMutexNames(cs.body.get(), names);
    collectThreadMutexNames(cs.exprBody.get(), names);
  }
  collectThreadMutexNames(n->deflt.get(), names);
}
std::string threadLockContextKey(const std::set<std::string> &locks) {
  std::string key;
  for (const auto &lock : locks) key += std::to_string(lock.size()) + ":" + lock + ";";
  return key;
}
std::string describeThreadEffect(const std::string &key, const ThreadStorageEffect &effect) {
  std::string mode;
  if (effect.read) mode += "read";
  if (effect.write) mode += (mode.empty() ? "" : "/") + std::string("write");
  if (effect.alias) mode += (mode.empty() ? "" : "/") + std::string("alias");
  if (effect.atomicRead || effect.atomicWrite) {
    mode += (mode.empty() ? "" : "/") + std::string("atomic-");
    mode += effect.atomicRead && effect.atomicWrite ? "read/write" : effect.atomicWrite ? "write" : "read";
  }
  if (mode.empty()) mode = "unknown";
  std::string result = key + " (type " + (effect.type.empty() ? "unknown" : effect.type) + "; effect " + mode;
  auto renderOrders = [](const std::set<std::string> &orders) {
    std::string text = "{"; bool first = true;
    for (const auto &order : orders) { if (!first) text += ","; text += order; first = false; }
    return text + "}";
  };
  if (effect.atomicRead || effect.atomicWrite) {
    result += "; atomic-order read=" + renderOrders(effect.atomicReadOrders) +
              " write=" + renderOrders(effect.atomicWriteOrders);
    if (!effect.atomicCasFailureOrders.empty())
      result += " cas-failure=" + renderOrders(effect.atomicCasFailureOrders);
    const bool hasRelease = effect.atomicWriteOrders.count("release") || effect.atomicWriteOrders.count("acq_rel") || effect.atomicWriteOrders.count("seq_cst");
    const bool hasAcquire = effect.atomicReadOrders.count("acquire") || effect.atomicReadOrders.count("acq_rel") || effect.atomicReadOrders.count("seq_cst");
    if (hasRelease && hasAcquire)
      result += "; release/acquire semantics present (no read-from edge proven)";
    if (effect.atomicReadOrders.count("seq_cst") || effect.atomicWriteOrders.count("seq_cst"))
      result += "; participates in seq_cst order (not a cross-thread race proof)";
    auto acquireCapable = [](const ThreadAtomicEvent &event) {
      return event.readOrder == "acquire" || event.readOrder == "acq_rel" ||
             event.readOrder == "seq_cst" || event.failureOrder == "acquire" ||
             event.failureOrder == "acq_rel" || event.failureOrder == "seq_cst";
    };
    auto failureAcquireCapable = [](const ThreadAtomicEvent &event) {
      return event.compareExchange &&
             (event.failureOrder == "acquire" || event.failureOrder == "acq_rel" ||
              event.failureOrder == "seq_cst");
    };
    auto releaseCapable = [](const ThreadAtomicEvent &event) {
      return event.writes && (event.writeOrder == "release" || event.writeOrder == "acq_rel" ||
                              event.writeOrder == "seq_cst");
    };
    auto seqCstCapable = [](const ThreadAtomicEvent &event) {
      return event.readOrder == "seq_cst" || event.writeOrder == "seq_cst" ||
             event.failureOrder == "seq_cst";
    };
    std::set<std::pair<uintptr_t, uintptr_t>> readFromCandidates;
    std::set<std::pair<uintptr_t, uintptr_t>> releaseAcquireCandidates;
    std::set<std::pair<uintptr_t, uintptr_t>> casFailureAcquireCandidates;
    std::set<std::pair<uintptr_t, uintptr_t>> seqCstPairs;
    std::set<std::tuple<uintptr_t, uintptr_t, uintptr_t>> rmwBridgeCandidates;
    std::set<std::pair<int, int>> readFromLines;
    std::set<std::pair<int, int>> releaseAcquireLines;
    std::set<std::pair<int, int>> casFailureAcquireLines;
    std::set<uintptr_t> workerTemplates;
    std::set<std::string> callPaths;
    for (const auto &event : effect.atomicEvents) {
      if (event.workerTemplate) workerTemplates.insert(event.workerTemplate);
      if (!event.callPath.empty()) callPaths.insert(event.callPath);
    }
    // Every atomic modification on the resolved storage is a possible source
    // for every distinct atomic read. This is intentionally a may-read-from
    // relation: no modification order, value-flow or runtime thread identity
    // is inferred from AST order.
    for (const auto &write : effect.atomicEvents) {
      if (!write.writes) continue;
      for (const auto &read : effect.atomicEvents) {
        if (!read.reads || write.site == read.site) continue;
        readFromCandidates.insert({write.site, read.site});
        readFromLines.insert({write.line, read.line});
        if (releaseCapable(write) && acquireCapable(read)) {
          releaseAcquireCandidates.insert({write.site, read.site});
          releaseAcquireLines.insert({write.line, read.line});
        }
        if (releaseCapable(write) && failureAcquireCapable(read)) {
          casFailureAcquireCandidates.insert({write.site, read.site});
          casFailureAcquireLines.insert({write.line, read.line});
        }
        // A distinct RMW can be an intermediate modification in a release
        // sequence, but this pass cannot prove it is ordered between endpoints.
        if (releaseCapable(write) && acquireCapable(read)) {
          for (const auto &middle : effect.atomicEvents) {
            if (!middle.rmw || middle.site == write.site || middle.site == read.site) continue;
            rmwBridgeCandidates.insert({write.site, middle.site, read.site});
          }
        }
      }
    }
    for (size_t i = 0; i < effect.atomicEvents.size(); ++i) {
      if (!seqCstCapable(effect.atomicEvents[i])) continue;
      for (size_t j = i + 1; j < effect.atomicEvents.size(); ++j) {
        if (!seqCstCapable(effect.atomicEvents[j]) ||
            effect.atomicEvents[i].site == effect.atomicEvents[j].site) continue;
        const uintptr_t a = std::min(effect.atomicEvents[i].site, effect.atomicEvents[j].site);
        const uintptr_t b = std::max(effect.atomicEvents[i].site, effect.atomicEvents[j].site);
        seqCstPairs.insert({a, b});
      }
    }
    result += "; atomic-sync-graph nodes=" + std::to_string(effect.atomicEvents.size()) +
              " release-acquire-candidates=" + std::to_string(releaseAcquireCandidates.size()) +
              " seq-cst-pairs=" + std::to_string(seqCstPairs.size()) +
              " read-from-candidates=" + std::to_string(readFromCandidates.size()) +
              " cas-failure-acquire-candidates=" + std::to_string(casFailureAcquireCandidates.size()) +
              " rmw-bridge-candidates=" + std::to_string(rmwBridgeCandidates.size()) +
              " worker-templates=" + std::to_string(workerTemplates.size()) +
              " call-paths=" + std::to_string(callPaths.size()) +
              " read-from-edges={";
    bool firstRead = true;
    for (const auto &edge : readFromLines) {
      if (!firstRead) result += ",";
      result += "L" + std::to_string(edge.first) + "->L" + std::to_string(edge.second);
      firstRead = false;
    }
    result += "} cas-failure-edges={";
    bool firstCasFailure = true;
    for (const auto &edge : casFailureAcquireLines) {
      if (!firstCasFailure) result += ",";
      result += "L" + std::to_string(edge.first) + "->L" + std::to_string(edge.second);
      firstCasFailure = false;
    }
    result += "} edges={";
    bool firstEdge = true;
    for (const auto &edge : releaseAcquireLines) {
      if (!firstEdge) result += ",";
      result += "L" + std::to_string(edge.first) + "->L" + std::to_string(edge.second);
      firstEdge = false;
    }
    result += "} (candidate edges only; no modification-order/read-from/thread execution is proven)";
  }
  if ((effect.read || effect.write) && (effect.atomicRead || effect.atomicWrite))
    result += "; mixed atomic/non-atomic access (potential data race)";
  if (!effect.locks.empty()) {
    result += "; lock observed ";
    bool first = true;
    for (const std::string &lock : effect.locks) { if (!first) result += ","; result += threadLockDisplayName(lock); first = false; }
  }
  if (effect.alias) result += "; alias exposure (lock does not bound escaped lifetime)";
  if (effect.hasOrdinaryAccess) {
    if (effect.ordinaryUnprotected) result += "; unprotected ordinary access";
    else if (!effect.commonLocks.empty()) {
      result += "; lock common to all ordinary accesses ";
      bool first = true;
      for (const std::string &lock : effect.commonLocks) { if (!first) result += ","; result += threadLockDisplayName(lock); first = false; }
    } else result += "; no common lock across ordinary accesses";
  }
  if (!effect.locks.empty() || effect.hasOrdinaryAccess)
    result += " (observed lock evidence only; not a whole-program synchronization proof)";
  return result + ")";
}
std::string scanSharedState(Node *body, const std::set<std::string> &params, const std::string &mod,
                            std::map<Node *, std::set<std::string>> &seen, int depth,
                            ThreadEffectSummary *aggregate = nullptr, const std::string &viaPath = {},
                            const std::set<std::string> &entryLocks = {}, Node *workerTemplate = nullptr,
                            Node *workerSite = nullptr) {
  if (!body) return "";
  if (!workerTemplate) workerTemplate = body;
  // This is a safety check, so an analysis limit must fail closed. Returning an
  // empty result here used to let a thread closure hide a global access behind a call chain deeper than 64 functions.
  if (depth > 64) return "call chain ลึกเกิน 64 ระดับ จึงตรวจสอบความปลอดภัยของ thread closure ไม่ได้";
  const std::string contextKey = threadLockContextKey(entryLocks);
  if (!seen[body].insert(contextKey).second) return "";
  for (const auto &param : params)
    for (const auto &lock : entryLocks)
      if (threadLockShadowsName(lock, param))
        return "parameter '" + param + "' shadow ชื่อ mutex ที่ caller ถืออยู่ จึงพิสูจน์ lock identity ไม่ได้";
  std::map<std::string, size_t> localDeclCounts;
  for (const auto &param : params) localDeclCounts[param] = 1;
  collectThreadLocalDeclCounts(body, localDeclCounts);
  std::set<std::string> mutexNames;
  collectThreadMutexNames(body, mutexNames);
  for (const auto &name : mutexNames)
    if (localDeclCounts[name] > 1)
      return "ชื่อ mutex '" + name + "' มี local declaration ซ้ำหลาย scope จึงพิสูจน์ lock identity ไม่ได้";
  ThreadEffectSummary local;
  local.workerTemplate = reinterpret_cast<uintptr_t>(workerTemplate);
  local.workerSite = reinterpret_cast<uintptr_t>(workerSite);
  local.eventCallPath = viaPath.empty() ? "<worker>" : viaPath;
  std::set<std::string> locals = params;
  std::set<std::string> heldLocks = entryLocks;
  collectThreadGlobalEffects(body, mod, params, locals, local, ThreadAccessKind::Read, &heldLocks, body);
  if (local.unknownLockFlow)
    return "มี mutex shadow/alias หรือ exception path ที่ยืนยัน lock identity และ cleanup ไม่ได้";
  if (!viaPath.empty()) for (auto &entry : local.globals) if (entry.second.via.empty()) entry.second.via = viaPath;
  if (aggregate) aggregate->merge(local);

  std::vector<ThreadCallSite> callSites;
  std::set<std::string> callLocks = entryLocks;
  std::set<std::string> callLocals = params;
  bool unknownLockFlow = false;
  collectThreadCallSites(body, mod, callLocals, body, callLocks, callSites, unknownLockFlow);
  if (unknownLockFlow)
    return "control-flow/exception path หรือ lock scope ที่ไม่ชัดเจน ทำให้พิสูจน์สถานะ mutex ที่ถืออยู่ไม่ได้";
  if (heldLocks != entryLocks)
    return "function/closure เปลี่ยน lock state ก่อน return (acquire/release ไม่สมดุลกับ caller)";

  // Scan one function/method body with the lock context at its call site.
  // A callee must return with the same lock set it received; otherwise the
  // caller's subsequent lock state cannot be proven.
  auto scanFn = [&](FuncInfo &fn, const std::string &shown,
                    const std::set<std::string> &callEntryLocks) -> std::string {
    if (!fn.node || fn.isExtern || fn.node->c.empty() || trustedModules.count(fn.module)) return "";
    std::set<std::string> ps; for (auto &p : fn.node->params) ps.insert(p.name);
    const std::string nextPath = viaPath.empty() ? shown : viaPath + " -> " + shown;
    return scanSharedState(fn.node->c[0].get(), ps, fn.module, seen, depth + 1,
                           aggregate, nextPath, callEntryLocks, workerTemplate, workerSite);
  };
  for (const ThreadCallSite &site : callSites) {
    Node *c = site.node;
    if (!c) continue;
    if (c->k == NK::New) {   // new Foo(): constructors/destructors run on this thread
      for (std::string cls = c->s; !cls.empty();) {
        auto sit = structs.find(cls); if (sit == structs.end()) break;
        for (const char *m : {"__ctor", "__dtor"}) {
          auto it = funcs.find(cls + "::" + m);
          if (it != funcs.end()) {
            std::string r = scanFn(it->second, "new " + cls, site.heldLocks);
            if (!r.empty()) return r + " (ผ่าน 'new " + cls + "')";
          }
        }
        cls = sit->second.parent;
      }
      continue;
    }
    if (c->k != NK::Call || c->c.empty()) continue;
    Node *f = c->c[0].get();
    std::string key;
    if (f->k == NK::Ident) key = mod + "." + f->s;
    else if (f->k == NK::Member && !f->c.empty() && f->c[0]->k == NK::Ident) key = f->c[0]->s + "." + f->s;
    auto it = key.empty() ? funcs.end() : funcs.find(key);
    if (it != funcs.end()) {
      std::string r = scanFn(it->second, f->s, site.heldLocks);
      if (!r.empty()) return r + " (ผ่าน '" + f->s + "')";
      continue;
    }
    if (f->k == NK::Member) {
      // Unknown receiver class: conservatively include each same-named user method.
      const std::string suffix = "::" + f->s;
      for (auto &kv : funcs) {
        if (kv.first.size() <= suffix.size() || kv.first.compare(kv.first.size() - suffix.size(), suffix.size(), suffix) != 0) continue;
        std::string r = scanFn(kv.second, f->s, site.heldLocks);
        if (!r.empty()) return r + " (ผ่าน '" + f->s + "')";
      }
    }
  }
  if (depth == 0 && aggregate) {
    for (const auto &entry : aggregate->globals) {
      const size_t dot = entry.first.find('.');
      const std::string owner = dot == std::string::npos ? mod : entry.first.substr(0, dot);
      const std::string name = dot == std::string::npos ? entry.first : entry.first.substr(dot + 1);
      auto gm = globalVars.find(owner);
      if (gm == globalVars.end()) continue;
      auto gv = gm->second.find(name);
      if (gv == gm->second.end() || gv->second.isConst) continue;
      // A mutex handle is a synchronization primitive, not ordinary shared
      // payload. Its use is summarized separately; this does NOT certify the
      // payload protected by it and does not prove all program accesses lock it.
      const bool balancedMutexHandle = entry.second.type == "mutex" && entry.second.read &&
          !entry.second.write && !entry.second.alias &&
          aggregate->lockAcquires.count("global:" + owner + ":" + name) &&
          aggregate->lockReleases.count("global:" + owner + ":" + name);
      if (balancedMutexHandle) continue;
      std::string message = "แตะตัวแปร global '" + name + "' ที่แก้ค่าได้ (" + describeThreadEffect(entry.first, entry.second) + ")";
      if (!entry.second.via.empty()) {
        size_t begin = 0;
        while (begin < entry.second.via.size()) {
          size_t end = entry.second.via.find(" -> ", begin);
          if (end == std::string::npos) end = entry.second.via.size();
          const std::string step = entry.second.via.substr(begin, end - begin);
          if (!step.empty()) message += " (ผ่าน '" + step + "')";
          begin = end + 4;
        }
      }
      return message;
    }
    if (aggregate->unknownAlias) return "ส่ง address ของ global ผ่าน alias/call ที่ยังไม่มี effect contract จึงตรวจสอบ data race ไม่ได้";
  }
  return "";
}
// Whole-program worker registry. V70 analyzed one closure at a time; V71 scans
// every statically visible thread.start / thread.parallelFor callback after all
// functions and globals have been registered. Its graph remains candidate-only:
// join ordering, runtime thread identity, and actual read-from values are not
// inferred here.
enum class ThreadWorkerMultiplicity : uint8_t {
  PerActivation, LoopRepeatable, ParallelReplicated, Unknown
};
enum class ThreadJoinDisposition : uint8_t {
  NotTracked, MustJoin, MayOutlive, Conditional, Unknown, RuntimeJoined
};
const char *threadWorkerMultiplicityName(ThreadWorkerMultiplicity m) {
  switch (m) {
    case ThreadWorkerMultiplicity::PerActivation: return "per-activation";
    case ThreadWorkerMultiplicity::LoopRepeatable: return "loop-repeatable";
    case ThreadWorkerMultiplicity::ParallelReplicated: return "parallel-replicated";
    default: return "unknown";
  }
}
const char *threadJoinDispositionName(ThreadJoinDisposition j) {
  switch (j) {
    case ThreadJoinDisposition::NotTracked: return "untracked";
    case ThreadJoinDisposition::MustJoin: return "must-join";
    case ThreadJoinDisposition::MayOutlive: return "may-outlive";
    case ThreadJoinDisposition::Conditional: return "conditional";
    case ThreadJoinDisposition::RuntimeJoined: return "runtime-joined";
    default: return "unknown";
  }
}
struct ThreadWorkerSiteInfo {
  Node *call = nullptr;
  Node *closure = nullptr;
  Node *ownerBody = nullptr;
  std::string module, owner, api, handleName;
  int line = 0;
  unsigned loopDepth = 0;
};
struct ThreadWorkerRegistryEntry {
  ThreadWorkerSiteInfo site;
  ThreadEffectSummary effects;
  std::string problem;
  ThreadWorkerMultiplicity multiplicity = ThreadWorkerMultiplicity::Unknown;
  ThreadJoinDisposition join = ThreadJoinDisposition::NotTracked;
  bool unresolved = false;
};
struct ThreadWorkerRegistry {
  bool built = false;
  std::vector<ThreadWorkerRegistryEntry> workers;
  std::string summary;
};
ThreadWorkerRegistry &wholeProgramWorkerRegistry() {
  static ThreadWorkerRegistry registry;
  return registry;
}
void resetWholeProgramWorkerRegistry() {
  wholeProgramWorkerRegistry() = ThreadWorkerRegistry{};
}
std::string threadCallPath(Node *n) {
  if (!n || n->k != NK::Call || n->c.empty()) return {};
  std::string path;
  return flatten(n->c[0].get(), path) ? path : std::string{};
}
bool isThreadStartCall(Node *n) { return threadCallPath(n) == "thread.start"; }
bool isThreadHandleDecl(Node *n) {
  return n && n->k == NK::VarDecl && n->ts.kind == "ptr" && n->ts.base == "thread";
}
std::string threadHandleExprKey(Node *n) {
  if (!n || (n->k != NK::Ident && n->k != NK::Member)) return {};
  std::string key;
  return flatten(n, key) ? key : std::string{};
}
const Node *threadHandleStructDef(const std::string &rawName) {
  std::string name = rawName;
  const size_t dot = name.rfind('.');
  if (dot != std::string::npos) name = name.substr(dot + 1);
  for (Program *program : progs) if (program)
    for (const auto &decl : program->structs)
      if (decl && decl->s == name && !decl->isClass && !decl->isInterface) return decl.get();
  return nullptr;
}
bool isThreadHandleStructDecl(Node *n) {
  if (!n || n->k != NK::VarDecl || (n->ts.kind != "" && n->ts.kind != "var") ||
      n->ts.cat == "array" || n->ts.cat == "list" || n->ts.cat == "obj") return false;
  return threadHandleStructDef(n->ts.base) != nullptr;
}
void collectThreadHandleStructFields(const std::string &typeName, const std::string &prefix,
                                     std::vector<std::string> &out, unsigned depth = 0,
                                     std::set<std::string> *activeTypes = nullptr) {
  if (depth >= 8) return;
  std::set<std::string> localActive;
  if (!activeTypes) activeTypes = &localActive;
  std::string simple = typeName;
  const size_t dot = simple.rfind('.');
  if (dot != std::string::npos) simple = simple.substr(dot + 1);
  if (!activeTypes->insert(simple).second) return;
  const Node *record = threadHandleStructDef(simple);
  if (record) for (const auto &field : record->c) {
    if (!field || field->k != NK::VarDecl || field->isStatic || field->isClass) continue;
    const std::string path = prefix + "." + field->s;
    if (field->ts.kind == "ptr" && field->ts.base == "thread") out.push_back(path);
    else if ((field->ts.kind.empty() || field->ts.kind == "var") &&
             field->ts.cat != "array" && field->ts.cat != "list" && field->ts.cat != "obj")
      collectThreadHandleStructFields(field->ts.base, path, out, depth + 1, activeTypes);
  }
  activeTypes->erase(simple);
}
bool threadHandleStructType(const TypeSpec &type, std::string &baseName) {
  if ((type.kind != "" && type.kind != "var") || type.cat == "array" ||
      type.cat == "list" || type.cat == "obj") return false;
  if (!threadHandleStructDef(type.base)) return false;
  std::vector<std::string> fields;
  collectThreadHandleStructFields(type.base, "__thread_handle_type", fields);
  if (fields.empty()) return false;
  baseName = type.base;
  const size_t dot = baseName.rfind('.');
  if (dot != std::string::npos) baseName = baseName.substr(dot + 1);
  return true;
}
bool threadHandleStructTypeForExpr(Node *ownerBody, Node *expr, std::string &baseName) {
  if (!ownerBody || !expr) return false;
  if (expr->k == NK::Call && threadCallPath(expr) == "move" && expr->c.size() == 2)
    return threadHandleStructTypeForExpr(ownerBody, expr->c[1].get(), baseName);
  if (expr->k == NK::Ident) {
    bool found = false;
    std::string resolved;
    auto accept = [&](const TypeSpec &type) {
      std::string candidate;
      if (!threadHandleStructType(type, candidate)) return false;
      if (found && resolved != candidate) return false;
      found = true;
      resolved = candidate;
      return true;
    };
    for (FuncInfo *fn : allFuncs) {
      if (!fn || !fn->node || fn->node->c.empty() || fn->node->c[0].get() != ownerBody) continue;
      for (const Param &param : fn->node->params)
        if (param.name == expr->s && !accept(param.ts)) return false;
    }
    std::function<bool(Node *)> scan = [&](Node *node) {
      if (!node || node->k == NK::Lambda) return true;
      if (node->k == NK::VarDecl && node->s == expr->s && !accept(node->ts)) return false;
      for (auto &child : node->c) if (!scan(child.get())) return false;
      for (auto &cs : node->cases)
        if (!scan(cs.guard.get()) || !scan(cs.body.get()) || !scan(cs.exprBody.get())) return false;
      return scan(node->deflt.get());
    };
    if (!scan(ownerBody) || !found) return false;
    baseName = resolved;
    return true;
  }
  if (expr->k == NK::Member && !expr->c.empty()) {
    std::string parentType;
    if (!threadHandleStructTypeForExpr(ownerBody, expr->c[0].get(), parentType)) return false;
    const Node *record = threadHandleStructDef(parentType);
    if (!record) return false;
    for (const auto &field : record->c) {
      if (!field || field->k != NK::VarDecl || field->s != expr->s || field->isStatic || field->isClass)
        continue;
      return threadHandleStructType(field->ts, baseName);
    }
  }
  return false;
}
std::vector<std::string> threadHandleStructFieldPaths(const std::string &typeName) {
  std::vector<std::string> fields;
  collectThreadHandleStructFields(typeName, "__thread_handle_root", fields);
  const std::string prefix = "__thread_handle_root.";
  for (std::string &field : fields)
    if (field.compare(0, prefix.size(), prefix) == 0) field.erase(0, prefix.size());
  return fields;
}
// Recover only argument types that are certain from syntax or a built-in's
// explicit result contract, without consulting the current codegen scope.
// Arbitrary calls, computed expressions and uncertain forms stay conservative.
bool threadKnownExactValueArgType(Node *arg, T &type) {
  if (!arg) return false;
  switch (arg->k) {
    case NK::IntLit: type = constInt(arg->iv).t; return true;
    case NK::FloatLit: type = T_double; return true;
    case NK::CharLit: type = arg->iv < 128 ? T_char : T_uni; return true;
    case NK::StrLit: type = T_str; return true;
    case NK::BoolLit: type = T_bool; return true;
    case NK::NullLit: type = T_null; return true;
    case NK::Call: {
      if (arg->c.empty()) return false;
      const std::string path = threadCallPath(arg);
      // `str(value)` has a fixed String result, independent of the operand type.
      // It is a built-in name, so arbitrary user functions are not inferred.
      if (path == "str" && arg->c.size() == 2) {
        type = T_str;
        return true;
      }
      // These built-ins have fixed result contracts. `parse` takes an explicit
      // primitive target; size/sizeof and strcmp always return Int. Do not
      // generalize this to arbitrary user-defined calls.
      if ((path == "size" || path == "sizeof") && arg->c.size() == 2) {
        type = T_int;
        return true;
      }
      if (path == "strcmp" && arg->c.size() == 3) {
        type = T_int;
        return true;
      }
      // math.abs/min/max have argument-dependent numeric return types.
      // Exact scalar operands are sufficient to mirror mathMinMaxAbs()'s
      // promote/commonT rules without evaluating the expression.
      if (path == "math.abs" && arg->c.size() == 2) {
        T operandType = nullptr;
        if (!threadKnownExactValueArgType(arg->c[1].get(), operandType) ||
            !isNum(operandType)) return false;
        type = promote(operandType);
        return type && isNum(type);
      }
      if ((path == "math.min" || path == "math.max") && arg->c.size() == 3) {
        T leftType = nullptr, rightType = nullptr;
        if (!threadKnownExactValueArgType(arg->c[1].get(), leftType) ||
            !threadKnownExactValueArgType(arg->c[2].get(), rightType) ||
            !isNum(leftType) || !isNum(rightType)) return false;
        type = commonT(leftType, rightType);
        return type && isNum(type);
      }
      // Fixed-result runtime built-ins outside the scalar core. Their result
      // contracts are independent of argument values, so the call's arity is
      // sufficient evidence. Value-dependent results (for example random.int)
      // are intentionally excluded.
      if ((path == "terminal.in.readline" || path == "terminal.in.readLine") &&
          arg->c.size() == 1) {
        type = T_str;
        return true;
      }
      if (path == "cstr" && arg->c.size() == 2) {
        type = T_str;
        return true;
      }
      if (path == "memory.weakAlive" && arg->c.size() == 2) {
        type = T_bool;
        return true;
      }
      if ((path == "memory.sizeof" || path == "find" || path == "type") &&
          arg->c.size() == (path == "find" ? 3u : 2u)) {
        type = T_int;
        return true;
      }
      // `random.int` has an argument-dependent result in tableCall(). The
      // exact-value path handles direct literal/unary/cast integer arguments;
      // identifiers are handled separately by the call-site-aware resolver.
      if (path == "random.int" && arg->c.size() == 3) {
        T minType = nullptr, maxType = nullptr;
        if (!threadKnownExactValueArgType(arg->c[1].get(), minType) ||
            !threadKnownExactValueArgType(arg->c[2].get(), maxType) ||
            !isIntLike(minType) || !isIntLike(maxType)) return false;
        type = (bitsOf(minType) > 32 || bitsOf(maxType) > 32) ? T_long : T_int;
        return true;
      }
      // Source API table entries have a declared result code. Reuse that
      // contract for scalar returns only; void, pointer, list and other
      // argument-dependent return codes remain unknown to this bounded resolver.
      const size_t builtinArgc = arg->c.size() - 1;
      for (const BI *builtin = BTAB; builtin->q; ++builtin) {
        if (path != builtin->q || strlen(builtin->params) != builtinArgc) continue;
        switch (builtin->ret) {
          case 'i': type = T_int; return true;
          case 'l': type = T_long; return true;
          case 'u': type = T_ulong; return true;
          case 'U': type = T_uint; return true;
          case 'c': type = T_uni; return true;
          case 'd': type = T_double; return true;
          case 'b': type = T_bool; return true;
          case 'S': type = T_str; return true;
          default: break;
        }
      }
      if (path == "parse" && arg->c.size() == 3 && arg->c[1] &&
          arg->c[1]->k == NK::Ident) {
        T target = typeFromName(arg->c[1]->s);
        // gen_call.inc implements parse only for numeric and boolean targets.
        if (target && (isNum(target) || target->k == BOOL)) {
          type = target;
          return true;
        }
        return false;
      }
      // `cast(Type, value)` fixes the result type explicitly. Use only known
      // primitive targets; class/enum casts and arbitrary calls remain unknown.
      if (path != "cast" || arg->c.size() != 3 ||
          !arg->c[1] || arg->c[1]->k != NK::Ident) return false;
      T target = typeFromName(arg->c[1]->s);
      if (!target || !(isNum(target) || target->k == BOOL || target->k == CHAR ||
                       target->k == UNI || target->k == STR)) return false;
      type = target;
      return true;
    }
    case NK::Unary: {
      // Unary literal typing may recurse through a chain of unary operators,
      // but never through identifiers, arbitrary calls, or binary expressions.
      // Each operator is checked against the already-resolved operand type.
      if (arg->c.size() != 1 || !arg->c[0]) return false;
      Node *operand = arg->c[0].get();
      T operandType = nullptr;
      if (!threadKnownExactValueArgType(operand, operandType)) return false;
      if (arg->s == "!") {
        if (!(isNum(operandType) || operandType->k == BOOL)) return false;
        type = T_bool;
        return true;
      }
      if ((arg->s == "+" || arg->s == "-") && isNum(operandType)) {
        type = operandType; // unary +/- preserves the numeric operand type
        return true;
      }
      if (arg->s == "~" && isIntLike(operandType)) {
        type = promote(operandType); // unary bitwise complement promotes narrow integers
        return true;
      }
      return false;
    }
    default: return false;
  }
}
// Resolve only the exact scalar/string value type of the identifier bound at this
// call site: explicit declarations, directly-proven `auto`, or a chain
// of `auto` value copies from an already-known visible scalar identifier.
// Unsupported inferred/dynamic declarations and ambiguous shadows stay unknown.
// This pass deliberately does not infer calls, member paths, operators, globals
// or aliases.
bool threadKnownScalarTypeSpec(const TypeSpec &spec, T &type) {
  if ((!spec.kind.empty() && spec.kind != "var") || !spec.cat.empty()) return false;
  static const std::set<std::string> supported = {
      "byte", "short", "int", "long", "ubyte", "ushort", "uint", "ulong",
      "float", "double", "boolean", "char", "unichar", "string"};
  if (!supported.count(spec.base)) return false;
  type = baseType(spec.base, 0);
  return type && (isNum(type) || type->k == BOOL || type->k == CHAR ||
                  type->k == UNI || type->k == STR);
}
// `auto` scalar facts are limited to exact literal/unary/cast or fixed-result
// built-in initializers, plus the bounded random.int rule resolved against the
// active lexical bindings below. Non-scalar, string and null values are not
// admitted by this scalar-only lifecycle resolver.
bool threadKnownAutoExactValueType(Node *decl, T &type) {
  if (!decl || decl->k != NK::VarDecl || decl->ts.base != "auto" ||
      decl->ts.cat.size() || (!decl->ts.kind.empty() && decl->ts.kind != "var") ||
      decl->c.size() != 1 || !threadKnownExactValueArgType(decl->c[0].get(), type))
    return false;
  return type && (isNum(type) || type->k == BOOL || type->k == CHAR || type->k == UNI);
}
struct ThreadKnownScalarBinding {
  bool known = false;
  T type = nullptr;
};
bool threadKnownDeclaredScalarArgType(Node *ownerBody, Node *callSite, Node *arg, T &type) {
  if (!ownerBody || !callSite || !arg || arg->k != NK::Ident) return false;

  // Resolve the identifier at the exact call site, following the same lexical
  // block boundaries used by code generation. Sibling branches must not poison
  // one another, and a declaration after the call must not affect the result.
  std::vector<std::map<std::string, ThreadKnownScalarBinding>> scopes(1);
  auto bind = [&](const std::string &name, const TypeSpec &spec, Node *decl = nullptr) {
    if (name.empty()) return;
    ThreadKnownScalarBinding binding;
    binding.known = threadKnownScalarTypeSpec(spec, binding.type);
    if (!binding.known && decl) {
      binding.known = threadKnownAutoExactValueType(decl, binding.type);
      // An auto initialized by random.int can retain its fixed Int/Long result
      // when both bounds are exact scalar values or visible, already-proven
      // scalar identifiers. Resolve the initializer in the declaration scope
      // (not the later use scope); arbitrary calls and computed bounds stay unknown.
      if (!binding.known && decl->ts.base == "auto" && decl->ts.cat.empty() &&
          decl->c.size() == 1 && decl->c[0] && decl->c[0]->k == NK::Call &&
          decl->c[0]->c.size() == 3 &&
          threadCallPath(decl->c[0].get()) == "random.int") {
        auto knownInitializerScalar = [&](Node *value, T &valueType) {
          if (threadKnownExactValueArgType(value, valueType)) return true;
          if (!value || value->k != NK::Ident) return false;
          for (auto scope = scopes.rbegin(); scope != scopes.rend(); ++scope) {
            auto source = scope->find(value->s);
            if (source == scope->end()) continue;
            if (source->second.known) valueType = source->second.type;
            return source->second.known;
          }
          return false;
        };
        T minType = nullptr, maxType = nullptr;
        Node *initializer = decl->c[0].get();
        if (knownInitializerScalar(initializer->c[1].get(), minType) &&
            knownInitializerScalar(initializer->c[2].get(), maxType) &&
            isIntLike(minType) && isIntLike(maxType)) {
          binding.known = true;
          binding.type = (bitsOf(minType) > 32 || bitsOf(maxType) > 32) ? T_long : T_int;
        }
      }
      // A scalar `auto` initialized from another visible scalar identifier is
      // a value copy, not an alias. Reuse only a binding already proven in the
      // current lexical environment; calls, member paths and computed values
      // remain unknown. The new name is not installed until after this lookup.
      if (!binding.known && decl->ts.base == "auto" && decl->ts.cat.empty() &&
          decl->c.size() == 1 && decl->c[0] && decl->c[0]->k == NK::Ident) {
        const std::string &sourceName = decl->c[0]->s;
        for (auto scope = scopes.rbegin(); scope != scopes.rend(); ++scope) {
          auto source = scope->find(sourceName);
          if (source == scope->end()) continue;
          if (source->second.known) binding = source->second;
          break;
        }
      }
    }
    auto inserted = scopes.back().emplace(name, binding);
    if (!inserted.second) inserted.first->second = ThreadKnownScalarBinding{};
  };
  auto bindUnknown = [&](const std::string &name) {
    if (name.empty()) return;
    auto inserted = scopes.back().emplace(name, ThreadKnownScalarBinding{});
    if (!inserted.second) inserted.first->second = ThreadKnownScalarBinding{};
  };
  for (FuncInfo *fn : allFuncs) {
    if (!fn || !fn->node || fn->node->c.empty() || fn->node->c[0].get() != ownerBody) continue;
    for (const Param &param : fn->node->params) bind(param.name, param.ts);
  }

  bool reached = false;
  ThreadKnownScalarBinding resolved;
  auto lookup = [&](const std::string &name, ThreadKnownScalarBinding &out) {
    for (auto it = scopes.rbegin(); it != scopes.rend(); ++it) {
      auto found = it->find(name);
      if (found == it->end()) continue;
      out = found->second;
      return out.known;
    }
    return false;
  };

  std::function<bool(Node *, bool)> walkBlock;
  std::function<bool(Node *)> walk;
  walkBlock = [&](Node *block, bool createScope) {
    if (!block) return false;
    if (block->k != NK::Block) return walk(block);
    if (createScope) scopes.emplace_back();
    for (auto &statement : block->c) {
      if (walk(statement.get())) {
        if (createScope) scopes.pop_back();
        return true;
      }
    }
    if (createScope) scopes.pop_back();
    return false;
  };
  walk = [&](Node *node) -> bool {
    if (!node || node->k == NK::Lambda) return false;
    if (node == callSite) {
      reached = true;
      lookup(arg->s, resolved);
      return true;
    }
    switch (node->k) {
      case NK::Block:
        return walkBlock(node, true);
      case NK::VarDecl:
        // A local becomes visible after its initializer has been evaluated.
        for (auto &child : node->c) if (walk(child.get())) return true;
        bind(node->s, node->ts, node);
        return false;
      case NK::If:
        if (!node->c.empty() && walk(node->c[0].get())) return true;
        if (node->c.size() > 1 && walk(node->c[1].get())) return true;
        return node->c.size() > 2 && walk(node->c[2].get());
      case NK::For: {
        scopes.emplace_back();
        for (auto &child : node->c) if (walk(child.get())) { scopes.pop_back(); return true; }
        scopes.pop_back();
        return false;
      }
      case NK::ForEach: {
        scopes.emplace_back();
        if (!node->c.empty() && walk(node->c[0].get())) { scopes.pop_back(); return true; }
        bind(node->s, node->ts);
        if (node->c.size() > 1 && walk(node->c[1].get())) { scopes.pop_back(); return true; }
        scopes.pop_back();
        return false;
      }
      case NK::Try: {
        if (!node->c.empty() && node->c[0]) {
          scopes.emplace_back(); // tryCore executes its body in a handler scope
          bool foundCall = walkBlock(node->c[0].get(), false);
          scopes.pop_back();
          if (foundCall) return true;
        }
        if (node->c.size() > 1 && node->c[1]) {
          scopes.emplace_back();
          bindUnknown(node->s); // catch(Error name) shadows any outer identifier
          bool foundCall = walkBlock(node->c[1].get(), false);
          scopes.pop_back();
          if (foundCall) return true;
        }
        return node->c.size() > 2 && walk(node->c[2].get());
      }
      case NK::Switch:
      case NK::Match:
      case NK::MatchExpr:
        if (!node->c.empty() && walk(node->c[0].get())) return true;
        for (auto &cs : node->cases) {
          scopes.emplace_back();
          for (const std::string &name : cs.bindings) bindUnknown(name);
          bool foundCall = false;
          for (auto &value : cs.vals) if (walk(value.get())) { foundCall = true; break; }
          for (auto &range : cs.ranges) {
            if (foundCall) break;
            if (walk(range.lo.get()) || walk(range.hi.get())) { foundCall = true; break; }
          }
          if (!foundCall && walk(cs.guard.get())) foundCall = true;
          if (!foundCall && walk(cs.body.get())) foundCall = true;
          if (!foundCall && walk(cs.exprBody.get())) foundCall = true;
          scopes.pop_back();
          if (foundCall) return true;
        }
        return walk(node->deflt.get());
      default:
        for (auto &child : node->c) if (walk(child.get())) return true;
        for (auto &cs : node->cases) {
          if (walk(cs.guard.get()) || walk(cs.body.get()) || walk(cs.exprBody.get())) return true;
        }
        return walk(node->deflt.get());
    }
  };

  bool foundCall = ownerBody->k == NK::Block ? walkBlock(ownerBody, false) : walk(ownerBody);
  if (!foundCall || !reached || !resolved.known) return false;
  type = resolved.type;
  return true;
}
// Resolve numeric built-in results with the same rules as mathMinMaxAbs():
// abs promotes its operand; min/max use commonT. Identifiers are accepted only
// when their exact lexical scalar binding is already proven at this call site.
bool threadKnownNumericBuiltinResultAtCall(Node *ownerBody, Node *callSite,
                                           Node *arg, T &type) {
  if (!arg || arg->k != NK::Call || arg->c.empty()) return false;
  const std::string path = threadCallPath(arg);
  auto knownNumericOperand = [&](Node *value, T &valueType) {
    return (threadKnownExactValueArgType(value, valueType) ||
            threadKnownDeclaredScalarArgType(ownerBody, callSite, value, valueType)) &&
           isNum(valueType);
  };
  if (path == "math.abs" && arg->c.size() == 2) {
    T operandType = nullptr;
    if (!knownNumericOperand(arg->c[1].get(), operandType)) return false;
    type = promote(operandType);
    return type && isNum(type);
  }
  if ((path == "math.min" || path == "math.max") && arg->c.size() == 3) {
    T leftType = nullptr, rightType = nullptr;
    if (!knownNumericOperand(arg->c[1].get(), leftType) ||
        !knownNumericOperand(arg->c[2].get(), rightType)) return false;
    type = commonT(leftType, rightType);
    return type && isNum(type);
  }
  return false;
}
// Extend exact expression facts with only lexical identifier facts needed by
// existing argument-dependent built-in result rules.
bool threadKnownArgTypeAtCall(Node *ownerBody, Node *callSite, Node *arg, T &type) {
  if (threadKnownExactValueArgType(arg, type)) return true;
  if (threadKnownDeclaredScalarArgType(ownerBody, callSite, arg, type)) return true;
  if (threadKnownNumericBuiltinResultAtCall(ownerBody, callSite, arg, type)) return true;
  if (!arg || arg->k != NK::Call || arg->c.size() != 3 ||
      threadCallPath(arg) != "random.int") return false;
  T minType = nullptr, maxType = nullptr;
  auto knownIntegerArg = [&](Node *value, T &valueType) {
    return threadKnownExactValueArgType(value, valueType) ||
           threadKnownDeclaredScalarArgType(ownerBody, callSite, value, valueType);
  };
  if (!knownIntegerArg(arg->c[1].get(), minType) ||
      !knownIntegerArg(arg->c[2].get(), maxType) ||
      !isIntLike(minType) || !isIntLike(maxType)) return false;
  type = (bitsOf(minType) > 32 || bitsOf(maxType) > 32) ? T_long : T_int;
  return true;
}

std::vector<FuncInfo *> resolveThreadJoinStructHelper(Node *call, const std::string &module,
                                                       Node *ownerBody) {
  std::vector<FuncInfo *> matches;
  if (!call || call->k != NK::Call || call->c.empty() || !ownerBody) return matches;
  const std::string path = threadCallPath(call);
  if (path.empty() || path == "thread.join" || path == "thread.start" ||
      path == "thread.parallelFor" || path == "thread.cancel" ||
      path == "thread.isDone" || path == "thread.isCancelled" || path == "move") return matches;
  const size_t dot = path.rfind('.');
  const bool qualified = dot != std::string::npos;
  const std::string wantedName = qualified ? path.substr(dot + 1) : path;
  const std::string wantedModule = qualified ? path.substr(0, dot) : std::string{};
  const size_t argc = call->c.size() - 1;

  // Resolve argument facts once. A tracked value-struct argument has an exact
  // type; literals and explicitly-declared primitive identifiers have exact
  // value types. Computed expressions and unsupported declarations stay unknown.
  std::vector<std::string> actualStructTypes(argc);
  std::vector<T> knownScalarTypes(argc);
  std::vector<bool> hasStructType(argc, false), hasKnownScalarType(argc, false);
  bool allArgsKnown = true;
  for (size_t i = 0; i < argc; ++i) {
    Node *arg = call->c[i + 1].get();
    hasStructType[i] = threadHandleStructTypeForExpr(ownerBody, arg, actualStructTypes[i]);
    if (!hasStructType[i]) {
      hasKnownScalarType[i] = threadKnownArgTypeAtCall(ownerBody, call, arg, knownScalarTypes[i]);
    }
    if (!hasStructType[i] && !hasKnownScalarType[i]) allArgsKnown = false;
  }

  std::vector<std::pair<FuncInfo *, int>> ranked;
  for (FuncInfo *fn : allFuncs) {
    if (!fn || !fn->node || fn->node->c.empty() || fn->isExtern || fn->isAbstract ||
        fn->generic || fn->isMethod || fn->variadic || fn->name != wantedName || fn->pt.size() != argc)
      continue;
    bool visible = false;
    if (qualified) visible = fn->module == wantedModule;
    else if (fn->module == module) visible = true;
    else {
      auto imports = modGlobalImports.find(module);
      visible = imports != modGlobalImports.end() && imports->second.count(fn->module) != 0;
    }
    if (!visible) continue;
    bool sawTrackedStruct = false;
    bool typesMatch = true;
    int score = 0;
    for (size_t i = 0; i < argc; ++i) {
      if (hasStructType[i]) {
        std::string formalType;
        if (!threadHandleStructType(fn->node->params[i].ts, formalType) ||
            formalType != actualStructTypes[i]) {
          typesMatch = false;
          break;
        }
        sawTrackedStruct = true;
        score += 3; // exact STRUCT argument, same weight as scoreArg()
      } else if (hasKnownScalarType[i]) {
        const int scalarScore = scoreArg(knownScalarTypes[i], fn->pt[i]);
        if (scalarScore < 0) {
          typesMatch = false;
          break;
        }
        score += scalarScore;
      }
    }
    if (typesMatch && sawTrackedStruct) ranked.push_back({fn, score});
  }

  // If every argument is statically known, use the same score ordering as
  // pickFunc(). Otherwise retain all viable candidates; a unique survivor is
  // safe to use, but a remaining tie must stay unresolved.
  if (allArgsKnown && ranked.size() > 1) {
    int bestScore = -1000000;
    for (const auto &candidate : ranked) bestScore = std::max(bestScore, candidate.second);
    size_t bestCount = 0;
    for (const auto &candidate : ranked) if (candidate.second == bestScore) ++bestCount;
    if (bestCount == 1) {
      for (const auto &candidate : ranked)
        if (candidate.second == bestScore) matches.push_back(candidate.first);
      return matches;
    }
  }
  for (const auto &candidate : ranked) matches.push_back(candidate.first);
  return matches;
}
void collectThreadWorkerSites(Node *n, const std::string &module, const std::string &owner,
                              Node *ownerBody, std::vector<ThreadWorkerSiteInfo> &out,
                              std::set<Node *> &seenCalls, const std::string &boundHandle = {},
                              unsigned loopDepth = 0) {
  if (!n) return;
  // A start directly initializing a local thread handle can be paired with a
  // same-function join. Nested callback bodies become their own flow region.
  if (isThreadHandleDecl(n) && !n->c.empty() && isThreadStartCall(n->c[0].get())) {
    collectThreadWorkerSites(n->c[0].get(), module, owner, ownerBody, out, seenCalls, n->s, loopDepth);
    for (size_t i = 1; i < n->c.size(); ++i)
      collectThreadWorkerSites(n->c[i].get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
    return;
  }
  if (n->k == NK::Assign && n->c.size() > 1 && n->c[0] &&
      !threadHandleExprKey(n->c[0].get()).empty() && isThreadStartCall(n->c[1].get())) {
    collectThreadWorkerSites(n->c[1].get(), module, owner, ownerBody, out, seenCalls,
                             threadHandleExprKey(n->c[0].get()), loopDepth);
    return;
  }
  if (n->k == NK::Lambda && !n->c.empty()) ownerBody = n->c[0].get();
  if (n->k == NK::Call && !n->c.empty()) {
    const std::string path = threadCallPath(n);
    const bool start = path == "thread.start";
    const bool parallel = path == "thread.parallelFor";
    if ((start || parallel) && seenCalls.insert(n).second) {
      const size_t argIndex = start ? 1 : 2;
      if (n->c.size() > argIndex) {
        ThreadWorkerSiteInfo site;
        site.call = n;
        site.closure = n->c[argIndex].get();
        site.ownerBody = ownerBody;
        site.module = module;
        site.owner = owner;
        site.api = path;
        site.handleName = start ? boundHandle : std::string{};
        site.line = n->line;
        site.loopDepth = loopDepth;
        out.push_back(std::move(site));
      }
    }
  }
  // A for initializer executes once per loop entry; condition, increment and
  // body may execute repeatedly. Other loop bodies/conditions are repeatable.
  for (size_t i = 0; i < n->c.size(); ++i) {
    unsigned childDepth = loopDepth;
    if (n->k == NK::For && i > 0) ++childDepth;
    else if (n->k == NK::ForEach && i > 0) ++childDepth;
    else if (n->k == NK::ForPP && i > 0) ++childDepth;
    else if (n->k == NK::While || n->k == NK::DoWhile) ++childDepth;
    collectThreadWorkerSites(n->c[i].get(), module, owner, ownerBody, out, seenCalls, {}, childDepth);
  }
  for (auto &cs : n->cases) {
    for (auto &value : cs.vals) collectThreadWorkerSites(value.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
    for (auto &range : cs.ranges) {
      collectThreadWorkerSites(range.lo.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
      collectThreadWorkerSites(range.hi.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
    }
    collectThreadWorkerSites(cs.guard.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
    collectThreadWorkerSites(cs.body.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
    collectThreadWorkerSites(cs.exprBody.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
  }
  collectThreadWorkerSites(n->deflt.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
  for (auto &param : n->params) collectThreadWorkerSites(param.def.get(), module, owner, ownerBody, out, seenCalls, {}, loopDepth);
}

// A bounded, fail-closed flow pass for local `ptr thread` handles. V73 adds
// summaries for direct, uniquely-resolved helper calls; V76 adds value-struct
// parameter field summaries; V77 adds bounded fixed-point forwarding; V78 uses
// a dependency-worklist fixed point; V79 adds literal-aware overload ranking,
// V80 adds explicitly declared scalar identifiers, and V81 resolves their
// visible lexical binding at each call site. It does not
// infer arbitrary pointer ownership, method dispatch, FFI effects, general recursion
// guarantees, or runtime scheduling.
using ThreadHandleFlowState = std::map<std::string, unsigned>;
using ThreadJoinFunctionSummaries = std::map<FuncInfo *, std::vector<ThreadJoinDisposition>>;
ThreadJoinFunctionSummaries &threadJoinFunctionSummaries() {
  static ThreadJoinFunctionSummaries summaries;
  return summaries;
}
std::string &threadJoinAnalysisModule() {
  static std::string module;
  return module;
}
Node *&threadJoinAnalysisOwnerBody() {
  static Node *body = nullptr;
  return body;
}
using ThreadJoinStructFunctionSummaries =
    std::map<FuncInfo *, std::vector<std::vector<ThreadJoinDisposition>>>;
ThreadJoinStructFunctionSummaries &threadJoinStructFunctionSummaries() {
  static ThreadJoinStructFunctionSummaries summaries;
  return summaries;
}
static constexpr unsigned kThreadHandleNotStarted = 1u;
static constexpr unsigned kThreadHandleLive = 2u;
static constexpr unsigned kThreadHandleJoined = 4u;
static constexpr unsigned kThreadHandleUnknown = 8u;
struct ThreadHandleFlowResult {
  ThreadHandleFlowState fall;
  bool fallsThrough = true;
  std::vector<ThreadHandleFlowState> exits;
};
void collectThreadHandleNames(Node *n, std::map<std::string, unsigned> &counts) {
  if (!n || n->k == NK::Lambda) return;
  if (isThreadHandleDecl(n) && !n->s.empty()) ++counts[n->s];
  if (isThreadHandleStructDecl(n) && !n->s.empty()) {
    std::vector<std::string> fields;
    collectThreadHandleStructFields(n->ts.base, n->s, fields);
    for (const std::string &field : fields) ++counts[field];
  }
  for (auto &child : n->c) collectThreadHandleNames(child.get(), counts);
  for (auto &cs : n->cases) {
    collectThreadHandleNames(cs.body.get(), counts);
    collectThreadHandleNames(cs.guard.get(), counts);
    collectThreadHandleNames(cs.exprBody.get(), counts);
  }
  collectThreadHandleNames(n->deflt.get(), counts);
}
std::vector<FuncInfo *> resolveThreadJoinHelper(Node *call, const std::string &module,
                                                        const ThreadHandleFlowState &state) {
  std::vector<FuncInfo *> matches;
  if (!call || call->k != NK::Call || call->c.empty()) return matches;
  std::string path = threadCallPath(call);
  if (path.empty() || path == "thread.join" || path == "thread.start" ||
      path == "thread.parallelFor" || path == "thread.cancel" ||
      path == "thread.isDone" || path == "thread.isCancelled") return matches;
  const size_t dot = path.rfind('.');
  const bool qualified = dot != std::string::npos;
  const std::string wantedName = qualified ? path.substr(dot + 1) : path;
  const std::string wantedModule = qualified ? path.substr(0, dot) : std::string{};
  const size_t argc = call->c.size() - 1;
  for (FuncInfo *fn : allFuncs) {
    if (!fn || !fn->node || fn->node->c.empty() || fn->isExtern || fn->isAbstract ||
        fn->generic || fn->isMethod || fn->variadic || fn->name != wantedName || fn->pt.size() != argc)
      continue;
    bool visible = false;
    if (qualified) visible = fn->module == wantedModule;
    else if (fn->module == module) visible = true;
    else {
      auto imports = modGlobalImports.find(module);
      visible = imports != modGlobalImports.end() && imports->second.count(fn->module) != 0;
    }
    if (!visible) continue;
    bool handleArgsMatch = true;
    for (size_t i = 1; i < call->c.size(); ++i) {
      Node *arg = call->c[i].get();
      const std::string argKey = threadHandleExprKey(arg);
      if (argKey.empty() || !state.count(argKey)) continue;
      if (i - 1 >= fn->node->params.size()) { handleArgsMatch = false; break; }
      const TypeSpec &paramType = fn->node->params[i - 1].ts;
      if (paramType.kind != "ptr" || paramType.base != "thread") {
        handleArgsMatch = false;
        break;
      }
    }
    if (!handleArgsMatch) continue;
    matches.push_back(fn);
  }
  return matches;
}
bool threadNodeContainsIdent(Node *n, const std::string &name) {
  if (!n || n->k == NK::Lambda) return false;
  if (n->k == NK::Ident && n->s == name) return true;
  for (auto &child : n->c) if (threadNodeContainsIdent(child.get(), name)) return true;
  for (auto &cs : n->cases) {
    if (threadNodeContainsIdent(cs.guard.get(), name) ||
        threadNodeContainsIdent(cs.body.get(), name) ||
        threadNodeContainsIdent(cs.exprBody.get(), name)) return true;
  }
  return threadNodeContainsIdent(n->deflt.get(), name);
}
bool threadHandleParameterEscapes(Node *n, const std::string &name, const std::string &module) {
  if (!n || n->k == NK::Lambda) return false;
  if (n->k == NK::Call) {
    const std::string path = threadCallPath(n);
    for (size_t i = 1; i < n->c.size(); ++i) {
      Node *arg = n->c[i].get();
      if (!threadNodeContainsIdent(arg, name)) continue;
      if (!arg || arg->k != NK::Ident) return true;
      if (path == "thread.join" && i == 1) continue;
      ThreadHandleFlowState tracked{{name, kThreadHandleLive}};
      const auto targets = resolveThreadJoinHelper(n, module, tracked);
      if (targets.size() != 1 || i - 1 >= targets.front()->node->params.size()) return true;
      const TypeSpec &formal = targets.front()->node->params[i - 1].ts;
      if (formal.kind != "ptr" || formal.base != "thread") return true;
    }
    // Recurse only into the callee and arguments that do not contain this
    // parameter; recognized direct helper arguments were checked above.
    if (!n->c.empty() && threadHandleParameterEscapes(n->c[0].get(), name, module)) return true;
    for (size_t i = 1; i < n->c.size(); ++i)
      if (!threadNodeContainsIdent(n->c[i].get(), name) &&
          threadHandleParameterEscapes(n->c[i].get(), name, module)) return true;
    return false;
  }
  if (n->k == NK::Return && threadNodeContainsIdent(n, name)) return true;
  if (n->k == NK::Assign && n->c.size() > 1 &&
      (threadNodeContainsIdent(n->c[0].get(), name) || threadNodeContainsIdent(n->c[1].get(), name))) return true;
  if (n->k == NK::VarDecl && !n->c.empty() && threadNodeContainsIdent(n->c[0].get(), name)) return true;
  if (n->k == NK::Ident && n->s == name) return true;
  for (auto &child : n->c) if (threadHandleParameterEscapes(child.get(), name, module)) return true;
  for (auto &cs : n->cases) {
    if (threadHandleParameterEscapes(cs.guard.get(), name, module) ||
        threadHandleParameterEscapes(cs.body.get(), name, module) ||
        threadHandleParameterEscapes(cs.exprBody.get(), name, module)) return true;
  }
  return threadHandleParameterEscapes(n->deflt.get(), name, module);
}
void applyThreadJoinStateEffect(ThreadHandleFlowState &state, const std::string &name,
                                ThreadJoinDisposition effect) {
  auto it = state.find(name);
  if (it == state.end()) return;
  if (effect == ThreadJoinDisposition::MustJoin) {
    unsigned next = it->second & kThreadHandleUnknown;
    if (it->second & (kThreadHandleNotStarted | kThreadHandleJoined)) next |= kThreadHandleUnknown;
    if (it->second & kThreadHandleLive) next |= kThreadHandleJoined;
    it->second = next ? next : kThreadHandleUnknown;
  } else if (effect == ThreadJoinDisposition::Conditional) {
    if (it->second & kThreadHandleUnknown) return;
    if (it->second & kThreadHandleLive) it->second |= kThreadHandleJoined;
    else it->second = kThreadHandleUnknown;
  } else if (effect == ThreadJoinDisposition::Unknown ||
             effect == ThreadJoinDisposition::NotTracked) {
    it->second = kThreadHandleUnknown;
  }
  // MayOutlive means the callee returned without consuming or escaping the
  // handle. The caller retains the original live/joined state.
}
bool threadNodeContainsIdentAny(Node *node, const std::string &name) {
  if (!node) return false;
  if (node->k == NK::Ident && node->s == name) return true;
  for (auto &child : node->c) if (threadNodeContainsIdentAny(child.get(), name)) return true;
  for (auto &cs : node->cases)
    if (threadNodeContainsIdentAny(cs.guard.get(), name) ||
        threadNodeContainsIdentAny(cs.body.get(), name) ||
        threadNodeContainsIdentAny(cs.exprBody.get(), name)) return true;
  return threadNodeContainsIdentAny(node->deflt.get(), name);
}
bool threadStructParameterEscapes(Node *node, const std::string &name,
                                  const std::string &module, Node *ownerBody) {
  if (!node) return false;
  if (node->k == NK::Lambda) return threadNodeContainsIdentAny(node, name);
  if (node->k == NK::Call) {
    const std::string path = threadCallPath(node);
    for (size_t i = 1; i < node->c.size(); ++i) {
      Node *arg = node->c[i].get();
      if (!threadNodeContainsIdentAny(arg, name)) continue;
      std::string key = threadHandleExprKey(arg);
      if (key.empty()) key = threadHandleMoveSourceKey(arg);
      const std::string prefix = name + ".";
      const bool rootedAtParameter = key == name ||
          (key.size() > prefix.size() && key.compare(0, prefix.size(), prefix) == 0);
      if (rootedAtParameter && path == "thread.join") continue;
      // A whole aggregate (or a nested aggregate field) may be forwarded to
      // one uniquely resolved value-struct helper. Its effect is supplied by
      // the bounded summary fixed point below; unresolved and ambiguous calls
      // remain escapes.
      std::string actualStructType;
      if (rootedAtParameter && threadHandleStructTypeForExpr(ownerBody, arg, actualStructType)) {
        const auto structTargets = resolveThreadJoinStructHelper(node, module, ownerBody);
        if (structTargets.size() == 1) continue;
      }
      if (rootedAtParameter && key.size() > prefix.size() &&
          key.compare(0, prefix.size(), prefix) == 0) {
        ThreadHandleFlowState tracked{{key, kThreadHandleLive}};
        const auto targets = resolveThreadJoinHelper(node, module, tracked);
        if (targets.size() == 1 && threadJoinFunctionSummaries().count(targets.front())) continue;
      }
      return true;
    }
    if (!node->c.empty() && threadStructParameterEscapes(node->c[0].get(), name, module, ownerBody)) return true;
    for (size_t i = 1; i < node->c.size(); ++i)
      if (!threadNodeContainsIdentAny(node->c[i].get(), name) &&
          threadStructParameterEscapes(node->c[i].get(), name, module, ownerBody)) return true;
    return false;
  }
  if (node->k == NK::Return && threadNodeContainsIdentAny(node, name)) return true;
  if (node->k == NK::Assign && node->c.size() > 1 &&
      (threadNodeContainsIdentAny(node->c[0].get(), name) || threadNodeContainsIdentAny(node->c[1].get(), name))) return true;
  if (node->k == NK::VarDecl && !node->c.empty() && threadNodeContainsIdentAny(node->c[0].get(), name)) return true;
  if (node->k == NK::Ident && node->s == name) return true;
  for (auto &child : node->c)
    if (threadStructParameterEscapes(child.get(), name, module, ownerBody)) return true;
  for (auto &cs : node->cases)
    if (threadStructParameterEscapes(cs.guard.get(), name, module, ownerBody) ||
        threadStructParameterEscapes(cs.body.get(), name, module, ownerBody) ||
        threadStructParameterEscapes(cs.exprBody.get(), name, module, ownerBody)) return true;
  return threadStructParameterEscapes(node->deflt.get(), name, module, ownerBody);
}
bool threadFunctionLocalShadows(Node *node, const std::string &name) {
  if (!node || node->k == NK::Lambda) return false;
  if (node->k == NK::VarDecl && node->s == name) return true;
  for (auto &child : node->c)
    if (threadFunctionLocalShadows(child.get(), name)) return true;
  for (auto &cs : node->cases)
    if (threadFunctionLocalShadows(cs.guard.get(), name) ||
        threadFunctionLocalShadows(cs.body.get(), name) ||
        threadFunctionLocalShadows(cs.exprBody.get(), name)) return true;
  return threadFunctionLocalShadows(node->deflt.get(), name);
}
std::vector<std::vector<ThreadJoinDisposition>> analyzeThreadJoinStructFunctionSummary(FuncInfo *fn) {
  std::vector<std::vector<ThreadJoinDisposition>> summary;
  if (!fn || !fn->node || fn->node->c.empty()) return summary;
  summary.resize(fn->node->params.size());
  ThreadHandleFlowState initial;
  std::vector<std::vector<std::string>> paths(fn->node->params.size());
  for (size_t i = 0; i < fn->node->params.size(); ++i) {
    const Param &param = fn->node->params[i];
    std::string typeName;
    if (!threadHandleStructType(param.ts, typeName) || param.name.empty()) continue;
    paths[i] = threadHandleStructFieldPaths(typeName);
    summary[i].assign(paths[i].size(), ThreadJoinDisposition::Unknown);
    for (const std::string &field : paths[i])
      initial[param.name + "." + field] = kThreadHandleLive;
  }
  bool hasTrackedParameter = false;
  for (const auto &fieldList : paths) if (!fieldList.empty()) hasTrackedParameter = true;
  if (!hasTrackedParameter) return summary;
  std::map<std::string, unsigned> localCounts;
  collectThreadHandleNames(fn->node->c[0].get(), localCounts);
  for (size_t i = 0; i < fn->node->params.size(); ++i) {
    const Param &param = fn->node->params[i];
    if (paths[i].empty()) continue;
    if (localCounts.count(param.name) || threadFunctionLocalShadows(fn->node->c[0].get(), param.name) ||
        threadStructParameterEscapes(fn->node->c[0].get(), param.name, fn->module, fn->node->c[0].get())) {
      for (const std::string &field : paths[i]) initial[param.name + "." + field] = kThreadHandleUnknown;
    }
  }
  const std::string previousModule = threadJoinAnalysisModule();
  Node *previousBody = threadJoinAnalysisOwnerBody();
  threadJoinAnalysisModule() = fn->module;
  threadJoinAnalysisOwnerBody() = fn->node->c[0].get();
  ThreadHandleFlowResult flow = analyzeThreadHandleFlow(fn->node->c[0].get(), initial);
  std::vector<ThreadHandleFlowState> exits = flow.exits;
  if (flow.fallsThrough) exits.push_back(flow.fall);
  ThreadHandleFlowState finalState = mergeThreadHandleStates(exits, initial);
  threadJoinAnalysisModule() = previousModule;
  threadJoinAnalysisOwnerBody() = previousBody;
  for (size_t i = 0; i < fn->node->params.size(); ++i) {
    const Param &param = fn->node->params[i];
    for (size_t j = 0; j < paths[i].size(); ++j)
      summary[i][j] = summarizeThreadHandleBits(finalState[param.name + "." + paths[i][j]]);
  }
  return summary;
}
void collectThreadJoinStructSummaryDependencies(
    Node *node, FuncInfo *caller, Node *ownerBody,
    std::map<FuncInfo *, std::set<FuncInfo *>> &dependents) {
  if (!node || node->k == NK::Lambda || !caller || !ownerBody) return;
  if (node->k == NK::Call) {
    const auto targets = resolveThreadJoinStructHelper(node, caller->module, ownerBody);
    if (targets.size() == 1) dependents[targets.front()].insert(caller);
  }
  for (auto &child : node->c)
    collectThreadJoinStructSummaryDependencies(child.get(), caller, ownerBody, dependents);
  for (auto &cs : node->cases) {
    collectThreadJoinStructSummaryDependencies(cs.guard.get(), caller, ownerBody, dependents);
    collectThreadJoinStructSummaryDependencies(cs.body.get(), caller, ownerBody, dependents);
    collectThreadJoinStructSummaryDependencies(cs.exprBody.get(), caller, ownerBody, dependents);
  }
  collectThreadJoinStructSummaryDependencies(node->deflt.get(), caller, ownerBody, dependents);
}
void buildThreadJoinStructFunctionSummaries() {
  auto &summaries = threadJoinStructFunctionSummaries();
  summaries.clear();
  std::vector<FuncInfo *> eligible;
  size_t summarySlots = 0;
  for (FuncInfo *fn : allFuncs) {
    if (!fn || !fn->node || fn->node->c.empty() || fn->isExtern || fn->isAbstract ||
        fn->isMethod || fn->generic || fn->variadic) continue;
    bool hasStructHandleParam = false;
    std::vector<std::vector<ThreadJoinDisposition>> initial(fn->node->params.size());
    for (size_t i = 0; i < fn->node->params.size(); ++i) {
      std::string typeName;
      if (!threadHandleStructType(fn->node->params[i].ts, typeName)) continue;
      std::vector<std::string> fields = threadHandleStructFieldPaths(typeName);
      if (fields.empty()) continue;
      hasStructHandleParam = true;
      initial[i].assign(fields.size(), ThreadJoinDisposition::Unknown);
      summarySlots += fields.size();
    }
    if (!hasStructHandleParam) continue;
    eligible.push_back(fn);
    summaries[fn] = std::move(initial);
  }
  if (eligible.empty()) return;

  // Build reverse call dependencies once. When a callee's field effects become
  // more precise, only callers that can consume that summary are re-analyzed.
  // This removes V77's 32-round ceiling without rescanning unrelated helpers.
  std::map<FuncInfo *, std::set<FuncInfo *>> dependents;
  for (FuncInfo *fn : eligible)
    collectThreadJoinStructSummaryDependencies(fn->node->c[0].get(), fn,
                                               fn->node->c[0].get(), dependents);

  std::deque<FuncInfo *> worklist(eligible.begin(), eligible.end());
  std::set<FuncInfo *> queued(eligible.begin(), eligible.end());
  // Each field summary has a small finite effect domain. Keep a generous
  // deterministic work budget as a final guard against unexpected oscillation;
  // exhausting it discards every partial result and fails closed as Unknown.
  const size_t maxEvaluations = std::max<size_t>(eligible.size(), 1) *
      std::max<size_t>(summarySlots, 1) * 8 + eligible.size();
  size_t evaluations = 0;
  while (!worklist.empty() && evaluations < maxEvaluations) {
    FuncInfo *fn = worklist.front();
    worklist.pop_front();
    queued.erase(fn);
    ++evaluations;
    auto candidate = analyzeThreadJoinStructFunctionSummary(fn);
    auto current = summaries.find(fn);
    if (current == summaries.end() || candidate == current->second) continue;
    current->second = std::move(candidate);
    auto callers = dependents.find(fn);
    if (callers == dependents.end()) continue;
    for (FuncInfo *caller : callers->second)
      if (caller && queued.insert(caller).second) worklist.push_back(caller);
  }
  if (!worklist.empty()) {
    for (auto &entry : summaries)
      for (auto &parameter : entry.second)
        std::fill(parameter.begin(), parameter.end(), ThreadJoinDisposition::Unknown);
  }
}
void applyThreadJoinCalls(Node *n, ThreadHandleFlowState &state) {
  if (!n || n->k == NK::Lambda) return;
  if (n->k == NK::Call) {
    const std::string path = threadCallPath(n);
    if (path == "move") return; // ownership transfer is handled by the enclosing declaration/assignment
    if (path == "thread.cancel" || path == "thread.isDone" || path == "thread.isCancelled") return;
    if (path == "thread.join") {
      if (n->c.size() > 1) {
        const std::string key = threadHandleExprKey(n->c[1].get());
        if (!key.empty()) applyThreadJoinStateEffect(state, key, ThreadJoinDisposition::MustJoin);
      }
      return;
    }
    bool hasTrackedHandleArg = false;
    for (size_t i = 1; i < n->c.size(); ++i) {
      Node *arg = n->c[i].get();
      std::string key = threadHandleExprKey(arg);
      if (key.empty()) key = threadHandleMoveSourceKey(arg);
      if (key.empty()) continue;
      if (state.count(key)) {
        hasTrackedHandleArg = true;
        continue;
      }
      if (!hasThreadHandleSubtree(state, key)) continue;
      bool summaryUsable = false;
      auto candidates = resolveThreadJoinStructHelper(n, threadJoinAnalysisModule(), threadJoinAnalysisOwnerBody());
      if (candidates.size() == 1) {
        auto summary = threadJoinStructFunctionSummaries().find(candidates.front());
        if (summary != threadJoinStructFunctionSummaries().end() &&
            i - 1 < summary->second.size()) {
          std::string actualType;
          if (threadHandleStructTypeForExpr(threadJoinAnalysisOwnerBody(), arg, actualType)) {
            std::vector<std::string> fields = threadHandleStructFieldPaths(actualType);
            const auto &effects = summary->second[i - 1];
            if (effects.size() == fields.size()) {
              for (size_t j = 0; j < fields.size(); ++j)
                applyThreadJoinStateEffect(state, key + "." + fields[j], effects[j]);
              summaryUsable = true;
            }
          }
        }
      }
      if (!summaryUsable) markThreadHandleSubtreeUnknown(state, key);
    }
    if (hasTrackedHandleArg) {
      const auto candidates = resolveThreadJoinHelper(n, threadJoinAnalysisModule(), state);
      bool summaryUsable = candidates.size() == 1;
      auto summary = summaryUsable ? threadJoinFunctionSummaries().find(candidates.front()) :
                                     threadJoinFunctionSummaries().end();
      summaryUsable = summaryUsable && summary != threadJoinFunctionSummaries().end() &&
                      summary->second.size() == n->c.size() - 1;
      for (size_t i = 1; i < n->c.size(); ++i) {
        std::string key = threadHandleExprKey(n->c[i].get());
        if (key.empty()) key = threadHandleMoveSourceKey(n->c[i].get());
        if (key.empty() || !state.count(key)) continue;
        ThreadJoinDisposition effect = ThreadJoinDisposition::Unknown;
        if (summaryUsable) effect = summary->second[i - 1];
        applyThreadJoinStateEffect(state, key, effect);
      }
    }
  }
  for (auto &child : n->c) applyThreadJoinCalls(child.get(), state);
  for (auto &cs : n->cases) {
    applyThreadJoinCalls(cs.guard.get(), state);
    applyThreadJoinCalls(cs.body.get(), state);
    applyThreadJoinCalls(cs.exprBody.get(), state);
  }
  applyThreadJoinCalls(n->deflt.get(), state);
}
void markThreadHandlesUnknown(ThreadHandleFlowState &state) {
  for (auto &entry : state) entry.second = kThreadHandleUnknown;
}
void markThreadHandleSubtreeUnknown(ThreadHandleFlowState &state, const std::string &root) {
  if (root.empty()) return;
  const std::string prefix = root + ".";
  for (auto &entry : state)
    if (entry.first.compare(0, prefix.size(), prefix) == 0) entry.second = kThreadHandleUnknown;
}
// Recognize the language's explicit move(expr) form for thread-handle flow.
// Unlike a plain assignment, this transfers the tracked state and leaves the
// source uninitialized. Only exact local paths present in the flow map qualify.
std::string threadHandleMoveSourceKey(Node *expr) {
  if (!expr || expr->k != NK::Call || threadCallPath(expr) != "move" || expr->c.size() != 2)
    return {};
  return threadHandleExprKey(expr->c[1].get());
}
bool hasThreadHandleSubtree(const ThreadHandleFlowState &state, const std::string &root) {
  if (root.empty()) return false;
  const std::string prefix = root + ".";
  for (const auto &entry : state)
    if (entry.first.compare(0, prefix.size(), prefix) == 0) return true;
  return false;
}
void transferThreadHandlePath(ThreadHandleFlowState &state, const std::string &source,
                              const std::string &target) {
  if (source.empty() || target.empty() || source == target) return;
  auto direct = state.find(source);
  if (direct != state.end()) {
    auto destination = state.find(target);
    if (destination != state.end()) destination->second = direct->second;
    direct->second = kThreadHandleNotStarted;
  }
  const std::string sourcePrefix = source + ".";
  const std::string targetPrefix = target + ".";
  std::vector<std::pair<std::string, unsigned>> moved;
  for (const auto &entry : state) {
    if (entry.first.compare(0, sourcePrefix.size(), sourcePrefix) == 0)
      moved.push_back({targetPrefix + entry.first.substr(sourcePrefix.size()), entry.second});
  }
  for (const auto &entry : moved) {
    auto destination = state.find(entry.first);
    if (destination != state.end()) destination->second = entry.second;
  }
  for (auto &entry : state)
    if (entry.first.compare(0, sourcePrefix.size(), sourcePrefix) == 0)
      entry.second = kThreadHandleNotStarted;
}
ThreadHandleFlowState mergeThreadHandleStates(const std::vector<ThreadHandleFlowState> &states,
                                               const ThreadHandleFlowState &fallback) {
  ThreadHandleFlowState merged = fallback;
  if (states.empty()) return merged;
  for (auto &entry : merged) entry.second = 0;
  for (const auto &state : states)
    for (const auto &entry : state) merged[entry.first] |= entry.second;
  for (auto &entry : merged) if (!entry.second) entry.second = kThreadHandleUnknown;
  return merged;
}
ThreadHandleFlowResult analyzeThreadHandleFlow(Node *n, const ThreadHandleFlowState &input) {
  ThreadHandleFlowResult result; result.fall = input;
  if (!n) return result;
  if (n->k == NK::Block) {
    ThreadHandleFlowState state = input;
    for (const auto &stmt : n->c) {
      if (!result.fallsThrough) break;
      ThreadHandleFlowResult step = analyzeThreadHandleFlow(stmt.get(), state);
      result.exits.insert(result.exits.end(), step.exits.begin(), step.exits.end());
      result.fallsThrough = step.fallsThrough;
      state = step.fall;
    }
    result.fall = state;
    return result;
  }
  if (n->k == NK::VarDecl) {
    auto it = result.fall.find(n->s);
    const std::string movedSource = n->c.empty() ? std::string{} : threadHandleMoveSourceKey(n->c[0].get());
    if (it != result.fall.end()) {
      if (!movedSource.empty() && hasThreadHandleSubtree(result.fall, movedSource))
        transferThreadHandlePath(result.fall, movedSource, n->s);
      else if (!n->c.empty() && isThreadStartCall(n->c[0].get())) it->second = kThreadHandleLive;
      else if (!n->c.empty()) it->second = kThreadHandleUnknown;
      else it->second = kThreadHandleNotStarted;
    }
    if (isThreadHandleStructDecl(n)) {
      const std::string prefix = n->s + ".";
      for (auto &entry : result.fall) if (entry.first.compare(0, prefix.size(), prefix) == 0)
        entry.second = n->c.empty() ? kThreadHandleNotStarted : kThreadHandleUnknown;
      if (!movedSource.empty() && result.fall.count(movedSource))
        transferThreadHandlePath(result.fall, movedSource, n->s);
    }
    if (!n->c.empty()) {
      const std::string sourceKey = threadHandleExprKey(n->c[0].get());
      if (movedSource.empty() && !sourceKey.empty() && result.fall.count(sourceKey)) result.fall[sourceKey] = kThreadHandleUnknown;
      if (movedSource.empty() && isThreadHandleStructDecl(n) && !sourceKey.empty())
        markThreadHandleSubtreeUnknown(result.fall, sourceKey); // value copies duplicate opaque handle bits
      applyThreadJoinCalls(n->c[0].get(), result.fall);
    }
    return result;
  }
  if (n->k == NK::ExprStmt && !n->c.empty()) {
    Node *expr = n->c[0].get();
    if (expr && expr->k == NK::Assign && expr->c.size() > 1 && expr->c[0]) {
      const std::string targetKey = threadHandleExprKey(expr->c[0].get());
      const std::string movedSource = threadHandleMoveSourceKey(expr->c[1].get());
      const std::string sourceKey = movedSource.empty() ? threadHandleExprKey(expr->c[1].get()) : movedSource;
      auto target = result.fall.find(targetKey);
      if (!movedSource.empty() && !targetKey.empty() &&
          (result.fall.count(movedSource) || hasThreadHandleSubtree(result.fall, movedSource))) {
        transferThreadHandlePath(result.fall, movedSource, targetKey);
      } else {
        if (target != result.fall.end())
          target->second = isThreadStartCall(expr->c[1].get()) ? kThreadHandleLive : kThreadHandleUnknown;
        if (!sourceKey.empty() && result.fall.count(sourceKey) && sourceKey != targetKey)
          result.fall[sourceKey] = kThreadHandleUnknown; // copies/aliases are not ownership transfers
        // Value-struct copies may duplicate nested handle fields even though the
        // aggregate itself is not a tracked handle key. Invalidate both owners.
        if (!sourceKey.empty() && sourceKey != targetKey) {
          markThreadHandleSubtreeUnknown(result.fall, sourceKey);
          markThreadHandleSubtreeUnknown(result.fall, targetKey);
        }
        // Assignment into an untracked destination also escapes the tracked handle.
        if (!sourceKey.empty() && result.fall.count(sourceKey) && target == result.fall.end())
          result.fall[sourceKey] = kThreadHandleUnknown;
      }
    }
    applyThreadJoinCalls(expr, result.fall);
    return result;
  }
  if (n->k == NK::If && n->c.size() >= 2) {
    ThreadHandleFlowResult yes = analyzeThreadHandleFlow(n->c[1].get(), input);
    ThreadHandleFlowResult no;
    if (n->c.size() > 2 && n->c[2]) no = analyzeThreadHandleFlow(n->c[2].get(), input);
    else no.fall = input;
    result.exits = yes.exits;
    result.exits.insert(result.exits.end(), no.exits.begin(), no.exits.end());
    std::vector<ThreadHandleFlowState> falls;
    if (yes.fallsThrough) falls.push_back(yes.fall);
    if (no.fallsThrough) falls.push_back(no.fall);
    result.fallsThrough = !falls.empty();
    result.fall = mergeThreadHandleStates(falls, input);
    return result;
  }
  if (n->k == NK::For || n->k == NK::ForPP || n->k == NK::ForEach ||
      n->k == NK::While || n->k == NK::DoWhile) {
    ThreadHandleFlowState loopInput = input;
    size_t bodyIndex = n->k == NK::For ? 3 : (n->k == NK::ForEach || n->k == NK::ForPP ? 1 : (n->k == NK::DoWhile ? 0 : 1));
    if (n->k == NK::For && !n->c.empty() && n->c[0]) {
      ThreadHandleFlowResult init = analyzeThreadHandleFlow(n->c[0].get(), loopInput);
      loopInput = init.fall;
      result.exits.insert(result.exits.end(), init.exits.begin(), init.exits.end());
    }
    if (bodyIndex < n->c.size() && n->c[bodyIndex]) {
      ThreadHandleFlowResult body = analyzeThreadHandleFlow(n->c[bodyIndex].get(), loopInput);
      result.exits.insert(result.exits.end(), body.exits.begin(), body.exits.end());
      // A loop can execute zero or multiple times; union the entry and one
      // body iteration rather than claiming that a join inside it is certain.
      std::vector<ThreadHandleFlowState> candidates{loopInput};
      if (body.fallsThrough) candidates.push_back(body.fall);
      result.fall = mergeThreadHandleStates(candidates, loopInput);
    } else result.fall = loopInput;
    // Joins in loop headers/steps may execute zero or many times. Their exact
    // sequencing is intentionally not inferred by this one-iteration summary.
    std::vector<Node *> loopHeaders;
    if (n->k == NK::For) {
      if (n->c.size() > 1 && n->c[1]) loopHeaders.push_back(n->c[1].get());
      if (n->c.size() > 2 && n->c[2]) loopHeaders.push_back(n->c[2].get());
    } else if ((n->k == NK::While || n->k == NK::DoWhile) && n->c.size() > 1) {
      loopHeaders.push_back(n->c[n->k == NK::While ? 0 : 1].get());
    }
    for (Node *header : loopHeaders) {
      std::function<bool(Node *)> hasLifecycle = [&](Node *x) {
        if (!x || x->k == NK::Lambda) return false;
        const std::string path = x->k == NK::Call ? threadCallPath(x) : std::string{};
        if (path == "thread.join" || path == "thread.start") return true;
        for (auto &child : x->c) if (hasLifecycle(child.get())) return true;
        return false;
      };
      if (hasLifecycle(header)) markThreadHandlesUnknown(result.fall);
    }
    return result;
  }
  if (n->k == NK::Switch || n->k == NK::Match) {
    std::vector<ThreadHandleFlowState> falls;
    for (auto &cs : n->cases) {
      ThreadHandleFlowResult branch = analyzeThreadHandleFlow(cs.body.get(), input);
      result.exits.insert(result.exits.end(), branch.exits.begin(), branch.exits.end());
      if (branch.fallsThrough) falls.push_back(branch.fall);
    }
    if (n->deflt) {
      ThreadHandleFlowResult branch = analyzeThreadHandleFlow(n->deflt.get(), input);
      result.exits.insert(result.exits.end(), branch.exits.begin(), branch.exits.end());
      if (branch.fallsThrough) falls.push_back(branch.fall);
    } else falls.push_back(input);
    result.fallsThrough = !falls.empty();
    result.fall = mergeThreadHandleStates(falls, input);
    return result;
  }
  if (n->k == NK::Return) {
    if (!n->c.empty() && n->c[0]) {
      const std::string returnedKey = threadHandleExprKey(n->c[0].get());
      auto it = result.fall.find(returnedKey);
      if (it != result.fall.end()) it->second = kThreadHandleUnknown; // handle escapes to caller
      else markThreadHandleSubtreeUnknown(result.fall, returnedKey); // aggregate fields escape together
    }
    if (!n->c.empty()) applyThreadJoinCalls(n->c[0].get(), result.fall);
    result.exits.push_back(result.fall);
    result.fallsThrough = false;
    return result;
  }
  if (n->k == NK::Break || n->k == NK::Continue) {
    // Loop-exit/back-edge transfer is not modeled as a first-class CFG edge.
    markThreadHandlesUnknown(result.fall);
    return result;
  }
  if (n->k == NK::Throw) {
    if (!n->c.empty()) applyThreadJoinCalls(n->c[0].get(), result.fall);
    result.exits.push_back(result.fall);
    result.fallsThrough = false;
    return result;
  }
  if (n->k == NK::Try || n->k == NK::Defer) {
    // Defer/exception paths need precise cleanup edge semantics. If this
    // region starts or joins a tracked handle, keep the result explicitly unknown.
    std::set<std::string> mentioned;
    std::function<void(Node *)> findJoinNames = [&](Node *x) {
      if (!x || x->k == NK::Lambda) return;
      if (x->k == NK::Call && threadCallPath(x) == "thread.join" && x->c.size() > 1) {
        const std::string key = threadHandleExprKey(x->c[1].get());
        if (!key.empty()) mentioned.insert(key);
      }
      if (x->k == NK::VarDecl && isThreadHandleDecl(x) && !x->s.empty() && !x->c.empty() && isThreadStartCall(x->c[0].get()))
        mentioned.insert(x->s);
      if (x->k == NK::Assign && x->c.size() > 1 && isThreadStartCall(x->c[1].get())) {
        const std::string key = threadHandleExprKey(x->c[0].get());
        if (!key.empty()) mentioned.insert(key);
      }
      for (auto &child : x->c) findJoinNames(child.get());
      for (auto &cs : x->cases) {
        findJoinNames(cs.body.get());
        findJoinNames(cs.guard.get());
        findJoinNames(cs.exprBody.get());
      }
    };
    findJoinNames(n);
    for (const auto &name : mentioned) {
      if (result.fall.count(name)) result.fall[name] = kThreadHandleUnknown;
      else markThreadHandleSubtreeUnknown(result.fall, name);
    }
    return result;
  }
  if (n->k == NK::ExprStmt && !n->c.empty()) {
    std::function<bool(Node *)> hasPropagate = [&](Node *x) {
      if (!x || x->k == NK::Lambda) return false;
      if (x->k == NK::Propagate) return true;
      for (auto &child : x->c) if (hasPropagate(child.get())) return true;
      return false;
    };
    if (hasPropagate(n->c[0].get())) markThreadHandlesUnknown(result.fall);
  }
  applyThreadJoinCalls(n, result.fall);
  return result;
}
ThreadJoinDisposition summarizeThreadHandleBits(unsigned bits) {
  if (!bits || (bits & kThreadHandleUnknown)) return ThreadJoinDisposition::Unknown;
  const bool live = (bits & kThreadHandleLive) != 0;
  const bool joined = (bits & kThreadHandleJoined) != 0;
  if (live && joined) return ThreadJoinDisposition::Conditional;
  if (live) return ThreadJoinDisposition::MayOutlive;
  if (joined) return ThreadJoinDisposition::MustJoin;
  return ThreadJoinDisposition::Unknown;
}
std::vector<ThreadJoinDisposition> analyzeThreadJoinFunctionSummary(FuncInfo *fn) {
  std::vector<ThreadJoinDisposition> summary;
  if (!fn || !fn->node || fn->node->c.empty()) return summary;
  summary.resize(fn->node->params.size(), ThreadJoinDisposition::Unknown);
  ThreadHandleFlowState initial;
  std::set<std::string> parameterNames;
  for (size_t i = 0; i < fn->node->params.size(); ++i) {
    const Param &param = fn->node->params[i];
    if (param.ts.kind == "ptr" && param.ts.base == "thread" && !param.name.empty()) {
      initial[param.name] = kThreadHandleLive;
      parameterNames.insert(param.name);
    }
  }
  if (parameterNames.empty()) return summary;
  std::map<std::string, unsigned> localCounts;
  collectThreadHandleNames(fn->node->c[0].get(), localCounts);
  for (const std::string &name : parameterNames) {
    if (localCounts.count(name) || threadHandleParameterEscapes(fn->node->c[0].get(), name, fn->module))
      initial[name] = kThreadHandleUnknown;
  }
  const std::string previousModule = threadJoinAnalysisModule();
  Node *previousBody = threadJoinAnalysisOwnerBody();
  threadJoinAnalysisModule() = fn->module;
  threadJoinAnalysisOwnerBody() = fn->node->c[0].get();
  ThreadHandleFlowResult flow = analyzeThreadHandleFlow(fn->node->c[0].get(), initial);
  std::vector<ThreadHandleFlowState> exits = flow.exits;
  if (flow.fallsThrough) exits.push_back(flow.fall);
  ThreadHandleFlowState finalState = mergeThreadHandleStates(exits, initial);
  threadJoinAnalysisModule() = previousModule;
  threadJoinAnalysisOwnerBody() = previousBody;
  for (size_t i = 0; i < fn->node->params.size(); ++i) {
    const Param &param = fn->node->params[i];
    if (param.ts.kind == "ptr" && param.ts.base == "thread" && !param.name.empty())
      summary[i] = summarizeThreadHandleBits(finalState[param.name]);
  }
  return summary;
}
void buildThreadJoinFunctionSummaries() {
  auto &summaries = threadJoinFunctionSummaries();
  summaries.clear();
  std::vector<FuncInfo *> eligible;
  for (FuncInfo *fn : allFuncs) {
    if (!fn || !fn->node || fn->node->c.empty() || fn->isExtern || fn->isAbstract ||
        fn->isMethod || fn->generic || fn->variadic) continue;
    bool hasThreadParam = false;
    for (const Param &param : fn->node->params)
      if (param.ts.kind == "ptr" && param.ts.base == "thread") hasThreadParam = true;
    if (!hasThreadParam) continue;
    eligible.push_back(fn);
    summaries[fn] = std::vector<ThreadJoinDisposition>(fn->node->params.size(), ThreadJoinDisposition::Unknown);
  }
  // Bounded monotone iteration propagates direct-call summaries through helper
  // chains. Recursive or unresolved cycles stay Unknown when they do not settle.
  const size_t limit = std::min<size_t>(eligible.size() + 1, 32);
  for (size_t iteration = 0; iteration < limit; ++iteration) {
    bool changed = false;
    ThreadJoinFunctionSummaries next = summaries;
    for (FuncInfo *fn : eligible) {
      auto candidate = analyzeThreadJoinFunctionSummary(fn);
      auto old = summaries.find(fn);
      if (old != summaries.end() && candidate != old->second) {
        next[fn] = std::move(candidate);
        changed = true;
      }
    }
    summaries.swap(next);
    if (!changed) break;
  }
}
std::string resolveMovedThreadHandlePath(Node *ownerBody, const std::string &launchPath) {
  std::vector<std::pair<std::string, std::string>> transfers;
  std::function<void(Node *)> collect = [&](Node *node) {
    if (!node || node->k == NK::Lambda) return;
    if (node->k == NK::Assign && node->c.size() > 1) {
      const std::string target = threadHandleExprKey(node->c[0].get());
      const std::string source = threadHandleMoveSourceKey(node->c[1].get());
      if (!target.empty() && !source.empty()) transfers.push_back({source, target});
    } else if (node->k == NK::VarDecl && !node->c.empty()) {
      const std::string source = threadHandleMoveSourceKey(node->c[0].get());
      if (!source.empty() && !node->s.empty()) transfers.push_back({source, node->s});
    }
    for (auto &child : node->c) collect(child.get());
    for (auto &cs : node->cases) { collect(cs.guard.get()); collect(cs.body.get()); collect(cs.exprBody.get()); }
    collect(node->deflt.get());
  };
  collect(ownerBody);
  std::string resolved = launchPath;
  for (size_t pass = 0; pass < transfers.size() + 1; ++pass) {
    bool changed = false;
    for (const auto &transfer : transfers) {
      const std::string &source = transfer.first;
      if (resolved == source || (resolved.size() > source.size() &&
          resolved.compare(0, source.size(), source) == 0 && resolved[source.size()] == '.')) {
        resolved = transfer.second + resolved.substr(source.size());
        changed = true;
      }
    }
    if (!changed) break;
  }
  return resolved;
}
std::map<std::string, ThreadJoinDisposition> analyzeThreadHandleJoins(Node *ownerBody) {
  std::map<std::string, unsigned> counts;
  collectThreadHandleNames(ownerBody, counts);
  ThreadHandleFlowState initial;
  for (const auto &entry : counts) initial[entry.first] = entry.second > 1 ? kThreadHandleUnknown : kThreadHandleNotStarted;
  ThreadHandleFlowResult flow = analyzeThreadHandleFlow(ownerBody, initial);
  std::vector<ThreadHandleFlowState> exits = flow.exits;
  if (flow.fallsThrough) exits.push_back(flow.fall);
  ThreadHandleFlowState finalState = mergeThreadHandleStates(exits, initial);
  std::map<std::string, ThreadJoinDisposition> result;
  for (const auto &entry : counts) {
    const unsigned bits = finalState[entry.first];
    if (entry.second > 1 || (bits & kThreadHandleUnknown)) result[entry.first] = ThreadJoinDisposition::Unknown;
    else if (bits & kThreadHandleLive) {
      result[entry.first] = (bits & kThreadHandleJoined) ? ThreadJoinDisposition::Conditional : ThreadJoinDisposition::MayOutlive;
    } else if (bits & kThreadHandleJoined) result[entry.first] = ThreadJoinDisposition::MustJoin;
    else result[entry.first] = ThreadJoinDisposition::NotTracked;
  }
  return result;
}
std::string summarizeWholeProgramWorkerRegistry(const ThreadWorkerRegistry &registry) {
  if (!registry.built || registry.workers.empty()) return {};
  using Edge = std::tuple<uintptr_t, uintptr_t, uintptr_t, uintptr_t>;
  std::map<std::string, std::vector<std::pair<const ThreadWorkerRegistryEntry *, const ThreadStorageEffect *>>> byStorage;
  std::set<uintptr_t> templates, sites;
  std::set<std::string> modules;
  std::set<std::pair<uintptr_t, std::string>> bindings;
  size_t unresolved = 0, callPaths = 0;
  for (const auto &worker : registry.workers) {
    if (worker.site.call) sites.insert(reinterpret_cast<uintptr_t>(worker.site.call));
    modules.insert(worker.site.module);
    if (worker.unresolved) ++unresolved;
    if (worker.site.closure) templates.insert(reinterpret_cast<uintptr_t>(worker.site.closure));
    std::set<std::string> paths;
    for (const auto &global : worker.effects.globals) {
      byStorage[global.first].push_back({&worker, &global.second});
      bindings.insert({reinterpret_cast<uintptr_t>(worker.site.call), global.first});
      if (!global.second.via.empty()) paths.insert(global.second.via);
      for (const auto &event : global.second.atomicEvents)
        if (!event.callPath.empty()) paths.insert(event.callPath);
    }
    callPaths += paths.size();
  }
  std::set<Edge> crossReadFrom, crossReleaseAcquire, parallelReadFrom, parallelReleaseAcquire;
  std::set<Edge> crossCasFailure, parallelCasFailure;
  std::set<std::pair<uintptr_t, uintptr_t>> ordinaryConflicts, parallelOrdinaryConflicts;
  std::set<std::string> sharedStorages, parallelSelfStorages;
  size_t multiplicityPerActivation = 0, multiplicityLoopRepeatable = 0;
  size_t multiplicityParallelReplicated = 0, multiplicityUnknown = 0;
  size_t joinMust = 0, joinMayOutlive = 0, joinConditional = 0;
  size_t joinUnknown = 0, joinUntracked = 0, joinRuntime = 0;
  for (const auto &worker : registry.workers) {
    switch (worker.multiplicity) {
      case ThreadWorkerMultiplicity::PerActivation: ++multiplicityPerActivation; break;
      case ThreadWorkerMultiplicity::LoopRepeatable: ++multiplicityLoopRepeatable; break;
      case ThreadWorkerMultiplicity::ParallelReplicated: ++multiplicityParallelReplicated; break;
      default: ++multiplicityUnknown; break;
    }
    switch (worker.join) {
      case ThreadJoinDisposition::MustJoin: ++joinMust; break;
      case ThreadJoinDisposition::MayOutlive: ++joinMayOutlive; break;
      case ThreadJoinDisposition::Conditional: ++joinConditional; break;
      case ThreadJoinDisposition::Unknown: ++joinUnknown; break;
      case ThreadJoinDisposition::RuntimeJoined: ++joinRuntime; break;
      default: ++joinUntracked; break;
    }
  }
  auto releaseCapable = [](const ThreadAtomicEvent &event) {
    return event.writes && (event.writeOrder == "release" || event.writeOrder == "acq_rel" ||
                            event.writeOrder == "seq_cst");
  };
  auto acquireCapable = [](const ThreadAtomicEvent &event) {
    return event.reads && (event.readOrder == "acquire" || event.readOrder == "acq_rel" ||
                           event.readOrder == "seq_cst");
  };
  auto failureAcquireCapable = [](const ThreadAtomicEvent &event) {
    return event.compareExchange && (event.failureOrder == "acquire" ||
        event.failureOrder == "acq_rel" || event.failureOrder == "seq_cst");
  };
  for (const auto &storage : byStorage) {
    const auto &owners = storage.second;
    std::set<uintptr_t> storageSites;
    std::vector<std::pair<const ThreadWorkerRegistryEntry *, const ThreadAtomicEvent *>> events;
    for (const auto &owner : owners) {
      const auto *worker = owner.first;
      storageSites.insert(reinterpret_cast<uintptr_t>(worker->site.call));
      for (const auto &event : owner.second->atomicEvents) events.push_back({worker, &event});
    }
    if (storageSites.size() > 1) sharedStorages.insert(storage.first);
    // A parallelFor callback is replicated by the runtime across worker
    // threads. Distinct atomic sites in that one template can therefore be
    // candidate peers even though they share one static API call site.
    for (const auto &owner : owners) if (owner.first->site.api == "thread.parallelFor") {
      const auto &workerEvents = owner.second->atomicEvents;
      for (const auto &write : workerEvents) if (write.writes)
        for (const auto &read : workerEvents) if (read.reads && write.site != read.site) {
          sharedStorages.insert(storage.first);
          parallelSelfStorages.insert(storage.first);
        }
      if (owner.second->write && (owner.second->read || owner.second->write)) {
        const uintptr_t site = reinterpret_cast<uintptr_t>(owner.first->site.call);
        parallelOrdinaryConflicts.insert({site, site});
        sharedStorages.insert(storage.first);
        parallelSelfStorages.insert(storage.first);
      }
    }
    for (size_t i = 0; i < owners.size(); ++i) {
      for (size_t j = i + 1; j < owners.size(); ++j) {
        const auto *a = owners[i].first;
        const auto *b = owners[j].first;
        const bool sameSite = a->site.call == b->site.call;
        const bool parallelSelf = sameSite && a->site.api == "thread.parallelFor";
        if (sameSite && !parallelSelf) continue;
        const bool conflict = (owners[i].second->write && (owners[j].second->read || owners[j].second->write)) ||
                              (owners[j].second->write && (owners[i].second->read || owners[i].second->write));
        if (conflict) {
          const uintptr_t x = reinterpret_cast<uintptr_t>(a->site.call);
          const uintptr_t y = reinterpret_cast<uintptr_t>(b->site.call);
          if (parallelSelf) parallelOrdinaryConflicts.insert({x, y});
          else ordinaryConflicts.insert({std::min(x, y), std::max(x, y)});
        }
        if (parallelSelf && conflict) parallelSelfStorages.insert(storage.first);
      }
    }
    for (const auto &writeRef : events) {
      const ThreadAtomicEvent &write = *writeRef.second;
      if (!write.writes) continue;
      for (const auto &readRef : events) {
        const ThreadAtomicEvent &read = *readRef.second;
        if (!read.reads || (write.site == read.site && write.workerSite == read.workerSite)) continue;
        const bool sameSite = writeRef.first->site.call == readRef.first->site.call;
        const bool parallelSelf = sameSite && writeRef.first->site.api == "thread.parallelFor";
        if (sameSite && !parallelSelf) continue;
        const Edge edge{write.workerSite, write.site, read.workerSite, read.site};
        if (parallelSelf) parallelReadFrom.insert(edge);
        else crossReadFrom.insert(edge);
        if (releaseCapable(write) && acquireCapable(read)) {
          if (parallelSelf) parallelReleaseAcquire.insert(edge);
          else crossReleaseAcquire.insert(edge);
        }
        if (releaseCapable(write) && failureAcquireCapable(read)) {
          if (parallelSelf) parallelCasFailure.insert(edge);
          else crossCasFailure.insert(edge);
        }
      }
    }
  }
  return "whole-program-worker-registry workers=" + std::to_string(sites.size()) +
      " templates=" + std::to_string(templates.size()) +
      " modules=" + std::to_string(modules.size()) +
      " storage-bindings=" + std::to_string(bindings.size()) +
      " shared-storages=" + std::to_string(sharedStorages.size()) +
      " cross-worker-read-from-candidates=" + std::to_string(crossReadFrom.size()) +
      " cross-worker-release-acquire-candidates=" + std::to_string(crossReleaseAcquire.size()) +
      " cross-worker-cas-failure-acquire-candidates=" + std::to_string(crossCasFailure.size()) +
      " parallelFor-self-read-from-candidates=" + std::to_string(parallelReadFrom.size()) +
      " parallelFor-self-release-acquire-candidates=" + std::to_string(parallelReleaseAcquire.size()) +
      " parallelFor-self-cas-failure-acquire-candidates=" + std::to_string(parallelCasFailure.size()) +
      " possible-ordinary-conflict-pairs=" + std::to_string(ordinaryConflicts.size() + parallelOrdinaryConflicts.size()) +
      " parallelFor-self-conflict-storages=" + std::to_string(parallelSelfStorages.size()) +
      " unresolved-sites=" + std::to_string(unresolved) +
      " call-paths=" + std::to_string(callPaths) +
      " join-summary-functions=" + std::to_string(threadJoinFunctionSummaries().size()) +
      " join-struct-summary-functions=" + std::to_string(threadJoinStructFunctionSummaries().size()) +
      " (candidate-only; joins, runtime thread identity, alias equivalence and actual read-from are unresolved)" +
      " multiplicity{per-activation=" + std::to_string(multiplicityPerActivation) +
      ",loop-repeatable=" + std::to_string(multiplicityLoopRepeatable) +
      ",parallel-replicated=" + std::to_string(multiplicityParallelReplicated) +
      ",unknown=" + std::to_string(multiplicityUnknown) + "}" +
      " join{must-join=" + std::to_string(joinMust) +
      ",may-outlive=" + std::to_string(joinMayOutlive) +
      ",conditional=" + std::to_string(joinConditional) +
      ",unknown=" + std::to_string(joinUnknown) +
      ",untracked=" + std::to_string(joinUntracked) +
      ",runtime-joined=" + std::to_string(joinRuntime) + "}";
}
void buildWholeProgramWorkerRegistry() {
  ThreadWorkerRegistry &registry = wholeProgramWorkerRegistry();
  if (registry.built) return;
  registry.built = true;
  std::vector<ThreadWorkerSiteInfo> sites;
  std::set<Node *> seenCalls, seenBodies;
  for (FuncInfo *fn : allFuncs) {
    if (!fn || !fn->node || fn->node->c.empty() || fn->isExtern || fn->isAbstract) continue;
    if (trustedModules.count(fn->module) && safeEnforced()) continue;
    Node *body = fn->node->c[0].get();
    if (!body || !seenBodies.insert(body).second) continue;
    const std::string owner = fn->structName.empty() ? fn->module + "." + fn->name :
        fn->structName + "::" + fn->name;
    collectThreadWorkerSites(body, fn->module, owner, body, sites, seenCalls);
  }
  // Global initializer expressions are compiled into per-module init functions
  // and are not represented by ordinary FuncInfo entries.
  for (Program *program : progs) if (program) {
    for (const auto &global : program->globals)
      collectThreadWorkerSites(global.get(), program->module, program->module + ".<global-init>", global.get(), sites, seenCalls);
    for (const auto &decl : program->structs) if (decl) {
      for (const auto &field : decl->c) if (field && field->isStatic)
        collectThreadWorkerSites(field.get(), program->module, decl->s + ".<static-init>", field.get(), sites, seenCalls);
    }
  }
  const std::string savedModule = curModule;
  const auto savedImports = curImports;
  buildThreadJoinFunctionSummaries();
  buildThreadJoinStructFunctionSummaries();
  std::map<Node *, std::map<std::string, ThreadJoinDisposition>> ownerJoinFlows;
  for (const ThreadWorkerSiteInfo &site : sites) {
    if (site.api == "thread.parallelFor" || !site.ownerBody ||
        site.owner.find("<global-init>") != std::string::npos ||
        site.owner.find("<static-init>") != std::string::npos) continue;
    if (!ownerJoinFlows.count(site.ownerBody)) {
      const std::string previousModule = threadJoinAnalysisModule();
      Node *previousBody = threadJoinAnalysisOwnerBody();
      threadJoinAnalysisModule() = site.module;
      threadJoinAnalysisOwnerBody() = site.ownerBody;
      ownerJoinFlows[site.ownerBody] = analyzeThreadHandleJoins(site.ownerBody);
      threadJoinAnalysisModule() = previousModule;
      threadJoinAnalysisOwnerBody() = previousBody;
    }
  }
  for (const ThreadWorkerSiteInfo &site : sites) {
    ThreadWorkerRegistryEntry entry;
    entry.site = site;
    if (site.api == "thread.parallelFor") {
      entry.multiplicity = ThreadWorkerMultiplicity::ParallelReplicated;
      entry.join = ThreadJoinDisposition::RuntimeJoined;
    } else if (site.loopDepth) entry.multiplicity = ThreadWorkerMultiplicity::LoopRepeatable;
    else entry.multiplicity = ThreadWorkerMultiplicity::PerActivation;
    if (site.api == "thread.start") {
      if (site.handleName.empty()) entry.join = ThreadJoinDisposition::NotTracked;
      else {
        auto owner = ownerJoinFlows.find(site.ownerBody);
        if (owner == ownerJoinFlows.end()) entry.join = ThreadJoinDisposition::Unknown;
        else {
          const std::string resolvedHandle = resolveMovedThreadHandlePath(site.ownerBody, site.handleName);
          auto handle = owner->second.find(resolvedHandle);
          entry.join = handle == owner->second.end() ? ThreadJoinDisposition::Unknown : handle->second;
        }
      }
    }
    if (!site.closure || site.closure->k != NK::Lambda || site.closure->c.empty()) {
      entry.multiplicity = ThreadWorkerMultiplicity::Unknown;
      if (site.api == "thread.start") entry.join = ThreadJoinDisposition::Unknown;
      entry.unresolved = true;
      entry.problem = "worker callback is not a direct lambda";
      registry.workers.push_back(std::move(entry));
      continue;
    }
    curModule = site.module;
    curImports = modImports[curModule];
    std::set<std::string> params;
    for (const auto &param : site.closure->params) params.insert(param.name);
    std::map<Node *, std::set<std::string>> seen;
    entry.problem = scanSharedState(site.closure->c[0].get(), params, site.module, seen, 0,
                                    &entry.effects, site.owner, {}, site.closure, site.call);
    // A diagnosed mutable-global touch is a known effect, not an analysis
    // failure. Other scan failures (unknown aliases/lock flow/depth limits)
    // remain explicitly unresolved while retaining any effects already found.
    entry.unresolved = (!entry.problem.empty() &&
                        entry.problem.rfind("แตะตัวแปร global", 0) != 0) ||
                       entry.effects.unknownAlias || entry.effects.unknownLockFlow;
    registry.workers.push_back(std::move(entry));
  }
  curModule = savedModule;
  curImports = savedImports;
  registry.summary = summarizeWholeProgramWorkerRegistry(registry);
}

// In strict mode, a thread closure may not invoke a function value whose body
// cannot be statically followed. This closes the indirect-call hole without
// pretending that an arbitrary function pointer can be proven race-free.
void collectFunctionValueDecls(Node *n, std::set<std::string> &names) {
  if (!n) return;
  if (n->k == NK::VarDecl && !n->s.empty() &&
      (n->ts.cat == "func" || (!n->c.empty() && n->c[0] && n->c[0]->k == NK::Lambda)))
    names.insert(n->s);
  for (auto &c : n->c) collectFunctionValueDecls(c.get(), names);
  for (auto &cs : n->cases) {
    collectFunctionValueDecls(cs.guard.get(), names);
    collectFunctionValueDecls(cs.body.get(), names);
    collectFunctionValueDecls(cs.exprBody.get(), names);
  }
  collectFunctionValueDecls(n->deflt.get(), names);
}
std::string scanIndirectCallsStrict(Node *body, const std::string &mod) {
  if (!body) return "";
  std::set<std::string> localFunctionValues;
  collectFunctionValueDecls(body, localFunctionValues);
  std::vector<Node *> calls; collectCalls(body, calls);
  for (Node *call : calls) {
    if (!call || call->k != NK::Call || call->c.empty()) continue;
    Node *callee = call->c[0].get();
    if (callee->k == NK::Ident) {
      const std::string &name = callee->s;
      if (localFunctionValues.count(name))
        return "เรียก function value '" + name + "' ซึ่งไม่สามารถตรวจ call target ได้ (--strict-safe)";
      auto gm = globalVars.find(mod);
      if (gm != globalVars.end()) {
        auto gv = gm->second.find(name);
        if (gv != gm->second.end() && gv->second.ty && gv->second.ty->k == FUNC)
          return "เรียก global function value '" + name + "' ซึ่งไม่สามารถตรวจ call target ได้ (--strict-safe)";
      }
      auto imports = modGlobalImports.find(mod);
      if (imports != modGlobalImports.end()) for (const std::string &im : imports->second) {
        auto ig = globalVars.find(im);
        if (ig == globalVars.end()) continue;
        auto gv = ig->second.find(name);
        if (gv != ig->second.end() && gv->second.ty && gv->second.ty->k == FUNC)
          return "เรียก imported function value '" + name + "' ซึ่งไม่สามารถตรวจ call target ได้ (--strict-safe)";
      }
    } else if (callee->k == NK::Member) {
      // Module-qualified global function values (including aliases).
      if (!callee->c.empty() && callee->c[0]->k == NK::Ident) {
        std::string provider = callee->c[0]->s;
        auto alias = modImportAliases[mod].find(provider);
        if (alias != modImportAliases[mod].end()) provider = alias->second;
        auto gm = globalVars.find(provider);
        if (gm != globalVars.end()) {
          auto gv = gm->second.find(callee->s);
          if (gv != gm->second.end() && gv->second.ty && gv->second.ty->k == FUNC)
            return "เรียก module function value '" + provider + "." + callee->s + "' ซึ่งไม่สามารถตรวจ call target ได้ (--strict-safe)";
        }
        auto sit = structs.find(callee->c[0]->s);
        if (sit != structs.end()) {
          for (const auto &field : sit->second.staticFields)
            if (field.name == callee->s && field.ty && field.ty->k == FUNC)
              return "เรียก static function value '" + callee->s + "' ซึ่งไม่สามารถตรวจ call target ได้ (--strict-safe)";
        }
      }
      // A member can be either a method (covered by the normal call graph) or
      // a function-valued field. If any user type exposes a callable field
      // under this name, strict mode fails closed rather than guessing.
      for (const auto &kv : structs) for (const auto &field : kv.second.fields)
        if (field.name == callee->s && field.ty && field.ty->k == FUNC)
          return "เรียก member function value '" + callee->s + "' ซึ่งอาจเป็น callable field ที่ตรวจ call target ไม่ได้ (--strict-safe)";
    } else {
      return "เรียกผ่าน expression/function pointer ที่ไม่ทราบเป้าหมาย จึงตรวจ thread isolation ไม่ได้ (--strict-safe)";
    }
  }
  return "";
}
void checkThreadIsolation(const char *api, Node *arg, Node *callSite = nullptr) {
  if (!safeEnforced()) return;
  std::string why;
  if (arg->k != NK::Lambda) why = "ส่ง function ที่ไม่ใช่ lambda เขียนตรงนี้ (ตรวจสิ่งที่มันจับไว้ไม่ได้)";
  else {
    const FuncInfo &lam = lambdas.back();
    why = sharedCapProblem(lam);
    if (why.empty() && !arg->c.empty()) {
      std::set<std::string> ps; for (auto &p : arg->params) ps.insert(p.name);
      std::map<Node *, std::set<std::string>> seen;
      ThreadEffectSummary effects;
      why = scanSharedState(arg->c[0].get(), ps, curModule, seen, 0, &effects, {}, {}, arg, callSite);
      if (why.empty() && opt.strictSafe) why = scanIndirectCallsStrict(arg->c[0].get(), curModule);
    }
  }
  ThreadWorkerRegistry &registry = wholeProgramWorkerRegistry();
  if (!registry.built && !inGlobalInit) buildWholeProgramWorkerRegistry();
  // Registry evidence enriches an existing isolation diagnostic; it must not
  // turn an otherwise-safe channel/atomic/owned worker into a false warning.
  if (!registry.summary.empty() && !why.empty()) why += "; " + registry.summary;
  if (!why.empty())
    reportUnsafe(std::string(api) + ": closure ที่ส่งเข้า thread ต้องแยกขาดจากตัวอื่น (โหมด --safe) แต่" + why +
        " — ส่งเฉพาะค่า/string/list/struct, ใช้ sync.Atomic/sync.Channel สำหรับของร่วม หรือครอบด้วย unsafe { } ถ้ารับผิดชอบการซิงค์เอง", arg->line);
}
void collectIdents(Node *n, std::set<std::string> &out) {
  if (!n) return;
  if (n->k == NK::Ident) out.insert(n->s);
  for (auto &c : n->c) collectIdents(c.get(), out);
  for (auto &cs : n->cases) {
    for (auto &v : cs.vals) collectIdents(v.get(), out);
    for (auto &r : cs.ranges) { collectIdents(r.lo.get(), out); collectIdents(r.hi.get(), out); }
    collectIdents(cs.guard.get(), out); collectIdents(cs.body.get(), out); collectIdents(cs.exprBody.get(), out);
  }
  collectIdents(n->deflt.get(), out);
  for (auto &p : n->params) if (p.def) collectIdents(p.def.get(), out);
}
// Used by lambda capture analysis only. Do not use this whole-subtree name set
// to prove thread isolation: declarations in nested blocks are not function-wide.
void collectDecls(Node *n, std::set<std::string> &out) {
  if (!n) return;
  if (n->k == NK::VarDecl || n->k == NK::ForEach || n->k == NK::Try) { if (!n->s.empty()) out.insert(n->s); }
  for (auto &c : n->c) collectDecls(c.get(), out);
  for (auto &cs : n->cases) { collectDecls(cs.guard.get(), out); collectDecls(cs.body.get(), out); collectDecls(cs.exprBody.get(), out); }
  collectDecls(n->deflt.get(), out);
}
// closure คงที่ (ไม่มี capture): { fnptr } ใน global constant ; ทุก function value คือ pointer ไปยัง closure (word แรก = fnptr รับ env เป็น argument แรก)
std::string closureConst(const std::string &sym) {
  std::string g = "@clo." + sym.substr(1);
  if (!extraDecls.count(g)) { extraDecls.insert(g); globals += g + " = private constant { ptr, i64, ptr } { ptr " + sym + ", i64 -1, ptr null }\n"; }
  return g;
}
// function ที่ตั้งชื่อไว้แล้วใช้เป็นค่า: สร้าง thunk รับ env แล้วส่งต่อให้ function จริง
std::string funcClosure(FuncInfo &f) {
  std::string th = "@thunk." + f.sym.substr(1), g = "@clo." + th.substr(1);
  if (extraDecls.count(g)) return g;
  extraDecls.insert(g);
  std::string ps, args;
  auto add = [&](const std::string &s) { ps += ", " + s; args += (args.empty() ? "" : ", ") + s; };
  for (size_t i = 0; i < f.pt.size(); i++) {
    T pt = f.pt[i]; std::string nm = "%a" + std::to_string(i);
    if (pt->k == ARR) { add("ptr " + nm + "d"); add("i64 " + nm + "n"); }
    else if (f.pref[i] || pt->k == STRUCT) add("ptr " + nm);
    else add(llty(pt) + " " + nm);
  }
  std::string rt = llty(f.ret), d = "define internal " + rt + " " + th + "(ptr %env" + ps + ") nounwind {\nentry:\n";
  if (f.ret->k == VOID) d += "  call void " + f.sym + "(" + args + ")\n  ret void\n}\n\n";
  else d += "  %r = call " + rt + " " + f.sym + "(" + args + ")\n  ret " + rt + " %r\n}\n\n";
  globals += d + g + " = private constant { ptr, i64, ptr } { ptr " + th + ", i64 -1, ptr null }\n";
  return g;
}
bool lambdaReturnsValue(Node *n) {
  if (!n) return false;
  if (n->k == NK::Lambda) return false;
  if (n->k == NK::Return && !n->c.empty()) return true;
  for (auto &c : n->c) if (lambdaReturnsValue(c.get())) return true;
  for (auto &cs : n->cases) if (lambdaReturnsValue(cs.guard.get()) || lambdaReturnsValue(cs.body.get()) || lambdaReturnsValue(cs.exprBody.get())) return true;
  return lambdaReturnsValue(n->deflt.get());
}

V dryExpr(Node *n) {  // วิเคราะห์ type โดยไม่เก็บโค้ดที่สร้าง
  size_t bl = body.size(), tl = temps.size(); bool tm = term; std::string bb = curBB;
  V r = expr(n);
  body.resize(bl); temps.resize(tl); term = tm; curBB = bb;
  return r;
}

std::string enumTable(const std::string &name, bool strs) {
  std::string g = "@enum." + name + (strs ? ".s" : ".i");
  if (extraDecls.count(g)) return g;
  extraDecls.insert(g);
  EnumInfo &e = enums[name];
  std::string items;
  for (size_t i = 0; i < e.mem.size(); i++) {
    if (i) items += ", ";
    items += strs ? "ptr " + strLit(e.mem[i].str) : "i32 " + std::to_string(e.mem[i].val);
  }
  globals += g + " = private constant [" + std::to_string(e.mem.size()) + " x " + (strs ? "ptr" : "i32") + "] [" + items + "]\n";
  return g;
}
V enumConv(const V &a, bool toStr) {
  if (a.t->payloadEnum) err("payload enum ไม่มี toString/toInt อัตโนมัติ; ใช้ match เพื่ออ่าน variant", curLine);
  std::string idx = conv(a, T_long);
  std::string tbl = enumTable(a.t->name, toStr);
  std::string p = def("getelementptr inbounds " + std::string(toStr ? "ptr" : "i32") + ", ptr " + tbl + ", i64 " + idx);
  V r; r.t = toStr ? T_str : T_int; r.v = def(std::string("load ") + (toStr ? "ptr" : "i32") + ", ptr " + p);
  return r;
}

int fieldIndex(StructInfo &s, const std::string &f, int line) {
  for (size_t i = 0; i < s.fields.size(); i++) if (s.fields[i].name == f) return (int)i;
  err("struct " + s.name + " ไม่มี field '" + f + "'", line);
}

V structOf(Node *obj) {  // address ของ struct/class payload (lvalue หรือ temp)
  V v;
  if (isLvalNode(obj)) {
    LV l = lval(obj);
    if (l.ty->k == OBJ) { V p = loadLV(l); v.v = p.v; v.t = tStruct(l.ty->name); }
    else if (l.ty->k == STRUCT) { v.v = l.addr; v.t = l.ty; }
    else err("ไม่ใช่ struct/object (เจอ " + tname(l.ty) + ")");
  } else {
    v = expr(obj);
    if (v.t->k == OBJ) { borrow(v); v.t = tStruct(v.t->name); }
    else borrow(v);
  }
  if (v.t->k != STRUCT) err("ไม่ใช่ struct/object (เจอ " + tname(v.t) + ")");
  return v;
}

std::string listField(const std::string &l, int idx, const char *ty) {
  std::string p = def("getelementptr inbounds %FacList, ptr " + l + ", i32 0, i32 " + std::to_string(idx));
  return def(std::string("load ") + ty + ", ptr " + p);
}

LV indexLV(Node *n, V *strOut) {
  // matrix m[row][column] is parsed as Index(Index(m, row), column).
  if (n->c[0]->k == NK::Index) {
    Node *ri = n->c[0].get();
    V matrix = expr(ri->c[0].get());
    if (matrix.t->k == DSK && matrix.t->name == "matrix") {
      borrow(matrix);
      V row = expr(ri->c[1].get());
      V col = expr(n->c[1].get());
      return {def("call ptr @fac_mx_ptr(ptr " + matrix.v + ", i64 " + toI64(row) + ", i64 " + toI64(col) + ")"), matrix.t->el};
    }
  }
  V b = expr(n->c[0].get()); borrow(b);
  V ix = expr(n->c[1].get());
  borrow(b);
  std::string idx = toI64(ix);
  if (b.t->k == STR) {
    if (!strOut) err("แก้ตัวอักษรใน string ไม่ได้ (string เป็น immutable)", n->line);
    strOut->t = T_uni; strOut->v = def("call i32 @fac_str_at(ptr " + b.v + ", i64 " + idx + ")");
    return LV();
  }
  if (b.t->k == ARR) {
    boundsCheck(idx, b.len);
    return {def("getelementptr inbounds " + llty(b.t->el) + ", ptr " + b.v + ", i64 " + idx), b.t->el};
  }
  if (b.t->k == LIST) {
    std::string data = listField(b.v, 0, "ptr"), len = listField(b.v, 1, "i64");
    boundsCheck(idx, len);
    return {def("getelementptr inbounds " + llty(b.t->el) + ", ptr " + data + ", i64 " + idx), b.t->el};
  }
  if (b.t->k == DSK && b.t->name == "linked") return {def("call ptr @fac_ll_ptr(ptr " + b.v + ", i64 " + idx + ")"), b.t->el};
  err("ใช้ [] กับ " + tname(b.t) + " ไม่ได้ (ptr ใช้ [p] แบบ deref)", n->line);
}

LV lval(Node *n) {
  curLine = n->line;
  switch (n->k) {
    case NK::Ident: {
      Var *v = findVar(n->s);
      if (!v) err("ไม่รู้จักตัวแปร '" + n->s + "'", n->line);
      if (v->ty->k == ARR) err("'" + n->s + "' เป็น array แก้ทั้งก้อนไม่ได้ (ใช้ " + n->s + "[i] = ...)", n->line);
      return {varAddr(*v), v->ty, v->isVolatile};
    }
    case NK::Member: {
      if (FieldInfo *sf = qualifiedStaticField(n, n->line)) {
        if (sf->isConst) err("แก้ค่าของ const static field '" + sf->name + "' ไม่ได้", n->line);
        return {sf->sym, sf->ty, sf->ty->isVolatile};
      }
      if (Var *gq = qualifiedGlobal(n, n->line)) { if (gq->ty->k == ARR) err("'" + n->s + "' เป็น array แก้ทั้งก้อนไม่ได้", n->line); return {varAddr(*gq), gq->ty, gq->isVolatile}; }
      V s = structOf(n->c[0].get());
      StructInfo &si = structInfo(s.t->name, n->line);
      int fi = fieldIndex(si, n->s, n->line);
      const FieldInfo &field = si.fields[fi];
      if (!field.isPublic && !canAccessMember(field.owner, field.isPrivate, field.isProtected))
        err("field '" + n->s + "' ไม่มีสิทธิ์เข้าถึงจากภายนอก type " + field.owner, n->line);
      return {def("getelementptr inbounds %S." + si.name + ", ptr " + s.v + ", i32 0, i32 " + std::to_string(fi)), field.ty, field.ty->isVolatile};
    }
    case NK::Index: return indexLV(n, nullptr);
    case NK::Deref: {
      V p = expr(n->c[0].get());
      if (p.t->k != PTR || !p.t->el || p.t->el->k == VOID) err("deref [..] ต้องใช้กับ ptr ที่มี type (เจอ " + tname(p.t) + ")", n->line);
      requireUnsafe("deref [..] ของ ptr ดิบ", n->line);
      if (opt.debug) {  // --debug: เช็ก null ก่อน deref
        std::string isn = def("icmp eq ptr " + p.v + ", null"), bad = lbl("nullp"), ok = lbl("nullok");
        cbr(isn, bad, ok, true);
        placeLabel(bad); ins("call void @fac_null_deref()"); ins("unreachable"); term = true;
        placeLabel(ok);
      }
      return {p.v, p.t->el, p.t->el->isVolatile};
    }
    default: err("ใช้เป็นที่เก็บค่า (lvalue) ไม่ได้", n->line);
  }
}

V loadLV(const LV &l) {
  V r; r.t = l.ty;
  if (l.ty->k == STRUCT || (l.ty->k == ENUM && l.ty->payloadEnum)) { r.v = l.addr; return r; }
  if (l.ty->k == ARR) { r.v = l.addr; r.len = std::to_string(l.ty->n); return r; }  // array field ใน struct
  r.v = def(std::string("load ") + ((l.isVolatile || l.ty->isVolatile) ? "volatile " : "") + llty(l.ty) + ", ptr " + l.addr);
  return r;
}

V identExpr(Node *n) {
  Var *v = findVar(n->s);
  if (!v) {
    // Public globals from modules imported with `global` become visible in this source module only.
    std::vector<std::pair<std::string, Var *>> gv;
    auto gi = modGlobalImports.find(curModule);
    if (gi != modGlobalImports.end()) for (const std::string &mod : gi->second) {
      auto gm = globalVars.find(mod);
      if (gm == globalVars.end()) continue;
      auto vi = gm->second.find(n->s);
      if (vi != gm->second.end() && globalPublic[mod + "." + n->s]) gv.push_back({mod, &vi->second});
    }
    if (gv.size() > 1) err("ตัวแปร '" + n->s + "' กำกวมจาก global import หลายไลบรารี", n->line);
    if (gv.size() == 1) return loadVar(gv[0].second);

    // Math constants are values as well as qualified members: `PI` with `math.fac global`.
    if (modGlobalImports[curModule].count("math") && moduleImportAllows("math", n->s)) {
      V r; r.t = T_double;
      if (n->s == "PI") { r.v = fhex(3.14159265358979323846); return r; }
      if (n->s == "TAU") { r.v = fhex(6.28318530717958647692); return r; }
      if (n->s == "E") { r.v = fhex(2.71828182845904523536); return r; }
      if (n->s == "INF") { r.v = "0x7FF0000000000000"; return r; }
      if (n->s == "NAN") { r.v = "0x7FF8000000000000"; return r; }
    }
    auto fit = funcs.find(curModule + "." + n->s);  // ชื่อ function ใช้เป็นค่าได้
    if (fit != funcs.end() && fit->second.isConsteval)
      err("consteval function '" + n->s + "' เป็น compile-time only และใช้เป็น runtime function value ไม่ได้", n->line);
    if (fit != funcs.end() && !fit->second.generic && !overloads.count(fit->first)) {
      V r; r.t = tFunc(fit->second.ret, fit->second.pt, fit->second.pnoescape, fit->second.preadonly);
      setFunctionLifetimeContract(r.t, fit->second.node);
      r.v = funcClosure(fit->second); return r;
    }
    err("ไม่รู้จักตัวแปร '" + n->s + "'", n->line);
  }
  return loadVar(v);
}
V loadVar(Var *v) {
  V r; r.t = v->ty;
  if (v->ty->k == ARR) { r.v = varAddr(*v); r.len = v->len; return r; }
  if (v->ty->k == STRUCT || (v->ty->k == ENUM && v->ty->payloadEnum)) { r.v = varAddr(*v); return r; }
  r.v = def(std::string("load ") + ((v->isVolatile || v->ty->isVolatile) ? "volatile " : "") + llty(v->ty) + ", ptr " + varAddr(*v));
  return r;
}

V memberExpr(Node *n) {
  Node *b = n->c[0].get();
  if (FieldInfo *sf = qualifiedStaticField(n, n->line)) {
    V r; r.t = sf->ty;
    r.v = def(std::string("load ") + (sf->ty->isVolatile ? "volatile " : "") + llty(sf->ty) + ", ptr " + sf->sym);
    return r;
  }
  if (Var *gq = qualifiedGlobal(n, n->line)) return loadVar(gq);
  std::string root = rootIdent(n);
  if (!root.empty() && isModuleName(root)) {
    std::string path; flatten(n, path);
    path = canonicalModulePath(path);
    if (path == "math.PI" || path == "math.INF" || path == "math.NAN" || path == "math.TAU" || path == "math.E") {
      if (!moduleImportAllows("math", path.substr(5))) err("math." + path.substr(5) + " ไม่อยู่ในรายการ import ที่อนุญาต", n->line);
      V r; r.t = T_double;
      if (path == "math.PI") r.v = fhex(3.14159265358979323846);
      else if (path == "math.INF") r.v = "0x7FF0000000000000";
      else if (path == "math.NAN") r.v = "0x7FF8000000000000";
      else if (path == "math.TAU") r.v = fhex(6.28318530717958647692);
      else r.v = fhex(2.71828182845904523536);
      return r;
    }
    if (path == "sys.args") { V r; r.t = tList(T_str); r.owned = true; r.v = def("call ptr @fac_args()"); return r; }
    // Imported enum values: Module.Enum.Member
    {
      std::vector<std::string> parts; std::string part;
      for (char ch : path) { if (ch == '.') { if (!part.empty()) parts.push_back(part); part.clear(); } else part += ch; }
      if (!part.empty()) parts.push_back(part);
      if (parts.size() == 3 && enums.count(parts[1])) {
        EnumInfo &en = enums[parts[1]];
        if (en.module == parts[0] && (en.module == curModule || curImports.count(en.module) || modGlobalImports[curModule].count(en.module))) {
          requireTypeAccess(path, en.name, en.module, en.isPublic, n->line);
          for (size_t i = 0; i < en.mem.size(); i++) if (en.mem[i].name == parts[2]) return enumV(en.name, parts[2]);
          err("enum " + en.name + " ไม่มีสมาชิก '" + parts[2] + "'", n->line);
        }
      }
    }
    err("ไม่รู้จัก '" + path + "'", n->line);
  }
  if (b->k == NK::Ident && !findVar(b->s) && enums.count(b->s)) {
    EnumInfo &e = enums[b->s];
    requireTypeAccess(e.name, e.name, e.module, e.isPublic, n->line);
    for (size_t i = 0; i < e.mem.size(); i++) if (e.mem[i].name == n->s) return enumV(e.name, n->s);
    err("enum " + e.name + " ไม่มีสมาชิก '" + n->s + "'", n->line);
  }
  if (!isLvalNode(b)) {  // เช่น Day.Sun.toString หรือ f().field
    V o = dryExpr(b);   // เช็กชนิดเท่านั้น (rollback โค้ดที่ emit): ห้ามประเมิน b จริงสองรอบ ไม่งั้น f().field เรียก f() ซ้ำ
    if (o.t->k == ENUM && (n->s == "toString" || n->s == "toInt")) { V ov = expr(b); return enumConv(ov, n->s == "toString"); }
  } else if (b->k == NK::Member || b->k == NK::Ident) {
    V o = dryExpr(b);
    if (o.t->k == ENUM && (n->s == "toString" || n->s == "toInt")) { V ov = expr(b); return enumConv(ov, n->s == "toString"); }
  }
  return loadLV(lval(n));
}

V sliceExpr(Node *n) {
  V b = expr(n->c[0].get()); borrow(b);
  V a = expr(n->c[1].get()), e = expr(n->c[2].get());
  borrow(b);
  std::string ai = toI64(a), ei = toI64(e);
  V r; r.owned = true;
  if (b.t->k == STR) { r.t = T_str; r.v = def("call ptr @fac_str_slice(ptr " + b.v + ", i64 " + ai + ", i64 " + ei + ")"); }
  else if (b.t->k == ARR) {
    r.t = tList(b.t->el);
    r.v = def("call ptr @fac_array_slice(ptr " + b.v + ", i64 " + b.len + ", i64 " + ai + ", i64 " + ei + ", i32 " + std::to_string(sizeOf(b.t->el)) + ", i32 " + std::to_string(ekOf(b.t->el)) + ")");
  } else if (b.t->k == LIST) { r.t = b.t; r.v = def("call ptr @fac_list_slice(ptr " + b.v + ", i64 " + ai + ", i64 " + ei + ")"); }
  else err("ใช้ [a:b] กับ " + tname(b.t) + " ไม่ได้", n->line);
  return r;
}

V loopIdx(Node *n) {
  // The selector path is an inner-to-outer subsequence of active counted-loop
  // directions: for--.for++.i => nearest descending loop, then ascending loop.
  std::vector<bool> path;
  if (!n->s.empty()) {
    size_t at = 0;
    while (at < n->s.size()) {
      size_t dot = n->s.find('.', at);
      if (dot == std::string::npos) break;
      std::string_view segment(n->s.data() + at, dot - at);
      if (segment == "for++") path.push_back(true);
      else if (segment == "for--" || segment == "++for" || segment == "--for") path.push_back(false);
      at = dot + 1;
    }
  }
  if (path.empty()) path.push_back(n->b);
  size_t matched = 0;
  for (size_t i = loops.size(); i > 0; i--) {
    const LoopCtx &loop = loops[i - 1];
    if (!loop.isPP || loop.up != path[matched]) continue;
    if (++matched == path.size()) {
      V r; r.t = T_int; r.v = def("load i32, ptr " + loop.idxSlot); return r;
    }
  }
  err("ไม่มี counted loop ที่ตรงกับ selector path '" + n->s + "'; path เรียงจากวงในไปวงนอก", n->line);
}

V ifvExpr(Node *n) {
  size_t pairs = (n->c.size() - 1) / 2;
  // ifv is a value-producing condition chain. Determine its result type before
  // emitting branches so numeric branches can join to a safe common type.
  T rt = nullptr;
  auto joinType = [&](Node *e) {
    T branch = dryType(e);
    if (!branch || branch->k == NULLT || branch->k == ARR || branch->k == VOID)
      err("ifv: ชนิดของค่าไม่รองรับ (" + tname(branch) + ")", e ? e->line : n->line);
    if (!rt) { rt = branch; return; }
    if (sameT(rt, branch)) return;
    if (isNum(rt) && isNum(branch)) { rt = commonT(rt, branch); return; }
    err("ifv: ชนิดค่าของทุก branch ต้องตรงกัน หรือเป็นชนิดตัวเลขที่แปลงร่วมกันได้ (เจอ " +
        tname(rt) + " และ " + tname(branch) + ")", e ? e->line : n->line);
  };
  for (size_t i = 0; i < pairs; ++i) joinType(n->c[2 * i + 1].get());
  joinType(n->c.back().get());
  std::string endL = lbl("ifv.end"), slot = alloca_(rt);
  auto branch = [&](Node *e) {
    size_t mk = temps.size();
    V v = expr(e);
    if (sameT(v.t, rt)) storeRaw(slot, rt, v);
    else if (isNum(v.t) && isNum(rt)) {
      checkImplicit(v, rt, e->line);
      V converted = v; converted.t = rt; converted.v = conv(v, rt, e->line);
      storeRaw(slot, rt, converted, false);
    } else err("ifv: branch type ไม่ตรงกับชนิดผลลัพธ์ " + tname(rt), e->line);
    flushTemps(mk);
    br(endL);
  };
  for (size_t i = 0; i < pairs; i++) {
    size_t mk = temps.size();
    V c = expr(n->c[2 * i].get()); std::string cd = condOf(c); flushTemps(mk);
    std::string th = lbl("ifv.then"), nx = lbl("ifv.next");
    cbr(cd, th, nx);
    placeLabel(th); branch(n->c[2 * i + 1].get());
    placeLabel(nx);
  }
  branch(n->c.back().get());
  placeLabel(endL);
  V r; r.t = rt;
  if (rt->k == STRUCT) { r.v = slot; r.owned = true; }
  else { r.v = def("load " + llty(rt) + ", ptr " + slot); r.owned = needsFree(rt); }
  return r;
}

// ---- numeric helpers
static T intT(int bits, bool sg) { return bits == 8 ? (sg ? T_byte : T_ubyte) : bits == 16 ? (sg ? T_short : T_ushort) : bits == 32 ? (sg ? T_int : T_uint) : (sg ? T_long : T_ulong); }
T promote(const T &t) {
  if (isFlt(t)) return t;
  int b = bitsOf(t); bool s = signedOf(t);
  if (t->k == UNI) return T_uint;
  if (b < 32) return T_int;
  return intT(b, s);
}
T commonT(const T &a, const T &b) {
  if (a->k == F64 || b->k == F64) return T_double;
  if (a->k == F32 || b->k == F32) return T_float;
  T pa = promote(a), pb = promote(b);
  int bits = std::max(pa->bits, pb->bits);
  bool sg = pa->bits == pb->bits ? (pa->sg && pb->sg) : (pa->bits > pb->bits ? pa->sg : pb->sg);
  return intT(bits, sg);
}

V boolV(const std::string &i1) { V r; r.t = T_bool; r.v = def("zext i1 " + i1 + " to i8"); return r; }
// concrete class ทั้งหมดที่เป็นชนิด tn (ตัวมันเอง/ลูกหลาน/implements) -- ใช้เทียบ vtbl ตอนรันสำหรับ instanceof และ downcast
std::vector<std::string> concreteSubtypes(const std::string &tn) {
  std::vector<std::string> r;
  for (auto &kv : structs) { StructInfo &si = kv.second; if (si.isClass && !si.isInterface && !si.isAbstract && isSubclass(si.name, tn)) r.push_back(si.name); }
  return r;
}
std::string vtblMatch(const std::string &objPtr, const std::vector<std::string> &cands) {   // i1: ชนิดจริงของ obj อยู่ใน cands หรือไม่
  if (cands.empty()) return "false";
  std::string vt = def("call ptr @fac_obj_vtbl(ptr " + objPtr + ")"), acc;
  for (auto &c : cands) { std::string eq = def("icmp eq ptr " + vt + ", @vtbl." + c); acc = acc.empty() ? eq : def("or i1 " + acc + ", " + eq); }
  return acc;
}
std::string classTypeName(const std::string &q, int line, const char *who) {
  std::string tn = q; size_t d = tn.rfind('.'); if (d != std::string::npos) tn = tn.substr(d + 1);
  auto it = structs.find(tn);
  if (it == structs.end() || !it->second.isClass) err(std::string(who) + ": '" + q + "' ไม่ใช่ class หรือ interface", line);
  return tn;
}
V instanceOfExpr(Node *n) {
  V a = expr(n->c[0].get());
  if (a.t->k != OBJ && a.t->k != NULLT) err("instanceof ใช้กับค่า obj เท่านั้น (ได้ " + tname(a.t) + ")", n->line);
  std::string tn = classTypeName(n->c[1]->s, n->line, "instanceof");
  if (a.t->k == NULLT) return boolV("false");
  borrow(a);
  return boolV(vtblMatch(a.v, concreteSubtypes(tn)));
}

// Per-function cache. Without it every '+' node dry-runs its whole left subtree and then generates it again, so
// compile time doubles with each extra operator (a+b+c+... of ~25 terms took >10 s: an accidental DoS on the compiler).
// The cache is keyed by node and cleared at the start of every emitFunc(), because a generic body is emitted once per
// instantiation and the same Node can have a different type in each.
std::unordered_map<Node *, bool> concatTreeCache;
bool isStringConcatTree(Node *n) {
  if (!n || n->k != NK::Binary || n->s != "+") return false;
  auto it = concatTreeCache.find(n);
  if (it != concatTreeCache.end()) return it->second;
  bool r = dryType(n->c[0].get())->k == STR && dryType(n->c[1].get())->k == STR;
  concatTreeCache[n] = r;
  return r;
}
void collectStringConcatParts(Node *n, std::vector<Node *> &parts) {
  if (isStringConcatTree(n)) {
    collectStringConcatParts(n->c[0].get(), parts);
    collectStringConcatParts(n->c[1].get(), parts);
  } else parts.push_back(n);
}
V stringConcatChain(Node *n, int line) {
  std::vector<Node *> parts;
  collectStringConcatParts(n, parts);
  if (parts.size() < 3) {
    V a = expr(n->c[0].get()); if (a.t->k == STR) borrow(a);
    V b = expr(n->c[1].get()); return binop("+", a, b, line);
  }
  std::vector<V> values;
  values.reserve(parts.size());
  for (Node *part : parts) {
    V v = expr(part);
    if (v.t->k != STR) err("ต่อ string ได้เฉพาะ string + string (ใช้ str(x) แปลงตัวเลข)", line);
    borrow(v);
    values.push_back(v);
  }
  std::string arr = alloca_(T_str, (int64_t)values.size());
  std::string arrTy = "[" + std::to_string(values.size()) + " x ptr]";
  for (size_t i = 0; i < values.size(); i++) {
    std::string p = def("getelementptr inbounds " + arrTy + ", ptr " + arr + ", i64 0, i64 " + std::to_string(i));
    ins("store ptr " + values[i].v + ", ptr " + p);
  }
  V r; r.t = T_str; r.owned = true;
  r.v = def("call ptr @fac_str_cat_many(ptr " + arr + ", i64 " + std::to_string(values.size()) + ")");
  return r;
}

V binop(const std::string &op, V a, V b, int line = -1) {
  if (isVecT(a.t) || isVecT(b.t) || isMatT(a.t) || isMatT(b.t)) return vecBinop(op, a, b, line);
  const bool isCmp = op == "==" || op == "!=" || op == "<" || op == ">" || op == "<=" || op == ">=";
  if (a.t->k == STR || b.t->k == STR) {
    borrow(a); borrow(b);
    if (op == "+") {
      if (a.t->k != STR || b.t->k != STR) err("ต่อ string ได้เฉพาะ string + string (ใช้ str(x) แปลงตัวเลข)", line);
      V r; r.t = T_str; r.owned = true; r.v = def("call ptr @fac_str_cat(ptr " + a.v + ", ptr " + b.v + ")"); return r;
    }
    if (op == "==" || op == "!=") {
      if (a.t->k == NULLT || b.t->k == NULLT) return boolV(def(std::string("icmp ") + (op == "==" ? "eq" : "ne") + " ptr " + a.v + ", " + b.v));
      if (a.t->k != STR || b.t->k != STR) err("เทียบ string กับ " + tname(a.t->k == STR ? b.t : a.t) + " ไม่ได้", line);
      std::string r = def("call i32 @fac_str_eq(ptr " + a.v + ", ptr " + b.v + ")");
      return boolV(def(std::string("icmp ") + (op == "==" ? "ne" : "eq") + " i32 " + r + ", 0"));
    }
    err("string ใช้ตัวดำเนินการ '" + op + "' ไม่ได้", line);
  }
  if (isPtrish(a.t) || isPtrish(b.t) || a.t->k == ARR || b.t->k == ARR) {
    if (isCmp && (op == "==" || op == "!=")) {
      std::string x = conv(a, T_opaque, line), y = conv(b, T_opaque, line);
      return boolV(def(std::string("icmp ") + (op == "==" ? "eq" : "ne") + " ptr " + x + ", " + y));
    }
    if ((op == "+" || op == "-") && (a.t->k == PTR) && isIntLike(b.t)) {  // เลื่อนทีละ byte
      requireUnsafe("การคำนวณ pointer (ptr " + op + " n)", line);
      std::string off = conv(b, T_long, line);
      if (op == "-") off = def("sub i64 0, " + off);
      V r; r.t = a.t; r.v = def("getelementptr i8, ptr " + a.v + ", i64 " + off); return r;
    }
    if (op == "+" && a.t->k != PTR && b.t->k == PTR && isIntLike(a.t)) { requireUnsafe("การคำนวณ pointer (n + ptr)", line); return binop("+", b, a, line); }
    err("ใช้ '" + op + "' กับ " + tname(a.t) + " และ " + tname(b.t) + " ไม่ได้", line);
  }
  if (!isNum(a.t) || !isNum(b.t)) err("ใช้ '" + op + "' กับ " + tname(a.t) + " และ " + tname(b.t) + " ไม่ได้", line);
  if (op == "&&" || op == "||") {
    std::string x = condOf(a), y = condOf(b);
    return boolV(def(std::string(op == "&&" ? "and" : "or") + " i1 " + x + ", " + y));
  }
  if (op == "**") {
    if (isFlt(a.t) || isFlt(b.t)) {
      std::string x = conv(a, T_double), y = conv(b, T_double);
      V r; r.t = T_double; r.v = def("call double @llvm.pow.f64(double " + x + ", double " + y + ")"); return r;
    }
    T ct = commonT(a.t, b.t);
    std::string x = conv(a, T_long), y = conv(b, T_long);
    V r; r.t = T_long; r.v = def("call i64 @fac_ipow(i64 " + x + ", i64 " + y + ")");
    return cv(r, ct);
  }
  T ct = commonT(a.t, b.t);
  std::string x = conv(a, ct, line), y = conv(b, ct, line), ty = llty(ct);
  bool f = isFlt(ct), s = ct->sg;
  V r; r.t = ct;
  if (opt.overflow && !f && (op == "+" || op == "-" || op == "*")) {  // --check-overflow: เกินช่วง -> throw Error
    std::string in = std::string("llvm.") + (s ? "s" : "u") + (op == "+" ? "add" : op == "-" ? "sub" : "mul") + ".with.overflow." + ty;
    declIntr(in, "{ " + ty + ", i1 } @" + in + "(" + ty + ", " + ty + ")");
    std::string agg = def("call { " + ty + ", i1 } @" + in + "(" + ty + " " + x + ", " + ty + " " + y + ")");
    r.v = def("extractvalue { " + ty + ", i1 } " + agg + ", 0");
    std::string ov = def("extractvalue { " + ty + ", i1 } " + agg + ", 1");
    std::string bad = lbl("ovf"), ok = lbl("ovfok");
    cbr(ov, bad, ok, true);
    placeLabel(bad); ins("call void @fac_overflow()"); ins("unreachable"); term = true;
    placeLabel(ok);
    return r;
  }
  {  // เลขจำนวนเต็มเล็ก (byte/short/char) ที่คำนวณกับ literal หรือเลขเล็กด้วยกัน -> อนุญาตตัดกลับโดยปริยาย
    auto small = [&](const V &v) { return isIntLike(v.t) && bitsOf(v.t) < 32 && v.t->k != BOOL; };
    auto litv = [&](const V &v) { return v.t->k == INT && isLit(v.v); };
    r.smallArith = !f && (small(a) || small(b) || a.smallArith || b.smallArith) && (small(a) || litv(a) || a.smallArith) && (small(b) || litv(b) || b.smallArith);
  }
  if (isCmp) {
    std::string p;
    if (f) p = op == "==" ? "oeq" : op == "!=" ? "une" : op == "<" ? "olt" : op == ">" ? "ogt" : op == "<=" ? "ole" : "oge";
    else p = op == "==" ? "eq" : op == "!=" ? "ne" : op == "<" ? (s ? "slt" : "ult") : op == ">" ? (s ? "sgt" : "ugt") : op == "<=" ? (s ? "sle" : "ule") : (s ? "sge" : "uge");
    return boolV(def(std::string(f ? "fcmp " : "icmp ") + p + " " + ty + " " + x + ", " + y));
  }
  if (op == "+") r.v = def(std::string(f ? "fadd " : "add ") + ty + " " + x + ", " + y);
  else if (op == "-") r.v = def(std::string(f ? "fsub " : "sub ") + ty + " " + x + ", " + y);
  else if (op == "*") r.v = def(std::string(f ? "fmul " : "mul ") + ty + " " + x + ", " + y);
  else if (op == "/" || op == "%") {
    if (f) r.v = def(std::string(op == "/" ? "fdiv " : "frem ") + ty + " " + x + ", " + y);
    else {
      if (opt.divcheck && !(isLit(y) && atoll(y.c_str()) != 0)) {
        std::string z = def("icmp eq " + ty + " " + y + ", 0");
        std::string bad = lbl("div0"), ok = lbl("divok");
        cbr(z, bad, ok, true);
        placeLabel(bad); ins("call void @fac_div0()"); ins("unreachable"); term = true;
        placeLabel(ok);
      }
      if (s && !(isLit(y) && atoll(y.c_str()) != -1)) {
        // INT_MIN / -1 และ INT_MIN % -1 ทำให้ CPU (x86) trap เป็น SIGFPE -> คำนวณแบบ wrap-around แทน (ผลเหมือน Java/Go)
        std::string m1 = def("icmp eq " + ty + " " + y + ", -1");
        std::string ysafe = def("select i1 " + m1 + ", " + ty + " 1, " + ty + " " + y);
        std::string q = def(std::string(op == "/" ? "sdiv " : "srem ") + ty + " " + x + ", " + ysafe);
        std::string alt = op == "/" ? def("sub " + ty + " 0, " + x) : std::string("0");
        r.v = def("select i1 " + m1 + ", " + ty + " " + alt + ", " + ty + " " + q);
      } else
      r.v = def(std::string(op == "/" ? (s ? "sdiv " : "udiv ") : (s ? "srem " : "urem ")) + ty + " " + x + ", " + y);
    }
  } else if (f) err("ตัวดำเนินการ '" + op + "' ใช้กับเลขทศนิยมไม่ได้", line);
  else if (op == "&") r.v = def("and " + ty + " " + x + ", " + y);
  else if (op == "|") r.v = def("or " + ty + " " + x + ", " + y);
  else if (op == "^" || op == "~") r.v = def("xor " + ty + " " + x + ", " + y);
  else if (op == "<<" || op == ">>") {
    std::string m = def("and " + ty + " " + y + ", " + std::to_string(ct->bits - 1));
    r.v = def(std::string(op == "<<" ? "shl " : (s ? "ashr " : "lshr ")) + ty + " " + x + ", " + m);
  } else err("ไม่รู้จักตัวดำเนินการ '" + op + "'", line);
  return r;
}

V unaryExpr(Node *n) {
  const std::string &op = n->s;
  Node *e = n->c[0].get();
  if (op == "++" || op == "--") {
    LV l = lval(e); V cur = loadLV(l);
    V nv = binop(op == "++" ? "+" : "-", cur, constInt(1), n->line);
    storeRaw(l.addr, l.ty, nv, false, l.isVolatile);
    V r = cv(nv, l.ty); return r;
  }
  V a = expr(e);
  if (op == "-" && isVecT(a.t)) return vecNeg(a);
  if (op == "!") { std::string c = condOf(a); return boolV(def("xor i1 " + c + ", true")); }
  if (!isNum(a.t)) err("ใช้ '" + op + "' กับ " + tname(a.t) + " ไม่ได้", n->line);
  if (op == "+") return a;
  if (op == "-") {
    if (isFlt(a.t)) { V r; r.t = a.t; r.v = def("fneg " + llty(a.t) + " " + a.v); return r; }
    if (a.t->k == INT && a.v.size() && isLit(a.v) && a.v[0] != '-') { V r = a; r.v = "-" + a.v; if (a.v == "0") r.v = "0"; return r; }
    T pt = promote(a.t); V r; r.t = pt; r.v = def("sub " + llty(pt) + " 0, " + conv(a, pt)); return r;
  }
  if (op == "~") {
    if (isFlt(a.t)) err("~ ใช้กับเลขทศนิยมไม่ได้", n->line);
    T pt = promote(a.t); V r; r.t = pt; r.v = def("xor " + llty(pt) + " " + conv(a, pt) + ", -1"); return r;
  }
  err("ตัวดำเนินการเดี่ยว '" + op + "' ไม่รู้จัก", n->line);
}

V shortCircuit(Node *n) {
  bool isAnd = n->s == "&&";
  V a = expr(n->c[0].get());
  std::string ca = condOf(a), lhsBB = curBB;
  std::string rhsL = lbl("sc.rhs"), endL = lbl("sc.end");
  if (isAnd) cbr(ca, rhsL, endL); else cbr(ca, endL, rhsL);
  placeLabel(rhsL);
  size_t mk = temps.size();
  V b = expr(n->c[1].get());
  std::string cb = condOf(b);
  flushTemps(mk);
  std::string rhsBB = curBB;
  br(endL);
  placeLabel(endL);
  std::string p = def("phi i1 [ " + std::string(isAnd ? "false" : "true") + ", %" + lhsBB + " ], [ " + cb + ", %" + rhsBB + " ]");
  return boolV(p);
}

V bulkAssign(Node *n) {  // x[i] = {a, b, c}  เติมต่อเนื่องจาก index i
  Node *l = n->c[0].get(), *r = n->c[1].get();
  if (l->k != NK::Index) err("{...} กำหนดค่าได้เฉพาะ x[i] = {...}", n->line);
  V b = expr(l->c[0].get()); borrow(b);
  V ix = expr(l->c[1].get());
  borrow(b);
  std::string idx = toI64(ix), data, len; T el;
  if (b.t->k == ARR) { data = b.v; len = b.len; el = b.t->el; }
  else if (b.t->k == LIST) { data = listField(b.v, 0, "ptr"); len = listField(b.v, 1, "i64"); el = b.t->el; }
  else err("{...} ใช้กับ array/list เท่านั้น", n->line);
  size_t cnt = r->c.size();
  if (cnt == 0) return V();
  std::string last = def("add i64 " + idx + ", " + std::to_string(cnt - 1));
  boundsCheck(last, len); boundsCheck(idx, len);
  for (size_t i = 0; i < cnt; i++) {
    V v = expr(r->c[i].get());
    std::string at = i == 0 ? idx : def("add i64 " + idx + ", " + std::to_string(i));
    std::string p = def("getelementptr inbounds " + llty(el) + ", ptr " + data + ", i64 " + at);
    if (el->k == STR) { V o = ownV(v); std::string old = def("load ptr, ptr " + p); freeVal(T_str, old); ins("store ptr " + o.v + ", ptr " + p); }
    else { checkImplicit(v, el, n->line); ins("store " + llty(el) + " " + conv(v, el, n->line) + ", ptr " + p); }
  }
  return V();
}

V assignExpr(Node *n) {
  std::string op = n->s;
  Node *l = n->c[0].get(), *r = n->c[1].get();
  if (r->k == NK::InitList) return bulkAssign(n);
  if (l->k == NK::Ident) {
    Var *v = findVar(l->s);
    if (v && v->isConst) err("แก้ค่าของ const '" + l->s + "' ไม่ได้", n->line);
  }
  if (l->k == NK::Member) { Var *gq = qualifiedGlobal(l, n->line); if (gq && gq->isConst) err("แก้ค่าของ const '" + l->s + "' ไม่ได้", n->line); }
  LV lv = lval(l);
  if (lv.ty->k == ARR) err("แก้ทั้ง array ในครั้งเดียวไม่ได้ (ใช้ x.f[i] = ... หรือ x.f[0] = {...})", n->line);
  bool freeOld = true;
  if (l->k == NK::Ident) { Var *v = findVar(l->s); if (v && v->isParam) freeOld = false; }
  if (op == "=") {
    V rv = expr(r);
    if (lv.ty->k == STR && rv.t->k != STR && rv.t->k != NULLT) err("กำหนด " + tname(rv.t) + " ให้ string ไม่ได้ (ใช้ str(x))", n->line);
    if (lv.ty->k == STRUCT && !(rv.t->k == STRUCT && rv.t->name == lv.ty->name)) err("ชนิด struct ไม่ตรงกัน", n->line);
    if (lv.ty->k == ENUM && lv.ty->payloadEnum && !(rv.t->k == ENUM && rv.t->name == lv.ty->name && rv.t->payloadEnum)) err("ชนิด payload enum ไม่ตรงกัน", n->line);
    if (rv.t->k == NULLT && lv.ty->k == STR) rv.v = "null";
    storeAssign(lv.addr, lv.ty, rv, freeOld, lv.isVolatile);
    return V();
  }
  std::string bop = op.substr(0, op.size() - 1);
  if (bop == "~") bop = "^";
  V cur = loadLV(lv);
  V rv = expr(r);
  V nv = binop(bop, cur, rv, n->line);
  if (lv.ty->k == STR) storeAssign(lv.addr, lv.ty, nv, freeOld);
  else { ins(std::string("store ") + ((lv.isVolatile || lv.ty->isVolatile) ? "volatile " : "") + llty(lv.ty) + " " + conv(nv, lv.ty, n->line) + ", ptr " + lv.addr); }
  return V();
}

V postInc(Node *n) {
  LV l = lval(n->c[0].get()); V cur = loadLV(l);
  if (!isNum(l.ty)) err("++/-- ใช้กับ " + tname(l.ty) + " ไม่ได้", n->line);
  V nv = binop(n->s == "++" ? "+" : "-", cur, constInt(1), n->line);
  ins(std::string("store ") + ((l.isVolatile || l.ty->isVolatile) ? "volatile " : "") + llty(l.ty) + " " + conv(nv, l.ty) + ", ptr " + l.addr);
  return cur;
}

V tupleLit(Node *n, const T &target) {  // (a, b, ...) -> aggregate ที่ SSA (สมาชิก string เป็นของผู้รับ)
  if (target && target->ps.size() != n->c.size()) err("tuple มี " + std::to_string(n->c.size()) + " ค่า แต่ต้องการ " + std::to_string(target->ps.size()), n->line);
  std::vector<V> vals; std::vector<T> ts;
  for (size_t i = 0; i < n->c.size(); i++) {
    V e = expr(n->c[i].get()); T mt = target ? target->ps[i] : e.t;
    if (mt->k == NULLT || mt->k == VOID || mt->k == ARR || mt->k == STRUCT || mt->k == TUPLE || mt->k == LIST || mt->k == DSK || mt->k == FUNC || mt->k == OBJ) err("tuple: สมาชิกที่ " + std::to_string(i + 1) + " ชนิด " + tname(mt) + " ไม่รองรับ", n->line);
    if (mt->k == STR) {
      if (e.t->k != STR && e.t->k != NULLT) err("tuple: สมาชิกที่ " + std::to_string(i + 1) + " ต้องเป็น string", n->line);
      e = e.t->k == NULLT ? e : ownV(e);
      // A later tuple member can throw. Protect earlier owned strings until the
      // aggregate is complete, then transfer their ownership to the tuple value.
      if (e.t->k == STR && e.owned) borrow(e);
    }
    else if (target) { checkImplicit(e, mt, n->line); e = cv(e, mt, n->line); }
    vals.push_back(e); ts.push_back(mt);
  }
  T tt = target ? target : tTuple(ts);
  std::string cur = "undef";
  for (size_t i = 0; i < vals.size(); i++) cur = def("insertvalue " + llty(tt) + " " + cur + ", " + llty(ts[i]) + " " + (vals[i].t->k == NULLT ? "null" : vals[i].v) + ", " + std::to_string(i));
  for (const V &e : vals) if (e.t->k == STR && e.owned) transferTemp(e);
  V r; r.t = tt; r.v = cur; r.owned = needsFree(tt); return r;
}

V propagateExpr(Node *n) {
  V src = expr(n->c[0].get());
  if (!cf || cf->ret->k != ENUM || !cf->ret->payloadEnum)
    err("operator '?' ใช้ได้เฉพาะใน function ที่คืนค่า native Option<T> หรือ Result<T, E>", n->line);
  if (src.t->k != ENUM || !src.t->payloadEnum)
    err("operator '?' ต้องใช้กับ native Option<T> หรือ Result<T, E>", n->line);
  borrow(src);

  auto fi = enums.find(src.t->name), ti = enums.find(cf->ret->name);
  if (fi == enums.end() || ti == enums.end()) err("ภายใน compiler: ไม่พบ metadata ของ generic enum", n->line);
  EnumInfo &from = fi->second;
  EnumInfo &to = ti->second;
  const std::string family = from.genericOrigin;
  if ((family != "Option" && family != "Result") || from.module != "result" || to.module != "result")
    err("operator '?' รองรับเฉพาะ native result.Option<T> และ result.Result<T, E> จาก result.fac", n->line);
  if (to.genericOrigin != family)
    err("operator '?' ต้องคืนค่าในตระกูล " + family + " เดียวกัน (return เป็น " + to.name + ")", n->line);

  auto findVariant = [&](EnumInfo &ei, const std::string &name) -> size_t {
    size_t ix = 0;
    if (!enumMember(ei, name, &ix)) err("native " + family + " enum ไม่มี variant " + name, n->line);
    return ix;
  };
  const size_t fromOk = findVariant(from, family == "Option" ? "Some" : "Ok");
  const size_t fromBad = findVariant(from, family == "Option" ? "None" : "Err");
  const size_t toOk = findVariant(to, family == "Option" ? "Some" : "Ok");
  const size_t toBad = findVariant(to, family == "Option" ? "None" : "Err");
  if (from.payloadTypes[fromOk].size() != 1 || to.payloadTypes[toOk].size() != 1 ||
      from.payloadTypes[fromBad].size() != (family == "Option" ? 0u : 1u) ||
      to.payloadTypes[toBad].size() != (family == "Option" ? 0u : 1u))
    err("รูปแบบ variant ของ " + family + " ไม่ถูกต้อง", n->line);

  T srcValueTy = from.payloadTypes[fromOk][0];
  T dstValueTy = to.payloadTypes[toOk][0];
  if (family == "Result" && !sameT(from.payloadTypes[fromBad][0], to.payloadTypes[toBad][0]))
    err("Result propagation ต้องใช้ชนิด error เดียวกัน (" + tname(from.payloadTypes[fromBad][0]) + " กับ " + tname(to.payloadTypes[toBad][0]) + ")", n->line);

  std::string tagAddr = def("getelementptr inbounds " + llty(src.t) + ", ptr " + src.v + ", i32 0, i32 0");
  std::string tag = def("load i32, ptr " + tagAddr);
  std::string failed = def("icmp eq i32 " + tag + ", " + std::to_string(fromBad));
  std::string bad = lbl("propagate.fail"), good = lbl("propagate.ok");
  cbr(failed, bad, good);

  // Build the failure variant in the function's declared specialization.
  placeLabel(bad);
  std::string propagated = alloca_(cf->ret);
  ins("store " + llty(cf->ret) + " zeroinitializer, ptr " + propagated);
  std::string dstTag = def("getelementptr inbounds " + llty(cf->ret) + ", ptr " + propagated + ", i32 0, i32 0");
  ins("store i32 " + std::to_string(toBad) + ", ptr " + dstTag);
  if (family == "Result") {
    T srcErrorTy = from.payloadTypes[fromBad][0];
    T dstErrorTy = to.payloadTypes[toBad][0];
    V errorValue = decodeEnumPayload(from.name, src.v, 0, srcErrorTy);
    std::string encoded = encodeEnumPayload(errorValue, dstErrorTy, n->line);
    ins("store i64 " + encoded + ", ptr " + enumSlotAddr(to.name, propagated, 0));
  }
  std::string retValue = def("load " + llty(cf->ret) + ", ptr " + propagated);
  flushTemps(0, false);
  cleanupAll(0, nullptr);
  emitRecursionLeave();
  ins("ret " + llty(cf->ret) + " " + retValue);
  term = true;

  placeLabel(good);
  return decodeEnumPayload(from.name, src.v, 0, srcValueTy);
}

V moveExpr(Node *n) {
  if (!opt.strictMove) err("move() ต้องเปิดใช้ --strict-move เพื่อให้มีการตรวจ use-after-move", n->line);
  if (n->c.size() != 2 || !n->c[1])
    err("move() ต้องรับ local variable หรือ named struct field path", n->line);
  if (n->c[1]->k == NK::Member) {
    Node *fieldNode = n->c[1].get();
    std::vector<std::string> segments;
    Node *base = fieldNode;
    while (base && base->k == NK::Member && base->c.size() == 1) {
      segments.push_back(base->s);
      base = base->c[0].get();
    }
    if (!base || base->k != NK::Ident || segments.empty())
      err("partial move ต้องเป็น named field path ที่มี local struct เป็นราก", n->line);
    std::reverse(segments.begin(), segments.end());

    Var *root = findLocal(base->s);
    if (!root) err("partial move ต้องใช้ local struct variable โดยตรง", n->line);
    if (root->isParam || root->isBorrowedAlias || root->slot == "%self" || root->kind == "heap" || root->indirect)
      err("partial move ไม่อนุญาตกับ parameter/self/borrow alias/heap storage", n->line);
    if (root->isConst || root->isVolatile || !root->ty || root->ty->isVolatile)
      err("partial move ต้องใช้ local mutable struct", n->line);
    if (root->ty->k != STRUCT)
      err("partial move ใช้ได้เฉพาะ field ของ local value struct", n->line);

    T current = root->ty;
    for (size_t i = 0; i < segments.size(); ++i) {
      if (!current || current->k != STRUCT)
        err("nested partial move รองรับเฉพาะเส้นทาง value struct; ไม่รองรับ class/object/interface หรือ dynamic storage", n->line);
      StructInfo &si = structInfo(current->name, n->line);
      if (si.isClass || si.isInterface)
        err("partial move ไม่อนุญาตภายใน class/interface; ใช้ value struct เท่านั้น", n->line);
      int fi = fieldIndex(si, segments[i], n->line);
      const FieldInfo &field = si.fields[(size_t)fi];
      if (!field.isPublic && !canAccessMember(field.owner, field.isPrivate, field.isProtected))
        err("field '" + segments[i] + "' ไม่มีสิทธิ์เข้าถึงจาก partial move", n->line);
      if (field.isConst)
        err("partial move ไม่อนุญาตกับ const field '" + segments[i] + "'", n->line);
      current = field.ty;
      if (i + 1 < segments.size() && (!current || current->k != STRUCT))
        err("ทุก field ระหว่างทางของ nested partial move ต้องเป็น value struct", n->line);
    }

    T ft = current;
    const bool managedHandle = ft &&
      (ft->k == STR || ft->k == LIST || ft->k == DSK || ft->k == FUNC ||
       ft->k == OBJ || ft->k == WEAK);
    const bool managedValueStruct = ft && ft->k == STRUCT && needsFree(ft) &&
      !structInfo(ft->name, n->line).isClass && !structInfo(ft->name, n->line).isInterface;
    const bool managedPayloadEnum = ft && ft->k == ENUM && ft->payloadEnum && needsFree(ft);
    if (!managedHandle && !managedValueStruct && !managedPayloadEnum)
      err("partial move รองรับ managed handle, managed value struct หรือ managed payload enum; ไม่รองรับ scalar, unit enum, array หรือ raw ptr", n->line);

    LV lv = lval(fieldNode); // validates every access and yields the final field slot
    V r; r.t = ft; r.owned = true;
    if (ft->k == STRUCT || (ft->k == ENUM && ft->payloadEnum)) {
      r.v = alloca_(ft);
      std::string value = def("load " + llty(ft) + ", ptr " + lv.addr);
      ins("store " + llty(ft) + " " + value + ", ptr " + r.v);
      ins("store " + llty(ft) + " zeroinitializer, ptr " + lv.addr);
    } else {
      r.v = def("load ptr, ptr " + lv.addr);
      ins("store ptr null, ptr " + lv.addr);
    }
    borrow(r);
    return r;
  }
  if (n->c[1]->k != NK::Ident)
    err("move() ต้องรับ local variable หรือ named struct field path", n->line);
  const std::string &name = n->c[1]->s;
  Var *v = findLocal(name);
  if (!v) err("move(): ต้องเป็นตัวแปร local (ไม่รองรับ global/field/parameter): '" + name + "'", n->line);
  if (v->isParam || v->isBorrowedAlias || v->slot == "%self") err("move(): ไม่อนุญาตให้ย้าย ownership จาก parameter/self/local borrow alias ที่เป็น borrowed value", n->line);
  if (v->isConst || v->isVolatile || v->ty->isVolatile || v->kind == "heap")
    err("move(): source ต้องเป็น local mutable variable ที่มี cleanup ownership: '" + name + "'", n->line);
  T t = v->ty;
  if (!needsFree(t) || t->k == TUPLE)
    err("move(): รองรับเฉพาะ managed values (string/list/data structure/function/object/weak/managed struct/payload enum)", n->line);

  std::string addr = varAddr(*v);
  V r; r.t = t; r.owned = true;
  if (t->k == STRUCT || (t->k == ENUM && t->payloadEnum)) {
    r.v = alloca_(t);
    const std::string bytes = std::to_string(sizeOf(t));
    ins("call void @llvm.memcpy.p0.p0.i64(ptr " + r.v + ", ptr " + addr + ", i64 " + bytes + ", i1 false)");
    ins("call void @llvm.memset.p0.i64(ptr " + addr + ", i8 0, i64 " + bytes + ", i1 false)");
  } else {
    r.v = def("load ptr, ptr " + addr);
    ins("store ptr null, ptr " + addr);
  }
  borrow(r);
  return r;
}

// A deliberately conservative integer constant folder for pure literal trees.
// The evaluator walks each node once (bottom-up), rejects every intermediate
// value that would leave its FAC type range, and has a small depth/node budget.
// Potential overflow, division-by-zero and side-effecting expressions remain IR.
bool foldIntFitsType(int64_t value, const T &type) {
  if (type->k == BOOL) return value == 0 || value == 1;
  if (!isIntLike(type)) return false;
  const int bits = bitsOf(type);
  if (bits <= 0) return false;
  if (signedOf(type)) {
    if (bits >= 64) return true;
    const int64_t limit = int64_t(1) << (bits - 1);
    return value >= -limit && value < limit;
  }
  if (value < 0) return false;
  if (bits >= 64) return true;
  return static_cast<uint64_t>(value) < (uint64_t(1) << bits);
}

bool evalFoldIntExpr(Node *n, int64_t &value, T &type, size_t &visited) {
  if (!n || ++visited > 64) return false;
  switch (n->k) {
    case NK::IntLit:
      value = n->iv;
      type = (n->iv >= INT32_MIN && n->iv <= INT32_MAX) ? T_int : T_long;
      return true;
    case NK::CharLit:
      value = n->iv;
      type = n->iv < 128 ? T_char : T_uni;
      return true;
    case NK::BoolLit:
      value = n->b ? 1 : 0;
      type = T_bool;
      return true;
    case NK::Unary: {
      if (n->c.empty()) return false;
      int64_t operand = 0;
      T operandType;
      if (!evalFoldIntExpr(n->c[0].get(), operand, operandType, visited)) return false;
      if (n->s == "+") { value = operand; type = operandType; }
      else if (n->s == "!") { value = operand == 0; type = T_bool; }
      else if (n->s == "-") {
        if (operand == INT64_MIN) return false;
        value = -operand; type = promote(operandType);
      } else if (n->s == "~") {
        value = constFromBits(~static_cast<uint64_t>(operand));
        type = promote(operandType);
      } else return false;
      return foldIntFitsType(value, type);
    }
    case NK::Binary: {
      if (n->c.size() < 2) return false;
      int64_t left = 0, right = 0;
      T leftType, rightType;
      if (!evalFoldIntExpr(n->c[0].get(), left, leftType, visited) ||
          !evalFoldIntExpr(n->c[1].get(), right, rightType, visited)) return false;
      const std::string &op = n->s;
      if (op == "&&" || op == "||") {
        value = op == "&&" ? ((left != 0) && (right != 0)) : ((left != 0) || (right != 0));
        type = T_bool;
        return true;
      }
      const T operandType = commonT(leftType, rightType);
      // constEval-style signed host math cannot model FAC's modulo conversion
      // when a negative operand participates in an unsigned operation/compare.
      // Leave those cases to LLVM instead of risking a wrong compile-time value.
      if (!signedOf(operandType) && (left < 0 || right < 0)) return false;
      if (op == "+") { if (__builtin_add_overflow(left, right, &value)) return false; }
      else if (op == "-") { if (__builtin_sub_overflow(left, right, &value)) return false; }
      else if (op == "*") { if (__builtin_mul_overflow(left, right, &value)) return false; }
      else if (op == "/" || op == "%") {
        if (right == 0 || (left == INT64_MIN && right == -1)) return false;
        value = op == "/" ? left / right : left % right;
      } else if (op == "&") value = constFromBits(static_cast<uint64_t>(left) & static_cast<uint64_t>(right));
      else if (op == "|") value = constFromBits(static_cast<uint64_t>(left) | static_cast<uint64_t>(right));
      else if (op == "^") value = constFromBits(static_cast<uint64_t>(left) ^ static_cast<uint64_t>(right));
      else if (op == "==") value = left == right;
      else if (op == "!=") value = left != right;
      else if (op == "<") value = left < right;
      else if (op == "<=") value = left <= right;
      else if (op == ">") value = left > right;
      else if (op == ">=") value = left >= right;
      else return false;
      const bool comparison = op == "==" || op == "!=" || op == "<" || op == "<=" || op == ">" || op == ">=";
      type = comparison ? T_bool : operandType;
      return foldIntFitsType(value, type);
    }
    default:
      return false;
  }
}

bool tryFoldIntExpr(Node *n, V &out) {
  size_t visited = 0;
  int64_t value = 0;
  T type;
  if (!evalFoldIntExpr(n, value, type, visited)) return false;
  out.t = type;
  out.v = std::to_string(value);
  return true;
}

V expr(Node *n) {
  curLine = n->line;
  switch (n->k) {
    case NK::IntLit: return constInt(n->iv);
    case NK::FloatLit: { V r; r.t = T_double; r.v = fhex(n->dv); return r; }
    case NK::CharLit: { V r; r.t = n->iv < 128 ? T_char : T_uni; r.v = std::to_string(n->iv); return r; }
    case NK::StrLit: { V r; r.t = T_str; r.v = strLit(n->s); return r; }
    case NK::BoolLit: { V r; r.t = T_bool; r.v = n->b ? "1" : "0"; return r; }
    case NK::NullLit: { V r; r.t = T_null; r.v = "null"; return r; }
    case NK::Ident: return identExpr(n);
    case NK::Member: return memberExpr(n);
    case NK::Index: { V s; LV l = indexLV(n, &s); if (l.addr.empty()) return s; return loadLV(l); }
    case NK::Deref: return loadLV(lval(n));
    case NK::Slice: return sliceExpr(n);
    case NK::Unary: { V folded; if (tryFoldIntExpr(n, folded)) return folded; return unaryExpr(n); }
    case NK::PostInc: return postInc(n);
    case NK::Binary: {
      V folded; if (tryFoldIntExpr(n, folded)) return folded;
      if (n->s == "instanceof") return instanceOfExpr(n);
      if (n->s == "&&" || n->s == "||") return shortCircuit(n);
      if (n->s == "+" && isStringConcatTree(n)) {
        std::vector<Node *> parts; collectStringConcatParts(n, parts);
        if (parts.size() >= 3) return stringConcatChain(n, n->line);
      }
      { V a = expr(n->c[0].get()); if (a.t->k == STR) borrow(a); V b = expr(n->c[1].get()); return binop(n->s, a, b, n->line); }
    }
    case NK::Assign: return assignExpr(n);
    case NK::Call:
      if (!n->c.empty() && n->c[0]->k == NK::Ident && n->c[0]->s == "move") return moveExpr(n);
      if (!n->c.empty() && n->c[0]->k == NK::Ident && isTypeQueryName(n->c[0]->s) &&
          typeQueryArguments(n)) {
        const std::string &query = n->c[0]->s;
        if (isStructuralReflectionName(query)) {
          T target;
          StructInfo *record = nullptr;
          int64_t visibleIndex = 0;
          bool hasIndex = false;
          if (!resolveReflectionTarget(n, target, record, visibleIndex, hasIndex))
            err(query + " ต้องรับ type argument ของ struct/class ที่ resolve แล้ว" +
                (query == "fieldCount" ? " ในรูปแบบ fieldCount<T>()" : " และ const field index ในรูปแบบ " + query + "<T, I>()") +
                " โดยไม่มี runtime arguments", n->line);
          const std::vector<size_t> visible = publicReflectionFieldIndices(*record);
          if (query == "fieldCount") return constInt(static_cast<int64_t>(visible.size()));
          const size_t actualIndex = checkedReflectionFieldIndex(*record, visibleIndex, n->line, query);
          const FieldInfo &field = record->fields[actualIndex];
          if (query == "fieldName") { V result; result.t = T_str; result.v = strLit(field.name); return result; }
          if (query == "fieldType") return enumV("Type", typeQueryCategory(field.ty));
          if (query == "fieldOffset") return constInt(reflectedFieldOffset(*record, actualIndex, n->line));
          err("unknown structural reflection intrinsic", n->line);
        }
        T target;
        if (!resolveTypeQueryTarget(n, target))
          err("typeOf/sizeof/alignof ต้องรับ type argument เดียวในรูปแบบ name<T>() และไม่มี runtime arguments", n->line);
        if (query == "typeOf") return enumV("Type", typeQueryCategory(target));
        if (target->k == VOID || target->k == AUTOT || target->k == NULLT || target->k == TUPLE || target->k == FUNC)
          err(query + " ไม่รองรับ type " + tname(target), n->line);
        if (query == "sizeof" && target->k == ARR)
          err("sizeof<array T>() ต้องระบุ fixed extent; unsized array ไม่มี object size คงที่", n->line);
        if (target->k == STRUCT) {
          auto it = structs.find(target->name);
          if (it == structs.end() || !it->second.resolved)
            err(query + " ต้องใช้หลังจาก compiler resolve layout ของ struct " + target->name + " แล้ว", n->line);
        }
        return constInt(query == "sizeof" ? sizeOf(target) : alignOf(target));
      }
      if (FuncInfo *compileTimeFunction = findConstevalFunction(n, curModule)) {
        int64_t value = 0;
        if (!constEval(n, value))
          err("consteval function '" + compileTimeFunction->name + "' ต้องรับ compile-time scalar arguments และใช้เฉพาะ expression/control flow ที่ evaluator รองรับ", n->line);
        V result; result.t = compileTimeFunction->ret; result.v = std::to_string(value); return result;
      }
      return callExpr(n);
    case NK::Propagate: return propagateExpr(n);
    case NK::New: return constructClass(n->s, [&]() { std::vector<Node *> a; for (auto &x : n->c) a.push_back(x.get()); return a; }(), n);
    case NK::IfV: return ifvExpr(n);
    case NK::MatchExpr: return matchExpr(n);
    case NK::LoopIdx: return loopIdx(n);
    case NK::TupleLit: return tupleLit(n, nullptr);
    case NK::Lambda: return lambdaExpr(n);
    case NK::InitList: err("{...} ใช้ได้เฉพาะตอนประกาศ array/list หรือ x[i] = {...}", n->line);
    default: err("นิพจน์นี้ยังไม่รองรับ", n->line);
  }
}
