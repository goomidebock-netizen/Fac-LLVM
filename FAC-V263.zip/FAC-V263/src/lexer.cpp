#include "lexer.hpp"
#include <utility>

std::vector<Tok> lex(const std::string &src, size_t *compilationTokens) {
  // A 64 MiB source-file cap alone still permits millions of tiny tokens.
  // Bound each file and the complete import graph so splitting hostile input
  // across many modules cannot bypass the memory budget.
  static constexpr size_t kMaxTokens = kMaxTokensPerSourceUnit;
  std::vector<Tok> out;
  size_t i = 0, n = src.size();
  int line = 1;
  size_t lineStart = 0;
  bool nl = false;
  if (n >= 3 && (unsigned char)src[0] == 0xEF && (unsigned char)src[1] == 0xBB && (unsigned char)src[2] == 0xBF) { i = 3; lineStart = 3; }
  auto push = [&](Tok t) {
    if (out.size() >= kMaxTokens)
      throw CompileError(line, "จำนวน token เกิน 1,000,000 ต่อไฟล์ -- ลดขนาดไฟล์หรือแบ่งเป็นโมดูลย่อย", t.column);
    if (compilationTokens && *compilationTokens >= kMaxTokensPerCompilation)
      throw CompileError(line, "จำนวน token รวมเกิน 2,000,000 ต่อ compilation -- ลดขนาดโปรเจกต์หรือแบ่งการ build", t.column);
    t.line = line; if (!t.column) t.column = static_cast<int>(i - lineStart + 1); t.nl = nl; nl = false; out.push_back(std::move(t));
    if (compilationTokens) ++*compilationTokens;
  };
  auto isid0 = [](char c) { return isalpha((unsigned char)c) || c == '_'; };
  auto isid = [](char c) { return isalnum((unsigned char)c) || c == '_'; };
  // Parse an explicit loop-index path. Segments are read from the innermost
  // direction outward, e.g. `for--.for++.i` selects a descending inner loop
  // and then an ascending outer loop. Legacy one-segment forms remain valid.
  auto loopIndexPath = [&](size_t q, char firstDir, std::string &path, size_t &end) -> bool {
    path.clear(); path.push_back(firstDir);
    auto segment = [&](size_t at, size_t &len, char &dir) -> bool {
      static const struct { const char *text; char dir; } forms[] = {
        {"for++", 'u'}, {"for--", 'd'}, {"++for", 'd'}, {"--for", 'd'}
      };
      for (const auto &form : forms) {
        const size_t size = std::strlen(form.text);
        if (at + size < n && src.compare(at, size, form.text) == 0 && src[at + size] == '.') {
          len = size + 1; dir = form.dir; return true;
        }
      }
      return false;
    };
    while (true) {
      size_t len = 0; char dir = 0;
      if (!segment(q, len, dir)) break;
      if (path.size() >= 64) throw CompileError(line, "loop index selector ซ้อนลึกเกิน 64 ระดับ");
      path.push_back(dir); q += len;
    }
    size_t m = q;
    while (m < n && isid(src[m])) ++m;
    if (m == q || src.substr(q, m - q) != "i") return false;
    end = m;
    return true;
  };
  auto escape = [&](char e, int ln) -> uint32_t {
    switch (e) {
      case '0': return 0; case 'n': return '\n'; case 't': return '\t'; case 'r': return '\r';
      case '\\': return '\\'; case '\'': return '\''; case '"': return '"';
      case '{': return 1; case '}': return 2;  // \{ \} ในสตริง (ไม่ใช่ interpolation)
      default: throw CompileError(ln, std::string("escape ไม่รู้จัก: \\") + e);
    }
  };
  while (i < n) {
    char c = src[i];
    if (c == '\n') { line++; nl = true; i++; lineStart = i; continue; }
    if (c == ' ' || c == '\t' || c == '\r') { i++; continue; }
    if (c == '#') {
      if (i + 1 < n && src[i + 1] == '*') {  // #* ... *#
        int start = line; i += 2;
        while (true) {
          if (i + 1 >= n) throw CompileError(start, "unterminated comment");
          if (src[i] == '*' && src[i + 1] == '#') { i += 2; break; }
          if (src[i] == '\n') { line++; lineStart = i + 1; }
          i++;
        }
        continue;
      }
      while (i < n && src[i] != '\n') i++;  // # และ ## (doc comment)
      continue;
    }
    Tok t; t.column = static_cast<int>(i - lineStart + 1);
    if (isid0(c)) {
      size_t j = i; while (j < n && isid(src[j])) j++;
      std::string w = src.substr(i, j - i);
      if (w == "for" && j + 1 < n && src[j] == '+' && src[j + 1] == '+') {
        size_t k = j + 2; while (k < n && (src[k] == ' ' || src[k] == '\t')) k++;
        if (k < n && src[k] == '(') { t.t = Tok::ForPP; t.s = "for++"; i = j + 2; push(t); continue; }
        if (j + 2 < n && src[j + 2] == '.') {  // for++.i / for++.for++.i
          std::string path; size_t m = 0;
          if (!loopIndexPath(j + 3, 'u', path, m))
            throw CompileError(line, "for++ index path ต้องลงท้ายด้วย .i เช่น for++.i หรือ for++.for++.i");
          t.t = Tok::LoopUp; t.s = src.substr(i, m - i); t.iv = static_cast<int64_t>(path.size() - 1); i = m; push(t); continue;
        }
      }
      if (w == "for" && j + 1 < n && src[j] == '-' && src[j + 1] == '-') {
        size_t k = j + 2; while (k < n && (src[k] == ' ' || src[k] == '\t')) k++;
        if (k < n && src[k] == '(') { t.t = Tok::ForDown; t.s = "for--"; i = j + 2; push(t); continue; }
        if (j + 2 < n && src[j + 2] == '.') {
          std::string path; size_t m = 0;
          if (!loopIndexPath(j + 3, 'd', path, m))
            throw CompileError(line, "for-- index path ต้องลงท้ายด้วย .i เช่น for--.i หรือ for--.for--.i");
          t.t = Tok::LoopForDown; t.s = src.substr(i, m - i); t.iv = static_cast<int64_t>(path.size() - 1); i = m; push(t); continue;
        }
      }
      t.t = Tok::Ident; t.s = w; i = j; push(t); continue;
    }
    if (c == '+' && i + 1 < n && src[i + 1] == '+' && i + 4 < n && src.compare(i + 2, 3, "for") == 0 && !(i + 5 < n && isid(src[i + 5]))) {
      size_t k = i + 5; while (k < n && (src[k] == ' ' || src[k] == '\t')) k++;
      if (k < n && src[k] == '(') { t.t = Tok::PPFor; t.s = "++for"; i = i + 5; push(t); continue; }
      if (i + 5 < n && src[i + 5] == '.') {
        std::string path; size_t m = 0;
        if (!loopIndexPath(i + 6, 'd', path, m))
          throw CompileError(line, "++for index path ต้องลงท้ายด้วย .i เช่น ++for.i หรือ ++for.++for.i");
        t.t = Tok::LoopDown; t.s = src.substr(i, m - i); t.iv = static_cast<int64_t>(path.size() - 1); i = m; push(t); continue;
      }
    }
    if (c == '-' && i + 1 < n && src[i + 1] == '-' && i + 4 < n && src.compare(i + 2, 3, "for") == 0 && !(i + 5 < n && isid(src[i + 5]))) {
      size_t k = i + 5; while (k < n && (src[k] == ' ' || src[k] == '\t')) k++;
      if (k < n && src[k] == '(') { t.t = Tok::DownFor; t.s = "--for"; i = i + 5; push(t); continue; }
      if (i + 5 < n && src[i + 5] == '.') {
        std::string path; size_t m = 0;
        if (!loopIndexPath(i + 6, 'd', path, m))
          throw CompileError(line, "--for index path ต้องลงท้ายด้วย .i เช่น --for.i หรือ --for.--for.i");
        t.t = Tok::LoopDownFor; t.s = src.substr(i, m - i); t.iv = static_cast<int64_t>(path.size() - 1); i = m; push(t); continue;
      }
    }
    if (isdigit((unsigned char)c)) {
      size_t j = i; bool isf = false; int base = 10;
      if (c == '0' && i + 1 < n && (src[i + 1] == 'x' || src[i + 1] == 'X')) { base = 16; j = i + 2; }
      else if (c == '0' && i + 1 < n && (src[i + 1] == 'b' || src[i + 1] == 'B')) { base = 2; j = i + 2; }
      else if (c == '0' && i + 1 < n && (src[i + 1] == 'o' || src[i + 1] == 'O')) { base = 8; j = i + 2; }
      if (base != 10) {
        const size_t digitsBegin = j;
        bool hasSeparator = false, hasDigit = false;
        while (j < n && (isxdigit((unsigned char)src[j]) || src[j] == '_')) {
          hasSeparator = hasSeparator || src[j] == '_';
          hasDigit = hasDigit || src[j] != '_';
          j++;
        }
        if (j == digitsBegin || !hasDigit) throw CompileError(line, "เลขฐานไม่มีหลัก");
        // Avoid a temporary string for the common case. strtoull can parse
        // directly from the source buffer; only separator-bearing literals
        // need a compacted copy.
        std::string compact;
        const char *begin = src.c_str() + digitsBegin;
        if (hasSeparator) {
          compact.reserve(j - digitsBegin);
          for (size_t k = digitsBegin; k < j; ++k) if (src[k] != '_') compact += src[k];
          begin = compact.c_str();
        }
        errno = 0; char *endp = nullptr; unsigned long long v = strtoull(begin, &endp, base);
        if (errno == ERANGE) throw CompileError(line, "เลขฐาน " + std::to_string(base) + " เกิน 64 บิต");
        const char *expectedEnd = begin + (hasSeparator ? compact.size() : j - digitsBegin);
        if (!endp || endp != expectedEnd) {
          char bad = endp && *endp ? *endp : '\0';
          throw CompileError(line, "เลขฐาน " + std::to_string(base) + " มีหลักที่ไม่ถูกต้อง: '" + (bad ? std::string(1, bad) : std::string()) + "'");
        }
        t.t = Tok::Int; t.iv = (int64_t)v;
      } else {
        const size_t digitsBegin = i;
        bool hasSeparator = false;
        while (j < n && (isdigit((unsigned char)src[j]) || src[j] == '_')) {
          hasSeparator = hasSeparator || src[j] == '_';
          j++;
        }
        if (j + 1 < n && src[j] == '.' && isdigit((unsigned char)src[j + 1])) { isf = true; j++; while (j < n && isdigit((unsigned char)src[j])) j++; }
        if (j < n && (src[j] == 'e' || src[j] == 'E') && j + 1 < n && (isdigit((unsigned char)src[j + 1]) || ((src[j + 1] == '-' || src[j + 1] == '+') && j + 2 < n && isdigit((unsigned char)src[j + 2])))) {
          isf = true; j++; if (src[j] == '-' || src[j] == '+') j++; while (j < n && isdigit((unsigned char)src[j])) j++;
        }
        // Most numeric literals have no separators. Parse those in-place from
        // the NUL-terminated source buffer and allocate a compact copy only
        // for the less common underscore form.
        std::string compact;
        const char *number = src.c_str() + digitsBegin;
        if (hasSeparator) {
          compact.reserve(j - digitsBegin);
          for (size_t k = digitsBegin; k < j; ++k) if (src[k] != '_') compact += src[k];
          number = compact.c_str();
        }
        if (isf) { t.t = Tok::Float; t.dv = strtod(number, nullptr); }
        else {
          // Decimal integers are signed-long values; 2^63 is retained as a
          // special literal for the unary-minus boundary case.
          errno = 0; unsigned long long v = strtoull(number, nullptr, 10);
          if (errno == ERANGE || v > 9223372036854775808ULL) {
            const std::string shown = hasSeparator ? compact : src.substr(digitsBegin, j - digitsBegin);
            throw CompileError(line, "เลข " + shown + " ใหญ่เกินช่วง long (สูงสุด 9223372036854775807); ถ้าต้องการ bit pattern 64 บิตใช้เลขฐาน 16 เช่น 0xFFFFFFFFFFFFFFFF");
          }
          t.t = Tok::Int; t.iv = (int64_t)v; t.big = (v == 9223372036854775808ULL);
        }
      }
      i = j; push(t); continue;
    }
    if (c == '\'') {
      i++; if (i >= n) throw CompileError(line, "char literal ไม่จบ");
      uint32_t cp;
      if (src[i] == '\\') { if (i + 1 >= n) throw CompileError(line, "char literal ไม่จบ"); cp = escape(src[i + 1], line); i += 2; }
      else { cp = utf8dec(src, i); if (cp == kBadUtf8) throw CompileError(line, "char literal ไม่ใช่ UTF-8 ที่ถูกต้อง (overlong / surrogate / เกิน U+10FFFF / ไบต์ขาด)"); }
      if (i >= n || src[i] != '\'') throw CompileError(line, "char literal ต้องมี 1 ตัวอักษร");
      i++; t.t = Tok::Char; t.iv = cp; push(t); continue;
    }
    if (c == '"') {
      i++; std::string s;
      while (true) {
        if (i >= n || src[i] == '\n') throw CompileError(line, "string literal ไม่ปิด \"");
        if (src[i] == '"') { i++; break; }
        if (src[i] == '\\') { if (i + 1 >= n) throw CompileError(line, "string ไม่จบ"); s += (char)escape(src[i + 1], line); i += 2; }
        else s += src[i++];
      }
      t.t = Tok::Str; t.s = s; push(t); continue;
    }
    struct OpToken { const char *text; size_t length; };
    static constexpr OpToken ops[] = {{"=>", 2}, {"**=", 3}, {"<<=", 3}, {">>=", 3}, {"&&=", 3}, {"||=", 3}, {"..", 2},
      {"++", 2}, {"--", 2}, {"**", 2}, {"<<", 2}, {">>", 2}, {"<=", 2}, {">=", 2}, {"==", 2}, {"!=", 2},
      {"&&", 2}, {"||", 2}, {"+=", 2}, {"-=", 2}, {"*=", 2}, {"/=", 2}, {"%=", 2}, {"&=", 2}, {"|=", 2},
      {"^=", 2}, {"~=", 2}};
    bool found = false;
    for (const auto &op : ops) {
      if (op.text[0] != c) continue;
      // Preserve the existing three-dot variadic tokenization: `...` must
      // remain three separate dots rather than becoming `..` followed by `.`.
      if (op.length == 2 && op.text[0] == '.' && op.text[1] == '.' &&
          ((i > 0 && src[i - 1] == '.') || (i + 2 < n && src[i + 2] == '.'))) continue;
      if (src.compare(i, op.length, op.text) == 0) { t.t = Tok::Op; t.s = op.text; i += op.length; found = true; break; }
    }
    if (!found) {
      if (strchr("+-*/%&|^~!<>=(){}[],;.:?", c)) { t.t = Tok::Op; t.s = std::string(1, c); i++; }
      else throw CompileError(line, std::string("อักขระที่ไม่รู้จัก: '") + c + "'");
    }
    push(t);
  }
  Tok e; e.t = Tok::End; e.line = line; e.column = static_cast<int>(n - lineStart + 1); e.nl = true; out.push_back(e);
  return out;
}

