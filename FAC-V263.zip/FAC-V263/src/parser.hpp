#pragma once
#include "lexer.hpp"
#include "ast.hpp"
#include <algorithm>
#include <memory>
#include <set>
#include <string>
#include <string_view>
#include <unordered_set>
#include <utility>
#include <vector>

// ============================================================ Parser
struct Parser {
  std::vector<Tok> t; size_t p = 0; int paren = 0;
  std::set<std::string> genericTypeParams;
  // While parsing generic const expressions, a top-level `>` closes the
  // argument list rather than acting as a relational operator. Parenthesized
  // expressions temporarily leave this top-level context.
  int genericAngleExprDepth = 0;
  // Nesting guard (security/stability): source nested or chained absurdly deep must produce a normal
  // compile error, never a stack-overflow crash of the compiler (parser, codegen and AST destructors are recursive).
  static constexpr int kMaxNest = 1500;    // recursion units (a block/expression level costs 1-2 units)
  static constexpr int kMaxChain = 1000;   // operators in one left-associative chain (a+b+c...) or postfix chain (a.b().c()...)
  int nest = 0;
  // Shared by all source units and nested interpolation parsers in one Loader.
  // Standalone parser users may leave this null for the per-source limit only.
  size_t *tokenBudgetUsed = nullptr;
  struct NestGuard {
    Parser &ps; int w;
    explicit NestGuard(Parser &x, int weight = 1) : ps(x), w(weight) { ps.nest += w; if (ps.nest > kMaxNest) throw CompileError(ps.cur().line, "โค้ดซ้อนลึกเกินไป (เกิน " + std::to_string(kMaxNest / 2) + " ระดับ) -- แยกเป็นฟังก์ชันย่อย", ps.cur().column); }
    ~NestGuard() { ps.nest -= w; }
    NestGuard(const NestGuard &) = delete; NestGuard &operator=(const NestGuard &) = delete;
  };
  static bool isDS(const std::string &s) {
    return s == "arraylist" || s == "linked" || s == "hashmap" || s == "hashset" ||
           s == "tree" || s == "graph" || s == "stack" || s == "queue" ||
           s == "heap" || s == "maxheap" || s == "trie" || s == "matrix";
  }
  static bool isKind(const std::string &s) { return s == "var" || s == "ptr" || s == "dyn" || s == "heap"; }
  static bool isTypeWord(const std::string &s) {
    // This closed vocabulary is queried on parser hot paths. A string_view
    // hash set avoids per-lookup allocation and the pointer chasing of std::set.
    static const std::unordered_set<std::string_view> words = {
        "byte", "short", "int", "long", "ubyte", "ushort", "uint", "ulong",
        "float", "double", "char", "unichar", "string", "boolean", "auto", "void"};
    return words.find(std::string_view(s)) != words.end();
  }
  static bool isReserved(const std::string &s) {
    // Include type words here as well: the old implementation performed two
    // tree lookups for a non-keyword identifier.
    static const std::unordered_set<std::string_view> words = {
        "var", "ptr", "dyn", "heap", "array", "list", "struct", "enum", "function",
        "public", "private", "protected", "final", "consteval", "if", "else", "guard", "select",
        "for", "while", "until", "ifv", "eiv", "elv", "switch", "match", "case",
        "default", "break", "continue", "return", "ref", "import", "module", "const",
        "try", "catch", "finally", "throw", "extern", "export", "true", "false", "null",
        "self", "this", "new", "class", "obj", "constructor", "destructor", "extends",
        "implements", "interface", "abstract", "static", "override", "do", "arraylist",
        "linked", "hashmap", "hashset", "tree", "graph", "stack", "queue", "heap",
        "maxheap", "trie", "matrix", "alias", "defer", "volatile", "align", "instanceof",
        "weak", "static_assert", "noescape", "readonly", "where", "byte", "short", "int", "long",
        "ubyte", "ushort", "uint", "ulong", "float", "double", "char", "unichar",
        "string", "boolean", "auto", "void"};
    return words.find(std::string_view(s)) != words.end();
  }
  Tok &cur() { return t[p]; }
  Tok &peek(size_t k = 1) { return t[std::min(p + k, t.size() - 1)]; }
  [[noreturn]] void err(const std::string &m) { throw CompileError(cur().line, m, cur().column); }
  bool isOp(const char *s) { return cur().t == Tok::Op && cur().s == s; }
  bool isId(const char *s) { return cur().t == Tok::Ident && cur().s == s; }
  bool accOp(const char *s) { if (isOp(s)) { p++; return true; } return false; }
  bool accId(const char *s) { if (isId(s)) { p++; return true; } return false; }
  void expOp(const char *s) { if (!accOp(s)) err(std::string("คาดว่าจะเจอ '") + s + "' แต่เจอ '" + cur().s + "'"); }
  std::string expIdent() { if (cur().t != Tok::Ident) err("คาดว่าจะเป็นชื่อ แต่เจอ '" + cur().s + "'"); return t[p++].s; }
  std::string expQualifiedIdent() {
    std::string n = expIdent();
    while (accOp(".")) n += "." + expIdent();
    return n;
  }
  bool isStructOrEnumDefStart() const {
    if (p >= t.size() || t[p].t != Tok::Ident || (t[p].s != "struct" && t[p].s != "enum")) return false;
    size_t q = p + 2;
    if (q < t.size() && t[q].t == Tok::Op && t[q].s == "{") return true;
    if (q >= t.size() || t[q].t != Tok::Op || t[q].s != "<") return false;
    int depth = 0;
    for (; q < t.size(); q++) {
      if (t[q].t != Tok::Op) continue;
      if (t[q].s == "<") depth++;
      else if (t[q].s == ">") { if (--depth == 0) { q++; break; } }
      else if (t[q].s == ">>" && depth >= 2) { depth -= 2; if (depth == 0) { q++; break; } }
    }
    return depth == 0 && q < t.size() && t[q].t == Tok::Op && t[q].s == "{";
  }
  NP mk(NK k) { return std::make_unique<Node>(k, cur().line); }
  void skipSemi() { while (accOp(";")) {} }
  bool atEnd() { return cur().t == Tok::End || isOp("}") || isOp(";") || (cur().nl && paren == 0); }

  Program parseProgram(const std::string &file) {
    Program pr; pr.file = file;
    skipSemi();
    while (cur().t != Tok::End) {
      // Top-level types are public by default. Explicit public/private controls module export.
      bool hasTypeModifier = false, typePublic = true, typeFinal = false;
      if ((isId("public") || isId("private")) && peek().t == Tok::Ident &&
          (peek().s == "class" || peek().s == "interface" || peek().s == "abstract" || peek().s == "struct" || peek().s == "enum" || peek().s == "final")) {
        typePublic = isId("public"); hasTypeModifier = true; p++;
      }
      if (isId("final") && peek().t == Tok::Ident && peek().s == "class") { typeFinal = true; hasTypeModifier = true; p++; }
      if (isId("static_assert")) {
        const int assertionLine = cur().line;
        p++; expOp("("); paren++;
        NP expression = parseExpr();
        expOp(",");
        if (cur().t != Tok::Str) err("static_assert ต้องมีข้อความ string เป็น argument ที่สอง");
        std::string message = t[p++].s;
        paren--; expOp(")");
        pr.staticAssertions.push_back({std::move(expression), std::move(message), assertionLine});
      }
      else if (isId("import")) {
        int importLine = cur().line;
        p++;
        std::string nm;
        if (cur().t == Tok::Str) {
          std::string f = t[p++].s;
          size_t d = f.rfind('.');
          nm = d == std::string::npos ? f : f.substr(0, d);
          // Keep slash-separated import paths as supplied.
        } else {
          nm = expIdent();
          while (isOp(".") && peek().t == Tok::Ident && peek().s != "fac") { p++; nm += "/" + expIdent(); }
          if (accOp(".")) { if (!accId("fac")) err("import ต้องลงท้ายด้วย .fac"); }
        }
        ImportSpec spec; spec.module = nm; spec.line = importLine;
        bool more = true;
        while (more && !cur().nl) {
          if (accId("global")) spec.global = true;
          else if (accId("as")) {
            spec.alias = expIdent();
            if (spec.alias == "global") err("หากต้องการ import แบบ global ให้ใช้ 'import " + nm + ".fac global' โดยไม่ต้องมี as");
          } else if (accId("just")) {
            if (spec.selection && spec.selection != 1) err("import ใช้ just และ without พร้อมกันไม่ได้");
            spec.selection = 1;
            do { spec.names.insert(expIdent()); } while (accOp(","));
          } else if (accId("without")) {
            if (spec.selection && spec.selection != 2) err("import ใช้ just และ without พร้อมกันไม่ได้");
            spec.selection = 2;
            do { spec.names.insert(expIdent()); } while (accOp(","));
          } else more = false;
        }
        if (!cur().nl && cur().t != Tok::End && !isOp(";") && !isOp("}")) err("หลัง import อนุญาต global, as <name>, just <names> หรือ without <names>");
        for (const auto &old : pr.importSpecs) {
          if (old.module == spec.module && (old.global != spec.global || old.alias != spec.alias || old.selection != spec.selection || old.names != spec.names))
            err("import โมดูล '" + spec.module + "' ซ้ำด้วยรูปแบบที่ขัดแย้งกัน");
          if (!spec.alias.empty() && old.alias == spec.alias && old.module != spec.module)
            err("ชื่อ import alias '" + spec.alias + "' ซ้ำ");
        }
        pr.imports.push_back(nm);
        pr.importSpecs.push_back(spec);
      } else if (isId("module")) { p++; pr.module = expIdent(); }
      else if (isId("link") && peek().t == Tok::Str) { p++; pr.links.push_back(t[p++].s); }
      else if (isId("extern")) pr.funcs.push_back(parseExtern());
      else if (isId("export")) { p++; NP f = parseFunc(); f->isExport = true; f->isPublic = true; pr.funcs.push_back(std::move(f)); }
      else if (isId("alias")) { p++; std::string nm = expIdent(); expOp("="); pr.aliases.push_back({nm, expIdent()}); }
      else if ((isId("public") || isId("private")) && peek().t == Tok::Ident && peek().s != "function" && peek().s != "unsafe" && peek().s != "consteval") {  // ตัวแปร/ค่าคงที่ global: public const var int MAX = 5
        bool pub = isId("public"); p++;
        if (!startsDecl()) err("หลัง public/private ต้องเป็น function หรือการประกาศตัวแปร");
        NP g = parseVarDecl(); if (g->isRef) err("ref local borrow ใช้ประกาศได้เฉพาะภายใน function/block"); g->isPublic = pub;
        if (!atEnd()) err("มีข้อความเกินหลังประกาศตัวแปร: '" + cur().s + "'");
        pr.globals.push_back(std::move(g));
      }
      else if (hasTypeModifier) {
        NP tdef;
        if (accId("abstract")) {
          if (!isId("class")) err("abstract ใช้ได้เฉพาะกับ class");
          tdef = parseClassDef(); tdef->isAbstract = true;
        } else if (isId("interface")) tdef = parseInterfaceDef();
        else if (isId("class")) tdef = parseClassDef();
        else if (isId("struct")) tdef = parseStructDef();
        else if (isId("enum")) tdef = parseEnumDef();
        else err("public/private/final ต้องนำหน้าการประกาศ class, interface, struct หรือ enum");
        if (typeFinal && !tdef->isClass) err("final ใช้ได้เฉพาะกับ class");
        if (typeFinal && tdef->isAbstract) err("class ไม่สามารถเป็นทั้ง abstract และ final ได้");
        tdef->isPublic = typePublic; tdef->isPrivate = !typePublic; tdef->isFinal = typeFinal;
        if (tdef->k == NK::EnumDef) pr.enums.push_back(std::move(tdef));
        else pr.structs.push_back(std::move(tdef));
      }
      else if (isId("public") || isId("private") || isId("function") || isId("consteval") ||
               (isId("unsafe") && peek().t == Tok::Ident && (peek().s == "function" || peek().s == "public" || peek().s == "private"))) pr.funcs.push_back(parseFunc());
      else if (isId("interface")) { NP d = parseInterfaceDef(); d->isPublic = true; pr.structs.push_back(std::move(d)); }
      else if (isId("abstract") && peek().t == Tok::Ident && peek().s == "class") { p++; NP c = parseClassDef(); c->isAbstract = true; c->isPublic = true; pr.structs.push_back(std::move(c)); }
      else if (isId("final") && peek().t == Tok::Ident && peek().s == "class") { p++; NP c = parseClassDef(); c->isFinal = true; c->isPublic = true; pr.structs.push_back(std::move(c)); }
      else if (startsDecl() && !isStructOrEnumDefStart()) {  // ตัวแปร global
        NP g = parseVarDecl();
        if (g->isRef) err("ref local borrow ใช้ประกาศได้เฉพาะภายใน function/block");
        if (!atEnd()) err("มีข้อความเกินหลังประกาศตัวแปร: '" + cur().s + "'");
        pr.globals.push_back(std::move(g));
      }
      else if (isId("struct")) { NP d = parseStructDef(); d->isPublic = true; pr.structs.push_back(std::move(d)); }
      else if (isId("class")) { NP d = parseClassDef(); d->isPublic = true; pr.structs.push_back(std::move(d)); }
      else if (isId("enum")) { NP d = parseEnumDef(); d->isPublic = true; pr.enums.push_back(std::move(d)); }
      else err("ระดับบนสุดของไฟล์ใส่ได้เฉพาะ import / module / function / struct / class / enum / ตัวแปร global (เจอ '" + cur().s + "')");
      skipSemi();
    }
    return pr;
  }

  // Generic type arguments are parsed only in type positions, so ordinary < and >
  // expression operators retain their existing meaning. Split >> when it closes
  // two nested generic argument lists (Box<Box<int>>).
  void expTypeAngleClose() {
    if (accOp(">")) return;
    if (isOp(">>")) {
      Tok first = cur(), second = cur(); first.s = ">"; second.s = ">";
      t[p] = first; t.insert(t.begin() + (long)p + 1, second); p++; return;
    }
    err("คาดว่าจะเจอ '>' ปิด generic type arguments");
  }
  std::vector<TypeSpec> parseGenericArgs() {
    std::vector<TypeSpec> args;
    if (!accOp("<")) return args;
    if (isOp(">") || isOp(">>")) err("generic ต้องมี type argument อย่างน้อยหนึ่งตัว");
    do {
      std::string argumentName;
      if (cur().t == Tok::Ident && peek().t == Tok::Op && peek().s == "=") {
        argumentName = cur().s;
        p += 2; // generic parameter name and '='
      }
      // Type arguments remain unambiguous identifiers/types. Integer literals,
      // unary integer expressions and parenthesized expressions are parsed as
      // deferred const expressions; parentheses also allow named constants
      // such as `(PAGE_SIZE)` without confusing them with type names.
      const bool unaryConst = cur().t == Tok::Op &&
          (cur().s == "+" || cur().s == "-" || cur().s == "~");
      const bool constExprStart = cur().t == Tok::Int || unaryConst || isOp("(");
      if (constExprStart) {
        if (cur().t == Tok::Int && cur().big)
          err("const generic argument ใหญ่เกินช่วง int64");
        // Preserve the common literal form without allocating an expression AST.
        const bool literalOnly = cur().t == Tok::Int &&
            (peek().s == "," || peek().s == ">" || peek().s == ">>");
        if (literalOnly) {
          TypeSpec value; value.isConstValue = true; value.constValue = t[p++].iv;
          value.genericArgName = std::move(argumentName);
          args.push_back(std::move(value));
        } else {
          ++genericAngleExprDepth;
          NP expression;
          try { expression = parseExpr(); }
          catch (...) { --genericAngleExprDepth; throw; }
          --genericAngleExprDepth;
          TypeSpec value;
          value.constExpr = std::shared_ptr<Node>(expression.release());
          value.genericArgName = std::move(argumentName);
          args.push_back(std::move(value));
        }
      } else {
        TypeSpec typeArgument = parseType();
        typeArgument.genericArgName = std::move(argumentName);
        args.push_back(std::move(typeArgument));
      }
    } while (accOp(","));
    expTypeAngleClose();
    return args;
  }
  TypeSpec parseNamedTypeRef() {
    TypeSpec ts; ts.base = expQualifiedIdent(); ts.genericArgs = parseGenericArgs(); return ts;
  }
  std::vector<std::string> parseGenericParams(
      std::vector<GenericBound> *bounds = nullptr,
      std::vector<std::string> *constParams = nullptr,
      std::vector<TypeSpec> *defaults = nullptr,
      std::vector<bool> *hasDefaults = nullptr) {
    std::vector<std::string> out;
    if (!accOp("<")) return out;
    std::set<std::string> seen;
    bool sawDefault = false;
    do {
      const bool isConstParam = accId("const");
      if (isConstParam) {
        if (!constParams)
          err("const generic parameter รุ่นนี้ไม่รองรับใน generic enum");
        if (!accId("int")) err("const generic parameter ต้องระบุชนิด int เช่น const int N");
      }
      std::string name = expIdent();
      if (isTypeWord(name) || isReserved(name)) err("ชื่อ generic parameter '" + name + "' เป็น keyword/type ที่สงวนไว้");
      if (!seen.insert(name).second) err("generic parameter ซ้ำ: " + name);
      out.push_back(name);
      if (isConstParam) {
        constParams->push_back(name);
        if (accOp(":")) {
          do {
            const std::string predicate = expIdent();
            if (!isConstGenericConstraintName(predicate))
              err("const generic constraint ไม่รู้จัก '" + predicate +
                  "' (รองรับ positive, nonnegative, nonzero, negative, even, odd, power_of_two)");
            TypeSpec bound; bound.base = predicate;
            if (bounds) bounds->push_back({name, std::move(bound)});
          } while (accOp("&"));
        }
      } else if (accOp(":")) {
        do {
          TypeSpec bound = parseNamedTypeRef();
          if (bound.base.empty()) err("generic constraint ของ '" + name + "' ไม่ถูกต้อง");
          if (bounds) bounds->push_back({name, std::move(bound)});
        } while (accOp("&"));
      }

      TypeSpec defaultValue;
      const bool hasDefault = accOp("=");
      if (hasDefault) {
        sawDefault = true;
        if (isConstParam) {
          const bool unaryConst = cur().t == Tok::Op &&
              (cur().s == "+" || cur().s == "-" || cur().s == "~");
          const bool literalOnly = cur().t == Tok::Int &&
              (peek().s == "," || peek().s == ">");
          if (literalOnly) {
            if (cur().big) err("const generic default ใหญ่เกินช่วง int64");
            defaultValue.isConstValue = true;
            defaultValue.constValue = t[p++].iv;
          } else {
            if (cur().t != Tok::Int && !unaryConst && !isOp("("))
              err("const generic default ต้องเป็น integer constant expression เช่น N = 16");
            ++genericAngleExprDepth;
            try { defaultValue.constExpr = std::shared_ptr<Node>(parseExpr().release()); }
            catch (...) { --genericAngleExprDepth; throw; }
            --genericAngleExprDepth;
          }
        } else {
          defaultValue = parseType();
          if (defaultValue.base.empty() || defaultValue.isConstValue || defaultValue.constExpr)
            err("generic type default ของ '" + name + "' ต้องเป็น type เช่น T = int");
        }
      } else if (sawDefault) {
        err("generic parameters ที่มี default ต้องอยู่ท้าย declaration; parameter '" + name + "' ไม่มี default");
      }
      if (defaults) defaults->push_back(std::move(defaultValue));
      if (hasDefaults) hasDefaults->push_back(hasDefault);
    } while (accOp(","));
    expTypeAngleClose();
    if (defaults && hasDefaults && defaults->size() == out.size() &&
        hasDefaults->size() == out.size()) {
      auto expressionReferences = [](const Node *node, const std::string &name,
                                     const auto &self) -> bool {
        if (!node) return false;
        if (node->k == NK::Ident && node->s == name) return true;
        for (const auto &child : node->c)
          if (self(child.get(), name, self)) return true;
        return false;
      };
      auto typeReferences = [&](const TypeSpec &type, const std::string &name,
                                const auto &self) -> bool {
        if (type.base == name || type.base2 == name) return true;
        if (type.size && expressionReferences(type.size.get(), name, expressionReferences)) return true;
        if (type.size2 && expressionReferences(type.size2.get(), name, expressionReferences)) return true;
        if (type.constExpr && expressionReferences(type.constExpr.get(), name, expressionReferences)) return true;
        for (const auto &argument : type.genericArgs)
          if (self(argument, name, self)) return true;
        for (const auto &parameter : type.sig)
          if (self(parameter, name, self)) return true;
        if (type.sigReturnType && self(*type.sigReturnType, name, self)) return true;
        return false;
      };
      for (size_t i = 0; i < out.size(); ++i) {
        if (!(*hasDefaults)[i]) continue;
        const TypeSpec &defaultValue = (*defaults)[i];
        for (size_t later = i + 1; later < out.size(); ++later) {
          if (typeReferences(defaultValue, out[later], typeReferences))
            err("generic default ของ parameter '" + out[i] + "' อ้างถึง parameter ภายหลัง '" +
                out[later] + "'; default ต้องใช้ parameter ที่ประกาศก่อนหน้าเท่านั้น");
        }
      }
    }
    if (out.empty()) err("generic declaration ต้องมี type parameter");
    return out;
  }

  // ---- types
  TypeSpec parseType(bool allowKindOnly = true, bool allowLifetime = false) {
    (void)allowKindOnly;
    TypeSpec ts;
    if (isId("weak")) { p++; if (!accId("obj")) err("weak ต้องตามด้วย obj เช่น weak obj Node"); ts.cat = "weakobj"; ts.base = expQualifiedIdent(); ts.genericArgs = parseGenericArgs(); return ts; }
    if (isId("array") || isId("list") || isId("obj") ||
        (cur().t == Tok::Ident && isDS(cur().s) && (cur().s != "heap" || (peek().t == Tok::Ident && isKind(peek().s))))) { ts.cat = t[p++].s; }
    else if (isId("struct")) { p++; ts.cat = "struct"; }
    else if (isId("enum")) { p++; ts.cat = "enum"; }
    if (cur().t == Tok::Ident && isKind(cur().s)) ts.kind = t[p++].s;
    if (isOp("<")) {
      if (!allowLifetime) err("lifetime annotation ใช้ได้เฉพาะชนิด ptr ใน function signature");
      if (ts.kind != "ptr" || !ts.cat.empty()) err("lifetime annotation ใช้ได้เฉพาะชนิด ptr T โดยตรง");
      p++;
      ts.lifetime = expIdent();
      expTypeAngleClose();
      if (ts.lifetime.empty()) err("ชื่อ lifetime ในชนิด ptr ต้องไม่ว่าง");
    }
    if (accId("volatile")) ts.isVolatile = true;
    if (ts.cat == "list" && isId("obj")) { p++; ts.elemObj = true; ts.base = expQualifiedIdent(); ts.genericArgs = parseGenericArgs(); return ts; }
    ts.base = ts.cat == "obj" ? expQualifiedIdent() : ((ts.cat == "struct" || ts.cat == "enum") ? expQualifiedIdent() : expIdent());
    if (ts.cat == "obj" || ts.cat == "struct" || ts.cat == "enum" || ts.cat == "list") ts.genericArgs = parseGenericArgs();
    if (ts.cat == "hashmap") { expOp(","); ts.base2 = expIdent(); }
    return ts;
  }

  void parseFuncTypeLifetimeParams(TypeSpec &ts) {
    if (!accId("lifetime")) return;
    expOp("<");
    std::set<std::string> seen;
    do {
      std::string name = expIdent();
      if (isReserved(name) || isTypeWord(name)) err("ชื่อ lifetime parameter '" + name + "' เป็น keyword/type ที่สงวนไว้");
      if (!seen.insert(name).second) err("lifetime parameter ซ้ำ: " + name);
      ts.sigLifetimeParams.push_back(name);
    } while (accOp(","));
    expTypeAngleClose();
    if (ts.sigLifetimeParams.empty()) err("lifetime declaration ของ function type ต้องมี parameter อย่างน้อยหนึ่งตัว");
  }

  void parseFuncTypeLifetimeWhere(TypeSpec &ts) {
    if (!accId("where")) return;
    if (ts.sigLifetimeParams.empty()) err("where lifetime constraint ต้องมี function lifetime<...>");
    std::set<std::pair<int, int>> seen;
    do {
      std::string longerName = expIdent(); expOp(":"); std::string shorterName = expIdent();
      auto longer = std::find(ts.sigLifetimeParams.begin(), ts.sigLifetimeParams.end(), longerName);
      auto shorter = std::find(ts.sigLifetimeParams.begin(), ts.sigLifetimeParams.end(), shorterName);
      if (longer == ts.sigLifetimeParams.end()) err("ไม่พบ lifetime parameter '" + longerName + "' ใน function type where constraint");
      if (shorter == ts.sigLifetimeParams.end()) err("ไม่พบ lifetime parameter '" + shorterName + "' ใน function type where constraint");
      const int li = static_cast<int>(std::distance(ts.sigLifetimeParams.begin(), longer));
      const int si = static_cast<int>(std::distance(ts.sigLifetimeParams.begin(), shorter));
      if (!seen.insert({li, si}).second) err("where lifetime constraint ซ้ำ: " + longerName + ": " + shorterName);
      ts.sigLifetimeOutlives.push_back({li, si});
      // In a nested function-value type, the comma may instead delimit the
      // containing function's next parameter. Continue only when the token
      // sequence after it is another explicit `name: name` edge.
      if (!(isOp(",") && peek().t == Tok::Ident && peek(2).t == Tok::Op && peek(2).s == ":")) break;
      p++;
    } while (true);
  }

  void bindFuncTypeLifetimeAnnotations(TypeSpec &ts) {
    if (!ts.sigReturnType) return;
    auto bind = [&](TypeSpec &type, const std::string &where) {
      if (type.lifetime.empty()) return;
      if (type.kind != "ptr" || !type.cat.empty()) err("lifetime binding ของ " + where + " ต้องเป็นชนิด ptr T โดยตรง");
      if (ts.sigLifetimeParams.empty()) err("ชนิด ptr<" + type.lifetime + "> ใน function type ต้องประกาศ lifetime<...> ก่อน");
      auto it = std::find(ts.sigLifetimeParams.begin(), ts.sigLifetimeParams.end(), type.lifetime);
      if (it == ts.sigLifetimeParams.end()) err("ไม่พบ lifetime parameter '" + type.lifetime + "' ใน function type");
      type.lifetimeParamIndex = static_cast<int>(std::distance(ts.sigLifetimeParams.begin(), it));
    };
    bind(*ts.sigReturnType, "function return type");
    for (size_t i = 0; i < ts.sig.size(); ++i) bind(ts.sig[i], "function parameter " + std::to_string(i + 1));
    if (!ts.sigReturnType->lifetime.empty()) {
      auto outlives = [&](int longer, int shorter) {
        if (longer < 0 || shorter < 0) return false;
        std::vector<int> pending{longer}; std::vector<bool> visited(ts.sigLifetimeParams.size(), false);
        while (!pending.empty()) {
          int current = pending.back(); pending.pop_back();
          if (current == shorter) return true;
          if (current < 0 || static_cast<size_t>(current) >= visited.size() || visited[static_cast<size_t>(current)]) continue;
          visited[static_cast<size_t>(current)] = true;
          for (const auto &edge : ts.sigLifetimeOutlives)
            if (edge.first == current && edge.second >= 0 && static_cast<size_t>(edge.second) < visited.size()) pending.push_back(edge.second);
        }
        return false;
      };
      bool supplied = false;
      for (const auto &param : ts.sig)
        if (param.kind == "ptr" && outlives(param.lifetimeParamIndex, ts.sigReturnType->lifetimeParamIndex)) supplied = true;
      if (!supplied) err("function type return lifetime '" + ts.sigReturnType->lifetime + "' ต้องผูกกับ pointer parameter ที่มี lifetime ยาวพอ (outlives)");
    }
  }

  TypeSpec parseFuncType(std::string &nameOut) {  // function [lifetime<...>] <return-type> name [(types)] [where ...]
    TypeSpec ts; ts.cat = "func"; p++;  // 'function'
    parseFuncTypeLifetimeParams(ts);
    TypeSpec result = parseType(true, true);
    ts.base = result.base;
    ts.sigReturnType = std::make_shared<TypeSpec>(std::move(result));
    nameOut = expIdent();
    if (accOp("(")) {
      ts.hasSig = true;
      while (!isOp(")")) {
        bool noescape = false, readonly = false;
        while (isId("noescape") || isId("readonly")) {
          if (accId("noescape")) { if (noescape) err("noescape ซ้ำใน function type"); noescape = true; }
          else if (accId("readonly")) { if (readonly) err("readonly ซ้ำใน function type"); readonly = true; }
        }
        accId("ref");
        TypeSpec a = parseType(true, true);
        if ((noescape || readonly) && a.kind != "ptr") err("noescape/readonly ใน function type ใช้ได้เฉพาะ ptr parameter");
        if (cur().t == Tok::Ident && !isKind(cur().s)) p++;  // optional parameter name
        ts.sig.push_back(std::move(a));
        ts.sigNoescape.push_back(noescape); ts.sigReadonly.push_back(readonly);
        if (!accOp(",")) break;
      }
      expOp(")");
    }
    parseFuncTypeLifetimeWhere(ts);
    if (!ts.sigLifetimeParams.empty() && !ts.hasSig)
      err("function type ที่ประกาศ lifetime ต้องระบุ parameter signature ด้วย (...)");
    if (!ts.sigLifetimeParams.empty()) bindFuncTypeLifetimeAnnotations(ts);
    return ts;
  }
  void parseParams(Node *f) {
    expOp("(");
    while (!isOp(")")) {
      if (isOp(".") && peek().t == Tok::Op && peek().s == "." && peek(2).t == Tok::Op && peek(2).s == ".") { p += 3; f->cvar = true; break; }
      Param pa;
      // Parameter effects are compile-time contracts. `noescape` controls
      // retention; `readonly` controls writes through the pointed-to storage.
      // They may be combined and do not change the pointer ABI.
      while (isId("noescape") || isId("readonly")) {
        if (accId("noescape")) {
          if (pa.noescape) err("ระบุ noescape ซ้ำใน parameter เดียวกัน");
          pa.noescape = true;
        } else if (accId("readonly")) {
          if (pa.readonly) err("ระบุ readonly ซ้ำใน parameter เดียวกัน");
          pa.readonly = true;
        }
      }
      if (accId("ref")) {
        pa.ref = true;
        // `ref const T value` is an immutable borrow. `ref T value` remains
        // the existing mutable-borrow spelling for source compatibility.
        pa.immutableRef = accId("const");
      }
      if (isId("function")) pa.ts = parseFuncType(pa.name);
      else {
        pa.ts = parseType(true, true);
        if (isOp(".") && peek().t == Tok::Op && peek().s == "." && peek(2).t == Tok::Op && peek(2).s == ".") { p += 3; pa.variadic = true; pa.ts.cat = "array"; }
        pa.name = expIdent();
        if (isOp("[")) { p++; if (!isOp("]")) { pa.ts.size = parseExpr(); pa.ts.hasSize = true; } expOp("]"); if (pa.ts.cat.empty()) pa.ts.cat = "array"; }
      }
      if (pa.noescape) {
        if (pa.ref) err("noescape ไม่สามารถใช้ร่วมกับ ref ได้; noescape ใช้กับ ptr parameter ที่ส่งค่า pointer โดยตรง");
        if (pa.ts.kind != "ptr") err("noescape ใช้ได้เฉพาะ parameter ชนิด ptr เช่น noescape ptr int data");
        if (pa.variadic) err("noescape parameter ห้ามเป็น variadic");
      }
      if (pa.readonly) {
        if (pa.ref) err("readonly ใช้กับ ptr parameter ไม่ใช่ ref parameter");
        if (pa.ts.kind != "ptr") err("readonly ใช้ได้เฉพาะ ptr parameter เช่น readonly ptr int data");
        if (pa.variadic) err("readonly parameter ห้ามเป็น variadic");
      }
      if (accOp("=")) pa.def = parseExpr();
      if (pa.noescape && pa.def) err("noescape parameter ห้ามมี default value");
      if (pa.readonly && pa.def) err("readonly parameter ห้ามมี default value");
      f->params.push_back(std::move(pa));
      if (!accOp(",")) break;
    }
    expOp(")");
  }
  NP strExpr(const std::string &s, int line) {
    auto fix = [](std::string x) { for (auto &c : x) { if (c == 1) c = '{'; else if (c == 2) c = '}'; } return x; };
    std::vector<NP> parts; std::string lit; size_t i = 0;
    auto mkLit = [&](const std::string &v) { NP n = std::make_unique<Node>(NK::StrLit, line); n->s = fix(v); return n; };
    while (i < s.size()) {
      if (s[i] == '{') {
        int depth = 1; size_t j = i + 1;
        while (j < s.size() && depth) { if (s[j] == '{') depth++; else if (s[j] == '}') depth--; j++; }
        if (depth) throw CompileError(line, "string interpolation: ขาด '}' (ถ้าต้องการ { จริงใช้ \\{)");
        std::string inner = s.substr(i + 1, j - i - 2);
        if (!lit.empty()) { parts.push_back(mkLit(lit)); lit.clear(); }
        Parser sub; sub.nest = nest; sub.tokenBudgetUsed = tokenBudgetUsed;
        sub.t = lex(inner, tokenBudgetUsed); for (auto &tk : sub.t) { tk.line = line; tk.column = 0; }   // nested expression columns are relative to the decoded interpolation text
        NP e = sub.parseExpr();
        if (sub.cur().t != Tok::End) throw CompileError(line, "string interpolation: นิพจน์ใน {} ไม่ถูกต้อง: " + inner);
        NP call = std::make_unique<Node>(NK::Call, line);
        NP callee = std::make_unique<Node>(NK::Ident, line); callee->s = "str";
        call->c.push_back(std::move(callee)); call->c.push_back(std::move(e));
        parts.push_back(std::move(call));
        i = j;
      } else lit += s[i++];
    }
    if (!lit.empty() || parts.empty()) parts.push_back(mkLit(lit));
    NP acc = std::move(parts[0]);
    for (size_t k = 1; k < parts.size(); k++) {
      NP b = std::make_unique<Node>(NK::Binary, line); b->s = "+";
      b->c.push_back(std::move(acc)); b->c.push_back(std::move(parts[k])); acc = std::move(b);
    }
    return acc;
  }

  void parseLifetimeParams(Node *f) {
    if (!f || !accId("lifetime")) return;
    expOp("<");
    std::set<std::string> seenLifetimes;
    do {
      std::string name = expIdent();
      if (isReserved(name) || isTypeWord(name)) err("ชื่อ lifetime parameter '" + name + "' เป็น keyword/type ที่สงวนไว้");
      if (!seenLifetimes.insert(name).second) err("lifetime parameter ซ้ำ: " + name);
      f->lifetimeParams.push_back(name);
    } while (accOp(","));
    expTypeAngleClose();
    if (f->lifetimeParams.empty()) err("lifetime declaration ต้องมี parameter อย่างน้อยหนึ่งตัว");
  }

  void parseLifetimeWhere(Node *f) {
    if (!f || !accId("where")) return;
    if (f->lifetimeParams.empty()) err("where lifetime constraint ต้องมี function lifetime<...>");
    std::set<std::pair<int, int>> seenOutlives;
    do {
      std::string longerName = expIdent();
      expOp(":");
      std::string shorterName = expIdent();
      auto longer = std::find(f->lifetimeParams.begin(), f->lifetimeParams.end(), longerName);
      auto shorter = std::find(f->lifetimeParams.begin(), f->lifetimeParams.end(), shorterName);
      if (longer == f->lifetimeParams.end()) err("ไม่พบ lifetime parameter '" + longerName + "' ใน where constraint");
      if (shorter == f->lifetimeParams.end()) err("ไม่พบ lifetime parameter '" + shorterName + "' ใน where constraint");
      int longerIndex = static_cast<int>(std::distance(f->lifetimeParams.begin(), longer));
      int shorterIndex = static_cast<int>(std::distance(f->lifetimeParams.begin(), shorter));
      if (!seenOutlives.insert({longerIndex, shorterIndex}).second)
        err("where lifetime constraint ซ้ำ: " + longerName + ": " + shorterName);
      f->lifetimeOutlives.push_back({longerIndex, shorterIndex});
    } while (accOp(","));
  }

  void bindLifetimeAnnotations(Node *f) {
    if (!f) return;
    auto bindLifetime = [&](TypeSpec &type, const std::string &where) {
      if (type.lifetime.empty()) return;
      if (type.kind != "ptr" || !type.cat.empty())
        err("lifetime binding ของ " + where + " ต้องเป็นชนิด ptr T โดยตรง");
      if (f->lifetimeParams.empty())
        err("ชนิด ptr<" + type.lifetime + "> ต้องประกาศ function lifetime<...> ก่อน");
      auto it = std::find(f->lifetimeParams.begin(), f->lifetimeParams.end(), type.lifetime);
      if (it == f->lifetimeParams.end())
        err("ไม่พบ lifetime parameter '" + type.lifetime + "' ใน function นี้");
      type.lifetimeParamIndex = static_cast<int>(std::distance(f->lifetimeParams.begin(), it));
    };
    bindLifetime(f->ts, "return type");
    for (auto &param : f->params) bindLifetime(param.ts, "parameter '" + param.name + "'");

    if (!f->ts.lifetime.empty()) {
      // A parameter carrying lifetime `a` can provide a return annotated `b`
      // exactly when `a` outlives `b`. Compute reachability over declared constraints;
      // for extern declarations this is a trusted FFI promise, not a body proof.
      auto outlives = [&](int longer, int shorter) {
        if (longer < 0 || shorter < 0) return false;
        std::vector<int> pending{longer};
        std::vector<bool> visited(f->lifetimeParams.size(), false);
        while (!pending.empty()) {
          int current = pending.back(); pending.pop_back();
          if (current == shorter) return true;
          if (current < 0 || static_cast<size_t>(current) >= visited.size() || visited[static_cast<size_t>(current)]) continue;
          visited[static_cast<size_t>(current)] = true;
          for (const auto &edge : f->lifetimeOutlives)
            if (edge.first == current && edge.second >= 0 &&
                static_cast<size_t>(edge.second) < visited.size() &&
                !visited[static_cast<size_t>(edge.second)]) pending.push_back(edge.second);
        }
        return false;
      };
      bool suppliedByParameter = false;
      for (const auto &param : f->params)
        if (param.ts.kind == "ptr" && outlives(param.ts.lifetimeParamIndex, f->ts.lifetimeParamIndex))
          suppliedByParameter = true;
      if (!suppliedByParameter)
        err("return lifetime '" + f->ts.lifetime + "' ต้องผูกกับ pointer parameter ที่มี lifetime ยาวพอ (outlives)");
    }
  }

  NP parseExtern() {  // extern function [lifetime<...>] <ret> name(params) [where ...] [as "c_symbol"]
    NP f = mk(NK::Func); p++; f->isExtern = true; f->isPublic = true;
    if (cur().t == Tok::Str) p++;  // extern "C"
    if (!accId("function")) err("extern ต้องตามด้วย function");
    parseLifetimeParams(f.get());
    const bool returnVolatile = accId("volatile");
    f->ts = parseType(true, true);
    f->ts.isVolatile = f->ts.isVolatile || returnVolatile;
    f->s = expIdent(); f->csym = f->s;
    parseParams(f.get());
    parseLifetimeWhere(f.get());
    bindLifetimeAnnotations(f.get());
    // An extern noescape/readonly/lifetime annotation is a trusted FFI contract.
    // The compiler validates callers but cannot prove the foreign implementation.
    if (accId("as")) { if (cur().t != Tok::Str) err("as ต้องตามด้วยชื่อ symbol เป็น string"); f->csym = t[p++].s; }
    return f;
  }
  bool inInterface = false;
  NP parseFunc() {
    NP f = mk(NK::Func);
    bool sawVis = false;
    while (isId("public") || isId("private") || isId("protected") || isId("static") || isId("override") || isId("abstract") || isId("final") || isId("unsafe") || isId("consteval")) {
      if (accId("unsafe")) { if (f->isUnsafe) err("ระบุ unsafe ซ้ำ"); f->isUnsafe = true; }
      else if (accId("consteval")) { if (f->isConsteval) err("ระบุ consteval ซ้ำ"); f->isConsteval = true; }
      else if (accId("override")) f->isOverride = true;
      else if (accId("abstract")) f->isAbstract = true;
      else if (accId("final")) f->isFinal = true;
      else if (accId("public")) { if (sawVis) err("ระบุ access modifier ซ้ำ"); f->isPublic = true; sawVis = true; }
      else if (accId("private")) { if (sawVis) err("ระบุ access modifier ซ้ำ"); f->isPrivate = true; sawVis = true; }
      else if (accId("protected")) { if (sawVis) err("ระบุ access modifier ซ้ำ"); f->isProtected = true; sawVis = true; }
      else if (accId("static")) f->isStatic = true;
    }
    if (f->isFinal && f->isAbstract) err("method ไม่สามารถเป็นทั้ง final และ abstract ได้");
    if (!accId("function")) err("คาดว่าจะเป็น 'function'");
    // Named lifetime parameters also serve as the namespace for ptr<name> annotations.
    parseLifetimeParams(f.get());
    std::set<std::string> savedGenericParams = genericTypeParams;
    if (isOp("<")) {
      f->typeParams = parseGenericParams(&f->genericBounds, &f->constGenericParams, &f->genericDefaults, &f->genericHasDefault);
      genericTypeParams.insert(f->typeParams.begin(), f->typeParams.end());
    }
    if (isOp("(")) {  // คืนหลายค่า: function (int, string) f(...)
      p++; f->ts.cat = "tuple";
      while (!isOp(")")) { f->ts.sig.push_back(parseType()); if (!accOp(",")) break; }
      expOp(")");
    } else if (isId("array") || isId("list") || isId("obj") || isId("weak") || isId("struct") || isId("enum") || (cur().t == Tok::Ident && isDS(cur().s))) {
      f->ts = parseType();
      if (isOp("[")) { p++; if (!isOp("]")) { f->ts.size = parseExpr(); f->ts.hasSize = true; } expOp("]"); }
    } else {
      f->ts = parseType(true, true);
    }
    f->s = expIdent();
    parseParams(f.get());
    // Resolve named outlives edges and pointer bindings to stable indices.
    parseLifetimeWhere(f.get());
    bindLifetimeAnnotations(f.get());
    // Const-qualified instance method: the receiver may be read but not mutated.
    // This is a compile-time contract; it does not change the native ABI.
    f->isConst = accId("const");
    if (inInterface) {                         // interface: signature-only = abstract; body = default method
      f->isPublic = true;
      if (f->isPrivate || f->isProtected || f->isStatic || f->isFinal || f->isOverride)
        err("interface method ต้องเป็น public instance method (ไม่ระบุ private/protected/static/final/override)");
      if (f->isAbstract && isOp("{")) err("abstract interface method ห้ามมี body");
      if (isOp("{")) f->c.push_back(parseBlock());
      else f->isAbstract = true;
    } else if (f->isAbstract) {
      if (isOp("{")) err("abstract method ห้ามมี body");
    } else f->c.push_back(parseBlock());
    for (const auto &param : f->params) {
      if (param.noescape && f->c.empty() && !f->isAbstract) err("noescape ต้องมี function body ให้ compiler ตรวจ หรือเป็น abstract/interface contract ที่ implementation ต้องรักษา");
      if (param.readonly && f->c.empty() && !f->isAbstract) err("readonly ต้องมี function body ให้ compiler ตรวจ หรือเป็น abstract/interface contract ที่ implementation ต้องรักษา (extern readonly เป็น trusted FFI contract)");
    }
    if (inInterface && !f->typeParams.empty()) err("generic interface method ยังไม่รองรับ; ให้กำหนด type parameter ที่ interface");
    genericTypeParams = std::move(savedGenericParams);
    return f;
  }

  NP parseConstructor(const std::string &className, bool isPublic = true, bool isPrivate = false, bool isProtected = false) {
    NP f = mk(NK::Func); f->isConstructor = true; f->isPublic = isPublic; f->isPrivate = isPrivate; f->isProtected = isProtected; f->ts.base = "void"; f->s = "__ctor";
    p++; // constructor
    std::string declared = expIdent();
    if (declared != className) err("constructor ต้องใช้ชื่อ class เดียวกัน: constructor " + className + "(...) ");
    parseParams(f.get());
    f->c.push_back(parseBlock());
    return f;
  }
  NP parseDestructor(const std::string &className) {
    NP f = mk(NK::Func); f->isDestructor = true; f->s = "__dtor"; f->ts.base = "void";
    p++; // destructor
    std::string declared = expIdent();
    if (declared != className) err("destructor ต้องใช้ชื่อ class เดียวกัน: destructor " + className + "()");
    expOp("("); expOp(")");
    f->c.push_back(parseBlock());
    return f;
  }
  NP parseRecordDef(bool isClass) {
    NP s = mk(NK::StructDef); s->isClass = isClass; p++;
    s->s = expIdent();
    s->typeParams = parseGenericParams(&s->genericBounds, &s->constGenericParams, &s->genericDefaults, &s->genericHasDefault);
    std::set<std::string> savedGenericParams = genericTypeParams;
    genericTypeParams.insert(s->typeParams.begin(), s->typeParams.end());
    bool hasDestructor = false;
    if (isClass && accId("extends")) { s->parentType = parseNamedTypeRef(); s->parent = s->parentType.base; }
    if (isClass && accId("implements")) {
      do { TypeSpec it = parseNamedTypeRef(); s->impls.push_back(it.base); s->implTypeSpecs.push_back(std::move(it)); } while (accOp(","));
    }
    expOp("{"); skipSemi();
    while (!isOp("}")) {
      if (cur().t == Tok::End) err("ไม่เจอ '}' ปิด class/struct");
      size_t q = p;
      bool ctorPublic = true, ctorPrivate = false, ctorProtected = false, ctorVis = false;
      while (q < t.size() && t[q].t == Tok::Ident && (t[q].s == "public" || t[q].s == "private" || t[q].s == "protected")) {
        if (ctorVis) err("ระบุ access modifier ซ้ำ");
        ctorVis = true; ctorPublic = t[q].s == "public"; ctorPrivate = t[q].s == "private"; ctorProtected = t[q].s == "protected"; q++;
      }
      if (isId("destructor")) {
        if (!isClass) err("destructor ใช้ได้เฉพาะใน class");
        if (p != q) err("destructor ไม่รับ access/static modifier; ระบบเรียกให้อัตโนมัติ");
        if (hasDestructor) err("class " + s->s + " มี destructor ได้เพียงหนึ่งตัว");
        hasDestructor = true;
        s->methods.push_back(parseDestructor(s->s));
      } else if (q < t.size() && t[q].t == Tok::Ident && t[q].s == "constructor") {
        if (!isClass) err("constructor ใช้ได้เฉพาะใน class");
        while (p < q) p++;
        s->methods.push_back(parseConstructor(s->s, ctorPublic, ctorPrivate, ctorProtected));
      } else if ([&]() { size_t m = p; while (m < t.size() && t[m].t == Tok::Ident && (t[m].s == "public" || t[m].s == "private" || t[m].s == "protected" || t[m].s == "static" || t[m].s == "override" || t[m].s == "abstract" || t[m].s == "final" || t[m].s == "unsafe" || t[m].s == "consteval")) m++; return m < t.size() && t[m].t == Tok::Ident && t[m].s == "function"; }()) {
        NP m = parseFunc();
        // Methods are public by default; module-level functions keep their own visibility policy.
        if (!m->isPrivate && !m->isProtected) m->isPublic = true;
        if (m->isStatic && !isClass) err("static method ใช้ได้เฉพาะใน class");
        if (m->isConst && m->isStatic) err("const method ใช้ได้เฉพาะ instance method ไม่ใช่ static method");
        if (m->isProtected && !isClass) err("protected method ใช้ได้เฉพาะใน class");
        if (m->isFinal && !isClass) err("final method ใช้ได้เฉพาะใน class");
        s->methods.push_back(std::move(m));
      } else {
        bool visSet = false, isPub = !isClass, isPriv = isClass, isProt = false, isStat = false;
        while (isId("public") || isId("private") || isId("protected") || isId("static")) {
          if (accId("public")) { if (visSet) err("ระบุ access modifier ซ้ำ"); isPub = true; isPriv = false; isProt = false; visSet = true; }
          else if (accId("private")) { if (visSet) err("ระบุ access modifier ซ้ำ"); isPub = false; isPriv = true; isProt = false; visSet = true; }
          else if (accId("protected")) { if (visSet) err("ระบุ access modifier ซ้ำ"); isPub = false; isPriv = false; isProt = true; visSet = true; }
          else if (accId("static")) isStat = true;
        }
        if (isProt && !isClass) err("protected field ใช้ได้เฉพาะใน class");
        if (isStat && !isClass) err("static field ใช้ได้เฉพาะใน class");
        NP field = parseVarDecl(); if (field->isRef) err("field ไม่สามารถเก็บ local ref borrow ได้"); field->isPublic = isPub; field->isPrivate = isPriv; field->isProtected = isProt; field->isStatic = isStat;
        s->c.push_back(std::move(field));
      }
      skipSemi();
    }
    expOp("}");
    genericTypeParams = std::move(savedGenericParams);
    return s;
  }
  // interface Name [extends A, B] { function RET name(params) ... }   -- มีได้เฉพาะ signature ของ method (public)
  NP parseInterfaceDef() {
    NP s = mk(NK::StructDef); s->isClass = true; s->isInterface = true; p++;
    s->s = expIdent(); s->typeParams = parseGenericParams(&s->genericBounds, nullptr, &s->genericDefaults, &s->genericHasDefault);
    std::set<std::string> savedGenericParams = genericTypeParams;
    genericTypeParams.insert(s->typeParams.begin(), s->typeParams.end());
    if (accId("extends")) { do { TypeSpec it = parseNamedTypeRef(); s->impls.push_back(it.base); s->implTypeSpecs.push_back(std::move(it)); } while (accOp(",")); }
    expOp("{"); skipSemi();
    while (!isOp("}")) {
      if (cur().t == Tok::End) err("ขาด '}' ของ interface");
      if (!(isId("function") || isId("public"))) err("interface มีได้เฉพาะ function signature หรือ default method");
      inInterface = true; NP m = parseFunc(); inInterface = false;
      s->methods.push_back(std::move(m));
      skipSemi();
    }
    expOp("}");
    genericTypeParams = std::move(savedGenericParams);
    return s;
  }
  NP parseStructDef() { return parseRecordDef(false); }
  NP parseClassDef() { return parseRecordDef(true); }
  NP parseEnumDef() {
    NP e = mk(NK::EnumDef); p++;
    e->s = expIdent();
    e->typeParams = parseGenericParams(&e->genericBounds, nullptr, &e->genericDefaults, &e->genericHasDefault);
    std::set<std::string> savedGenericParams = genericTypeParams;
    genericTypeParams.insert(e->typeParams.begin(), e->typeParams.end());
    expOp("{");
    int64_t idx = 0;
    while (!isOp("}")) {
      EnumMember m; m.name = expIdent(); m.val = idx; m.str = m.name;
      if (accOp("(")) {
        // Legacy metadata form remains compatible: Sun(0, "Sunday").
        // Typed payload form is explicit: Some(int), Point(float, float).
        if (cur().t == Tok::Int || isOp("-") || cur().t == Tok::Str) {
          bool neg = accOp("-");
          if (cur().t != Tok::Int) err("enum metadata ต้องเป็น Name(เลข, \"ข้อความ\")");
          m.val = t[p++].iv; if (neg) m.val = -m.val;
          if (accOp(",")) { if (cur().t != Tok::Str) err("enum metadata: ค่าที่ 2 ต้องเป็น string"); m.str = t[p++].s; }
        } else if (!isOp(")")) {
          do {
            TypeSpec payload = parseType();
            if (payload.base == "void" || payload.cat == "array")
              err("payload enum ไม่รองรับ void และ fixed/dynamic array; ใช้ list หรือ struct แทน");
            m.payloadTypes.push_back(std::move(payload));
          } while (accOp(","));
        }
        expOp(")");
      }
      e->members.push_back(std::move(m)); idx++;
      if (!accOp(",") && !isOp("}")) err("คาดว่าจะเจอ ',' หรือ '}' ใน enum");
    }
    expOp("}");
    genericTypeParams = std::move(savedGenericParams);
    return e;
  }

  // ---- statements
  NP parseBlock() {
    NestGuard ng(*this);
    NP b = mk(NK::Block);
    expOp("{");
    int saved = paren; paren = 0;
    skipSemi();
    while (!isOp("}")) {
      if (cur().t == Tok::End) err("ไม่เจอ '}' ปิด block");
      b->c.push_back(parseStmt());
      skipSemi();
    }
    paren = saved;
    expOp("}");
    return b;
  }

  NP parseVarDecl() {  // [ref [const]] [const] kind type name [= init] | array/list/struct/enum ...
    NP d = mk(NK::VarDecl);
    if (accId("ref")) { d->isRef = true; d->isImmutableRef = accId("const"); }
    bool modifiers = true;
    while (modifiers) {
      if (accId("const")) d->isConst = true;
      else if (accId("volatile")) d->isVolatile = true;
      else if (accId("align")) {
        expOp("(");
        if (cur().t != Tok::Int) err("align(...) ต้องเป็นจำนวนเต็มคงที่ เช่น align(16)");
        int64_t requested = t[p++].iv;
        if (requested < 1 || requested > 4096 || (requested & (requested - 1)))
          err("align(...) ต้องเป็นกำลังสองของ 2 ตั้งแต่ 1 ถึง 4096");
        d->alignment = requested;
        expOp(")");
      } else modifiers = false;
    }
    if (isId("array") || isId("list")) {
      d->ts.cat = t[p++].s;
      if (cur().t != Tok::Ident || !isKind(cur().s)) err("ต้องระบุ kind (var/ptr/dyn/heap) หลัง " + d->ts.cat);
      d->ts.kind = t[p++].s;
      if (d->ts.cat == "list" && isId("obj")) { p++; d->ts.elemObj = true; d->ts.base = expQualifiedIdent(); d->ts.genericArgs = parseGenericArgs(); }
      else { d->ts.base = expIdent(); if (d->ts.cat == "list") d->ts.genericArgs = parseGenericArgs(); }
      d->s = expIdent();
      if (d->ts.cat == "array" && isOp("[")) { p++; if (!isOp("]")) { d->ts.size = parseExpr(); d->ts.hasSize = true; } expOp("]"); }
      else if (d->ts.cat == "array") err("array ต้องมี [size] หลังชื่อ");
    } else if (cur().t == Tok::Ident && isDS(cur().s) && (cur().s != "heap" || (peek().t == Tok::Ident && isKind(peek().s)))) {
      d->ts.cat = t[p++].s;
      if (cur().t != Tok::Ident || !isKind(cur().s)) err("ต้องระบุ kind (var/dyn/heap) หลัง " + d->ts.cat);
      d->ts.kind = t[p++].s; if (accId("volatile")) d->ts.isVolatile = true; d->ts.base = expIdent();
      if (d->ts.cat == "hashmap") { expOp(","); d->ts.base2 = expIdent(); }
      d->s = expIdent();
      if (d->ts.cat == "matrix") {
        expOp("["); d->ts.size = parseExpr(); d->ts.hasSize = true; expOp("]");
        expOp("["); d->ts.size2 = parseExpr(); d->ts.hasSize2 = true; expOp("]");
      }
    } else if (isId("struct") || isId("enum") || isId("obj")) {
      d->ts = parseType(); d->ts.kind = d->ts.kind.empty() ? "var" : d->ts.kind; d->s = expIdent();
    } else if (isId("weak")) {
      d->ts = parseType(); d->s = expIdent();
    } else if (cur().t == Tok::Ident && isKind(cur().s) && peek().t == Tok::Op && peek().s == "(") {  // var (int a, dyn string s) = f()
      std::string kd = t[p++].s; p++;
      d->ts.cat = "tuple"; d->ts.kind = kd;
      while (!isOp(")")) { Param pa; pa.ts = parseType(); pa.name = expIdent(); d->params.push_back(std::move(pa)); if (!accOp(",")) break; }
      expOp(")");
    } else if (cur().t == Tok::Ident && isKind(cur().s) && peek().t == Tok::Ident && peek().s == "function") {
      std::string kd = t[p++].s; d->ts = parseFuncType(d->s); d->ts.kind = kd;
    } else if (cur().t == Tok::Ident && isKind(cur().s)) {
      d->ts.kind = t[p++].s; if (accId("volatile")) d->ts.isVolatile = true; d->ts.base = expIdent(); d->s = expIdent();
    } else if (cur().t == Tok::Ident && genericTypeParams.count(cur().s) && peek().t == Tok::Ident) {
      d->ts.kind = "var"; d->ts.base = t[p++].s; d->s = expIdent();
    } else if (cur().t == Tok::Ident && isTypeWord(cur().s)) {   // เช่นใน for(int i = 0, ...)  -> var โดยปริยาย
      d->ts.kind = "var"; d->ts.base = t[p++].s; d->s = expIdent();
    } else err("คาดว่าจะเป็นการประกาศตัวแปร");
    if (accOp("=")) d->c.push_back(parseExpr());
    return d;
  }

  bool startsDecl() {
    if (cur().t != Tok::Ident) return false;
    const std::string &s = cur().s;
    if (s == "ref" || s == "var" || s == "ptr" || s == "dyn" || s == "heap" || s == "const" || s == "volatile" || s == "align" || s == "array" || s == "list" || s == "obj" || s == "weak" || isDS(s) || genericTypeParams.count(s)) return true;
    if ((s == "struct" || s == "enum") && peek().t == Tok::Ident) return true;
    return false;
  }

  static bool isLoopStart(const Tok &k) {
    return k.t == Tok::ForPP || k.t == Tok::PPFor || k.t == Tok::ForDown || k.t == Tok::DownFor ||
           (k.t == Tok::Ident && (k.s == "for" || k.s == "while" || k.s == "until" || k.s == "do"));
  }
  NP parseStmt() {
    NestGuard ng(*this);
    // label: `outer: for(...) { ... break outer }`  (สเปก §18.8)
    if (cur().t == Tok::Ident && !isReserved(cur().s) && peek().t == Tok::Op && peek().s == ":" && isLoopStart(peek(2))) {
      std::string lb = t[p].s; int ln = cur().line; p += 2;
      NP n = parseStmt(); n->label = lb; (void)ln; return n;
    }
    if (isOp("{")) return parseBlock();
    if (cur().t == Tok::ForPP || cur().t == Tok::PPFor || cur().t == Tok::ForDown || cur().t == Tok::DownFor) {
      NP n = mk(NK::ForPP); n->b = cur().t == Tok::ForPP; p++;
      expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
      n->c.push_back(parseBlock());
      return n;
    }
    if (cur().t == Tok::Ident) {
      const std::string s = cur().s;
      if (startsDecl()) { NP d = parseVarDecl(); if (!atEnd()) err("มีข้อความเกินหลังประกาศตัวแปร: '" + cur().s + "'"); return d; }
      if (s == "struct" && isStructOrEnumDefStart()) return parseStructDef();
      if (s == "class" && peek(2).t == Tok::Op && peek(2).s == "{") return parseClassDef();
      if (s == "enum" && isStructOrEnumDefStart()) return parseEnumDef();
      if (s == "if") return parseIf();
      if (s == "guard") {
        NP n = mk(NK::If); n->b = true; p++;
        expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
        if (!accId("else")) err("guard ต้องมี else block สำหรับออกจากเส้นทางที่เงื่อนไขไม่ผ่าน");
        n->c.push_back(parseBlock());
        return n;
      }
      if (s == "select") return parseSelect();
      if (s == "while" || s == "until") {
        NP n = mk(NK::While); n->b = s == "until"; p++; expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
        n->c.push_back(parseBlock()); return n;
      }
      if (s == "do") {
        NP n = mk(NK::DoWhile); p++;
        n->c.push_back(parseBlock());
        if (accId("while")) n->b = false;
        else if (accId("until")) n->b = true;
        else err("do { ... } ต้องตามด้วย while(เงื่อนไข) หรือ until(เงื่อนไข)");
        expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
        return n;
      }
      if (s == "for" && isForEach()) {  // for(var int v : xs) { ... }
        NP n = mk(NK::ForEach); p++; expOp("("); paren++;
        if (isKind(cur().s)) n->ts.kind = t[p++].s; else n->ts.kind = "var";
        n->ts.base = expIdent(); n->s = expIdent(); expOp(":");
        n->c.push_back(parseExpr()); paren--; expOp(")");
        n->c.push_back(parseBlock());
        return n;
      }
      if (s == "for") {
        NP n = mk(NK::For); p++; expOp("("); paren++;
        auto sep = [&]() { if (!accOp(",") && !accOp(";")) err("for ต้องคั่นด้วย , หรือ ;"); };
        if (isOp(",") || isOp(";")) n->c.push_back(nullptr);
        else if (startsDecl() || (cur().t == Tok::Ident && isTypeWord(cur().s))) n->c.push_back(parseVarDecl());
        else { NP e = mk(NK::ExprStmt); e->c.push_back(parseExpr()); n->c.push_back(std::move(e)); }
        sep();
        if (isOp(",") || isOp(";")) n->c.push_back(nullptr); else n->c.push_back(parseExpr());
        sep();
        if (isOp(")")) n->c.push_back(nullptr);
        else { NP e = mk(NK::ExprStmt); e->c.push_back(parseExpr()); n->c.push_back(std::move(e)); }
        paren--; expOp(")");
        n->c.push_back(parseBlock()); return n;
      }
      if (s == "switch") return parseSwitch();
      if (s == "match") return parseMatch();
      if (s == "break" || s == "continue") {
        NP n = mk(s == "break" ? NK::Break : NK::Continue); p++;
        if (!atEnd() && cur().t == Tok::Ident && !isReserved(cur().s)) n->label = t[p++].s;   // break outer / continue outer
        return n;
      }
      if (s == "return") {
        NP n = mk(NK::Return); p++;
        if (!atEnd()) n->c.push_back(parseExpr());
        return n;
      }
      if (s == "unsafe" && peek().t == Tok::Op && peek().s == "{") { p++; NP b = parseBlock(); b->isUnsafe = true; return b; }   // unsafe { ... }
      if (s == "defer") { NP n = mk(NK::Defer); p++; n->c.push_back(parseStmt()); return n; }
      if (s == "throw") { NP n = mk(NK::Throw); p++; n->c.push_back(parseExpr()); return n; }
      if (s == "try") {
        NP n = mk(NK::Try); p++;
        n->c.push_back(parseBlock());
        NP cb, fb;
        if (accId("catch")) {
          expOp("("); n->ts.base = expIdent(); n->s = expIdent(); expOp(")");
          cb = parseBlock();
        }
        if (accId("finally")) fb = parseBlock();
        if (!cb && !fb) err("try ต้องมี catch หรือ finally");
        n->c.push_back(std::move(cb)); n->c.push_back(std::move(fb));
        return n;
      }
      if (s == "function" || s == "public" || s == "private") err("function ประกาศซ้อนใน function ไม่ได้");
    }
    NP e = mk(NK::ExprStmt);
    e->c.push_back(parseExpr());
    if (!atEnd()) err("มีข้อความเกินท้ายคำสั่ง: '" + cur().s + "' (ขึ้นบรรทัดใหม่หรือใช้ ; คั่นคำสั่ง)");
    return e;
  }

  bool isForEach() {  // for ( [kind] type name : ...
    size_t q = p + 1;
    if (!(t[q].t == Tok::Op && t[q].s == "(")) return false;
    q++;
    if (t[q].t == Tok::Ident && isKind(t[q].s)) q++;
    if (t[q].t != Tok::Ident) return false; q++;
    if (t[q].t != Tok::Ident) return false; q++;
    return t[q].t == Tok::Op && t[q].s == ":";
  }
  NP parseIf() {
    NestGuard ng(*this, 3);   // heavier: an `else if` ladder recurses through the parser, codegen and AST destructors
    NP n = mk(NK::If); p++;
    expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
    n->c.push_back(parseBlock());
    if (isId("else")) {
      p++;
      if (isId("if")) n->c.push_back(parseIf()); else n->c.push_back(parseBlock());
    }
    return n;
  }

  // `select` is an ordered condition dispatch. It lowers to an if ladder so
  // every existing semantic/ownership/control-flow pass sees the same edges.
  NP parseSelect() {
    const int line = cur().line;
    p++; expOp("{");
    std::vector<std::pair<NP, NP>> branches;
    NP fallback;
    bool sawDefault = false;
    int saved = paren; paren = 0;
    while (!isOp("}")) {
      if (accId("case")) {
        if (sawDefault) err("select ต้องวาง case ก่อน default");
        expOp("("); paren++; NP cond = parseExpr(); paren--; expOp(")");
        NP body = parseBlock();
        branches.emplace_back(std::move(cond), std::move(body));
      } else if (accId("default")) {
        if (sawDefault) err("select มี default ได้เพียงหนึ่งครั้ง");
        sawDefault = true; fallback = parseBlock();
        skipSemi();
        if (!isOp("}")) {
          if (isId("default")) err("select มี default ได้เพียงหนึ่งครั้ง");
          err("default ของ select ต้องเป็น branch สุดท้าย");
        }
      } else err("ใน select ใช้ case(condition) { ... } หรือ default { ... }");
      skipSemi();
    }
    paren = saved; expOp("}");
    if (branches.empty() && !fallback) err("select ต้องมี case หรือ default อย่างน้อยหนึ่งรายการ");
    NP result = fallback ? std::move(fallback) : std::make_unique<Node>(NK::Block, line);
    for (auto it = branches.rbegin(); it != branches.rend(); ++it) {
      NP branch = std::make_unique<Node>(NK::If, it->first->line);
      branch->c.push_back(std::move(it->first));
      branch->c.push_back(std::move(it->second));
      branch->c.push_back(std::move(result));
      result = std::move(branch);
    }
    return result;
  }

  NP parseSwitch() {
    NP n = mk(NK::Switch); p++;
    expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
    expOp("{");
    int saved = paren; paren = 0;
    while (!isOp("}")) {
      if (accId("case")) {
        Case cs; expOp("("); paren++;
        cs.vals.push_back(parseExpr());
        while (accOp(",")) cs.vals.push_back(parseExpr());
        paren--; expOp(")");
        cs.body = parseBlock(); n->cases.push_back(std::move(cs));
      } else if (accId("default")) n->deflt = parseBlock();
      else err("ใน switch ใส่ได้เฉพาะ case(...) {} และ default {}");
    }
    paren = saved;
    expOp("}");
    if (isId("default") && !n->deflt) { p++; n->deflt = parseBlock(); }  // รองรับรูปแบบในตัวอย่างสเปก: default อยู่หลัง } ของ switch
    return n;
  }

  // Shared pattern grammar for statement and expression match.
  void parseMatchPattern(Case &cs) {
    if (isId("_")) { p++; cs.wildcard = true; return; }
    // Payload destructuring: case(Option.Some(value)) or case(Option.None).
    // A three-part path Alias.Option.Some is accepted for imported enums.
    if (cur().t == Tok::Ident && peek().t == Tok::Op && peek().s == ".") {
      size_t q = p;
      std::string first = t[q++].s;
      q++; // dot
      if (q < t.size() && t[q].t == Tok::Ident) {
        std::string second = t[q++].s;
        if (q < t.size() && t[q].t == Tok::Op && t[q].s == ".") {
          q++;
          if (q < t.size() && t[q].t == Tok::Ident) { cs.variantEnum = first + "." + second; cs.variantName = t[q++].s; }
        } else { cs.variantEnum = first; cs.variantName = second; }
      }
      if (!cs.variantName.empty()) {
        p = q;
        if (accOp("(")) {
          if (!isOp(")")) {
            do {
              std::string binding = expIdent();
              if (binding != "_" && isReserved(binding)) err("ชื่อ binding ใน pattern เป็น keyword ที่สงวนไว้: " + binding);
              cs.bindings.push_back(binding);
            } while (accOp(","));
          }
          expOp(")");
        }
      }
    }
    if (cs.variantName.empty()) {
      do {
        NP lo = parseExpr();
        if (accOp("..")) {
          NP hi = parseExpr();
          cs.ranges.push_back({std::move(lo), std::move(hi)});
        } else cs.vals.push_back(std::move(lo));
      } while (accOp(","));
      if (cs.vals.empty() && cs.ranges.empty()) err("match case ต้องมี pattern อย่างน้อยหนึ่งค่า");
    }
  }

  NP parseMatch() {
    NP n = mk(NK::Match); p++;
    expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
    expOp("{");
    int saved = paren; paren = 0;
    bool sawDefault = false;
    while (!isOp("}")) {
      if (accId("case")) {
        if (sawDefault) err("case ต้องอยู่ก่อน default ใน match");
        Case cs; expOp("("); paren++; parseMatchPattern(cs); paren--; expOp(")");
        if (accId("if")) { expOp("("); paren++; cs.guard = parseExpr(); paren--; expOp(")"); }
        cs.body = parseBlock(); n->cases.push_back(std::move(cs));
      } else if (accId("default")) {
        if (sawDefault) err("match มี default ได้เพียงหนึ่งครั้ง");
        sawDefault = true; n->deflt = parseBlock();
      } else err("ใน match ใส่ได้เฉพาะ case(...) [if(guard)] {} และ default {}");
      skipSemi();
    }
    paren = saved; expOp("}");
    if (n->cases.empty() && !n->deflt) err("match ต้องมี case หรือ default อย่างน้อยหนึ่งรายการ");
    return n;
  }

  NP parseMatchExpr() {
    NP n = mk(NK::MatchExpr); p++;
    expOp("("); paren++; n->c.push_back(parseExpr()); paren--; expOp(")");
    expOp("{");
    int saved = paren; paren = 0;
    bool sawDefault = false;
    while (!isOp("}")) {
      if (accId("case")) {
        if (sawDefault) err("case ต้องอยู่ก่อน default ใน match expression");
        Case cs; expOp("("); paren++; parseMatchPattern(cs); paren--; expOp(")");
        if (accId("if")) { expOp("("); paren++; cs.guard = parseExpr(); paren--; expOp(")"); }
        expOp("=>");
        cs.exprBody = parseExpr();
        n->cases.push_back(std::move(cs));
        if (accOp(",")) { skipSemi(); continue; }
        skipSemi();
        if (!isOp("}") && !isId("case") && !isId("default")) err("match expression ต้องคั่น branch ด้วย ',' หรือขึ้นบรรทัดใหม่");
      } else if (accId("default")) {
        if (sawDefault) err("match expression มี default ได้เพียงหนึ่งครั้ง");
        sawDefault = true; expOp("=>"); n->deflt = parseExpr();
        skipSemi();
        if (!isOp("}")) err("default ของ match expression ต้องเป็น branch สุดท้าย");
      } else err("ใน match expression ใช้ case(...) [if(guard)] => expression หรือ default => expression");
    }
    paren = saved; expOp("}");
    if (n->cases.empty() && !n->deflt) err("match expression ต้องมี case หรือ default อย่างน้อยหนึ่งรายการ");
    return n;
  }

  // ---- expressions
  NP parseExpr() { return parseAssign(); }
  NP parseAssign() {
    NestGuard ng(*this);
    NP l = parseBin(0);
    if (cur().t == Tok::Op && !(cur().nl && paren == 0) && isAssignOp(cur().s)) {
      NP n = mk(NK::Assign); n->s = t[p++].s;
      n->c.push_back(std::move(l)); n->c.push_back(parseAssign());
      return n;
    }
    return l;
  }
  static bool isAssignOp(const std::string &o) {
    // Expression parsing is one of the hottest parser paths. Avoid a tree lookup
    // through std::set for this small, closed operator vocabulary.
    if (o.size() == 1) return o == "=";
    if (o.size() == 2) {
      switch (o[0]) {
        case '+': return o == "+=";
        case '-': return o == "-=";
        case '*': return o == "*=";
        case '/': return o == "/=";
        case '%': return o == "%=";
        case '&': return o == "&=";
        case '|': return o == "|=";
        case '^': return o == "^=";
        case '~': return o == "~=";
        default: return false;
      }
    }
    if (o.size() == 3) {
      return o == "**=" || o == "&&=" || o == "||=" || o == "<<=" || o == ">>=";
    }
    return false;
  }
  static int prec(const std::string &o) {
    if (o.empty()) return -1;
    switch (o[0]) {
      case '|': return o == "||" ? 1 : (o == "|" ? 3 : -1);
      case '&': return o == "&&" ? 2 : (o == "&" ? 5 : -1);
      case '^': return o == "^" ? 4 : -1;
      case '=': case '!': return o == "==" || o == "!=" ? 6 : -1;
      case '<': case '>':
        if (o == "<" || o == ">" || o == "<=" || o == ">=") return 7;
        if (o == "<<" || o == ">>") return 8;
        return -1;
      case '+': case '-': return o.size() == 1 ? 9 : -1;
      case '*': case '/': case '%': return o.size() == 1 ? 10 : -1;
      default: return -1;
    }
  }
  NP parseBin(int minp) {
    NP l = parsePow();
    int chain = 0;
    while (true) {
      if (++chain > kMaxChain) err("นิพจน์ต่อเนื่องยาวเกินไป (เกิน " + std::to_string(kMaxChain) + " ตัวดำเนินการ) -- แบ่งเป็นหลายนิพจน์");
      if (cur().t == Tok::Ident && cur().s == "instanceof" && !(cur().nl && paren == 0) && minp <= 7) {   // x instanceof Type  (ระดับเดียวกับ < >)
        NP n = mk(NK::Binary); n->s = "instanceof"; p++;
        NP r = mk(NK::Ident); r->s = expQualifiedIdent();
        n->c.push_back(std::move(l)); n->c.push_back(std::move(r));
        l = std::move(n); continue;
      }
      if (genericAngleExprDepth > 0 && paren == 0 && isOp(">")) break;
      if (!(cur().t == Tok::Op && !(cur().nl && paren == 0))) break;
      int pr = prec(cur().s);
      if (pr < 0 || pr < minp || pr == 0) break;
      NP n = mk(NK::Binary); n->s = t[p++].s;
      NP r = parseBin(pr + 1);
      n->c.push_back(std::move(l)); n->c.push_back(std::move(r));
      l = std::move(n);
    }
    return l;
  }
  NP parsePow() {
    NestGuard ng(*this);
    NP l = parseUnary();
    if (isOp("**") && !(cur().nl && paren == 0)) {
      NP n = mk(NK::Binary); n->s = "**"; p++;
      NP r = parsePow();
      n->c.push_back(std::move(l)); n->c.push_back(std::move(r));
      return n;
    }
    return l;
  }
  NP parseUnary() {
    NestGuard ng(*this);
    if (cur().t == Tok::Op && (cur().s == "-" || cur().s == "!" || cur().s == "~" || cur().s == "++" || cur().s == "--" || cur().s == "+")) {
      if (cur().s == "-" && peek().t == Tok::Int && peek().big) {   // -9223372036854775808 = long ต่ำสุด
        NP n = mk(NK::IntLit); n->iv = INT64_MIN; p += 2; return n;
      }
      NP n = mk(NK::Unary); n->s = t[p++].s;
      n->c.push_back(parseUnary());
      return n;
    }
    return parsePostfix();
  }
  NP parsePostfix() {
    NP e = parsePrimary();
    int chain = 0;
    while (true) {
      if (cur().nl && paren == 0) break;
      if (++chain > kMaxChain) err("นิพจน์ต่อเนื่องยาวเกินไป (เกิน " + std::to_string(kMaxChain) + " ขั้น) -- แบ่งเป็นหลายนิพจน์");
      // Explicit generic method call: receiver.method<T>(...). Only accept the
      // angle list when it is followed by a call, so `a < b` keeps its meaning.
      if (e->k == NK::Member && isOp("<")) {
        size_t q = p; int depth = 0; bool closed = false;
        for (; q < t.size(); q++) {
          if (t[q].t != Tok::Op) continue;
          if (t[q].s == "<") depth++;
          else if (t[q].s == ">") { if (--depth == 0) { closed = true; q++; break; } }
          else if (t[q].s == ">>" && depth >= 2) { depth -= 2; if (depth == 0) { closed = true; q++; break; } }
        }
        if (closed && q < t.size() && t[q].t == Tok::Op && t[q].s == "(") {
          if (!e->explicitTypeArgs.empty()) err("generic method call ระบุ type arguments ซ้ำ");
          e->explicitTypeArgs = parseGenericArgs();
          continue;
        }
      }
      // Generic struct constructor / generic type static receiver: Pair<int>(...)
      // and Box<int>.create(). This is deliberately not enabled for bare
      // generic free functions to avoid ambiguity with relational expressions.
      if ((e->k == NK::Ident || e->k == NK::Member) && isOp("<")) {
        size_t q = p; int depth = 0; bool closed = false;
        for (; q < t.size(); q++) {
          if (t[q].t != Tok::Op) continue;
          if (t[q].s == "<") depth++;
          else if (t[q].s == ">") { if (--depth == 0) { closed = true; q++; break; } }
          else if (t[q].s == ">>" && depth >= 2) { depth -= 2; if (depth == 0) { closed = true; q++; break; } }
        }
        if (closed && q < t.size() && t[q].t == Tok::Op && (t[q].s == "(" || t[q].s == ".")) {
          std::function<bool(Node *, std::string &)> flattenTypePath = [&](Node *x, std::string &out) {
            if (x->k == NK::Ident) { out = x->s; return true; }
            if (x->k == NK::Member && flattenTypePath(x->c[0].get(), out)) { out += "." + x->s; return true; }
            return false;
          };
          if (!flattenTypePath(e.get(), e->ts.base)) err("generic type receiver ต้องเป็นชื่อชนิดหรือ module alias เช่น Box<int> หรือ M.Box<int>");
          e->ts.genericArgs = parseGenericArgs();
          continue;
        }
      }
      if (isOp("(")) {
        NP c = mk(NK::Call); p++; paren++;
        c->c.push_back(std::move(e));
        while (!isOp(")")) { c->c.push_back(parseExpr()); if (!accOp(",")) break; }
        paren--; expOp(")"); e = std::move(c);
      } else if (isOp(".")) {
        NP m = mk(NK::Member); p++; m->s = expIdent(); m->c.push_back(std::move(e)); e = std::move(m);
      } else if (isOp("[")) {
        p++; paren++;
        NP a = parseExpr();
        if (accOp(":")) {
          NP s = mk(NK::Slice); NP b = parseExpr();
          s->c.push_back(std::move(e)); s->c.push_back(std::move(a)); s->c.push_back(std::move(b)); e = std::move(s);
        } else { NP ix = mk(NK::Index); ix->c.push_back(std::move(e)); ix->c.push_back(std::move(a)); e = std::move(ix); }
        paren--; expOp("]");
      } else if (isOp("++") || isOp("--")) {
        NP n = mk(NK::PostInc); n->s = t[p++].s; n->c.push_back(std::move(e)); e = std::move(n);
      } else if (isOp("?")) {
        NP n = mk(NK::Propagate); p++; n->c.push_back(std::move(e)); e = std::move(n);
      } else break;
    }
    return e;
  }
  NP parsePrimary() {
    Tok &k = cur();
    switch (k.t) {
      case Tok::Int: { if (k.big) err("เลข 9223372036854775808 ใหญ่เกินช่วง long: เขียนเป็น -9223372036854775808 หรือใช้เลขฐาน 16"); NP n = mk(NK::IntLit); n->iv = k.iv; p++; return n; }
      case Tok::Float: { NP n = mk(NK::FloatLit); n->dv = k.dv; p++; return n; }
      case Tok::Char: { NP n = mk(NK::CharLit); n->iv = k.iv; p++; return n; }
      case Tok::Str: { int ln = k.line; p++; return strExpr(k.s, ln); }
      case Tok::LoopUp: case Tok::LoopDown: case Tok::LoopForDown: case Tok::LoopDownFor: {
        NP n = mk(NK::LoopIdx); n->b = k.t == Tok::LoopUp; n->iv = k.iv; n->s = k.s; p++; return n;
      }
      case Tok::Ident: {
        if (k.s == "new") {
          int ln = k.line; p++;
          NP n = std::make_unique<Node>(NK::New, ln); n->s = expQualifiedIdent(); n->ts.cat = "obj"; n->ts.base = n->s; n->ts.genericArgs = parseGenericArgs();
          if (accOp("(")) {
            paren++;
            while (!isOp(")")) { n->c.push_back(parseExpr()); if (!accOp(",")) break; }
            paren--; expOp(")");
          }
          return n;
        }
        if (k.s == "this") { NP n = mk(NK::Ident); n->s = "self"; p++; return n; }
        if (k.s == "function") {
          NP n = mk(NK::Lambda); p++;
          if (!isOp("(")) n->ts.base = expIdent();
          parseParams(n.get());
          for (const auto &param : n->params)
            if (param.noescape) err("noescape ยังไม่รองรับใน lambda parameter; ให้ประกาศเป็น named function เพื่อให้ compiler ตรวจ contract ได้ทั่วถึง");
          n->c.push_back(parseBlock());
          return n;
        }
        if (k.s == "true" || k.s == "false") { NP n = mk(NK::BoolLit); n->b = k.s == "true"; p++; return n; }
        if (k.s == "null") { NP n = mk(NK::NullLit); p++; return n; }
        if (k.s == "match") return parseMatchExpr();
        if (k.s == "ifv") {
          NP n = mk(NK::IfV); p++;
          paren++;
          expOp("("); n->c.push_back(parseExpr()); expOp(")");
          expOp("{"); n->c.push_back(parseExpr()); expOp("}");
          while (isId("eiv")) {
            p++; expOp("("); n->c.push_back(parseExpr()); expOp(")");
            expOp("{"); n->c.push_back(parseExpr()); expOp("}");
          }
          if (!accId("elv")) err("ifv ต้องมี elv{...} ปิดท้าย");
          expOp("{"); n->c.push_back(parseExpr()); expOp("}");
          paren--;
          return n;
        }
        if (isReserved(k.s) && !isTypeWord(k.s) && k.s != "self") err("keyword '" + k.s + "' ใช้ตรงนี้ไม่ได้");
        NP n = mk(NK::Ident); n->s = k.s; p++; return n;
      }
      case Tok::Op: {
        if (k.s == "(") {
          p++; paren++; NP e = parseExpr();
          if (isOp(",")) {  // tuple literal (a, b, ...)
            NP tl = mk(NK::TupleLit); tl->c.push_back(std::move(e));
            while (accOp(",")) tl->c.push_back(parseExpr());
            paren--; expOp(")"); return tl;
          }
          paren--; expOp(")"); return e;
        }
        if (k.s == "[") { NP n = mk(NK::Deref); p++; paren++; n->c.push_back(parseExpr()); paren--; expOp("]"); return n; }
        if (k.s == "{") {
          NP n = mk(NK::InitList); p++; paren++;
          while (!isOp("}")) { n->c.push_back(parseExpr()); if (!accOp(",")) break; }
          paren--; expOp("}"); return n;
        }
        break;
      }
      default: break;
    }
    err("นิพจน์ไม่ถูกต้อง ใกล้ '" + (k.t == Tok::End ? std::string("<จบไฟล์>") : k.s) + "'");
  }
};
