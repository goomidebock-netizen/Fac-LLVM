#pragma once

// Shared FAC syntax tree and parsed-program data model.
// Keep this header independent from Parser and LLVM Codegen so compiler
// phases can consume one stable AST contract.
#include <cstdint>
#include <memory>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

// ============================================================ AST
enum class NK {
  IntLit, FloatLit, CharLit, StrLit, BoolLit, NullLit, Ident, Unary, PostInc, Binary, Assign, Call, Member, Index, Slice, Deref,
  InitList, IfV, LoopIdx,
  Block, VarDecl, ExprStmt, If, For, ForPP, While, Switch, Match, MatchExpr, Break, Continue, Return, Try, Throw, Propagate, New,
  Func, StructDef, EnumDef, Defer, Lambda, DoWhile, ForEach, TupleLit
};
struct Node;
typedef std::unique_ptr<Node> NP;
struct TypeSpec {
  bool elemObj = false;               // list ของ object: list dyn obj Name
  std::string cat;   // "" | "array" | "list" | "struct" | "enum"
  std::string kind;  // var ptr dyn heap หรือ ""
  std::string base;  // int, string, Person, void, auto ...
  std::string base2; // hashmap: ชนิดของ value
  NP size;
  bool hasSize = false;
  NP size2;                       // matrix: column count
  bool hasSize2 = false;
  std::vector<struct TypeSpec> sig;  // cat=="func": ชนิด parameter
  std::vector<bool> sigNoescape, sigReadonly; // function-value parameter effect contracts
  std::shared_ptr<struct TypeSpec> sigReturnType; // full return type for function values (including ptr lifetime)
  std::vector<std::string> sigLifetimeParams;
  std::vector<std::pair<int, int>> sigLifetimeOutlives;
  std::vector<struct TypeSpec> genericArgs; // generic type arguments: Box<int>
  // Optional declaration parameter name in a generic argument list, e.g.
  // Box<N = 8> or make<T = int>(). Cleared after declaration-order mapping.
  std::string genericArgName;
  // A const generic argument is an integer value rather than a type. The
  // bounded V220 implementation accepts int64 constant expressions on
  // generic struct/class/function/method specializations (for example
  // Buffer<int, (2 * 8)> or capacity<(PAGE_SIZE / 2)>()).
  bool isConstValue = false;
  int64_t constValue = 0;
  // Deferred integer constant expression for generic arguments, e.g. (2 * 8).
  // Shared ownership keeps TypeSpec copyable; cloneTypeSpec deep-clones this AST.
  std::shared_ptr<Node> constExpr;
  bool hasSig = false;
  bool isVolatile = false;  // qualifier ของ element เมื่อ kind==ptr
  std::string lifetime;    // named lifetime binding on pointer types (V201+)
  int lifetimeParamIndex = -1; // resolved index in the enclosing function declaration
};
struct Param {
  TypeSpec ts;
  std::string name;
  bool ref = false, immutableRef = false, variadic = false, noescape = false, readonly = false;
  std::unique_ptr<struct Node> def;
};
struct EnumMember { std::string name; int64_t val; std::string str; std::vector<TypeSpec> payloadTypes; };
struct GenericBound { std::string param; TypeSpec bound; };

// Reorder explicit generic arguments into declaration order. Positional
// arguments may precede named arguments, but positional arguments after the
// first named argument are rejected to keep mixed calls predictable.
// The input is left untouched on failure so callers can still report useful
// diagnostics without losing the original labels.
inline bool orderNamedGenericArguments(std::vector<TypeSpec> &arguments,
                                       const std::vector<std::string> &parameters,
                                       std::string &diagnostic) {
  bool hasNamed = false;
  for (const TypeSpec &argument : arguments)
    if (!argument.genericArgName.empty()) { hasNamed = true; break; }
  if (!hasNamed) return true;

  std::map<std::string, size_t> parameterIndices;
  for (size_t i = 0; i < parameters.size(); ++i)
    parameterIndices.emplace(parameters[i], i);

  std::vector<size_t> destinations(arguments.size(), parameters.size());
  std::vector<bool> assigned(parameters.size(), false);
  size_t nextPositional = 0;
  bool sawNamed = false;
  for (size_t i = 0; i < arguments.size(); ++i) {
    const std::string &name = arguments[i].genericArgName;
    size_t destination = parameters.size();
    if (name.empty()) {
      if (sawNamed) {
        diagnostic = "ห้ามวาง positional generic argument หลัง named argument";
        return false;
      }
      while (nextPositional < assigned.size() && assigned[nextPositional])
        ++nextPositional;
      destination = nextPositional++;
      if (destination >= parameters.size()) {
        diagnostic = "generic arguments มากเกินไป";
        return false;
      }
    } else {
      sawNamed = true;
      const auto found = parameterIndices.find(name);
      if (found == parameterIndices.end()) {
        diagnostic = "ไม่พบ generic parameter ชื่อ '" + name + "'";
        return false;
      }
      destination = found->second;
    }
    if (assigned[destination]) {
      diagnostic = "ระบุ generic parameter '" + parameters[destination] + "' ซ้ำ";
      return false;
    }
    assigned[destination] = true;
    destinations[i] = destination;
  }

  for (size_t i = 0; i < assigned.size(); ++i) {
    if (!assigned[i]) {
      diagnostic = "ไม่ได้ระบุ generic parameter '" + parameters[i] + "'";
      return false;
    }
  }

  std::vector<TypeSpec> ordered(parameters.size());
  for (size_t i = 0; i < arguments.size(); ++i) {
    TypeSpec argument = std::move(arguments[i]);
    argument.genericArgName.clear();
    ordered[destinations[i]] = std::move(argument);
  }
  arguments = std::move(ordered);
  return true;
}

// Map positional/named generic arguments while allowing omitted parameters
// whose declarations provide defaults. The returned vector is declaration-
// ordered and `supplied[i]` distinguishes an explicit value from a slot that
// the caller must materialize from its declaration default.
inline bool orderNamedGenericArgumentsWithDefaults(
    std::vector<TypeSpec> &arguments,
    const std::vector<std::string> &parameters,
    const std::vector<bool> &hasDefaults,
    std::vector<bool> &supplied,
    std::string &diagnostic) {
  if (hasDefaults.size() != parameters.size()) {
    diagnostic = "internal generic default metadata size mismatch";
    return false;
  }
  std::map<std::string, size_t> parameterIndices;
  for (size_t i = 0; i < parameters.size(); ++i)
    parameterIndices.emplace(parameters[i], i);

  std::vector<TypeSpec> ordered(parameters.size());
  supplied.assign(parameters.size(), false);
  size_t nextPositional = 0;
  bool sawNamed = false;
  for (size_t i = 0; i < arguments.size(); ++i) {
    const std::string &name = arguments[i].genericArgName;
    size_t destination = parameters.size();
    if (name.empty()) {
      if (sawNamed) {
        diagnostic = "ห้ามวาง positional generic argument หลัง named argument";
        return false;
      }
      while (nextPositional < supplied.size() && supplied[nextPositional])
        ++nextPositional;
      destination = nextPositional++;
      if (destination >= parameters.size()) {
        diagnostic = "generic arguments มากเกินไป";
        return false;
      }
    } else {
      sawNamed = true;
      const auto found = parameterIndices.find(name);
      if (found == parameterIndices.end()) {
        diagnostic = "ไม่พบ generic parameter ชื่อ '" + name + "'";
        return false;
      }
      destination = found->second;
    }
    if (supplied[destination]) {
      diagnostic = "ระบุ generic parameter '" + parameters[destination] + "' ซ้ำ";
      return false;
    }
    supplied[destination] = true;
    ordered[destination] = std::move(arguments[i]);
    ordered[destination].genericArgName.clear();
  }

  for (size_t i = 0; i < supplied.size(); ++i) {
    if (!supplied[i] && !hasDefaults[i]) {
      diagnostic = "ไม่ได้ระบุ generic parameter '" + parameters[i] + "' และไม่มีค่า default";
      return false;
    }
  }
  arguments = std::move(ordered);
  return true;
}

// Built-in predicates accepted by `const int N: predicate` generic bounds.
// Keep this list shared by parser and semantic specialization checks so an
// accepted spelling can never become an unchecked constraint.
inline bool isConstGenericConstraintName(const std::string &name) {
  return name == "positive" || name == "nonnegative" || name == "nonzero" ||
         name == "negative" || name == "even" || name == "odd" ||
         name == "power_of_two";
}
inline bool satisfiesConstGenericConstraint(const std::string &name, int64_t value) {
  if (name == "positive") return value > 0;
  if (name == "nonnegative") return value >= 0;
  if (name == "nonzero") return value != 0;
  if (name == "negative") return value < 0;
  if (name == "even") return (value % 2) == 0;
  if (name == "odd") return (value % 2) != 0;
  if (name == "power_of_two") {
    if (value <= 0) return false;
    const uint64_t v = static_cast<uint64_t>(value);
    return (v & (v - 1)) == 0;
  }
  return false;
}
struct CaseRange { NP lo, hi; };
struct Case { std::vector<NP> vals; std::vector<CaseRange> ranges; NP body, guard, exprBody; std::string variantEnum, variantName; std::vector<std::string> bindings; bool wildcard = false; };
struct Node {
  NK k; int line = 0;
  std::string s;
  int64_t iv = 0; double dv = 0; bool b = false;
  std::vector<NP> c;
  TypeSpec ts;
  std::vector<Param> params;
  std::vector<EnumMember> members;
  std::vector<Case> cases;
  NP deflt;
  std::vector<NP> methods;
  bool isPublic = false, isPrivate = false, isProtected = false, isStatic = false, isClass = false, isConstructor = false, isDestructor = false, isOverride = false;
  bool isFinal = false;
  bool isUnsafe = false;                          // unsafe function / unsafe { } block: ปลดล็อกการใช้ ptr ดิบในโหมด --safe
  bool isConst = false, isConsteval = false, isExtern = false, cvar = false, isExport = false;
  bool isRef = false, isImmutableRef = false; // local scoped borrow binding: ref [const] T alias = lvalue
  bool isVolatile = false; bool genericSubstituted = false; int64_t alignment = 0;
  std::string label;                               // ชื่อ label ของ loop (outer: for ...) / เป้าหมายของ break/continue label
  bool isInterface = false, isAbstract = false;   // interface / abstract class / abstract method (ไม่มี body)
  std::vector<std::string> impls;                // normalized class/interface parent types
  std::vector<TypeSpec> implTypeSpecs;           // source forms, including generic interface args
  TypeSpec parentType;                           // class extends type (may be generic)
  std::vector<std::string> typeParams;            // generic class/interface/function parameters
  std::vector<std::string> constGenericParams;    // const int parameters (subset of typeParams)
  std::vector<TypeSpec> genericDefaults;          // declaration-order defaults, aligned with typeParams
  std::vector<bool> genericHasDefault;             // distinguishes an omitted default from an empty TypeSpec
  std::vector<std::string> lifetimeParams;        // named lifetime parameters on functions (V200+)
  std::vector<std::pair<int, int>> lifetimeOutlives; // (longer, shorter) constraints, resolved to lifetime parameter indices (V202+)
  std::vector<GenericBound> genericBounds;        // T: Interface / T: Base / T: numeric; const N: positive/even/...
  std::vector<TypeSpec> genericAppliedArgs;       // concrete arguments retained for constraint validation
  std::vector<std::string> genericAppliedNames;
  std::vector<TypeSpec> explicitTypeArgs;          // method-level call syntax: value.map<int>(...)
  std::string parent;
  std::string csym;
  std::string module;
  Node(NK k_, int l) : k(k_), line(l) {}
};
inline NP cloneNode(const Node *src);
inline TypeSpec cloneTypeSpec(const TypeSpec &src) {
  TypeSpec d; d.elemObj = src.elemObj; d.cat = src.cat; d.kind = src.kind; d.base = src.base; d.base2 = src.base2;
  d.size = cloneNode(src.size.get());
  d.hasSize = src.hasSize; d.size2 = cloneNode(src.size2.get()); d.hasSize2 = src.hasSize2;
  d.sig.reserve(src.sig.size()); for (const auto &a : src.sig) d.sig.push_back(cloneTypeSpec(a));
  d.sigNoescape = src.sigNoescape; d.sigReadonly = src.sigReadonly;
  if (src.sigReturnType) d.sigReturnType = std::make_shared<TypeSpec>(cloneTypeSpec(*src.sigReturnType));
  d.sigLifetimeParams = src.sigLifetimeParams; d.sigLifetimeOutlives = src.sigLifetimeOutlives;
  d.genericArgs.reserve(src.genericArgs.size()); for (const auto &a : src.genericArgs) d.genericArgs.push_back(cloneTypeSpec(a));
  d.genericArgName = src.genericArgName;
  d.isConstValue = src.isConstValue; d.constValue = src.constValue;
  if (src.constExpr) d.constExpr = std::shared_ptr<Node>(cloneNode(src.constExpr.get()).release());
  d.hasSig = src.hasSig; d.isVolatile = src.isVolatile; d.lifetime = src.lifetime; d.lifetimeParamIndex = src.lifetimeParamIndex; return d;
}
inline NP cloneNode(const Node *src) {
  if (!src) return nullptr;
  NP d = std::make_unique<Node>(src->k, src->line);
  d->s = src->s; d->iv = src->iv; d->dv = src->dv; d->b = src->b; d->ts = cloneTypeSpec(src->ts);
  d->isPublic = src->isPublic; d->isPrivate = src->isPrivate; d->isProtected = src->isProtected;
  d->isUnsafe = src->isUnsafe; d->isStatic = src->isStatic; d->isClass = src->isClass; d->isConstructor = src->isConstructor; d->isDestructor = src->isDestructor;
  d->isOverride = src->isOverride; d->isFinal = src->isFinal; d->isConst = src->isConst; d->isConsteval = src->isConsteval; d->isExtern = src->isExtern; d->cvar = src->cvar; d->isExport = src->isExport;
  d->isRef = src->isRef; d->isImmutableRef = src->isImmutableRef;
  d->isVolatile = src->isVolatile; d->genericSubstituted = src->genericSubstituted; d->alignment = src->alignment; d->label = src->label; d->isInterface = src->isInterface; d->isAbstract = src->isAbstract;
  d->impls = src->impls; d->implTypeSpecs.reserve(src->implTypeSpecs.size());
  for (const auto &a : src->implTypeSpecs) d->implTypeSpecs.push_back(cloneTypeSpec(a));
  d->parent = src->parent; d->parentType = cloneTypeSpec(src->parentType); d->typeParams = src->typeParams; d->constGenericParams = src->constGenericParams; d->genericDefaults.reserve(src->genericDefaults.size()); for (const auto &a : src->genericDefaults) d->genericDefaults.push_back(cloneTypeSpec(a)); d->genericHasDefault = src->genericHasDefault; d->lifetimeParams = src->lifetimeParams; d->lifetimeOutlives = src->lifetimeOutlives;
  d->genericAppliedNames = src->genericAppliedNames;
  d->genericAppliedArgs.reserve(src->genericAppliedArgs.size()); for (const auto &a : src->genericAppliedArgs) d->genericAppliedArgs.push_back(cloneTypeSpec(a));
  d->explicitTypeArgs.reserve(src->explicitTypeArgs.size()); for (const auto &a : src->explicitTypeArgs) d->explicitTypeArgs.push_back(cloneTypeSpec(a));
  d->genericBounds.reserve(src->genericBounds.size()); for (const auto &b : src->genericBounds) d->genericBounds.push_back({b.param, cloneTypeSpec(b.bound)});
  d->csym = src->csym; d->module = src->module;
  d->c.reserve(src->c.size()); for (const auto &c : src->c) d->c.push_back(cloneNode(c.get()));
  d->methods.reserve(src->methods.size()); for (const auto &m : src->methods) d->methods.push_back(cloneNode(m.get()));
  d->params.reserve(src->params.size());
  for (const auto &pa : src->params) { Param cp; cp.ts = cloneTypeSpec(pa.ts); cp.name = pa.name; cp.ref = pa.ref; cp.immutableRef = pa.immutableRef; cp.variadic = pa.variadic; cp.noescape = pa.noescape; cp.readonly = pa.readonly; cp.def = cloneNode(pa.def.get()); d->params.push_back(std::move(cp)); }
  d->members.reserve(src->members.size());
  for (const auto &m : src->members) {
    EnumMember em; em.name = m.name; em.val = m.val; em.str = m.str;
    for (const auto &pt : m.payloadTypes) em.payloadTypes.push_back(cloneTypeSpec(pt));
    d->members.push_back(std::move(em));
  }
  d->cases.reserve(src->cases.size());
  for (const auto &cs : src->cases) {
    Case cc;
    for (const auto &v : cs.vals) cc.vals.push_back(cloneNode(v.get()));
    for (const auto &r : cs.ranges) cc.ranges.push_back({cloneNode(r.lo.get()), cloneNode(r.hi.get())});
    cc.variantEnum = cs.variantEnum; cc.variantName = cs.variantName; cc.bindings = cs.bindings; cc.wildcard = cs.wildcard;
    cc.body = cloneNode(cs.body.get()); cc.guard = cloneNode(cs.guard.get()); cc.exprBody = cloneNode(cs.exprBody.get()); d->cases.push_back(std::move(cc));
  }
  d->deflt = cloneNode(src->deflt.get()); return d;
}

struct ImportSpec {
  std::string module, alias;
  bool global = false;
  int line = 0;
  int selection = 0;              // 0=all, 1=just, 2=without
  std::set<std::string> names;
};
struct StaticAssertion {
  NP expr;
  std::string message;
  int line = 0;
};
struct Program {
  std::string module, file;
  std::vector<std::string> imports;
  std::vector<ImportSpec> importSpecs;
  std::vector<std::pair<std::string, std::string>> aliases;
  std::vector<std::string> links;
  std::vector<NP> funcs, structs, enums, globals;
  std::vector<StaticAssertion> staticAssertions;
};
