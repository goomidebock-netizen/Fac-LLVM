// ---- (included inside class Gen) V2 data structures: linked, hashmap, hashset, tree, graph ----
T dsKeyT(const T &t) { return t->name == "hashmap" ? t->key : t->el; }

void checkDsElem(const T &e, int line) {
  if (!(e->k == INT || e->k == BOOL || e->k == CHAR || e->k == UNI || e->k == F32 || e->k == F64 || e->k == STR || e->k == ENUM))
    err("สมาชิกของ " + std::string("data structure") + " ต้องเป็นตัวเลข/char/boolean/string/enum (เจอ " + tname(e) + ")", line);
}

std::string dsNew(const T &t) {
  const std::string &n = t->name;
  T k = dsKeyT(t), e = t->el;
  std::string kc = std::to_string(tcode(k)), ks = std::to_string(sizeOf(k));
  if (n == "hashmap") return def("call ptr @fac_hm_new(i32 " + kc + ", i32 " + ks + ", i32 " + std::to_string(tcode(e)) + ", i32 " + std::to_string(sizeOf(e)) + ")");
  if (n == "hashset") return def("call ptr @fac_hs_new(i32 " + kc + ", i32 " + ks + ")");
  if (n == "stack") return def("call ptr @fac_st_new(i32 " + kc + ", i32 " + ks + ")");
  if (n == "queue") return def("call ptr @fac_q_new(i32 " + kc + ", i32 " + ks + ")");
  if (n == "heap") return def("call ptr @fac_hp_new(i32 " + kc + ", i32 " + ks + ")");
  if (n == "maxheap") return def("call ptr @fac_mxh_new(i32 " + kc + ", i32 " + ks + ")");
  if (n == "trie") return def("call ptr @fac_ti_new()");
  if (n == "tree") return def("call ptr @fac_tr_new(i32 " + kc + ", i32 " + ks + ")");
  if (n == "graph") return def("call ptr @fac_g_new(i32 " + kc + ", i32 " + ks + ")");
  return def("call ptr @fac_ll_new(i32 " + kc + ", i32 " + ks + ")");  // linked
}

V dsMethod(V ov, const std::string &m, const std::vector<Node *> &args, Node *n) {
  borrow(ov);
  const std::string &ds = ov.t->name;
  T kt = dsKeyT(ov.t), et = ov.t->el;
  if (m == "isEmpty" && args.empty()) return boolV(def("icmp eq i64 " + def("call i64 @fac_ds_len(ptr " + ov.v + ")") + ", 0"));
  if ((m == "size" || m == "length") && args.empty()) { V r; r.t = T_int; r.v = def("trunc i64 " + def("call i64 @fac_ds_len(ptr " + ov.v + ")") + " to i32"); return r; }
  if (ds == "matrix" && (m == "rows" || m == "cols") && args.empty()) { V r; r.t = T_int; r.v = def(std::string("call i32 @fac_mx_") + (m == "rows" ? "rows" : "cols") + "(ptr " + ov.v + ")"); return r; }
  if (m == "clear" && args.empty()) { ins("call void @fac_ds_clear(ptr " + ov.v + ")"); return V(); }
  if (m == "copy" && args.empty()) { V r; r.t = ov.t; r.owned = true; r.v = def("call ptr @fac_ds_copy(ptr " + ov.v + ")"); return r; }
  for (const DM *d = DTAB; d->ds; d++) {
    if (ds != d->ds || m != d->m || strlen(d->params) != args.size()) continue;
    std::string al = "ptr " + ov.v;
    for (size_t i = 0; i < args.size(); i++) {
      V a = expr(args[i]); borrow(a);
      char c = d->params[i];
      if (c == 'K' || c == 'E') {
        T t = c == 'K' ? kt : et;
        if (t->k == STR && a.t->k != STR) err(ds + "." + m + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็น string", n->line);
        std::string tmp = alloca_(t);
        ins("store " + llty(t) + " " + conv(a, t, n->line) + ", ptr " + tmp);
        al += ", ptr " + tmp;
      } else if (c == 'd') al += ", double " + conv(a, T_double, n->line);
      else if (c == 'l') al += ", i64 " + conv(a, T_long, n->line);
      else if (c == 'D') {
        if (a.t->k != DSK || a.t->name != ds) err(ds + "." + m + " ต้องรับ " + ds + " อีกตัว", n->line);
        al += ", ptr " + a.v;
      }
    }
    auto cl = [&](const std::string &rt, const std::string &extra = "") { return "call " + rt + " @" + d->sym + "(" + al + extra + ")"; };
    V r;
    switch (d->ret) {
      case 'v': ins(cl("void")); return r;
      case 'b': { std::string x = def(cl("i32")); return boolV(def("icmp ne i32 " + x + ", 0")); }
      case 'i': r.t = T_int; r.v = def(cl("i32")); return r;
      case 'E': {
        std::string out = alloca_(et);
        ins(cl("void", ", ptr " + out));
        r.t = et; r.v = def("load " + llty(et) + ", ptr " + out); return r;  // ยืมค่าจาก container (ไม่ owned)
      }
      case 'O': {
        std::string out = alloca_(et);
        ins(cl("void", ", ptr " + out));
        r.t = et; r.v = def("load " + llty(et) + ", ptr " + out);
        r.owned = et->k == STR; // pop/dequeue ย้าย ownership ของ string ออกจาก container
        return r;
      }
      case 'L': r.t = tList(et); r.owned = true; r.v = def(cl("ptr")); return r;
      case 'Q': r.t = tList(kt); r.owned = true; r.v = def(cl("ptr")); return r;
      default: r.t = ov.t; r.owned = true; r.v = def(cl("ptr")); return r;
    }
  }
  err(ds + " ไม่มี method '" + m + "' ที่รับ " + std::to_string(args.size()) + " argument", n->line);
}

void dsDecl(Node *n) {
  TypeSpec &ts = n->ts;
  if (ts.kind == "ptr") err(ts.cat + " ใช้ kind ptr ไม่ได้", n->line);
  T t = resolveType(ts, n->line);
  checkDsElem(t->el, n->line); checkDsElem(dsKeyT(t), n->line);
  if (t->name == "trie" && t->el->k != STR) err("trie ใช้ได้กับ string เท่านั้น เช่น trie dyn string words", n->line);
  Node *init = n->c.empty() ? nullptr : n->c[0].get();
  std::string d;
  if (!init) d = dsNew(t);
  else if (init->k == NK::InitList) {
    d = dsNew(t);
    if (!init->c.empty()) {
      if (t->name == "hashmap" || t->name == "graph") err(t->name + " ใส่ค่าเริ่มต้นด้วย {...} ไม่ได้ (ใช้ .set / .addEdge)", n->line);
      V ov; ov.t = t; ov.v = d;
      for (auto &e : init->c) dsMethod(ov, t->name == "linked" ? "addLast" : "add", {e.get()}, n);
    }
  } else {
    V v = expr(init);
    if (v.t->k != DSK || v.t->name != t->name) err("ต้องกำหนด " + t->name + " ด้วย " + t->name + " ชนิดเดียวกัน หรือ {...}", n->line);
    V owned = ownV(v); d = owned.v; transferTemp(owned);
  }
  std::string slot = alloca_(t); ins("store ptr " + d + ", ptr " + slot);
  Var &v = declVar(n->s, t, ts.kind); v.slot = slot;
  if (ts.kind != "heap") regCleanup(v);
}
