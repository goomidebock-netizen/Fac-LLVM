// ---- (included inside class Gen) vec2/vec3/vec4/mat4 : struct ในตัวภาษา + operator + ฟังก์ชันคณิตศาสตร์เวกเตอร์ ----
static bool isVecName(const std::string &n) { return n == "vec2" || n == "vec3" || n == "vec4"; }
static int vecN(const std::string &n) { return n[3] - '0'; }
bool isVecT(const T &t) { return t->k == STRUCT && isVecName(t->name); }
bool isMatT(const T &t) { return t->k == STRUCT && t->name == "mat4"; }

std::string vcomp(const V &v, int i) {
  return def("load float, ptr " + def("getelementptr inbounds %S." + v.t->name + ", ptr " + v.v + ", i32 0, i32 " + std::to_string(i)));
}
V vnew(const T &t, const std::vector<std::string> &c) {
  std::string a = alloca_(t);
  for (size_t i = 0; i < c.size(); i++) ins("store float " + c[i] + ", ptr " + def("getelementptr inbounds %S." + t->name + ", ptr " + a + ", i32 0, i32 " + std::to_string(i)));
  V r; r.t = t; r.v = a; return r;
}
std::string fsqrt(const std::string &x) { declIntr("llvm.sqrt.f32", "float @llvm.sqrt.f32(float)"); return def("call float @llvm.sqrt.f32(float " + x + ")"); }
std::string fop(const std::string &op, const std::string &x, const std::string &y) {
  return def(std::string(op == "+" ? "fadd" : op == "-" ? "fsub" : op == "*" ? "fmul" : "fdiv") + " float " + x + ", " + y);
}

V vecBinop(const std::string &op, V a, V b, int line) {
  if (isMatT(a.t) || isMatT(b.t)) {
    if (op != "*") err("mat4 รองรับเฉพาะ * (mat4*mat4, mat4*vec4, mat4*vec3)", line);
    if (!isMatT(a.t)) err("ต้องเขียน mat4 * vector (matrix อยู่ซ้าย)", line);
    if (isMatT(b.t)) { V r; r.t = a.t; r.v = alloca_(a.t); ins("call void @fac_mat4_mul(ptr " + r.v + ", ptr " + a.v + ", ptr " + b.v + ")"); return r; }
    if (b.t->k == STRUCT && (b.t->name == "vec4" || b.t->name == "vec3")) {
      V r; r.t = b.t; r.v = alloca_(b.t);
      ins("call void @" + std::string(b.t->name == "vec4" ? "fac_mat4_mulv" : "fac_mat4_mulp") + "(ptr " + r.v + ", ptr " + a.v + ", ptr " + b.v + ")"); return r;
    }
    err("mat4 * " + tname(b.t) + " ไม่ได้", line);
  }
  bool av = isVecT(a.t), bv = isVecT(b.t);
  if (av && bv && a.t->name != b.t->name) err("vector คนละขนาด (" + a.t->name + " กับ " + b.t->name + ")", line);
  if ((!av && !isNum(a.t)) || (!bv && !isNum(b.t))) err("ใช้ '" + op + "' กับ " + tname(a.t) + " และ " + tname(b.t) + " ไม่ได้", line);
  T vt = av ? a.t : b.t; int nc = vecN(vt->name);
  std::string sa, sb;
  if (!av) sa = conv(a, T_float, line);
  if (!bv) sb = conv(b, T_float, line);
  if (op == "==" || op == "!=") {
    if (!(av && bv)) err("เทียบ vector ได้เฉพาะ vector กับ vector", line);
    std::string all = "true";
    for (int i = 0; i < nc; i++) { std::string c = def("fcmp oeq float " + vcomp(a, i) + ", " + vcomp(b, i)); all = def("and i1 " + all + ", " + c); }
    return boolV(op == "==" ? all : def("xor i1 " + all + ", true"));
  }
  if (op != "+" && op != "-" && op != "*" && op != "/") err("vector ไม่รองรับ '" + op + "' (ใช้ + - * / == !=)", line);
  if ((op == "+" || op == "-") && (!av || !bv)) err("vector " + op + " ต้องเป็น vector ทั้งสองข้าง (ใช้ * / กับตัวเลขได้)", line);
  std::vector<std::string> c;
  for (int i = 0; i < nc; i++) c.push_back(fop(op, av ? vcomp(a, i) : sa, bv ? vcomp(b, i) : sb));
  return vnew(vt, c);
}

V vecNeg(const V &a) {
  std::vector<std::string> c; for (int i = 0; i < vecN(a.t->name); i++) c.push_back(def("fneg float " + vcomp(a, i)));
  return vnew(a.t, c);
}

std::string vdot(const V &a, const V &b) {
  std::string s = "0.0";
  for (int i = 0; i < vecN(a.t->name); i++) { std::string m = fop("*", vcomp(a, i), vcomp(b, i)); s = i == 0 ? m : fop("+", s, m); }
  return s;
}

V vecFunc(const std::string &fn, const std::vector<Node *> &args, Node *n) {
  auto vec = [&](size_t i) { V v = expr(args[i]); if (!isVecT(v.t)) err("math." + fn + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็น vector", n->line); return v; };
  auto need = [&](size_t k) { if (args.size() != k) err("math." + fn + " ต้องการ " + std::to_string(k) + " argument", n->line); };
  V r;
  if (fn == "dot") { need(2); V a = vec(0), b = vec(1); if (a.t->name != b.t->name) err("math.dot: vector คนละขนาด", n->line); r.t = T_float; r.v = vdot(a, b); return r; }
  if (fn == "length" || fn == "lengthSq") { need(1); V a = vec(0); std::string d = vdot(a, a); r.t = T_float; r.v = fn == "length" ? fsqrt(d) : d; return r; }
  if (fn == "distance") {
    need(2); V a = vec(0), b = vec(1); if (a.t->name != b.t->name) err("math.distance: vector คนละขนาด", n->line);
    std::string s = "0.0";
    for (int i = 0; i < vecN(a.t->name); i++) { std::string d = fop("-", vcomp(a, i), vcomp(b, i)); std::string m = fop("*", d, d); s = i == 0 ? m : fop("+", s, m); }
    r.t = T_float; r.v = fsqrt(s); return r;
  }
  if (fn == "normalize") {
    need(1); V a = vec(0); std::string len = fsqrt(vdot(a, a)), pos = def("fcmp ogt float " + len + ", 0.0");
    std::string inv = def("select i1 " + pos + ", float " + len + ", float 1.0");
    std::vector<std::string> c; for (int i = 0; i < vecN(a.t->name); i++) c.push_back(fop("/", vcomp(a, i), inv));
    return vnew(a.t, c);
  }
  if (fn == "cross") {
    need(2); V a = vec(0), b = vec(1);
    if (a.t->name != "vec3" || b.t->name != "vec3") err("math.cross ใช้กับ vec3 เท่านั้น", n->line);
    std::string ax = vcomp(a, 0), ay = vcomp(a, 1), az = vcomp(a, 2), bx = vcomp(b, 0), by = vcomp(b, 1), bz = vcomp(b, 2);
    return vnew(a.t, {fop("-", fop("*", ay, bz), fop("*", az, by)), fop("-", fop("*", az, bx), fop("*", ax, bz)), fop("-", fop("*", ax, by), fop("*", ay, bx))});
  }
  if (fn == "lerp") {
    need(3); V a = vec(0), b = vec(1); V t = expr(args[2]); if (a.t->name != b.t->name) err("math.lerp: vector คนละขนาด", n->line);
    std::string tt = conv(t, T_float, n->line); std::vector<std::string> c;
    for (int i = 0; i < vecN(a.t->name); i++) { std::string x = vcomp(a, i); c.push_back(fop("+", x, fop("*", fop("-", vcomp(b, i), x), tt))); }
    return vnew(a.t, c);
  }
  if (fn == "reflect") {
    need(2); V v = vec(0), nn = vec(1); if (v.t->name != nn.t->name) err("math.reflect: vector คนละขนาด", n->line);
    std::string k = fop("*", "2.0", vdot(v, nn)); std::vector<std::string> c;
    for (int i = 0; i < vecN(v.t->name); i++) c.push_back(fop("-", vcomp(v, i), fop("*", k, vcomp(nn, i))));
    return vnew(v.t, c);
  }
  err("math." + fn + " ใช้กับ vector ไม่ได้ (มี: dot cross length lengthSq distance normalize lerp reflect)", n->line);
}

V vecCtor(const std::string &name, const std::vector<Node *> &args, Node *n) {  // vec3(1) splat · vec4(v3, w) · vec3(v2, z) · vec3(v4) ตัด
  T t = tStruct(name); int nc = vecN(name);
  if (args.size() == 1) {
    V a = expr(args[0]);
    if (isNum(a.t)) { std::string s = conv(a, T_float, n->line); return vnew(t, std::vector<std::string>((size_t)nc, s)); }
    if (isVecT(a.t)) { std::vector<std::string> c; int sn = vecN(a.t->name); for (int i = 0; i < nc; i++) c.push_back(i < sn ? vcomp(a, i) : "0.0"); return vnew(t, c); }
    err(name + "(...): argument ต้องเป็นตัวเลขหรือ vector", n->line);
  }
  if (args.size() == 2) {
    V a = expr(args[0]);
    if (isVecT(a.t) && vecN(a.t->name) == nc - 1) {
      V b = expr(args[1]); std::vector<std::string> c; for (int i = 0; i < nc - 1; i++) c.push_back(vcomp(a, i)); c.push_back(conv(b, T_float, n->line)); return vnew(t, c);
    }
  }
  if (args.size() > (size_t)nc) err(name + " มี " + std::to_string(nc) + " ค่า แต่ส่งมา " + std::to_string(args.size()), n->line);
  std::vector<std::string> c;  // ตัวเลขทุกแบบแปลงเป็น float ตรงๆ (เช่น -1.0 หรือ int) ไม่ต้อง cast; ค่าที่ไม่ส่งเป็น 0
  for (size_t i = 0; i < (size_t)nc; i++) {
    if (i >= args.size()) { c.push_back("0.0"); continue; }
    V a = expr(args[i]); if (!isNum(a.t)) err(name + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็นตัวเลข", n->line);
    c.push_back(conv(a, T_float, n->line));
  }
  return vnew(t, c);
}

V mat4Call(const std::string &fn, const std::vector<Node *> &args, Node *n) {
  static const struct { const char *n, *a, *sym; } MF[] = {
    {"identity", "", "fac_mat4_identity"}, {"translate", "fff", "fac_mat4_translate"}, {"scale", "fff", "fac_mat4_scale"},
    {"rotateX", "f", "fac_mat4_rotatex"}, {"rotateY", "f", "fac_mat4_rotatey"}, {"rotateZ", "f", "fac_mat4_rotatez"},
    {"perspective", "ffff", "fac_mat4_perspective"}, {"ortho", "ffffff", "fac_mat4_ortho"}, {"lookAt", "vvv", "fac_mat4_lookat"},
    {"transpose", "m", "fac_mat4_transpose"}, {"inverse", "m", "fac_mat4_inverse"}, {nullptr, nullptr, nullptr}};
  for (auto *m = MF; m->n; m++) {
    if (fn != m->n) continue;
    if (strlen(m->a) != args.size()) err(std::string("mat4.") + fn + " ต้องการ " + std::to_string(strlen(m->a)) + " argument", n->line);
    V r; r.t = tStruct("mat4"); r.v = alloca_(r.t);
    std::string al = "ptr " + r.v;
    for (size_t i = 0; i < args.size(); i++) {
      V a = expr(args[i]);
      if (m->a[i] == 'f') al += ", float " + conv(a, T_float, n->line);
      else if (m->a[i] == 'v') { if (!(a.t->k == STRUCT && a.t->name == "vec3")) err(std::string("mat4.") + fn + ": argument ที่ " + std::to_string(i + 1) + " ต้องเป็น vec3", n->line); al += ", ptr " + a.v; }
      else { if (!isMatT(a.t)) err(std::string("mat4.") + fn + ": ต้องเป็น mat4", n->line); al += ", ptr " + a.v; }
    }
    ins(std::string("call void @") + m->sym + "(" + al + ")");
    return r;
  }
  err("ไม่รู้จัก mat4." + fn + " (มี: identity translate scale rotateX rotateY rotateZ perspective ortho lookAt transpose inverse)", n->line);
}
