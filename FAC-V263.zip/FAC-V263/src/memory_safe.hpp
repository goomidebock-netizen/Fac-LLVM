#pragma once
#include "parser.hpp"
#include <set>
#include <string>
#include <cstring>
#include <vector>

// Conservative, fail-closed source profile. This deliberately accepts a
// smaller language subset than --secure: it excludes raw/opaque pointers,
// manual heap storage, FFI and unsafe blocks/functions. Checked `ref` borrows
// are allowed only in function scopes, where strict ownership analysis runs.
// It is a memory-safety boundary, not a proof that the C++ Runtime is verified.
namespace fac_memory_safe {

[[noreturn]] inline void reject(const Program &program, int line, const std::string &why) {
  throw CompileError(line, "memory-safe: " + why + " [module " + program.module + ", " + program.file + "]");
}

inline void checkNode(const Program &program, const Node *node, bool allowBorrow = false);

inline void checkType(const Program &program, const TypeSpec &type, int line) {
  if (type.kind == "ptr") reject(program, line, "raw pointer type is not permitted");
  if (type.kind == "heap") reject(program, line, "manual heap storage is not permitted");
  if (type.base == "ptr" || type.base2 == "ptr") reject(program, line, "opaque pointer type is not permitted");
  if (type.isVolatile) reject(program, line, "volatile storage is outside the memory-safe subset");
  for (const auto &sig : type.sig) checkType(program, sig, line);
  for (const auto &arg : type.genericArgs) checkType(program, arg, line);
  // Array/matrix dimensions are expressions too. Scan them so an unsafe
  // primitive cannot hide in a type-level expression.
  checkNode(program, type.size.get());
  checkNode(program, type.size2.get());
}

inline std::string calleePath(const Node *node) {
  if (!node) return {};
  if (node->k == NK::Ident) return node->s;
  if (node->k == NK::Member && node->c.size() == 1) {
    std::string base = calleePath(node->c[0].get());
    return base.empty() ? std::string{} : base + "." + node->s;
  }
  return {};
}

inline std::string canonicalCallPath(const Program &program, const std::string &path) {
  const size_t dot = path.find('.');
  if (dot == std::string::npos) return path;
  const std::string head = path.substr(0, dot);
  for (const auto &imported : program.importSpecs) {
    if (!imported.alias.empty() && imported.alias == head)
      return imported.module + path.substr(dot);
  }
  return path;
}

inline const std::set<std::string> &builtinModulesWithRawHandles() {
  // Build this index once. The safe-profile AST walk may visit many calls; do
  // not rescan the full built-in declaration table for every call expression.
  static const std::set<std::string> modules = [] {
    std::set<std::string> result;
    for (const BI *builtin = BTAB; builtin->q; ++builtin) {
      if (builtin->ret != 'p' && !std::strchr(builtin->params, 'p') && !std::strchr(builtin->params, 'M')) continue;
      const std::string name(builtin->q);
      const size_t dot = name.find('.');
      if (dot != std::string::npos) result.insert(name.substr(0, dot));
    }
    return result;
  }();
  return modules;
}

inline bool builtinModuleUsesRawHandles(const std::string &module) {
  return builtinModulesWithRawHandles().count(module) != 0;
}

inline void checkNode(const Program &program, const Node *node, bool allowBorrow) {
  if (!node) return;
  if (node->isUnsafe) reject(program, node->line, "unsafe block/function is not permitted");
  if (node->isExtern) reject(program, node->line, "extern/FFI declaration is not permitted");
  if (node->isExport) reject(program, node->line, "exported native ABI boundary is not permitted");
  if ((node->isRef || node->isImmutableRef) && !allowBorrow)
    reject(program, node->line, "ref borrow is permitted only in function scopes checked by strict ownership analysis");
  if (node->isVolatile || node->ts.isVolatile)
    reject(program, node->line, "volatile memory access is not permitted");
  checkType(program, node->ts, node->line);
  if (node->k == NK::Deref)
    reject(program, node->line, "raw pointer dereference is not permitted");
  if (node->k == NK::Ident && (node->s == "addr" || node->s == "alloc" || node->s == "realloc" ||
      node->s == "free" || node->s == "cfn" || node->s == "cstr" || node->s == "memcpy" ||
      node->s == "memset" || node->s == "memcmp"))
    reject(program, node->line, "raw memory / function-pointer primitive reference '" + node->s + "' is not permitted");
  if (node->k == NK::Member) {
    const std::string referenced = canonicalCallPath(program, calleePath(node));
    if (referenced == "sys.run" || referenced == "sys.output")
      reject(program, node->line, "shell process execution API '" + referenced + "' is not permitted by this profile");
    const size_t dot = referenced.find('.');
    if (dot != std::string::npos && builtinModuleUsesRawHandles(referenced.substr(0, dot)))
      reject(program, node->line, "built-in native handle reference '" + referenced + "' is not permitted by this profile");
  }
  if (node->k == NK::Call && !node->c.empty()) {
    const std::string path = canonicalCallPath(program, calleePath(node->c[0].get()));
    static const std::set<std::string> forbidden = {
      "addr", "alloc", "realloc", "free", "cfn", "cstr", "memcpy", "memset", "memcmp",
      "memory.copy", "memory.set", "memory.compare", "memory.zero"
    };
    const std::string leaf = path.substr(path.find_last_of('.') == std::string::npos ? 0 : path.find_last_of('.') + 1);
    if (forbidden.count(path) || forbidden.count(leaf))
      reject(program, node->line, "raw memory / function-pointer primitive '" + path + "' is not permitted");
    if (path == "sys.run" || path == "sys.output")
      reject(program, node->line, "shell process execution API '" + path + "' is not permitted by this profile");
    const size_t moduleDot = path.find('.');
    if (moduleDot != std::string::npos) {
      const std::string module = path.substr(0, moduleDot);
      if (builtinModuleUsesRawHandles(module))
        reject(program, node->line, "built-in module '" + module + "' exposes raw native handles; this module is outside the memory-safe subset");
    }
  }
  for (const auto &param : node->params) {
    if ((param.ref || param.immutableRef) && !allowBorrow)
      reject(program, node->line, "ref parameter '" + param.name + "' is permitted only on a checked function declaration");
    checkType(program, param.ts, node->line);
    if (param.def) checkNode(program, param.def.get());
  }
  for (const auto &member : node->members)
    for (const auto &payload : member.payloadTypes) checkType(program, payload, node->line);
  checkType(program, node->parentType, node->line);
  for (const auto &impl : node->implTypeSpecs) checkType(program, impl, node->line);
  for (const auto &bound : node->genericBounds) {
    if (std::find(node->constGenericParams.begin(), node->constGenericParams.end(), bound.param) == node->constGenericParams.end())
      checkType(program, bound.bound, node->line);
  }
  for (const auto &arg : node->genericAppliedArgs) checkType(program, arg, node->line);
  for (const auto &arg : node->explicitTypeArgs) checkType(program, arg, node->line);
  // A borrow is allowed only inside a function body (including its nested
  // blocks/lambdas). Aggregate fields and module globals are visited without
  // this permission, because the local CFG loan checker does not model them.
  const bool childAllowsBorrow = allowBorrow || node->k == NK::Func || node->k == NK::Lambda;
  for (const auto &child : node->c) checkNode(program, child.get(), childAllowsBorrow);
  for (const auto &method : node->methods) checkNode(program, method.get(), true);
  for (const auto &cs : node->cases) {
    for (const auto &value : cs.vals) checkNode(program, value.get(), childAllowsBorrow);
    for (const auto &range : cs.ranges) { checkNode(program, range.lo.get(), childAllowsBorrow); checkNode(program, range.hi.get(), childAllowsBorrow); }
    checkNode(program, cs.body.get(), childAllowsBorrow);
    checkNode(program, cs.guard.get(), childAllowsBorrow);
    checkNode(program, cs.exprBody.get(), childAllowsBorrow);
  }
  checkNode(program, node->deflt.get(), childAllowsBorrow);
}

inline void check(const std::vector<std::unique_ptr<Program>> &programs) {
  for (const auto &entry : programs) {
    if (!entry) continue;
    const Program &program = *entry;
    // Type aliases are top-level declarations rather than AST nodes. Inspect
    // their targets explicitly so an unused raw-pointer/heap alias cannot sit
    // latent in a profile-checked module and later be made reachable through
    // another alias or future generic expansion.
    for (const auto &alias : program.aliases) {
      if (alias.second == "ptr" || alias.second == "heap")
        reject(program, 0, "type alias '" + alias.first + "' targets forbidden raw type '" + alias.second + "'");
    }
    for (const auto &imported : program.importSpecs) {
      if (builtinModuleUsesRawHandles(imported.module))
        reject(program, imported.line, "built-in module '" + imported.module + "' exposes raw native handles and is outside the memory-safe subset");
      // The sys module also exposes shell command execution. Reject the module
      // import as a whole so function values/aliases cannot hide sys.run/output.
      if (imported.module == "sys")
        reject(program, imported.line, "built-in module 'sys' exposes process execution and is outside the memory-safe subset");
    }
    if (!program.links.empty())
      reject(program, 0, "native link directives are not permitted");
    for (const auto &assertion : program.staticAssertions) checkNode(program, assertion.expr.get());
    for (const auto &function : program.funcs) checkNode(program, function.get(), true);
    for (const auto &type : program.structs) checkNode(program, type.get());
    for (const auto &type : program.enums) checkNode(program, type.get());
    for (const auto &global : program.globals) checkNode(program, global.get());
  }
}

} // namespace fac_memory_safe
