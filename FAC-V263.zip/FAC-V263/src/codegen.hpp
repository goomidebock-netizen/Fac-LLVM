// Fac codegen: AST -> LLVM IR (textual .ll)       (C++17)
// หลักการ: ทุกตัวแปรเป็น alloca (mem2reg/SROA ของ LLVM แปลงเป็น register ตอน -O2),
//          เรียก runtime ผ่าน C ABI, bounds-check เป็น branch ที่ถูกระบุว่า "ไม่น่าเกิด" (cold)
#pragma once
#include "hir.hpp"
#include "ast.hpp"
#include "lexer.hpp"
#include <algorithm>
#include <deque>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <sstream>
#include <string_view>

enum TK { VOID, INT, F32, F64, BOOL, CHAR, UNI, STR, PTR, ARR, LIST, DSK, FUNC, TUPLE, AUTOT, STRUCT, OBJ, WEAK, ENUM, OPAQUE, NULLT };
struct Ty;
typedef std::shared_ptr<Ty> T;
struct Ty {
  TK k; int bits = 0; bool sg = false; bool isVolatile = false; bool payloadEnum = false;
  T el, key; int64_t n = -1; std::string name; std::vector<T> ps; std::vector<bool> noescape, readonly;
  // Function-value lifetime contracts are compile-time-only and do not affect
  // the closure/function-pointer ABI.
  std::vector<std::string> lifetimeNames;
  std::vector<std::pair<int, int>> lifetimeOutlives;
  std::vector<int> parameterLifetimeIndices;
  int returnLifetimeIndex = -1;
};
static T mkT(TK k, int bits = 0, bool sg = false) { auto t = std::make_shared<Ty>(); t->k = k; t->bits = bits; t->sg = sg; return t; }
static T T_void = mkT(VOID), T_byte = mkT(INT, 8, true), T_short = mkT(INT, 16, true), T_int = mkT(INT, 32, true), T_long = mkT(INT, 64, true),
         T_ubyte = mkT(INT, 8, false), T_ushort = mkT(INT, 16, false), T_uint = mkT(INT, 32, false), T_ulong = mkT(INT, 64, false),
         T_float = mkT(F32), T_double = mkT(F64), T_bool = mkT(BOOL), T_char = mkT(CHAR), T_uni = mkT(UNI), T_str = mkT(STR),
         T_null = mkT(NULLT), T_opaque = mkT(OPAQUE);
static T tPtr(T el) { T t = mkT(PTR); t->el = el; return t; }
static T qualifyVolatile(const T &base) { T t = std::make_shared<Ty>(*base); t->isVolatile = true; return t; }
static T tArr(T el, int64_t n) { T t = mkT(ARR); t->el = el; t->n = n; return t; }
static T tList(T el) { T t = mkT(LIST); t->el = el; return t; }
static T tDS(const std::string &name, T key, T el) { T t = mkT(DSK); t->name = name; t->key = key; t->el = el; return t; }
static T tTuple(std::vector<T> ps) { auto t = std::make_shared<Ty>(); t->k = TUPLE; t->ps = std::move(ps); return t; }
static T tFunc(T ret, std::vector<T> ps, std::vector<bool> noescape = {}, std::vector<bool> readonly = {}) { T t = mkT(FUNC); t->el = ret; t->ps = std::move(ps); t->noescape = std::move(noescape); t->readonly = std::move(readonly); if (t->noescape.size() < t->ps.size()) t->noescape.resize(t->ps.size(), false); if (t->readonly.size() < t->ps.size()) t->readonly.resize(t->ps.size(), false); t->parameterLifetimeIndices.resize(t->ps.size(), -1); return t; }
static void setFunctionLifetimeContract(T &functionType, const Node *signature) {
  if (!functionType || functionType->k != FUNC || !signature) return;
  functionType->lifetimeNames = signature->lifetimeParams;
  functionType->lifetimeOutlives = signature->lifetimeOutlives;
  functionType->returnLifetimeIndex = signature->ts.lifetimeParamIndex;
  functionType->parameterLifetimeIndices.assign(functionType->ps.size(), -1);
  for (size_t i = 0; i < signature->params.size() && i < functionType->parameterLifetimeIndices.size(); ++i)
    functionType->parameterLifetimeIndices[i] = signature->params[i].ts.lifetimeParamIndex;
}
static T T_auto = mkT(AUTOT);
static T tStruct(const std::string &n) { T t = mkT(STRUCT); t->name = n; return t; }
static T tObj(const std::string &n) { T t = mkT(OBJ); t->name = n; return t; }
static T tWeak(const T &obj) { T t = mkT(WEAK); t->el = obj; t->name = obj->name; return t; }
static T tEnum(const std::string &n, bool payload = false) { T t = mkT(ENUM); t->name = n; t->payloadEnum = payload; return t; }
static bool isIntLike(const T &t) { return t->k == INT || t->k == BOOL || t->k == CHAR || t->k == UNI || (t->k == ENUM && !t->payloadEnum); }
static bool isFlt(const T &t) { return t->k == F32 || t->k == F64; }
static bool isNum(const T &t) { return isIntLike(t) || isFlt(t); }
static bool isPtrish(const T &t) { return t->k == PTR || t->k == OBJ || t->k == WEAK || t->k == OPAQUE || t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == NULLT; }
static int bitsOf(const T &t) { switch (t->k) { case INT: return t->bits; case BOOL: case CHAR: return 8; case UNI: case ENUM: return 32; default: return 0; } }
static bool signedOf(const T &t) { return t->k == INT ? t->sg : t->k == ENUM; }
static std::string tname(const T &t) {
  switch (t->k) {
    case VOID: return "void"; case F32: return "float"; case F64: return "double"; case BOOL: return "boolean"; case CHAR: return "char";
    case UNI: return "unichar"; case STR: return "string"; case PTR: return "ptr " + (t->el ? tname(t->el) : "?"); case ARR: return "array " + tname(t->el);
    case LIST: return "list " + tname(t->el); case STRUCT: return "struct " + t->name; case OBJ: return "obj " + t->name; case WEAK: return "weak obj " + t->name; case ENUM: return "enum " + t->name; case OPAQUE: return "ptr";
    case NULLT: return "null";
    case DSK: return t->name;
    case FUNC: return "function";
    case TUPLE: { std::string s = "("; for (size_t i = 0; i < t->ps.size(); i++) s += (i ? ", " : "") + tname(t->ps[i]); return s + ")"; }
    case AUTOT: return "auto";
    case INT: { std::string s = t->sg ? "" : "u"; return s + (t->bits == 8 ? "byte" : t->bits == 16 ? "short" : t->bits == 32 ? "int" : "long"); }
  }
  return "?";
}
static bool sameFunctionLifetimeShape(const T &a, const T &b) {
  if (!a || !b || a->lifetimeNames.size() != b->lifetimeNames.size() ||
      a->lifetimeOutlives != b->lifetimeOutlives ||
      a->returnLifetimeIndex != b->returnLifetimeIndex ||
      a->parameterLifetimeIndices != b->parameterLifetimeIndices) return false;
  return true;
}
static bool sameT(const T &a, const T &b) {
  if (a->k != b->k) return false;
  switch (a->k) {
    case INT: return a->bits == b->bits && a->sg == b->sg;
    case STRUCT: case OBJ: case ENUM: return a->name == b->name && (a->k != ENUM || a->payloadEnum == b->payloadEnum);
    case WEAK: return a->name == b->name;
    case PTR: case ARR: case LIST: return true;
    case TUPLE: if (a->ps.size() != b->ps.size()) return false; for (size_t i = 0; i < a->ps.size(); i++) if (!sameT(a->ps[i], b->ps[i])) return false; return true;
    case FUNC: if (!sameT(a->el, b->el) || a->ps.size() != b->ps.size() || !sameFunctionLifetimeShape(a, b)) return false; for (size_t i = 0; i < a->ps.size(); i++) if (!sameT(a->ps[i], b->ps[i]) || a->noescape[i] != b->noescape[i] || a->readonly[i] != b->readonly[i]) return false; return true;
    case DSK: return a->name == b->name;
    default: return true;
  }
}
static bool sameOverloadParamType(const T &a, const T &b) {
  if (!a || !b || a->k != b->k) return false;
  if (a->k == PTR) return a->isVolatile == b->isVolatile && sameOverloadParamType(a->el, b->el);
  if (a->k == ARR || a->k == LIST) return sameOverloadParamType(a->el, b->el);
  return sameT(a, b);
}
static bool sameFunctionValueType(const T &a, const T &b) {
  if (!a || !b || a->k != b->k) return false;
  if (a->k == PTR) return a->isVolatile == b->isVolatile && sameFunctionValueType(a->el, b->el);
  if (a->k == FUNC) {
    if (!sameFunctionValueType(a->el, b->el) || a->ps.size() != b->ps.size() || !sameFunctionLifetimeShape(a, b)) return false;
    for (size_t i = 0; i < a->ps.size(); ++i)
      if (!sameFunctionValueType(a->ps[i], b->ps[i]) || a->noescape[i] != b->noescape[i] || a->readonly[i] != b->readonly[i]) return false;
    return true;
  }
  return sameT(a, b);
}
static bool functionTypeSatisfies(const T &actual, const T &required) {
  if (!actual || !required || actual->k != FUNC || required->k != FUNC ||
      !sameFunctionValueType(actual->el, required->el) || actual->ps.size() != required->ps.size()) return false;
  // A declared callback lifetime contract is a promise about the result and
  // argument provenance. A value assigned to that type must carry the same
  // verified contract; an unannotated function value cannot satisfy it.
  if (!required->lifetimeNames.empty() && !sameFunctionLifetimeShape(actual, required)) return false;
  for (size_t i = 0; i < actual->ps.size(); ++i) {
    if (!sameFunctionValueType(actual->ps[i], required->ps[i])) return false;
    const bool actualNoescape = i < actual->noescape.size() && actual->noescape[i];
    const bool requiredNoescape = i < required->noescape.size() && required->noescape[i];
    const bool actualReadonly = i < actual->readonly.size() && actual->readonly[i];
    const bool requiredReadonly = i < required->readonly.size() && required->readonly[i];
    // A function may provide stronger guarantees than its receiving type asks for,
    // but it may never weaken a required noescape/readonly promise.
    if ((requiredNoescape && !actualNoescape) || (requiredReadonly && !actualReadonly)) return false;
  }
  return true;
}
static std::string fhex(double v) { char b[40]; union { double d; uint64_t u; } x; x.d = v; snprintf(b, 40, "0x%016llX", (unsigned long long)x.u); return b; }

struct Opts { bool overflow = false; bool bounds = true; bool divcheck = true; bool strict = true; bool debug = false; bool lib = false; bool captureWrite = false;
  bool trustStdlib = true;   // --no-trust-stdlib: ตรวจ stdlib เหมือนโค้ดผู้ใช้ (ใช้ audit ว่า stdlib เองปลอดภัยแค่ไหน)
  bool warnUnsafe = false;   // --warn-unsafe: รายงานจุดที่ --safe จะปฏิเสธเป็น warning (ไม่หยุด compile) -- ใช้ย้ายโค้ดเดิมไป --safe ทีละส่วน
  bool safe = false;   // --safe: enforce unsafe boundaries and thread isolation
  bool strictSafe = false; // --strict-safe: additionally reject unverified indirect calls from thread closures
  bool strictMove = false; // --strict-move: enable explicit managed moves and flow-sensitive use-after-move checks
  bool strictOwnership = false; // --strict-ownership: enable checked local borrow bindings
};
struct V { std::string v; T t = T_void; bool owned = false; std::string len; bool smallArith = false; };
struct LV { std::string addr; T ty; bool isVolatile = false; };
struct Var {
  std::string name; T ty; std::string kind, slot, len;
  bool direct = false, indirect = false, isConst = false, isParam = false, isVolatile = false;
  bool isBorrowedAlias = false; // local ref binding aliases an existing storage slot; it owns no cleanup
};
struct Node;
struct Scope { std::map<std::string, Var> vars; struct Cl { std::string name; bool tryLeave; Node *dn = nullptr; }; std::vector<Cl> cl; };
struct LoopCtx { std::string brk, cont; size_t depth; std::string idxSlot; bool isLoop, isPP, up; std::string name; };
struct FieldInfo {
  std::string name; T ty; bool isPublic = true; std::string owner;
  bool isProtected = false, isPrivate = false, isStatic = false, isConst = false;
  std::string sym;
};
struct Cap { std::string name; T ty; };
struct FuncInfo {
  bool isLambda = false; std::vector<Cap> caps; std::string envTy;
  std::string name, module, sym, structName;
  T ret = T_void; std::vector<T> pt; std::vector<bool> pref; std::vector<std::string> pn;
  Node *node = nullptr; bool isMethod = false, isStatic = false, isPrivate = false, isProtected = false, isFinal = false, isConstructor = false, isDestructor = false;
  std::vector<Node *> pdef; std::vector<bool> pnoescape, preadonly; bool variadic = false, generic = false, isExtern = false, cvar = false, exported = false;
  bool isAbstract = false;   // method ของ interface / abstract class: ไม่มี body ไม่ emit
  bool isConst = false; // const-qualified instance method receiver contract
  bool isConsteval = false; // compile-time-only scalar function interpreted by the bounded evaluator
};
struct ConstEvalVariable { int64_t value = 0; bool isConst = false; };
struct ConstEvalFrame { std::string module; std::vector<std::map<std::string, ConstEvalVariable>> scopes; };
struct ConstEvalState { uint64_t steps = 0; std::vector<std::string> callStack; };
struct StructInfo {
  std::string name, module, parent;
  std::string genericOrigin;
  bool isClass = false, isInterface = false, isAbstract = false;
  std::vector<std::string> impls;
  std::vector<FieldInfo> fields, staticFields;
  std::map<std::string, FuncInfo *> methods;
  FuncInfo *destructor = nullptr;
  bool resolved = false, busy = false;
  bool isPublic = true, isFinal = false;
};
struct EnumInfo {
  std::string name, module, genericOrigin;
  std::vector<EnumMember> mem;
  std::vector<std::vector<T>> payloadTypes;
  std::vector<TypeSpec> genericAppliedArgs;
  bool hasPayload = false;
  bool managed = false;              // true when any active variant owns a managed value or boxed aggregate
  size_t maxPayload = 0;
  bool isPublic = true;
};

struct BI { const char *q; char ret; const char *params; const char *sym; };
static const BI BTAB[] = {
  {"string.length", 'i', "S", "fac_str_len"}, {"string.byteLength", 'i', "S", "fac_str_bytelen"},
  {"string.toBytes", 'B', "S", "fac_str_tobytes"}, {"string.fromBytes", 'S', "Y", "fac_str_frombytes"}, {"string.graphemeLength", 'i', "S", "fac_str_grapheme_len"},
  {"string.graphemeSlice", 'S', "Sll", "fac_str_grapheme_slice"},
  {"string.upper", 'S', "S", "fac_str_upper"}, {"string.lower", 'S', "S", "fac_str_lower"},
  {"string.trim", 'S', "S", "fac_str_trim"}, {"string.find", 'i', "SS", "fac_str_find"}, {"string.replace", 'S', "SSS", "fac_str_replace"},
  {"string.split", 'L', "SS", "fac_str_split"}, {"string.join", 'S', "LS", "fac_str_join"}, {"string.contains", 'b', "SS", "fac_str_contains"},
  {"string.startsWith", 'b', "SS", "fac_str_starts"}, {"string.endsWith", 'b', "SS", "fac_str_ends"},
  {"char.isDigit", 'b', "c", "fac_char_isdigit"}, {"char.isAlpha", 'b', "c", "fac_char_isalpha"}, {"char.isSpace", 'b', "c", "fac_char_isspace"},
  {"char.toInt", 'i', "c", "fac_char_toint"}, {"unichar.toInt", 'i', "c", "fac_char_toint"},
  {"path.join", 'S', "SS", "fac_path_join"}, {"path.name", 'S', "S", "fac_path_name"}, {"path.ext", 'S', "S", "fac_path_ext"},
  {"path.parent", 'S', "S", "fac_path_parent"}, {"path.exists", 'b', "S", "fac_path_exists"}, {"path.isDir", 'b', "S", "fac_path_isdir"},
  {"path.list", 'L', "S", "fac_path_list"},
  {"path.changeExtension", 'S', "SS", "fac_path_change_extension"},
  {"path.withName", 'S', "SS", "fac_path_with_name"},
  {"path.isSymlink", 'b', "S", "fac_path_is_symlink"},
  {"path.componentCount", 'i', "S", "fac_path_component_count"},
  {"regex.match", 'b', "SS", "fac_regex_match"}, {"regex.find", 'S', "SS", "fac_regex_find"}, {"regex.findAll", 'L', "SS", "fac_regex_findall"},
  {"regex.replace", 'S', "SSS", "fac_regex_replace"},
  {"thread.start", 'p', "f", "fac_thread_start"}, {"thread.join", 'v', "p", "fac_thread_join"}, {"thread.sleep", 'v', "l", "fac_sleep"},
  {"thread.cancel", 'b', "p", "fac_thread_cancel"}, {"thread.cancelled", 'b', "", "fac_thread_cancelled"},
  {"thread.isDone", 'b', "p", "fac_thread_is_done"}, {"thread.isCancelled", 'b', "p", "fac_thread_is_cancelled"},
  {"mutex.lock", 'v', "M", "fac_mutex_lock"}, {"mutex.unlock", 'v', "M", "fac_mutex_unlock"},
  {"time.year", 'i', "l", "fac_time_year"},
  {"time.month", 'i', "l", "fac_time_month"},
  {"time.day", 'i', "l", "fac_time_day"},
  {"time.hour", 'i', "l", "fac_time_hour"},
  {"time.minute", 'i', "l", "fac_time_minute"},
  {"time.second", 'i', "l", "fac_time_second"},
  {"time.weekday", 'i', "l", "fac_time_weekday"},
  {"time.nowSec", 'l', "", "fac_time_sec"},
  {"time.mono", 'u', "", "fac_time_mono"},
  {"time.format", 'S', "lS", "fac_time_format"},
  {"time.formatUtc", 'S', "lS", "fac_time_formatutc"},
  {"time.iso", 'S', "l", "fac_time_iso"},
  {"time.parse", 'l', "SS", "fac_time_parse"},
  {"time.utcOffset", 'i', "", "fac_time_utcoffset"},
  {"crypto.sha256", 'S', "S", "fac_crypto_sha256"},
  {"crypto.sha512", 'S', "S", "fac_crypto_sha512"},
  {"crypto.sha1", 'S', "S", "fac_crypto_sha1"},
  {"crypto.md5", 'S', "S", "fac_crypto_md5"},
  {"crypto.base64Encode", 'S', "S", "fac_crypto_b64enc"},
  {"crypto.base64Decode", 'S', "S", "fac_crypto_b64dec"},
  {"crypto.hexEncode", 'S', "S", "fac_crypto_hexenc"},
  {"crypto.hexDecode", 'S', "S", "fac_crypto_hexdec"},
  {"crypto.sha256File", 'S', "S", "fac_crypto_sha256file"},
  {"crypto.hmacSha256", 'S', "SS", "fac_crypto_hmac256"},
  {"crypto.hmacSha512", 'S', "SS", "fac_crypto_hmac512"},
  {"crypto.crc32", 'U', "S", "fac_crypto_crc32"},
  {"crypto.randomHex", 'S', "i", "fac_crypto_randhex"},
  {"crypto.randomBytes", 'S', "i", "fac_crypto_randbytes"},
  {"crypto.randomInt", 'l', "ll", "fac_crypto_randint"},
  {"crypto.uuid", 'S', "", "fac_crypto_uuid"},
  {"crypto.constantTimeEq", 'b', "SS", "fac_crypto_consteq"},
  {"graphic.create", 'p', "ii", "fac_gfx_create"},
  {"graphic.open", 'p', "iiS", "fac_gfx_open"},
  {"graphic.free", 'v', "p", "fac_gfx_free"},
  {"graphic.width", 'i', "p", "fac_gfx_width"},
  {"graphic.height", 'i', "p", "fac_gfx_height"},
  {"graphic.rgb", 'U', "iii", "fac_gfx_rgb"},
  {"graphic.clear", 'v', "pi", "fac_gfx_clear"},
  {"graphic.pixel", 'v', "piii", "fac_gfx_pixel"},
  {"graphic.get", 'U', "pii", "fac_gfx_get"},
  {"graphic.line", 'v', "piiiii", "fac_gfx_line"},
  {"graphic.rect", 'v', "piiiii", "fac_gfx_rect"},
  {"graphic.fillRect", 'v', "piiiii", "fac_gfx_fillrect"},
  {"graphic.circle", 'v', "piiii", "fac_gfx_circle"},
  {"graphic.fillCircle", 'v', "piiii", "fac_gfx_fillcircle"},
  {"graphic.fillTriangle", 'v', "piiiiiii", "fac_gfx_filltri"},
  {"graphic.text", 'v', "piiSi", "fac_gfx_text1"},
  {"graphic.text", 'v', "piiSii", "fac_gfx_text"},
  {"graphic.bitmapText", 'v', "piiSii", "fac_gfx_bitmap_text"},
  {"graphic.bitmapText", 'v', "piiSi", "fac_gfx_bitmap_text1"},
  {"graphic.bitmapTextWidth", 'i', "Si", "fac_gfx_bitmap_textwidth"},
  {"graphic.systemTextAvailable", 'b', "", "fac_gfx_system_text_available"},
  {"graphic.save", 'v', "pS", "fac_gfx_save"},
  {"graphic.poll", 'b', "p", "fac_gfx_poll"},
  {"graphic.present", 'v', "p", "fac_gfx_present"},
  {"graphic.key", 'b', "pS", "fac_gfx_key"},
  {"graphic.startTextInput", 'v', "p", "fac_gfx_start_text_input"},
  {"graphic.stopTextInput", 'v', "p", "fac_gfx_stop_text_input"},
  {"graphic.textInput", 'S', "p", "fac_gfx_text_input"},
  {"graphic.clipboardGet", 'S', "p", "fac_gfx_clipboard_get"},
  {"graphic.clipboardSet", 'b', "pS", "fac_gfx_clipboard_set"},
  {"graphic.mouseX", 'i', "p", "fac_gfx_mousex"},
  {"graphic.mouseY", 'i', "p", "fac_gfx_mousey"},
  {"graphic.mouseDown", 'b', "p", "fac_gfx_mousedown"},
  {"graphic.delay", 'v', "l", "fac_sleep"},
  {"json.parse", 'p', "S", "fac_jd_parse"},
  {"json.get", 'p', "pS", "fac_jd_get"},
  {"json.at", 'p', "pl", "fac_json_at"},
  {"json.str", 'S', "p", "fac_jd_str"},
  {"json.int", 'l', "p", "fac_jd_i64"},
  {"json.float", 'd', "p", "fac_jd_f64"},
  {"json.bool", 'b', "p", "fac_jd_bool"},
  {"json.len", 'l', "p", "fac_json_len"},
  {"json.kind", 'S', "p", "fac_json_kind"},
  {"json.has", 'b', "pS", "fac_json_has"},
  {"json.keys", 'L', "p", "fac_json_keys"},
  {"json.free", 'v', "p", "fac_jd_free"},
  {"json.valid", 'b', "S", "fac_json_valid"},
  {"json.pretty", 'S', "S", "fac_json_pretty"},
  {"json.compact", 'S', "S", "fac_json_compact"},
  {"csv.parseLine", 'L', "S", "fac_csv_parseline"},
  {"csv.formatLine", 'S', "L", "fac_csv_formatline"},
  {"file.readLines", 'L', "S", "fac_file_readlines"},
  {"file.readText", 'S', "S", "fac_file_readtext"},
  {"file.writeAll", 'v', "SS", "fac_file_writeall"},
  {"file.append", 'v', "SS", "fac_file_append"},
  {"file.size", 'l', "S", "fac_file_size"},
  {"file.mkdir", 'b', "S", "fac_file_mkdir"},
  {"file.rename", 'b', "SS", "fac_file_rename"},
  {"file.copy", 'b', "SS", "fac_file_copy"},
  {"sys.run", 'i', "S", "fac_sys_run"},
  {"sys.output", 'S', "S", "fac_sys_output"},
  {"sys.cwd", 'S', "", "fac_sys_cwd"},
  {"sys.chdir", 'b', "S", "fac_sys_chdir"},
  {"sys.pid", 'i', "", "fac_sys_pid"},
  {"sys.platform", 'S', "", "fac_sys_platform"},
  {"sys.cpuCount", 'i', "", "fac_sys_cpus"},
  {"sys.hostname", 'S', "", "fac_sys_hostname"},
  {"math.asin", 'd', "d", "asin"},
  {"math.acos", 'd', "d", "acos"},
  {"math.atan", 'd', "d", "atan"},
  {"math.sinh", 'd', "d", "sinh"},
  {"math.cosh", 'd', "d", "cosh"},
  {"math.tanh", 'd', "d", "tanh"},
  {"math.exp", 'd', "d", "exp"},
  {"math.cbrt", 'd', "d", "cbrt"},
  {"math.trunc", 'd', "d", "trunc"},
  {"math.atan2", 'd', "dd", "atan2"},
  {"math.hypot", 'd', "dd", "hypot"},
  {"math.fmod", 'd', "dd", "fmod"},
  {"math.lerp", 'd', "ddd", "fac_lerp"},
  {"math.clamp", 'd', "ddd", "fac_clamp"},
  {"math.sign", 'i', "d", "fac_sign"},
  {"math.isNaN", 'b', "d", "fac_isnan"}, {"math.isFinite", 'b', "d", "fac_isfinite"},
  {"math.degToRad", 'd', "d", "fac_degtorad"}, {"math.radToDeg", 'd', "d", "fac_radtodeg"},
  {"math.smoothstep", 'd', "ddd", "fac_smoothstep"}, {"math.wrap", 'd', "ddd", "fac_wrap"},
  {"random.gauss", 'd', "dd", "fac_rand_gauss"},
  {"random.normal", 'd', "dd", "fac_rand_normal"},
  {"random.triangular", 'd', "ddd", "fac_rand_triangular"},
  {"random.exponential", 'd', "d", "fac_rand_exponential"},
  {"random.poisson", 'u', "d", "fac_rand_poisson"},
  {"random.perlin", 'd', "d", "fac_rand_perlin1"}, {"random.perlin", 'd', "dd", "fac_rand_perlin2"},
  {"random.simplex", 'd', "d", "fac_rand_simplex1"}, {"random.simplex", 'd', "dd", "fac_rand_simplex2"},
  {"random.fbm", 'd', "di", "fac_rand_fbm1"}, {"random.fbm", 'd', "ddi", "fac_rand_fbm2"},
  {"string.repeat", 'S', "Si", "fac_str_repeat"},
  {"string.padLeft", 'S', "Sic", "fac_str_padleft"},
  {"string.padRight", 'S', "Sic", "fac_str_padright"},
  {"string.reverse", 'S', "S", "fac_str_reverse"},
  {"string.count", 'i', "SS", "fac_str_count"},
  {"string.lastFind", 'i', "SS", "fac_str_lastfind"},
  {"string.lines", 'L', "S", "fac_str_lines"},
  {"string.capitalize", 'S', "S", "fac_str_capitalize"},
  {"string.isNumber", 'b', "S", "fac_str_isnumber"},
  {"net.connect", 'p', "Si", "fac_net_connect"},
  {"net.listen", 'p', "i", "fac_net_listen"},
  {"net.accept", 'p', "p", "fac_net_accept"},
  {"net.send", 'i', "pS", "fac_net_send"},
  {"net.sendBytes", 'i', "pY", "fac_net_sendbytes"},
  {"net.recv", 'S', "pi", "fac_net_recv"},
  {"net.recvExact", 'S', "pi", "fac_net_recvexact"},
  {"net.recvExactBytes", 'B', "pi", "fac_net_recvexactbytes"},
  {"net.recvLineStrict", 'S', "p", "fac_net_recvlinestrict"},
  {"net.recvLine", 'S', "p", "fac_net_recvline"},
  {"net.close", 'v', "p", "fac_net_close"},
  {"net.localPort", 'i', "p", "fac_net_localport"},
  {"net.httpGet", 'S', "S", "fac_net_httpget"},
  {"net.httpPost", 'S', "SS", "fac_net_httppost"},
  {"net.get", 'S', "S", "fac_net_httpget"},
  {"net.post", 'S', "SS", "fac_net_httppost"},
  {"net.urlEncode", 'S', "S", "fac_net_urlencode"},
  {"net.urlDecode", 'S', "S", "fac_net_urldecode"},
  {"net.setTimeout", 'v', "pi", "fac_net_settimeout"},
  {"net.recvAll", 'S', "p", "fac_net_recvall"},
  {"net.sendLine", 'i', "pS", "fac_net_sendline"},
  {"tls.available", 'b', "", "fac_tls_available"},
  {"tls.wrapClient", 'p', "pS", "fac_tls_wrapclient"},
  {"tls.wrapServer", 'p', "pSS", "fac_tls_wrapserver"},
  {"tls.sendBytes", 'i', "pY", "fac_tls_sendbytes"},
  {"tls.recvExactBytes", 'B', "pi", "fac_tls_recvexactbytes"},
  {"tls.close", 'v', "p", "fac_tls_close"},
  {"tls.version", 'S', "p", "fac_tls_version"},
  {"tls.cipher", 'S', "p", "fac_tls_cipher"},
  {"terminal.out.flush", 'v', "", "fac_out_flush"},
  {"terminal.in.eof", 'b', "", "fac_in_eof"},
  {"terminal.in.readAll", 'S', "", "fac_in_readall"},
  {"terminal.in.readChar", 'i', "", "fac_in_readchar"},
  {"terminal.clear", 'v', "", "fac_term_clear"},
  {"string.trimLeft", 'S', "S", "fac_str_trimleft"},
  {"string.trimRight", 'S', "S", "fac_str_trimright"},
  {"string.equalsIgnoreCase", 'b', "SS", "fac_str_eqnocase"},
  {"string.chars", 'L', "S", "fac_str_chars"},
  {"string.indexOf", 'i', "SS", "fac_str_find"},
  {"string.compare", 'i', "SS", "fac_str_cmp"},
  {"char.isUpper", 'b', "c", "fac_char_isupper"},
  {"char.isLower", 'b', "c", "fac_char_islower"},
  {"char.isAlnum", 'b', "c", "fac_char_isalnum"},
  {"char.isPunct", 'b', "c", "fac_char_ispunct"},
  {"char.toUpper", 'c', "c", "fac_char_toupper"},
  {"char.toLower", 'c', "c", "fac_char_tolower"},
  {"math.deg", 'd', "d", "fac_deg"},
  {"math.rad", 'd', "d", "fac_rad"},
  {"math.gcd", 'l', "ll", "fac_gcd"},
  {"math.lcm", 'l', "ll", "fac_lcm"},
  {"math.isInf", 'b', "d", "fac_isinf"},
  {"math.mod", 'l', "ll", "fac_pmod"},
  {"memory.zero", 'v', "pl", "fac_memzero"},
  {"file.isFile", 'b', "S", "fac_file_isfile"},
  {"file.modified", 'l', "S", "fac_file_modified"},
  {"file.eof", 'b', "p", "fac_file_eof"},
  {"file.writeLine", 'v', "pS", "fac_file_writeline"},
  {"file.flush", 'v', "p", "fac_file_flush"},
  {"file.remove", 'b', "S", "fac_file_delete"},
  {"sys.setEnv", 'v', "SS", "fac_sys_setenv"},
  {"sys.tempDir", 'S', "", "fac_sys_tempdir"},
  {"path.stem", 'S', "S", "fac_path_stem"},
  {"path.absolute", 'S', "S", "fac_path_absolute"},
  {"path.isFile", 'b', "S", "fac_file_isfile"},
  {"path.isAbsolute", 'b', "S", "fac_path_isabs"},
  {"path.normalize", 'S', "S", "fac_path_normalize"},
  {"regex.groups", 'L', "SS", "fac_regex_groups"},
  {"regex.split", 'L', "SS", "fac_regex_split"},
  {"regex.count", 'i', "SS", "fac_regex_count"},
  {"json.object", 'p', "", "fac_json_object"},
  {"json.array", 'p', "", "fac_json_array"},
  {"json.newStr", 'p', "S", "fac_json_newstr"},
  {"json.newInt", 'p', "l", "fac_json_newint"},
  {"json.newFloat", 'p', "d", "fac_json_newfloat"},
  {"json.newBool", 'p', "i", "fac_json_newbool"},
  {"json.newNull", 'p', "", "fac_json_newnull"},
  {"json.set", 'v', "pSp", "fac_json_set"},
  {"json.push", 'v', "pp", "fac_json_push"},
  {"json.stringify", 'S', "p", "fac_json_stringify"},
  {"json.stringifyPretty", 'S', "p", "fac_json_stringifyp"},
  {"thread.id", 'l', "", "fac_thread_id"},
  {"thread.yield", 'v', "", "fac_thread_yield"},
  {"thread.atomicAdd", 'i', "pi", "fac_atomic_add"},
  {"thread.atomicGet", 'i', "p", "fac_atomic_get"},
  {"thread.atomicSet", 'v', "pi", "fac_atomic_set"},
  {"thread.atomicCas", 'b', "pii", "fac_atomic_cas"},
  // Explicit SeqCst spellings are source-level aliases of the legacy defaults.
  {"thread.atomicAddSeqCst", 'i', "pi", "fac_atomic_add"},
  {"thread.atomicGetSeqCst", 'i', "p", "fac_atomic_get"},
  {"thread.atomicSetSeqCst", 'v', "pi", "fac_atomic_set"},
  {"thread.atomicCasSeqCst", 'b', "pii", "fac_atomic_cas"},
  {"thread.atomicAddRelaxed", 'i', "pi", "fac_atomic_add_relaxed"},
  {"thread.atomicAddAcquire", 'i', "pi", "fac_atomic_add_acquire"},
  {"thread.atomicAddRelease", 'i', "pi", "fac_atomic_add_release"},
  {"thread.atomicAddAcqRel", 'i', "pi", "fac_atomic_add_acqrel"},
  {"thread.atomicGetRelaxed", 'i', "p", "fac_atomic_get_relaxed"},
  {"thread.atomicGetAcquire", 'i', "p", "fac_atomic_get_acquire"},
  {"thread.atomicSetRelaxed", 'v', "pi", "fac_atomic_set_relaxed"},
  {"thread.atomicSetRelease", 'v', "pi", "fac_atomic_set_release"},
  {"thread.atomicCasRelaxed", 'b', "pii", "fac_atomic_cas_relaxed"},
  {"thread.atomicCasAcquire", 'b', "pii", "fac_atomic_cas_acquire"},
  {"thread.atomicCasRelease", 'b', "pii", "fac_atomic_cas_release"},
  {"thread.atomicCasAcqRel", 'b', "pii", "fac_atomic_cas_acqrel"},
  {"thread.parallelFor", 'v', "ig", "fac_parallel_for"},
  {"crypto.pbkdf2", 'S', "SSii", "fac_crypto_pbkdf2"},
  {"csv.field", 'S', "Si", "fac_csv_field"},
  {"graphic.blit", 'v', "ppii", "fac_gfx_blit"},
  {"graphic.blitKey", 'v', "ppiii", "fac_gfx_blitkey"},
  {"graphic.blend", 'v', "piiii", "fac_gfx_blend"},
  {"graphic.blitAlpha", 'v', "ppii", "fac_gfx_blitalpha"},
  {"graphic.blitRegion", 'v', "ppiiiiii", "fac_gfx_blitregion"},
  {"graphic.blitScaled", 'v', "ppiiii", "fac_gfx_blitscaled"},
  {"graphic.blitRegionEx", 'v', "ppiiiiiii", "fac_gfx_blitregionex"},
  {"graphic.hasAlpha", 'b', "p", "fac_gfx_hasalpha"},
  {"graphic.alphaAt", 'i', "pii", "fac_gfx_alphaat"},
  {"graphic.load", 'p', "S", "fac_gfx_load"},
  {"graphic.hsv", 'U', "ddd", "fac_gfx_hsv"},
  {"graphic.textWidth", 'i', "Si", "fac_gfx_textwidth"},
  // Consistent foundational APIs: create/free, query, then operate on handles.
  {"three.camera", 'p', "dddddd", "fac_3d_camera"},
  {"three.free", 'v', "p", "fac_3d_free"},
  {"three.begin", 'v', "pp", "fac_3d_begin"},
  {"three.projectX", 'i', "ppddd", "fac_3d_projectx"},
  {"three.projectY", 'i', "ppddd", "fac_3d_projecty"},
  {"three.projectDepth", 'd', "ppddd", "fac_3d_projectdepth"},
  {"three.point", 'v', "ppdddii", "fac_3d_point"},
  {"three.line", 'v', "ppddddddi", "fac_3d_line"},
  {"three.triangle", 'v', "ppdddddddddi", "fac_3d_triangle"},
  {"three.cube", 'v', "ppddddi", "fac_3d_cube"}, {"three.sphere", 'v', "ppddddi", "fac_3d_sphere"}, {"three.plane", 'v', "ppddddi", "fac_3d_plane"},
  {"three.grid", 'v', "ppddddii", "fac_3d_grid"}, {"three.moveCamera", 'v', "pddd", "fac_3d_move_camera"}, {"three.rotateCamera", 'v', "pdd", "fac_3d_rotate_camera"}, {"three.setFov", 'v', "pd", "fac_3d_set_fov"},
  {"gpu.backend", 'S', "", "fac_gpu_backend"},
  {"gpu.hardware", 'b', "", "fac_gpu_hardware"},
  {"gpu.createBuffer", 'p', "l", "fac_gpu_buffer_create"},
  {"gpu.freeBuffer", 'v', "p", "fac_gpu_buffer_free"},
  {"gpu.bufferSize", 'l', "p", "fac_gpu_buffer_size"},
  {"gpu.writeBuffer", 'b', "plS", "fac_gpu_buffer_write"},
  {"gpu.readBuffer", 'S', "pll", "fac_gpu_buffer_read"},
  {"gpu.copyBuffer", 'b', "plpll", "fac_gpu_buffer_copy"},
  {"gpu.backendCapabilities", 'S', "", "fac_gpu_backend_capabilities"},
  {"gpu.openclStatus", 'S', "", "fac_gpu_opencl_status"},
  {"gpu.addF64", 'b', "pppl", "fac_gpu_add_f64"},
  {"gpu.subF64", 'b', "pppl", "fac_gpu_sub_f64"},
  {"gpu.mulF64", 'b', "pppl", "fac_gpu_mul_f64"},
  {"gpu.scaleF64", 'b', "ppld", "fac_gpu_scale_f64"},
  {"gpu.matmulF64", 'b', "ppplll", "fac_gpu_matmul_f64"},
  {"gpu.writeF64", 'b', "pld", "fac_gpu_write_f64"}, {"gpu.readF64", 'd', "pl", "fac_gpu_read_f64"},
  // Public CPU SIMD bulk API. Handles are gpu buffers; count must be even and
  // each operation is transactional (false leaves destination unchanged).
  {"simd.backend", 'S', "", "fac_simd_backend"},
  {"simd.widthF64", 'i', "", "fac_simd_width_f64"},
  {"simd.nativeF64x2", 'b', "", "fac_simd_native_f64x2"},
  {"simd.addF64x2", 'b', "pppl", "fac_simd_add_f64x2"},
  {"simd.subF64x2", 'b', "pppl", "fac_simd_sub_f64x2"},
  {"simd.mulF64x2", 'b', "pppl", "fac_simd_mul_f64x2"},
  {"simd.divF64x2", 'b', "pppl", "fac_simd_div_f64x2"},
  {"simd.scaleF64x2", 'b', "ppld", "fac_simd_scale_f64x2"},
  {"audio.create", 'p', "iil", "fac_audio_create"},
  {"audio.tone", 'p', "ddid", "fac_audio_tone"},
  {"audio.load", 'p', "S", "fac_audio_load"},
  {"audio.saveWav", 'v', "pS", "fac_audio_savewav"},
  {"audio.play", 'b', "p", "fac_audio_play"},
  {"audio.stop", 'v', "", "fac_audio_stop"},
  {"audio.playLoop", 'b', "p", "fac_audio_playloop"},
  {"audio.volume", 'v', "d", "fac_audio_volume"},
  {"audio.playing", 'i', "", "fac_audio_playing"},
  {"audio.mix", 'v', "ppd", "fac_audio_mix"},
  {"audio.gain", 'v', "pd", "fac_audio_gain"},
  {"audio.free", 'v', "p", "fac_audio_free"},
  {"audio.frames", 'l', "p", "fac_audio_frames"},
  {"audio.rate", 'i', "p", "fac_audio_rate"},
  {"audio.channels", 'i', "p", "fac_audio_channels"},
  {"audio.duration", 'd', "p", "fac_audio_duration"},
  {"audio.available", 'b', "", "fac_audio_available"},
  {"font.create", 'p', "i", "fac_font_create"},
  {"font.load", 'p', "Si", "fac_font_load"},
  {"font.backendAvailable", 'b', "", "fac_font_backend_available"},
  {"font.free", 'v', "p", "fac_font_free"},
  {"font.setScale", 'v', "pi", "fac_font_setscale"},
  {"font.setSize", 'v', "pi", "fac_font_setsize"},
  {"font.size", 'i', "p", "fac_font_size"},
  {"font.family", 'S', "p", "fac_font_family"},
  {"font.isVector", 'b', "p", "fac_font_isvector"},
  {"font.draw", 'v', "ppiiSi", "fac_font_draw"},
  {"font.measure", 'i', "pS", "fac_font_measure"},
  {"font.height", 'i', "p", "fac_font_height"},
  {"keyboard.down", 'b', "pS", "fac_keyboard_down"},
  {"mouse.x", 'i', "p", "fac_mouse_x"},
  {"mouse.y", 'i', "p", "fac_mouse_y"},
  {"mouse.down", 'b', "p", "fac_mouse_down"},
  {"mouse.button", 'b', "pS", "fac_mouse_button"},
  {"math.sqrt", 'd', "d", "sqrt"}, {"math.floor", 'd', "d", "floor"}, {"math.ceil", 'd', "d", "ceil"}, {"math.round", 'd', "d", "round"},
  {"math.sin", 'd', "d", "sin"}, {"math.cos", 'd', "d", "cos"}, {"math.tan", 'd', "d", "tan"}, {"math.log", 'd', "d", "log"},
  {"math.log2", 'd', "d", "log2"}, {"math.log10", 'd', "d", "log10"}, {"math.pow", 'd', "dd", "pow"},
  {"random.seed", 'v', "l", "fac_rand_seed"}, {"random.int", 'n', "ll", "fac_rand_int"}, {"random.float", 'd', "", "fac_rand_f64"},
  {"random.boolean", 'b', "", "fac_rand_bool"},
  {"time.now", 'u', "", "fac_time_now"}, {"time.sleep", 'v', "l", "fac_sleep"},
  {"memory.copy", 'v', "ppl", "fac_memcpy"}, {"memory.set", 'v', "pil", "fac_memset"}, {"memory.compare", 'i', "ppl", "fac_memcmp"},
  {"memory.startTracking", 'v', "", "fac_mem_start_tracking"},
  {"memory.trackedUsed", 'u', "", "fac_mem_used"}, {"memory.trackedPeak", 'u', "", "fac_mem_peak"}, {"memory.trackedBlocks", 'u', "", "fac_mem_blocks"},
  {"memory.trackedReserved", 'u', "", "fac_mem_reserved"}, {"memory.trackedAllocs", 'u', "", "fac_mem_allocs"}, {"memory.trackedReallocs", 'u', "", "fac_mem_reallocs"},
  {"memory.resetPeak", 'v', "", "fac_mem_reset_peak"},
  {"memory.collectCycles", 'u', "", "fac_obj_collect_cycles"}, {"memory.liveObjects", 'u', "", "fac_obj_live_count"},
  {"memory.runtimeStackBytes", 'u', "", "fac_runtime_stack_bytes"}, {"memory.runtimeStackPeakBytes", 'u', "", "fac_runtime_stack_peak_bytes"},
  {"memory.trimThread", 'b', "", "fac_runtime_trim_thread"},
  {"sys.env", 'S', "S", "fac_env"}, {"sys.exit", 'v', "i", "fac_exit"},
  {"file.open", 'p', "SS", "fac_file_open"}, {"file.readline", 'S', "p", "fac_file_readline"}, {"file.readall", 'S', "p", "fac_file_readall"},
  {"file.readLine", 'S', "p", "fac_file_readline"}, {"file.readAll", 'S', "p", "fac_file_readall"},   // V44: canonical lowerCamelCase (old spellings kept)
  {"file.write", 'v', "pS", "fac_file_write"}, {"file.close", 'v', "p", "fac_file_close"}, {"file.exists", 'b', "S", "fac_file_exists"},
  {"file.delete", 'b', "S", "fac_file_delete"},
  {"file.liveHandles", 'u', "", "fac_file_live_handles"},
  // V97: CPU tensor, data analysis, ML, neural-network and optimizer APIs.
  {"tensor.create", 'p', "ii", "fac_tensor_create"}, {"tensor.zeros", 'p', "ii", "fac_tensor_zeros"}, {"tensor.ones", 'p', "ii", "fac_tensor_ones"},
  {"tensor.free", 'v', "p", "fac_tensor_free"}, {"tensor.rows", 'l', "p", "fac_tensor_rows"}, {"tensor.cols", 'l', "p", "fac_tensor_cols"}, {"tensor.size", 'l', "p", "fac_tensor_size"},
  {"tensor.get", 'd', "pii", "fac_tensor_get"}, {"tensor.set", 'v', "piid", "fac_tensor_set"}, {"tensor.fill", 'v', "pd", "fac_tensor_fill"},
  {"tensor.clone", 'p', "p", "fac_tensor_clone"}, {"tensor.reshape", 'v', "pii", "fac_tensor_reshape"}, {"tensor.transpose", 'p', "p", "fac_tensor_transpose"},
  {"tensor.add", 'p', "pp", "fac_tensor_add"}, {"tensor.sub", 'p', "pp", "fac_tensor_sub"}, {"tensor.hadamard", 'p', "pp", "fac_tensor_hadamard"},
  {"tensor.divide", 'p', "pp", "fac_tensor_divide"}, {"tensor.scale", 'p', "pd", "fac_tensor_scale"}, {"tensor.matmul", 'p', "pp", "fac_tensor_matmul"},
  {"tensor.sum", 'd', "p", "fac_tensor_sum"}, {"tensor.mean", 'd', "p", "fac_tensor_mean"}, {"tensor.min", 'd', "p", "fac_tensor_min"},
  {"tensor.max", 'd', "p", "fac_tensor_max"}, {"tensor.std", 'd', "p", "fac_tensor_std"}, {"tensor.argmax", 'l', "p", "fac_tensor_argmax"}, {"tensor.argmin", 'l', "p", "fac_tensor_argmin"},
  {"tensor.row", 'p', "pi", "fac_tensor_row"}, {"tensor.column", 'p', "pi", "fac_tensor_column"}, {"tensor.concatRows", 'p', "pp", "fac_tensor_concat_rows"}, {"tensor.concatCols", 'p', "pp", "fac_tensor_concat_cols"}, {"tensor.dot", 'd', "pp", "fac_tensor_dot"},
  {"tensor.abs", 'p', "p", "fac_tensor_abs"}, {"tensor.exp", 'p', "p", "fac_tensor_exp"}, {"tensor.log", 'p', "p", "fac_tensor_log"}, {"tensor.sqrt", 'p', "p", "fac_tensor_sqrt"}, {"tensor.clip", 'p', "pdd", "fac_tensor_clip"},
  {"tensor.sumAxis", 'p', "pi", "fac_tensor_sum_axis"}, {"tensor.meanAxis", 'p', "pi", "fac_tensor_mean_axis"}, {"tensor.addScalar", 'p', "pd", "fac_tensor_add_scalar"},
  {"data.parseCSV", 'p', "S", "fac_data_parse_csv"}, {"data.loadCSV", 'p', "S", "fac_data_load_csv"}, {"data.saveCSV", 'v', "pS", "fac_data_save_csv"},
  {"data.toCSV", 'S', "p", "fac_data_to_csv"}, {"data.selectRows", 'p', "pii", "fac_data_select_rows"}, {"data.selectColumns", 'p', "pii", "fac_data_select_columns"},
  {"data.shuffleRows", 'v', "pl", "fac_data_shuffle_rows"}, {"data.standardize", 'p', "p", "fac_data_standardize"}, {"data.normalize", 'p', "p", "fac_data_normalize"},
  {"data.dropColumn", 'p', "pi", "fac_data_drop_column"}, {"data.oneHot", 'p', "pi", "fac_data_one_hot"}, {"data.trainTestSplit", 'p', "pdl", "fac_data_train_test_split"},
  {"data.splitTrain", 'p', "p", "fac_data_split_train"}, {"data.splitTest", 'p', "p", "fac_data_split_test"}, {"data.freeSplit", 'v', "p", "fac_data_split_free"},
  {"stats.sum", 'd', "p", "fac_tensor_sum"}, {"stats.mean", 'd', "p", "fac_tensor_mean"}, {"stats.min", 'd', "p", "fac_tensor_min"}, {"stats.max", 'd', "p", "fac_tensor_max"}, {"stats.stddev", 'd', "p", "fac_tensor_std"},
  {"stats.median", 'd', "p", "fac_stats_median"}, {"stats.variance", 'd', "p", "fac_stats_variance"}, {"stats.quantile", 'd', "pd", "fac_stats_quantile"},
  {"stats.covariance", 'd', "pp", "fac_stats_covariance"}, {"stats.correlation", 'd', "pp", "fac_stats_correlation"}, {"stats.describe", 'S', "p", "fac_stats_describe"},
  {"stats.iqr", 'd', "p", "fac_stats_iqr"}, {"stats.mad", 'd', "p", "fac_stats_mad"}, {"stats.skewness", 'd', "p", "fac_stats_skewness"}, {"stats.kurtosis", 'd', "p", "fac_stats_kurtosis"},
  {"metrics.mse", 'd', "pp", "fac_metrics_mse"}, {"metrics.mae", 'd', "pp", "fac_metrics_mae"}, {"metrics.rmse", 'd', "pp", "fac_metrics_rmse"}, {"metrics.r2", 'd', "pp", "fac_metrics_r2"},
  {"metrics.accuracy", 'd', "pp", "fac_metrics_accuracy"}, {"metrics.precision", 'd', "pp", "fac_metrics_precision"}, {"metrics.recall", 'd', "pp", "fac_metrics_recall"},
  {"metrics.f1", 'd', "pp", "fac_metrics_f1"}, {"metrics.confusionMatrix", 'p', "pp", "fac_metrics_confusion"},
  {"metrics.specificity", 'd', "pp", "fac_metrics_specificity"}, {"metrics.balancedAccuracy", 'd', "pp", "fac_metrics_balanced_accuracy"}, {"metrics.mape", 'd', "pp", "fac_metrics_mape"},
  {"metrics.maxError", 'd', "pp", "fac_metrics_max_error"}, {"metrics.medianAbsoluteError", 'd', "pp", "fac_metrics_median_absolute_error"}, {"metrics.logLoss", 'd', "pp", "fac_metrics_log_loss"},
  {"ml.linearFit", 'p', "ppdi", "fac_ml_linear_fit"}, {"ml.linearPredict", 'p', "pp", "fac_ml_linear_predict"}, {"ml.linearWeight", 'd', "pi", "fac_ml_linear_weight"},
  {"ml.linearBias", 'd', "p", "fac_ml_linear_bias"}, {"ml.ridgeFit", 'p', "ppdid", "fac_ml_ridge_fit"}, {"ml.logisticFit", 'p', "ppdi", "fac_ml_logistic_fit"}, {"ml.logisticPredict", 'p', "pp", "fac_ml_linear_predict"},
  {"ml.logisticClassify", 'p', "ppd", "fac_ml_logistic_classify"}, {"ml.freeModel", 'v', "p", "fac_ml_free_model"},
  {"ml.kmeans", 'p', "piil", "fac_ml_kmeans"}, {"ml.kmeansPredict", 'p', "pp", "fac_ml_kmeans_predict"}, {"ml.kmeansCenters", 'p', "p", "fac_ml_kmeans_centers"}, {"ml.freeKMeans", 'v', "p", "fac_ml_free_kmeans"},
  {"ml.knnFit", 'p', "ppi", "fac_ml_knn_fit"}, {"ml.knnPredict", 'p', "pp", "fac_ml_knn_predict"}, {"ml.freeKNN", 'v', "p", "fac_ml_free_knn"},
  {"nn.dense", 'p', "ppp", "fac_nn_dense"}, {"nn.relu", 'p', "p", "fac_nn_relu"}, {"nn.sigmoid", 'p', "p", "fac_nn_sigmoid"},
  {"nn.tanh", 'p', "p", "fac_nn_tanh"}, {"nn.softmax", 'p', "p", "fac_nn_softmax"}, {"nn.dropout", 'p', "pdl", "fac_nn_dropout"},
  {"nn.leakyRelu", 'p', "pd", "fac_nn_leaky_relu"}, {"nn.elu", 'p', "pd", "fac_nn_elu"}, {"nn.gelu", 'p', "p", "fac_nn_gelu"}, {"nn.softplus", 'p', "p", "fac_nn_softplus"},
  {"nn.leakyReluBackward", 'p', "ppd", "fac_nn_leaky_relu_backward"}, {"nn.eluBackward", 'p', "ppd", "fac_nn_elu_backward"}, {"nn.softplusBackward", 'p', "pp", "fac_nn_softplus_backward"},
  {"nn.reluBackward", 'p', "pp", "fac_nn_relu_backward"}, {"nn.sigmoidBackward", 'p', "pp", "fac_nn_sigmoid_backward"}, {"nn.tanhBackward", 'p', "pp", "fac_nn_tanh_backward"}, {"nn.softmaxBackward", 'p', "pp", "fac_nn_softmax_backward"},
  {"nn.denseInputGrad", 'p', "pp", "fac_nn_dense_input_grad"}, {"nn.denseWeightGrad", 'p', "pp", "fac_nn_dense_weight_grad"}, {"nn.denseBiasGrad", 'p', "p", "fac_nn_dense_bias_grad"},
  {"nn.mseLoss", 'd', "pp", "fac_nn_mse_loss"}, {"nn.crossEntropy", 'd', "pp", "fac_nn_cross_entropy"}, {"nn.binaryCrossEntropy", 'd', "pp", "fac_nn_binary_cross_entropy"},
  {"nn.mseGrad", 'p', "pp", "fac_nn_mse_grad"}, {"nn.crossEntropyGrad", 'p', "pp", "fac_nn_cross_entropy_grad"}, {"nn.binaryCrossEntropyGrad", 'p', "pp", "fac_nn_binary_cross_entropy_grad"},
  {"optim.sgdStep", 'v', "ppd", "fac_optim_sgd_step"}, {"optim.adamCreate", 'p', "ii", "fac_optim_adam_create"},
  {"optim.adamStep", 'v', "pppd", "fac_optim_adam_step"}, {"optim.adamFree", 'v', "p", "fac_optim_adam_free"},
  {"optim.momentumCreate", 'p', "ii", "fac_optim_momentum_create"}, {"optim.momentumStep", 'v', "pppdd", "fac_optim_momentum_step"}, {"optim.momentumFree", 'v', "p", "fac_optim_momentum_free"},
  {"optim.rmspropCreate", 'p', "ii", "fac_optim_rmsprop_create"}, {"optim.rmspropStep", 'v', "pppddd", "fac_optim_rmsprop_step"}, {"optim.rmspropFree", 'v', "p", "fac_optim_rmsprop_free"},
  {"optim.clipNorm", 'p', "pd", "fac_optim_clip_norm"}, {"optim.clipValue", 'p', "pdd", "fac_optim_clip_value"},
  // V99: named numeric DataFrames and scalar reverse-mode automatic differentiation.
  {"dataframe.fromTensor", 'p', "pS", "fac_dataframe_from_tensor"}, {"dataframe.fromCSV", 'p', "SS", "fac_dataframe_from_csv"},
  {"dataframe.free", 'v', "p", "fac_dataframe_free"}, {"dataframe.rows", 'l', "p", "fac_dataframe_rows"}, {"dataframe.cols", 'l', "p", "fac_dataframe_cols"},
  {"dataframe.columnIndex", 'i', "pS", "fac_dataframe_column_index"}, {"dataframe.get", 'd', "piS", "fac_dataframe_get"}, {"dataframe.column", 'p', "pS", "fac_dataframe_column"},
  {"dataframe.select", 'p', "pS", "fac_dataframe_select"}, {"dataframe.drop", 'p', "pS", "fac_dataframe_drop"}, {"dataframe.filter", 'p', "pSid", "fac_dataframe_filter"},
  {"dataframe.sort", 'p', "pSi", "fac_dataframe_sort"}, {"dataframe.head", 'p', "pi", "fac_dataframe_head"}, {"dataframe.tail", 'p', "pi", "fac_dataframe_tail"},
  {"dataframe.mean", 'd', "pS", "fac_dataframe_mean"}, {"dataframe.min", 'd', "pS", "fac_dataframe_min"}, {"dataframe.max", 'd', "pS", "fac_dataframe_max"}, {"dataframe.stddev", 'd', "pS", "fac_dataframe_stddev"},
  {"dataframe.toTensor", 'p', "p", "fac_dataframe_to_tensor"}, {"dataframe.toCSV", 'S', "p", "fac_dataframe_to_csv"}, {"dataframe.concatRows", 'p', "pp", "fac_dataframe_concat_rows"},
  {"dataframe.withColumn", 'p', "pSp", "fac_dataframe_with_column"}, {"dataframe.renameColumn", 'p', "pSS", "fac_dataframe_rename_column"},
  {"dataframe.variance", 'd', "pS", "fac_dataframe_variance"}, {"dataframe.median", 'd', "pS", "fac_dataframe_median"}, {"dataframe.quantile", 'd', "pSd", "fac_dataframe_quantile"},
  {"dataframe.groupMean", 'p', "pSS", "fac_dataframe_group_mean"}, {"dataframe.groupSum", 'p', "pSS", "fac_dataframe_group_sum"},
  {"dataframe.groupMin", 'p', "pSS", "fac_dataframe_group_min"}, {"dataframe.groupMax", 'p', "pSS", "fac_dataframe_group_max"}, {"dataframe.groupCount", 'p', "pS", "fac_dataframe_group_count"},
  {"autograd.create", 'p', "", "fac_autograd_create"}, {"autograd.free", 'v', "p", "fac_autograd_free"}, {"autograd.variable", 'i', "pd", "fac_autograd_variable"},
  {"autograd.add", 'i', "pii", "fac_autograd_add"}, {"autograd.sub", 'i', "pii", "fac_autograd_sub"}, {"autograd.mul", 'i', "pii", "fac_autograd_mul"}, {"autograd.div", 'i', "pii", "fac_autograd_div"},
  {"autograd.neg", 'i', "pi", "fac_autograd_neg"}, {"autograd.exp", 'i', "pi", "fac_autograd_exp"}, {"autograd.log", 'i', "pi", "fac_autograd_log"}, {"autograd.tanh", 'i', "pi", "fac_autograd_tanh"},
  {"autograd.sigmoid", 'i', "pi", "fac_autograd_sigmoid"}, {"autograd.relu", 'i', "pi", "fac_autograd_relu"}, {"autograd.softplus", 'i', "pi", "fac_autograd_softplus"}, {"autograd.pow", 'i', "pid", "fac_autograd_pow"},
  {"autograd.value", 'd', "pi", "fac_autograd_value"}, {"autograd.grad", 'd', "pi", "fac_autograd_grad"}, {"autograd.backward", 'v', "pi", "fac_autograd_backward"}, {"autograd.backwardSeed", 'v', "pid", "fac_autograd_backward_seed"}, {"autograd.zeroGrad", 'v', "p", "fac_autograd_zero_grad"},
  {"autograd.tensorCreate", 'p', "", "fac_autograd_tensor_create"}, {"autograd.tensorFree", 'v', "p", "fac_autograd_tensor_free"}, {"autograd.tensorVariable", 'i', "pp", "fac_autograd_tensor_variable"},
  {"autograd.tensorAdd", 'i', "pii", "fac_autograd_tensor_add"}, {"autograd.tensorSub", 'i', "pii", "fac_autograd_tensor_sub"}, {"autograd.tensorHadamard", 'i', "pii", "fac_autograd_tensor_hadamard"}, {"autograd.tensorMatmul", 'i', "pii", "fac_autograd_tensor_matmul"},
  {"autograd.tensorScale", 'i', "pid", "fac_autograd_tensor_scale"}, {"autograd.tensorSum", 'i', "pi", "fac_autograd_tensor_sum"}, {"autograd.tensorMean", 'i', "pi", "fac_autograd_tensor_mean"},
  {"autograd.tensorRelu", 'i', "pi", "fac_autograd_tensor_relu"}, {"autograd.tensorSigmoid", 'i', "pi", "fac_autograd_tensor_sigmoid"}, {"autograd.tensorTanh", 'i', "pi", "fac_autograd_tensor_tanh"},
  {"autograd.tensorValue", 'p', "pi", "fac_autograd_tensor_value"}, {"autograd.tensorGrad", 'p', "pi", "fac_autograd_tensor_grad"}, {"autograd.tensorBackward", 'v', "pi", "fac_autograd_tensor_backward"},
  {"autograd.tensorBackwardSeed", 'v', "pid", "fac_autograd_tensor_backward_seed"}, {"autograd.tensorZeroGrad", 'v', "p", "fac_autograd_tensor_zero_grad"},
  {nullptr, 0, nullptr, nullptr}};

struct DM { const char *ds, *m, *params; char ret; const char *sym; };
// params: K=key/element  E=value  d=double  l=i64  D=DS ตัวเดียวกัน   ret: v b i  E=ค่า(out param)  L=list ของ value  Q=list ของ key  D=DS ใหม่
static const DM DTAB[] = {
  {"hashmap", "set", "KE", 'v', "fac_hm_set"}, {"hashmap", "get", "K", 'E', "fac_hm_get"}, {"hashmap", "getOr", "KE", 'E', "fac_hm_getor"},
  {"hashmap", "has", "K", 'b', "fac_hm_has"}, {"hashmap", "remove", "K", 'v', "fac_hm_remove"}, {"hashmap", "keys", "", 'Q', "fac_hm_keys"},
  {"hashmap", "values", "", 'L', "fac_hm_values"},
  {"hashset", "add", "K", 'v', "fac_hs_add"}, {"hashset", "has", "K", 'b', "fac_hm_has"}, {"hashset", "remove", "K", 'v', "fac_hm_remove"},
  {"hashset", "toList", "", 'Q', "fac_hs_tolist"}, {"hashset", "union", "D", 'D', "fac_hs_union"}, {"hashset", "intersect", "D", 'D', "fac_hs_intersect"},
  {"hashset", "diff", "D", 'D', "fac_hs_diff"},
  {"tree", "add", "K", 'v', "fac_tr_add"}, {"tree", "has", "K", 'b', "fac_tr_has"}, {"tree", "remove", "K", 'v', "fac_tr_remove"},
  {"tree", "min", "", 'E', "fac_tr_min"}, {"tree", "max", "", 'E', "fac_tr_max"}, {"tree", "height", "", 'i', "fac_tr_height"},
  {"tree", "inorder", "", 'L', "fac_tr_inorder"}, {"tree", "preorder", "", 'L', "fac_tr_preorder"}, {"tree", "postorder", "", 'L', "fac_tr_postorder"},
  {"graph", "addNode", "K", 'v', "fac_g_addnode"}, {"graph", "addEdge", "KK", 'v', "fac_g_addedge2"}, {"graph", "addEdge", "KKd", 'v', "fac_g_addedge3"},
  {"graph", "addArc", "KK", 'v', "fac_g_addarc2"}, {"graph", "addArc", "KKd", 'v', "fac_g_addarc3"}, {"graph", "neighbors", "K", 'L', "fac_g_neighbors"},
  {"graph", "hasEdge", "KK", 'b', "fac_g_hasedge"}, {"graph", "removeEdge", "KK", 'v', "fac_g_removeedge"}, {"graph", "removeArc", "KK", 'v', "fac_g_removearc"}, {"graph", "removeNode", "K", 'v', "fac_g_removenode"},
  {"graph", "bfs", "K", 'L', "fac_g_bfs"}, {"graph", "dfs", "K", 'L', "fac_g_dfs"}, {"graph", "shortest", "KK", 'L', "fac_g_shortest"},
  {"linked", "addFirst", "E", 'v', "fac_ll_addfirst"}, {"linked", "addLast", "E", 'v', "fac_ll_addlast"}, {"linked", "add", "E", 'v', "fac_ll_addlast"},
  {"linked", "removeFirst", "", 'v', "fac_ll_removefirst"}, {"linked", "removeLast", "", 'v', "fac_ll_removelast"},
  {"linked", "first", "", 'E', "fac_ll_first"}, {"linked", "last", "", 'E', "fac_ll_last"}, {"linked", "find", "E", 'i', "fac_ll_find"},
  {"linked", "insert", "lE", 'v', "fac_ll_insert"}, {"linked", "remove", "l", 'v', "fac_ll_remove"},
  {"stack", "push", "E", 'v', "fac_st_push"}, {"stack", "add", "E", 'v', "fac_st_push"},
  {"stack", "pop", "", 'O', "fac_st_pop"}, {"stack", "peek", "", 'E', "fac_st_peek"}, {"stack", "top", "", 'E', "fac_st_peek"},
  {"queue", "enqueue", "E", 'v', "fac_q_enqueue"}, {"queue", "add", "E", 'v', "fac_q_enqueue"},
  {"queue", "dequeue", "", 'O', "fac_q_dequeue"}, {"queue", "front", "", 'E', "fac_q_front"}, {"queue", "peek", "", 'E', "fac_q_front"}, {"queue", "back", "", 'E', "fac_q_back"},
  {"heap", "push", "E", 'v', "fac_hp_push"}, {"heap", "add", "E", 'v', "fac_hp_push"},
  {"heap", "pop", "", 'O', "fac_hp_pop"}, {"heap", "peek", "", 'E', "fac_hp_peek"}, {"heap", "min", "", 'E', "fac_hp_peek"},
  {"maxheap", "push", "E", 'v', "fac_hp_push"}, {"maxheap", "add", "E", 'v', "fac_hp_push"},
  {"maxheap", "pop", "", 'O', "fac_hp_pop"}, {"maxheap", "peek", "", 'E', "fac_hp_peek"}, {"maxheap", "max", "", 'E', "fac_hp_peek"},
  {"trie", "insert", "K", 'v', "fac_ti_insert"}, {"trie", "add", "K", 'v', "fac_ti_insert"},
  {"trie", "has", "K", 'b', "fac_ti_has"}, {"trie", "contains", "K", 'b', "fac_ti_has"},
  {"trie", "startsWith", "K", 'b', "fac_ti_prefix"}, {"trie", "remove", "K", 'v', "fac_ti_remove"},
  {"trie", "words", "K", 'L', "fac_ti_words"},
  {"matrix", "get", "ll", 'E', "fac_mx_get"}, {"matrix", "set", "llE", 'v', "fac_mx_set"},
  {"matrix", "fill", "E", 'v', "fac_mx_fill"}, {"matrix", "rows", "", 'i', "fac_mx_rows"}, {"matrix", "cols", "", 'i', "fac_mx_cols"},
  {nullptr, nullptr, nullptr, 0, nullptr}};

static const char *RT_DECLS = R"(%FacStr = type { ptr, i64, i64, i64, i64 }
%FacList = type { ptr, i64, i64, i32, i32, ptr, ptr }
declare void @fac_init(i32, ptr)
declare void @fac_shutdown()
declare void @fac_try_enter(ptr)
declare void @fac_try_leave()
declare void @fac_cleanup_push(ptr, i32, ptr)
declare void @fac_tmp_push(ptr, i32)
declare void @fac_tmp_pop(ptr)
declare void @fac_tmp_push_drop(ptr, ptr)
declare void @fac_cleanup_pop()
declare void @fac_closure_retain(ptr)
declare void @fac_closure_release(ptr)
@fac_recursion_depth = external thread_local global i32, align 4
@fac_recursion_stack_anchor = external thread_local global i64, align 8
declare void @fac_recursion_fail(i32) noreturn cold
declare i32 @llvm.eh.sjlj.setjmp(ptr)
declare ptr @llvm.frameaddress.p0(i32)
declare ptr @llvm.stacksave.p0()
declare void @fac_throw(ptr, i32) noreturn
declare void @fac_throw_owned(ptr, i32) noreturn
declare void @fac_oob(i64, i64) cold noreturn
declare void @fac_div0() cold noreturn
declare void @fac_assert_fail(ptr) cold noreturn
declare ptr @fac_err_msg()
declare i32 @fac_err_code()
declare ptr @fac_alloc(i64)
declare ptr @fac_obj_new(i64, ptr, ptr, ptr, ptr)
declare ptr @fac_vcall(ptr, i64)
declare ptr @fac_obj_vtbl(ptr)
declare void @fac_cast_fail(ptr) cold noreturn
declare void @fac_obj_slot_drop(ptr)
declare void @fac_obj_slot_copy(ptr, ptr)
declare void @fac_obj_retain(ptr)
declare void @fac_obj_release(ptr)
declare ptr @fac_obj_weak(ptr)
declare void @fac_obj_weak_retain(ptr)
declare void @fac_obj_weak_release(ptr)
declare i32 @fac_obj_weak_alive(ptr)
declare ptr @fac_obj_weak_lock(ptr)
declare void @fac_cycle_visit(ptr)
declare i64 @fac_obj_collect_cycles()
declare i64 @fac_obj_live_count()
declare void @fac_set_debug(i32)
declare void @fac_null_deref() cold noreturn
declare void @fac_free(ptr)
declare ptr @fac_realloc(ptr, i64)
declare void @fac_memcpy(ptr, ptr, i64)
declare void @fac_memset(ptr, i32, i64)
declare i32 @fac_memcmp(ptr, ptr, i64)
declare void @fac_mem_start_tracking()
declare i64 @fac_mem_used()
declare i64 @fac_mem_peak()
declare i64 @fac_mem_blocks()
declare i64 @fac_mem_reserved()
declare i64 @fac_mem_allocs()
declare i64 @fac_mem_reallocs()
declare void @fac_mem_reset_peak()
declare i64 @fac_runtime_stack_bytes()
declare i64 @fac_runtime_stack_peak_bytes()
declare i32 @fac_runtime_trim_thread()
declare ptr @fac_str_dup(ptr)
declare void @fac_str_free(ptr)
declare ptr @fac_str_cat(ptr, ptr)
declare ptr @fac_str_cat_many(ptr, i64)
declare i32 @fac_str_eq(ptr, ptr)
declare i32 @fac_str_cmp(ptr, ptr)
declare i32 @fac_str_len(ptr)
declare i32 @fac_str_bytelen(ptr)
declare ptr @fac_str_tobytes(ptr)
declare ptr @fac_str_frombytes(ptr)
declare i32 @fac_str_at(ptr, i64)
declare ptr @fac_str_slice(ptr, i64, i64)
declare i32 @fac_str_grapheme_len(ptr)
declare ptr @fac_str_grapheme_slice(ptr, i64, i64)
declare ptr @fac_str_from_i64(i64)
declare ptr @fac_str_from_u64(i64)
declare ptr @fac_str_from_f64(double)
declare ptr @fac_str_from_f32(float)
declare ptr @fac_str_from_char(i32)
declare ptr @fac_str_from_bool(i32)
declare ptr @fac_str_from_chars(ptr, i64)
declare ptr @fac_str_from_unichars(ptr, i64)
declare ptr @fac_str_upper(ptr)
declare ptr @fac_str_lower(ptr)
declare ptr @fac_str_trim(ptr)
declare i32 @fac_str_find(ptr, ptr)
declare i32 @fac_str_contains(ptr, ptr)
declare i32 @fac_str_starts(ptr, ptr)
declare i32 @fac_str_ends(ptr, ptr)
declare ptr @fac_str_replace(ptr, ptr, ptr)
declare ptr @fac_str_split(ptr, ptr)
declare ptr @fac_str_join(ptr, ptr)
declare i32 @fac_char_isdigit(i32)
declare i32 @fac_char_isalpha(i32)
declare i32 @fac_char_isspace(i32)
declare i32 @fac_char_toint(i32)
declare ptr @fac_list_new(i32, i32)
declare void @fac_list_set_ops(ptr, ptr, ptr)
declare void @fac_list_free(ptr)
declare void @fac_list_grow(ptr)
declare void @fac_list_insert(ptr, i64, ptr)
declare void @fac_list_remove(ptr, i64)
declare void @fac_list_clear(ptr)
declare ptr @fac_list_from(ptr, i64, i32, i32)
declare ptr @fac_list_copy(ptr)
declare ptr @fac_list_slice(ptr, i64, i64)
declare ptr @fac_array_slice(ptr, i64, i64, i64, i32, i32)
declare void @fac_sort(ptr, i64, i32)
declare void @fac_sort_cmp(ptr, i64, i64, ptr, ptr)
declare void @fac_reverse(ptr, i64, i32)
declare void @fac_fill(ptr, i64, i32, ptr)
declare i32 @fac_find(ptr, i64, i32, i32, ptr)
declare void @fac_use(i32)
declare void @fac_print_nl()
declare void @fac_print_i64(i64)
declare void @fac_print_u64(i64)
declare void @fac_print_f64(double)
declare void @fac_print_f32(float)
declare void @fac_print_str(ptr)
declare void @fac_print_char(i32)
declare void @fac_print_bool(i32)
declare void @fac_print_ptr(ptr)
declare void @fac_print_seq(ptr, i64, i32)
declare ptr @fac_readline()
declare i64 @fac_scan_i64()
declare double @fac_scan_f64()
declare ptr @fac_scan_str()
declare i32 @fac_scan_char()
declare i32 @fac_scan_bool()
declare i64 @fac_parse_i64(ptr)
declare double @fac_parse_f64(ptr)
declare i32 @fac_parse_bool(ptr)
declare i64 @fac_ipow(i64, i64)
declare i64 @fac_iabs(i64)
declare void @fac_rand_seed(i64)
declare i64 @fac_rand_int(i64, i64)
declare i64 @fac_rand_uint(i64, i64)
declare double @fac_rand_f64()
declare i32 @fac_rand_bool()
declare double @fac_rand_uniform_f64(double, double)
declare double @fac_rand_triangular(double, double, double)
declare double @fac_rand_exponential(double)
declare i64 @fac_rand_weighted_index(ptr, i64, i64, i32, i32, i32)
declare i64 @fac_rand_markov_index(ptr, i64, i64, i64, i32, i32, i32)
declare i64 @fac_time_now()
declare void @fac_sleep(i64)
declare void @fac_ds_free(ptr)
declare ptr @fac_ds_copy(ptr)
declare i64 @fac_ds_len(ptr)
declare void @fac_ds_clear(ptr)
declare ptr @fac_hm_new(i32, i32, i32, i32)
declare void @fac_hm_set(ptr, ptr, ptr)
declare void @fac_hm_get(ptr, ptr, ptr)
declare void @fac_hm_getor(ptr, ptr, ptr, ptr)
declare i32 @fac_hm_has(ptr, ptr)
declare void @fac_hm_remove(ptr, ptr)
declare ptr @fac_hm_keys(ptr)
declare ptr @fac_hm_values(ptr)
declare ptr @fac_hs_new(i32, i32)
declare void @fac_hs_add(ptr, ptr)
declare ptr @fac_hs_tolist(ptr)
declare ptr @fac_hs_union(ptr, ptr)
declare ptr @fac_hs_intersect(ptr, ptr)
declare ptr @fac_hs_diff(ptr, ptr)
declare ptr @fac_tr_new(i32, i32)
declare void @fac_tr_add(ptr, ptr)
declare i32 @fac_tr_has(ptr, ptr)
declare void @fac_tr_remove(ptr, ptr)
declare void @fac_tr_min(ptr, ptr)
declare void @fac_tr_max(ptr, ptr)
declare i32 @fac_tr_height(ptr)
declare ptr @fac_tr_inorder(ptr)
declare ptr @fac_tr_preorder(ptr)
declare ptr @fac_tr_postorder(ptr)
declare ptr @fac_g_new(i32, i32)
declare void @fac_g_addnode(ptr, ptr)
declare void @fac_g_addedge2(ptr, ptr, ptr)
declare void @fac_g_addedge3(ptr, ptr, ptr, double)
declare void @fac_g_addarc2(ptr, ptr, ptr)
declare void @fac_g_addarc3(ptr, ptr, ptr, double)
declare ptr @fac_g_neighbors(ptr, ptr)
declare i32 @fac_g_hasedge(ptr, ptr, ptr)
declare void @fac_g_removeedge(ptr, ptr, ptr)
declare void @fac_g_removenode(ptr, ptr)
declare ptr @fac_g_bfs(ptr, ptr)
declare ptr @fac_g_dfs(ptr, ptr)
declare ptr @fac_g_shortest(ptr, ptr, ptr)
declare ptr @fac_ll_new(i32, i32)
declare void @fac_ll_addfirst(ptr, ptr)
declare void @fac_ll_addlast(ptr, ptr)
declare void @fac_ll_removefirst(ptr)
declare void @fac_ll_removelast(ptr)
declare void @fac_ll_first(ptr, ptr)
declare void @fac_ll_last(ptr, ptr)
declare i32 @fac_ll_find(ptr, ptr)
declare ptr @fac_ll_ptr(ptr, i64)
declare void @fac_ll_insert(ptr, i64, ptr)
declare void @fac_ll_remove(ptr, i64)
declare ptr @fac_st_new(i32, i32)
declare void @fac_st_push(ptr, ptr)
declare void @fac_st_pop(ptr, ptr)
declare void @fac_st_peek(ptr, ptr)
declare ptr @fac_q_new(i32, i32)
declare void @fac_q_enqueue(ptr, ptr)
declare void @fac_q_dequeue(ptr, ptr)
declare void @fac_q_front(ptr, ptr)
declare void @fac_q_back(ptr, ptr)
declare ptr @fac_hp_new(i32, i32)
declare ptr @fac_mxh_new(i32, i32)
declare void @fac_hp_push(ptr, ptr)
declare void @fac_hp_pop(ptr, ptr)
declare void @fac_hp_peek(ptr, ptr)
declare ptr @fac_ti_new()
declare void @fac_ti_insert(ptr, ptr)
declare i32 @fac_ti_has(ptr, ptr)
declare i32 @fac_ti_prefix(ptr, ptr)
declare void @fac_ti_remove(ptr, ptr)
declare ptr @fac_ti_words(ptr, ptr)
declare ptr @fac_mx_new(i64, i64, i32, i32)
declare ptr @fac_mx_ptr(ptr, i64, i64)
declare void @fac_mx_set(ptr, i64, i64, ptr)
declare void @fac_mx_get(ptr, i64, i64, ptr)
declare void @fac_mx_fill(ptr, ptr)
declare i32 @fac_mx_rows(ptr)
declare i32 @fac_mx_cols(ptr)
declare void @fac_list_reserve(ptr, i64)
declare void @fac_list_shrink(ptr)
declare ptr @fac_path_join(ptr, ptr)
declare ptr @fac_path_name(ptr)
declare ptr @fac_path_ext(ptr)
declare ptr @fac_path_parent(ptr)
declare i32 @fac_path_exists(ptr)
declare i32 @fac_path_isdir(ptr)
declare ptr @fac_path_list(ptr)
declare ptr @fac_path_change_extension(ptr, ptr)
declare ptr @fac_path_with_name(ptr, ptr)
declare i32 @fac_path_is_symlink(ptr)
declare i32 @fac_path_component_count(ptr)
declare i32 @fac_regex_match(ptr, ptr)
declare ptr @fac_regex_find(ptr, ptr)
declare ptr @fac_regex_findall(ptr, ptr)
declare ptr @fac_regex_replace(ptr, ptr, ptr)
declare ptr @fac_thread_start(ptr)
declare void @fac_thread_join(ptr)
declare i32 @fac_thread_cancel(ptr)
declare i32 @fac_thread_cancelled()
declare i32 @fac_thread_is_done(ptr)
declare i32 @fac_thread_is_cancelled(ptr)
declare ptr @fac_mutex_new()
declare void @fac_mutex_lock(ptr)
declare void @fac_mutex_unlock(ptr)
declare ptr @fac_jb_new()
declare void @fac_jb_raw(ptr, ptr)
declare void @fac_jb_str(ptr, ptr)
declare void @fac_jb_i64(ptr, i64)
declare void @fac_jb_u64(ptr, i64)
declare void @fac_jb_f64(ptr, double)
declare void @fac_jb_bool(ptr, i32)
declare void @fac_jb_char(ptr, i32)
declare void @fac_jb_seq(ptr, ptr, i64, i32)
declare void @fac_jb_ds(ptr, ptr)
declare ptr @fac_jb_finish(ptr)
declare ptr @fac_jd_parse(ptr)
declare void @fac_jd_free(ptr)
declare ptr @fac_jd_get(ptr, ptr)
declare ptr @fac_jd_str(ptr)
declare i64 @fac_jd_i64(ptr)
declare double @fac_jd_f64(ptr)
declare i32 @fac_jd_bool(ptr)
declare i32 @fac_jd_enum(ptr, ptr, i32)
declare ptr @fac_jd_list(ptr, i32, i32)
declare i32 @fac_time_year(i64)
declare i32 @fac_time_month(i64)
declare i32 @fac_time_day(i64)
declare i32 @fac_time_hour(i64)
declare i32 @fac_time_minute(i64)
declare i32 @fac_time_second(i64)
declare i32 @fac_time_weekday(i64)
declare i64 @fac_time_sec()
declare i64 @fac_time_mono()
declare ptr @fac_time_format(i64, ptr)
declare ptr @fac_time_formatutc(i64, ptr)
declare ptr @fac_time_iso(i64)
declare i64 @fac_time_parse(ptr, ptr)
declare i32 @fac_time_utcoffset()
declare ptr @fac_crypto_sha256(ptr)
declare ptr @fac_crypto_sha512(ptr)
declare ptr @fac_crypto_sha1(ptr)
declare ptr @fac_crypto_md5(ptr)
declare ptr @fac_crypto_b64enc(ptr)
declare ptr @fac_crypto_b64dec(ptr)
declare ptr @fac_crypto_hexenc(ptr)
declare ptr @fac_crypto_hexdec(ptr)
declare ptr @fac_crypto_sha256file(ptr)
declare ptr @fac_crypto_hmac256(ptr, ptr)
declare ptr @fac_crypto_hmac512(ptr, ptr)
declare i32 @fac_crypto_crc32(ptr)
declare ptr @fac_crypto_randhex(i32)
declare ptr @fac_crypto_randbytes(i32)
declare i64 @fac_crypto_randint(i64, i64)
declare ptr @fac_crypto_uuid()
declare i32 @fac_crypto_consteq(ptr, ptr)
declare ptr @fac_gfx_create(i32, i32)
declare ptr @fac_gfx_open(i32, i32, ptr)
declare void @fac_gfx_free(ptr)
declare i32 @fac_gfx_width(ptr)
declare i32 @fac_gfx_height(ptr)
declare i32 @fac_gfx_rgb(i32, i32, i32)
declare void @fac_gfx_clear(ptr, i32)
declare void @fac_gfx_pixel(ptr, i32, i32, i32)
declare i32 @fac_gfx_get(ptr, i32, i32)
declare void @fac_gfx_line(ptr, i32, i32, i32, i32, i32)
declare void @fac_gfx_rect(ptr, i32, i32, i32, i32, i32)
declare void @fac_gfx_fillrect(ptr, i32, i32, i32, i32, i32)
declare void @fac_gfx_circle(ptr, i32, i32, i32, i32)
declare void @fac_gfx_fillcircle(ptr, i32, i32, i32, i32)
declare void @fac_gfx_filltri(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @fac_gfx_text1(ptr, i32, i32, ptr, i32)
declare void @fac_gfx_text(ptr, i32, i32, ptr, i32, i32)
declare void @fac_gfx_bitmap_text(ptr, i32, i32, ptr, i32, i32)
declare void @fac_gfx_bitmap_text1(ptr, i32, i32, ptr, i32)
declare i32 @fac_gfx_system_text_available()
declare void @fac_gfx_save(ptr, ptr)
declare i32 @fac_gfx_poll(ptr)
declare void @fac_gfx_present(ptr)
declare i32 @fac_gfx_key(ptr, ptr)
declare void @fac_gfx_start_text_input(ptr)
declare void @fac_gfx_stop_text_input(ptr)
declare ptr @fac_gfx_text_input(ptr)
declare ptr @fac_gfx_clipboard_get(ptr)
declare i32 @fac_gfx_clipboard_set(ptr, ptr)
declare i32 @fac_gfx_mousex(ptr)
declare i32 @fac_gfx_mousey(ptr)
declare i32 @fac_gfx_mousedown(ptr)
declare ptr @fac_3d_camera(double, double, double, double, double, double)
declare void @fac_3d_free(ptr)
declare void @fac_3d_begin(ptr, ptr)
declare i32 @fac_3d_projectx(ptr, ptr, double, double, double)
declare i32 @fac_3d_projecty(ptr, ptr, double, double, double)
declare double @fac_3d_projectdepth(ptr, ptr, double, double, double)
declare void @fac_3d_point(ptr, ptr, double, double, double, i32, i32)
declare void @fac_3d_line(ptr, ptr, double, double, double, double, double, double, i32)
declare void @fac_3d_triangle(ptr, ptr, double, double, double, double, double, double, double, double, double, i32)
declare void @fac_3d_cube(ptr, ptr, double, double, double, double, i32)
declare void @fac_3d_sphere(ptr, ptr, double, double, double, double, i32)
declare void @fac_3d_plane(ptr, ptr, double, double, double, double, i32)
declare void @fac_3d_grid(ptr, ptr, double, double, double, double, i32, i32)
declare void @fac_3d_move_camera(ptr, double, double, double)
declare void @fac_3d_rotate_camera(ptr, double, double)
declare void @fac_3d_set_fov(ptr, double)
declare ptr @fac_gpu_backend()
declare i32 @fac_gpu_hardware()
declare ptr @fac_gpu_buffer_create(i64)
declare void @fac_gpu_buffer_free(ptr)
declare i64 @fac_gpu_buffer_size(ptr)
declare i32 @fac_gpu_buffer_write(ptr, i64, ptr)
declare ptr @fac_gpu_buffer_read(ptr, i64, i64)
declare i32 @fac_gpu_buffer_copy(ptr, i64, ptr, i64, i64)
declare ptr @fac_gpu_backend_capabilities()
declare ptr @fac_gpu_opencl_status()
declare i32 @fac_gpu_add_f64(ptr, ptr, ptr, i64)
declare i32 @fac_gpu_sub_f64(ptr, ptr, ptr, i64)
declare i32 @fac_gpu_mul_f64(ptr, ptr, ptr, i64)
declare i32 @fac_gpu_scale_f64(ptr, ptr, i64, double)
declare i32 @fac_gpu_matmul_f64(ptr, ptr, ptr, i64, i64, i64)
declare i32 @fac_gpu_write_f64(ptr, i64, double)
declare double @fac_gpu_read_f64(ptr, i64)
declare ptr @fac_simd_backend()
declare i32 @fac_simd_width_f64()
declare i32 @fac_simd_native_f64x2()
declare i32 @fac_simd_add_f64x2(ptr, ptr, ptr, i64)
declare i32 @fac_simd_sub_f64x2(ptr, ptr, ptr, i64)
declare i32 @fac_simd_mul_f64x2(ptr, ptr, ptr, i64)
declare i32 @fac_simd_div_f64x2(ptr, ptr, ptr, i64)
declare i32 @fac_simd_scale_f64x2(ptr, ptr, i64, double)
declare ptr @fac_audio_create(i32, i32, i64)
declare ptr @fac_audio_tone(double, double, i32, double)
declare ptr @fac_audio_load(ptr)
declare void @fac_audio_savewav(ptr, ptr)
declare i32 @fac_audio_play(ptr)
declare void @fac_audio_stop()
declare i32 @fac_audio_playloop(ptr)
declare void @fac_audio_volume(double)
declare i32 @fac_audio_playing()
declare void @fac_audio_mix(ptr, ptr, double)
declare void @fac_audio_gain(ptr, double)
declare void @fac_audio_free(ptr)
declare i64 @fac_audio_frames(ptr)
declare i32 @fac_audio_rate(ptr)
declare i32 @fac_audio_channels(ptr)
declare double @fac_audio_duration(ptr)
declare i32 @fac_audio_available()
declare ptr @fac_font_create(i32)
declare ptr @fac_font_load(ptr, i32)
declare i32 @fac_font_backend_available()
declare void @fac_font_free(ptr)
declare void @fac_font_setscale(ptr, i32)
declare void @fac_font_setsize(ptr, i32)
declare i32 @fac_font_size(ptr)
declare ptr @fac_font_family(ptr)
declare i32 @fac_font_isvector(ptr)
declare void @fac_font_draw(ptr, ptr, i32, i32, ptr, i32)
declare i32 @fac_font_measure(ptr, ptr)
declare i32 @fac_font_height(ptr)
declare i32 @fac_keyboard_down(ptr, ptr)
declare i32 @fac_mouse_x(ptr)
declare i32 @fac_mouse_y(ptr)
declare i32 @fac_mouse_down(ptr)
declare i32 @fac_mouse_button(ptr, ptr)
declare ptr @fac_json_at(ptr, i64)
declare i64 @fac_json_len(ptr)
declare ptr @fac_json_kind(ptr)
declare i32 @fac_json_has(ptr, ptr)
declare ptr @fac_json_keys(ptr)
declare i32 @fac_json_valid(ptr)
declare ptr @fac_json_pretty(ptr)
declare ptr @fac_json_compact(ptr)
declare ptr @fac_csv_parseline(ptr)
declare ptr @fac_csv_formatline(ptr)
declare ptr @fac_file_readlines(ptr)
declare ptr @fac_file_readtext(ptr)
declare void @fac_file_writeall(ptr, ptr)
declare void @fac_file_append(ptr, ptr)
declare i64 @fac_file_size(ptr)
declare i32 @fac_file_mkdir(ptr)
declare i32 @fac_file_rename(ptr, ptr)
declare i32 @fac_file_copy(ptr, ptr)
declare i32 @fac_sys_run(ptr)
declare ptr @fac_sys_output(ptr)
declare ptr @fac_sys_cwd()
declare i32 @fac_sys_chdir(ptr)
declare i32 @fac_sys_pid()
declare ptr @fac_sys_platform()
declare i32 @fac_sys_cpus()
declare ptr @fac_sys_hostname()
declare double @asin(double)
declare double @acos(double)
declare double @atan(double)
declare double @sinh(double)
declare double @cosh(double)
declare double @tanh(double)
declare double @exp(double)
declare double @cbrt(double)
declare double @trunc(double)
declare double @atan2(double, double)
declare double @hypot(double, double)
declare double @fmod(double, double)
declare double @fac_lerp(double, double, double)
declare double @fac_clamp(double, double, double)
declare i32 @fac_sign(double)
declare i32 @fac_isnan(double)
declare i32 @fac_isfinite(double)
declare double @fac_degtorad(double)
declare double @fac_radtodeg(double)
declare double @fac_smoothstep(double, double, double)
declare double @fac_wrap(double, double, double)
declare double @fac_rand_gauss(double, double)
declare double @fac_rand_normal(double, double)
declare i64 @fac_rand_poisson(double)
declare double @fac_rand_perlin1(double)
declare double @fac_rand_perlin2(double, double)
declare double @fac_rand_simplex1(double)
declare double @fac_rand_simplex2(double, double)
declare double @fac_rand_fbm1(double, i32)
declare double @fac_rand_fbm2(double, double, i32)
declare ptr @fac_str_repeat(ptr, i32)
declare ptr @fac_str_padleft(ptr, i32, i32)
declare ptr @fac_str_padright(ptr, i32, i32)
declare ptr @fac_str_reverse(ptr)
declare i32 @fac_str_count(ptr, ptr)
declare i32 @fac_str_lastfind(ptr, ptr)
declare ptr @fac_str_lines(ptr)
declare ptr @fac_str_capitalize(ptr)
declare i32 @fac_str_isnumber(ptr)
declare ptr @fac_net_connect(ptr, i32)
declare ptr @fac_net_listen(i32)
declare ptr @fac_net_accept(ptr)
declare i32 @fac_net_send(ptr, ptr)
declare i32 @fac_net_sendbytes(ptr, ptr)
declare ptr @fac_net_recv(ptr, i32)
declare ptr @fac_net_recvexact(ptr, i32)
declare ptr @fac_net_recvexactbytes(ptr, i32)
declare ptr @fac_net_recvlinestrict(ptr)
declare ptr @fac_net_recvline(ptr)
declare void @fac_net_close(ptr)
declare i32 @fac_net_localport(ptr)
declare ptr @fac_net_httpget(ptr)
declare ptr @fac_net_httppost(ptr, ptr)
declare ptr @fac_net_urlencode(ptr)
declare ptr @fac_net_urldecode(ptr)
declare void @fac_net_settimeout(ptr, i32)
declare ptr @fac_net_recvall(ptr)
declare i32 @fac_net_sendline(ptr, ptr)
declare i32 @fac_tls_available()
declare ptr @fac_tls_wrapclient(ptr, ptr)
declare ptr @fac_tls_wrapserver(ptr, ptr, ptr)
declare i32 @fac_tls_sendbytes(ptr, ptr)
declare ptr @fac_tls_recvexactbytes(ptr, i32)
declare void @fac_tls_close(ptr)
declare ptr @fac_tls_version(ptr)
declare ptr @fac_tls_cipher(ptr)
declare void @fac_out_flush()
declare i32 @fac_in_eof()
declare ptr @fac_in_readall()
declare i32 @fac_in_readchar()
declare void @fac_term_clear()
declare ptr @fac_str_trimleft(ptr)
declare ptr @fac_str_trimright(ptr)
declare i32 @fac_str_eqnocase(ptr, ptr)
declare ptr @fac_str_chars(ptr)
declare i32 @fac_char_isupper(i32)
declare i32 @fac_char_islower(i32)
declare i32 @fac_char_isalnum(i32)
declare i32 @fac_char_ispunct(i32)
declare i32 @fac_char_toupper(i32)
declare i32 @fac_char_tolower(i32)
declare double @fac_deg(double)
declare double @fac_rad(double)
declare i64 @fac_gcd(i64, i64)
declare i64 @fac_lcm(i64, i64)
declare i32 @fac_isinf(double)
declare i64 @fac_pmod(i64, i64)
declare void @fac_memzero(ptr, i64)
declare i32 @fac_file_isfile(ptr)
declare i64 @fac_file_modified(ptr)
declare i32 @fac_file_eof(ptr)
declare void @fac_file_writeline(ptr, ptr)
declare void @fac_file_flush(ptr)
declare void @fac_sys_setenv(ptr, ptr)
declare ptr @fac_sys_tempdir()
declare ptr @fac_path_stem(ptr)
declare ptr @fac_path_absolute(ptr)
declare i32 @fac_path_isabs(ptr)
declare ptr @fac_path_normalize(ptr)
declare ptr @fac_regex_groups(ptr, ptr)
declare ptr @fac_regex_split(ptr, ptr)
declare i32 @fac_regex_count(ptr, ptr)
declare ptr @fac_json_object()
declare ptr @fac_json_array()
declare ptr @fac_json_newstr(ptr)
declare ptr @fac_json_newint(i64)
declare ptr @fac_json_newfloat(double)
declare ptr @fac_json_newbool(i32)
declare ptr @fac_json_newnull()
declare void @fac_json_set(ptr, ptr, ptr)
declare void @fac_json_push(ptr, ptr)
declare ptr @fac_json_stringify(ptr)
declare ptr @fac_json_stringifyp(ptr)
declare i64 @fac_thread_id()
declare void @fac_thread_yield()
declare i32 @fac_atomic_add(ptr, i32)
declare i32 @fac_atomic_get(ptr)
declare void @fac_atomic_set(ptr, i32)
declare i32 @fac_atomic_cas(ptr, i32, i32)
declare i32 @fac_atomic_add_relaxed(ptr, i32)
declare i32 @fac_atomic_add_acquire(ptr, i32)
declare i32 @fac_atomic_add_release(ptr, i32)
declare i32 @fac_atomic_add_acqrel(ptr, i32)
declare i32 @fac_atomic_get_relaxed(ptr)
declare i32 @fac_atomic_get_acquire(ptr)
declare void @fac_atomic_set_relaxed(ptr, i32)
declare void @fac_atomic_set_release(ptr, i32)
declare i32 @fac_atomic_cas_relaxed(ptr, i32, i32)
declare i32 @fac_atomic_cas_acquire(ptr, i32, i32)
declare i32 @fac_atomic_cas_release(ptr, i32, i32)
declare i32 @fac_atomic_cas_acqrel(ptr, i32, i32)
declare void @fac_parallel_for(i32, ptr)
declare ptr @fac_crypto_pbkdf2(ptr, ptr, i32, i32)
declare ptr @fac_csv_field(ptr, i32)
declare void @fac_gfx_blit(ptr, ptr, i32, i32)
declare void @fac_gfx_blitkey(ptr, ptr, i32, i32, i32)
declare void @fac_gfx_blitalpha(ptr, ptr, i32, i32)
declare void @fac_gfx_blitregion(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @fac_gfx_blitscaled(ptr, ptr, i32, i32, i32, i32)
declare void @fac_gfx_blitregionex(ptr, ptr, i32, i32, i32, i32, i32, i32, i32)
declare i32 @fac_gfx_hasalpha(ptr)
declare i32 @fac_gfx_alphaat(ptr, i32, i32)
declare void @fac_gfx_blend(ptr, i32, i32, i32, i32)
declare ptr @fac_gfx_load(ptr)
declare i32 @fac_gfx_hsv(double, double, double)
declare i32 @fac_gfx_textwidth(ptr, i32)
declare i32 @fac_gfx_bitmap_textwidth(ptr, i32)
declare void @fac_shuffle(ptr, i64, i32)
declare i64 @fac_rand_index(i64)
declare void @fac_overflow() cold noreturn
declare void @fac_g_removearc(ptr, ptr, ptr)
declare void @fac_mat4_identity(ptr)
declare void @fac_mat4_translate(ptr, float, float, float)
declare void @fac_mat4_scale(ptr, float, float, float)
declare void @fac_mat4_rotatex(ptr, float)
declare void @fac_mat4_rotatey(ptr, float)
declare void @fac_mat4_rotatez(ptr, float)
declare void @fac_mat4_perspective(ptr, float, float, float, float)
declare void @fac_mat4_ortho(ptr, float, float, float, float, float, float)
declare void @fac_mat4_lookat(ptr, ptr, ptr, ptr)
declare void @fac_mat4_transpose(ptr, ptr)
declare void @fac_mat4_inverse(ptr, ptr)
declare void @fac_mat4_mul(ptr, ptr, ptr)
declare void @fac_mat4_mulv(ptr, ptr, ptr)
declare void @fac_mat4_mulp(ptr, ptr, ptr)
declare ptr @fac_vec_str(ptr, i32)
declare ptr @fac_mat4_str(ptr)
declare void @fac_print_vec(ptr, i32)
declare void @fac_print_mat4(ptr)
declare ptr @fac_cstr(ptr)
declare ptr @fac_cstr_new(ptr)
declare ptr @fac_args()
declare ptr @fac_env(ptr)
declare void @fac_exit(i32) noreturn
declare ptr @fac_file_open(ptr, ptr)
declare ptr @fac_file_readline(ptr)
declare ptr @fac_file_readall(ptr)
declare void @fac_file_write(ptr, ptr)
declare void @fac_file_close(ptr)
declare i32 @fac_file_exists(ptr)
declare i32 @fac_file_delete(ptr)
declare i64 @fac_file_live_handles()
declare double @sqrt(double)
declare double @floor(double)
declare double @ceil(double)
declare double @round(double)
declare double @sin(double)
declare double @cos(double)
declare double @tan(double)
declare double @log(double)
declare double @log2(double)
declare double @log10(double)
declare double @pow(double, double)
declare double @llvm.pow.f64(double, double)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @fac_tensor_create(i32, i32)
declare ptr @fac_tensor_zeros(i32, i32)
declare ptr @fac_tensor_ones(i32, i32)
declare void @fac_tensor_free(ptr)
declare i64 @fac_tensor_rows(ptr)
declare i64 @fac_tensor_cols(ptr)
declare i64 @fac_tensor_size(ptr)
declare double @fac_tensor_get(ptr, i32, i32)
declare void @fac_tensor_set(ptr, i32, i32, double)
declare void @fac_tensor_fill(ptr, double)
declare ptr @fac_tensor_clone(ptr)
declare void @fac_tensor_reshape(ptr, i32, i32)
declare ptr @fac_tensor_transpose(ptr)
declare ptr @fac_tensor_add(ptr, ptr)
declare ptr @fac_tensor_sub(ptr, ptr)
declare ptr @fac_tensor_hadamard(ptr, ptr)
declare ptr @fac_tensor_divide(ptr, ptr)
declare ptr @fac_tensor_scale(ptr, double)
declare ptr @fac_tensor_matmul(ptr, ptr)
declare double @fac_tensor_sum(ptr)
declare double @fac_tensor_mean(ptr)
declare double @fac_tensor_min(ptr)
declare double @fac_tensor_max(ptr)
declare double @fac_tensor_std(ptr)
declare i64 @fac_tensor_argmax(ptr)
declare i64 @fac_tensor_argmin(ptr)
declare ptr @fac_tensor_row(ptr, i32)
declare ptr @fac_tensor_column(ptr, i32)
declare ptr @fac_tensor_concat_rows(ptr, ptr)
declare ptr @fac_tensor_concat_cols(ptr, ptr)
declare double @fac_tensor_dot(ptr, ptr)
declare ptr @fac_tensor_abs(ptr)
declare ptr @fac_tensor_exp(ptr)
declare ptr @fac_tensor_log(ptr)
declare ptr @fac_tensor_sqrt(ptr)
declare ptr @fac_tensor_clip(ptr, double, double)
declare ptr @fac_tensor_sum_axis(ptr, i32)
declare ptr @fac_tensor_mean_axis(ptr, i32)
declare ptr @fac_tensor_add_scalar(ptr, double)
declare ptr @fac_data_parse_csv(ptr)
declare ptr @fac_data_load_csv(ptr)
declare void @fac_data_save_csv(ptr, ptr)
declare ptr @fac_data_to_csv(ptr)
declare ptr @fac_data_select_rows(ptr, i32, i32)
declare ptr @fac_data_select_columns(ptr, i32, i32)
declare void @fac_data_shuffle_rows(ptr, i64)
declare ptr @fac_data_standardize(ptr)
declare ptr @fac_data_normalize(ptr)
declare ptr @fac_data_drop_column(ptr, i32)
declare ptr @fac_data_one_hot(ptr, i32)
declare ptr @fac_data_train_test_split(ptr, double, i64)
declare ptr @fac_data_split_train(ptr)
declare ptr @fac_data_split_test(ptr)
declare void @fac_data_split_free(ptr)
declare double @fac_stats_median(ptr)
declare double @fac_stats_variance(ptr)
declare double @fac_stats_quantile(ptr, double)
declare double @fac_stats_iqr(ptr)
declare double @fac_stats_mad(ptr)
declare double @fac_stats_skewness(ptr)
declare double @fac_stats_kurtosis(ptr)
declare double @fac_stats_covariance(ptr, ptr)
declare double @fac_stats_correlation(ptr, ptr)
declare ptr @fac_stats_describe(ptr)
declare double @fac_metrics_mse(ptr, ptr)
declare double @fac_metrics_mae(ptr, ptr)
declare double @fac_metrics_rmse(ptr, ptr)
declare double @fac_metrics_r2(ptr, ptr)
declare double @fac_metrics_accuracy(ptr, ptr)
declare double @fac_metrics_precision(ptr, ptr)
declare double @fac_metrics_recall(ptr, ptr)
declare double @fac_metrics_specificity(ptr, ptr)
declare double @fac_metrics_balanced_accuracy(ptr, ptr)
declare double @fac_metrics_mape(ptr, ptr)
declare double @fac_metrics_max_error(ptr, ptr)
declare double @fac_metrics_median_absolute_error(ptr, ptr)
declare double @fac_metrics_log_loss(ptr, ptr)
declare double @fac_metrics_f1(ptr, ptr)
declare ptr @fac_metrics_confusion(ptr, ptr)
declare ptr @fac_ml_linear_fit(ptr, ptr, double, i32)
declare ptr @fac_ml_ridge_fit(ptr, ptr, double, i32, double)
declare ptr @fac_ml_linear_predict(ptr, ptr)
declare double @fac_ml_linear_weight(ptr, i32)
declare double @fac_ml_linear_bias(ptr)
declare ptr @fac_ml_logistic_fit(ptr, ptr, double, i32)
declare ptr @fac_ml_logistic_classify(ptr, ptr, double)
declare void @fac_ml_free_model(ptr)
declare ptr @fac_ml_kmeans(ptr, i32, i32, i64)
declare ptr @fac_ml_kmeans_predict(ptr, ptr)
declare ptr @fac_ml_kmeans_centers(ptr)
declare void @fac_ml_free_kmeans(ptr)
declare ptr @fac_ml_knn_fit(ptr, ptr, i32)
declare ptr @fac_ml_knn_predict(ptr, ptr)
declare void @fac_ml_free_knn(ptr)
declare ptr @fac_nn_dense(ptr, ptr, ptr)
declare ptr @fac_nn_relu(ptr)
declare ptr @fac_nn_sigmoid(ptr)
declare ptr @fac_nn_tanh(ptr)
declare ptr @fac_nn_leaky_relu(ptr, double)
declare ptr @fac_nn_elu(ptr, double)
declare ptr @fac_nn_gelu(ptr)
declare ptr @fac_nn_softplus(ptr)
declare ptr @fac_nn_leaky_relu_backward(ptr, ptr, double)
declare ptr @fac_nn_elu_backward(ptr, ptr, double)
declare ptr @fac_nn_softplus_backward(ptr, ptr)
declare ptr @fac_nn_softmax(ptr)
declare ptr @fac_nn_dropout(ptr, double, i64)
declare ptr @fac_nn_relu_backward(ptr, ptr)
declare ptr @fac_nn_sigmoid_backward(ptr, ptr)
declare ptr @fac_nn_tanh_backward(ptr, ptr)
declare ptr @fac_nn_softmax_backward(ptr, ptr)
declare ptr @fac_nn_dense_input_grad(ptr, ptr)
declare ptr @fac_nn_dense_weight_grad(ptr, ptr)
declare ptr @fac_nn_dense_bias_grad(ptr)
declare ptr @fac_nn_mse_grad(ptr, ptr)
declare ptr @fac_nn_cross_entropy_grad(ptr, ptr)
declare ptr @fac_nn_binary_cross_entropy_grad(ptr, ptr)
declare double @fac_nn_mse_loss(ptr, ptr)
declare double @fac_nn_cross_entropy(ptr, ptr)
declare double @fac_nn_binary_cross_entropy(ptr, ptr)
declare void @fac_optim_sgd_step(ptr, ptr, double)
declare ptr @fac_optim_adam_create(i32, i32)
declare void @fac_optim_adam_step(ptr, ptr, ptr, double)
declare void @fac_optim_adam_free(ptr)
declare ptr @fac_optim_momentum_create(i32, i32)
declare void @fac_optim_momentum_step(ptr, ptr, ptr, double, double)
declare void @fac_optim_momentum_free(ptr)
declare ptr @fac_optim_rmsprop_create(i32, i32)
declare void @fac_optim_rmsprop_step(ptr, ptr, ptr, double, double, double)
declare void @fac_optim_rmsprop_free(ptr)
declare ptr @fac_optim_clip_norm(ptr, double)
declare ptr @fac_optim_clip_value(ptr, double, double)
; V99 DataFrame API
declare ptr @fac_dataframe_from_tensor(ptr, ptr)
declare ptr @fac_dataframe_from_csv(ptr, ptr)
declare void @fac_dataframe_free(ptr)
declare i64 @fac_dataframe_rows(ptr)
declare i64 @fac_dataframe_cols(ptr)
declare i32 @fac_dataframe_column_index(ptr, ptr)
declare double @fac_dataframe_get(ptr, i32, ptr)
declare ptr @fac_dataframe_column(ptr, ptr)
declare ptr @fac_dataframe_select(ptr, ptr)
declare ptr @fac_dataframe_drop(ptr, ptr)
declare ptr @fac_dataframe_filter(ptr, ptr, i32, double)
declare ptr @fac_dataframe_sort(ptr, ptr, i32)
declare ptr @fac_dataframe_head(ptr, i32)
declare ptr @fac_dataframe_tail(ptr, i32)
declare double @fac_dataframe_mean(ptr, ptr)
declare double @fac_dataframe_min(ptr, ptr)
declare double @fac_dataframe_max(ptr, ptr)
declare double @fac_dataframe_stddev(ptr, ptr)
declare ptr @fac_dataframe_to_tensor(ptr)
declare ptr @fac_dataframe_to_csv(ptr)
declare ptr @fac_dataframe_concat_rows(ptr, ptr)
declare ptr @fac_dataframe_with_column(ptr, ptr, ptr)
declare ptr @fac_dataframe_rename_column(ptr, ptr, ptr)
declare double @fac_dataframe_variance(ptr, ptr)
declare double @fac_dataframe_median(ptr, ptr)
declare double @fac_dataframe_quantile(ptr, ptr, double)
declare ptr @fac_dataframe_group_mean(ptr, ptr, ptr)
declare ptr @fac_dataframe_group_sum(ptr, ptr, ptr)
declare ptr @fac_dataframe_group_min(ptr, ptr, ptr)
declare ptr @fac_dataframe_group_max(ptr, ptr, ptr)
declare ptr @fac_dataframe_group_count(ptr, ptr)
; V99 scalar reverse-mode autograd API
declare ptr @fac_autograd_create()
declare void @fac_autograd_free(ptr)
declare i32 @fac_autograd_variable(ptr, double)
declare i32 @fac_autograd_add(ptr, i32, i32)
declare i32 @fac_autograd_sub(ptr, i32, i32)
declare i32 @fac_autograd_mul(ptr, i32, i32)
declare i32 @fac_autograd_div(ptr, i32, i32)
declare i32 @fac_autograd_neg(ptr, i32)
declare i32 @fac_autograd_exp(ptr, i32)
declare i32 @fac_autograd_log(ptr, i32)
declare i32 @fac_autograd_tanh(ptr, i32)
declare i32 @fac_autograd_sigmoid(ptr, i32)
declare i32 @fac_autograd_relu(ptr, i32)
declare i32 @fac_autograd_softplus(ptr, i32)
declare i32 @fac_autograd_pow(ptr, i32, double)
declare double @fac_autograd_value(ptr, i32)
declare double @fac_autograd_grad(ptr, i32)
declare void @fac_autograd_backward(ptr, i32)
declare void @fac_autograd_backward_seed(ptr, i32, double)
declare void @fac_autograd_zero_grad(ptr)
; V100 tensor reverse-mode autograd API
declare ptr @fac_autograd_tensor_create()
declare void @fac_autograd_tensor_free(ptr)
declare i32 @fac_autograd_tensor_variable(ptr, ptr)
declare i32 @fac_autograd_tensor_add(ptr, i32, i32)
declare i32 @fac_autograd_tensor_sub(ptr, i32, i32)
declare i32 @fac_autograd_tensor_hadamard(ptr, i32, i32)
declare i32 @fac_autograd_tensor_matmul(ptr, i32, i32)
declare i32 @fac_autograd_tensor_scale(ptr, i32, double)
declare i32 @fac_autograd_tensor_sum(ptr, i32)
declare i32 @fac_autograd_tensor_mean(ptr, i32)
declare i32 @fac_autograd_tensor_relu(ptr, i32)
declare i32 @fac_autograd_tensor_sigmoid(ptr, i32)
declare i32 @fac_autograd_tensor_tanh(ptr, i32)
declare ptr @fac_autograd_tensor_value(ptr, i32)
declare ptr @fac_autograd_tensor_grad(ptr, i32)
declare void @fac_autograd_tensor_backward(ptr, i32)
declare void @fac_autograd_tensor_backward_seed(ptr, i32, double)
declare void @fac_autograd_tensor_zero_grad(ptr)
!1 = !{!"branch_weights", i32 2000, i32 1}
!2 = !{!"llvm.loop.mustprogress"}
)";

class Gen {
 public:
  Opts opt;
  std::vector<Program *> progs;
  std::map<std::string, StructInfo> structs;
  // Codegen identities for declarations staged through the compiler-internal
  // HIR builder. These declarations are lowered only after the HIR model has
  // passed SemanticModel::validate().
  std::map<fac_hir::SymbolId, std::string> generatedFunctionSymbols;
  std::vector<std::string> generatedStructNames;
  std::string generatedDeclarationIR;
  std::map<std::string, std::string> genericOrigins; // specialized type -> source generic declaration
  std::map<std::string, EnumInfo> enums;
  // Concrete type arguments are resolved at the generic use site; while
  // materializing a specialization, the template's module must not re-check
  // those caller-owned types against its own import list.
  std::set<std::string> genericTypeArgsBeingResolved;
  std::map<std::string, FuncInfo> funcs;  // key: module.name  หรือ Struct::method
  std::set<std::string> userModules, builtinModules;
  std::map<std::string, std::string> aliases;
  std::map<std::string, std::vector<FuncInfo *>> overloads;
  std::deque<FuncInfo> extraFuncs, lambdas;
  std::deque<NP> genericNodeStorage; // owns AST clones emitted for explicit method-level generic specializations
  std::vector<FuncInfo *> allFuncs, exportFuncs;
  std::unordered_map<std::string, FuncInfo *> genCache;
  // Active whole-program type normalizer, reused after generic function value
  // substitution so dependent generic record arguments are materialized late.
  std::function<void(Node *, int)> normalizeGenericNode;
  std::map<std::string, std::set<std::string>> modImports;
  // Import bindings are scoped to the importing source module/file.
  std::map<std::string, std::set<std::string>> modGlobalImports;
  std::map<std::string, std::map<std::string, std::string>> modImportAliases;
  std::map<std::string, std::map<std::string, std::set<std::string>>> modImportJust;
  std::map<std::string, std::map<std::string, std::set<std::string>>> modImportWithout; // owner -> alias -> actual module
  T lamExpect; int nlam = 0, ngen = 0, novl = 0; size_t lamDone = 0;
  std::string curModule, curFile;
  // ---- โหมด --safe: ขอบเขต unsafe (แบบ Rust). ใน unsafe { } / unsafe function ใช้ ptr ดิบได้ ที่อื่น compile error
  int unsafeDepth = 0;
  std::set<std::string> stdlibModules;    // ทุก module ที่โหลดจาก stdlib/ (ไม่ขึ้นกับ --no-trust-stdlib): ใช้ยืนยันว่า "sync" คือ sync.fac ของ stdlib จริง
  std::set<std::string> trustedModules;   // module ของ stdlib (main.cpp เติมให้): ใช้ ptr ดิบภายในได้ แล้วเปิดเป็น API ที่ปลอดภัย
  bool safeEnforced() { return (opt.safe || opt.warnUnsafe) && unsafeDepth == 0 && !trustedModules.count(curModule); }
  std::set<std::string> warned;   // กัน warning ซ้ำ (dry-run ของ compiler ผ่านนิพจน์เดิมหลายรอบ)
  int nwarn = 0;
  // --safe: error ; --warn-unsafe: warning บน stderr (ไม่หยุด compile)
  void reportUnsafe(const std::string &msg, int line) {
    if (opt.safe) err(msg, line);
    int ln = line < 0 ? curLine : line;
    if (warned.insert(curFile + ":" + std::to_string(ln) + ":" + msg).second) { nwarn++; std::cerr << curFile << ":" << ln << ": warning: " << msg << "\n"; }
  }
  void requireUnsafe(const std::string &what, int line) {
    if (!safeEnforced()) return;
    reportUnsafe(what + " เป็นการทำงานที่ไม่ปลอดภัย: ต้องอยู่ใน unsafe { ... } หรือ unsafe function (โหมด --safe จะไม่ผ่าน)", line);
  }
  // ---- ตัวแปร global (ต่อ module): slot เป็น @gvN ; initializer รันใน @fac.init.<module> ก่อน main
  std::map<std::string, std::map<std::string, Var>> globalVars;
  std::map<std::string, bool> globalPublic;        // "module.name" -> public?
  std::map<std::string, int64_t> constGlobals;     // "module.name" -> ค่าคงที่ (ใช้เป็นขนาด array / case)
  bool inGlobalInit = false; std::string initOut;
  std::set<Node *> emittingDefer;

  // ---- per-module output
  std::string body, allocas, globals, loopMd;
  std::map<std::string, int> strPool;
  std::set<std::string> extraDecls;
  int nt = 0, nl = 0, na = 0, nloop = 0, nstr = 0;
  bool term = false;
  std::string curBB = "entry";
  int curLine = 0;
  // ---- per-function
  FuncInfo *cf = nullptr;
  std::vector<Scope> scopes;
  std::vector<LoopCtx> loops;
  std::vector<V> temps;
  Node *curBody = nullptr;

  [[noreturn]] void err(const std::string &m, int line = -1) { throw CompileError(line < 0 ? curLine : line, m); }

  // ================================================================ IR helpers
  std::string tmp() { return "%t" + std::to_string(++nt); }
  std::string lbl(const std::string &b) { return b + std::to_string(++nl); }
  // Append IR fragments directly to the destination buffer. Avoid chained
  // operator+ temporaries on the hottest code-generation path.
  void placeLabel(const std::string &l) { body.append(l).append(":\n"); term = false; curBB = l; }
  void ins(const std::string &s) {
    if (term) placeLabel("dead" + std::to_string(++nl));
    body.append("  ").append(s).push_back('\n');
  }
  void br(const std::string &l) { ins("br label %" + l); term = true; }
  void label(const std::string &l) { if (!term) br(l); placeLabel(l); }
  void cbr(const std::string &c, const std::string &a, const std::string &b, bool unlikely = false) {
    ins("br i1 " + c + ", label %" + a + ", label %" + b + (unlikely ? ", !prof !1" : ""));
    term = true;
  }
  std::string def(const std::string &rhs) { std::string t = tmp(); ins(t + " = " + rhs); return t; }

  // Inline the recursion/stack guard in emitted LLVM IR. The guard still runs
  // for every FAC call (including optimized tail-recursion loops), but the
  // common path no longer pays two external runtime calls per function call.
  void emitRecursionEnter() {
    const std::string markerSlot = "%a" + std::to_string(++na);
    allocas.append("  ").append(markerSlot).append(" = alloca i8, align 1\n");
    const std::string marker = def("ptrtoint ptr " + markerSlot + " to i64");
    const std::string anchor = def("load i64, ptr @fac_recursion_stack_anchor, align 8");
    const std::string anchorEmpty = def("icmp eq i64 " + anchor + ", 0");
    const std::string setAnchor = lbl("rec.set.anchor");
    const std::string checkAnchor = lbl("rec.check.anchor");
    const std::string checkDepth = lbl("rec.check.depth");
    const std::string failStack = lbl("rec.fail.stack");
    const std::string failDepth = lbl("rec.fail.depth");
    const std::string continueLabel = lbl("rec.continue");
    cbr(anchorEmpty, setAnchor, checkAnchor);
    placeLabel(setAnchor);
    ins("store i64 " + marker + ", ptr @fac_recursion_stack_anchor, align 8");
    br(checkDepth);
    placeLabel(checkAnchor);
    const std::string below = def("icmp ult i64 " + marker + ", " + anchor);
    const std::string downDiff = def("sub i64 " + anchor + ", " + marker);
    const std::string upDiff = def("sub i64 " + marker + ", " + anchor);
    const std::string distance = def("select i1 " + below + ", i64 " + downDiff + ", i64 " + upDiff);
#ifdef _WIN32
    const uint64_t stackBudget = 256u * 1024u;
#else
    const uint64_t stackBudget = 2u * 1024u * 1024u;
#endif
    const std::string stackExceeded = def("icmp ugt i64 " + distance + ", " + std::to_string(stackBudget));
    cbr(stackExceeded, failStack, checkDepth, true);
    placeLabel(failStack);
    ins("call void @fac_recursion_fail(i32 1)");
    ins("unreachable"); term = true;
    placeLabel(checkDepth);
    const std::string depth = def("load i32, ptr @fac_recursion_depth, align 4");
    const std::string depthExceeded = def("icmp uge i32 " + depth + ", 4096");
    cbr(depthExceeded, failDepth, continueLabel, true);
    placeLabel(failDepth);
    ins("call void @fac_recursion_fail(i32 2)");
    ins("unreachable"); term = true;
    placeLabel(continueLabel);
    const std::string nextDepth = def("add i32 " + depth + ", 1");
    ins("store i32 " + nextDepth + ", ptr @fac_recursion_depth, align 4");
  }

  void emitRecursionLeave() {
    const std::string depth = def("load i32, ptr @fac_recursion_depth, align 4");
    const std::string previous = def("sub i32 " + depth + ", 1");
    ins("store i32 " + previous + ", ptr @fac_recursion_depth, align 4");
    const std::string isOutermost = def("icmp eq i32 " + previous + ", 0");
    const std::string clearAnchor = lbl("rec.clear.anchor");
    const std::string done = lbl("rec.leave.done");
    cbr(isOutermost, clearAnchor, done);
    placeLabel(clearAnchor);
    ins("store i64 0, ptr @fac_recursion_stack_anchor, align 8");
    br(done);
    placeLabel(done);
  }

  std::string llty(const T &t) {
    switch (t->k) {
      case VOID: return "void"; case INT: return "i" + std::to_string(t->bits); case F32: return "float"; case F64: return "double";
      case BOOL: case CHAR: return "i8"; case UNI: return "i32"; case ENUM: return t->payloadEnum ? "%E." + t->name : "i32";
      case STRUCT: return "%S." + t->name;
      case TUPLE: { std::string s = "{ "; for (size_t i = 0; i < t->ps.size(); i++) s += (i ? ", " : "") + llty(t->ps[i]); return s + " }"; }
      case OBJ: case WEAK: return "ptr";
      case ARR: return t->n >= 0 ? "[" + std::to_string(t->n) + " x " + llty(t->el) + "]" : "ptr";
      default: return "ptr";
    }
  }
  std::string llzero(const T &t) {
    switch (t->k) {
      case VOID: return ""; case F32: case F64: return "0.0"; case STRUCT: case TUPLE: return "zeroinitializer"; case ENUM: return t->payloadEnum ? "zeroinitializer" : "0";
      case STR: case LIST: case DSK: case FUNC: case PTR: case OBJ: case WEAK: case OPAQUE: case ARR: case NULLT: return "null";
      default: return "0";
    }
  }
  // struct that contains itself by value (directly or through other structs) has no finite size: report it instead of recursing forever
  int defaultArgDepth = 0;   // default argument ที่เรียกฟังก์ชันที่ใช้ default ต่อกันเป็นทอด: ถ้าวนเป็นวง (f() ใช้ g() ซึ่งใช้ f()) ต้องรายงาน ไม่ใช่ recurse จน stack overflow
  struct DefaultArgGuard {
    Gen &g; bool on;
    DefaultArgGuard(Gen &gg, bool active, const std::string &fn, int line) : g(gg), on(active) {
      if (on && ++g.defaultArgDepth > 64) { g.defaultArgDepth = 0; g.err("default argument ของ function '" + fn + "' วนเป็นวงกลมหรือซ้อนลึกเกินไป (f() ใช้ default ที่เรียกกลับมาที่ f)", line); }
    }
    ~DefaultArgGuard() { if (on) --g.defaultArgDepth; }
  };
  std::vector<std::string> layoutStack;
  struct LayoutGuard {
    Gen &g;
    LayoutGuard(Gen &gg, const std::string &name) : g(gg) {
      for (auto &n : g.layoutStack) if (n == name) g.err("struct " + name + " มีตัวเองเป็น field แบบ value (ขนาดไม่จำกัด) — ใช้ obj / ptr / list แทนเพื่อทำโครงสร้างที่อ้างอิงตัวเอง", g.curLine);
      g.layoutStack.push_back(name);
    }
    ~LayoutGuard() { g.layoutStack.pop_back(); }
  };
  static constexpr int64_t kMaxObjBytes = int64_t(1) << 40;   // ขนาด array/struct สูงสุดที่ compiler ยอมให้ (กัน N*size ล้นช่วงและ layout เพี้ยน)
  static constexpr int64_t kMaxStackBytes = int64_t(1) << 30; // ตัวแปรบน stack (alloca) ใหญ่กว่านี้ชนแน่นอน
  int64_t sizeOf(const T &t) {
    switch (t->k) {
      case INT: return t->bits / 8; case F32: return 4; case F64: return 8; case BOOL: case CHAR: return 1; case UNI: return 4; case ENUM: return t->payloadEnum ? (int64_t)(8 + 8 * enums.at(t->name).maxPayload) : 4;
      case OBJ: case WEAK: return 8;
      case STRUCT: {
        LayoutGuard lg(*this, t->name);
        StructInfo &s = structInfo(t->name, curLine); int64_t off = 0, al = 1;
        for (auto &f : s.fields) {
          int64_t a = alignOf(f.ty), z = sizeOf(f.ty);
          off = (off + a - 1) / a * a;
          if (__builtin_add_overflow(off, z, &off) || off > kMaxObjBytes) err("struct " + t->name + " ใหญ่เกินไป (เกิน 1 TiB หรือขนาดล้นช่วง)", curLine);
          al = std::max(al, a);
        }
        return (off + al - 1) / al * al;
      }
      case ARR: {
        if (t->n <= 0) return t->n * sizeOf(t->el);
        int64_t z = sizeOf(t->el), total;
        if (__builtin_mul_overflow(t->n, z, &total) || total > kMaxObjBytes) err("array ใหญ่เกินไป (เกิน 1 TiB หรือ N * ขนาด element ล้นช่วง)", curLine);
        return total;
      }
      default: return 8;
    }
  }
  int64_t alignOf(const T &t) {
    if (t->k == OBJ || t->k == WEAK) return 8;
    if (t->k == STRUCT) { LayoutGuard lg(*this, t->name); int64_t al = 1; for (auto &f : structInfo(t->name, curLine).fields) al = std::max(al, alignOf(f.ty)); return al; }
    if (t->k == ARR) return alignOf(t->el);
    return std::min<int64_t>(sizeOf(t), 8);
  }
  int tcode(const T &t) {
    switch (t->k) {
      case INT: switch (t->bits) { case 8: return t->sg ? 1 : 5; case 16: return t->sg ? 2 : 6; case 32: return t->sg ? 3 : 7; default: return t->sg ? 4 : 8; }
      case F32: return 9; case F64: return 10; case BOOL: return 11; case CHAR: return 12; case UNI: return 13; case STR: return 14; case ENUM: return 15;
      default: return 8;
    }
  }
  int ekOf(const T &t) { return t->k == STR ? 1 : 0; }
  void setListOps(const T &el, const std::string &list) {
    if (el->k == OBJ) ins("call void @fac_list_set_ops(ptr " + list + ", ptr @fac_obj_slot_drop, ptr @fac_obj_slot_copy)");
    if (el->k == STRUCT)
      ins("call void @fac_list_set_ops(ptr " + list + ", ptr @drop." + el->name + ", ptr @copy." + el->name + ")");
    else if (el->k == ENUM && el->payloadEnum && needsFree(el))
      ins("call void @fac_list_set_ops(ptr " + list + ", ptr @drop.enum." + el->name + ", ptr @copy.enum." + el->name + ")");
  }

  std::string alloca_(const T &t, int64_t count = -1, int64_t requestedAlign = 0) {
    if (requestedAlign < 0 || requestedAlign > 4096 || (requestedAlign && (requestedAlign & (requestedAlign - 1))))
      err("align(...) ต้องเป็นกำลังสองของ 2 ตั้งแต่ 1 ถึง 4096", curLine);
    if (inGlobalInit) {  // ตอน init global: ที่เก็บทุกอย่างเป็น global จริง (อยู่ตลอดโปรแกรม)
      std::string gn = "@gv" + std::to_string(++na);
      std::string gty = count >= 0 ? "[" + std::to_string(count) + " x " + llty(t) + "]" : llty(t);
      int64_t gal = std::max<int64_t>({alignOf(t), count >= 0 ? 16 : 1, requestedAlign});
      globals += gn + " = internal global " + gty + " zeroinitializer, align " + std::to_string(gal) + "\n";
      return gn;
    }
    {
      int64_t each = sizeOf(t), total;
      if (__builtin_mul_overflow(each, count >= 0 ? count : 1, &total) || total > kMaxStackBytes) err("ตัวแปรใหญ่เกินไปสำหรับ stack (" + std::to_string(each) + " bytes" + (count >= 0 ? " x " + std::to_string(count) : std::string()) + ") ใช้ heap แทน", curLine);
    }
    std::string n = "%a" + std::to_string(++na);
    std::string ty = count >= 0 ? "[" + std::to_string(count) + " x " + llty(t) + "]" : llty(t);
    int64_t al = std::max<int64_t>({alignOf(t), count >= 0 ? 16 : 1, requestedAlign});
    allocas.append("  ").append(n).append(" = alloca ").append(ty).append(", align ")
           .append(std::to_string(al)).push_back('\n');
    return n;
  }
  std::string strLit(const std::string &s) {
    auto it = strPool.find(s);
    int id;
    if (it != strPool.end()) id = it->second;
    else {
      id = ++nstr; strPool[s] = id;
      std::string esc;
      for (unsigned char c : s) { char b[8]; if (c >= 32 && c < 127 && c != '"' && c != '\\') esc += (char)c; else { snprintf(b, 8, "\\%02X", c); esc += b; } }
      int64_t ncp = 0; for (unsigned char c : s) ncp += ((c & 0xC0) != 0x80);
      std::string L = std::to_string(s.size());
      globals += "@str." + std::to_string(id) + ".d = private constant [" + std::to_string(s.size() + 1) + " x i8] c\"" + esc + "\\00\"\n";
      globals += "@str." + std::to_string(id) + " = private constant %FacStr { ptr @str." + std::to_string(id) + ".d, i64 " + L + ", i64 " + L + ", i64 " + std::to_string(ncp) + ", i64 1 }\n";
    }
    return "@str." + std::to_string(id);
  }

  // ================================================================ registry
  StructInfo &structInfo(const std::string &n, int line) {
    auto it = structs.find(n);
    if (it == structs.end()) err("ไม่รู้จัก struct '" + n + "'", line);
    return it->second;
  }
  bool isManaged(const T &t) {
    if (t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == OBJ || t->k == WEAK) return true;
    if (t->k == STRUCT) { for (auto &f : structInfo(t->name, curLine).fields) if (isManaged(f.ty)) return true; }
    if (t->k == ENUM && t->payloadEnum) { auto it = enums.find(t->name); return it != enums.end() && it->second.managed; }
    return false;
  }
  bool containsManagedValue(const T &t) {
    if (t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == OBJ || t->k == WEAK) return true;
    if (t->k == STRUCT) { for (auto &f : structInfo(t->name, curLine).fields) if (containsManagedValue(f.ty)) return true; }
    if (t->k == ENUM && t->payloadEnum) return isManaged(t);
    if (t->k == ARR) return containsManagedValue(t->el);
    if (t->k == TUPLE) { for (const auto &m : t->ps) if (containsManagedValue(m)) return true; }
    return false;
  }
  // child เป็น base ได้ไหม: เหมือนกัน, ลูกหลานของ class base (extends), หรือ implements/extends interface base (ผ่านทุกชั้น).
  // Class-to-class checks follow a single parent chain; avoid allocating a DFS worklist/set for this common type-check path.
  // Interface checks retain the cycle-safe graph traversal because a class/interface may have multiple interface edges.
  bool isSubclass(const std::string &child, const std::string &base) {
    if (child == base) return true;
    const auto baseIt = structs.find(base);
    if (baseIt != structs.end() && baseIt->second.isClass && !baseIt->second.isInterface) {
      std::string cur = child;
      size_t remaining = structs.size() + 1; // defensive bound even if an invalid cycle reaches this helper
      while (!cur.empty() && remaining--) {
        auto it = structs.find(cur);
        if (it == structs.end()) break;
        cur = it->second.parent;
        if (cur == base) return true;
      }
      return false;
    }
    std::set<std::string> seen; std::vector<std::string> work{child};
    while (!work.empty()) {
      std::string cur = work.back(); work.pop_back();
      if (!seen.insert(cur).second) continue;
      auto it = structs.find(cur); if (it == structs.end()) continue;
      if (!it->second.parent.empty()) { if (it->second.parent == base) return true; work.push_back(it->second.parent); }
      for (const auto &i : it->second.impls) { if (i == base) return true; work.push_back(i); }
    }
    return false;
  }
  // selector ของ method = ชื่อ + signature (ชนิดพารามิเตอร์/ref/ชนิดคืนค่า); method ใน class กับใน interface ที่ signature เท่ากันจะได้ selector เดียวกัน
  std::map<std::string, int> selectorIds;
  std::string sigKey(const FuncInfo &f) {
    std::string k = f.name + "(";
    for (size_t i = 0; i < f.pt.size(); i++) k += (i ? "," : "") + tname(f.pt[i]) + (i < f.pref.size() && f.pref[i] ? "&" : "");
    return k + ")" + tname(f.ret) + (f.isConst ? " const" : "");
  }
  int selectorOf(const FuncInfo &f) {
    std::string k = sigKey(f); auto it = selectorIds.find(k);
    if (it != selectorIds.end()) return it->second;
    int id = (int)selectorIds.size() + 1; selectorIds[k] = id; return id;
  }
  std::set<std::string> overriddenKeys;   // "Ancestor::method": มี class ลูกหลานประกาศ method นี้ซ้ำ -> ต้องเรียกแบบ virtual
  bool isPayloadEnum(const T &t) const { return t && t->k == ENUM && t->payloadEnum; }
  const EnumMember *enumMember(const EnumInfo &e, const std::string &name, size_t *index = nullptr) const {
    for (size_t i = 0; i < e.mem.size(); ++i) if (e.mem[i].name == name) { if (index) *index = i; return &e.mem[i]; }
    return nullptr;
  }
  T baseType(const std::string &b, int line) {
    { auto al = aliases.find(b); if (al != aliases.end()) return baseType(al->second, line); }
    std::string simple = b; size_t qdot = simple.rfind('.'); if (qdot != std::string::npos) simple = simple.substr(qdot + 1);
    static const std::map<std::string, T> m = {{"byte", T_byte}, {"short", T_short}, {"int", T_int}, {"long", T_long}, {"ubyte", T_ubyte},
        {"ushort", T_ushort}, {"uint", T_uint}, {"ulong", T_ulong}, {"float", T_float}, {"double", T_double}, {"boolean", T_bool},
        {"char", T_char}, {"unichar", T_uni}, {"string", T_str}, {"void", T_void}};
    auto it = m.find(b); if (it != m.end()) return it->second;
    if (structs.count(simple)) { const StructInfo &si = structs.at(simple); if (!genericTypeArgsBeingResolved.count(simple)) requireTypeAccess(b, simple, si.module, si.isPublic, line); return tStruct(simple); }
    if (enums.count(simple)) { const EnumInfo &ei = enums.at(simple); if (!genericTypeArgsBeingResolved.count(simple)) requireTypeAccess(b, simple, ei.module, ei.isPublic, line); return tEnum(simple, ei.hasPayload); }
    if (b == "file" || b == "thread" || b == "mutex" || b == "graphic" || b == "socket" || b == "json" || b == "jnode" || b == "three" || b == "gpu" || b == "simd" || b == "audio" || b == "font" || b == "keyboard" || b == "mouse" || b == "tensor" || b == "data" || b == "ml" || b == "optim" || b == "dataframe" || b == "autograd") return T_opaque;
    err("ไม่รู้จัก type '" + b + "'", line);
  }
  T resolveType(const TypeSpec &ts, int line) {
    if (ts.cat == "tuple") {
      std::vector<T> ps;
      for (auto &a : ts.sig) {
        T m = resolveType(a, line);
        if (!(isNum(m) || m->k == STR || m->k == PTR || m->k == OPAQUE)) err("tuple รองรับสมาชิกเป็นตัวเลข/boolean/char/enum/string/ptr เท่านั้น (เจอ " + tname(m) + ")", line);
        ps.push_back(m);
      }
      if (ps.size() < 2) err("tuple ต้องมีอย่างน้อย 2 ค่า", line);
      return tTuple(ps);
    }
    if (ts.cat == "func") {
      T r = ts.sigReturnType ? resolveType(*ts.sigReturnType, line)
                             : (ts.base == "void" ? T_void : baseType(ts.base, line));
      std::vector<T> ps; for (auto &a : ts.sig) ps.push_back(resolveType(a, line));
      T functionType = tFunc(r, ps, ts.sigNoescape, ts.sigReadonly);
      functionType->lifetimeNames = ts.sigLifetimeParams;
      functionType->lifetimeOutlives = ts.sigLifetimeOutlives;
      functionType->returnLifetimeIndex = ts.sigReturnType ? ts.sigReturnType->lifetimeParamIndex : -1;
      for (size_t i = 0; i < ts.sig.size() && i < functionType->parameterLifetimeIndices.size(); ++i)
        functionType->parameterLifetimeIndices[i] = ts.sig[i].lifetimeParamIndex;
      return functionType;
    }
    if (ts.cat == "weakobj") {
      std::string simple = ts.base; size_t d = simple.rfind('.'); if (d != std::string::npos) simple = simple.substr(d + 1);
      auto it = structs.find(simple);
      if (it == structs.end() || !it->second.isClass || it->second.isInterface) err("weak obj ต้องใช้ชนิด class ที่รู้จัก (เจอ '" + ts.base + "')", line);
      requireTypeAccess(ts.base, simple, it->second.module, it->second.isPublic, line);
      return tWeak(tObj(simple));
    }
    if (ts.cat == "obj") {
      std::string simple = ts.base; size_t d = simple.rfind('.'); if (d != std::string::npos) simple = simple.substr(d + 1);
      auto it = structs.find(simple);
      if (it == structs.end() || !it->second.isClass) err("obj ต้องใช้ชนิด class ที่รู้จัก (เจอ '" + ts.base + "')", line);
      requireTypeAccess(ts.base, simple, it->second.module, it->second.isPublic, line);
      return tObj(simple);
    }
    if (ts.cat == "list" && ts.elemObj) {   // list dyn obj Name: element เป็นการอ้างอิง object (ถือ 1 reference ต่อ element)
      if (ts.kind != "dyn") err("list ของ obj ต้องประกาศเป็น dyn (list dyn obj " + ts.base + " ชื่อ)", line);
      std::string simple = ts.base; size_t d = simple.rfind('.'); if (d != std::string::npos) simple = simple.substr(d + 1);
      auto it = structs.find(simple);
      if (it == structs.end() || !it->second.isClass) err("list ของ obj ต้องใช้ class หรือ interface ที่รู้จัก (ได้ '" + ts.base + "')", line);
      requireTypeAccess(ts.base, simple, it->second.module, it->second.isPublic, line);
      return tList(tObj(simple));
    }
    T b = baseType(ts.base, line);
    if (ts.isVolatile) { if (!(isNum(b) || b->k == PTR)) err("volatile type qualifier รองรับเฉพาะ scalar/pointer", line); b = qualifyVolatile(b); }
    if (ts.cat == "array") { if (b->k == ENUM && b->payloadEnum) err("array ของ payload enum ยังไม่รองรับ; ใช้ตัวแปรแยกหรือ struct wrapper", line); return tArr(b, -1); }
    if (ts.cat == "list") return tList(b);
    if (ts.cat == "arraylist") { T t = tList(b); t->name = "arraylist"; return t; }
    if (ts.cat == "hashmap") return tDS("hashmap", b, baseType(ts.base2, line));
    if (ts.cat == "hashset" || ts.cat == "tree" || ts.cat == "graph" || ts.cat == "linked" ||
        ts.cat == "stack" || ts.cat == "queue" || ts.cat == "heap" || ts.cat == "maxheap" || ts.cat == "trie" || ts.cat == "matrix")
      return tDS(ts.cat, b, b);
    if (ts.kind == "ptr") return tPtr(b);
    return b;
  }
  T typeFromName(const std::string &n) {  // ชื่อ type แบบพิมพ์ใหญ่ตัวแรก (Int, Double, Person ...) ใช้ใน type()/cast()/parse()/Scanner()
    static const std::map<std::string, T> m = {{"Byte", T_byte}, {"Short", T_short}, {"Int", T_int}, {"Long", T_long}, {"Ubyte", T_ubyte},
        {"Ushort", T_ushort}, {"Uint", T_uint}, {"Ulong", T_ulong}, {"Float", T_float}, {"Double", T_double}, {"Boolean", T_bool},
        {"Char", T_char}, {"Unichar", T_uni}, {"String", T_str}};
    auto it = m.find(n); if (it != m.end()) return it->second;
    if (structs.count(n)) return tStruct(n);
    if (enums.count(n)) return tEnum(n, enums.at(n).hasPayload);
    return nullptr;
  }

  // ================================================================ conversions
  std::string conv(const V &a, const T &to, int line = -1) {
    const T &from = a.t;
    if (sameT(from, to) && from->k != PTR) return a.v;
    if (from->k == OBJ && to->k == OBJ && isSubclass(from->name, to->name)) return a.v;
    if (from->k == WEAK && to->k == WEAK && isSubclass(from->name, to->name)) return a.v;
    if (from->k == NULLT) { if (isPtrish(to) || to->k == ARR) return "null"; err("ใช้ null กับ " + tname(to) + " ไม่ได้", line); }
    if (isIntLike(from) && isIntLike(to)) {
      if (to->k == BOOL && from->k != BOOL) { std::string c = def("icmp ne " + llty(from) + " " + a.v + ", 0"); return def("zext i1 " + c + " to i8"); }
      int fb = bitsOf(from), tb = bitsOf(to);
      if (fb == tb) return a.v;
      if (fb > tb) return def("trunc " + llty(from) + " " + a.v + " to " + llty(to));
      return def(std::string(signedOf(from) ? "sext " : "zext ") + llty(from) + " " + a.v + " to " + llty(to));
    }
    if (isIntLike(from) && isFlt(to)) return def(std::string(signedOf(from) ? "sitofp " : "uitofp ") + llty(from) + " " + a.v + " to " + llty(to));
    if (isFlt(from) && isIntLike(to)) {
      if (to->k == BOOL) { std::string c = def("fcmp une " + llty(from) + " " + a.v + ", 0.0"); return def("zext i1 " + c + " to i8"); }
      std::string intr = std::string("llvm.") + (signedOf(to) ? "fptosi" : "fptoui") + ".sat." + llty(to) + "." + (from->k == F32 ? "f32" : "f64");
      if (!extraDecls.count(intr)) { extraDecls.insert(intr); globals += "declare " + llty(to) + " @" + intr + "(" + llty(from) + ")\n"; }
      return def("call " + llty(to) + " @" + intr + "(" + llty(from) + " " + a.v + ")");
    }
    if (isFlt(from) && isFlt(to)) return def(std::string(from->k == F32 ? "fpext " : "fptrunc ") + llty(from) + " " + a.v + " to " + llty(to));
    if ((from->k == PTR || from->k == OPAQUE || from->k == OBJ || from->k == WEAK ||
         from->k == STR || from->k == LIST || from->k == DSK || from->k == FUNC) &&
        (to->k == PTR || to->k == OPAQUE)) return a.v;
    if (isIntLike(from) && to->k == PTR) {
      std::string w = a.v; if (bitsOf(from) < 64) w = def(std::string(signedOf(from) ? "sext " : "zext ") + llty(from) + " " + a.v + " to i64");
      return def("inttoptr i64 " + w + " to ptr");
    }
    if ((from->k == PTR || from->k == OPAQUE) && isIntLike(to)) {
      std::string w = def("ptrtoint ptr " + a.v + " to i64");
      return bitsOf(to) == 64 ? w : def("trunc i64 " + w + " to " + llty(to));
    }
    if (from->k == ARR && (to->k == PTR || to->k == OPAQUE)) return a.v;
    err("แปลง " + tname(from) + " เป็น " + tname(to) + " ไม่ได้", line);
  }
  V cv(const V &a, const T &to, int line = -1) { V r; r.t = to; r.v = conv(a, to, line); r.len = a.len; return r; }
  std::string condOf(const V &a) {
    if (isIntLike(a.t)) return def("icmp ne " + llty(a.t) + " " + a.v + ", 0");
    if (isFlt(a.t)) return def("fcmp une " + llty(a.t) + " " + a.v + ", 0.0");
    if (isPtrish(a.t)) return def("icmp ne ptr " + a.v + ", null");
    err("ใช้ " + tname(a.t) + " เป็นเงื่อนไขไม่ได้");
  }
  V constInt(int64_t x, const T &t = nullptr) { V r; r.v = std::to_string(x); r.t = t ? t : ((x >= INT32_MIN && x <= INT32_MAX) ? T_int : T_long); return r; }

  // ================================================================ ownership
  bool needsFree(const T &t) { if (t->k == TUPLE) { for (auto &m : t->ps) if (m->k == STR) return true; return false; } return t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == OBJ || t->k == WEAK || (t->k == STRUCT && isManaged(t)) || (t->k == ENUM && t->payloadEnum && isManaged(t)); }
  void freeVal(const T &t, const std::string &v) {  // v = ptr for handles, aggregate address for STRUCT / payload ENUM
    if (t->k == TUPLE) { for (size_t i = 0; i < t->ps.size(); i++) if (t->ps[i]->k == STR) ins("call void @fac_str_free(ptr " + def("extractvalue " + llty(t) + " " + v + ", " + std::to_string(i)) + ")"); }
    else if (t->k == STR) ins("call void @fac_str_free(ptr " + v + ")");
    else if (t->k == LIST) ins("call void @fac_list_free(ptr " + v + ")");
    else if (t->k == DSK) ins("call void @fac_ds_free(ptr " + v + ")");
    else if (t->k == FUNC) ins("call void @fac_closure_release(ptr " + v + ")");
    else if (t->k == OBJ) ins("call void @fac_obj_release(ptr " + v + ")");
    else if (t->k == WEAK) ins("call void @fac_obj_weak_release(ptr " + v + ")");
    else if (t->k == STRUCT) ins("call void @drop." + t->name + "(ptr " + v + ")");
    else if (t->k == ENUM && t->payloadEnum && isManaged(t)) ins("call void @drop.enum." + t->name + "(ptr " + v + ")");
  }
  // ค่า owned ชั่วคราวที่ต้องเรียก destructor จะลงทะเบียนใน runtime temp stack เพื่อให้ throw/longjmp ปล่อยได้
  // รวม managed STRUCT ผ่าน callback; tuple ที่มี string จะปกป้องสมาชิกระหว่างประกอบ/ย้ายค่า
  int tmpKind(const T &t) {
    if (t->k == STR) return 1;
    if (t->k == LIST) return 2;
    if (t->k == DSK) return 3;
    if (t->k == FUNC) return 5;
    if (t->k == OBJ) return 6;
    if (t->k == WEAK) return 9;
    if ((t->k == STRUCT && isManaged(t)) || (t->k == ENUM && t->payloadEnum && isManaged(t))) return 8; // callback-based aggregate cleanup
    return 0;
  }
  void borrow(const V &v) {   // idempotent: เรียกซ้ำกับค่าเดิมไม่ลงทะเบียน/ปล่อยซ้ำ
    if (!(v.owned && needsFree(v.t))) return;
    for (auto &x : temps) if (x.v == v.v) return;
    temps.push_back(v);
    int k = tmpKind(v.t);
    if (k == 8) ins("call void @fac_tmp_push_drop(ptr " + v.v + ", ptr " + (v.t->k == ENUM ? "@drop.enum." : "@drop.") + v.t->name + ")");
    else if (k) ins("call void @fac_tmp_push(ptr " + v.v + ", i32 " + std::to_string(k) + ")");
  }
  void transferTemp(const V &v) { // ownership moves from expression-temp tracking to a local/return aggregate
    if (!v.owned || !tmpKind(v.t)) return;
    for (size_t i = temps.size(); i > 0; i--) if (temps[i - 1].v == v.v) {
      ins("call void @fac_tmp_pop(ptr " + v.v + ")");
      temps.erase(temps.begin() + (long)(i - 1));
      return;
    }
  }
  void flushTemps(size_t from, bool truncate = true) {
    for (size_t i = temps.size(); i > from; i--) { if (tmpKind(temps[i - 1].t)) ins("call void @fac_tmp_pop(ptr " + temps[i - 1].v + ")"); freeVal(temps[i - 1].t, temps[i - 1].v); }
    if (truncate) temps.resize(from);
  }
  V ownV(const V &a) {  // ให้ผลเป็นของที่ผู้เรียกเป็นเจ้าของ (copy ถ้ายังไม่ owned)
    if (a.owned || !needsFree(a.t)) return a;
    V r = a; r.owned = true;
    if (a.t->k == STR) r.v = def("call ptr @fac_str_dup(ptr " + a.v + ")");
    else if (a.t->k == LIST) r.v = def("call ptr @fac_list_copy(ptr " + a.v + ")");
    else if (a.t->k == DSK) r.v = def("call ptr @fac_ds_copy(ptr " + a.v + ")");
    else if (a.t->k == FUNC) { ins("call void @fac_closure_retain(ptr " + a.v + ")"); r.v = def("select i1 true, ptr " + a.v + ", ptr null"); }
    else if (a.t->k == OBJ) { ins("call void @fac_obj_retain(ptr " + a.v + ")"); r.v = def("select i1 true, ptr " + a.v + ", ptr null"); }
    else if (a.t->k == WEAK) { ins("call void @fac_obj_weak_retain(ptr " + a.v + ")"); r.v = def("select i1 true, ptr " + a.v + ", ptr null"); }
    else if (a.t->k == STRUCT) {
      std::string tmpA = alloca_(a.t);
      ins("call void @copy." + a.t->name + "(ptr " + tmpA + ", ptr " + a.v + ")");
      r.v = tmpA;
    } else if (a.t->k == ENUM && a.t->payloadEnum && isManaged(a.t)) {
      std::string tmpA = alloca_(a.t);
      ins("call void @copy.enum." + a.t->name + "(ptr " + tmpA + ", ptr " + a.v + ")");
      r.v = tmpA;
    }
    return r;
  }
  // ---- ตรวจการแปลงชนิดตัวเลขโดยนัย: ห้ามตัดค่าเงียบๆ (ต้องใช้ cast หรือเป็นค่าคงที่ที่พอดีช่วง)
  std::string castName(const T &t) { std::string s = tname(t); if (!s.empty()) s[0] = (char)toupper((unsigned char)s[0]); return s; }
  void checkImplicit(const V &a, const T &to, int line) {
    const T &from = a.t;
    if (to && from && to->k == FUNC && from->k == FUNC && !functionTypeSatisfies(from, to))
      err("function value ไม่ตรงกับ function type (implementation ทำ effect contract อ่อนกว่า หรือชนิดผลลัพธ์/parameter ไม่ตรงกัน)", line);
    if (!opt.strict) return;
    if (!isNum(from) || !isNum(to)) return;
    if (to->k == BOOL || from->k == BOOL || to->k == ENUM || from->k == ENUM) return;
    if (isFlt(from) && !isFlt(to)) err("แปลง " + tname(from) + " เป็น " + tname(to) + " โดยปริยายไม่ได้ (ใช้ cast(" + castName(to) + ", x))", line);
    if (isFlt(from) && isFlt(to)) {
      if (from->k == F64 && to->k == F32 && !isLit(a.v)) err("แปลง double เป็น float โดยปริยายไม่ได้ (ใช้ cast(Float, x))", line);
      return;
    }
    if (isFlt(to)) return;  // จำนวนเต็ม -> ทศนิยม ปลอดภัยพอ
    int fb = bitsOf(from), tb = bitsOf(to); bool fs = signedOf(from), ts = signedOf(to);
    if (isLit(a.v)) {  // ค่าคงที่: ต้องพอดีช่วงของ type ปลายทาง
      long long v = atoll(a.v.c_str());
      bool fits = ts ? (tb >= 64 || (v >= -(1LL << (tb - 1)) && v < (1LL << (tb - 1)))) : (v >= 0 && (tb >= 64 || v < (1LL << tb)));
      if (!fits) err("ค่า " + a.v + " เกินช่วงของ " + tname(to), line);
      return;
    }
    if (a.smallArith && tb < fb && tb <= 16) return;  // byte/short/char: x = x + 1 (คำนวณแบบ C แล้วตัดกลับ)
    if (tb > fb) { if (fs && !ts) err("แปลง " + tname(from) + " (มีเครื่องหมาย) เป็น " + tname(to) + " โดยปริยายไม่ได้ (ใช้ cast(" + castName(to) + ", x))", line); return; }
    if (tb == fb) return;
    err("แปลง " + tname(from) + " เป็น " + tname(to) + " ทำให้ค่าถูกตัด โดยปริยายไม่ได้ (ใช้ cast(" + castName(to) + ", x))", line);
  }
  // เก็บ owned/borrowed value ลง address (ไม่ free ของเก่า)
  void storeRaw(const std::string &addr, const T &t, const V &val, bool strictConv = true, bool isVolatile = false) {
    // Function values carry their complete static signature, including named
    // lifetime/effect shape. Validate it on every storage path (locals,
    // assignments, and aggregate constructor fields), not only funcDecl.
    if (t && t->k == FUNC) checkImplicit(val, t, curLine);
    if (t->k == STRUCT || (t->k == ENUM && t->payloadEnum)) {
      if (t->k == ENUM && (!val.t || val.t->k != ENUM || !val.t->payloadEnum || val.t->name != t->name))
        err("ชนิด payload enum ไม่ตรงกัน: ต้องเป็น " + tname(t), curLine);
      V o = ownV(val);
      std::string x = def("load " + llty(t) + ", ptr " + o.v);
      ins("store " + llty(t) + " " + x + ", ptr " + addr);
      transferTemp(o);
    } else if (t->k == STR || t->k == LIST || t->k == DSK || t->k == FUNC || t->k == OBJ || t->k == WEAK) {
      V o = ownV(val);
      ins("store ptr " + o.v + ", ptr " + addr);
      transferTemp(o);
    } else { if (strictConv) checkImplicit(val, t, curLine); ins(std::string("store ") + ((isVolatile || t->isVolatile) ? "volatile " : "") + llty(t) + " " + conv(val, t) + ", ptr " + addr); }
  }
  void storeAssign(const std::string &addr, const T &t, const V &val, bool freeOld, bool isVolatile = false) {
    // Managed function values take the ownership-copy path below, so validate
    // their declared signature here as well as in storeRaw. This keeps field
    // reassignment from bypassing lifetime/effect compatibility checks.
    if (t && t->k == FUNC) checkImplicit(val, t, curLine);
    if (needsFree(t) && freeOld) {
      V o = ownV(val);  // ทำสำเนาก่อน (กัน a = a) แล้วค่อยคืนของเก่า
      if (t->k == STRUCT || (t->k == ENUM && t->payloadEnum)) {
        freeVal(t, addr); std::string x = def("load " + llty(t) + ", ptr " + o.v); ins("store " + llty(t) + " " + x + ", ptr " + addr); transferTemp(o);
      } else { std::string old = def("load ptr, ptr " + addr); freeVal(t, old); ins("store ptr " + o.v + ", ptr " + addr); transferTemp(o); }
    } else storeRaw(addr, t, val, true, isVolatile);
  }

  // ================================================================ scopes
  void pushScope() { scopes.emplace_back(); }
  void cleanupVar(Var &v) {
    if (v.ty->k == STR || v.ty->k == LIST || v.ty->k == DSK) { std::string x = def("load ptr, ptr " + v.slot); freeVal(v.ty, x); }
    else if (v.ty->k == STRUCT || (v.ty->k == ENUM && v.ty->payloadEnum)) freeVal(v.ty, v.slot);
    else if (v.ty->k == FUNC || v.ty->k == OBJ || v.ty->k == WEAK) { std::string a = varAddr(v); std::string x = def("load ptr, ptr " + a); freeVal(v.ty, x); }
    if (needsFree(v.ty)) ins("call void @fac_cleanup_pop()");
  }
  void emitScopeCleanup(size_t si, Var *skip) {
    for (size_t i = scopes[si].cl.size(); i > 0; i--) {
      Scope::Cl c = scopes[si].cl[i - 1];
      if (c.tryLeave) { ins("call void @fac_try_leave()"); continue; }
      if (c.dn) {  // defer/finally: รันคำสั่งที่เลื่อนไว้ (แยก temps ออกไม่ให้ free ซ้ำ)
        if (emittingDefer.count(c.dn)) continue;  // กัน return ใน finally เรียกตัวเองซ้ำไม่รู้จบ
        emittingDefer.insert(c.dn);
        std::vector<V> saved; saved.swap(temps);
        stmt(c.dn);
        temps.swap(saved);
        emittingDefer.erase(c.dn);
        continue;
      }
      Var &v = scopes[si].vars[c.name];
      if (&v == skip) { if (needsFree(v.ty)) ins("call void @fac_cleanup_pop()"); continue; }
      cleanupVar(v);
    }
  }
  void cleanupAll(size_t from, Var *skip) { for (size_t i = scopes.size(); i > from; i--) emitScopeCleanup(i - 1, skip); }
  void popScope() { if (!term) emitScopeCleanup(scopes.size() - 1, nullptr); scopes.pop_back(); }
  Var *findLocal(const std::string &n) {
    for (size_t i = scopes.size(); i > 0; i--) { auto it = scopes[i - 1].vars.find(n); if (it != scopes[i - 1].vars.end()) return &it->second; }
    return nullptr;
  }
  Var *findVar(const std::string &n) {
    if (Var *l = findLocal(n)) return l;
    auto m = globalVars.find(curModule);
    if (m != globalVars.end()) { auto it = m->second.find(n); if (it != m->second.end()) return &it->second; }
    return nullptr;
  }
  FieldInfo *qualifiedStaticField(Node *n, int line) {
    if (!n || n->k != NK::Member) return nullptr;
    std::string path;
    if (!flatten(n, path)) return nullptr;
    path = canonicalModulePath(path);
    std::vector<std::string> parts; std::string part;
    for (char ch : path) { if (ch == '.') { if (!part.empty()) parts.push_back(part); part.clear(); } else part += ch; }
    if (!part.empty()) parts.push_back(part);
    std::string className, fieldName, provider, rawTypePath;
    if (parts.size() == 2) {
      className = parts[0]; fieldName = parts[1];
      auto it = structs.find(className); if (it == structs.end()) return nullptr;
      provider = it->second.module; rawTypePath = className;
    } else if (parts.size() == 3 && userModules.count(parts[0])) {
      provider = parts[0]; className = parts[1]; fieldName = parts[2]; rawTypePath = parts[0] + "." + parts[1];
      auto it = structs.find(className);
      if (it == structs.end() || it->second.module != provider) return nullptr;
    } else return nullptr;
    StructInfo &si = structs[className];
    if (!si.isClass || si.isInterface || si.module != provider) return nullptr;
    auto it = std::find_if(si.staticFields.begin(), si.staticFields.end(), [&](const FieldInfo &f) { return f.name == fieldName; });
    if (it == si.staticFields.end()) return nullptr;
    if (provider != curModule) requireTypeAccess(rawTypePath, className, provider, si.isPublic, line);
    if (!it->isPublic && !canAccessMember(it->owner, it->isPrivate, it->isProtected))
      err("static field '" + fieldName + "' ไม่มีสิทธิ์เข้าถึงจากภายนอก class " + it->owner, line);
    return &*it;
  }
  Var *qualifiedGlobal(Node *n, int line) {  // util.MAX  (ตัวแปร global ของ module อื่น ต้อง public)
    if (n->k != NK::Member || n->c[0]->k != NK::Ident) return nullptr;
    std::string mod = n->c[0]->s;
    if (findLocal(mod)) return nullptr;
    auto am = modImportAliases[curModule].find(mod);
    if (am != modImportAliases[curModule].end()) mod = am->second;
    if (!userModules.count(mod)) return nullptr;
    auto m = globalVars.find(mod); if (m == globalVars.end()) return nullptr;
    auto it = m->second.find(n->s); if (it == m->second.end()) return nullptr;
    if (!globalPublic[mod + "." + n->s]) err("ตัวแปร '" + mod + "." + n->s + "' ไม่ใช่ public", line);
    return &it->second;
  }
  Var &declVar(const std::string &name, const T &t, const std::string &kind) {
    if (scopes.back().vars.count(name)) err("ตัวแปร '" + name + "' ประกาศซ้ำใน scope เดียวกัน");
    Var &v = scopes.back().vars[name]; v.name = name; v.ty = t; v.kind = kind; return v;
  }
  void regCleanup(Var &v) {
    if (!needsFree(v.ty)) return;
    scopes.back().cl.push_back({v.name, false});
    int kind = v.ty->k == STR ? 1 : v.ty->k == LIST ? 2 : v.ty->k == DSK ? 3 : v.ty->k == FUNC ? 5 : v.ty->k == OBJ ? 6 : v.ty->k == WEAK ? 9 : 4;
    std::string drop = v.ty->k == STRUCT ? "@drop." + v.ty->name : (v.ty->k == ENUM && v.ty->payloadEnum ? "@drop.enum." + v.ty->name : "null");
    ins("call void @fac_cleanup_push(ptr " + v.slot + ", i32 " + std::to_string(kind) + ", ptr " + drop + ")");
  }
  std::string varAddr(Var &v) {  // address ของที่เก็บค่า
    if (v.indirect) return def("load ptr, ptr " + v.slot);
    return v.slot;
  }

  // ================================================================ checks
  bool isLit(const std::string &s) { return !s.empty() && (isdigit((unsigned char)s[0]) || (s[0] == '-' && s.size() > 1 && isdigit((unsigned char)s[1]))); }
  void boundsCheck(const std::string &idx, const std::string &len) {
    if (!opt.bounds) return;
    if (isLit(idx) && isLit(len)) { long long i = atoll(idx.c_str()), n = atoll(len.c_str()); if (i >= 0 && i < n) return; }
    std::string ok = def("icmp ult i64 " + idx + ", " + len);
    std::string a = lbl("ok"), b = lbl("oob");
    cbr(ok, a, b, true);
    placeLabel(b);
    ins("call void @fac_oob(i64 " + idx + ", i64 " + len + ")");
    ins("unreachable"); term = true;
    placeLabel(a);
  }
  std::string toI64(const V &a) {
    if (!isIntLike(a.t)) err("index ต้องเป็นจำนวนเต็ม (เจอ " + tname(a.t) + ")");
    return conv(a, T_long);
  }
#include "gen_expr.inc"
#include "gen_ds.inc"
#include "gen_vec.inc"
#include "gen_lib.inc"
#include "gen_call.inc"
#include "gen_stmt.inc"
};
