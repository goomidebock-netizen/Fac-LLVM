// Fac frontend: lexer + AST + parser (C++17)
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <functional>
#include <vector>

struct CompileError : std::runtime_error {
  int line;
  int column; // 1-based UTF-8 byte column; zero when the source position is unavailable.
  CompileError(int l, const std::string &m, int c = 0) : std::runtime_error(m), line(l), column(c) {}
};

// ============================================================ Lexer
struct Tok {
  enum T { Ident, Int, Float, Char, Str, Op, End, ForPP, PPFor, LoopUp, LoopDown, ForDown, DownFor, LoopForDown, LoopDownFor } t = End;
  std::string s;
  int64_t iv = 0;
  double dv = 0;
  int line = 0;
  int column = 0; // 1-based UTF-8 byte column; zero when unavailable (e.g. nested string interpolation)
  bool nl = false;  // มีขึ้นบรรทัดใหม่ก่อน token นี้
  bool big = false; // เลขฐาน 10 ที่เท่ากับ 2^63 พอดี: ใช้ได้เฉพาะเป็น -9223372036854775808
};

inline void utf8enc(std::string &o, uint32_t c) {
  if (c < 0x80) o += (char)c;
  else if (c < 0x800) { o += (char)(0xC0 | (c >> 6)); o += (char)(0x80 | (c & 63)); }
  else if (c < 0x10000) { o += (char)(0xE0 | (c >> 12)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
  else { o += (char)(0xF0 | (c >> 18)); o += (char)(0x80 | ((c >> 12) & 63)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
}
// Strict UTF-8 decoder (same rules as the runtime's dec()): overlong forms, surrogates (U+D800..DFFF), values above
// U+10FFFF and truncated/stray bytes return kBadUtf8 and advance by 1 byte; callers must treat that as an error.
constexpr uint32_t kBadUtf8 = 0xFFFFFFFFu;
inline uint32_t utf8dec(const std::string &s, size_t &i) {
  unsigned char c = (unsigned char)s[i];
  auto cont = [&](size_t k) { return i + k < s.size() && ((unsigned char)s[i + k] & 0xC0) == 0x80; };
  if (c < 0x80) { i += 1; return c; }
  if (c >= 0xC2 && c <= 0xDF && cont(1)) { uint32_t r = ((c & 31u) << 6) | ((unsigned char)s[i + 1] & 63u); i += 2; return r; }
  if ((c >> 4) == 14 && cont(1) && cont(2)) {
    unsigned char c1 = (unsigned char)s[i + 1];
    if (!((c == 0xE0 && c1 < 0xA0) || (c == 0xED && c1 >= 0xA0))) {
      uint32_t r = ((c & 15u) << 12) | ((c1 & 63u) << 6) | ((unsigned char)s[i + 2] & 63u); i += 3; return r;
    }
  }
  if (c >= 0xF0 && c <= 0xF4 && cont(1) && cont(2) && cont(3)) {
    unsigned char c1 = (unsigned char)s[i + 1];
    if (!((c == 0xF0 && c1 < 0x90) || (c == 0xF4 && c1 >= 0x90))) {
      uint32_t r = ((c & 7u) << 18) | ((c1 & 63u) << 12) | (((unsigned char)s[i + 2] & 63u) << 6) | ((unsigned char)s[i + 3] & 63u); i += 4; return r;
    }
  }
  i += 1; return kBadUtf8;
}

inline constexpr size_t kMaxTokensPerSourceUnit = 1000000;
inline constexpr size_t kMaxTokensPerCompilation = 2000000;
std::vector<Tok> lex(const std::string &src, size_t *compilationTokens = nullptr);
