# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V263

## V263 — verified noescape forwarding for pointer fields in value structs

V263 adds a bounded, body-verified noescape forwarding summary for pointer
fields in non-`ref` value-struct parameters. Nested value-struct paths are
supported only when every pointer leaf is used exclusively as an exact
argument to a uniquely resolved, non-generic helper parameter with a matching
pointer type and a verified `noescape` contract. Ordinary retaining helpers,
whole-aggregate aliases/escapes, captures, direct pointer-field use, overloaded
or generic helpers, unknown layouts, pointer-bearing containers and
`ptr thread` remain outside this rule. Thread handles continue to use the
separate join-only contract. The new positive nested-struct regression runs
and returns `41`; a negative retaining-helper regression is rejected.
This is not general pointer provenance or heap escape analysis. No syntax,
Runtime semantics, public API, ABI or `--memory-safe` accepted-subset change.
See [`docs/MEMORY_MANAGEMENT_V263.md`](docs/MEMORY_MANAGEMENT_V263.md) and
[`docs/CODE_AUDIT_V263.md`](docs/CODE_AUDIT_V263.md).

Validation: Safe Profile 438/438; Ownership 12/12; const-method ownership
8/8; local borrow 167/167; noescape 20/20; field-sensitive borrow 25/25;
effect contract 19/19; function-effect 13/13; Move 20/20; Partial Move
28/28; Compile-time 57/57; Memory-Safe 39/39; Generic 3/3; Lexer 18/18;
Parser 68 + AST 1/1; Codegen passed; Runtime full runner passed; Tools 91/91;
Negative 134/134; Limits 21/21. Semantic component tests passed individually,
but the combined Semantic runner did not complete within the execution limit,
so a full uninterrupted Semantic-suite pass is not claimed. Standards,
Formatter, API manifest/contract/compatibility and generated-doc checks passed.
API audit: 5 baseline findings, 0 new; compatibility against V128: 0 breaking
changes and 132 existing warnings; 114 generated API docs current. Full
CMake/CTest, sanitizers, Windows/macOS build/run and production qualification
are not claimed.

## V261 — owned thread-handle provenance through local struct moves

V261 narrowly recognizes the independently allocated owned handle returned by
`thread.start`, tracks it through local value-struct pointer fields and nested
explicit `move(...)` transfers, and models the exact `thread.join(ptr thread)`
argument as consumed. Arbitrary incoming `ptr thread` values remain untracked
and cannot be retained in a value-struct field. This is not general resource
provenance, heap escape analysis, or a complete helper-summary/borrow-checker
implementation. No syntax, Runtime semantics, public API, ABI or
`--memory-safe` accepted-subset change. See
[`docs/MEMORY_MANAGEMENT_V261.md`](docs/MEMORY_MANAGEMENT_V261.md) and
[`docs/CODE_AUDIT_V261.md`](docs/CODE_AUDIT_V261.md).

Validation: Lifetime 147/147; Ownership 12/12; const-method ownership 8/8;
local borrow 167/167; noescape 17/17; field-sensitive borrow 25/25; effect
contract 19/19; function-effect 13/13; Move 20/20; Partial Move 28/28;
Compile-time 57/57; Memory-Safe 39/39; Generic 3/3; Lexer 18/18; Parser 68
+ AST 1/1; Codegen passed. Safe Profile: 435 passed, 2 V76 helper-provenance
checks still fail (V75 struct-move checks now pass). API checks: 0 breaking
changes against V128, 132 warnings; 5 baseline findings, 0 new; 114 generated
docs current. Standards and Formatter passed. Runtime runner, Semantic and
Tools suites did not complete with confirmed full-run results; only 17
Semantic ancestry checks are confirmed. Full CMake/CTest, sanitizers,
cross-platform build/run and production qualification are not claimed.

## V259 — pointer arithmetic in inferred enum-payload returns

V259 closes a strict-ownership gap where an `auto` function could return an
untracked raw pointer from an enum payload after pointer-preserving arithmetic,
such as `pointer + 0`. The checker now rejects pointer-valued `+`/`-`, assignment, compound
assignment (`+=`/`-=`), and prefix/postfix increment/decrement result forms
derived from such payload bindings. Scalar pointer difference
(`pointer - pointer`) and pointer comparisons remain non-pointer result forms.
The guard remains bounded; it does not implement general enum-payload
provenance or general expression/heap escape analysis. No syntax, Runtime,
ARC/GC, public API, ABI or `--memory-safe` accepted-subset change. See
[`docs/MEMORY_MANAGEMENT_V259.md`](docs/MEMORY_MANAGEMENT_V259.md) and
[`docs/CODE_AUDIT_V259.md`](docs/CODE_AUDIT_V259.md).

Validation: Lifetime 141 PASS; Ownership passed (function-effect 13/13);
Move 20/20; Partial Move 28/28; Memory-Safe 39/39; Generic 3/3; Codegen,
Lexer 18/18, Parser 68 + AST 1/1 and Runtime regression passed; Tools 91/91;
Negative 134/134; Limits 21/21; Formatter, Standards, API manifest, API audit,
strict API contract and generated-doc checks passed. API audit: 5 baseline
findings, 0 new; compatibility against V128: 0 breaking changes, 132 warnings.
Safe Profile: 433 passed, 4 known V258-baseline failures. Semantic suite
reported 17 ancestry checks before timing out; full Semantic success is not
claimed. Full CMake/CTest, ASan/UBSan/TSan, cross-platform and production
qualification are not claimed.


## V258 — nested match-binding shadowing in strict ownership

V258 fixes a false positive in V257's `auto`-return enum payload guard. A
nested match binding now shadows an inherited same-named binding before the
inner payload type is classified: a known scalar inner payload is accepted,
while an inner raw-pointer payload remains rejected when provenance is
untracked. Unknown/generic/ambiguous layouts remain conservative. This is a
precision correction only; no syntax, Runtime, ARC/GC, API, ABI or
`--memory-safe` accepted-subset change. See [`docs/MEMORY_MANAGEMENT_V258.md`](docs/MEMORY_MANAGEMENT_V258.md)
and [`docs/CODE_AUDIT_V258.md`](docs/CODE_AUDIT_V258.md).

Validation: Lifetime 130; Ownership 261; Secure Profile 6/6; Memory-Safe
39/39; Move/Partial Move 48; Compile-time 57/57; Lexer 18; Parser 68 + AST
1/1; Codegen, Generic 3/3, Semantic, Runtime, Tools 91/91, API, Formatter and
Standards checks passed. Legacy matrix 132/132 at `-O0` and `-O2`; Negative
134/134; Limits 21/21. Safe Profile 433 passed, 4 existing V257-baseline
failures. Sanitizers, CMake/CTest, cross-platform and production qualification
are not claimed.

## V256 — nested match-payload pointer-return fail-closed check

V256 closes a strict-ownership gap where a pointer returned from an enum payload binding was rejected when the `match` was the direct return expression, but could pass when nested inside an `ifv / eiv / elv` result arm. Return checking now recursively inspects result-producing conditional and match expressions, rejects untracked payload bindings, and continues to ignore conditions, scrutinees, patterns and guards that only select the returned value. This remains fail-closed; enum-payload provenance is not yet tracked. No Runtime, ARC/GC, public API, ABI or `--memory-safe` acceptance change. See [`docs/MEMORY_MANAGEMENT_V256.md`](docs/MEMORY_MANAGEMENT_V256.md) and the [`V256 focused code-audit report`](docs/CODE_AUDIT_V256.md).

Validation on Linux x86-64 with Clang 17 C++17 (`-O0 -g0` Compiler build): lifetime 123 checks; ownership 261 checks; secure profile 6/6; `--memory-safe` 39/39; move/partial-move 20/20 and 28/28; compile-time/const-generic 57/57; generic specialization 3/3; parser 68 checks plus AST model 1/1; lexer 18/18; focused Codegen checks passed. API/standards checks passed with 0 compatibility breakings, 132 warnings and 5 existing baseline API findings. The semantic suite (17 ancestry checks passed) and Tools suite did not complete within the command time limit. Full CMake/CTest, ASan/UBSan/TSan, cross-platform and production qualification are not claimed.

## V235 — branch-aware pointer-return lifetime validation

V235 extends bounded pointer-return lifetime inference through `ifv / eiv / elv` and `match` result expressions. Every possible non-null result must derive from the same verified pointer input or eligible local alias; mixed sources do not receive a guessed lifetime. Predicates, match scrutinees, patterns and guards are excluded from result provenance. Pointer returns that reference enum payload bindings remain rejected until payload provenance is modeled, preventing Unknown from being mistaken for a safe empty origin set. Match inference requires an explicit `default`. No first-class `ref T` return type, Runtime, ARC/GC, public API/ABI or `--memory-safe` subset change. See [`docs/MEMORY_MANAGEMENT_V235.md`](docs/MEMORY_MANAGEMENT_V235.md).

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler build): Compiler reports V235 for Core/Lib/API/Lang/Runtime/Stdlib; lifetime regression 121/121; ownership 261 checks (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect); secure profile 6/6; move/partial-move 48/48; `--memory-safe` 39/39; Tools 91 tests; parser 68 checks plus AST model 1/1; lexer 18/18; CTest 37/37. `make fmt-check` and `make standards-check` passed. API manifest and contract checks passed; 950 public source functions had the required documentation annotations; API audit covered 663 built-ins and 1,014 source declarations with 5 existing baseline findings and 0 new findings; compatibility against V128 reported 0 breaking changes and 132 warnings. `tools/check_versions.py` passed and `facc --version` reported V235 for every component. The broad legacy semantic suite, ASan/UBSan/TSan qualification, cross-platform testing and production qualification are not claimed.



## V234 — bounded nested-closure lifetime proof

V234 extends the local direct-call-only closure proof to nested local closures. A nested lambda may capture a verified pointer only when its function value is local, every use is an immediate direct call, and each enclosing closure independently satisfies the same non-escape proof. Copies, assignments, returns, argument passing, shadowing, self-capture, nested named-function references and cyclic proof dependencies remain rejected. Pointer origins must be known, non-`noescape`, and outlive every closure region. This is a bounded syntactic proof, not general closure/heap escape analysis. No syntax, Runtime, ARC/GC, public API, ABI or `--memory-safe` acceptance changed. See [`docs/MEMORY_MANAGEMENT_V234.md`](docs/MEMORY_MANAGEMENT_V234.md).

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler/Runtime build): Compiler reports V234 for every component; Lifetime 116 checks; ownership 261 checks (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect); secure profile 6/6; move/partial-move 48 checks; `--memory-safe` 39/39; Tools 91 tests (6 skipped, no failures); parser 68 checks plus AST model 1/1; lexer 18 checks; codegen constant-fold and recursion-guard checks passed. Full CMake build completed and CTest passed 37/37, including lifetime integration, Runtime safety/cycle-collector/concurrency, frontend/runtime fuzz and package-install consumer tests. `make fmt-check`, standards, API manifest, API contract, API compatibility, generated docs and version checks passed. API audit covered 663 built-ins and 1,014 source declarations, with 5 existing baseline findings and 0 new findings; compatibility reported 0 breaking changes and 132 warnings against V128. The broad semantic suite was only partially run (17 ancestry checks passed before the overall command timed out); no full semantic-suite success is claimed. ASan/UBSan/TSan qualification, cross-platform testing and production qualification are not claimed.


## V233 — bounded local closure capture for verified pointer lifetimes

V233 permits a closure to capture a non-null pointer or pointer-bearing local value struct only when its source provenance is complete, every origin outlives the closure binding's lexical region, and the lambda is the direct initializer of a local function value whose every use is a direct call in the same function. Copies, assignment, return, argument passing, aggregate/container storage, nested-closure capture, name shadowing, unknown provenance, shorter-lived origins and `noescape` pointer inputs remain rejected. Pointer-free aggregates and the V232 Verified-Null rules are unchanged. This is a bounded syntactic escape proof, not general closure lifetime inference or whole-program escape analysis. No syntax, Runtime, ARC, Cycle Collector, public API or ABI changed; `--memory-safe` acceptance is unchanged. See [`docs/MEMORY_MANAGEMENT_V233.md`](docs/MEMORY_MANAGEMENT_V233.md).

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler build): Compiler reports V233 for every component; Lifetime 112 checks; ownership 261 checks; secure profile 6/6; move/partial-move 48 checks; `--memory-safe` 39/39; Tools 91 tests (6 skipped, no failures); parser 68 checks plus AST model 1/1; lexer 18 checks; focused codegen checks passed. Full CMake build completed and CTest passed 37/37, including Runtime safety/cycle-collector/concurrency regressions, fuzz regressions and package install consumer. `make fmt-check`, `make standards-check`, `make api-check` and version checks passed; API audit reported 0 breaking changes and 132 compatibility warnings against V128, with 5 existing baseline findings and 0 new findings. Sanitizer qualification, cross-platform testing and production qualification are not claimed.

## V232 — verified-null pointer locals in closure captures

V232 distinguishes a standalone pointer local whose current value is proven `null` from a pointer whose provenance is Unknown. Pointer locals initialized or overwritten with verified null receive an exact empty flow-sensitive provenance fact; copies from another verified-null pointer or exact aggregate field preserve it; unknown writes remove it, and branch joins keep it only when every possible predecessor is verified. Closure capture is allowed for this Verified-Null state, while non-null frame-derived pointers and missing/unknown provenance remain rejected. Current flow facts supersede historical declaration summaries so a pointer cleared to null does not retain a stale escape origin. This is not general closure escape/lifetime inference; ARC, Cycle Collector, Runtime, public API, C ABI and Runtime ABI are unchanged. See [`docs/MEMORY_MANAGEMENT_V232.md`](docs/MEMORY_MANAGEMENT_V232.md).

## V231 — nested pointer-alias returns and fail-closed closure capture

V231 combines two bounded strict-ownership improvements.

**Nested-block pointer-alias return inference:** When a source-defined function has exactly one eligible non-`noescape` pointer return source and every other pointer input has a body-verified `noescape` contract, the selected source may now be returned directly or through a simple local pointer alias declared in a nested lexical block. Child blocks inherit visible aliases from parents but do not export their aliases to parent/sibling scopes. Candidate names must be unique across the function body, directly initialized from a visible parameter/alias, never assigned and never passed to a call. This remains a bounded name-based proof, not general declaration-identity or interprocedural escape analysis.

**Fail-closed closure capture:** Capturing a pointer local/parameter is rejected when its provenance is known to be frame-restricted or missing/unknown. Capturing a value struct with pointer fields requires an exact provenance fact for every pointer-bearing field; Unknown is not treated as verified null. Pointer-free structs and structs whose pointer fields are all explicitly verified null remain capturable. Standalone pointer locals do not yet have a separate verified-null state, so an origin-free pointer local is conservatively rejected if captured. General closure non-escape/lifetime inference and heap/container escape analysis remain unsupported.

No source syntax, Runtime, ARC/GC behavior, public API, C ABI or Runtime ABI changed. `--memory-safe` remains unchanged and continues to exclude raw pointer types and `addr`. See [`docs/MEMORY_MANAGEMENT_V231.md`](docs/MEMORY_MANAGEMENT_V231.md).

V231 validation on Linux x86-64 with Clang 17 C++17: Compiler rebuilt with `-O0 -g0`; Runtime rebuilt with `-O2 -g0`; `facc --version` reports V231 for every component. `tests/lifetimes/run.sh`: 98 checks passed; ownership: 261 checks passed; `tests/ownership/secure_profile.sh`: 6/6; move/partial-move: 48 checks; `tests/memory_safe/run.sh`: 39/39; Tools: 91 tests, 6 skipped, no failures; parser: 68 checks plus AST model 1/1; lexer: 18 checks; codegen constant-fold and recursion-guard checks passed; formatter passed. `make api-check` passed: 663 built-in entries and 1,014 source declarations audited, 950 public source functions had required documentation annotations, 0 compatibility breakings and 132 warnings against V128; all 5 API findings were present in the baseline (0 new). `tools/check_versions.py` passed. Full semantic/legacy-suite, sanitizer, cross-platform and production qualification are not claimed.

## V230 — verified local pointer-alias return lifetimes

Strict ownership can now infer the unique return lifetime for a bounded local pointer alias (or alias chain) when a function has multiple pointer inputs, exactly one eligible return source, and body-verified `noescape` contracts for the other pointer inputs. Aliases must be top-level declarations, initialized directly from the selected source/earlier alias, unique across the function body, never assigned, and never passed to a call. The selected source parameter also cannot be assigned. Shadowing, nested alias declarations, call exposure, reassignment and ambiguous sources keep inference disabled. This improves return-reference checking without changing source syntax, Runtime memory management, ARC/GC, public APIs or ABI. See [`docs/MEMORY_MANAGEMENT_V230.md`](docs/MEMORY_MANAGEMENT_V230.md).
V230 validation: lifetime 89 checks; ownership 261; move/partial-move 48; `--memory-safe` 39/39; Tools 91/91; parser 68 plus AST 1/1; lexer 18; focused codegen, formatter, standards and API checks passed. The legacy `tests/run_safe.sh` had 4 failures that reproduced on the untouched V229 baseline (433 passes); these remain unresolved and are not claimed as passing. Sanitizer, cross-platform and production qualification are not claimed.

## V229 — loop-carried pointer provenance fixed point

V229 computes a bounded may-origin fixed point for local pointer variables and exact pointer-field paths in local value structs across `while`, `do-while`, C-style `for`, foreach and compact `ForPP` loops. Each pass transfers the condition/body/step in execution order and joins the loop entry with the back-edge until the visible facts stabilize. Origins from all possible iterations are retained; missing facts remain Unknown and verified null remains distinct. Lifetime regions are stable across repeated analysis and duplicate constraints are removed. The solver is capped at 32 passes and invalidates changed facts if it does not converge. Loops containing `break` still use conservative invalidation because break exits are not yet separate provenance predecessors; `continue` is not a distinct edge yet. This remains local and intraprocedural; no general heap alias/escape proof, ARC/GC behavior, Runtime, public API or ABI changes. See [`docs/MEMORY_MANAGEMENT_V229.md`](docs/MEMORY_MANAGEMENT_V229.md).

V229 validation: lifetime 83 checks; ownership 261 checks; secure profile 6/6; move/partial-move 48 checks; `--memory-safe` 39/39; parser 68 checks plus AST model regression; lexer 18 checks; focused codegen checks passed. The full Tools suite, complete legacy suite, sanitizers and cross-platform qualification are not claimed.

## V228 — aggregate lifetime propagation across control-flow joins

V228 propagates local value-struct pointer provenance through lexical blocks and joins it across `if`, `switch` / `match`, and `try` / `catch` alternatives. Each exact field path is retained only when every possible predecessor has a verified fact; all possible pointer origins are unioned and must satisfy the later store/return lifetime. Known-null remains distinct from unknown provenance. Pointer-local origins are also propagated by declaration identity. Because a loop fixed-point is not yet implemented, changed outer aggregate/pointer facts are invalidated after a loop rather than retaining stale pre-loop origins. This closes stale-provenance gaps without enabling heap-stored references, general aggregate parameters/returns, closure/global/container escapes, or changing ARC, Cycle Collector, Runtime, public API or ABI behavior. See [`docs/MEMORY_MANAGEMENT_V228.md`](docs/MEMORY_MANAGEMENT_V228.md).

## V227 — validated nested aggregate borrow graph

V227 validates every nested local reborrow as a graph edge before installing the child alias. The edge must retain the original storage owner, remain within an exact metadata-resolved parent field projection, and have a parent lifetime that outlives the child. Missing parents, cycles and owner/projection escapes are rejected. Three-level nested struct borrows are covered, including disjoint sibling leaves, same-leaf conflict rejection, parent suspension while a grandchild remains live, and NLL retention of ancestor loans. This is a local borrow graph, not a general heap graph; ARC, Cycle Collector, Runtime, public API and ABI behavior are unchanged. See [`docs/MEMORY_MANAGEMENT_V227.md`](docs/MEMORY_MANAGEMENT_V227.md).

## V226 — field-sensitive aggregate pointer provenance

V226 replaces V225's root-level pointer-origin union for local value structs with exact field-path facts. Sibling fields can now retain independent lifetimes; nested value-struct paths and local aggregate copies preserve field provenance. Assigning a new pointer or `null` kills the previous fact for that field, while replacing a nested/whole aggregate clears and rebuilds the affected subtree. Known-null facts are distinct from missing provenance, and reads/copies/passes/returns involving pointer-bearing aggregates without complete verified field facts fail closed. Heap/object fields, globals, containers, arbitrary aliases, closures and general heap reference graphs remain unsupported. No ARC, Cycle Collector, Runtime, public API or ABI behavior changed. See [`docs/MEMORY_MANAGEMENT_V226.md`](docs/MEMORY_MANAGEMENT_V226.md).

## V225 — checked pointers in local value structs

V225 lets strict-ownership code store a tracked pointer in a local value `struct` when its origin is proven to outlive that struct's lexical storage. This covers nested by-value struct fields, constructor initialization, direct pointer-field assignment, local aggregate copies and verified named-lifetime inputs. Untracked pointers, `noescape` retention, short-lived owners, return/call/closure escapes, `class` / `obj` fields, globals, containers, array/index paths and managed-object boundary crossings remain rejected. Provenance is summarized conservatively per local aggregate root, so the implementation may reject safe sibling-field cases; this is not a general heap borrow graph or a Rust-equivalent guarantee. No Runtime, ARC, Cycle Collector, public API or ABI behavior changed. See [`docs/MEMORY_MANAGEMENT_V225.md`](docs/MEMORY_MANAGEMENT_V225.md).

## V224 — body-proven pointer return lifetime elision with multiple inputs

V224 extends the V222 implicit return-lifetime rule to a constrained multi-pointer function: exactly one non-`noescape` pointer parameter may be the return source, every other pointer parameter must be `noescape`, and every explicit non-null return must directly name the same source parameter. The compiler verifies each secondary `noescape` body contract, checks the return against a synthetic lifetime for the selected source, and propagates provenance from only that argument at direct call sites. Multiple possible return sources, returns through aliases/calls/fields/computed expressions, extern/abstract functions and unannotated function-value callbacks remain conservative. See [`docs/MEMORY_MANAGEMENT_V224.md`](docs/MEMORY_MANAGEMENT_V224.md).

## V223 — nested value-field borrowing through managed objects

V223 fixes field-path normalization for strong managed `obj` handles. With metadata-resolved by-value aggregate fields, local borrows can now distinguish nested disjoint paths such as `actor.stats.health` and `actor.stats.mana`. Disjoint fields may be borrowed/accessed independently; overlapping borrows and owner writes to the active field remain rejected. Borrow analysis deliberately stops at a nested `obj` reference boundary, because that child object may be shared through another handle, and borrowing through a `weak obj` handle is rejected because it does not prove liveness. See [`docs/MEMORY_MANAGEMENT_V223.md`](docs/MEMORY_MANAGEMENT_V223.md).

## V222 — single-input pointer lifetime elision and managed heap-field borrows

V222 adds a bounded implicit return lifetime for a verified, source-defined FAC function that returns `ptr T` and has exactly one non-`noescape` pointer parameter, with no explicit named lifetime parameters. The body is checked against a synthetic lifetime for that input, and direct call sites propagate the selected input's pointer provenance. A pointer to a local or shorter-lived object still cannot escape. At V222, multiple pointer inputs remained ambiguous; V224 adds only the constrained body-proven case described above. `extern`, abstract declarations and unannotated function-value/callback types do not receive this inference. See [`docs/MEMORY_MANAGEMENT_V222.md`](docs/MEMORY_MANAGEMENT_V222.md).

The memory-safe regression suite now verifies local mutable borrows of metadata-resolved fields on managed `obj` handles. The object handle remains the loan root, so writes through the owner are rejected while an overlapping mutable borrow is live. This does not permit storing `ref` values in object/aggregate fields or containers, and does not add a general heap-reference graph solver. Raw pointers and FFI remain outside `--memory-safe`.

## V221 — ownership-first checked borrows

V221 updates `--memory-safe` to permit `ref` parameters and function-local `ref` / `ref const` aliases when strict ownership/loan analysis proves the borrow safe. Borrows in globals and aggregate fields remain rejected, as do raw pointers, manual heap operations, FFI and unsafe code. This is a bounded safe subset, not a complete Rust-equivalent borrow/lifetime proof. See [`docs/MEMORY_MANAGEMENT_V221.md`](docs/MEMORY_MANAGEMENT_V221.md) and [`docs/MEMORY_SAFE_PROFILE.md`](docs/MEMORY_SAFE_PROFILE.md).

# FAC V220 — Socket/TLS handle lifetime and concurrency safety

V220 hardens TCP socket and optional OpenSSL TLS handles. Both now expose stable opaque Runtime tokens resolved through registries before native state is accessed; token addresses are retained as tombstones so a stale pointer alias cannot become valid again after a later open. Socket state is reference-counted independently of the token and tracks active operations, close and TLS ownership transfer. Read and write have separate locks, preserving full-duplex TCP I/O, while close waits for operations already in flight and rejects later operations with Network (11).

TLS handles use the same non-reused-token and registry pattern. A successful TLS handshake atomically transfers the socket state to the TLS handle and retires the raw socket token; a failed handshake leaves socket ownership with the caller. OpenSSL operations and close are serialized per TLS stream, with FAC cleanup callbacks releasing locks on longjmp-based error propagation. A blocking TLS read therefore delays a concurrent write on that same stream; applications that need independent full-duplex progress should use separate streams.

The public function signatures, pointer-sized opaque-handle C ABI, and exported symbol names are unchanged. Socket/TLS tokens are not native OS descriptors, `SSL*`, or `SSL_CTX*`; foreign callers must pass them only to the corresponding FAC APIs. Managed wrapper objects still require callers to prevent concurrent mutation/destruction of their own handle fields. See `docs/RUNTIME_SOCKET_TLS_CONCURRENCY_V220.md`, `docs/api/net.md`, `docs/api/tls.md`, `docs/api/tls_stream.md`, and `docs/STATUS.md`.

## V220: compiler-internal typed declaration generation

The compiler has bounded C++ `fac_hir::TypedDeclarationBuilder` and `fac_hir::TypedFunctionBodyBuilder` APIs for registering generated non-generic structs/free functions and building typed scalar bodies in an existing semantic HIR model. Generated bodies support immutable/mutable scalar locals, exact-TypeId local assignments, nested `if/else` regions with bool conditions, supported literals/unary/binary expressions, exact same-module calls and one terminal return. The Codegen bridge lowers generated structs through the ordinary LLVM record-layout/helper path, body-less functions as deterministic external C-ABI declarations, and supported generated bodies as internal LLVM definitions with conditional branches/basic blocks. These are compiler-internal APIs, not FAC source-level metaprogramming. Loops, branch-local declarations/returns, multiple return paths, generated classes/methods/generics and many non-scalar signatures remain unsupported. See [`docs/TYPED_DECLARATION_BUILDER_V220.md`](docs/TYPED_DECLARATION_BUILDER_V220.md), [`docs/GENERATED_DECLARATION_CODEGEN_V220.md`](docs/GENERATED_DECLARATION_CODEGEN_V220.md), [`docs/GENERATED_FUNCTION_BODY_V220.md`](docs/GENERATED_FUNCTION_BODY_V220.md) and [`docs/STATUS.md`](docs/STATUS.md).

## V220: multi-paradigm Language Core map

FAC is designed to support several programming styles in one statically typed language: procedural functions/control flow, OOP (`class`/`obj`/interfaces), generic type specialization, functional function-values/lambdas and `match`/`Result`, bounded compile-time assertions, scalar `consteval` free functions, typed query intrinsics `typeOf<T>()`/`sizeof<T>()`/`alignof<T>()` and bounded structural field queries, and explicit low-level pointer/FFI operations. These areas are not equally complete: V220 supports bounded `const int` generic parameters on struct/class types, free functions and methods. Call sites may provide integer constant expressions, which become specialization values and can participate in dependent types and fixed-array dimensions. Const values may be constrained with built-in value predicates (`positive`, `nonnegative`, `nonzero`, `negative`, `even`, `odd`, `power_of_two`); multiple predicates joined by `&` must all pass. Generic arguments may be positional, named (`N = 8`), or positional followed by named, and are normalized to declaration order before specialization. Generic type parameters on structs/classes/interfaces/enums, free functions and methods may declare trailing defaults, while `const int` defaults are supported on structs/classes, free functions and methods; omitted arguments are filled in declaration order, while eligible free-function inference takes precedence over defaults. This is not general compile-time execution: const-value inference is limited to generic free functions whose parameter exposes a fixed-array extent directly as `[N]`; generic methods and struct/class instantiations do not infer parameters, though they may omit parameters covered by defaults. V220 supports a bounded `consteval` interpreter for scalar free functions and bounded structural field queries (`fieldCount`, `fieldName`, `fieldType`, `fieldOffset`) over resolved struct/class records. These queries enumerate public non-static instance fields, include inherited public class fields and do not expose private/protected or static fields. Generic specialized records, interfaces, enums, source-level typed declaration builders and unrestricted macros remain outside the current scope. The compiler also materializes an immutable, source-mapped typed-expression AST projection and provides an internal C++ `TypedAstFactory` for validated generated expression nodes. These are not FAC AST-construction APIs and the expression factory does not create declarations; a restricted subset of its nodes can be assembled into generated scalar function bodies with mutable locals, exact-type assignments and nested `if/else` by the separate `TypedFunctionBodyBuilder` and consumed by Codegen. See `docs/TYPED_AST_BUILDER_V220.md`, `docs/TYPED_AST_FACTORY_V220.md` and `docs/STRUCTURAL_REFLECTION_V220.md`. Reference-capturing closures, generic virtual/interface methods and fully proven raw-pointer/FFI safety also remain incomplete. See `docs/TYPED_AST_BUILDER_V220.md`, `docs/TYPED_CONSTANT_VALUES_V220.md`, `docs/CONST_GENERIC_FUNCTIONS_V220.md`, `docs/CONST_GENERIC_CONSTRAINTS_V220.md`, `docs/NAMED_GENERIC_ARGUMENTS_V220.md`, `docs/CONST_VALUE_INFERENCE_V220.md`, `docs/GENERIC_DEFAULT_ARGUMENTS_V220.md` and `docs/CONSTEVAL_V220.md` for syntax and boundaries.

See [`docs/LANGUAGE_PARADIGMS.md`](docs/LANGUAGE_PARADIGMS.md) for the feature-by-feature syntax, examples, maturity and limitations; [`tests/cases/t220_language_paradigms.fac`](tests/cases/t220_language_paradigms.fac) is the cross-paradigm compiler/runtime regression.


## V219 — SQLite resource-handle concurrency and lifetime safety

V219 hardens SQLite connection and prepared-statement handles. The Runtime returns monotonically increasing opaque tokens, resolves them through registries before touching native state, and never recycles a token during process lifetime. Per-connection mutexes serialize every native SQLite call with connection close/free and statement operations. A Statement record retains shared connection state so `sqlite3_close_v2` can defer native destruction until outstanding statements are finalized; a prepared FAC Statement can continue after its Database handle is closed. Stale or freed connection/statement tokens are rejected without dereferencing freed memory.

SQLite column text and column-name results are copied into per-thread buffers while the connection lock is held, avoiding a pointer into native SQLite row storage being invalidated by another thread after the wrapper releases its lock. The C function signatures and pointer-sized opaque-handle ABI remain unchanged. The token values are not native `sqlite3*` or `sqlite3_stmt*` pointers and must only be passed back to FAC SQLite functions.

The design retains monotonic token numbering but removes registry entries when handles are freed; it does not keep one tombstone record per closed handle. Active statements retain their shared connection record until finalization. Native calls are serialized, but a multi-call logical transaction or bind/step/reset sequence still requires application-level sequencing.

V218 file-handle lifetime protection and earlier Runtime safety work remain in place. See `docs/STATUS.md`, `docs/api/sqlite.md`, and `tests/runtime/sqlite_handle_concurrency.cpp` for scope and validation.

## Previous release: V216

V216 adds per-handle recursive synchronization to the software Canvas. Operations that read or mutate a live Canvas now serialize access to its pixel, alpha, text-input, window and depth-buffer state. Cross-Canvas blits acquire source and destination locks with `std::lock`, preventing opposing `A <- B` and `B <- A` copies from deadlocking. Save operations hold a coherent snapshot lock while reading image data. The POSIX SDL2 path keeps its process-wide video-state mutex in a consistent Canvas-then-video lock order. The Pango/Cairo/Fontconfig backend libraries are kept loaded for the process lifetime because their process-global caches and worker/TLS teardown state are unsafe to unload during static destruction. Public API signatures and the C ABI are unchanged.

The Runtime still requires callers to prevent new uses of a raw Canvas handle before calling `graphic.free`; concurrent destruction is not made safe by an in-object mutex. Mutable camera handles also remain caller-synchronized. V215 Pango/Fontconfig synchronization and earlier ML/autograd, tensor/buffer and resource hardening remain in place. See `docs/RUNTIME_CANVAS_CONCURRENCY_V216.md`, `docs/RUNTIME_SHARED_STATE_V215.md`, `docs/STATUS.md`, `docs/API_CONVENTIONS.md` and `docs/BUILD.md` for scope and validation.

## V199 — transitive parent/child/grandchild reborrow suspension

V199 makes mutable reborrow suspension explicitly transitive. Reads/writes through a mutable ancestor, member/method access and calls are rejected while any live descendant loan (child, grandchild or deeper) remains active. The ancestor walk resolves parent links by declaration identity rather than alias spelling, preserving correctness under lexical shadowing. NLL still releases the chain after the deepest descendant's last reachable use; a runtime regression verifies that the parent can then write through to the original owner.

See `docs/LANGUAGE_CORE_V199.md` for the exact scope and tests. This remains an intraprocedural local-loan analysis, not named lifetime parameters or a complete general lifetime solver.


## V198 — unified outlives constraints for pointer storage

V198 routes pointer-provenance storage checks through the same per-function lifetime-constraint solver used for local `ref` borrows. Pointer initializers, pointer-to-pointer assignments, aggregate/container stores and returns now record explicit owner-region versus destination-region constraints; the solver validates them after visiting the function. This preserves same/shorter-scope pointer use while rejecting an inner-scope origin copied through one or more local pointer aliases into an outer destination. `noescape` return diagnostics remain specialized. This is a bounded lexical-region constraint solver, not named lifetime parameters or general interprocedural lifetime inference.

See `docs/LANGUAGE_CORE_V198.md`, `docs/LANGUAGE_CORE_V197.md`, `docs/OWNERSHIP.md` and `docs/MEMORY_MODEL.md` for scope and tests.


## V197 — implicit control-flow lifetime regions

V197 tightens the lexical lifetime tree for control-flow branches. `if` arms, `switch`/`match` statement cases and `match` expression cases (including pattern bindings and default arms), and `try`/`catch`/`finally` bodies now receive distinct child lifetime regions even when the contained statement is not wrapped in an explicit block. Match payload bindings are assigned to their case region. This prevents an address derived from a case-local pattern binding from being stored in a pointer declared in an enclosing scope; immediate use within the case or storage in a pointer with the same/shorter lifetime remains allowed. Runtime-dependent control flow remains conservative. This is still a bounded lexical region analysis, not general source-level lifetime parameters or a complete borrow checker.

See `docs/LANGUAGE_CORE_V197.md`, `docs/OWNERSHIP.md` and `docs/MEMORY_MODEL.md` for scope and tests.

## V196 — reachable-CFG analysis for local borrow lifetimes

V196 fixes a precision bug in strict local-borrow liveness: the backward data-flow pass previously evaluated every constructed CFG block, including blocks that could not be reached from the function entry. This could report a borrow conflict for a write that existed only in an impossible branch, even when a literal Boolean condition had already pruned the incoming CFG edge. The pass now computes forward reachability first, runs backward loan liveness only over reachable blocks, and records empty flow facts for unreachable syntax so the semantic pass can still type-check dead code without treating its impossible accesses as active runtime loans. Deferred uses pin loans only when the corresponding `defer` node is reachable.

The CFG pruner recognizes only side-effect-free syntax that is provably constant: Boolean literals, unary `!`, short-circuit `&&` / `||` when the left side determines the result or both sides are constant, integer-literal comparisons, and Boolean-literal equality/inequality. Identifiers (including const variables), function calls, arithmetic expressions, floating comparisons and other unknown predicates retain both edges. This is a bounded CFG precision improvement, not general constant evaluation or a complete borrow/lifetime checker. The V195 system-font default and explicit bitmap-text path are retained unchanged.

See `docs/LANGUAGE_CORE_V196.md` and `docs/OWNERSHIP.md` for scope and test details.

## V195 — readable default system typography for the canvas UI

V195 corrects the default canvas UI typography. The reusable `render.text()` path previously delegated to FAC's intentionally tiny 3×5 bitmap renderer, while the existing vector-font API was only used when an application explicitly loaded a font. `render.text()` now uses a native/system sans renderer by default and `render.measureText()` measures with that same renderer. Windows uses native GDI with Segoe UI preferred; Linux/macOS use Pango/Cairo/Fontconfig with the system `Sans` family and fallback. If the host backend is unavailable, the renderer remains usable with the bitmap fallback. `graphic.bitmapText()` and `graphic.bitmapTextWidth()` retain the legacy bitmap behavior for games and pixel-art applications; `graphic.text()` uses normal system typography by default. No new font file is required for the default UI.

## V194 — bounded floating-point arithmetic constants in array-borrow projections

V194 extends the strict local-borrow fixed-array projection evaluator to fold supported floating `+`, `-`, `*`, `/` and `%` expressions when every operand is a statically known literal or initialized local constant. The evaluator tracks float32 versus float64 and applies FAC `commonT()` promotion: float32 operations are rounded after each operation, while any double operand selects float64. Floating results are converted through the existing FAC saturating casts when used as indexes. Calls, mutable values, exponentiation, zero-divisor operations and non-finite arithmetic results remain conservative. This is bounded expression folding, not general const evaluation or a complete borrow/lifetime checker. See `docs/LANGUAGE_CORE_V194.md` and `docs/OWNERSHIP.md`.


## V193 — bounded floating-point constant casts in array-borrow projections

V193 extends strict local-borrow fixed-array projection analysis to resolve explicit float/double-to-integer and float/double-to-boolean casts when the source is a floating literal or an initialized local `const float` / `const double` whose value is supported by the bounded scalar evaluator. Conversion folding follows FAC's LLVM saturating float-to-integer conversion behavior (truncate toward zero, saturate to the target range, and map NaN to zero); boolean conversion follows the nonzero/ unordered comparison behavior. Float32 constants are rounded to their stored precision and declaration identity prevents shadowing from reusing an outer value. Unknown, mutable, unsupported arithmetic, and unsigned-64 projections outside signed-64 range remain conservative. This is not general floating-point constant evaluation or a complete borrow/lifetime checker. See `docs/LANGUAGE_CORE_V193.md` and `docs/OWNERSHIP.md`.


## V192 — local const character identifiers in array-borrow projections

V192 extended the bounded strict local-borrow fixed-array index evaluator to resolve initialized local `const char` and `const unichar` declarations whose values are supported pure integer-like constants. Values use FAC character storage widths (8-bit unsigned `char`, 32-bit unsigned `unichar`) and remain tied to exact declaration identity. Constant chaining, supported arithmetic/casts, and character-derived predicates can select exact indexes; mutable, shadowed, uninitialized, unsupported, or out-of-representation values remain conservative. This is a narrow borrow-projection improvement, not general constant evaluation or a complete borrow/lifetime checker. See `docs/LANGUAGE_CORE_V192.md` and `docs/OWNERSHIP.md`.


## V191 — explicit primitive casts in constant array-borrow projections

V191 extends the bounded strict local-borrow fixed-array index evaluator to resolve pure `cast(Type, value)` calls when the target is a primitive integer, boolean, `char`, or `unichar` type and the source is a supported pure integer-like constant. Folding follows FAC's actual conversion model: integer truncation keeps low bits, widening sign-extends signed sources and zero-extends unsigned sources, and boolean conversion maps zero/nonzero to false/true. Nested casts and cast-derived `ifv / eiv / elv` predicates are supported. Float conversions, pointer/class/enum casts, unsupported source expressions and values outside the evaluator's signed-64-bit projection representation remain conservative.

This is a bounded borrow-projection improvement, not general constant evaluation, runtime bounds checking, dynamic alias analysis or a complete borrow/lifetime checker. See `docs/LANGUAGE_CORE_V191.md` and `docs/OWNERSHIP.md` for the exact boundary and tests.


## V190 — local `const boolean` predicates for conditional borrow projections

V190 extends the bounded strict local-borrow evaluator so initialized local `const boolean` declarations can be used as `ifv / eiv / elv` predicates. Constant boolean initializers can use supported pure predicates and can chain from earlier visible boolean/integer constants. Each recorded value is tied to its exact declaration node, preserving shadowing and initializer-before-shadow semantics. Unknown, mutable, global, uninitialized, side-effecting or unsupported predicates remain conservative. This is a targeted borrow-projection improvement, not general constant evaluation, lifetime solving or a complete borrow checker.

See [`docs/LANGUAGE_CORE_V190.md`](docs/LANGUAGE_CORE_V190.md) and [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md) for the exact supported subset and limitations.


## V189 — constant conditional-expression array-index projections

V189 extends strict local-borrow fixed-array projection analysis to constant `ifv / eiv / elv` expressions. It selects an arm only when each tested predicate is provably constant using boolean literals, integer truth values, logical short-circuit operators and integer comparisons. Every result arm must resolve to a pure integer constant with the same width and signedness; otherwise the projection stays conservative. Runtime regression tests verify that a borrow selected through `ifv` still aliases the original array element. This is a bounded borrow-projection enhancement, not general constant evaluation or a complete lifetime checker.

See `docs/LANGUAGE_CORE_V189.md` and `docs/OWNERSHIP.md` for the exact supported subset and limitations.

## V188 — bitwise and shift constant array-index projections

V188 extends the bounded strict local-borrow fixed-array projection evaluator with pure integer bitwise operators `&`, `|`, `^`, shifts `<<` / `>>`, and unary bitwise complement `~`. It applies FAC integer promotions and common integer signedness/width rules, masks shift counts exactly as the code generator does, evaluates signed right shift arithmetically and unsigned right shift logically, and remains conservative when a value cannot be represented as a non-negative `int64_t` projection. Runtime alias tests verify that references still update their original array elements. V188 builds on V183–V187 literal, arithmetic and local-const index support.

This is still a bounded fixed-array borrow-projection analysis, not general constant evaluation, dynamic alias analysis, bounds checking, lifetime solving or a complete borrow checker. Unsupported/side-effecting expressions remain conservative. See `docs/LANGUAGE_CORE_V188.md`, `docs/LANGUAGE_CORE_V187.md` and `docs/OWNERSHIP.md` for the feature boundary.

Validation is recorded in `docs/STATUS.md`; only suites actually run for this archive are claimed. No unrun platform or sanitizer qualification is implied.

## V187 — unsigned local const array-index projections

V187 continues the sequential release line (V181 → V182 → V183 → V184 → V185 → V186 → V187). The strict local-borrow checker recognizes visible initialized local `const ubyte`, `const ushort`, `const uint` and `const ulong` declarations, alongside the signed integer subset from V185/V186. A value is recorded only when proven by the bounded checked integer evaluator, non-negative and within the declared unsigned width. Declaration identity, constant chaining and pre-shadowing initializer evaluation remain in force. Equal resolved indexes still conflict; distinct exact indexes may be borrowed independently. Runtime alias tests verify writes update original array elements.

The evaluator stores indexes in a signed 64-bit representation. Therefore unsigned `ulong` values above `INT64_MAX`, unsigned negation, negative results, out-of-width values, calls, side effects, globals/statics, mutable bindings and unsupported expressions remain unknown/conservative. This is a bounded fixed-array borrow-projection analysis, not general constant propagation, general unsigned constant evaluation, bounds checking, lifetime solving or a complete borrow checker. See `docs/LANGUAGE_CORE_V187.md`, `docs/LANGUAGE_CORE_V186.md` and `docs/OWNERSHIP.md` for the exact feature boundary.

Validation is recorded in `docs/STATUS.md`; only suites actually run for this archive are claimed. No unrun platform or sanitizer qualification is implied.


## V186 — local const byte/short array-index projections

V186 continues the sequential release line (V181 → V182 → V183 → V184 → V185 → V186). The strict local-borrow checker now recognizes visible initialized local `const byte` and `const short` declarations in addition to the existing `const int` and `const long` subset. Narrow constants are accepted only when their proven value fits the declared signed width (8 or 16 bits); declaration identity and pre-shadowing initializer lookup remain in force. Distinct narrow-constant array indexes can therefore be proven disjoint, while equal indexes still conflict. Runtime alias tests verify that writes through the borrowed references update the original array elements.

This remains a bounded extension of local-borrow projection analysis. Mutable variables, unsigned integer types, globals/statics, uninitialized consts, non-integer consts, calls, side effects and unsupported expressions remain conservative may-alias paths. It does not add general constant propagation, dynamic index analysis, general lifetime solving or complete borrow checking. See `docs/LANGUAGE_CORE_V186.md`, `docs/LANGUAGE_CORE_V185.md` and `docs/OWNERSHIP.md` for the feature boundary. Compiler architecture work remains queued until Language Core acceptance gates are met.

Validation is recorded in `docs/STATUS.md`; only suites actually run for this archive are claimed. No unrun platform or sanitizer qualification is implied.

Validation is recorded in `docs/STATUS.md`; only suites actually run for this archive are claimed. No unrun platform or sanitizer qualification is implied.


## V182 — Language Core borrow diagnostics

V182 continued the existing V181 release sequence and made strict local-borrow conflict diagnostics identify the alias and source declaration line. Conflicts against signature-level `ref` parameters identify the parameter contract. The semantic acceptance/rejection rules did not change in that increment. See `docs/STATUS.md` for the V182 test record.


## V181 — bounded per-thread temporary scratch reuse

V181 adds an internal, thread-local cache for short-lived raw byte workspaces used by stable merge sort, reverse, and aliased list insertion snapshots. The cache has three size classes (64, 256 and 1,024 bytes), keeps at most one block per class per thread, and therefore retains at most 1,392 bytes per thread including block headers. Requests larger than 1,024 bytes bypass the cache and use the ordinary upstream allocator. Cached blocks are returned to the upstream allocator by `fac_runtime_trim_thread()` when ownership stacks are idle or when the thread exits. The pool is deliberately limited to raw scratch buffers; FAC-managed strings, lists, closures, class objects, reference counts, finalizers, cycle registration and the memory-tracking index continue to use their existing allocation/ownership paths. No public API signature, existing C ABI signature, language syntax, managed object layout, default FAC allocation strategy, GPU behavior or external dependency changes.

A scoped guard combines C++ stack unwinding with the FAC temporary ownership stack: a native C++ exception releases the workspace through RAII, while FAC `throw` / `longjmp` releases it through the existing temporary-drop callback. The new `runtime-temporary-scratch-pool` regression covers max-alignment, every size class, one-block-per-class retention, same-class bursts, oversized bypass, allocation-size overflow, FAC and C++ exception cleanup, stable sort/reverse results, list self-alias insertion across growth, thread-local isolation, refusal to trim while a temporary is live, and explicit trim. The optional `fac_temporary_scratch_bench` target and `make bench-temporary-scratch` measure these call sites.

Validation (Linux x86-64 / GCC 14.2): clean CMake Debug build succeeded and CTest passed 28/28, including `runtime-temporary-scratch-pool`. The full Runtime shell suite passed using the optimized Make Runtime object and the V181 CMake-built Compiler. Compiler fixtures passed 127/127 at both FAC `-O0` and `-O2`; API fixtures passed 41/41 at both modes; negative tests 132/132; limits 21/21; safe profile 430/430. API audit covered 649 built-ins and 1,001 source declarations with 5 baseline findings and 0 new findings; strict API contracts had 0 missing blocks across 939 public functions; compatibility reported 0 breaking changes and 27 baseline warnings; standards inventory covers 5 OS families and 6 architecture families; generated API docs are current (112 files). API manifest, release-version, standards, documentation and formatter checks passed. The tools test suite did not finish: `make tools-check` exceeded the 5-minute command time limit after partial output, so a complete tooling pass is not claimed. The optional Release benchmark target built. The V180/V181 comparison used nine alternating process pairs, each with seven timed samples, identical GCC 14.2 Release Runtime/harness flags and CPU 0 affinity. Timings varied by operation and process pair; no consistent end-to-end latency reduction is claimed. The verified benefit is bounded reuse of warmed 64/256/1,024-byte TLS scratch blocks without another upstream allocation for eligible requests; cache retention is at most 1,392 bytes per thread and is released by explicit trim or thread exit. A targeted Clang ASan/UBSan build exceeded the command time limit and is not claimed. Windows/macOS/ARM64 execution is not claimed.

## V180: tracked small-allocation performance and flat diagnostics index

V180 replaces the opt-in `std::unordered_map<void*, size_t>` allocation-size registry with a compact open-addressed flat table. The normal allocator path is unchanged: it still uses the platform allocator directly with no per-allocation header, lock or side-table lookup while memory tracking is disabled. When `memory.startTracking()` is enabled, allocations are indexed in contiguous slots rather than allocating one hash node per live block. The table grows geometrically, reuses tombstones, compacts deletion-heavy tables, updates keys in-place after `realloc`, and reserves empty slots so `free` and tracked `realloc` do not need to allocate. If table growth fails, the just-created payload is freed and the FAC Resource error is raised without changing existing accounting. `memory.trackedReserved()` now reports live payload bytes plus the flat table's reserved slot storage; it still excludes libc allocator metadata and process RSS.

V180 adds `runtime-memory-allocator-regression` for table growth, realloc key updates, deterministic randomized frees, tombstone reuse and accounting recovery, plus `runtime-memory-tracking-oom` to inject failure at the first table growth and verify rollback/retry. It also adds `benchmarks/allocator_small.cpp`, optional CMake target `fac_allocator_bench`, and `make bench-allocator`. No public API signature, C ABI, language syntax, object layout, default allocation strategy, GPU backend or external dependency changes.

Validation (Linux x86-64 / GCC 14.2): clean CMake Debug configure/build succeeded and CTest passed 27/27, including allocator-index growth/realloc/tombstone coverage and deterministic OOM rollback/retry. The complete Runtime shell suite passed using the optimized Make Runtime object, including allocator tests and existing thread, ownership, cycle-collector, CPU SIMD/buffer, networking, JSON, sync and UTF-8 regressions. Compiler fixtures passed 127/127 at both FAC `-O0` and `-O2`; API fixtures passed 41/41 at both modes; negative tests 132/132; limits 21/21; safe profile 430/430; tooling tests 89/89. API audit covered 649 built-ins and 1,001 source declarations with 5 baseline findings and 0 new findings; strict API contracts had 0 missing blocks across 939 public functions; compatibility reported 0 breaking changes and 27 pre-existing warnings; standards inventory covers 5 OS families and 6 architecture families; generated API docs are current (112 files). Manifest, release-version, standards, docs and formatter checks passed. The optional Release allocator benchmark target built and ran; all benchmark modes returned tracked live bytes/blocks to zero. The paired V179/V180 allocator comparison used GCC 14.2, Runtime `-O2` with identical hardening flags, benchmark `-O3 -DNDEBUG`, CPU affinity pinned to CPU 0, 160,000 blocks per sample, one warm-up, nine timed samples and five alternating process pairs. For tracking-enabled alloc/realloc/free, the median of the five process medians fell from 157.55 ns/op to 76.53 ns/op (51.4% lower latency, about 2.06x throughput). The untracked path showed overlapping run-to-run variation; no speedup is claimed there. This is a synthetic, host-specific diagnostics benchmark, not a whole-program speedup. The optimized Make Compiler build exceeded the command time limit while compiling `src/main.cpp`; the Compiler was built successfully through CMake Debug, and the FAC `-O0`/`-O2` fixture sweeps passed. A targeted Clang ASan/UBSan build also exceeded the command time limit, so sanitizer qualification is not claimed. Windows/macOS/ARM64 builds were not run.

## V179: Cycle Collector Performance & Scalability

V179 optimizes the existing trial-deletion Cycle Collector without changing its public behavior or ABI. The collector now builds a single pointer-to-index lookup table instead of maintaining separate `incoming`, `live` and `marked` hash containers. Incoming-reference counts, mark flags and traversal indices use contiguous vectors. This reduces per-object hash-node allocation and makes the mark worklist index-based while preserving conservative external-root detection, trace-error abort-before-mutation, two-phase finalization/drop, weak-handle detachment and deferred callback-error propagation. The Runtime remains CPU-only; no GPU/OpenCL code or external dependency was added.

V179 adds `runtime-cycle-collector-scalability`, which verifies sparse and dense strongly-connected graphs with and without an external root at multiple sizes. It also adds the optional `fac_cycle_collector_bench` target (`-DFAC_BUILD_BENCHMARKS=ON`) and `make bench-cycle-collector`. The benchmark measures only the collection phase after graph construction, reports median microseconds across repeated samples, checks exact collected counts, and verifies live-object/allocation counters return to baseline.

Validation (Linux x86-64 / GCC 14.2): clean CMake Debug build succeeded and CTest passed 25/25. The full Runtime shell suite passed using the optimized (`-O2`) Make Runtime object, including the new scalability regression, cycle graph safety/stress, thread/cleanup, CPU SIMD/buffer, networking, JSON, sync and UTF-8 checks. Compiler fixtures passed 127/127 at `-O0`; negative tests 132/132; limits 21/21; safe profile 430/430. Tooling tests passed 89/89; formatter, standards, release-version, API manifest and generated-document checks passed. API audit covered 649 built-ins and 1,001 source declarations with 5 baseline findings and 0 new findings; strict contracts had 0 missing blocks across 939 public functions; API compatibility reported 0 breaking changes and 27 pre-existing warnings; the standards inventory covers 5 OS families and 6 architecture families; generated API docs are current (112 files). The V178/V179 benchmark used identical GCC 14.2 `-O2 -DNDEBUG` Runtime and benchmark flags, pinned both runs to CPU 0 on the same Linux x86-64 KVM VM, and reports medians from 9 timed samples after one warm-up. V179 was faster in all ten measured cases: sparse graphs by 14.7–44.7%, dense unrooted graphs by 1.2–14.8%, a 16,384-node rooted sparse graph by 52.7%, and a 512-node rooted dense graph by 28.1%. The benchmark is synthetic and host-specific, not a promise for arbitrary applications. Full compiler `-O2` fixtures, ASan/UBSan and Windows/macOS/ARM64 execution are not claimed.

## V178: deterministic cycle-collector stress coverage

V178 adds `runtime-cycle-collector-stress`, a deterministic stress regression for repeated creation and reclamation of object graphs. Across 80 batches it allocates and collects 7,680 objects arranged as strongly-connected components with ring edges, deterministic long chords and self-edges. Alternate batches retain a real external root and verify conservative marking keeps the entire component alive until that root is released. Selected batches inject C++ and FAC errors from trace callbacks and finalizers; the test verifies failed trace snapshots leave graph liveness/allocation counts unchanged, finalizer errors are reported only after every finalizer/drop has run exactly once, the collector can be called again, and live-object plus Runtime allocation-block counters return to their initial baselines after every batch. The stress target is deterministic and uses no third-party dependency. No Runtime implementation, public API signature, C ABI, language syntax, CPU-only backend or external dependency changes.

Validation (Linux x86-64 / GCC 14.2): clean CMake Debug build succeeded and CTest passed 24/24. The full Runtime shell suite also passed with the Runtime built at `-O2`, including the new cycle stress test. Core Compiler fixtures passed 127/127 at `-O0`; negative tests 132/132, limits 21/21, safe profile 430/430 and memory-safe profile 25/25. API fixtures passed 41/41 at both `-O0` and `-O2`. The stress target passed with GCC and Clang `-O2`, and first passed as a baseline probe against V177. It completed 7,680 object lifecycles in 80 batches, with 16 trace-failure recoveries and 8 finalizer-error recoveries; finalizers/drops ran exactly once and live-object plus Runtime allocation-block counters returned to baseline after every batch. `make api-check` passed: manifest current; API audit 5 baseline findings and 0 new findings across 649 built-ins and 1,001 source declarations; strict contract audit 0 missing blocks across 939 public functions; API compatibility 0 breaking changes and 27 pre-existing warnings; standards inventory 5 OS families / 6 architecture families; generated API docs current (112 files). Tooling tests passed 89/89, formatter checks passed and release-version checks report V178 across all components. Full Compiler `-O2` sweep and ASan/UBSan are not claimed; Windows/macOS and ARM64 execution are also not claimed.

## V177: cycle-collector graph safety and recovery

V177 hardens the trial-deletion cycle collector's temporary state. A scoped state guard restores the thread-local trace context and clears the process-wide collection flag on every C++ exit path, including exceptions raised before the collector's inner recovery block. Trace callbacks execute through a narrow FAC `try` boundary and context-restoring helper. This catches FAC `longjmp` locally before it can skip the registry lock/state cleanup, and also prevents a C++ exception from leaving `g_cycle_edges` pointing at a destroyed stack vector. The new `runtime-cycle-collector-graph-safety` regression covers disconnected strongly-connected components, duplicate/self edges, conservative external roots, recovery after C++ and FAC-throwing trace callbacks, weak-handle detachment before finalizers, and reentrant `memory.collectCycles()` calls from finalizers. It verifies exact-once finalization/drop and live-object counts returning to baseline. No public API signature, C ABI, language syntax, CPU-only backend or external dependency changes.

Validation (Linux x86-64 / GCC 14.2): clean CMake Debug build succeeded; CTest passed 23/23, including `runtime-cycle-collector-graph-safety`. The complete Runtime shell suite passed, including the new cycle regression, object registry, weak references, thread/task cleanup, CPU SIMD/buffer, collections and strict UTF-8 tests. The focused cycle regression also passed when compiled with `-O2`. `make api-check` passed: API manifest current; API audit 5 baseline findings and 0 new findings; strict contract audit 0 missing blocks across 939 public functions; compatibility 0 breaking changes and 27 pre-existing warnings; standards check 5 OS families / 6 architecture families; generated API docs current (112 files). Tooling tests passed 89/89 and formatter checks passed. The new FAC-throw trace regression fails against V176 (collector remains stuck and the next collection returns zero) and passes against V177. Full compiler/API fixture sweeps and ASan/UBSan are not claimed for this release; Windows/macOS and ARM64 execution are also not claimed.

## V176: nested ownership graph recovery after child callback errors

V176 fixes a nested managed-object destruction gap. Previously, when a child object's finalizer or drop callback raised a FAC/C++ error while a parent object's generated field-drop callback was releasing that child, the child release rethrew immediately through the parent callback boundary. That could stop the parent from releasing later owned sibling fields. The Runtime now routes nested object-callback errors into the outermost active destruction error sink. Child and grandchild errors are recorded (the first error wins) while every remaining nested field and owner is released; only after the outermost object storage has been freed is the first error rethrown to FAC. The same containment applies when a nested release happens during cycle-collection callbacks. A new regression builds a root → middle → three-child ownership graph with FAC and C++ finalizer failures, verifies every finalizer/drop runs exactly once, checks live-object and allocation counts return to baseline, and repeats the failure/recovery sequence. No public API signature, C ABI, language syntax, CPU-only backend or external dependency changes.

Validation (Linux x86-64 / GCC 14.2): clean CMake Debug build succeeded and CTest passed 22/22, including `runtime-nested-ownership-recovery`. The complete Runtime shell suite passed. Core compiler fixtures passed 127/127 at both `-O0` and `-O2`; API fixtures passed 41/41 at both levels; negative tests 132/132; limits 21/21; safe profile 430/430; memory-safe profile 25/25. The BinaryReader mutation corpus passed 19 malformed cases plus a valid control at both `-O0` and `-O2`; frontend fuzz and 30,000-operation CPU buffer fuzz passed through CTest. Tooling tests passed 89/89. API compatibility reports 0 breaking changes and 27 pre-existing warnings; API audit has 5 baseline findings and 0 new findings; strict API contract audit reports 0 missing blocks across 939 public functions; standards check passed for 5 OS families and 6 architecture families; generated API docs are current (112 files); formatter and release-version checks passed. The regression fails against the V175 Runtime and passes against V176, completing the nested graph exactly once and restoring live-object/allocation counters across two repeated runs. Targeted ASan/UBSan Runtime compilation exceeded the command time limit with both GCC and Clang, so sanitizer qualification is not claimed. No Windows/macOS/ARM64 validation is claimed.

## V175: exception-safe ownership stack draining

V175 makes cleanup and temporary ownership unwinding resilient to native C++ exceptions raised by individual drop callbacks. Both stacks are now drained in LIFO order even if one callback throws: the failed entry is consumed exactly once, remaining entries are still attempted, and the original FAC or worker error remains the primary error. Worker `thread.join()` diagnostics append a bounded note when cleanup or temporary drops also failed. A dedicated regression covers native C++ callback failure and FAC `throw`, with both cleanup and temporary-drop callbacks throwing between successful callbacks; all drops must execute exactly once and the original error code must be preserved. No public API signature, C ABI, language syntax, CPU-only backend or external dependency changes.

Validation (Linux x86-64 / GCC 14.2): a clean CMake Debug build succeeded and CTest passed 21/21, including `runtime-cleanup-exception-safety`. The complete Runtime shell suite passed, including the new cleanup regression, thread/task lifecycle, parallelFor, allocation-failure rollback, CPU numeric buffers and strict UTF-8. The focused new Runtime regression also passed when compiled with `g++ -O2`; it verifies LIFO order, exactly-once drops, and preservation of the original error code for both native C++ callback exceptions and FAC `throw`. Strict API contract audit found 0 missing blocks across 939 public functions; API compatibility passed with no breaking changes; standards check passed for 5 OS families and 6 architecture families; generated docs were current (112 files); release-version check reports V175 for all components. Targeted tooling groups for contract, compatibility, docs and repository consistency passed 18/18. The complete compiler fixture sweep (`tests/run.sh -O0`) and the full tooling test suite exceeded the command time limit before completion, so complete-suite passes are not claimed. The focused ASan/UBSan build also exceeded the time limit while compiling the Runtime, so sanitizer qualification is not claimed. No Windows/macOS/ARM64 build is claimed.

## V174: worker ownership cleanup after native C++ exceptions

V174 fixes an error-recovery leak in `thread.start`. When a worker callback raised a native C++ exception, the worker boundary captured the exception and stored it for `thread.join()`, but did not unwind the FAC cleanup and temporary ownership stacks. The native thread's TLS stack storage was eventually destroyed, but registered FAC values were not dropped. The worker now preserves the bounded exception message, unwinds both ownership stacks to the worker's entry depths after leaving the C++ catch block, then stores the Resource error. FAC `throw` continues to use the existing `setjmp`/`longjmp` cleanup path. A regression registers both a cleanup callback and an owned temporary before throwing; each drop must run exactly once and `thread.join()` must still report the original Resource error. No public API signature, C ABI, language syntax, CPU-only backend or external dependency changes.

Validation (Linux x86-64 / GCC 14.2): a clean CMake Debug build succeeded and CTest passed 20/20, including the new `runtime-thread-start-join-cleanup` regression. The complete Runtime shell suite passed, including thread lifecycle, task lifecycle, parallelFor cleanup, STL allocation-failure rollback, CPU numeric buffers and strict UTF-8. The regression was also run against the V173 Runtime from the release ZIP and failed as expected because the worker skipped cleanup/temporary drops; it passes against V174. No full compiler/API optimization sweep, sanitizer qualification or Windows/macOS/ARM64 build is claimed for this release.


## V173: bounded BinaryReader identifier decoding

V173 hardens FACB record and field identifier parsing. Record type names and field names are now length-checked as 1..128 UTF-8 bytes before the reader copies or decodes their payloads. Embedded NUL and malformed UTF-8 are rejected as encoding errors. The public `beginRecord()` and `readField*()` entry points validate caller-supplied expected identifiers before consuming input; invalid API arguments remain recoverable and do not poison the reader. The existing `skipField()` and known-field paths share the same bounded identifier decoder.

The release adds deterministic mutation cases for overlong field names through both skip/read paths, overlong record names and NUL-containing record names, plus API regressions proving invalid expected names do not consume the stream. The wire format and public API signatures are unchanged. The project remains CPU-only and introduces no external dependencies.

Validation (Linux x86-64 / Clang 17): `make CXX=clang++ CXXFLAGS='-std=c++17 -O0' all` succeeded and `facc --version` reports V173. API fixtures passed 41/41 at `-O0`; the new V173 identifier-limit fixture also passed independently at `-O2`. The complete API `-O2` run exceeded the 120-second command limit while compiling an older fixture, so a full-suite `-O2` pass is not claimed. Core compiler fixtures passed 127/127 at `-O0`; the full core `-O2` run exceeded the command limit at fixture t94 and is not claimed. Negative tests passed 132/132, limits 21/21, safe profile 430/430, and the complete Runtime shell suite passed. Deterministic fuzz runs passed: frontend 5,000 cases, CPU buffer 30,000 model-checked operations, and BinaryReader 19 malformed cases plus a valid control at both `-O0` and `-O2`. A clean Clang 17 CMake Debug build succeeded and CTest passed 19/19. Standards, API manifest, API audit (5 documented baseline findings, 0 new findings), strict API contract audit (0 missing blocks across 939 public functions), API compatibility (0 breaking changes; 27 pre-existing warnings), generated API docs, and formatter checks passed. Focused tooling tests passed 37/37. The full tooling suite exceeded the command limit and is not claimed as a complete pass. No sanitizer qualification or Windows/macOS/ARM64 build is claimed.

## V172: deterministic fuzz coverage for CPU buffers and frontend parsing

V172 adds bounded, deterministic fuzz-style regression suites without introducing third-party dependencies. The frontend harness mutates valid FAC fragments and feeds arbitrary bytes (including malformed UTF-8, NUL bytes, truncated strings/comments, odd operator sequences, and excessive nesting) through the real lexer and parser. It verifies that successful lexing always produces a single terminal `End` token and that malformed programs fail with the normal `CompileError` diagnostic path rather than an unexpected exception.

The Runtime buffer harness performs 30,000 seeded operations against two CPU-backed byte buffers. It compares writes, reads, bounded copies, invalid offsets and lengths, and overlapping self-copies against a byte-vector reference model after every operation. The existing malformed BinaryReader corpus remains part of `make test-fuzz`. All fuzz suites are deterministic and bounded so they can run in ordinary CI without an external fuzzer or GPU/OpenCL installation.

V172 does not change the public API, C ABI, buffer storage format, or CPU-only backend behavior.

Validation (Linux x86-64 / GCC 14.2): `make -j2 all` succeeded with C++17 `-O0`; the Compiler reports FAC V172. The frontend fuzz harness passed 5,000 seeded cases (1,112 accepted, 2,768 lexer-rejected, 1,120 parser-rejected) and the Buffer harness passed 30,000 model-checked operations. The existing BinaryReader mutation corpus passed 14 malformed cases plus a valid control at both FAC `-O0` and `-O2`. Core compiler fixtures passed 127/127 at both optimization levels; negative tests 132/132; limits 21/21; safe profile 430/430; API fixtures 40/40 at both optimization levels. The Runtime shell suite passed, and a clean CMake Debug build completed with CTest 19/19, including both new fuzz regressions. API/standards gates and formatting passed; API audit found 5 documented baseline findings and 0 new findings, strict contract audit found 0 missing blocks across 939 public functions, and compatibility against V128 reported 0 breaking changes (27 pre-existing warnings). Tooling tests passed 89/89. No sanitizer qualification or Windows/macOS/ARM64 build is claimed.

## V171: CPU buffer boundary and transactional safety regression

V171 keeps the Runtime CPU-only and adds direct C ABI regression coverage for numeric-buffer boundaries: exact-end and zero-length ranges, zero-sized buffers, overlapping same-buffer copies with `memmove` semantics, negative/out-of-range offsets, partial trailing float64 slots, and raw-byte injected non-finite values. The tests assert that rejected numeric operations and typed writes leave destination bytes unchanged. No public API, C ABI, storage format, GPU runtime, OpenCL loader, or external dependency is added.

The API and platform documents are synchronized to the current CPU-only contract: historical `gpu.*` names remain a source-compatibility surface for host-resident CPU buffers, while hardware discovery and dispatch remain absent. No additional installation is required.

## V170: CPU-only runtime foundation and GPU backend pause

V170 removes the optional native OpenCL backend, device discovery, dynamic OpenCL loading, GPU contexts/queues/kernels, and the mock device integration tests. The runtime no longer probes for or depends on an OpenCL platform or GPU driver. The historical `gpu.*` namespace remains as a compatibility surface for CPU-backed float64 buffers and transactional numeric operations; `gpu.hardware()` is always false, `gpu.backend()` is always `software-reference`, and the legacy `gpu.openclStatus()` query returns `disabled`. CPU SIMD and portable scalar fallbacks remain available.

The V170 regression suite strengthens the CPU-only contract, float64 matrix multiplication, SIMD division failure handling, aliasing, and no-partial-write guarantees. No GPU installation or other device-specific setup is required to build or test this release.

## V166: Public two-lane SIMD API

V166 exposes the CPU SIMD foundation through a public FAC `simd` module. The API operates on float64 buffers created by `gpu.createBuffer` and adds two-lane bulk `addF64x2`, `subF64x2`, `mulF64x2`, `divF64x2` and `scaleF64x2` operations, plus `backend()`, `widthF64()` and `nativeF64x2()` capability queries. Element counts must be even. Operations stage results and validate finiteness before committing output, so odd counts, invalid ranges, division by zero and overflow return false without partial writes. In-place source/destination aliasing is supported.

In V166 this was a CPU SIMD API over the existing little-endian float64 buffer representation and had no native GPU backend. V170 retains the CPU SIMD ABI and removes the later experimental native device backend. See `docs/SIMD_V166.md` and `docs/STATUS.md`.

## V165: Cross-platform CI and SIMD-friendly float64 compute foundation

V165 adds bounded block decode/encode paths for the software-reference `gpu.addF64` and `gpu.scaleF64` operations on little-endian IEEE-754 binary64 hosts. x86-64 and AArch64 use two-lane 128-bit float64 vector operations through the GCC/Clang vector extension, with a scalar tail; other architectures use a scalar block kernel, and big-endian/non-IEEE hosts retain the original byte-wise scalar path. Output is staged and fully validated before destination bytes are written, preserving no-partial-write behavior and supporting in-place aliases. This is a CPU optimization foundation only: `gpu.hardware()` remains false and no GPU device/queue/shader backend is added.

The CMake CI matrix includes Linux ARM64 (`ubuntu-24.04-arm`) and macOS ARM64 (`macos-15`) host build/runtime CTest smoke coverage, alongside Linux x86-64 GCC/Clang and the existing Windows x64 lane. Workflow configuration is not evidence of a pass until GitHub Actions completes. See `docs/SIMD_V165.md`, `docs/PORTABILITY.md` and `docs/STATUS.md`.

## V164: Managed payload-enum partial moves

V164 extends the existing projection-aware `move()` support so a directly owned local value struct can transfer a final managed payload-enum field, including nested paths such as `move(envelope.detail.payload)` when each intermediate field is a value struct. The enum representation is copied into an owned temporary, and its source field is zero-initialized. Generated recursive drop callbacks therefore release the remaining fields without double-releasing the moved payload. Use-after-move and repeated/overlapping moves remain rejected by the existing CFG move analysis; assigning a new enum value to the moved field reinitializes that projection.

The scope remains deliberately bounded: no unit-enum, scalar, raw-pointer, array/index, class/object, parameter, borrowed-alias or heap/indirect-root moves are added. No reference return syntax, general lifetime parameters, ABI changes or public Runtime API changes are introduced. This is not a complete lifetime solver or a general runtime drop-flag bitmap.

Validation is recorded in `docs/STATUS.md` and `docs/MEMORY_SAFETY_V164.md`. The test fixture covers nested extraction of `Option<string>.Some`, reading sibling fields, reinitializing the moved field with `Some` and `None`, and negative checks for use-after-move and double move.

## V163: Compiler keyword lookup fast path

V163 replaces parser keyword/type membership tables based on `std::set<std::string>` with immutable `std::unordered_set<std::string_view>` tables and folds primitive type words into the reserved-word lookup. The narrow 4,000,000-lookups benchmark measured 113.514 ms on V162 and 47.069 ms on V163 (2.41x faster for that workload); broader parser timing did not establish a whole-compiler speedup. See `docs/COMPILER_PERFORMANCE_V163.md`.

---

---

# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V162

## V162: Bounded parallelFor queues and Runtime back-pressure

V162 hardens the reusable Runtime worker pool. Each worker queue is capped at 64 pending job tickets. A caller that would exceed the bound waits on a capacity condition variable until workers dequeue queued tickets; shutdown wakes blocked submitters. The pool mutex protects the queue-capacity predicate and the selected worker slots, and queue publication remains all-or-nothing with rollback if deque allocation fails. The public FAC API and C ABI are unchanged. The pressure regression launches 80 simultaneous callers, each submitting 96 callbacks, and verifies exact-once completion under back-pressure.

Validation (Linux x86-64): the Runtime shell suite passed with Clang 17 at `-O2`, excluding only the compiler-driver integration section because the compiler frontend build exceeded this environment's execution limit. The suite included the new 80-caller bounded-queue stress case, nested `parallelFor`, callback errors, OOM rollback, weak-handle ABA, HashMap/Graph, sync channel and HTTP framing checks. Focused GCC 14.2 ASan/UBSan/LSan and ThreadSanitizer runs of the new pool stress test both passed. Warm-pool before/after medians were within 1.5% for 8- and 32-item batches; no throughput gain is claimed. No Windows/macOS or 32-bit build is claimed.

## V161: Runtime weak-handle fast path and atomic slot state

V161 improves FAC Runtime weak-reference hot paths without changing the public C ABI or the pointer-sized opaque token format. Weak slots now live in lazily allocated, stable blocks. Each slot combines its generation, object-anchor bit, and external-handle count in one atomic state word, so `weak_alive`, `weak_retain`, and `weak_release` no longer take the global object-lifecycle mutex on their normal path. Generation is checked by the same compare-and-exchange used to change the handle count, preventing a stale token from changing a reused slot. `weak_lock` still synchronizes with object destruction because it promotes a weak value to a strong object reference.

The trade-off is that allocated weak-slot blocks remain reserved until process exit; blocks are created only as the slot high-water mark grows and are reused after handles expire. The 64-bit token uses 23 slot bits / 24 generation bits, and the 32-bit token uses 12 slot bits / 19 generation bits. A slot is retired rather than allowing generation wrap. The public token remains opaque and must not be dereferenced or used in pointer arithmetic.

Validation (Linux x86-64): Runtime tests passed with Clang 17 at `-O0`, including stale/invalid handle rejection, ABA slot reuse, concurrent weak lock/release, and a 5,000-slot multi-block/reuse stress test. Focused weak/object/refcount tests passed GCC 14.2 ASan/UBSan/LSan and ThreadSanitizer runs. A paired GCC 14.2 C++17 benchmark (Runtime `-O2 -DNDEBUG`, harness `-O3 -DNDEBUG`, three alternating process pairs, nine samples of 3,000,000 iterations) measured `weak_alive` at 10.46 ns/op on V159 and 2.26 ns/op on V161 (4.63x faster), and weak retain+release at 19.00 ns/pair and 8.33 ns/pair (2.28x faster). These are single-thread microbenchmarks, not whole-application speed claims. The full compiler build completed at `-O0`; the Runtime shell suite passed. Windows/macOS and 32-bit builds are not claimed as tested.

## V159: frozen byte buffers and zero-copy ByteView decoding

V159 adds an explicit immutable-sharing path for FACB readers. `ByteBuffer.freeze()` seals a buffer against append/set/clear operations. `serialize.BinaryWriter.toFrozenBuffer()` finalizes the writer, appends the V2 CRC32 trailer in-place when needed, freezes the backing buffer, and returns a retained `ByteBuffer` object. A finalized writer rejects further writes; `toBytes()` remains available and returns an independent list copy, including after finalization.

`deserialize.BinaryReader.fromFrozenBuffer(buffer)` creates a reader that retains the already-frozen buffer without copying the encoded stream. `readByteView()` / `readRawByteView()` and `readFieldByteView()` return `bytes.ByteView` windows over that same backing buffer. A ByteView exposes only `size`, `isEmpty`, `get`, `slice`, and explicit `toList`; `slice()` is another zero-copy view and `toList()` is the opt-in copy. The view retains the frozen buffer, so it remains valid after the reader variable goes out of scope. The legacy list constructor and `readBytes()` copy APIs remain source-compatible.

ByteView intentionally requires a frozen buffer. This avoids a mutable-alias hazard where a caller could change the backing bytes after CRC validation. The list-based BinaryReader constructor still copies into a private buffer and freezes it. FACB V1/V2 wire bytes and the Runtime ABI are unchanged.

`make bench-serialization` runs a reproducible 64 KiB workload comparing the legacy list-copy read path, frozen-buffer `ByteView`, and JSON decode. It verifies identical checksums and reports median wall time plus FAC allocator-tracked allocation counts/peak. These allocator counters exclude STL/libc allocations, allocator metadata outside the FAC tracker, and OS RSS; results are workload- and machine-specific, not a general performance claim.

Validation (Linux x86-64 / Clang 17): API regression passed 37/37 at both `-O0` and `-O2`; the V159 fixture also passed strict-safe and secure compilation. The 64 KiB benchmark median over five process runs (FAC Runtime `-O2`, generated program `-O2`) measured `readBytes` 32.298 ms / 108 allocations / 556.04 KiB peak, `ByteView` 9.341 ms / 96 allocations / 0.28 KiB peak, and JSON decode 132.104 ms / 36 allocations / 277.93 KiB peak. The checksum matched across all paths; ByteView was 3.46x faster than the copy path and 14.14x faster than this JSON decode workload on this host. FAC tracked allocation counters are not total RSS and exclude STL/libc. API audit found five baseline findings and 0 new findings; contract audit found 939 public source functions with no missing tags; compatibility against V128 reports 0 breaking changes and 27 existing warnings. Manifest, standards, version, and formatter checks passed. Windows/macOS and full non-API suites are not claimed as tested.

## V158: fail-closed BinaryReader and malformed FACB hardening

V158 hardens `deserialize.BinaryReader` without changing FACB V1/V2 wire formats or Runtime ABI. A malformed header, CRC/schema/version mismatch, invalid UTF-8, truncated value, duplicate field/map key, unknown field tag, invalid boolean, impossible field count, overflow during legacy narrowing, or trailing bytes marks the reader failed. `isFailed()` exposes this state. Any subsequent decode operation is rejected; callers must create a new reader rather than continue from a partially consumed cursor. API misuse such as reading before the header remains a recoverable InvalidArgument error and does not poison the reader.

`beginRecord()` also rejects impossible field counts against the remaining bytes using the minimum encoded field size. This bounds invalid count declarations before a caller loops over fields. The release adds a deterministic FACB mutation corpus with valid CRC32 trailers to exercise malformed record bodies through the real FAC decoder, rather than relying only on CRC rejection.

Custom migration hooks remain ordinary FAC calls. If a hook throws, the generated decoder returns no partially migrated Struct; side effects performed by user hooks are not rolled back, so migration hooks should avoid external mutation until they succeed.


Validation (Linux x86-64 / Clang 17): compiler and Runtime build completed; all eight serialization regression fixtures from V152–V158 passed at both `-O0` and `-O2`. The API run completed 36/36 at both optimization levels before a final API-misuse classification refinement; after that refinement the serialization-specific 8/8 subset and the mutation corpus were rerun and passed at both levels. The V158 mutation corpus contains 14 malformed FACB V2 bodies with recomputed valid CRC32 trailers plus one valid control; all cases passed at `-O0` and `-O2`. Polygon SAT oracle passed 60/60 and SpatialHash oracle passed 70 queries over 80 objects. Focused FacSerde generator tests passed 19/19. Manifest has 988 source declarations; API audit found five baseline findings and 0 new findings; contract audit found 927 public functions with 0 missing contract tags; compatibility against V128 reports 0 breaking changes and 27 existing warnings. Manifest, generated docs, formatter, standards and version checks passed. Full tooling and non-API compiler/runtime suites, Windows/macOS builds and execution are not claimed as passing.

## V157: field renames, checked numeric type migration and migration hooks

V157 extends `tools/facserde.py` while keeping the FACB V1/V2 binary headers and existing field tags unchanged. A field may declare a historical wire name with `renameFrom=OLD renameSince=N`; generated encoders continue to write the old name before N and the current field name from N onward. Generated decoders choose the expected wire name from the stored schema version, so names remain deterministic and field order/type checks remain strict.

Numeric migrations are explicit and currently limited to signed `i32` ↔ `i64`. Use `convertFrom=i32 convertSince=N` on a current `long` field to widen old Int32 payloads, or `convertFrom=i64 convertSince=N` on a current `int` field to narrow old Int64 payloads. Older schema encoders continue writing the historical tag; `BinaryWriter.writeFieldI32` checks Int32 range and `BinaryReader.readFieldI32FromI64` rejects values outside that range with IntegerOverflow (17). No truncating conversion is generated. Renamed/converted fields require `default=VALUE` as an explicit safe initializer, although the initializer is replaced whenever the payload contains the field.

For business-specific transformations, declare a hook outside the Struct: `# @serde-migrate struct=Wallet from=1 function=migrateWalletV1` and implement `public function struct Wallet migrateWalletV1(struct Wallet value)`. The generator verifies the hook signature and emits calls in ascending version order after structural decoding. A payload at version 1 runs all hooks with `from` values >=1; a V2 payload skips the V1 hook. Hooks are ordinary FAC functions and may implement domain-specific normalization or calculation.

Example input/generated pair: `examples/api/25_field_migration_source.facsrc` and `examples/api/25_field_migration_generated.fac`; regression input/generated pair: `tests/api/a34_v157_field_migration_source.facsrc` and `tests/api/a34_v157_field_migration.fac`. Generator unit tests: `python3 -m unittest tests.tools.test_tools.FacSerdeGeneratorTests`.

Validation (Linux x86-64 / Clang 17): compiler and Runtime rebuilt at `-O0`; full API regression passed **34/34 at `-O0` and 34/34 at `-O2`**. The V157 test fixture and generated example both compiled and ran, printing `fac-field-migration-ok`; strict-safe and secure compile checks passed. Focused FacSerde generator tests passed **19/19**. Manifest contains 987 source declarations; API audit reports five baseline findings and **0 new findings**; contract audit reports 926 public functions with **0 missing contract tags**; compatibility against V128 reports **0 breaking changes / 27 pre-existing warnings**. Standards, manifest, generated docs, formatter and version checks passed. The complete tooling suite exceeded the runner time limit and is not claimed as passing; full non-API compiler/runtime suites and Windows/macOS builds were not run.

Limitations: automatic migration hooks are explicit functions, not reflection; supported numeric conversion is limited to signed `i32`/`i64`; rename/type migrations require explicit defaults and stable append-only field order. This is Linux-host validation, not cross-platform certification.

## V156: append-only schema evolution and optional Struct fields

V156 extends the `tools/facserde.py` build-time Struct serializer generator. Fields may be annotated with `# @serde since=N default=VALUE`; a generated encoder can emit older schema versions by passing `schemaVersion`, while a generated decoder reads earlier versions and supplies defaults for fields not yet introduced. Unknown trailing fields from later schema versions are skipped with the existing validated `BinaryReader.skipField()` path. Existing fields must remain in their original order and must not change type; new fields are append-only.

Example:

```fac
struct Player {
    var int id
    # @serde since=2 default=0
    var int level
    # @serde since=3 default="guest"
    dyn string title
}
```

`fac_encode_Player(value, 1)` writes the V1 prefix, `fac_encode_Player(value, 2)` writes through `level`, and the default call writes the current V3 shape. `fac_decode_Player(bytes)` accepts versions 1..65535, applies defaults to fields newer than the payload, then skips unknown trailing fields. Optional defaults currently support scalar byte/boolean/integer/floating/string fields only. Optional nested Structs, collection defaults, field reordering/renaming, in-place type changes, explicit migrations and arbitrary unknown field ordering are not supported. This is build-time source generation; compiler grammar, Runtime ABI and FACB V1/V2 wire headers are unchanged.

Regression: `tests/api/a33_v156_schema_evolution.fac`; example input/generated pair: `examples/api/24_schema_evolution_source.facsrc` and `examples/api/24_schema_evolution_generated.fac`; generator tests: `python3 -m unittest tests.tools.test_tools.FacSerdeGeneratorTests`.

Validation (Linux x86-64 / Clang 17): compiler and Runtime built at `-O0`; API regression **33/33 at `-O0` and 33/33 at `-O2`**. The schema-evolution fixture ran at both optimization levels, passed strict-safe and secure compile profiles, and the V155 nested-Struct fixture still ran. Eleven focused generator tests passed. Full tooling and non-API compiler/runtime suites, Windows/macOS builds and execution were not run.

---

## V155: generated Struct serialization and nested Struct values

V155 adds `tools/facserde.py`, a source generator that reads FAC `struct` declarations and appends ordinary FAC `fac_encode_Type()` / `fac_decode_Type()` helpers backed by `serialize.BinaryWriter` and `deserialize.BinaryReader`. The generated code uses the existing FACB V2 format, explicit field names/types, schema IDs and CRC32 checks; it never writes native Struct memory, pointers, padding or compiler-specific layout.

Nested Struct members are encoded as bounded byte fields containing an independent FACB V2 stream. Each nested value therefore has its own schema ID, version and CRC32. Primitive fields supported by the generator are byte, boolean, int, long, float, double and string; it also supports `list var int`, `list dyn string`, `hashmap dyn string, string`, and nested `struct Type` members. Unsupported fields fail generation instead of being silently omitted.

Generate a source file:

```sh
python3 tools/facserde.py models.fac build/models_serde.fac --schema-prefix game.save --version 1
./build/facc build/models_serde.fac -o build/save
```

The generated file includes the original source declarations plus helper functions; compile/use that generated file in place of the original model source to avoid duplicate Struct declarations. `--check` validates a model file without writing output. The generator requires public/default-accessible fields and the compiler's field-order Struct constructor. Private/protected fields, explicit constructors, recursive Struct graphs, enums, arrays, pointers, arbitrary collection types and automatic migrations are not supported. This is build-time code generation, not runtime reflection or automatic compiler magic.

Regression: `tests/api/a32_v155_struct_serde.fac`; generated example: `examples/api/23_struct_serde_generated.fac`; generator input: `examples/api/23_struct_serde_source.facsrc`; tooling tests: `tests/tools/test_tools.py`.

Validation (Linux x86_64 / Clang 17): compiler and Runtime built at `-O0`; full API regression passed **32/32 at `-O0` and 32/32 at `-O2`**. The generated nested Struct example compiled and ran at both levels and compiled under `--strict-safe --no-trust-stdlib` and `--secure --no-trust-stdlib`. Seven generator unit tests passed. The full tooling suite exceeded the 120-second runner limit (the seven facserde-specific unit tests passed); Windows/macOS builds and full non-API compiler/runtime suites were not run. CRC32 detects accidental corruption only; it is not authentication.

---

## V153: binary serialization v2, schema evolution, floating-point and integrity

V153 keeps the existing FACB v1 writer and reader source-compatible and adds an explicit FACB v2 path. `BinaryWriter.beginV2(schemaId, schemaVersion)` writes a distinct binary-format version, a caller-controlled 16-bit schema version, and a CRC32 trailer. `BinaryReader.readHeaderV2(schemaId, minSchemaVersion, maxSchemaVersion)` validates the complete CRC before exposing fields and returns the schema version so application code can apply explicit defaults/migrations. It does not attempt automatic struct migration.

Both formats support IEEE-754 `writeF32`/`readF32` and `writeF64`/`readF64` in little-endian order. Finite values, infinities and signed zero are preserved; NaNs are normalized to a canonical quiet NaN. Binary64 serialization is implemented using the FAC numeric operations rather than copying host-native struct memory. CRC32 detects accidental corruption but is not authentication or tamper protection; use a cryptographic MAC/signature when the source is untrusted.

V1 stays unchanged: `begin()` still writes FACB format 1 and `readHeader()` reads it. V2 is deliberately opt-in. V152 readers do not understand V2 files; V153 readers continue to read V1. Both paths retain the 64 MiB stream and 16 MiB field caps. Schema version compatibility is an application contract: set the accepted range and handle older versions explicitly.

Regression: `tests/api/a29_v152_binary_serialization.fac` (V1 compatibility) and `tests/api/a30_v153_binary_serialization_v2.fac`; example: `examples/api/21_binary_serialization_v2.fac`; details: `docs/LIBRARIES.md`, `docs/STATUS.md`, `docs/api/serialize.md`, `docs/api/deserialize.md` and section 41 of `syntax/fac_spec.fac`.

Validation (Linux x86_64 / Clang 17): compiler and Runtime rebuilt at `-O0`; full API regression passed **30/30 at `-O0` and 30/30 at `-O2`**. The new V2 fixture passed at both optimization levels and ran under both `--strict-safe --no-trust-stdlib` and `--secure --no-trust-stdlib`; the V2 example compiled and ran. An independent Python `struct`/`zlib` check matched the emitted IEEE-754 bytes for binary32 1.5 and binary64 π, and verified the CRC-32/ISO-HDLC trailer. Standards validation, API manifest freshness, API audit (5 baseline findings, 0 new), contract audit (891 public source functions, 0 missing tags), compatibility (0 breaking changes, 27 pre-existing warnings), generated API docs, formatter and version checks passed. Full non-API compiler/runtime suites and tools-check were not run; Windows/macOS builds and execution were not tested. This is a Linux-host validation, not cross-platform certification.

---

## V152: versioned binary serialization

V152 adds `serialize.fac` and `deserialize.fac` as a separate binary-data path alongside the existing typed JSON API. `BinaryWriter` and `BinaryReader` use a FACB header with a format version, reserved flags and caller-supplied schema identifier. Integer fields use fixed-width little-endian encodings; strings and byte arrays use bounded U32 length prefixes. The reader validates magic, version, flags, schema, canonical booleans, byte ranges, truncation, UTF-8 and trailing bytes.

The format is explicit and field-ordered: applications must write/read fields in the same order and evolve schema identifiers/versioning deliberately. It does not serialize native object memory, pointers, arbitrary object graphs or floats, and does not provide encryption, authentication, checksums, compression or automatic schema migration. Total stream size is capped at 64 MiB and individual string/byte fields at 16 MiB.

Regression: `tests/api/a29_v152_binary_serialization.fac`; example: `examples/api/20_binary_serialization.fac`; details: `docs/LIBRARIES.md` and section 40 of `syntax/fac_spec.fac`.

Validation (Linux / Clang 17): API regression 29/29 at both `-O0` and `-O2`; strict-safe and secure compile checks passed; the example compiled and ran; API audit had 0 new findings, contract audit had 0 missing tags, compatibility had 0 breaking changes; formatter and version checks passed. Full language/runtime suites and Windows/macOS builds were not run for V152.

## V151: SQLite database driver and prepared SQL statements

V151 adds three source modules: `database.fac` defines reusable connection options; `sqlite.fac` wraps a real SQLite database connection and prepared statements; `sql.fac` provides identifier quoting, numbered placeholders and escaped `LIKE` contains patterns. The Runtime dynamically loads the system SQLite library (`sqlite3.dll` on Windows, `libsqlite3` on POSIX), so FAC has no link-time SQLite dependency. `sqlite.available()` lets an application detect the optional backend before use.

`sqlite.Database` supports `execute` for trusted SQL/DDL batches, `prepare` for parameterized statements, `changes`, `lastInsertRowId`, busy timeout configuration, explicit close and actual SQLite `begin`/`commit`/`rollback` transactions (`BEGIN IMMEDIATE`). `Statement` supports signed 64-bit integers, doubles, UTF-8 text and SQL NULL bindings, `step`, reset, clear-bindings and typed column access. Bind values instead of concatenating user input into SQL. `execute` returns void; use `changes()` for the last INSERT/UPDATE/DELETE row count.

Scope and caveats: this is a synchronous SQLite driver, not an ORM, connection pool, async database framework or cross-engine SQL abstraction. The system SQLite shared library must be installed at runtime. The string-based API is NUL-terminated UTF-8: embedded NUL and BLOB binding are not supported yet; `columnText` maps SQL NULL to an empty string, so check `columnType` to distinguish them. Individual native SQLite calls use `SQLITE_OPEN_FULLMUTEX`, but callers must not interleave logical transactions on one connection across threads. `transaction.fac` remains an in-memory StateStore transaction and is not ACID. Windows/macOS runtime loading and external platform builds require separate validation.

Regression: `tests/api/a28_v151_sqlite_database.fac`; targeted checks: `make test-sqlite`; example: `examples/api/19_sqlite_database.fac`; details: `docs/LIBRARIES.md`, `docs/STATUS.md`, `docs/api/` and section 39 of `syntax/fac_spec.fac`.

Validation (Linux / Clang 17): V151 compiler and Runtime rebuilt at `-O0`; targeted SQLite integration passed at `-O0` and `-O2`, and its fixture compiled under strict-safe and secure profiles. Full API regression passed 28/28 at both optimization levels. API manifest/docs, API audit (5 baseline findings, 0 new), contract audit (860 public source functions, 0 missing contract tags), compatibility (0 breaking changes) and formatter/version checks passed. The `tools-check` suite reached the runner time limit and is not claimed as passing; full non-API suites and Windows/macOS builds were not run. See `docs/STATUS.md` for full validation scope and caveats.

---


## V150: optional TLS transport and integrated WebSocket upgrade

V150 adds an optional native `tls` module backed by dynamically-loaded OpenSSL 1.1.1+ / 3.x on POSIX systems. OpenSSL is not a link-time dependency, so builds without OpenSSL still work and `tls.available()` reports whether the backend can be loaded. TLS 1.2 is the minimum. Client connections require system CA trust and DNS hostname verification; only ASCII DNS names are supported (no IP-literal or IDN verification). Server connections load a PEM certificate and private key. Successful wrapping transfers ownership of the TCP socket to the TLS handle. Windows remains unavailable in this release pending a separate Schannel backend.

`tls_stream.fac` provides the owning `TlsStream` wrapper with byte/text send, exact byte receive, strict CRLF line receive, negotiated version/cipher inspection, `detach()` and idempotent close. Configure `net.setTimeout(socket, ms)` before wrapping. TLS I/O is blocking, synchronous and single-owner; there is no async integration or total-operation deadline.

`websocket.fac` now creates client upgrade requests with a cryptographic nonce, verifies the server's `Sec-WebSocket-Accept` in constant time, and performs complete HTTP/1.1 Upgrade on raw TCP or `TlsStream` connections. Server-side upgrade validates bounded CRLF headers and rejects duplicate/invalid header names, transfer encoding and non-empty content lengths. After a successful upgrade, transfer the `TlsStream` handle with `detach()` into `WebSocketConnection(..., tlsTransport=true)`; cleartext TCP remains the default. The connection keeps client masking/server unmasked semantics, fragmentation, text UTF-8 validation, ping/pong and close handling. Extensions, subprotocol negotiation, permessage-deflate, async I/O and a complete high-level server/router are not included.

Regression: `tests/api/a27_v150_tls_websocket_upgrade.fac`; runtime TLS loopback: `make test-tls`; example: `examples/api/18_tls_websocket.fac`; details: `docs/LIBRARIES.md`, `docs/STATUS.md`, `docs/api/` and section 38 of `syntax/fac_spec.fac`.

Validation (Linux / Clang 17): API regression 27/27 at `-O0` and `-O2`; Runtime regression and tools tests 70/70 passed; optional TLS test verified TLS 1.3, hostname mismatch rejection and a FAC TLS-WebSocket loopback at both optimization levels. The main language suite passed 127/127 at `-O0`; full `make test` timed out during its `-O2` language suite at `t47_entity_world`, so the complete target is not claimed. API/contract/compatibility, standards, formatter, docs and version checks passed. Windows/macOS and external-server interoperability were not tested; details and all caveats are in `docs/STATUS.md`.

---

# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V156

## V149: byte-oriented TCP APIs and WebSocket transport

V149 adds `net.sendBytes(socket, list dyn int)` and `net.recvExactBytes(socket, count)` for bounded binary-safe TCP I/O, plus `string.toBytes` / `string.fromBytes` for explicit UTF-8 conversion. Byte lists are `list dyn int` with values in `[0,255]`; socket byte-list operations are capped at 16 MiB per call. `string.fromBytes` validates canonical UTF-8 and rejects overlong forms, surrogates, truncated sequences and values above U+10FFFF.

`websocket.fac` now includes `WebSocketConnection`, which takes ownership of a connected TCP socket and sends/receives complete RFC 6455 frames. Client frames are cryptographically masked; server frames are unmasked. `receiveMessage()` assembles fragmented text/binary messages, automatically replies to ping, ignores pong and echoes a close frame before closing the socket. Close frames validate the RFC status-code ranges and UTF-8 reason; text messages are UTF-8 validated. This is synchronous, frame/message-level TCP transport: the caller still performs the HTTP Upgrade handshake, applies socket timeouts with `net.setTimeout`, and must provide a trusted transport. TLS, extension negotiation, permessage-deflate, asynchronous I/O and server/client HTTP handshake orchestration are not included.

Validation (Linux / Clang 17): see the V149 validation results in `docs/STATUS.md`. Windows/macOS builds and the full non-API test suite are not claimed unless explicitly recorded there.

---

# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V148

## V148: WebSocket protocol codec and acknowledged message queue

V148 adds two preview source modules without changing compiler grammar, built-in APIs, Runtime implementation or Runtime ABI. `websocket.WebSocketHandshake` validates the RFC 6455 HTTP/1.1 upgrade header set, computes `Sec-WebSocket-Accept` using the Runtime SHA-1/Base64 primitives and builds the 101 response header block. `WebSocketFrameCodec` encodes/decodes one complete frame at a time, supports 7/16/64-bit payload lengths, client masking/unmasking, strict endpoint mask expectations and bounded payloads; it rejects nonzero RSV bits, reserved opcodes, malformed lengths and invalid control-frame constraints. It does not own a socket, convert raw TCP strings to byte lists, assemble fragmented messages, validate text UTF-8, negotiate extensions or manage ping/pong/close state. Therefore it is a protocol codec, not a WebSocket client/server transport.

`message_queue.MessageQueue` is a bounded in-memory point-to-point work queue with caller-supplied monotonic millisecond time, visibility leases, explicit `claim`/`ack`/`nack`, max delivery attempts, bounded dead-letter retention, a per-message payload byte cap and manual dead-letter redrive. Expired leases can be reclaimed; exhausted messages move to the dead-letter list. It is not durable, distributed, exactly-once or thread-safe. Active queue count, per-message payload bytes (64 KiB by default, 16 MiB maximum) and dead-letter capacity are independently bounded; when the dead-letter list is full, expiration processing leaves the affected message active and reports a Resource error.

Regression: `tests/api/a25_v148_websocket_message_queue.fac`; example: `examples/api/16_protocol_and_queue.fac`; details: `docs/LIBRARIES.md`, `docs/api/` and section 36 of `syntax/fac_spec.fac`.

Validation (Linux / Clang 17): clean Compiler and Runtime rebuild reports V148; the full API regression suite passes **25/25 at `-O0` and 25/25 at `-O2`**; the new fixture compiles under `--strict-safe --no-trust-stdlib` and `--secure --no-trust-stdlib`; the example compiles/runs at both optimization levels with matching output; `tools-check` passes **70/70**; API manifest/docs, contract audit, compatibility, formatter, standards and version checks pass. API audit reports 5 baseline findings and 0 new; contract audit reports 791 public source functions and 0 missing tags; compatibility against V128 reports 0 breaking changes, 27 existing warnings and 464 accumulated additions. An attempted full Runtime regression did not finish within the 300-second runner window (the last visible completed check was the parallelFor regression), so no full Runtime/non-API suite pass is claimed. TLS transport, live WebSocket socket exchange and Windows/macOS builds are not claimed.

---

## V147: networking and service observability

V147 adds preview source modules `http_server`, `rpc`, `pubsub`, `health` and `telemetry`, plus byte-accurate `net.recvExact`, CRLF/EOF-aware `net.recvLineStrict`, and `string.byteLength` primitives for HTTP framing. `http_server` is a bounded synchronous HTTP/1.x server over the existing TCP runtime: one request per connection, Content-Length request bodies up to 8 MiB, no chunked requests, keep-alive, TLS or callbacks. `rpc.JsonRpcCodec` builds and inspects JSON-RPC 2.0 envelopes but does not dispatch methods or provide a transport. `pubsub.PubSubBus` is a bounded in-process polling bus with per-subscriber queue copies. `health.HealthRegistry` stores caller-reported states; `telemetry.TelemetryRegistry` stores counters, gauges and sample summaries and exports simple Prometheus text. None of these modules is a distributed service, background exporter or thread-safe shared registry. TLS and WebSocket are deferred: the current runtime has no TLS socket abstraction and no complete binary frame reader.

Regression: `tests/api/a24_v147_networking_services.fac`; example: `examples/api/15_networking_services.fac`; details: `docs/LIBRARIES.md`, `docs/api/` and section 35 of `syntax/fac_spec.fac`.

---

## V146: application framework primitives

V146 adds five preview source-level modules without changing compiler grammar, built-in APIs or the Runtime ABI. `rate_limit.FixedWindowRateLimiter` enforces a deterministic caller-clock fixed window; the window starts on the first call and is not aligned to wall-clock minutes. `circuit_breaker.CircuitBreaker` tracks closed/open/half-open state, counts admitted in-flight calls and allows one half-open probe after the cooldown; callers execute operations and explicitly report success/failure. `middleware.MiddlewarePipeline` stores enabled named middleware descriptors in stable ascending-priority order but does not invoke functions. `service.ServiceRegistry` tracks stopped/running/paused/failed lifecycle state and failure messages but does not construct or supervise services. `di.InstanceRegistry<T>` stores pre-created values in a typed registry and returns `Option<T>`; each registry stores one static T using a linear key list and does not provide factories, type erasure, automatic dependency graphs or object lifetime scopes. These APIs are in-memory and not thread-safe. Regression: `tests/api/a23_v146_framework_primitives.fac`; example: `examples/api/14_application_framework.fac`; details: `docs/LIBRARIES.md` and section 34 of `syntax/fac_spec.fac`.

## V145: application-service primitives

V145 adds six source-level modules without changing compiler grammar, built-in APIs or the Runtime ABI. `cache.CacheStore` supports caller-clock TTL entries, lazy expiry and pruning; callers provide a non-negative millisecond clock for deterministic behavior. `retry.RetryPolicy` calculates total-attempt limits and capped exponential delays, but deliberately does not invoke callbacks or sleep. `transaction.StateTransaction` stages key/value writes and removals for `StateStore`, supports read-your-writes and explicit commit/rollback, but is not an ACID transaction and cannot undo a partially applied commit. `router.RouteRegistry` maps HTTP-method/path patterns to handler names, prefers exact routes and otherwise chooses the longest trailing `/*` prefix; it resolves names and does not execute handlers or run an HTTP server. `scheduler.PollScheduler` returns due task identifiers on caller polling; repeating tasks coalesce missed ticks and reschedule from the poll time. `workflow.Workflow` provides declared finite-state transitions and an in-memory state history. These classes are in-memory and not thread-safe. Callback-based middleware, DI and service factories remain deferred until FAC has a stable callable registry and type-erased object lifetime contract. Regression: `tests/api/a22_v145_application_services.fac`; example: `examples/api/13_application_services.fac`; details: `docs/LIBRARIES.md` and section 33 of `syntax/fac_spec.fac`.

## V144: application architecture helpers

V144 adds four source-level modules without changing compiler grammar, built-in APIs or the Runtime ABI. `events` provides an explicit FIFO polling queue (`EventQueue`), not callback-based event dispatch. `observer` provides generic `ObservableValue<T>` revision tokens for polling change detection, not automatic callbacks. `state` provides an in-memory string-keyed `StateStore` with typed integer/boolean accessors and a mutation revision. `validation` accumulates field-level scalar/string validation errors for required values, length bounds, integers, numbers, allow-lists and conservative email-like syntax. These APIs are not thread-safe unless externally synchronized. Callback-driven EventBus/Observer, DI container and Service factories are deliberately deferred until FAC has a stable callable/object-erasure and lifetime contract. Regression: `tests/api/a21_application_architecture.fac`; example: `examples/api/12_application_architecture.fac`; full notes: `docs/LIBRARIES.md` and section 32 of `syntax/fac_spec.fac`.

## V143: XML, template rendering and type introspection helpers

V143 adds three source-level modules without changing compiler grammar or Runtime ABI. `xml` parses a deliberately bounded element-only XML subset with indexed child paths, comments, an optional declaration and the five predefined XML entities; attributes, namespaces, DTDs, CDATA and processing instructions are rejected. `template` renders explicit `{{name}}` placeholders from a caller-provided map, preserves missing placeholders by default, offers strict missing-key errors, and has an HTML text-escaping mode for inserted values; it does not evaluate expressions or provide loops/includes. `reflection` wraps the existing `typeof`, `type` and `DSof` builtins with generic helpers; the source library itself is not a runtime reflection object. Separately, V220 compiler intrinsics provide bounded compile-time queries for public non-static instance fields of resolved struct/class records; see `docs/STRUCTURAL_REFLECTION_V220.md`. See `docs/LIBRARIES.md` and section 31 of `syntax/fac_spec.fac`; regression: `tests/api/a20_xml_template_reflection.fac`; example: `examples/api/11_xml_template_reflection.fac`.

## V142: decimal, TOML, YAML and data-schema libraries

V142 adds four source-level modules without changing compiler grammar or the Runtime ABI. `decimal` provides six-place fixed-point decimal values stored as signed Int64 millionths; it does not use binary floating point and exposes scaled-integer arithmetic to avoid object-argument limitations in the current compiler. `toml` reads/writes a deliberately small scalar/table subset (quoted strings, signed integers, booleans and one-level tables). `yaml` reads a deliberately small mapping subset with at most one nested mapping level. `schema` validates declared string/integer/boolean fields across existing `Config` (INI), TOML and YAML documents. Existing `config.fac` already supplies the INI subset; native `json.encode` / `json.decode` already cover JSON serialization/deserialization, so no duplicate `ini`, `serialize` or `deserialize` wrappers were added. Unsupported TOML/YAML constructs are rejected rather than silently interpreted. See `docs/LIBRARIES.md` and section 30 of `syntax/fac_spec.fac`; regression: `tests/api/a19_v142_structured_data.fac`; example: `examples/api/10_structured_data.fac`.

## V141: date/time, configuration, URL, IP and locale libraries

V141 adds five source-level modules without changing FAC grammar or the Runtime ABI. `datetime` wraps the existing epoch-millisecond `time` API with Gregorian date helpers and UTC parsing/formatting. `config` reads and writes a documented small INI subset. `url` parses/builds absolute hierarchical `scheme://authority` URLs and provides separate RFC 3986 component and form-query decoding helpers. `ip` parses IPv4/IPv6 literals and exposes byte/loopback checks. `locale` supplies a deliberately small deterministic convention table, not ICU/CLDR. Current limitations (including URL user-info rejection, IPv6 embedded-IPv4/zone-ID support, and local-timezone dependence) are documented in `docs/LIBRARIES.md` and `syntax/fac_spec.fac`. Regression coverage is `tests/api/a18_datetime_config_url_ip_locale.fac`; example: `examples/api/09_datetime_config_url_ip_locale.fac`.

## V140: binary, Unicode, encoding, compression and UUID libraries

V140 adds source-level `bytes`, `encoding`, `unicode`, `compress` and `uuid` modules. `ByteBuffer` stores unsigned byte values as integer list elements and supports endian-aware U16/U32 reads/writes; it does not treat UTF-8 `string` values as arbitrary binary storage. `encoding` provides strict hexadecimal and canonical padded RFC 4648 Base64 conversion between byte lists and printable text. `UnicodeTools` distinguishes code points from grapheme clusters and exposes code-point conversion/slicing, while inheriting the Runtime's documented practical grapheme subset rather than claiming full UAX #29 or normalization. `compress` currently provides bounded RLE only, not ZIP/gzip/DEFLATE/zstd. `uuid.v4()` delegates generation to the existing Runtime crypto UUID implementation and adds canonical format/version/variant checks. Regression coverage is `tests/api/a17_binary_unicode.fac`; the new example is `examples/api/08_binary_unicode.fac`.

## V139: foundational utility libraries

V139 adds source-level FAC libraries for generic collection helpers (`CollectionOps<T>`), pull iterators (`ListIterator<T>` and half-open `RangeIterator`), generic search/bounds algorithms, `Option`/`Result` helpers and built-in `Error` descriptions, in-memory text reader/writer buffers, synchronous stderr logging, explicit debug output, assertions and an in-process test accumulator. Existing built-in collection types, `result.fac`, `string`, `file`/`fs`, `terminal`, `thread` and other modules are reused rather than shadowed. The new example is `examples/api/07_core_utilities.fac`; the regression fixture is `tests/api/a16_core_libraries.fac`. FAC still has no foreach/yield or async/await syntax; the iterator API is pull-based and returns `Option<T>`.

## V138: generation-tagged weak handles and ABA protection

V138 replaces public weak-control-block addresses with opaque pointer-sized generation tokens. On 64-bit targets, a token encodes a one-based slot value in 23 bits and a nonzero generation in 24 bits; on 32-bit targets, the layout is 12 slot bits plus 19 generation bits. The slot table is protected by the existing object lifecycle mutex. Weak retain/release/alive/lock decode and validate the token before accessing a control block. When the final handle is released, its slot is invalidated and the generation advances before the slot can be reused. A slot is permanently retired rather than allowing its generation to wrap. Thus, a stale weak token cannot alias a later weak control block even when the slot is reused. `FacWeakControl` remains an internal Runtime allocation, and the 64-byte managed-object header is unchanged. Public C function signatures are unchanged, but weak values are now strictly opaque tokens, not addresses: native code must copy/store/pass them unchanged and must never dereference or perform pointer arithmetic on them. The token layout is bounded to the low 47 bits on 64-bit targets and low 31 bits on 32-bit targets. See [`docs/SECURITY_AUDIT_V138.md`](docs/SECURITY_AUDIT_V138.md).

`tests/runtime/object_registry_safety.cpp` forces slot reuse and verifies that the new generation token differs from the stale token; stale retain/release/alive/lock operations cannot access the new control block. The test selects the matching 64-bit or 32-bit slot layout. The weak-slot vector retains capacity up to the peak number of simultaneously allocated weak-control slots; it reuses slots across object lifetimes rather than allocating a permanent tombstone for every expired handle. `benchmarks/weak_handle.cpp` measures weak-alive and weak retain/release throughput. In a same-flags optimized single-thread microbenchmark (three alternating process runs, nine samples each, 3,000,000 iterations per sample), the median of process medians was 2.14 ns on V137 versus 14.07 ns on V138 for `weak_alive`, and 22.15 ns versus 30.50 ns for a weak retain/release pair. This is a clear safety cost on these uncontended weak-handle hot paths, not a whole-program speed comparison. This closes weak-handle ABA only. Raw strong object pointers still use the existing pointer ABI and can theoretically suffer address-reuse ABA; solving that requires a wider object-handle ABI change. FAC still does not claim Rust-equivalent memory safety or complete C++-safe error unwinding; focused TSan checks passed, but this is not full-runtime TSan coverage.

## V137: validate object liveness before Runtime header access

V137 hardens managed-object reference operations against stale and invalid object pointers. `fac_obj_retain`, `fac_obj_release`, `fac_obj_weak` and `fac_obj_weak_lock` now consult the synchronized object registry before reading an object header. Registry entries distinguish live objects, objects in final destruction and peers being destroyed as part of a cycle batch; this preserves collector-internal peer releases while rejecting stale handles before dereference. The registry reuses its existing hash entry for destruction state rather than allocating a separate state map on every final release. A focused regression exercises expired weak handles, stale object pointers and invalid native pointers. Public C ABI declarations and object header layout are unchanged. See [`docs/SECURITY_AUDIT_V137.md`](docs/SECURITY_AUDIT_V137.md).

V137 validation on GCC 14.2: CMake Debug/CTest **13/13**; Runtime shell suite passed; memory-safe profile **25/25**; ownership/borrow/effect tests and move/partial-move suites passed; focused stale-pointer, finalizer-cleanup and concurrent refcount tests passed under GCC ASan+UBSan+LeakSanitizer with leak detection. The Clang `-O1` sanitizer build exceeded the local build time limit, so no Clang sanitizer result is claimed. A same-flags one-object refcount microbenchmark (9 samples, 5,000,000 retain/release pairs per sample) measured median **25.90 ns** on V136 and **27.13 ns** on V137, about **4.75% slower** for this path due to registry validation. This is a narrow safety-overhead measurement, not a general performance result. The registry cannot distinguish an address-reuse/ABA stale pointer from a new live object at the same address, and it does not make arbitrary invalid weak-handle storage safe. FAC still does not claim Rust-equivalent memory safety; see the audit for remaining boundaries.

## V136: Runtime object finalization error safety

V136 makes object destruction continue safely when an object's finalizer or field-drop callback raises an error. `fac_obj_release()` now catches FAC non-local errors at the callback boundary, runs the remaining drop/free steps, and then propagates the first error. Cycle collection applies the same policy across all dead peers, resets its collection gate, and exits the scope owning its STL work buffers before rethrowing. C++ callback exceptions are also translated into a FAC Runtime error after cleanup. A regression test covers single-object FAC/C++ finalizer failures and a two-object cycle whose finalizers both fail. No public API signatures, standard-library declarations or Runtime object layouts changed. See [`docs/SECURITY_AUDIT_V136.md`](docs/SECURITY_AUDIT_V136.md).

V136 validation on GCC C++17: CMake Debug build and CTest **12/12**; full Runtime shell suite passed; ownership/borrow contract suites **178/178**; move and partial-move suites **43/43**; targeted object-finalizer regression passed under ASan+UBSan+LeakSanitizer with leak detection enabled. API compatibility against V128 reports **0 Breaking / 27 Warnings / 0 Added**; warnings are error-contract changes, including the now-explicit dynamic error propagation of `memory.collectCycles()`. This is focused error-path hardening, not a general replacement of `setjmp`/`longjmp`, and no broad runtime speedup or Rust-equivalent memory safety is claimed.

## V135: Runtime cleanup on FAC error paths

V135 fixes two Runtime ownership leaks that could occur when FAC errors used the existing `setjmp`/`longjmp` boundary during construction of a managed string list. `sys.args` now registers its partially built list before any operation that can fail, and JSON array-to-list conversion does the same so a type error in a later element frees earlier converted strings and list storage. A new Runtime regression test checks that FAC allocator usage and block counts return to their baseline after both numeric and string conversion failures, and exercises successful `sys.args` construction. These are targeted error-path fixes, not a redesign of Runtime unwinding: `setjmp`/`longjmp` remains, and this release does not claim that every C++ Runtime temporary is protected or that FAC is Rust-equivalent. No public standard-library signatures or Runtime ABI layouts changed. See [`docs/SECURITY_AUDIT_V135.md`](docs/SECURITY_AUDIT_V135.md).

V135 validation on Clang 17: CMake/CTest 11/11; Runtime shell suite passed on rerun; ASan+UBSan with leak detection passed for the new regression; memory-safe 25/25; safe suite 316/316; core `-O0` cases 127/127; negative checks 132/132; limits 21/21. No broad runtime speedup or fully Rust-equivalent memory safety is claimed.

## V134: fail-closed memory-safe subset and Runtime lifetime stress tests

V134 adds an opt-in `--memory-safe` compiler profile. It enables strict-safe/ownership/move checks and integer overflow checking, validates imported source libraries, and rejects raw/opaque pointers, manual heap storage, `ref` borrows, FFI/export/native linking, unsafe blocks/functions, native linker inputs, and built-in modules whose public signatures expose raw native handles. Shell process APIs are rejected even through import aliases. The profile is deliberately restrictive and is **not Rust-equivalent**: the compiler still lacks a complete region-based borrow/lifetime checker, the C++ Runtime remains trusted, and the FAC error boundary still uses `setjmp`/`longjmp`. It is a language-subset gate, not an OS sandbox. See [`docs/MEMORY_SAFE_PROFILE.md`](docs/MEMORY_SAFE_PROFILE.md).

V134 adds 25 targeted safe-profile acceptance/rejection/runtime-guard checks and concurrent refcount stress coverage for strings, class objects, weak handles and closures. These tests are regression evidence for the exercised paths, not proof of all memory safety or race freedom. The Runtime implementation is otherwise intentionally unchanged in this release; no general runtime speedup is claimed. A 9-run, 240-function compiler microbenchmark at GCC `-O0` measured median compile times of 17.266 ms (normal), 22.364 ms (`--secure`) and 24.330 ms (`--memory-safe`): the new gate adds about 8.8% over `--secure` in this microbenchmark. This is compile-time overhead only; ordinary compilation does not run the extra AST gate. See [`docs/SECURITY_AUDIT_V134.md`](docs/SECURITY_AUDIT_V134.md) for the exact test scope, trust boundary and remaining risks.

## V133: Runtime security and resource-boundary audit

V133 audits the Runtime and standard libraries in addition to compiler development. It hardens integer edge cases, strict JSON parsing and tree ownership, image decoding/canvas limits, file and subprocess output limits, ML workload budgets, GPU/audio allocation failure paths, and TCP handle/host validation. It also documents important trust boundaries: `--safe` is not an OS sandbox, shell APIs are injection-sensitive, TCP listeners bind all IPv4 interfaces, DNS/connect are blocking and the HTTP client has no TLS.

Behavioral/resource limits introduced in this release: file `readAll`/`readText`/`readLines` are capped at 64 MiB; `readLine` at 16 MiB; `readLines` at 1,000,000 lines; `sys.output` captures at most 64 MiB; `net.recvAll` at 64 MiB; HTTP socket send/receive timeouts are 30 seconds with a 60-second response deadline; Canvas/image/font raster operations are capped at 16M pixels (down from 64M). These caps intentionally turn previously unbounded or high-memory requests into FAC errors. `sys.output` still has no child-process timeout and drains excess output until the process exits. The PNG fuzz runner defaults to Clang for LLVM IR input and allows constrained compile flags through `FUZZ_CXXFLAGS`.

Local V133 validation: GCC 14.2 and Clang 17 CMake Debug builds each pass 8/8 CTest checks; the Make Runtime regression suite passes; the Security Regression passes under ASan+UBSan; and 500 deterministic PNG mutations ran under ASan+UBSan (26 accepted, 474 rejected, no sanitizer report). `make api-check` reports 0 Breaking / 26 Warnings / 0 Added versus V128; the warnings describe stricter error/validation contracts. Hosted Windows/macOS jobs and a full optimized Compiler build are not claimed as verified. See [`docs/SECURITY_AUDIT_V133.md`](docs/SECURITY_AUDIT_V133.md) for confirmed findings, remediations, residual risks and the exact validation scope.

## V132: a separately compiled Lexer module

V132 extracts the token model and Lexer interface into `src/lexer.hpp` and moves the Lexer implementation into `src/lexer.cpp`. The Compiler now links the driver and Lexer as distinct translation units in GNU Make, CMake and the Windows batch build. This creates the first genuine front-end module boundary: edits to the Lexer implementation rebuild `lexer.o` rather than recompiling the full driver, while Parser continues to consume the same `Tok` and `lex()` interface. Changes to the shared `lexer.hpp` interface correctly rebuild its dependents.

Focused Lexer and Parser regression executables now link the compiled Lexer implementation; CTest includes both. The standalone token-budget test and front-end microbenchmark build commands were updated to link `src/lexer.cpp`. No FAC grammar, token representation, public FAC API, Runtime ABI or generated code behavior is intended to change. `tools/compare_compilers.py` can compare emitted LLVM IR from a V131 compiler and a candidate compiler on the same fixture set; byte-identical comparison should use the same host C++ toolchain and flags for both builds.

This is a staged refactor, not a complete Compiler split: AST and Parser remain together in `src/parser.hpp`, while Ownership/Move and LLVM Codegen remain header/implementation fragments included by the driver. The next safe boundaries are AST declarations and semantic-analysis interfaces, followed by Codegen declarations/definitions. See [`docs/FRONTEND_ARCHITECTURE.md`](docs/FRONTEND_ARCHITECTURE.md) and [`docs/STATUS.md`](docs/STATUS.md).

## V131: portable CMake build and Runtime integration

V131 adds an optional CMake/Ninja build alongside GNU Make. It exposes independent `facc` and `facrt` targets, tracks the included Compiler/Runtime implementation files through CMake's native dependency scanner, applies supported hardening flags, and links platform dependencies transitively (Threads, the dynamic-loader library where needed, and Windows system libraries). CTest runs the compiler version smoke test, release-manifest/API-compatibility checks when Python is available, and the Graph Runtime regression. Install rules provide the compiler, static Runtime library, version header and exported `FAC::Compiler` / `FAC::Runtime` CMake targets. See [`docs/CMAKE.md`](docs/CMAKE.md).
The local GCC 14.2 and Clang 17 Debug builds both passed all five CTest checks, including an install-and-consume test using `find_package(FAC)`.

This is a build-system and distribution improvement, not a claim that the Compiler has been split into multiple translation units or that hosted Windows/macOS jobs have already passed. The internal compiler remains a single translation unit until its shared AST and inline `Gen` definitions can be refactored behind stable declarations.

## V130: reliable incremental builds and compiler profiling

V130 makes build configuration part of Make's dependency graph: changing `CXX`, compile/link flags, Runtime-only flags or the archiver now rebuilds the affected artifacts instead of silently reusing objects produced with stale settings. Both Compiler and Runtime objects emit dependency files, and `compiler-only` / `runtime-only` targets allow the two artifacts to be built independently. `make profile-build` and `tools/profile_build.py` perform clean, repeatable builds and save compiler metadata, wall-time samples and full logs. CI uploads a GCC `-ftime-report` compiler-build profile for inspection.

This release improves build reliability and observability; it does not claim a faster compiler build. The Compiler remains one translation unit because its inline `Gen` implementation and shared AST definitions need a deliberate declaration/definition refactor before they can be split safely. See [`docs/BUILD.md`](docs/BUILD.md) for commands, profile interpretation and the current architectural boundary.

## V129: scalable Graphs, validated shortest paths and lower call overhead

V129 removes per-insertion exact-capacity reservations from Graph node and edge storage, using geometric vector growth instead. High-degree adjacency rows receive a secondary hash index while low-degree rows remain compact vectors. Index updates participate in edge insertion rollback and are kept coherent by directed removal, undirected removal and node deletion. Weighted Graph APIs reject negative and non-finite weights so Dijkstra's precondition is enforced at the boundary; shortest-path distances use IEEE infinity rather than a finite sentinel.

Generated FAC functions now perform the recursion depth and stack-distance checks inline through thread-local state. Only the cold failure path calls the Runtime. The depth and stack anchor are restored across FAC `throw`/`catch` longjmp boundaries and the anchor is cleared when the outermost FAC call returns. The existing limits and error behavior remain enabled.

The build now compiles the compiler driver and Runtime as independently rebuildable objects, with compiler dependency tracking. This is an incremental-build improvement; the compiler implementation is still one translation unit and is not yet split into independent frontend/backend translation units. CI adds GCC and Apple Clang runtime/codegen jobs plus Linux ASan/UBSan Graph coverage. The benchmark runner validates every checksum and reports median-of-N times rather than best-of-N. See [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md), [`docs/BENCHMARKS.md`](docs/BENCHMARKS.md) and [`docs/STATUS.md`](docs/STATUS.md).


## V128: faster Graph key lookup without weaker safety

V128 optimizes the runtime Graph index. Graph keys are stored once in stable `std::deque`-owned blobs; the hash index keeps non-owning `std::string_view` keys, avoiding the previous per-lookup temporary string and duplicate index key. The key storage remains stable across appends, and index publication, OOM rollback, deletion and clone cleanup remain transactional. No bounds checks, divide-by-zero checks, ownership checks, safe-mode rules or public API/Runtime ABI signatures were disabled or changed.

`make bench-graph-lookup` runs the focused lookup benchmark. See [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md) and [`docs/STATUS.md`](docs/STATUS.md) for measured scope and validation limits.


## V127: control-flow and pattern matching improvements

V127 adds `until`/`do ... until`, ordered `select`, exit-checked `guard`, explicit nested counted-loop index paths and match wildcard patterns. `ifv` now joins compatible numeric branch types into a common result type. Existing `defer` receives dedicated LIFO/exit-path regression coverage and documentation. No API declarations, Runtime ABI or Standard Library APIs change in this release.

See [`docs/LANGUAGE_CORE.md`](docs/LANGUAGE_CORE.md) and [`syntax/fac_spec.fac`](syntax/fac_spec.fac) for syntax and semantic rules.

## V126: thread task lifecycle and cooperative cancellation

V126 adds a small cross-platform task lifecycle to the existing `thread.start` handle without changing the established `thread.start` / `thread.join` signatures. A task progresses through Starting, Running and one terminal state (Succeeded, Failed or Cancelled), then Joined when its owning caller consumes the handle.

- `thread.cancel(handle)` requests a cooperative stop while the task is active; it never forcibly terminates an OS thread.
- `thread.cancelled()` is polled by the callback passed to `thread.start`; callbacks choose a safe point to return.
- `thread.isDone(handle)` and `thread.isCancelled(handle)` expose terminal state before `thread.join`.
- Worker errors take precedence over cancellation and are still re-raised by `thread.join` with their original FAC code.

Cancellation is cooperative: callbacks that do not poll continue running. The handle owner must serialize cancel/status operations with the consuming join, and no handle alias is valid after join. This release does not add `async/await`, futures, typed task results, detach, or cancellation propagation into `thread.parallelFor` workers. See `docs/CONCURRENCY.md` and `docs/RUNTIME.md`.

## V125: reusable parallelFor worker pool

V125 replaces per-call `std::thread` creation in `thread.parallelFor` with an internal reusable worker pool while preserving the public synchronous API. The pool grows lazily to the requested concurrency, is capped at 32 workers and the host's reported hardware concurrency, and keeps workers alive until process shutdown. Work is dynamically claimed through a 64-bit atomic cursor. Separate per-worker queues allow concurrent callers to submit independent batches; worker selection rotates to avoid routing all small jobs to the same worker. Nested `parallelFor` called from a pool worker runs inline under a nested FAC/C++ error boundary to prevent the worker from waiting for itself. If the pool cannot create the requested workers or queue tasks, the call raises the established Resource error (8); partial queue submission is rolled back before workers can observe it.

New Runtime tests cover exact-once scheduling, worker reuse, nested execution and catchable nested FAC errors, concurrent callers, and repeated cleanup/error propagation. The pool is internal: no Syntax, API signature, Standard Library declaration, C ABI or Runtime ABI changed. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/RUNTIME.md`](docs/RUNTIME.md) and [`docs/STATUS.md`](docs/STATUS.md).

## V124: concurrency callback error propagation and receive exception safety

V124 gives each `thread.parallelFor` worker a FAC-local error boundary. A FAC `throw` from a callback is captured on that worker, registered FAC cleanup/temporary state is unwound, all workers are joined, and the first callback error is re-raised on the caller with its original code and message. Existing C++ callback exceptions keep their established diagnostic. `sync.Channel.recv` now allocates its result copy before removing the queued message; allocation failure returns `NULL` without losing the message, which remains available for retry.

The runtime regression suite checks FAC error propagation/worker cleanup and deterministic `malloc` failure during channel receive. No Syntax, API, Standard Library, C ABI or Runtime ABI changes were made. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md) and [`docs/STATUS.md`](docs/STATUS.md).

## Previous release notes


## V123: generic specialization cache correctness and lookup performance

V123 fixes the per-compilation generic-type budget so it counts only distinct materialized specializations. Previously, every reference incremented the counter before the cache lookup, so a single `Box<int>` used in 5,001 fields was incorrectly rejected as if 5,001 different specializations had been created. Cache hits now return without consuming the 5,000-specialization budget; the budget still rejects 5,001 distinct concrete specializations. The lookup-only `genericTemplates`, `genericInstantiations` and generic method `genCache` tables use `std::unordered_map`; none is traversed to determine output order.

The new `make test-generic` suite checks 5,001 references to one specialization, the 5,001-distinct-specialization ceiling, and a generic method emitted only once across repeated calls. `make bench-generic` measures a synthetic project with 100 generic templates and 4,000 specialization references. On Linux x86_64, GCC C++17 `-O0`, nine runs measured median source-to-IR time of 373.091 ms on V122 and 356.334 ms on V123 (about 4.5% lower); generated IR remained byte-size identical at 557,191 bytes. This is a focused compile-time workload, not a general compiler or runtime speedup claim.

No FAC Syntax, API, Runtime, C ABI, Runtime ABI or Standard Library implementation changed. Existing Safety, Ownership/Borrow and Runtime regression suites remain release gates. See [`docs/GENERIC_SPECIALIZATION.md`](docs/GENERIC_SPECIALIZATION.md), [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md) and [`docs/STATUS.md`](docs/STATUS.md).

## Previous release notes

## V122: shorter frontend memory lifetime

V122 released imported ASTs, symbol/type metadata and generic caches after IR generation and before backend execution. It reduced RSS retained at backend launch in a 130-module synthetic build; peak memory during frontend analysis remained unchanged. See [`docs/COMPILER_MEMORY.md`](docs/COMPILER_MEMORY.md).


## V121: conservative integer constant folding in code generation

V121 adds a bounded, bottom-up constant evaluator for pure integer, character and boolean literal expression trees. Safe subexpressions are emitted as literals instead of redundant arithmetic IR. Every intermediate result must fit its FAC type before folding, so signed-width wrap behavior is preserved; mixed signed/unsigned cases that cannot be modelled exactly, divide-by-zero, signed division overflow, non-constant expressions, calls and side effects are left to normal code generation. Shift and exponent operations remain on the existing LLVM path. The `--check-overflow` path retains overflow intrinsics whenever a potentially overflowing intermediate prevents folding. The evaluator visits at most 64 AST nodes per candidate to bound frontend work.

The reproducible workload in `benchmarks/compiler_codegen.py` uses 600 functions (65,372 source bytes). On the Linux x86_64 development host, GCC C++17 `-O0` source-to-IR median changed from 101.189 ms in V120 to 92.092 ms in V121 (about 9.0% lower), while emitted IR size fell from 398,563 to 201,489 bytes (about 49.4% smaller). This is a constant-heavy source-to-IR microbenchmark, not an end-to-end compiler, LLVM backend, native-program runtime or general workload speedup claim. A 200-expression differential test matched V120 output and the integer reference results exactly.

V121 also adds `tests/codegen/constant_fold.fac` and `make test-codegen`; the test checks runtime results at `-O0`/`-O2` and verifies that overflow and division-by-zero guards remain in emitted IR. No Syntax, API declaration, Runtime implementation, C ABI or Standard Library declaration changed. See [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md) and [`docs/STATUS.md`](docs/STATUS.md) for measurement scope and validation.

## V120: faster class ancestry checks in the semantic/type-checking path

V120 removes temporary `std::set`/`std::vector` allocations from common class-to-class subtype checks. When the requested base is a concrete class, `isSubclass` follows only the single `parent` chain, with a defensive traversal bound. Interface targets still use the existing cycle-safe graph traversal so `implements`, interface inheritance and multiple-interface behavior remain unchanged. Protected-member ancestry uses a bounded parent-chain walk instead of allocating a visited set. No grammar, type-conversion rule, API declaration, Runtime implementation or ABI changed. A dedicated semantic regression covers class chains, interfaces/diamonds, protected access and malformed cycles. The `benchmarks/compiler_semantic.cpp` workload measures repeated subtype checks separately from full compilation.


## V119: parser throughput and column-aware diagnostics

V119 optimizes expression parsing without changing FAC grammar or operator semantics. Assignment-operator recognition no longer performs a `std::set` lookup for each expression; it uses exact checks over the small fixed assignment-operator vocabulary. Binary precedence dispatches by the operator's first character, and string-literal parsing passes the stable token buffer directly into interpolation parsing instead of first copying the entire decoded token. A dedicated Parser regression verifies all 15 assignment operators, right associativity, binary precedence, postfix increment and malformed-expression diagnostics.

Parser errors now retain the unexpected token's 1-based UTF-8 byte column in addition to the line number. The driver displays `file:line:column` for parser diagnostics. Nested string-interpolation columns remain unavailable because their decoded source positions cannot be mapped exactly through escapes; those diagnostics continue to report the line only. The benchmark at `benchmarks/compiler_parser.cpp` measures Lexer and Parser separately. On the development host, a 5,000-function workload had a Parser median of 37.62 ms in V118 and 30.75 ms in V119 (about 18.3% faster for this specific synthetic parse workload). This is a Parser-only result, not an end-to-end compiler speedup claim.

V119 does not change syntax, built-in API declarations, Runtime implementation, C ABI or Standard Library declarations. See [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md) and [`docs/STATUS.md`](docs/STATUS.md) for validation details.

## V118: compiler lexer throughput

V118 improves the frontend lexer without changing FAC syntax or token meaning. Numeric literals without digit separators are converted directly from the source buffer instead of being copied into a temporary string first; literals containing `_` retain a compacted fallback path. Multi-character operator matching now uses compile-time lengths and filters candidates by the first source character before comparing the full spelling. This reduces repeated string-length scans and avoids comparing operators that cannot match the current character.

A reproducible synthetic lexer microbenchmark is provided at `benchmarks/compiler_lexer.cpp`. On the Linux x86_64 development host, the 320,001-token identifier/operator workload had a warm-run median of 30.5151 ms in V118 versus 48.6075 ms in V117 (about 37.2% faster for this specific lexer workload). This is not a claim that full FAC compilation or generated programs are 37% faster. Numeric-literal correctness tests cover decimal boundaries, separators, scientific notation, 64-bit bit patterns and invalid bases/overflow. No syntax, built-in API, Runtime implementation, C ABI or Standard Library declaration changed.

See [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md) for benchmark details and [`docs/STATUS.md`](docs/STATUS.md) for validation scope.

---

## V117: Runtime clone rollback and allocation-failure safety

V117 hardens existing Runtime data structures without changing their public APIs. Linked List, Stack, Queue, Heap, AVL Tree, Trie and Matrix clone paths now keep incomplete copies under RAII ownership so an allocation failure destroys all elements already copied. Managed FAC string references are explicitly released when a container insertion fails before commit. AVL Tree node creation and successor-key transfer are made failure-safe, and Trie insertion rolls back a partially-created suffix if any later node/vector allocation fails. Graph `neighbors`, `bfs`, `dfs` and `shortest` now also catch work-buffer allocation failures before they cross the C ABI.

The relevant C-linkage entry points now translate caught `std::bad_alloc` and `std::length_error` into FAC Resource error 5 instead of allowing those C++ exceptions to cross the ABI boundary. Deterministic allocation-failure tests cover managed-string insertion, Queue block growth, Graph traversal work buffers, partial Trie insertion, and clone failure points for Linked List, Stack, Queue, Heap, AVL Tree, Trie and Matrix. This is targeted coverage for these paths, not a blanket guarantee that all Runtime code is exception-safe: FAC `do_throw` still uses non-local control transfer and bypasses ordinary C++ destructors in unguarded paths. No syntax, API declaration, C ABI layout or Runtime ABI changed. See [`docs/RUNTIME.md`](docs/RUNTIME.md) and [`docs/SAFETY.md`](docs/SAFETY.md).

---

## V116: optional vector fonts and shaped text layout

V116 adds an optional Pango/Cairo/Fontconfig vector-font backend. `font.load(path, size)` registers a local TTF/OTF file for the current process, exposes family/size/vector queries, measures real pixel metrics and rasterizes glyph coverage into the existing software canvas with alpha blending. `font.create(scale)` remains the portable bitmap fallback. The vector backend is loaded dynamically on supported Unix-like builds, so it does not add a compile-time Pango dependency; when those runtime libraries are absent, bitmap fonts remain available and `font.backendAvailable()` returns false. The tested host is Linux; Windows currently keeps the bitmap backend.

`typography.TextLayout.reflowWithFont()` now wraps and draws with the same caller-owned font handle, including variable-width metrics and Pango's shaping/fallback for scripts such as Thai. Vector font handles are not thread-safe and must outlive layouts borrowing them. This does not turn FAC's canvas into a native macOS renderer: native controls, vibrancy/blur, retained component trees and a platform validation matrix remain separate work. See [`docs/TYPOGRAPHY.md`](docs/TYPOGRAPHY.md), [`docs/LIBRARIES.md`](docs/LIBRARIES.md) and [`docs/STATUS.md`](docs/STATUS.md).

---

## V115: weighted UI layout and text paragraph measurement

V115 adds `ui.FlexBox` for weighted row/column layout with grow/shrink weights, min/max main-axis constraints, padding and cross-axis alignment. `typography.TextLayout` adds cached word wrapping, grapheme-safe long-token handling and line metrics. The V115 text layout used the bitmap renderer; V116 extends it with optional vector-font metrics and shaping. See [`docs/UI.md`](docs/UI.md) and [`docs/TYPOGRAPHY.md`](docs/TYPOGRAPHY.md).

---

## V114: UI motion system and animated desktop components

V114 adds `motion.Tween` and a damped `motion.Spring` as FAC-only scalar motion primitives. The UI now measures monotonic frame delta in `ui.beginFrame()` and adds animated buttons, sidebar items, toolbar actions, toggles, tab indicators and panel entrance motion. Animation state is explicit per widget, retargeting begins at the current value, and `theme.Theme.setReduceMotion(true)` disables built-in transitions for accessibility. Existing immediate-mode APIs and old widgets remain source-compatible. No compiler grammar, built-in Runtime API or C ABI changed.

The design uses restrained ease-out responses and small positional movement inspired by modern desktop interfaces; it is not a native macOS widget backend. The canvas renderer, bitmap font limitations, lack of TTF/OTF shaping and lack of window vibrancy/blur remain unchanged. See [`docs/UI.md`](docs/UI.md), [`docs/MOTION.md`](docs/MOTION.md), [`docs/STATUS.md`](docs/STATUS.md) and [`examples/ui_motion.fac`](examples/ui_motion.fac).

---


## V113: strict HTTP response framing and validation

V113 hardens the built-in cleartext HTTP client without changing its API signatures or adding a TLS dependency. It validates HTTP/1.0 and HTTP/1.1 status lines and header syntax, parses `Content-Length` as a checked decimal value, requires the received body length to match it exactly, and rejects conflicting lengths or simultaneous `Transfer-Encoding` and `Content-Length`. Chunked responses now require a valid terminal zero chunk, complete trailer termination and valid chunk boundaries; chunk extensions and valid trailers are supported. Informational responses such as 100 Continue and 103 Early Hints are skipped before the final response; 101 protocol upgrades are explicitly unsupported. HTTPS remains unsupported.

The Runtime tests cover valid framing and malformed/truncated responses. No public API signature, compiler grammar or C ABI changed. See [`docs/api/net.md`](docs/api/net.md) and [`docs/STATUS.md`](docs/STATUS.md).

---

## V112: network timeout validation

V112 hardens `net.setTimeout`: null sockets and negative timeout values now raise a FAC network error consistently, and operating-system timeout configuration failures are no longer silently ignored. A timeout of zero disables the receive timeout; positive values are milliseconds. The API signature and C ABI are unchanged.


## V111: practical path helpers and URL handling fixes

V111 extends the existing `path` built-in module with four operations: `changeExtension`, `withName`, `isSymlink` and `componentCount`. Their edge cases are defined explicitly: dotfiles do not lose their leading-dot name, trailing separators remain directory paths, symlink checks inspect the link itself (including dangling links), and component counts ignore repeated separators while retaining `.` and `..`.

The HTTP client now handles query-only request targets (`http://host?key=value`) and bracketed IPv6 authorities, and excludes URL fragments from the HTTP request target. `net.urlEncode` now follows RFC 3986's ASCII-only unreserved set, independent of the process locale, so UTF-8 bytes are percent-encoded consistently. HTTPS remains unsupported by this built-in client; use an explicitly linked TLS-capable library when HTTPS is required.

This release does not add a new UI design layer: V109's clean workspace direction and V110's color/easing/game APIs remain intact. See [`docs/api/path.md`](docs/api/path.md), [`docs/api/net.md`](docs/api/net.md) and [`docs/STATUS.md`](docs/STATUS.md).

---

## V110: color spaces, motion curves and fixed-step diagnostics

V110 expands three existing source libraries without changing FAC grammar, the compiler's built-in API table, Runtime implementation or C ABI:

- `color` adds `fromHsv`, `fromHsl`, `toHsv` and `toHsl`. Hue is measured in degrees and wraps into [0,360); saturation, value and lightness use [0,1]. Reverse conversions return `(hue, saturation, value/lightness)` tuples. Non-finite conversion inputs throw Math error 18; channel and normalized inputs are clamped as documented.
- `easing` adds quartic/quintic, exponential, circular, bounce, back and elastic in/out/in-out curves. Inputs clamp to [0,1]; back and elastic output may intentionally overshoot or oscillate, while exponential and elastic endpoints are exact.
- `game` adds `droppedNs()` and `updatesLastFrame()` so applications can observe fixed updates performed and simulation time discarded by the existing frame clamp/catch-up cap. The existing catch-up policy is preserved.

The V109 clean-workspace UI direction is retained unchanged. New APIs are FAC source code and add no native backend or platform-specific dependency. See [`docs/api/color.md`](docs/api/color.md), [`docs/api/easing.md`](docs/api/easing.md), [`docs/api/game.md`](docs/api/game.md), and [`docs/STATUS.md`](docs/STATUS.md).

---


## V109: clean workspace UI direction and neutral themes

V109 refines the canvas UI toward a modern desktop workspace style: neutral graphite/light surfaces, restrained blue selection/action color, thinner separators, smaller corner radii, and flat bordered panels instead of a shadow on every card. `ui.fac` adds `workspaceBar`, `sidebarItem`, `toolbarButton`, and `workspaceRow` while preserving the existing UI functions and interaction model. The default `ui.Styles.card` no longer adds a shadow; applications can still opt in explicitly.

The former generic KPI dashboard showcase is replaced by a source/workspace browser with a file list and a compact details inspector. Existing non-UI libraries, compiler grammar, built-in API table, Runtime implementation and C ABI are unchanged. This is a visual/API refinement, not a native macOS/Windows widget backend. Text still uses the 3×5 bitmap glyph renderer (Latin lowercase is drawn as uppercase); true TTF/OTF metrics and complex-script shaping remain a known blocker for matching polished desktop typography.

See [`docs/UI.md`](docs/UI.md), [`docs/STATUS.md`](docs/STATUS.md) and [`docs/api/ui.md`](docs/api/ui.md).

---


## V108: multiline text editing and equal-share Flex layout

V108 extends the immediate-mode UI with `ui.textArea`, a multiline editor that shares the existing text-field focus and bounded undo/redo session. It supports committed UTF-8 insertion, Enter for line breaks, line-local Home/End, Up/Down with a preferred column, Shift selection, clipboard operations, Tab focus links, vertical viewport scrolling and Ctrl+Z/Ctrl+Y. `ui.Flex` adds an equal-share row/column splitter that distributes remainder pixels deterministically. The focus manager remains text-editor-only; this is not a retained component tree or a complete CSS/browser Flexbox implementation. Text rendering still uses the existing bitmap font and supported grapheme subset.

No compiler grammar or Runtime ABI changed. The new editor and layout remain FAC source-library APIs on the existing software canvas. See [`docs/UI.md`](docs/UI.md), [`syntax/fac_spec.fac`](syntax/fac_spec.fac), [`docs/STATUS.md`](docs/STATUS.md) and [`docs/api/ui.md`](docs/api/ui.md).

---

# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V107

## V107: text-field focus control and bounded undo/redo

V107 builds on V106's UTF-8 text input with a small immediate-mode text-focus API: `ui.focusTextField`, `ui.focusedTextField`, `ui.blurTextField`, `ui.canUndoText`, `ui.canRedoText`, `ui.undoText` and `ui.redoText`. Text fields now support Ctrl+Z / Ctrl+Y and toolbar-driven undo/redo. History is capped at 64 snapshots in each direction for the active focus session; moving focus or blurring clears it, and a fresh edit discards the redo branch. The focus manager is intentionally limited to text fields and explicit IDs, not a retained component tree or a general focus/accessibility system.

No compiler grammar or Runtime ABI changed. This release adds only source-level UI APIs; the text-entry backend from V106 is reused. See [`docs/UI.md`](docs/UI.md), [`syntax/fac_spec.fac`](syntax/fac_spec.fac), [`docs/STATUS.md`](docs/STATUS.md) and [`docs/api/ui.md`](docs/api/ui.md).

---

# Fac (LLVM) — compiler ภาษา Fac v0.2 · Release V106

## V106: UTF-8 text input, editable GUI fields and clipboard

V106 adds a real text-input path to the graphics runtime: per-poll UTF-8 text snapshots, platform start/stop controls and clipboard get/set on SDL2 and Win32. The immediate-mode UI now has `ui.textField` with cursor placement, selection, insert/delete, Ctrl+A/C/X/V, explicit Tab/Shift+Tab focus order, maximum length and horizontal scrolling. `string.graphemeLength` / `string.graphemeSlice` provide a practical grapheme subset for combining marks, Thai marks, emoji modifier/ZWJ sequences and flag pairs. Text rendering width advances by grapheme cluster rather than UTF-8 byte; grapheme counting and render measurement use streaming scans without temporary offset-vector allocations.

The new field is single-line and uses an explicit focus order; it is not a retained/native widget system. The grapheme algorithm is not full Unicode UAX #29, and the existing bitmap font glyph coverage remains primarily ASCII (no Thai shaping or TTF/OTF). Clipboard can be unavailable in headless SDL environments. See [`docs/UI.md`](docs/UI.md), [`docs/LIBRARIES.md`](docs/LIBRARIES.md), [`syntax/fac_spec.fac`](syntax/fac_spec.fac) and [`docs/STATUS.md`](docs/STATUS.md).

---

## V105: Canvas UI controls and Grid layout

V105 extends `ui.fac` with a mouse/keyboard dropdown (`dropdown`), a vertical radio group (`radioGroup`) and a multi-column `Grid` layout helper. Dropdown Up/Down navigation, Enter/Esc close behavior and list scrolling are implemented in FAC source using the existing `graphic.key` input API. No compiler grammar or Runtime ABI changed. UI remains immediate-mode on the software canvas; this does not add native widgets, editable text/IME, general focus traversal, accessibility or TTF shaping. See `docs/UI.md`, `docs/LIBRARIES.md`, `syntax/fac_spec.fac` and `docs/STATUS.md`.

---


## V104: Convex polygon collision and spatial-hash broad phase

V104 extends the FAC-only `collide` library with `pointInPolygon` for simple concave/convex polygons, `overlapConvexPolygons` for convex-polygon SAT with bounded self-intersection validation, and `SpatialHash` for AABB broad-phase indexing. The spatial hash returns unique candidate IDs only; callers still run an exact narrow-phase collision test. Dynamic scenes can rebuild the index once per frame with `clear()` + `insert()`.

No FAC grammar production or Runtime ABI changed. The syntax, cell-size/range limits, false-positive behavior and validation results are recorded in [`syntax/fac_spec.fac`](syntax/fac_spec.fac), [`docs/LIBRARIES.md`](docs/LIBRARIES.md) and [`docs/STATUS.md`](docs/STATUS.md).

---

## V102: Gameplay library correctness and API additions (previous release)

V102 improves the source-level standard libraries without changing FAC grammar or Runtime ABI. It adds Result-based filesystem predicates/listing (`fs.isFile`, `fs.isDir`, `fs.list`), camera panning (`moveBy`), animation playback controls and overflow-safe time accumulation, tilemap clearing/counting and clipped rectangle fill, and additional collision queries for rays, segments and circles.

It also corrects edge cases: negative camera delta time no longer causes an accidental snap; animation clock updates avoid signed overflow; tilemap dimension multiplication is checked in 64-bit, negative tile IDs are rejected consistently, movement has a bounded substep budget, and drawing validates atlas column count. Collision helpers reject degenerate shapes and `distance` uses `hypot` for better numeric range.

Validation includes the new gameplay-library API fixture at `-O0` and `-O2`, the existing compiler/runtime/API regressions, strict API-contract and formatting checks, and API compatibility against V101. The release does not claim full native OS GUI widgets, TTF text shaping, polygon SAT, continuous collision detection, or broad-phase spatial indexing. See [`docs/LIBRARIES.md`](docs/LIBRARIES.md), [`syntax/fac_spec.fac`](syntax/fac_spec.fac), and [`docs/STATUS.md`](docs/STATUS.md).

---

## V101: Numerical API correctness and Runtime hardening (historical)

V101 improved float64 stability in statistics, tensor, metrics and neural-network operations, made optimizer updates transactional, hardened DataFrame CSV round-trips, and added targeted FAC cleanup-stack guards to audited temporary workspaces. See [`docs/STATUS.md`](docs/STATUS.md) for the full validation record.

---

## V100: Tensor Autograd, DataFrame analytics and GPU compute abstraction


---

## V96: targeted allocation-failure safety for Runtime data structures (previous release)

V96 strengthens Runtime resource safety when C++ STL allocation fails. HashMap insert/update and tombstone compaction preserve a valid old state or roll back the partial mutation. Graph node creation keeps its parallel storage/index consistent; undirected edge insertion reserves both directions before committing either; and clone operations clean up incomplete copies. The guarded Runtime C ABI paths translate caught `std::bad_alloc` / `std::length_error` into FAC OutOfMemory (5). A deterministic failpoint regression tests failures and successful retries. This is a targeted guarantee, not universal recovery for every Runtime allocation path. No syntax, public/Cross-Platform/native API, Standard Library declaration or C ABI changed. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/RUNTIME.md`](docs/RUNTIME.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V95: stack-safe Trie traversal and cleanup (previous release)

V95 removes recursion proportional to key length from the Runtime Trie implementation. `words()` now enumerates with an explicit work stack, `remove()` prunes with parent links, and `clear()` / destruction detach and free nodes iteratively. A Runtime regression uses a 100,000-byte key to verify insert, lookup, enumeration, cloning, removal, clear and destruction. It also passes with a 256 KiB native stack, where the V94 implementation segfaulted.

This strengthens Runtime stability for adversarially long keys without changing FAC syntax, public APIs, ABI, data-structure behavior or ownership rules. No Cross-Platform API or native/platform-specific API was added or changed. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/RUNTIME.md`](docs/RUNTIME.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V94: compilation-wide import and source budgets (historical)

V94 adds compilation-wide resource budgets on top of V93: 2,000,000 total emitted tokens across imported sources, 128 MiB aggregate source text, 4,096 source modules including the entry file, and 128 import-nesting levels. It also releases each source buffer after parsing so import recursion does not retain all ancestor source text. Exceeding a budget fails with a normal compile diagnostic; regression tests cover aggregate-token, aggregate-source-byte, module-count and import-depth limits.

This is a compiler stability/resource-safety guard; it does not change FAC syntax, ownership semantics, `--safe` acceptance, APIs or Standard Library. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/COMPILER_LIMITS.md`](docs/COMPILER_LIMITS.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V92: numeric `math.abs/min/max` result facts for helper overloads (historical)

V92 extends the bounded worker-lifecycle struct-helper overload resolver to recognize the existing numeric result rules of `math.abs`, `math.min`, and `math.max`. `math.abs(value)` uses the same `promote(valueType)` rule as code generation; `math.min(a, b)` and `math.max(a, b)` use the same `commonT(aType, bType)` rule. Operands may be exact scalar expressions or visible local scalar identifiers whose numeric types are proven at the call site. Arbitrary calls and computed/unresolved operands remain unknown. Exact literal forms can also initialize a supported scalar `auto`.

This adds bounded type facts only; it is not general expression inference, constant evaluation, an ownership/borrow/lifetime proof, or a data-race guarantee. It changes no math code generation, grammar, API declaration, Standard Library declaration, Runtime source/ABI, or `--safe` acceptance rule. No Cross-Platform API or native/platform-specific API was added or changed. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V91: `random.int` result facts through `auto` value copies (historical)

V91 extends the bounded struct-helper worker-lifecycle overload resolver so a local `var auto` initialized by `random.int(min, max)` can retain the existing `Int`/`Long` return contract when each bound is either a supported exact scalar expression or an identifier whose scalar type is already proven in the lexical scope at the initializer. A subsequent `auto` value-copy can reuse that proven result type. The result is `Int` when both known integer bounds are no wider than 32 bits and `Long` when either is wider.

Unknown function-call results, computed/unresolved bounds and unsupported declarations remain unknown. The change only feeds bounded facts into the existing `scoreArg` overload ranking; it is not general type inference or expression evaluation, and does not alter `random.int` code generation, ownership, borrowing, Runtime behavior or `--safe` acceptance. No syntax, public API, Cross-Platform API, native/platform-specific API, Standard Library declaration or ABI changed. The V91 fixture verifies narrow/wide identifier bounds, a scalar `auto` copy, conservative unknown cases and identical emitted IR with and without `--warn-unsafe`. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V90: bounded `random.int` result facts for helper overloads (historical)

V90 extends the bounded struct-helper worker-lifecycle overload resolver to mirror the existing `random.int(min, max)` result rule when both source arguments have proven integer types. The result is known as `Int` when both types are at most 32 bits and `Long` when either is wider than 32 bits. This matches the compiler's existing `tableCall()` selection rather than inferring from the numeric values.

The exact fact is supported for direct literals/unary integer expressions, explicitly-declared scalar identifiers visible at the call site, and eligible literal-backed `var auto` initializers. An argument returned by an arbitrary user function, a floating-point argument, an unresolved identifier, or an unsupported expression remains unknown. The resolver still uses ordinary `scoreArg` ranking and does not execute calls or infer general function return types. This only refines lifecycle-summary candidate selection; no syntax, API declaration, Standard Library implementation, Runtime source/ABI, ownership rule or `--safe` acceptance rule changes.

The V90 regression checks narrow `Int`, unary integer, declared wide `Long`, `auto`-initialized results, arbitrary user-defined argument calls and unsupported floating-point arguments, as well as identical emitted IR with and without `--warn-unsafe`. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

# Fac (LLVM) — compiler ภาษา Fac v0.2 · historical V89

C++17 front-end → **LLVM IR** → clang (-O2/-O3) → native executable, พร้อม **runtime ใหญ่ (C++)**

## V89: scalar result facts from the existing built-in API table (historical)

V89 lets the bounded struct-helper overload resolver use scalar return contracts already declared in FAC's built-in API table, when both the canonical function path and argument count match. This covers declared results such as integer, boolean, unsigned integer, floating-point and string returns. It also recognizes a small set of fixed-result runtime built-ins such as `terminal.in.readline()`, `cstr(...)`, `memory.weakAlive(...)`, `memory.sizeof(...)`, `find(...)` and `type(...)`.

Argument-dependent results such as `random.int(...)`, void/pointer/list results, arbitrary user-defined calls and unsupported expressions remain unknown. The resolver still uses the ordinary `scoreArg` ranking; it does not execute calls or infer arbitrary function return types. The new regression covers existing API-table functions including `string.length`, `string.contains`, `time.nowSec`, `crypto.crc32` and `string.upper`, while keeping user-defined calls and `random.int` unknown. It verifies identical emitted IR with and without `--warn-unsafe`. No grammar, API declaration, Standard Library implementation, Runtime source/ABI or safety acceptance rule changed.

See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V88: fixed-result scalar built-in facts for struct-helper overloads (historical)

V88 extends the bounded worker-lifecycle helper overload resolver to recognize built-ins whose result types are explicit in the language contract: `parse(Type, value)` for numeric/boolean targets, `size(...)` and `sizeof(...)` as `Int`, and `strcmp(...)` as `Int`. These facts can be used for direct arguments and supported scalar `var auto` initializers; parsing does not infer the source text. The compiler continues to use the existing `scoreArg` ranking. Arbitrary user-defined function calls remain unknown.

The regression checks direct and inferred numeric/boolean result facts, both size spellings, string comparison, and an arbitrary user-defined integer-returning call remaining unknown. It expects five `must-join`, one `conditional`, and one `unknown` outcome, with identical emitted IR with and without `--warn-unsafe`. This remains bounded lifecycle-summary analysis, not general type inference, ownership transfer, a happens-before proof or data-race guarantee. No syntax, API, Standard Library declaration, Runtime source, ABI or safety acceptance rule changes. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V87: fixed-result string conversion facts for struct-helper overloads (historical)

V87 extends the bounded worker-lifecycle helper overload resolver to recognize the exact `String` result type of a direct built-in `str(value)` argument. The operand is not inferred; overload selection continues to use the existing `scoreArg` ranking. This allows a string overload to be selected where the call-site argument is `str(...)`, while arbitrary user-defined function calls remain unknown.

The regression adds a `string` helper overload, verifies that a direct `str(...)` argument resolves to the conditional-join summary, and verifies that an ordinary user-defined string-returning function remains unknown. It expects four `must-join`, five `conditional`, and three `unknown` outcomes, and verifies emitted IR equivalence with and without `--warn-unsafe`. No grammar, API, Standard Library declaration, Runtime source, ABI, ownership rule or safety acceptance rule changes. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V86: explicit primitive-cast facts for struct-helper overloads (historical)

V86 teaches the bounded worker-lifecycle helper overload resolver to use the explicit result type of `cast(Type, value)` when the target is a built-in primitive type. The fact also flows through supported scalar `var auto` initializers and nested casts. The resolver still uses the ordinary `scoreArg` ranking and does not infer arbitrary calls, binary expressions, class/enum casts, or unknown identifiers.

The regression extends the recursive-unary fixture with direct boolean casts, an `auto` initialized by an integer cast, and nested casts. It expects four `must-join`, four `conditional`, and two `unknown` outcomes, and verifies that `--warn-unsafe` does not change emitted IR. This does not add general expression inference or weaken `--safe`, `--strict-safe` or `--strict-move`. No syntax, API, Standard Library declaration, Runtime source or ABI changed. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

---

## V85: recursive unary-literal facts for struct-helper overloads (historical)

V85 extends V84's bounded unary-literal typing to nested unary chains. Each operator is validated against the recursively resolved operand type: for example `!!false` resolves to `boolean`, and `-~1` resolves through integer promotion and unary numeric typing. The analysis still stops at identifiers, calls, casts, binary/computed expressions and unsupported operators. It uses the existing `scoreArg` ranking and does not perform general expression inference or constant evaluation.

The unary-literal regression now expects three `must-join`, two `conditional`, and two `unknown` workers for its supported cases. The fixture also checks emitted IR equivalence with and without `--warn-unsafe`. No syntax, API, Standard Library declaration, Runtime source or ABI changes; no weakening of `--safe`, `--strict-safe` or `--strict-move`. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V84: unary scalar-literal facts for struct-helper overloads (historical)

V84 recognizes a single unary operator applied directly to a supported scalar literal when choosing a struct-helper overload. `!false` is known as `boolean`; `-1` keeps its integer literal type; and `~1` uses the language's ordinary integer promotion. These facts feed existing `scoreArg` ranking and improve only bounded thread-handle lifecycle summaries.

Identifier operands, nested unary expressions, casts, binary/computed expressions, function calls, member paths and globals remain unknown. This is not general type inference, constant evaluation, ownership transfer, a happens-before proof or a race-freedom guarantee. No syntax, API, Standard Library declaration, Runtime source or ABI changed; no safety flag was weakened.

### V84 validation

The new `worker_join_struct_overload_unary_literal.fac` regression verifies boolean negation, negative integer and integer-complement result types, expecting one conditional and two must-join worker effects. It also checks identical emitted IR with and without `--warn-unsafe`. Full validation and compatibility evidence is recorded in [`docs/STATUS.md`](docs/STATUS.md).

---

## V83: scalar `auto` value-copy facts for struct-helper overloads (historical)

V83 extends the bounded call-site resolver to recognize `var auto` locals initialized from a simple scalar identifier whose visible binding already has a proven primitive type. This supports chains of ordinary scalar value copies from explicit primitive declarations or V82-eligible literal-initialized `auto` locals. The source identifier is resolved before the new declaration is installed, using the exact lexical scope visible at the initializer.

Function calls (including boolean-returning calls), operators, casts, aliases, member paths, globals, unsupported declarations and unknown source values remain unknown. This is not general type inference and does not change ownership, borrowing, Runtime, ABI or safety acceptance. No syntax or API is added. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

### V83 validation

The new `worker_join_struct_overload_auto_copy.fac` regression verifies multi-hop `auto` copies from explicitly typed `boolean` and `int` locals, while a function-call initializer remains unknown. The fixture also checks identical emitted IR with and without `--warn-unsafe`. Full validation and compatibility evidence is recorded in [`docs/STATUS.md`](docs/STATUS.md).

---

## V82: literal-initialized auto facts for struct-helper overloads (historical)


V82 extends the call-site lexical resolver with a narrow, exact rule for `var auto` locals initialized directly by scalar literals. For example, `var auto enabled = true` is known as `boolean`, and `var auto mode = 1` is known as `int` for helper overload selection. The inferred fact is installed only after the initializer and follows the lexical scope active at the call. It uses the same literal type and `scoreArg` ranking as normal compiler overload resolution.

An auto variable initialized by a function call, operator, cast, alias or other computed expression remains unknown. This improves only bounded thread-handle lifecycle summaries; it is not general type inference or an ownership/borrow/lifetime, happens-before or data-race proof. No syntax, API, standard-library declaration, Runtime source or ABI changed; `--safe` was not weakened. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

### V82 validation

The new regression resolves direct-literal `auto` arguments into one conditional and one mandatory helper effect, while an `auto` initialized by a boolean-returning function remains `unknown`. Plain compilation and `--warn-unsafe` compilation emit identical IR. Full build/test and compatibility evidence is recorded in [`docs/STATUS.md`](docs/STATUS.md).

---

## V81: lexical-scope-aware struct-helper overload summaries (historical)

V81 resolves explicit scalar identifier types at the exact helper call site using lexical scope and declaration order. A local declaration in one `if`/`else` branch no longer conflicts with a different declaration in its sibling branch, and a nested shadow stops affecting resolution after its block exits. Parameter bindings and `for`/`foreach`, `switch`/`match`, and `try` scopes are handled conservatively, with unsupported pattern/catch bindings remaining unknown. Overload ranking still uses the compiler's existing `scoreArg` ordering.

Computed expressions, function-call results, inferred/dynamic declarations, globals, member paths, unsupported bindings and ambiguous candidates remain unknown. This refines selection of bounded thread-handle lifecycle summaries only; it does not infer general expression types or establish ownership, borrow/lifetime, happens-before or data-race guarantees. No syntax, Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed; `--safe` was not weakened. The V81 branch-scope fixtures and full validation evidence are recorded in [`docs/STATUS.md`](docs/STATUS.md).

---

## V80: declared-identifier struct-helper overload summaries (historical)

V80 first allowed explicitly declared primitive identifiers to participate in struct-helper overload selection, but gathered same-name declarations across the entire function. Conflicting declaration types therefore remained unknown even when they belonged to separate lexical scopes. V81 refines this by resolving the visible binding at each call site.

---

## V79: literal-aware struct-helper overload summaries (historical)

V79 improves interprocedural worker-lifecycle summaries for value structs containing `ptr thread` fields. The analyzer now checks syntactically certain literal argument types against each overload using the same `scoreArg` ranking used by ordinary compiler overload resolution. A uniquely best candidate can therefore contribute its per-field `must-join` or `conditional` effect even when multiple helpers share the same struct parameter type but differ on a literal argument such as `boolean` versus `int`.

The new regression selects both overloads with boolean and integer literals and expects one `conditional` and one `must-join` worker. V79 intentionally left identifier variables unknown; V80 adds a separate explicit-declaration rule described above. Computed expressions and other uncertain argument forms are not guessed. This remains bounded lifecycle-effect analysis, not a general ownership/borrow contract, happens-before proof or data-race guarantee. No syntax, Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed; `--safe` was not weakened. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

### V79 validation

Exact build, regression, safe/ownership/Runtime/tooling checks and API/documentation audit evidence is recorded in [`docs/STATUS.md`](docs/STATUS.md).

## V78: dependency-worklist interprocedural struct thread-handle summaries (historical)

V78 replaced V77's fixed-point scan with a reverse-dependency worklist. When a uniquely resolved helper's per-field lifecycle summary changes, only callers that depend on that helper are re-analyzed. The previous hard 32-round ceiling is removed, allowing long wrapper chains to converge without repeatedly scanning unrelated functions. If the deterministic evaluation budget is exhausted, all partial aggregate summaries are reset to `unknown` rather than using an unproven partial result.

The V78 imported-module fixture contains 40 reverse-declared helper functions and verifies that a leaf `thread.join` propagates to the entry caller as `must-join`. Recursive cycles, ambiguous overloads, aliases, returns/stores, unsupported captures, methods/dynamic calls and FFI remain `unknown`. This remains lifecycle-effect analysis—not general ownership/borrow checking, not a happens-before proof and not data-race freedom. No FAC syntax, Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed; `--safe` acceptance rules were not weakened. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

### V78 historical validation

Exact build, regression, safe/ownership/Runtime/tooling checks and API/documentation audit evidence is recorded in [`docs/STATUS.md`](docs/STATUS.md).

## V77: fixed-point interprocedural struct thread-handle summaries (historical)

V77 added fixed-point propagation across aggregate helper chains, but limited the scan to at most 32 rounds. V78 replaces that scan with dependency-driven re-analysis and a fail-closed work budget.

## V76: interprocedural value-struct thread-handle lifecycle summaries (historical)

V76 added bounded per-field summaries for eligible free functions receiving value structs with direct or nested `ptr thread` fields. It supported direct joins and calls to already summarized raw `ptr thread` helpers, plus uniquely resolved imported helpers. It was one-pass for aggregate helper summaries, so multi-hop forwarding could depend on source declaration order.

## V75: explicit move-based struct thread-handle ownership transfer (historical)

V75 added existing whole-aggregate `move(source)` tracking for managed local value structs containing direct or nested `ptr thread` fields. It transferred lifecycle state to destination dotted paths and rebound launch-site attribution through explicit move chains. Plain aggregate copies remained unknown; raw `ptr thread` leaf-field partial moves remained unsupported.

## V73: interprocedural thread-handle join summaries (historical)

V73 propagates bounded `ptr thread` join effects across uniquely resolved direct free-function calls. It supports same-module and explicitly imported/module-qualified helper calls, follows multi-hop helper chains using a bounded summary iteration, and distinguishes `must-join`, conditional join, unchanged live handles, and unknown/escaped cases. The resolver filters candidates using tracked handle parameter types, so a `ptr thread` overload can be distinguished from a same-arity `ptr int` overload. Ambiguous overloads, methods/dynamic dispatch, function values, FFI and unsupported aliases remain unknown.

This is parameter-effect propagation, not general interprocedural ownership or a runtime execution proof. A helper's `must-join` summary says the analyzed helper joins that parameter on every modeled exit; it does not prove that the worker's shared data accesses are race-free or that all dynamic caller paths are synchronized. `--safe` continues to reject mutable global payload access. V73 adds no FAC syntax, public API, Cross-Platform API, native/platform-specific API, Runtime source or ABI change. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

### V73 validation

Validation results and known qualification limits are recorded in [`docs/STATUS.md`](docs/STATUS.md). The cross-platform API surface and platform-specific/native API declarations are unchanged in this release.

## V72: worker multiplicity and join-aware lifecycle analysis (historical)

V72 extended the V71 whole-program worker registry with per-activation, loop-repeatable and `parallelFor`-replicated launch classifications. It tracks direct local `ptr thread` handles through bounded structured control flow and reports must-join, may-outlive, conditional, unknown, untracked and Runtime-joined lifecycle outcomes. `parallelFor` is marked Runtime-joined because the current Runtime joins its internal worker threads before returning. Handle escapes, unsupported cleanup paths and interprocedural transfers were unknown rather than guessed.

These were bounded lifecycle facts, not an execution trace or race-freedom proof. Per-activation did not mean one launch per process; a caller may invoke the containing function repeatedly. The cross-worker graph remained candidate-only, and `--safe` continued rejecting mutable global payload access. No source syntax, public API, Runtime source or ABI changed.

### V72 validation

Historical validation results are recorded in [`docs/STATUS.md`](docs/STATUS.md).

## V71: whole-program worker registry and cross-worker candidate graph (historical)

V71 first built a whole-program static registry of direct `thread.start` and `thread.parallelFor` callback sites across loaded functions and initializers. It unified imported global storage identities and reported cross-worker atomic read-from/Release-Acquire/CAS-failure candidates and ordinary conflict pairs. It did not track runtime multiplicity or join lifecycle.

## V70: read-from and release-sequence candidate analysis (historical)

V70 extended V69's per-storage atomic graph with potential read-from pairs and RMW bridge candidates inside one worker-closure analysis. V71 expands the inventory to statically visible worker launch sites across loaded modules while preserving the candidate-only limitation.

## V69: static atomic synchronization graph candidates (historical)

V69 introduced per-storage atomic event nodes and Release-to-Acquire candidate edges. V70 later distinguished all possible atomic read-from source pairs from the narrower Release/Acquire subset.

## V68: atomic memory-order effect summaries (historical)

V68 preserves the legacy `thread.atomicGet/Set/Add/Cas` sequentially-consistent behavior and adds explicit `*SeqCst` spellings as source-level aliases. The `--safe` worker effect summary now records atomic read-side and write-side memory orders separately, including the compare-exchange failure order (`Relaxed` for Release success, `Acquire` for AcqRel success, etc.). This distinction matters for read-modify-write operations: an Acquire RMW does not publish a Release, and a Release RMW does not acquire. Diagnostics identify observed release/acquire-capable operations and mixed atomic/non-atomic access, but explicitly do not claim a synchronizes-with or happens-before edge without proving which release value an acquire reads. Mutable global payloads remain rejected from safe worker closures. No Runtime source or ABI change was required.

### V68 validation

Validation results are recorded in [`docs/STATUS.md`](docs/STATUS.md). The API compatibility baseline remains `api/baseline/current.json`; the four explicit SeqCst spellings are additive aliases to existing runtime symbols.

## V67: lock-aware data-race analysis foundation (historical)

V67 propagates held-mutex context through statically followed direct calls and requires callees to return with the same lock state they received. For each mutable global it reports locks observed across ordinary accesses, the intersection common to all such accesses, and whether any access was unprotected. Global mutex identities are module-qualified; local/parameter shadowing, ambiguous lock handles, loop lock-state changes and try-region mutex operations fail closed. Different locks protecting the same global are no longer conflated merely because their source names look alike across modules. This is still diagnostic evidence, not a whole-program race proof: mutable global payloads remain rejected in safe worker closures, regardless of the observed lock summary. No syntax, public API, Runtime source, or ABI changed. See [`docs/CONCURRENCY.md`](docs/CONCURRENCY.md), [`docs/SAFETY.md`](docs/SAFETY.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

### V67 validation

Linux x86_64: GCC and Clang C++17 `-O0` clean builds passed. Main regression passed 119/119 at both FAC `-O0` and `-O2`; negative 124/124; limits 15/15; safe 213/213; ownership, local borrow, effect contracts, function effects, moves, comptime and Runtime suites passed; Java-style entry 10/10 at both optimization levels; API runner 1/1; tooling tests 69/69; API/standards/docs/format checks passed. API compatibility against V63 baseline: 0 breaking, 0 warning, 0 added. Sanitizer, ThreadSanitizer, cross-OS builds and compiler-host `-O2` qualification were not run.

## V66: typed concurrency effect summaries (historical; extended in V67)

## V65: overload-aware ownership effect resolution

V65 retains parameter type metadata alongside `ref`, `noescape` and `readonly` contracts. Strict-ownership analysis now filters same-name overloads by argument types and uses the best applicable candidate for pointer-retention, pointee-write and local-borrow checks. `ptr int` and `ptr long` are now distinct overload parameter types; exact pointee matches outrank generic pointer compatibility. When an argument type is unknown or overload resolution remains ambiguous, the checker requires all arity-compatible candidates to satisfy the relevant effect, preserving fail-closed behavior. Runtime source, ABI and public API remain unchanged.

## V64: effect-aware function types

V64 carries `noescape` and `readonly` parameter contracts through explicit function-value types, named function values, lambdas and indirect-call lowering. An explicitly typed function variable now requires compatible return/parameter types and effect guarantees; a stronger implementation may satisfy a weaker function type, but a weaker implementation cannot satisfy stronger promises. The effects are compile-time metadata and do not change closure layout or ABI. Indirect-call escape proof remains conservative: a function-value annotation does not by itself make an unknown target trusted for stack-pointer escape analysis.

## V63: nested partial moves and exception-safe cleanup

V63 extends `move()` to metadata-validated nested value-struct paths, for example `move(record.inner.payload)` and `move(record.inner)`. Disjoint sibling projections remain usable; equal or parent/child paths overlap. The strict move checker rejects use-after-move, repeated/overlapping moves, and use of partially moved containing aggregates. Assigning the exact moved field or replacing a containing subaggregate restores the corresponding state.

Moved managed handles are replaced with null; moved managed value structs are replaced with a zero-initialized value. Existing recursive struct drop helpers and the Runtime cleanup stack then release the remaining fields and the moved temporary, including during exception unwinding. The Runtime source, ABI and public APIs are unchanged. This is projection-tracked compiler state plus null/zero sentinels, **not** a universal runtime drop-flag bitmap. Arrays/indexes, enum payloads, class traversal, scalar/raw-pointer fields, heap/indirect roots and arbitrary partially initialized aggregates remain unsupported. Use `--strict-move` or `--secure`. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/MOVE_SEMANTICS.md`](docs/MOVE_SEMANTICS.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`syntax/fac_spec.fac`](syntax/fac_spec.fac).

---


## V62: nested field projections

V62 extends field-sensitive local borrowing to metadata-validated nested struct field paths. For example, `outer.inner.left` and `outer.inner.right` are disjoint, while a path and its prefix (such as `outer.inner` and `outer.inner.left`) overlap. Unknown, indexed, dereferenced and computed paths remain conservative. The V61 `readonly` and `noescape` pointer effects remain unchanged and require `--strict-ownership` or `--secure`; they add no runtime/ABI overhead. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/POINTER_EFFECTS.md`](docs/POINTER_EFFECTS.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V60: initial bounded partial move (historical; extended in V63)

V60 extends `move()` to a direct first-level managed leaf field of a local value `struct`, for example `dyn string name = move(record.name)`. The field handle is loaded and its source slot is set to null; the extracted value is transferred through the existing temporary cleanup stack. The struct's existing drop helper releases the null source field safely and still releases all remaining fields. The CFG `--strict-move` checker tracks each `(local declaration, field)` separately and maintains a partially-moved aggregate marker. Reads/repeated moves of the field and whole-aggregate use are rejected until the field is assigned a new value. Branch joins are conservative; loops are accepted when the moved field is reinitialized on every iteration.

At the original V60 boundary, support was limited to first-level managed leaf fields (`dyn string`, list/data-structure handles, function handles, `obj`, `weak obj`). V60 did not support nested aggregates/paths, enums, arrays, raw `ptr`, scalar fields, classes, parameters, `self`, borrow aliases or heap/indirect storage. FAC raw `ptr` is not managed ownership. V60 used null sentinels rather than general per-field drop flags. V63 later extends Partial Move to metadata-validated nested named value-struct paths; that current behavior is described in the V63 section above. `--strict-move` or `--secure` is required. No public API or Runtime source/ABI change was needed. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V59: noescape pointer parameter contracts

V59 adds `noescape ptr T name` to make pointer-retention behavior explicit at direct call boundaries. Under `--strict-ownership` / `--secure`, FAC function bodies are checked: the pointer and tracked aliases cannot be returned, stored in globals/fields/aggregates/containers, captured in closures, or forwarded to a callee without a noescape contract. Local pointer aliases and direct forwarding to other noescape parameters remain supported. Since V65, the checker uses the best applicable overload when argument types are known; unknown types and ambiguous overloads still require every arity-compatible candidate to promise noescape.

`extern ... (noescape ptr T p)` is a trusted FFI promise, not something the compiler can verify. Only annotate foreign functions whose documented/audited behavior does not retain the pointer. The modifier adds no ABI/runtime overhead and says nothing about pointer validity, nullability, alignment, thread-safety or `nothrow`. Noescape requires `--strict-ownership` or `--secure`; V64 carries `noescape` and `readonly` through function-value signatures and checks effect compatibility; indirect-call escape proof remains fail-closed until the concrete target can be verified. At V59, Partial Move was still deferred; V60 later added the bounded first-level managed-field implementation. See [`NOESCAPE_CONTRACTS.md`](docs/NOESCAPE_CONTRACTS.md), [`OWNERSHIP.md`](docs/OWNERSHIP.md), [`MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), [`FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md), and [`docs/STATUS.md`](docs/STATUS.md).

## V58: bounded dangling-pointer escape analysis

V58 tracks stack-derived pointer provenance from `addr(local)` through local `ptr` variables using declaration identity. Under `--strict-ownership` / `--secure`, it rejects returning a pointer derived from function-frame storage, storing an inner-scope address into a longer-lived pointer variable, storing such addresses into aggregate fields/elements or external/global storage, and capturing stack-derived pointers in closures. Immediate address use in ordinary API/FFI calls remains available; known retaining collection mutators are rejected. Direct pointer arithmetic/cast expression trees are traversed, but helper functions, arbitrary pointer/integer round-trips, opaque FFI, indirect calls and unknown callees can still hide aliases. This is a conservative bounded analysis, not a complete raw-pointer/FFI escape proof. See `docs/STATUS.md`, `docs/OWNERSHIP.md`, and `docs/MEMORY_MODEL.md`.

## V57: lifetime regions and exceptional control-flow edges

V57 added a lexical lifetime-region tree to strict local-borrow checking. Every local declaration is associated with the region of its enclosing block/loop; each local loan records both its own region and the region of its storage root. The compiler collects and solves explicit `owner-region : outlives : borrow-region` constraints, including parent-region constraints for reborrows. This formalizes the bounded owner-outlives rule for the current local-alias feature; it is not yet a language-level lifetime-parameter or returned-reference system.

The borrow CFG now represents explicit `throw` edges to the nearest catch, routes escaping exceptions through applicable `finally` blocks, and adds conservative exceptional edges from expressions that may call user code or allocate. A `finally` body is analyzed under its enclosing exception handler, so an exception thrown by cleanup continues outward rather than being caught by the try whose cleanup is executing. Because the exceptional paths are now represented, try/catch/finally references no longer need to be globally pinned; `defer` remains pinned to lexical scope exit.

New tests exercise owner-outlives nested reborrows, borrow liveness through a thrown exception and finally cleanup, owner writes rejected before a catch/finally last use, and release after the last use. The work remains bounded: reference return/store types, user-declared lifetime parameters, raw-pointer/FFI escape proofs, general alias analysis, implicit exception guarantees for foreign calls, and whole-program data-race analysis are not complete. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V56: declaration-identity borrow checking

V56 resolves local-borrow aliases and their storage roots to exact lexical declarations. CFG liveness now tracks declaration IDs rather than identifier spellings, so shadowed locals, lambda parameters, foreach variables, catch variables and match bindings do not accidentally extend unrelated loans. Owner access and borrow conflicts also compare exact local storage declarations, and same-name nested reborrows preserve their parent/child relation.

The current checker establishes only a bounded lexical owner-outlives rule for local aliases: roots must be tracked and visible, while reference fields/returns are not part of the current language and unsupported pointer/callback escapes remain guarded. V66 adds typed read/write/alias/lock/atomic summaries to safe worker call chains, but it is not a complete lifetime parameter solver, complete raw-pointer escape proof or whole-program race analysis. See [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V55: CFG borrow dataflow and reborrowing (previous release)

V55 adds a per-function control-flow graph for strict local-borrow analysis. A backwards may-liveness fixed point propagates reference-alias uses through branches, loops and exits; loans can end at the last CFG point on each path instead of being kept alive through an entire structured statement. The implementation remains conservative for exception/finalizer and `defer` paths that are not yet represented with operation-level exceptional edges.

Local reborrows can now be created from an active local alias or `ref` parameter. A mutable parent is suspended while a child borrow is active; a shared parent may only produce shared children. Shared reborrows may be made from either shared or mutable parents.

```fac
public function void update() {
    var int value = 10
    ref var int parent = value
    {
        ref const var int child = parent
        terminal.out.println(child)
        # parent is suspended while child is active
    }
    parent = 20
    value = 30  # allowed after parent is no longer used
}
```

This is a conservative CFG liveness and loan-relationship analysis, not a complete Rust-style Borrow Checker. Reference-return/store types, fully path-sensitive exception effects, precise field/index disjointness, raw-pointer/FFI escape proofs, and whole-program data-race proofs remain incomplete. See [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V53: lexical local borrowing and strict ownership guardrails

V53 adds local storage aliases under `--strict-ownership` / `--secure`:

```fac
import terminal.fac

public function void main() {
    var int value = 10
    {
        ref var int writeView = value
        writeView = 20
        writeView++
    }
    terminal.out.println(value)  # 21; alias writes the original storage
}
```

`ref const var int view = value` creates a shared read-only local alias. V53 checks lexical shared/mutable loans, conflicting owner access, const methods, `move()`/`addr()` restrictions and untracked/const borrow roots. Borrowed aliases do not acquire their own cleanup ownership.

This is a conservative CFG-based local borrow checker, **not** a full Rust-style borrow checker or Lifetime Checker: V53 introduced lexical local loans, V54 added bounded last-use shortening, V55 added CFG may-liveness plus parent/child reborrows, V56 resolves declaration/storage identity, and V57 adds bounded lexical lifetime regions plus exceptional CFG edges; V58 adds bounded stack-pointer provenance and V59 adds direct-call noescape pointer contracts. Globals/statics as borrow roots, reference-valued returns/stores, general lifetime parameters, field-disjoint alias reasoning, complete raw-pointer/FFI escape proof, and static whole-program data-race analysis remain incomplete. V59 checks FAC noescape bodies and requires explicit trusted extern noescape promises; unknown/indirect calls remain outside the proof. See [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md), and [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md).

## V52: compile-time assertions and product target contract

V52 adds module-level `static_assert(expression, "message")`. It evaluates integer/bool constant expressions at compile time, including arithmetic, comparisons, bitwise operations and short-circuit logic. V220 adds a separate bounded `consteval` interpreter for explicitly marked scalar free functions, with local scalar variables, branches, returns, nested calls and recursion under depth/step limits. The type-query intrinsics `typeOf<T>()`, `sizeof<T>()` and `alignof<T>()` provide bounded typed constants for type categories and active target layout. Structural intrinsics `fieldCount<T>()`, `fieldName<T,I>()`, `fieldType<T,I>()` and `fieldOffset<T,I>()` expose public non-static instance-field metadata from resolved struct/class records; numeric queries are compile-time constants, while `fieldName` returns a static string literal. Runtime-dependent consteval arguments, non-struct/class targets and invalid field indexes are compile errors. These facilities are not full generic reflection, arbitrary compile-time execution, source-level AST/declaration generation or a macro system. The compiler also materializes a bounded immutable typed-expression AST projection and internal C++ factories for validated generated expression nodes, non-generic declarations and scalar function bodies. These APIs are not exposed to FAC source code or `consteval`. The bounded Codegen bridge lowers eligible generated structs, body-less external free-function prototypes and supported generated functions with mutable locals, assignments and nested `if/else` branches without mutating source AST ownership. Generated bodies still do not support loops, multiple return paths, branch-local declarations, aggregates, classes/methods, generics or cross-module calls. See `docs/CONSTEVAL_V220.md`, `docs/TYPED_CONSTANT_VALUES_V220.md`, `docs/STRUCTURAL_REFLECTION_V220.md`, `docs/TYPED_AST_BUILDER_V220.md`, `docs/TYPED_AST_FACTORY_V220.md`, `docs/TYPED_DECLARATION_BUILDER_V220.md`, `docs/GENERATED_DECLARATION_CODEGEN_V220.md` and `docs/GENERATED_FUNCTION_BODY_V220.md`.

V52 also formalizes the target matrix for core language features, ownership/borrowing/lifetimes, concurrency, Runtime, standard library, cross/native APIs, OS/architecture ABIs and GPU interoperability. The two API namespaces remain reserved design contracts rather than shipped importable modules. See [`docs/FAC_LANGUAGE_TARGETS.md`](docs/FAC_LANGUAGE_TARGETS.md), [`docs/COMPTIME_METAPROGRAMMING.md`](docs/COMPTIME_METAPROGRAMMING.md), and [`api/standards.json`](api/standards.json).

Example:

```fac
const var int PAGE_SIZE = 4096
const var int ALIGNMENT = 64
static_assert(PAGE_SIZE % ALIGNMENT == 0, "page alignment")
static_assert((ALIGNMENT & (ALIGNMENT - 1)) == 0, "power of two")
```

## V51: CFG-based move analysis

`--strict-move` now builds a control-flow graph and runs a forward fixed-point analysis over move states. It detects use-after-move and repeated moves through loop back-edges, understands branch joins and lexical shadowing, and permits a moved local to be assigned a new value before a later read or loop iteration. Moves in `defer` and closures remain restricted. The `ref` / `ref const` alias checks remain call-site checks; V51 does not claim general lifetime or escape safety.


## V49: Java-style class entry point

FAC now accepts a Java-like class launcher while preserving the existing top-level `public function void main()` form:

```fac
import terminal.fac

public class main {
    public static function void main(list dyn string args) {
        terminal.out.println("Hello, World!")
    }
}
```

The class may use another name such as `App`; its directly declared entry method must be public, static and return `void`. It accepts zero parameters or exactly `list dyn string args`. The compiler generates the native process wrapper, initializes modules, passes command-line arguments excluding the executable path, and performs Runtime shutdown. The two entry-point styles cannot be mixed. Lexer tokens and class/member grammar were already available; V49 adds entry-point discovery, validation and wrapper generation. See [`docs/JAVA_STYLE_ENTRY.md`](docs/JAVA_STYLE_ENTRY.md).
Runnable example: [`examples/java_style_main.fac`](examples/java_style_main.fac); its command-line argument list is an owned `list dyn string` and excludes the executable name.

## Release identity
ทุก component ใช้เลข release เดียวกันจาก `VERSION.toml`: Core / Lib / API / Lang / Runtime / Stdlib. ตรวจสอบความสอดคล้องด้วย `make check-version`; `build/facc --version` แสดงเลข release ของทุก component.


## V48: Worker error propagation and stricter borrow guardrails

- `thread.start` now installs a worker-local FAC error boundary. FAC `throw` errors raised by a worker unwind its FAC cleanup/temporary stacks, are saved on its thread handle and re-raised from `thread.join` with the original error code; uncaught C++ callback exceptions are converted to `Resource` (8) and reported by `join` instead of terminating the process.
- Worker error capture uses a fixed-size, non-allocating message buffer so reporting a failure does not require another allocation. The closure remains retained until worker completion; `thread.join` is still required to observe errors and release the thread handle.
- `thread.start` validates null closures and missing entry functions, and reports allocation/thread-creation failures through FAC errors. Thread join failure while still joinable remains fatal rather than detaching a worker that may outlive captured memory.
- `--strict-ownership` now rejects calls through `ref const` member receivers because FAC does not yet have const-qualified instance methods; it also rejects defaulted and variadic `ref` parameters. These checks are opt-in and do not change ordinary legacy compilation.
- Added runtime tests for successful join, C++ exception propagation, FAC error-code preservation with exactly-once worker cleanup, invalid closure validation, and static ownership negative cases.

## V47: Runtime concurrency hardening

- Hardened `thread.parallelFor`: worker creation failures no longer leave joinable threads inside a vector that is about to be destroyed; already-started workers are joined before a FAC error is raised. A rare OS join failure terminates rather than detaching a worker that could outlive caller-owned memory.
- Work allocation uses a 64-bit atomic cursor so the final worker fetch cannot wrap when the requested iteration count approaches `Int32.MAX_VALUE`.
- Foreign C++ exceptions from a parallel callback are caught inside the worker entry and reported on the calling thread after workers are joined; they no longer escape a `std::thread` entry point and trigger `std::terminate`.
- Added runtime regression coverage for empty/non-positive work, one iteration, 10,000 exact-once iterations, null closure/entry, and callback exception propagation. `thread.parallelFor` may now raise `NullPointer` (6) or `Resource` (8); this is an intentional error-contract expansion. At V47, FAC `throw`/`longjmp` across the worker boundary was not caught; V124 later added the worker-local FAC error boundary and superseded that limitation.
- Runtime inventory and maturity/ABI/safety limitations are documented in [`docs/RUNTIME.md`](docs/RUNTIME.md).

## V46: Generic constraints and static specialization

- Generic type parameters now accept multiple constraints with `&`, for example `T: IReadable & ISerializable`; every listed bound must be satisfied.
- Generic instance/static methods now accept method-level constraints, for example `function<T: IReadable & ISerializable> int score(T value)`. Constraints are checked at compile-time specialization.
- Existing generic method syntax and explicit type arguments remain compatible. Generic interface methods, generic virtual/override dispatch, generic type-argument inference, variance and generic enum methods remain unsupported.
- Added positive and negative regression cases for multi-bound generic classes and method-level generic constraints.

## V45: Language Core and platform contracts

- Added `ref const T` immutable/shared borrow parameters. With `--strict-ownership`, the compiler rejects direct writes through these parameters, direct passing into known mutable-ref parameters, and direct same-storage aliasing when any argument is a mutable borrow. `ref T` keeps its existing mutable-borrow meaning.
- Added `--secure`, a combined profile for `--safe`, `--strict-safe`, `--strict-ownership`, and `--strict-move`. It is the recommended highest-checking V45 build profile, but it is not a proof of complete memory/race safety.
- Added explicit language-core, memory/ownership, concurrency, compile-time/metaprogramming, standard-library and cross/native API roadmaps. These documents clearly separate V45 implementations from planned work.
- Added OS / architecture / object-format / ABI / GPU interoperability inventory in `api/standards.json`, validated by `make standards-check`. The inventory does not turn an LLVM target allowlist into a supported-platform claim.
- Added separate documentation namespaces for `cross.*` and `native.*`; V45 keeps existing top-level imports compatible and does not claim that the reserved namespaces already contain importable modules.

## API consistency and developer tools (V44)

- Standards: [`docs/API_LAYERS.md`](docs/API_LAYERS.md), [`docs/PLATFORM_STANDARDS.md`](docs/PLATFORM_STANDARDS.md), [`docs/API_CONVENTIONS.md`](docs/API_CONVENTIONS.md) (naming, errors, return types, ownership, thread-safety, `##` doc tags),
  [`docs/COMPATIBILITY.md`](docs/COMPATIBILITY.md), [`docs/ERROR_CODES.md`](docs/ERROR_CODES.md), audit report [`docs/API_AUDIT.md`](docs/API_AUDIT.md),
  generated reference [`docs/api/index.md`](docs/api/index.md), examples in `examples/api/`.
- `make api-check` = manifest + audit + compatibility vs last release + docs + contract tags + platform standards inventory. `make tools-check` = tool tests.
- One command for projects: `python3 tools/fac.py new|build|run|test|check|fmt|doc|clean|pkg|lsp|debug` (see [`docs/TOOLING.md`](docs/TOOLING.md)).
- Result-style filesystem API: `import fs.fac` (the built-in `file` module is unchanged).
- No language syntax was changed in V44.

## Build
- Linux/macOS: `./build.sh` (ต้องมี `c++` และ `clang++` ไว้ลิงก์)
- Windows: `build.bat` (ต้องมี LLVM/clang++ ใน PATH)

## ใช้
```
build/facc prog.fac -o prog [-O0|-O1|-O2|-O3] [--run] [--emit-ll]
                    [--no-bounds-check] [--check-overflow] [--no-div-check] [--unsafe-fast] [--safe] [--strict-safe] [--strict-ownership] [--strict-move] [--secure] [--target TRIPLE] [--cpu NAME] [--features LIST] [--sysroot PATH] [--lto]
```
env: `FAC_CC` (path ของ compiler/linker executable หนึ่งไฟล์, ค่าเริ่ม clang++; หากต้องใช้ ccache/wrapper ให้ทำเป็น script), `FAC_RT` (path ของ libfacrt.a), `FAC_KEEP_LL=1` (เก็บ .ll)
`import util.fac` หา `util.fac` ข้างไฟล์หลัก; built-in modules เช่น terminal/string/math/graphic/audio/net และ source-level standard libraries เช่น result/game/camera/tilemap/color/easing/theme/ui/tui อยู่ใน `stdlib/` — ดู `docs/LIBRARIES.md`

## Import แบบ namespace และ global

```fac
import terminal.fac                 # แบบเดิม: terminal.out.println(...)
import terminal.fac as term         # alias: term.out.println(...)
import terminal.fac global          # global mode: out.println(...), in.readline()
import math.fac global              # เรียก sin(...), add-style APIs และใช้ PI ได้โดยตรง
```

`global` นำชื่อ API ที่ export เข้ามาเฉพาะ scope ของไฟล์ต้นทางที่ import ไม่ใช่ global scope ของทั้งโปรแกรม และคง namespace ซ้อนของ API ไว้ เช่น `terminal.out.println` จะเรียกเป็น `out.println` และ `terminal.in.readline` เป็น `in.readline`; ส่วน `math.sin` จะเรียกเป็น `sin` ได้


## Language Core: Native Payload Enum, Option / Result

Native payload enum ใช้ `enum Token { End, Number(int), Pair(int, int) }` แล้วสร้างด้วย `Token.Number(42)` และ destructure ผ่าน `match(token) { case(Token.Number(value)) { ... } }`; ใช้ `_` เพื่อทิ้ง payload ได้ รองรับ scalar, string, list, struct, nested enum, function/closure, object/weak และ raw pointer รวมถึง function parameter/return และ imported enum alias/`just` โดยไม่ต้องใช้ `class` หรือ `obj`. Compiler สร้าง ownership-aware copy/drop/trace callbacks ตาม active variant; payload enum ใช้เป็น element ของ `list` ได้ เช่น `list var Option<string>`, แต่ fixed-size array ยังไม่รองรับ. Raw pointer เป็น non-owning. Cycle collector ไม่ trace เข้าไปใน arbitrary list/closure contents; references ที่ซ่อนใน container เหล่านี้ถูกนับเป็น conservative roots และอาจทำให้ cycle ยังไม่ถูก reclaim. `result.fac` ให้ native `Option<T> { None, Some(T) }` และ `Result<T,E> { Ok(T), Err(E) }`; ใช้ `match` destructure และ postfix `?` propagate `None/Err`. `match` รองรับ expression (`=>`), guard (`if(...)`) และ exhaustive checking สำหรับ enum/boolean ทั้ง statement และ expression. ดู [`docs/LANGUAGE_CORE.md`](docs/LANGUAGE_CORE.md), `examples/option_result.fac`, `examples/native_payload_enum.fac`, `examples/match_expression.fac`, `tests/cases/t104_native_payload_enum.fac`–`t112_managed_match_guard_cleanup.fac`.

ถ้า global imports สองตัวเปิดเผยชื่อระดับบนสุดเดียวกัน หรือชื่อชนกับ declaration ในไฟล์เดียวกัน compiler จะแจ้ง error พร้อมต้นทาง ให้เปลี่ยนไลบรารีที่ชนเป็น `import ... as name` แล้วเรียกผ่าน alias แทน Alias ใช้แทน prefix ของโมดูล เช่น `term.out.println(...)` ส่วน import แบบเดิมยังทำงานเหมือนเดิม

## Performance / ความปลอดภัย (เป้าหมาย: performance สูงมาก, safety สูงมาก, stability สูงมาก)
- ทุกอย่างคอมไพล์เป็น native ผ่าน LLVM; ตัวแปรเป็น alloca → mem2reg/SROA; `internal` + `nounwind` ให้ inline ได้
- `for(int i = 0, i < n, ++i)` รองรับ prefix increment (`++i`) ใน update; counted loop แบบเดิม `for++(n)` / `++for(n)` ยังคงใช้ได้เพื่อ compatibility; รูปแบบถอยหลัง `for--(n)` / `--for(n)` ใช้ counter `for--.i` / `--for.i` (`nuw nsw` + `llvm.loop.mustprogress`) → vectorize/unroll ได้
- เช็กขอบ array/list และหารศูนย์ เป็น branch ที่ถูกระบุว่า unlikely (`!prof`) ปิดได้ด้วย `--unsafe-fast`
- non-`ref` array parameter ไม่ถูก copy ถ้า function ไม่ได้เขียนลงมัน
- อย่าเทียบความเร็วจากภาษาอย่างเดียว: ต้อง benchmark workload เดียวกัน, compiler flags, CPU, runtime checks และ build mode เดียวกัน; ผล benchmark เก่าควรทดสอบซ้ำบนเครื่องเป้าหมายก่อนใช้อ้างอิง
- Runtime (`runtime/fac_rt.cpp`): architecture and safety limits are tracked in [`docs/RUNTIME.md`](docs/RUNTIME.md). V47 hardens `thread.parallelFor`; V48 adds worker-local FAC error handling and `thread.join` error propagation. Runtime uses immutable UTF-8 strings with atomic reference-counted sharing (O(1) copies) and one contiguous allocation per dynamic string; compiler flattens 3+ string-concatenation chains into one allocation/copy; list insert/copy paths protect managed ownership during exceptions; list growth and memory-size arithmetic are checked; temporary managed values unwind on errors; list, hashmap/hashset/tree(AVL)/graph/linked, JSON, regex, file, thread
- สำหรับการประกอบข้อความหลายชิ้น ให้ใช้ `string.join(parts, separator)` แทนการต่อ `+` ทีละชิ้น เพื่อลด intermediate allocations; ดู `docs/PERFORMANCE.md`

## V20 เพิ่มอะไร
`match(value) { case(1..5) { ... } case("FAC") { ... } default { ... } }` สำหรับ pattern matching ของ scalar/string/enum พร้อม inclusive integer ranges, guard, `match(...) { case(...) => expression }`, exhaustive checking ของ enum/boolean, ตรวจ unreachable patterns และ selector แบบ evaluate ครั้งเดียว · `outer: for(...) { ... break outer / continue outer }` (label ของ loop) · `x instanceof Type` + `cast(Class, obj)` (downcast ตรวจชนิดตอนรัน) · แก้ Makefile ให้ runtime ใส่ `-fcf-protection=none` จริง (ไม่งั้น try/catch crash บน Ubuntu/Debian) — รายละเอียด: สเปก §26, `docs/OOP.md`, `docs/STATUS.md`

## Language Core: Pattern Matching และ Payload Enum
ดู [`docs/LANGUAGE_CORE.md`](docs/LANGUAGE_CORE.md) และตัวอย่าง [`examples/match_core.fac`](examples/match_core.fac) สำหรับ `match`, grouped patterns, inclusive ranges, native payload enum และ pattern destructuring.

## Move Semantics (V42)
เปิดใช้ `--strict-move` เพื่อใช้ `move(local)` กับ managed local values และตรวจ use-after-move / double-move แบบ flow-sensitive ใน branch พื้นฐาน; assignment ใหม่ทำให้ local กลับมาใช้งานได้. รองรับ string, list, data structures, closures, objects, weak handles, managed structs และ managed payload enums. ข้อจำกัด: V42 ไม่อนุญาตย้ายจาก parameter/global/field, ไม่อนุญาต move ใน loop/defer/lambda, และการ merge ระหว่าง branches ใช้กฎ conservative (ย้ายใน branch ใด branch หนึ่งอาจทำให้ถือว่า moved หลัง if). นี่ไม่ใช่ Rust-equivalent borrow/lifetime checker. ดู [`docs/MOVE_SEMANTICS.md`](docs/MOVE_SEMANTICS.md).

## สถานะฟีเจอร์ → ดู `docs/STATUS.md`
## ไฟล์ syntax → `syntax/fac_spec.fac` (สเปกต้นฉบับ) และ `syntax/vscode-fac/` (VS Code syntax highlighting: คัดลอกไปที่ ~/.vscode/extensions/)
## ทดสอบ: `tests/run.sh -O2` (ชุด regression tests); `tests/run_neg.sh` (negative tests); `CXX=clang++ tests/runtime/run.sh` (runtime C ABI tests หลัง `make`); sandbox ที่ไม่มี clang ใช้ `FAC_BACKEND=llcheck` + `tools/llcheck.c`

## Low-level / hardware / portability (V16 extension)
- `volatile var int state` emits volatile loads/stores for that storage; `ptr volatile uint reg` emits volatile loads/stores through `[reg]`. Volatile is not atomic and is not a thread-synchronization primitive.
- `align(16) var byte scratch = 0` and `align(32) array var float samples[128] = {}` request extra storage alignment. Supported for `var` storage; not a struct-layout modifier and not a heap allocator alignment guarantee.
- Existing `thread.atomic*` operations default to `seq_cst`; explicit `Relaxed`, `Acquire`, `Release`, and `AcqRel` API variants are available where valid.
- LLVM handles normal optimization and may vectorize suitable loops at `-O2/-O3`; ไม่รับประกันว่าจะ vectorize ทุก loop. `--cpu native` / `--features` และ `--lto` อาจเพิ่ม performance แต่ทำให้ build ผูกกับ toolchain/CPU มากขึ้น (`--lto` ต้องมี LLD). ใช้ `--cpu generic` และไม่เปิด optional features เพื่อเน้น portability.
- `--target TRIPLE` asks Clang to compile/link for another target. Cross-compilation requires a matching 64-bit `libfacrt.a`, target C/C++ toolchain, libraries and sysroot. V16 has 64-bit pointer assumptions; 32-bit targets are not officially supported. See `docs/PORTABILITY.md` and `docs/FFI.md`.

## เรียก C/C++ → docs/FFI.md  (`extern function`, `link "lib"`, `facc prog.fac helper.c -lSDL2`)


## CI / cross-platform validation
GitHub Actions workflow: `.github/workflows/ci.yml`. It builds with `clang++` and runs regression/negative tests on Linux and Windows. A Windows result is only confirmed after that workflow actually completes successfully.

### Classes and objects (initial support)

FAC supports `class`, `obj`, constructors (`constructor Type(...)`), `destructor Type()`, `this.member`, `new Type(...)`, `extends`, `static` members, and `public`/`private`/`protected` access control. OOP includes `interface` (generic parameters, `extends` and default methods), `abstract class`, `implements`, virtual dispatch, `super.method()`, generic class/interface/struct specialization, bounded generic constraints, explicit generic instance/static methods (`function<T> T id(T value)`), access-controlled static fields, and `list dyn obj Name`. Imported types can be referenced as `Module.Type` (for example `import Dog.fac` then `obj Dog.Dog d = new Dog.Dog(2, "Bob")`). See [`docs/OOP.md`](docs/OOP.md) and [`docs/CLASS_OBJECTS.md`](docs/CLASS_OBJECTS.md). Generic payload enums are provided by Language Core (not OOP) and support scalar, string, list, struct, nested enum, function/closure, object/weak and raw-pointer payloads with ownership-aware copy/drop/trace; payload enums can be list elements, while fixed-size arrays remain unsupported. References hidden inside lists/closures are conservative cycle-collector roots, so cycles through these containers may remain allocated. Multiple bounds and method-level constraints are supported in V46 for built-in and nominal non-generic bounds; generic-interface specialization as a method-level bound is not yet claimed. Generic type-argument inference, variance and generic interface/virtual methods remain unsupported. Weak object references are supported by `weak obj` and `memory.weak`/`weakAlive`/`weakLock`; see the Weak References section below. Explicit object-field cycle collection is available as `memory.collectCycles()`; see `docs/OOP.md` and `stdlib/memory.fac` for its safety contract and limits. `public` may precede `class`/`interface`/`abstract class`/`struct`/`enum` (same meaning as without it). Lambda capture rules: [`docs/LAMBDA.md`](docs/LAMBDA.md).

## Terminal UI (TUI) — secondary module

FAC keeps `stdlib/tui.fac` as a lightweight secondary helper for CLI dashboards, build tools and diagnostics. It provides ANSI text styles, panels, tables, status/progress, keyboard hints and simple numeric menus; it is not a full raw-key widget framework. See [`docs/TUI.md`](docs/TUI.md) and `examples/tui_dashboard.fac`.

### Additional source libraries
`import easing.fac` provides normalized easing curves, interpolation/remapping, frame-rate-independent damping, `moveTowards`, `repeat` and `ping-pong` motion helpers. `import color.fac` provides packed `0xRRGGBB` color construction, channel access, interpolation, grayscale, inversion, brightness multiplication and alpha compositing. Both are ordinary FAC source modules with no external dependencies; see `docs/LIBRARIES.md`.


## Canvas GUI / UI Kit

FAC includes source-level `theme.fac` and `ui.fac` modules on top of `graphic`. The canvas GUI is the primary UI direction, with a conventional component API (`button`, `card`, `tabs`, `checkbox`, `toggle`, etc.) plus CSS-inspired reusable `ui.Style` / `ui.Styles` objects and cursor-based `ui.Row` / `ui.Column` layout helpers. The API is immediate-mode: call `ui.beginFrame(canvas)` once after polling events, then draw the current frame. See [`docs/UI.md`](docs/UI.md), `examples/ui_showcase.fac`, `examples/ui_interactive.fac`, and `examples/ui_styles.fac`.

This is a canvas-drawn UI toolkit, not a native OS widget layer. The current text renderer uses the existing scaled bitmap font; it does not provide TTF/OTF or Unicode shaping yet.

UI and Graphics are separate API responsibilities that currently share the same software `graphic` canvas: `three` draws the scene first, then `ui` draws widgets/overlays and reads the same mouse state. `ui.image` blits Graphics images into layouts and `ui.viewportFrame` decorates a scene region. This is not yet a renderer-neutral backend, clipped 3D viewport, or hardware GPU renderer. See [`docs/UI_GRAPHICS.md`](docs/UI_GRAPHICS.md) and `examples/ui_graphics_integration.fac`.


## Security and runtime safety

`--strict-safe` implies `--safe` and additionally rejects function-value or computed indirect calls inside thread closures when the compiler cannot verify the call target. This intentionally trades compatibility for a stronger fail-closed boundary; use direct calls to named functions or move audited synchronization into a small `unsafe` block. It does not provide a Rust-style borrow checker or lifetime system.


- The compiler driver launches the backend with an argument vector (`execvp`/`_spawnvp`), not a shell command. Source, output, runtime-library and extra-file paths are passed as literal arguments. `--pkg` accepts package identifiers made from letters, digits, `_`, `.`, `+` and `-`; shell metacharacters are rejected.
- `FAC_CC` is one executable path/name, not a shell command line. Use a small wrapper script when a compiler launcher needs additional arguments.
- `sys.run` and `sys.output` intentionally execute shell commands for programs that request that capability. Never concatenate untrusted user input into those command strings; validate/allowlist arguments or call a dedicated library API instead.
- `fill` is restricted to byte-copy-safe element types. Managed strings, objects, collections, closures and aggregates containing managed fields require ownership-aware operations and are rejected. `sort(sequence, comparator)` is the supported route for custom element types.
- `make` enables stack canaries and `_FORTIFY_SOURCE=2` by default when supported by the selected GCC/Clang toolchain. Override with `HARDEN_FLAGS=` only when building for a toolchain that does not support these flags.
- Runtime random APIs use per-thread `mt19937_64` engines. This avoids global RNG-lock contention when FAC threads generate random values; a `random.seed()` update is applied by each thread on its next random call. Parallel stream interleaving is intentionally nondeterministic.
- `crypto.randomBytes`, `crypto.randomHex`, `crypto.randomInt` and UUID use the operating-system CSPRNG (Linux `getrandom`/`/dev/urandom`, BSD/macOS `arc4random_buf`, Windows `BCryptGenRandom`) and fail closed when it is unavailable. `crypto.randomInt` batches 4 KiB of OS entropy per thread and uses unbiased rejection sampling across the full `int64` range. This is separate from the non-cryptographic `random.*` APIs, which use per-thread `mt19937_64` engines and an atomic seed epoch.
- Fixed-Huffman image decoding uses thread-safe lazy initialization. SDL loading and video/audio lifecycle operations are serialized; audio volume is atomic, and POSIX playback uses safely-created temporary files with `posix_spawnp`. Network line reads are capped at 1 MiB and TCP ports are validated.
- Additional concurrency/security checks: `CXX=clang++ ./tests/runtime/run_sanitizers.sh` and `make test-tsan`. See [`docs/STATUS.md`](docs/STATUS.md) for exact test scope, caveats and a reproducible `crypto.randomInt` benchmark.
- Run `make test` before distributing a compiler/runtime build. For additional memory checking, use the ASan/UBSan scripts in `tests/sanitizers/`; `tests/runtime/run_sanitizers.sh` also stress-tests concurrent random seeding.


### FAC memory tracking

Call `memory.startTracking()` before the section to measure. The process-wide
switch is one-way and idempotent; it does not reset counters. Use:

- `memory.trackedUsed()`, `memory.trackedPeak()`, `memory.trackedBlocks()` — live
  payload bytes, high-water mark, and number of live tracked blocks.
- `memory.trackedReserved()` — payload plus estimated side-table bookkeeping.
- `memory.trackedAllocs()`, `memory.trackedReallocs()` — successful allocation and
  reallocation calls counted after tracking is enabled.
- `memory.resetPeak()` — reset the high-water mark to current tracked usage for
  phase-by-phase profiling.
- `memory.runtimeStackBytes()`, `memory.runtimeStackPeakBytes()` — current and
  high-water capacity bytes for the calling thread's FAC temporary/cleanup stacks.
- `memory.trimThread()` — release heap spill capacity at an idle point while
  preserving the small inline reserve; returns `false` while managed cleanup or
  temporary entries are active. The default inline reserve is 32 entries per stack.

The counters cover blocks routed through the FAC runtime allocator, including
FAC-managed dynamic strings, list buffers and class-object blocks. Allocations
created before `startTracking()` remain untracked even if later resized/freed.
Tracking is opt-in, so the counter-update work is disabled until requested. Tracking
uses a pointer hash table to reduce side-table memory; a 200,000-allocation benchmark
on this host used about 9% less peak RSS than a tree registry but took about 1.8x as
long. This overhead applies only after opt-in tracking is enabled. The ordinary
allocation path stays headerless and avoids the tracking lock unless tracking is active.
These values are diagnostics, **not total process RSS or exact physical memory**:
STL containers, compiler internals, SDL/libc, foreign libraries, tracking-table allocator overhead, malloc metadata,
allocator arenas, page cache and OS overhead are estimated or excluded. Concurrent reads are
atomic individually, but several counters read in sequence are not one snapshot.

For a reproducible ArrayList capacity/memory profile, build and run:

```bash
g++ -std=c++17 -O2 -pthread benchmarks/memory_profile.cpp build/fac_rt.o -ldl -o build/bench_memory_profile
build/bench_memory_profile 524289
```

The benchmark reports logical FAC payload and list capacity, not process RSS. See
[`docs/STATUS.md`](docs/STATUS.md) for measured tradeoffs
between the 2x and 1.5x growth policies.

## V20 OOP and memory updates

- `weak obj ClassName name = memory.weak(object)` creates a managed weak handle. Use `memory.weakAlive(name)` to check expiration and `memory.weakLock(name)` to obtain a retained `obj ClassName` or `null`. Weak handles are copied/released automatically in locals, parameters, returns, class fields, nested by-value structs and lambda captures.
- Weak handles do not keep objects alive and are ignored by `memory.collectCycles()` graph tracing. The runtime expires them before destructors run.
- Generic methods (inferred `auto` and explicit `function<T>`), generic classes/interfaces/structs (compile-time specialization), multi-bound constraints and method-level generic constraints, destructors, explicit object-field cycle collection, and weak references are implemented. Generic enums are supported in Language Core with scalar and ownership-managed string/list/struct/object/weak/function/closure/nested-enum payloads; payload enums can be stored in lists, while fixed-size arrays remain unsupported; cycle collection does not recursively trace arbitrary list/closure contents, so references hidden there are conservative roots. Generic type/class argument inference and inference for generic methods remain unsupported; the bounded generic free-function inference rules are documented in `docs/CONST_VALUE_INFERENCE_V220.md`. Variance, generic interface methods, and generic virtual/override method type parameters also remain unsupported. See [`docs/OOP.md`](docs/OOP.md), [`docs/STATUS.md`](docs/STATUS.md), [`docs/STATUS.md`](docs/STATUS.md), and [`docs/STATUS.md`](docs/STATUS.md).


## Release V39 — conservative mutable-borrow checks

V39 adds the opt-in `--strict-ownership` pass. For statically known direct calls, it checks pairs of `ref` parameters and rejects arguments whose simple lvalue roots are the same. This includes same-variable aliases and conservatively treats different fields or indexes under one root as potentially overlapping. Distinct local storage remains accepted.

The check is intentionally conservative and incomplete: it does not resolve indirect function values, pointer aliases, dynamic dispatch, or aliases hidden across FFI/runtime boundaries. It does not implement ownership moves, general borrow scopes, or lifetime analysis, and it is not Rust-equivalent. Combine it with `--safe` / `--strict-safe` for the separate raw-pointer and thread-isolation checks. Run `make test-ownership` for the focused positive/negative checks.


## V44 — API consistency, compatibility policy and ecosystem tooling

See [`docs/STATUS.md`](docs/STATUS.md). Run `make api-check tools-check`.


## Release V63 — nested partial move

`--strict-move` / `--secure` can transfer managed values from metadata-validated nested value-struct field paths, such as `move(record.inner.payload)`. Compile-time state is tracked per dotted projection; sibling fields remain usable while the moved path and its aggregate ancestors are protected. Reinitialization restores the exact path or replaces a containing subaggregate. Existing recursive drop helpers and the Runtime cleanup stack handle zero/null sentinels during normal cleanup and exception unwind. See [`docs/STATUS.md`](docs/STATUS.md), [`docs/OWNERSHIP.md`](docs/OWNERSHIP.md), [`docs/MEMORY_MODEL.md`](docs/MEMORY_MODEL.md) and [`syntax/fac_spec.fac`](syntax/fac_spec.fac).


## V206 — managed file-resource lifecycle

V206 adds `file_resource.fac`, an additive standard-library owner for the existing `file.open` native handle. `FileHandle` owns one native file handle, shares that ownership when the managed `obj` is copied, closes on explicit `close()` or when the final strong object reference is released, and makes repeated explicit `close()` calls harmless. Its read/write methods reject use after close. The underlying `ptr file` API and FILE* representation remain unchanged.

The Runtime adds `file.liveHandles()` as a diagnostic count of native handles opened through FAC's built-in `file.open` path. The count is process-wide and is useful for regression/leak checks; it does not include streams created directly by foreign code or describe process-wide OS descriptors. The new regression covers shared owner lifetime, explicit close, repeated close, destructor cleanup and exception/scope exit cleanup. `FileHandle` is not thread-safe and does not make raw `ptr file` values safe; callers using the low-level API remain responsible for closing them. The existing FAC `setjmp`/`longjmp` error model and its C++ destructor limitation are unchanged.

See `stdlib/file_resource.fac`, `docs/RUNTIME.md`, `docs/LIBRARIES.md` and `tests/cases/t85_file_resource.fac`.

## V205 — Trusted FFI Lifetime Contracts

V205 allows `extern function` declarations to carry the same named `lifetime<...>`, `ptr<name> T`, and `where longer: shorter` contracts used by FAC function declarations. The compiler resolves those names to stable indices, validates the call-site lifetime substitution, and propagates pointer-return provenance only from parameters that can satisfy the declared return lifetime. This lets FFI callers retain the same static lifetime checks across an external boundary.

An extern lifetime annotation is a **trusted FFI promise**: the compiler can validate the caller against the declaration, but cannot inspect or prove that foreign code obeys it. The feature adds no native ABI change and does not change Runtime behavior. Indirect/function-value lifetime signatures and pointer provenance stored in aggregate fields/containers remain outside this milestone. See [`docs/LANGUAGE_CORE_V205.md`](docs/LANGUAGE_CORE_V205.md) and [`docs/STATUS.md`](docs/STATUS.md).

## V204 — Call-Site Lifetime Contract Checking

V204 extends named lifetime checking across resolved direct FAC function calls. The compiler instantiates a callee's `lifetime<...>` parameters from the pointer provenance supplied by the caller, unifies arguments that share one named lifetime, and checks declared `where longer: shorter` constraints against the caller's concrete region graph. For a pointer-returning call, result provenance is derived only from pointer parameters whose declared lifetime can satisfy the return lifetime; unrelated arguments are not merged into the result. Calls whose pointer provenance cannot be established are rejected when the contract requires it.

This is a static compiler/language-core change: FAC source syntax and Runtime ABI are unchanged. The implementation remains conservative for ambiguous overload sets, indirect/function-value calls, and pointer provenance stored in aggregate fields or containers. It is not yet a complete interprocedural borrow checker. See [`docs/LANGUAGE_CORE_V204.md`](docs/LANGUAGE_CORE_V204.md) and [`docs/STATUS.md`](docs/STATUS.md).

## V203 — Lifetime Region Inference

V203 connects named function lifetimes to the lexical lifetime-region checker. Pointer parameters annotated with `ptr<a>` seed abstract provenance regions; declared `where longer: shorter` relationships and lexical parent/child scope relationships are solved in one directed outlives graph. Pointer origin facts flow through local pointer aliases and branch merges. Every possible origin reaching a pointer return must outlive the return type's declared lifetime.

```fac
function lifetime<a, b, c> ptr<c> shorten(ptr<a> int value) where a: b, b: c {
    ptr int local = value
    return local
}
```

The function above is valid because the inferred origin `a` outlives `c` through the declared chain, and the function-local pointer alias does not change the referent's origin. Returning a pointer from a parameter with an unrelated/shorter lifetime, or returning an address of function-local storage as `ptr<a>`, is rejected. This release remains intraprocedural: it does not instantiate lifetime constraints across call sites, model pointer-valued aggregate fields, or replace conservative escape checks for unannotated pointers. See [`docs/LANGUAGE_CORE_V203.md`](docs/LANGUAGE_CORE_V203.md).

## V202 — Lifetime Outlives Relationships

V202 added explicit lifetime relationship clauses to function signatures using `where longer: shorter`, with transitive reachability and stable AST indices. V203 now uses those declared relationships during function-body provenance/region checking. See [`docs/LANGUAGE_CORE_V202.md`](docs/LANGUAGE_CORE_V202.md).

## V201 — Named Lifetime Parameter Binding

V201 extends the V200 `lifetime<...>` function declaration syntax by binding names to direct pointer types with `ptr<name> T`. Each annotation is resolved to a stable index in the enclosing function's lifetime parameter list and is preserved by AST cloning. Unknown names, annotations without a function lifetime declaration, annotations on non-pointer types, and return lifetimes not supplied by a matching pointer parameter are rejected.

```fac
function lifetime<a> ptr<a> int choose(ptr<a> int left, ptr<a> int right) {
    return left
}
```

This release establishes signature-level binding only. It does not yet perform interprocedural outlives solving or prove that a function body returns a pointer derived from the parameter carrying the matching annotation. Local pointer escape and return checks remain conservative; see `docs/LANGUAGE_CORE_V201.md`.

## V200 — Named Lifetime Parameter Syntax Foundation

V200 introduced a distinct `lifetime<...>` declaration list on functions, retained separately from generic type parameters in the AST. V201 binds the names to pointer types, V202 adds explicit outlives relationships, and V203 infers function-body regions and validates pointer-return provenance.


## V207 — managed thread-task lifecycle

V207 adds `thread_resource.fac` with the managed `thread_resource.Task` owner for `thread.start` handles. `Task` is created empty, then `adopt()` takes ownership of one native handle returned by `thread.start`. It exposes `cancel()`, `isDone()` and `isCancelled()`, and consumes the handle exactly once with `join()`. Create the owner before starting the worker, and keep `thread.start(lambda)` at the call site so the compiler can inspect callback captures. A failed adoption leaves the raw handle owned by the caller. The final `Task` owner joins an unconsumed worker during destruction. Explicit `join()` is required to observe and propagate worker errors; the destructor suppresses worker errors while ensuring the native thread is joined. The raw `thread.start` / `thread.join` API and ABI remain unchanged. `isDone()` returns true if the Task has not adopted a handle yet, after it has been joined, or when the worker reaches a terminal state.

Task handle operations must be serialized: do not race `join()`, `cancel()`, status queries or final-owner destruction. Do not capture a Task in the worker it owns or destroy it from that worker, because fallback cleanup would attempt a self-join. Destruction may block until the callback returns; cancellation remains cooperative and a callback that does not poll `thread.cancelled()` can keep destruction waiting. The managed wrapper does not add detach, timed join, async/await or a typed task result. The existing `--memory-safe` profile continues to reject the raw `thread` built-in module; this wrapper does not override that policy.


## V208 — function-value lifetime contracts and indirect calls

V208 extends named lifetime contracts to explicit function-value types. A callback type can declare `lifetime<...>`, annotate pointer parameters and its pointer return with `ptr<name> T`, and state `where longer: shorter` constraints. The parser binds each lifetime name to a stable index, validates return-source coverage, and preserves the signature through AST cloning, generic substitution and specialization keys. The compiler carries the lifetime shape in the function type and requires assigned function values to provide a compatible contract; lifetime parameter names are alpha-equivalent when their indexed shape and outlives edges agree.

The strict ownership/lifetime checker now applies the callback contract at indirect calls through statically typed function parameters and local function variables. It validates actual argument provenance and `where` constraints and propagates returned-pointer origins only from parameters that can outlive the declared result. Unknown/untracked origins and return escapes remain rejected. An unannotated target cannot satisfy a callback type that requires named lifetimes. `noescape` remains fail-closed for indirect calls: a function-type annotation is not, by itself, proof that the concrete target body has been verified not to retain a pointer. Function-valued aggregate fields, dynamically computed/returned callees, and general target-aware indirect effect verification remain outside this milestone.

This is a compile-time Compiler/Language Core change. No Runtime source, Runtime ABI, public built-in API or UI was changed. See `docs/LANGUAGE_CORE_V208.md`, `docs/OWNERSHIP.md` and `docs/POINTER_EFFECTS.md`.
