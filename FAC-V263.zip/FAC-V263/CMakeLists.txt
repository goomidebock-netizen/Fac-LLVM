cmake_minimum_required(VERSION 3.20)
project(FAC VERSION 0.2.0 LANGUAGES CXX)

include(CheckCXXCompilerFlag)
include(CTest)
include(GNUInstallDirs)
include(CMakePackageConfigHelpers)

option(FAC_ENABLE_HARDENING "Enable supported compiler hardening flags" ON)
option(FAC_BUILD_RUNTIME_TESTS "Build focused Runtime regression tests" ON)
option(FAC_BUILD_BENCHMARKS "Build optional performance benchmarks" OFF)

if(NOT CMAKE_CXX_COMPILER_ID MATCHES "^(GNU|Clang|AppleClang)$")
  message(FATAL_ERROR "FAC currently requires a GCC- or Clang-compatible C++17 compiler; found ${CMAKE_CXX_COMPILER_ID}")
endif()

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(Threads REQUIRED)

# Keep the compiler and the C ABI Runtime as independent, reusable targets.
# CMake's native dependency scanner tracks the included .hpp/.inc implementation
# files without maintaining a hand-written source list.
add_executable(facc src/main.cpp src/lexer.cpp)
add_executable(FAC::Compiler ALIAS facc)
target_include_directories(facc PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/include")
target_compile_features(facc PRIVATE cxx_std_17)

add_library(facrt STATIC runtime/fac_rt.cpp)
add_library(FAC::Runtime ALIAS facrt)
set_target_properties(facrt PROPERTIES
  OUTPUT_NAME facrt
  POSITION_INDEPENDENT_CODE ON
  EXPORT_NAME Runtime
)
target_compile_features(facrt PUBLIC cxx_std_17)
target_link_libraries(facrt PUBLIC Threads::Threads)

if(WIN32)
  target_link_libraries(facrt PUBLIC ws2_32 gdi32 user32 winmm)
else()
  if(CMAKE_DL_LIBS)
    target_link_libraries(facrt PUBLIC ${CMAKE_DL_LIBS})
  endif()
  if(UNIX AND NOT APPLE)
    target_link_libraries(facrt PUBLIC m)
  endif()
endif()

if(FAC_ENABLE_HARDENING)
  check_cxx_compiler_flag("-fstack-protector-strong" FAC_HAS_STACK_PROTECTOR_STRONG)
  if(FAC_HAS_STACK_PROTECTOR_STRONG)
    target_compile_options(facc PRIVATE -fstack-protector-strong)
    target_compile_options(facrt PRIVATE -fstack-protector-strong)
  endif()

  # FORTIFY_SOURCE is a glibc-oriented optimization and is intentionally not
  # forced on macOS or Windows. Only enable it for optimized Linux builds.
  if(CMAKE_SYSTEM_NAME STREQUAL "Linux")
    target_compile_definitions(facc PRIVATE "$<$<OR:$<CONFIG:Release>,$<CONFIG:RelWithDebInfo>>:_FORTIFY_SOURCE=2>")
    target_compile_definitions(facrt PRIVATE "$<$<OR:$<CONFIG:Release>,$<CONFIG:RelWithDebInfo>>:_FORTIFY_SOURCE=2>")
  endif()
endif()

# FAC's Runtime uses a longjmp-based error boundary. Disable CET instrumentation
# only when the selected compiler recognizes the option, matching the Make build.
if(NOT WIN32)
  check_cxx_compiler_flag("-fcf-protection=none" FAC_HAS_CF_PROTECTION_NONE)
  if(FAC_HAS_CF_PROTECTION_NONE)
    target_compile_options(facrt PRIVATE -fcf-protection=none)
  endif()
endif()

set_target_properties(facc PROPERTIES EXPORT_NAME Compiler)

if(BUILD_TESTING)
  add_test(NAME compiler-version COMMAND facc --version)

  find_package(Python3 QUIET COMPONENTS Interpreter)
  if(Python3_Interpreter_FOUND)
    add_test(NAME release-version-manifest
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/check_versions.py")
    add_test(NAME api-compatibility
      COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/api_compat.py"
              check --baseline "${CMAKE_CURRENT_SOURCE_DIR}/api/baseline/V128.json")
  endif()

  if(FAC_BUILD_RUNTIME_TESTS)
    add_executable(fac_runtime_graph_regression tests/runtime/graph_scalability.cpp)
    target_link_libraries(fac_runtime_graph_regression PRIVATE facrt)
    add_test(NAME runtime-graph-regression COMMAND fac_runtime_graph_regression)

    add_executable(fac_runtime_security_regression tests/runtime/security_regression.cpp)
    target_link_libraries(fac_runtime_security_regression PRIVATE facrt)
    add_test(NAME runtime-security-regression COMMAND fac_runtime_security_regression)

    add_executable(fac_runtime_list_error_cleanup tests/runtime/list_error_cleanup.cpp)
    target_link_libraries(fac_runtime_list_error_cleanup PRIVATE facrt)
    add_test(NAME runtime-list-error-cleanup COMMAND fac_runtime_list_error_cleanup)

    add_executable(fac_runtime_finalizer_error_cleanup tests/runtime/finalizer_error_cleanup.cpp)
    target_link_libraries(fac_runtime_finalizer_error_cleanup PRIVATE facrt)
    add_test(NAME runtime-finalizer-error-cleanup COMMAND fac_runtime_finalizer_error_cleanup)

    add_executable(fac_runtime_thread_start_join tests/runtime/thread_start_join.cpp)
    target_link_libraries(fac_runtime_thread_start_join PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-thread-start-join-cleanup COMMAND fac_runtime_thread_start_join)

    add_executable(fac_runtime_cleanup_exception_safety tests/runtime/cleanup_exception_safety.cpp)
    target_link_libraries(fac_runtime_cleanup_exception_safety PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-cleanup-exception-safety COMMAND fac_runtime_cleanup_exception_safety)

    add_executable(fac_runtime_nested_ownership_recovery tests/runtime/nested_ownership_recovery.cpp)
    target_link_libraries(fac_runtime_nested_ownership_recovery PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-nested-ownership-recovery COMMAND fac_runtime_nested_ownership_recovery)

    add_executable(fac_runtime_cycle_collector_graph_safety tests/runtime/cycle_collector_graph_safety.cpp)
    target_link_libraries(fac_runtime_cycle_collector_graph_safety PRIVATE facrt)
    add_test(NAME runtime-cycle-collector-graph-safety COMMAND fac_runtime_cycle_collector_graph_safety)

    add_executable(fac_runtime_cycle_collector_stress tests/runtime/cycle_collector_stress.cpp)
    target_link_libraries(fac_runtime_cycle_collector_stress PRIVATE facrt)
    add_test(NAME runtime-cycle-collector-stress COMMAND fac_runtime_cycle_collector_stress)

    add_executable(fac_runtime_cycle_collector_scalability tests/runtime/cycle_collector_scalability.cpp)
    target_link_libraries(fac_runtime_cycle_collector_scalability PRIVATE facrt)
    add_test(NAME runtime-cycle-collector-scalability COMMAND fac_runtime_cycle_collector_scalability)

    add_executable(fac_runtime_object_registry_safety tests/runtime/object_registry_safety.cpp)
    target_link_libraries(fac_runtime_object_registry_safety PRIVATE facrt)
    add_test(NAME runtime-object-registry-safety COMMAND fac_runtime_object_registry_safety)

    add_executable(fac_runtime_parallel_pool tests/runtime/parallel_pool.cpp)
    target_link_libraries(fac_runtime_parallel_pool PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-parallel-pool-regression COMMAND fac_runtime_parallel_pool)

    add_executable(fac_runtime_system_text tests/runtime/system_text.cpp)
    target_link_libraries(fac_runtime_system_text PRIVATE facrt)
    add_test(NAME runtime-system-text-regression COMMAND fac_runtime_system_text)

    add_executable(fac_runtime_gpu_simd tests/runtime/gpu_simd.cpp)
    target_link_libraries(fac_runtime_gpu_simd PRIVATE facrt)
    add_test(NAME runtime-gpu-simd-regression COMMAND fac_runtime_gpu_simd)

    add_executable(fac_runtime_simd_language tests/runtime/simd_language.cpp)
    target_link_libraries(fac_runtime_simd_language PRIVATE facrt)
    add_test(NAME runtime-simd-language-api COMMAND fac_runtime_simd_language)

    add_executable(fac_runtime_buffer_bounds tests/runtime/buffer_bounds.cpp)
    target_link_libraries(fac_runtime_buffer_bounds PRIVATE facrt)
    add_test(NAME runtime-buffer-bounds-regression COMMAND fac_runtime_buffer_bounds)

    add_executable(fac_runtime_memory_allocator tests/runtime/memory_allocator.cpp)
    target_link_libraries(fac_runtime_memory_allocator PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-memory-allocator-regression COMMAND fac_runtime_memory_allocator)

    add_executable(fac_runtime_memory_tracking_oom tests/runtime/memory_tracking_oom.cpp)
    target_link_libraries(fac_runtime_memory_tracking_oom PRIVATE facrt)
    add_test(NAME runtime-memory-tracking-oom COMMAND fac_runtime_memory_tracking_oom)

    add_executable(fac_runtime_temporary_scratch_pool tests/runtime/temporary_scratch_pool.cpp)
    target_link_libraries(fac_runtime_temporary_scratch_pool PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-temporary-scratch-pool COMMAND fac_runtime_temporary_scratch_pool)

  endif()

  # Keep the Lexer as an independent translation unit and exercise the
  # Parser against that compiled module (not a header-only fallback).
  add_executable(fac_lexer_regression tests/lexer/numeric_literals.cpp src/lexer.cpp)
  target_include_directories(fac_lexer_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
  add_test(NAME lexer-regression COMMAND fac_lexer_regression)

  add_executable(fac_parser_regression tests/parser/parser_regression.cpp src/lexer.cpp)
  target_include_directories(fac_parser_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
  add_test(NAME parser-regression COMMAND fac_parser_regression)
  add_executable(fac_ast_model_regression tests/parser/ast_model_regression.cpp)
  target_include_directories(fac_ast_model_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
  add_test(NAME ast-model-regression COMMAND fac_ast_model_regression)
  add_executable(fac_hir_model_regression tests/semantic/hir_model.cpp)
  target_include_directories(fac_hir_model_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
  add_test(NAME hir-model-regression COMMAND fac_hir_model_regression)
  add_executable(fac_typed_expr_hir_regression tests/semantic/typed_expr_hir.cpp)
  target_include_directories(fac_typed_expr_hir_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
  add_test(NAME typed-expression-hir-regression COMMAND fac_typed_expr_hir_regression)
  add_executable(fac_scope_overload_hir_regression tests/semantic/scope_overload_hir.cpp)
  target_include_directories(fac_scope_overload_hir_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
  add_test(NAME scope-overload-hir-regression COMMAND fac_scope_overload_hir_regression)
  add_executable(fac_generic_inference_hir_regression tests/semantic/generic_inference_hir.cpp)
  target_include_directories(fac_generic_inference_hir_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
  add_test(NAME generic-inference-hir-regression COMMAND fac_generic_inference_hir_regression)
  add_executable(fac_generic_free_function_hir_regression tests/semantic/generic_free_function_hir.cpp)
  target_include_directories(fac_generic_free_function_hir_regression PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
  add_test(NAME generic-free-function-hir-regression COMMAND fac_generic_free_function_hir_regression)
  add_test(NAME generic-free-function-end-to-end
    COMMAND "${CMAKE_COMMAND}" -E env
            "FAC_COMPILER=$<TARGET_FILE:facc>"
            "FAC_RT=$<TARGET_FILE:facrt>"
            sh "${CMAKE_CURRENT_SOURCE_DIR}/tests/run.sh" -O0 t220_generic_free_function)
  add_test(NAME lifetime-region-inference-integration
    COMMAND "${CMAKE_COMMAND}" -E env "FAC_COMPILER=$<TARGET_FILE:facc>"
            sh "${CMAKE_CURRENT_SOURCE_DIR}/tests/lifetimes/run.sh")

  add_executable(fac_frontend_fuzz tests/fuzz/frontend_fuzz.cpp src/lexer.cpp)
  target_include_directories(fac_frontend_fuzz PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
  add_test(NAME frontend-fuzz-regression COMMAND fac_frontend_fuzz)

  if(FAC_BUILD_RUNTIME_TESTS)
    add_executable(fac_runtime_buffer_fuzz tests/fuzz/buffer_fuzz.cpp)
    target_link_libraries(fac_runtime_buffer_fuzz PRIVATE facrt)
    add_test(NAME runtime-buffer-fuzz-regression COMMAND fac_runtime_buffer_fuzz)
  endif()

  if(UNIX)
    add_executable(fac_runtime_refcount_concurrency tests/runtime/refcount_concurrency.cpp)
    target_link_libraries(fac_runtime_refcount_concurrency PRIVATE facrt Threads::Threads)
    add_test(NAME runtime-refcount-concurrency COMMAND fac_runtime_refcount_concurrency)
  endif()

  add_test(NAME memory-safe-profile
    COMMAND "${CMAKE_COMMAND}" -E env "FAC_COMPILER=$<TARGET_FILE:facc>"
            "FAC_HOME=${CMAKE_CURRENT_SOURCE_DIR}"
            sh "${CMAKE_CURRENT_SOURCE_DIR}/tests/memory_safe/run.sh")

  add_test(NAME package-install-consumer
    COMMAND "${CMAKE_COMMAND}"
      "-DFAC_BUILD_DIR=${CMAKE_BINARY_DIR}"
      "-DFAC_TEST_SOURCE=${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/consumer"
      "-DFAC_TEST_BINARY=${CMAKE_CURRENT_BINARY_DIR}/package-consumer"
      "-DFAC_INSTALL_PREFIX=${CMAKE_CURRENT_BINARY_DIR}/package-install"
      "-DFAC_GENERATOR=${CMAKE_GENERATOR}"
      "-DFAC_CXX_COMPILER=${CMAKE_CXX_COMPILER}"
      "-DFAC_CONFIG=$<CONFIG>"
      -P "${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/package_consumer.cmake")
endif()

if(FAC_BUILD_BENCHMARKS)
  add_executable(fac_cycle_collector_bench benchmarks/cycle_collector.cpp)
  target_link_libraries(fac_cycle_collector_bench PRIVATE facrt)
  add_executable(fac_allocator_bench benchmarks/allocator_small.cpp)
  target_link_libraries(fac_allocator_bench PRIVATE facrt)
  add_executable(fac_temporary_scratch_bench benchmarks/temporary_scratch.cpp)
  target_link_libraries(fac_temporary_scratch_bench PRIVATE facrt)
endif()

install(TARGETS facc facrt
  EXPORT FACTargets
  RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}"
  ARCHIVE DESTINATION "${CMAKE_INSTALL_LIBDIR}"
  LIBRARY DESTINATION "${CMAKE_INSTALL_LIBDIR}"
)
install(DIRECTORY include/fac DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}")
set(FAC_INSTALL_CMAKEDIR "${CMAKE_INSTALL_LIBDIR}/cmake/FAC")
configure_package_config_file(
  cmake/FACConfig.cmake.in
  "${CMAKE_CURRENT_BINARY_DIR}/FACConfig.cmake"
  INSTALL_DESTINATION "${FAC_INSTALL_CMAKEDIR}"
)
write_basic_package_version_file(
  "${CMAKE_CURRENT_BINARY_DIR}/FACConfigVersion.cmake"
  VERSION "${PROJECT_VERSION}"
  COMPATIBILITY SameMajorVersion
)
install(EXPORT FACTargets
  FILE FACTargets.cmake
  NAMESPACE FAC::
  DESTINATION "${FAC_INSTALL_CMAKEDIR}"
)
install(FILES
  "${CMAKE_CURRENT_BINARY_DIR}/FACConfig.cmake"
  "${CMAKE_CURRENT_BINARY_DIR}/FACConfigVersion.cmake"
  DESTINATION "${FAC_INSTALL_CMAKEDIR}"
)
