# FAC Language Core — V182

## Scope

V182 is the next increment after V181. It is intentionally a correctness/diagnostics increment, not a broad syntax release.

### Implemented

- Local-borrow conflict diagnostics identify the alias that keeps the owner or parent inaccessible.
- When that alias is a local declaration, the diagnostic includes its source declaration line.
- Conflicts against signature-level `ref` parameters identify the parameter contract.
- The ownership regression suite checks that a mutable local borrow blocks an owner write and that the error points back to the borrow declaration.
- The version manifest, public version header, README, status record and release-version checker agree on V182.

### Semantic behavior

This change does not alter the borrow checker's accept/reject rules. It leaves the V181 CFG-based NLL computation, lexical lifetime regions, parent/child reborrow tracking and pointer-origin escape checks intact. Existing conservative rejection remains intentional where storage identity, escape lifetime, indirect calls, closure retention, FFI or raw-pointer aliasing cannot be proven.

### Explicit non-goals

V182 does not claim:

- general lifetime parameters or an outlives constraint solver across function signatures;
- borrow checking for arbitrary returned/stored references;
- complete raw-pointer alias tracking;
- soundness for every FFI, dynamic dispatch or closure escape path;
- Rust-equivalent memory safety.

## Validation gate

A change to ownership semantics must include positive and negative tests, including branch joins, loops, exceptions/finally, `defer`, shadowing, reborrows and pointer escape. V182's diagnostic-only change passed: clean CMake Debug build, CTest 28/28, local-borrow suite 93/93, all ownership suites, main compiler fixtures 127/127 at `-O2`, lexer/parser/semantic/move/comptime/generic/codegen suites, negative 132/132, limits 21/21, safe profile 430/430 and memory-safe profile 25/25. The version-manifest check and `facc --version` both confirm V182 across all public components. Windows/macOS/ARM64 and sanitizer qualification were not performed for this increment.

## Sequence

Language Core remains the active phase. Compiler architecture/performance work must not be presented as complete until the Language Core items have been implemented and validated. Subsequent release archives increment the source release number by exactly one (V183 after V182).
