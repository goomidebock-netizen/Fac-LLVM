# FAC V210 — Build reliability and optimized compiler profile

## Independent build targets

The GNU Make build has three public entry points:

```sh
make compiler-only   # build build/facc
make runtime-only    # build build/libfacrt.a
make -j2 all         # build both
```

The Compiler and Runtime are separate artifacts and can be built independently. The compiler and Runtime object files both emit Make dependency files (`build/facc.d` and `build/fac_rt.d`), so edits to included headers and `.inc` files rebuild the affected object.

## Build-configuration tracking

Make records the effective Compiler compile, Runtime compile, link and archive settings in separate configuration stamp files under `build/`. Compiler flags are controlled by `COMPILER_CXXFLAGS` (default `-std=c++17 -O1`); Runtime flags are controlled by `CXXFLAGS` (default `-std=c++17 -O2`) plus optional `RT_CXXFLAGS`. If the compiler executable, preprocessor flags, either optimization profile, hardening options, Runtime-only flags, linker flags, or archiver settings change, the relevant stamp timestamp changes and Make rebuilds the affected artifact. Changing only `RT_CXXFLAGS` does not invalidate the Compiler object. An identical invocation leaves the stamp timestamp unchanged and retains incremental behavior.

For example, changing only optimization flags is no longer silently ignored because an older object already exists:

```sh
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O0'
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O2'
```

The second invocation recompiles the compiler object with `-O2`. Runtime optimization is controlled separately with `CXXFLAGS`, so an optimized Runtime can be retained while selecting a faster-to-build Compiler profile.

## Clean build profiling

The profiling helper performs independent clean builds (serial by default to limit peak memory), captures the full command output, and writes a JSON report with compiler version, host platform, exact flags, samples and median wall time:

```sh
# Isolate the compiler translation unit / driver build
python3 tools/profile_build.py --target compiler-only --cxx clang++ \
  --compiler-flags '-std=c++17 -O1 -ftime-trace' --runs 1

# Profile the full build more robustly across repeated clean runs
python3 tools/profile_build.py --target all --cxx g++ \
  --compiler-flags '-std=c++17 -O1 -ftime-report' \
  --flags '-std=c++17 -O2 -ftime-report' --runs 3 --jobs 1
```

Set `--jobs 2` (or `PROFILE_JOBS=2` with `make profile-build`) only when the host has enough memory. Each build has a 30-minute timeout by default; override with `--timeout-seconds` or `PROFILE_TIMEOUT` on unusually slow hosts. Reports and per-run logs are written below `build-profile/`. `-ftime-trace` is supported by Clang; `-ftime-report` is supported by GCC. Select the matching flag for the selected compiler. The report records Compiler and Runtime flags independently. It measures clean build wall time; it is not a substitute for FAC program runtime benchmarks.

GitHub Actions runs a GCC optimized compiler-only profile and uploads the report/log as an artifact. Hosted CI results must be inspected after the workflow completes; a configured workflow is not evidence of a pass until it has run.

## Compiler translation-unit boundary

V130 does not split the Compiler into multiple translation units. `Gen` currently has a large inline implementation assembled from multiple `.inc` fragments, while Parser, Ownership and Move analysis share concrete AST definitions. Extracting these methods safely requires an explicit declaration/definition boundary and link-time API design, not simply moving include fragments into `.cpp` files. The new profiling job is intended to provide compiler-phase evidence before that structural refactor is attempted.

## V210 local observation (single run, not a performance claim)

A clean GCC compiler-only build with `-std=c++17 -O1 -DNDEBUG` completed in **32.52 seconds** with peak reported RSS of **964,940 KiB** on the Linux x86_64 development host. This is one sample, not a stable median. GCC `-O2` and Clang `-O2` compiler-only builds each exceeded a 300-second session limit and are not claimed as successful. The release therefore uses a separately configurable, optimized `-O1` host Compiler build by default while retaining Runtime `-O2`. Use the profiling helper on the target host to gather repeated measurements under its normal resource conditions.
