# FAC compatibility policy (V63)

## What is covered

The **public API** is: every name in `api/manifest.json` (built-in functions and constants, public
declarations of `stdlib/*.fac`), with its parameter types, return type, ownership contract and
documented error behaviour; the `Error` struct and the error codes in `docs/ERROR_CODES.md`; the
compiler command-line flags listed by `facc --help`; the `fac.toml` / `fac.lock` formats.
Not covered: undocumented behaviour, the text of error messages, generated IR, runtime internals,
the `tools/` scripts' internal Python modules.

## Versions

| Number | Meaning |
|---|---|
| release label `Vnn` (VERSION.toml) | one per delivery; the unit of deprecation windows |
| compiler version `x.y.z` (`facc --version`) | what `[compat] fac = "..."` in `fac.toml` refers to |

While the compiler is `0.y.z` (pre-1.0), **minor (`y`) is the breaking-change boundary**: releases that only change
`z` or the `Vnn` label never break source compatibility. From `1.0.0` the usual rule applies (breaking only in a major).

## Rules

1. **Additive is always allowed**: new functions, modules, flags, error codes, optional fields.
2. **Never changed in place** (inside one compiler minor): a public name's parameter types, return type,
   ownership/consumption rule, or whether it throws. Needed change = add a new name (`tryX`, `Result` variant,
   `...V2`) and deprecate the old one.
3. **Deprecation**: the old name stays and keeps working for at least **3 releases** (`deprecated_in` = Vn,
   `remove_not_before` ≥ Vn+3) and until the next compiler minor. It is recorded in `api/meta.json`
   (`aliases[]`, status `deprecated`) and appears in `docs/API_AUDIT.md` and the generated reference.
4. **Removal** happens only after its window, in a release whose notes say so, and never silently:
   `tools/api_compat.py check` fails on removal-before-window.
5. **Error codes** are never renumbered or reused. A function that gains a new failure mode gets a new
   code and the manifest records it (reported as WARNING by the compat check).
6. **Language syntax**: no change is made without asking the project owner first; syntax is outside this
   document's scope and any syntax change needs its own proposal.
7. **Docs and tooling formats** (`fac.toml`, `fac.lock`, manifest schema): new optional keys are additive;
   `manifest_version` changes only with a migration note.

## How it is enforced

```
make api-check       # manifest fresh + audit (baseline) + compat vs last release + docs fresh + contract tags
python3 tools/api_compat.py check            # compare against api/baseline/current.json
python3 tools/api_compat.py snapshot         # after release validation, advance current.json to this release
```

Only one compatibility snapshot is kept. `api/baseline/current.json` records the latest accepted release (V131 in this tree). Before accepting a newer release, compare its candidate manifest against this file; after the candidate passes and becomes the latest release, run `snapshot` to advance the file. This preserves a one-release compatibility window without accumulating one large JSON file per version. `BREAKING` fails CI; `WARNING` (new deprecations or error-contract changes) must be documented in `docs/STATUS.md`.

## Retained legacy aliases (introduced in V44; reviewed in V63)

| Name | Use instead | Not removable before |
|---|---|---|
| `terminal.out.anwser` | `terminal.out.answer` | V47 |
| `terminal.in.readline` | `terminal.in.readLine` | V47 |
| `file.readline` | `file.readLine` | V47 |
| `file.readall` | `file.readAll` | V47 |
| `file.delete` | `file.remove` | V47 |
| `net.get` | `net.httpGet` | V47 |
| `net.post` | `net.httpPost` | V47 |

Recorded aliases that are **not** deprecated (same implementation, kept for convenience): `string.indexOf`,
`file.exists`, `file.isFile`, `thread.sleep`, `graphic.delay`, `unichar.toInt`. The compiler does not emit a
warning when a deprecated name is used yet; adding that is a compiler change, tracked in `docs/TOOLING.md`.

## Migrating code

Every deprecated name above is an exact synonym (same runtime function), so migration is a pure rename. For
the error-style inconsistency of the `file` family, switch to `fs.fac` (returns `Result`), see `examples/api/03_errors.fac`.


## V48 notes

- `thread.start` now reports invalid closure/entry errors and out-of-memory/thread creation failures; `thread.join` propagates worker FAC errors. This expands runtime error behavior without changing the API signature.
- `--strict-ownership` adds conservative opt-in rejections for member calls through `ref const` receivers and for defaulted/variadic `ref` parameters. Ordinary compilation without this flag is unchanged.
