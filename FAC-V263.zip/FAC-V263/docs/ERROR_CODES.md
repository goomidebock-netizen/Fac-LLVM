# FAC runtime error codes

`Error` is a built-in struct `{ dyn string msg ; var int code }`. The runtime throws it with the codes below; the lists are produced by `tools/api_manifest.py` from the `do_throw(..., code)` call sites (direct and through helpers). Out-of-memory (5) can be raised by any allocating API and is not repeated per function.

| Code | Name | Raised by (built-ins) |
|---|---|---|
| 2 | IndexOutOfRange | `autograd.add`, `autograd.backward`, `autograd.backwardSeed`, `autograd.neg`, `autograd.pow`, `autograd.tensorAdd`, `autograd.tensorBackward`, `autograd.tensorBackwardSeed`, `autograd.tensorGrad`, `autograd.tensorHadamard`, `autograd.tensorMatmul`, `autograd.tensorMean` … (+21) |
| 3 | DivisionByZero | `autograd.add`, `math.mod`, `tensor.add`, `tensor.divide`, `tensor.hadamard`, `tensor.sub` |
| 4 | AssertionFailed | `tls.wrapClient`, `tls.wrapServer` |
| 5 | OutOfMemory | (language/runtime: see below) |
| 6 | NullPointer | `autograd.add`, `autograd.backward`, `autograd.backwardSeed`, `autograd.neg`, `autograd.pow`, `autograd.tensorAdd`, `autograd.tensorBackward`, `autograd.tensorBackwardSeed`, `autograd.tensorGrad`, `autograd.tensorHadamard`, `autograd.tensorMatmul`, `autograd.tensorMean` … (+173) |
| 7 | Io | `audio.saveWav`, `crypto.sha256File`, `data.loadCSV`, `data.saveCSV`, `file.append`, `file.eof`, `file.flush`, `file.modified`, `file.open`, `file.readAll`, `file.readLine`, `file.readLines` … (+10) |
| 8 | Resource | `autograd.add`, `autograd.backward`, `autograd.backwardSeed`, `autograd.neg`, `autograd.pow`, `autograd.tensorAdd`, `autograd.tensorBackward`, `autograd.tensorBackwardSeed`, `autograd.tensorGrad`, `autograd.tensorHadamard`, `autograd.tensorMatmul`, `autograd.tensorMean` … (+181) |
| 9 | Regex | `regex.count`, `regex.find`, `regex.findAll`, `regex.groups`, `regex.match`, `regex.replace`, `regex.split` |
| 10 | Json | `json.at`, `json.bool`, `json.compact`, `json.float`, `json.get`, `json.int`, `json.parse`, `json.pretty`, `json.push`, `json.set`, `json.str`, `json.stringify` … (+2) |
| 11 | Network | `net.accept`, `net.connect`, `net.get`, `net.httpGet`, `net.httpPost`, `net.listen`, `net.post`, `net.recv`, `net.recvAll`, `net.recvExact`, `net.recvExactBytes`, `net.recvLine` … (+11) |
| 12 | TimeParse | `time.day`, `time.format`, `time.formatUtc`, `time.hour`, `time.iso`, `time.minute`, `time.month`, `time.parse`, `time.second`, `time.utcOffset`, `time.weekday`, `time.year` |
| 13 | Encoding | `crypto.base64Decode`, `crypto.hexDecode`, `crypto.pbkdf2`, `crypto.randomBytes`, `crypto.randomHex`, `crypto.randomInt`, `crypto.uuid`, `net.sendBytes`, `string.fromBytes`, `tls.sendBytes` |
| 14 | Media | `audio.create`, `audio.gain`, `audio.mix`, `audio.saveWav`, `audio.tone`, `audio.volume`, `autograd.add`, `autograd.neg`, `autograd.pow`, `autograd.tensorAdd`, `autograd.tensorBackward`, `autograd.tensorBackwardSeed` … (+37) |
| 15 | Process | `sys.output` |
| 16 | Concurrency | `autograd.add`, `autograd.backward`, `autograd.backwardSeed`, `autograd.free`, `autograd.neg`, `autograd.pow`, `autograd.tensorAdd`, `autograd.tensorBackward`, `autograd.tensorBackwardSeed`, `autograd.tensorFree`, `autograd.tensorGrad`, `autograd.tensorHadamard` … (+14) |
| 17 | IntegerOverflow | (language/runtime: see below) |
| 18 | Math | `autograd.add`, `autograd.backward`, `autograd.backwardSeed`, `autograd.neg`, `autograd.pow`, `autograd.tensorAdd`, `autograd.tensorBackward`, `autograd.tensorBackwardSeed`, `autograd.tensorGrad`, `autograd.tensorHadamard`, `autograd.tensorMatmul`, `autograd.tensorMean` … (+160) |
| 19 | Database | (language/runtime: see below) |

## Known inconsistencies

- **Code 7** is used for file I/O failures *and* for object-model errors (null object method call, failed downcast, object size overflow). Prefer matching on `msg` prefix or use the `fs.fac` wrappers, which classify the failure.
- Codes **8** (resource/limits) and **14** (media) group several unrelated sources.
- Compatibility rule: codes are never renumbered; new failure kinds get new numbers (see `docs/COMPATIBILITY.md`).
