# V181 temporary scratch-buffer benchmark

`benchmarks/temporary_scratch.cpp` repeatedly calls Runtime stable sort, reverse, and aliased list insertion/removal. It initializes source data outside each timed operation and reports the median per-call latency for small and medium cases. Build with `cmake -S . -B build-bench -DCMAKE_BUILD_TYPE=Release -DFAC_BUILD_BENCHMARKS=ON`, then build `fac_temporary_scratch_bench`, or use `make bench-temporary-scratch`.

The V180/V181 comparison used GCC 14.2 Release Runtime archives and the same `-O3 -DNDEBUG` harness, pinned to CPU 0. Nine alternating process pairs ran seven timed samples per process. Per-operation timings varied with the operation and process pair; there was no consistent end-to-end latency reduction, so V181 makes no general speedup claim. The measured benefit is reuse of the warmed 64/256/1,024-byte thread-local scratch blocks without repeated upstream allocation for eligible temporary sizes. Cache retention is capped at 1,392 bytes per thread and is released by `fac_runtime_trim_thread()` or thread exit. Results are synthetic, local to the test host, and are not a claim that overall heap fragmentation or whole-program performance improves.

---

# V180 small-allocation benchmark

`benchmarks/allocator_small.cpp` tests small-block allocation with optional memory diagnostics. It reserves its pointer vector outside the timed region, then allocates 160,000 blocks of 24–55 bytes, reallocates every other block to 80–95 bytes, frees the blocks and checks the FAC tracked byte/block counters return to zero. It uses one warm-up and nine timed samples and reports the median. The benchmark distinguishes the normal `plain` path from the opt-in `tracked` path:

```sh
make bench-allocator
# Or run the two modes independently:
build/bench_allocator_small plain 160000 9
build/bench_allocator_small tracked 160000 9
```

The `fac_allocator_bench` CMake target is available when configured with `-DFAC_BUILD_BENCHMARKS=ON`. The test has no external dependency. On the Linux x86-64 / GCC 14.2 development VM, five alternating V179/V180 process pairs were pinned to CPU 0. Runtime used `-O2` with identical hardening flags and the harness used `-O3 -DNDEBUG`. The median of process medians for `tracked` was 157.55 ns/op (V179) versus 76.53 ns/op (V180), 51.4% lower. Untracked runs varied enough that no plain-path gain is claimed. These numbers describe only the synthetic memory-tracking workload.

---

# V179 Cycle Collector benchmark

`benchmarks/cycle_collector.cpp` measures only `fac_obj_collect_cycles()` after a graph has been fully constructed and all builder references have been released. The graph builder creates strongly-connected directed graphs with configurable out-degree. Cases include sparse graphs from 1,024 to 32,768 nodes, dense graphs through 512 nodes, and rooted sparse/dense graphs that must be preserved by conservative root marking. Every sample checks the collected count, live-object count and Runtime allocation-block count; rooted cases are then unrooted and collected as a correctness check.

Build and run with CMake:

```sh
cmake -S . -B build-bench -DCMAKE_BUILD_TYPE=Release -DFAC_BUILD_BENCHMARKS=ON
cmake --build build-bench --target fac_cycle_collector_bench
./build-bench/fac_cycle_collector_bench 9
```

Or use `make bench-cycle-collector`. The optional CMake benchmark target is off by default and introduces no third-party dependency. The benchmark runs one warm-up and reports the median of an odd number of timed collections (default 5; accepted range 3–21). It prints CSV rows including graph shape, node count, edge count, degree, root state and median microseconds. Pin old/new runs to the same CPU where possible and keep compiler, flags, host and sample count identical. The included V178/V179 comparison is a synthetic Linux x86-64 / GCC 14.2 measurement on the same KVM VM pinned to CPU 0. Both Runtime revisions and the benchmark executable used `-O2 -DNDEBUG`; each row is the median of 9 timed samples after one warm-up. Values below are collection-phase microseconds (lower is better):

| Case | V178 | V179 | V179 improvement |
|---|---:|---:|---:|
| Sparse 1,024 nodes, degree 2 | 259.3 | 143.3 | 44.7% |
| Sparse 4,096 nodes, degree 2 | 1,353.4 | 776.4 | 42.6% |
| Sparse 16,384 nodes, degree 2 | 4,329.5 | 3,692.0 | 14.7% |
| Sparse 32,768 nodes, degree 2 | 8,261.0 | 6,961.6 | 15.7% |
| Sparse 32,768 nodes, degree 8 | 11,824.5 | 9,349.4 | 20.9% |
| Dense 128 nodes, degree 127 | 265.3 | 250.8 | 5.5% |
| Dense 256 nodes, degree 255 | 926.7 | 915.5 | 1.2% |
| Dense 512 nodes, degree 511 | 4,045.9 | 3,448.3 | 14.8% |
| Rooted sparse 16,384 nodes, degree 2 | 2,963.9 | 1,401.6 | 52.7% |
| Rooted dense 512 nodes, degree 255 | 1,755.3 | 1,261.4 | 28.1% |

These are host-specific synthetic measurements and do not predict all application workloads. Do not extrapolate them to other hosts or workloads.

---

# V137 object-reference validation microbenchmark

`benchmarks/object_refcount.cpp` measures repeated `fac_obj_retain()` + `fac_obj_release()` on one live object. It performs a short warm-up followed by 9 timed samples and prints the median time per pair. To compare revisions, build the Runtime static library with identical flags and the benchmark executable with identical flags on the same host:

```sh
c++ -std=c++17 -O2 -DNDEBUG -g0 -pthread -c runtime/fac_rt.cpp -o fac_rt.o
ar rcs libfacrt.a fac_rt.o
c++ -std=c++17 -O3 -DNDEBUG benchmarks/object_refcount.cpp libfacrt.a -pthread -lm -ldl -o object_refcount
./object_refcount 5000000
```

A local GCC 14.2 comparison using Runtime `-O2 -DNDEBUG -g0`, benchmark `-O3 -DNDEBUG`, and 9 samples of 5,000,000 pairs measured **25.90 ns/pair (V136)** and **27.13 ns/pair (V137)**, approximately **4.75% slower** for V137 in this narrow case. This is the cost observed for validating the object address through the synchronized live registry on each retain/release. It is a synthetic one-object microbenchmark: it excludes allocation, contention across many objects, object graphs, application work and compiler execution. Do not extrapolate it to overall Runtime performance or claim a general slowdown/speedup from this result alone.

---

# V129 benchmark methodology

The benchmark runner validates the expected stdout checksum on every timed sample and reports median wall-clock time. It builds C/C++ references with `-O2`, FAC binaries with `-O2`, and a separate FAC `--unsafe-fast` binary. `FAC-fast` is diagnostic only: it disables selected runtime safety checks and must not be used as the default production comparison.

For Graph storage, use `make bench-graph-scale` to measure geometric node insertion and a high-degree star workload. For recursion hot-path measurements, use the existing `b01_fib` benchmark via `python3 tests/bench/run_bench.py --only fib --runs 5`. Run old and new revisions with the same compiler, host, flags and run count; do not compare historical best-of-N numbers with current median-of-N results.

---

# FAC benchmarks (V32)

`make bench` (or `python3 tests/bench/run_bench.py`) compiles six programs with `facc -O2`, compiles a C/C++ reference of the
same algorithm next to each, checks that all of them print the same checksum, and reports median-of-N wall time.

| benchmark | what it stresses | reference |
|---|---|---|
| `b01_fib` | function calls / recursion (`fib(42)`) | C |
| `b02_sieve` | `array heap byte` indexing, 20,000,000 entries | C |
| `b03_matmul` | nested loops over `array heap long`, 600x600 | C |
| `b04_collatz` | integer arithmetic and branches (`long`), starts below 3,000,000 | C |
| `b05_list` | `list var long` growth and indexing, 20,000,000 elements | C (realloc doubling) |
| `b06_hashmap` | `hashmap var int, int`: 1,000,000 `set`, `get`, `has` | C++ `std::unordered_map` |

```
benchmark             C      FAC FAC-fast    FAC/C   check cost
```
- **C**: reference built with `-O2`. **FAC**: `facc -O2` with bounds and divide checks on (the default). **FAC-fast**: `facc -O2 --unsafe-fast`.
- **FAC/C** is the number to watch for "C-level performance". **check cost** = FAC / FAC-fast - 1: what the safety checks cost on that program.
- Options: `--runs N`, `--only fib,sieve`, `--facc PATH`, `--cc clang`, `--cxx clang++`. Exit code is 1 on any build failure or checksum mismatch.

## Status of these programs (V32)

- Checksums were computed independently in pure Python (fib 267914296, 1270607 primes below 20,000,000, matmul 253996297, collatz
  `2298025 560`, list sum 9990000000) and the C references print exactly these; the hashmap value follows from the arithmetic.
- **The FAC versions have only been compiled to LLVM IR on the development host (no clang there); they have not been run.** The first run
  on a machine with clang is also a correctness check: a `MISMATCH` line means the FAC program or the compiler disagrees with the reference.
- The runner itself was exercised with a stub compiler (reference path, ratios, mismatch detection).
- Timings depend on the machine; compare ratios, not absolute milliseconds, and use `--runs 5` or more on a busy machine.
