# FAC V162 Runtime Hardening Audit — bounded parallelFor queues

## Scope

V162 bounds pending scheduler metadata in the reusable `thread.parallelFor` pool. It does not change task semantics, callback ownership, the public FAC API, or the Runtime C ABI.

## Queue bound and synchronization

- Each worker's private FIFO queue may contain at most 64 pending `FacParallelJob*` tickets.
- `submit()` selects its participating worker slots while holding the pool mutex. A counter tracks how many queues are exactly at their hard limit; while that count is zero, submission takes a fast path that only records rollback sizes. If any queue is saturated, the selected queues are checked and the caller waits on `spaceAvailable_` until its whole batch can fit.
- The condition-variable wait releases the pool mutex, allowing workers to dequeue tickets. `spaceWaiters_` is protected by the same mutex; workers broadcast only when they pop from a full queue while submitters are waiting, avoiding normal-path broadcast overhead.
- `saturatedQueues_` is incremented only after a complete batch is published when a selected queue reaches 64, and decremented when a worker pops from a full queue. Both changes happen under the pool mutex.
- `stopping_` is checked on every capacity-loop iteration; pool destruction notifies both worker and capacity condition variables.
- Batch publication remains all-or-nothing under the pool mutex. If a queue push throws, every ticket appended by that batch is removed before workers can observe the queues.
- Pool worker callbacks never submit to their own queues for nested `parallelFor`; nested calls continue to run inline.

## Safety limits

The bound limits queued scheduler tickets only. It does not cap the number of external caller threads, callback allocations, or memory retained by closures. The scheduler makes no new priority/fairness guarantee. As before, callers must not design callbacks that synchronously wait for other work which is queued behind them in the same saturated pool.

## Validation

- Runtime shell suite on Linux x86-64 with Clang 17 at `-O2`: passed, with the new bounded-queue stress case (80 concurrent submitters × 96 callback invocations) and existing parallel-pool cold-start, nested-call and concurrent-submission tests.
- Focused GCC 14.2 ASan/UBSan/LSan run of `parallel_pool.cpp` against the latest Runtime object: passed.
- Focused GCC 14.2 ThreadSanitizer run of `parallel_pool.cpp` against the latest Runtime object: passed with `halt_on_error=1`.
- CMake Release build of `fac_runtime_parallel_pool` and CTest `runtime-parallel-pool-regression`: passed with Clang 17.
- Warm-pool microbenchmark on Linux x86-64 with Clang 17, identical Runtime hardening flags and seven alternating process runs: median V161/V162 was 22.102/22.345 ms for 1,000 calls × 8 items (+1.1% V162 latency), and 19.760/19.473 ms for 1,000 calls × 32 items (-1.5% V162 latency). Variation is comparable to the differences; no general speedup is claimed.
- Compiler frontend build exceeded the available execution limit, so compiler-driver integration was not run for this release in this environment.
- No Windows, macOS or 32-bit build/run is claimed.

## Compatibility

No new public symbol, signature, API declaration, FAC syntax, C ABI layout or ownership rule is introduced. Only internal scheduling queue capacity and submission blocking behavior change.
