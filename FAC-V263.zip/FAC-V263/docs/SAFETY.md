## V135 Runtime cleanup update

The fail-closed `--memory-safe` source restrictions are unchanged from V134. V135 adds targeted cleanup of partially built string lists during `sys.args` and JSON array conversion errors. This improves two Runtime failure paths but does not remove the general `setjmp`/`longjmp` destructor limitation or establish Rust-equivalent guarantees. See [`SECURITY_AUDIT_V135.md`](SECURITY_AUDIT_V135.md).

## V134 fail-closed `--memory-safe` subset

V134 adds `--memory-safe` as an opt-in conservative source subset. It rejects raw/opaque pointers, manual heap storage, direct ref borrows, FFI/export/native link, unsafe blocks/functions, native object/linker inputs, and built-ins whose public signatures expose native handles. It enables overflow checks and does not trust source stdlib implementations by default. See [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md) for its exact boundary.

This is not a Rust-equivalent guarantee: FAC still lacks a complete region-based borrow/lifetime checker and a whole-program race proof, and its C++ Runtime remains trusted. Its `setjmp`/`longjmp` error transfer is not equivalent to Rust panic unwinding. `--memory-safe` is not an OS sandbox and does not constrain CPU, filesystem or network access. Targeted tests are regression evidence, not formal verification.

# FAC safety model (V39)

FAC has two levels in one language. **High level** (`string`, `dyn`, `list`, `array var`, `class`/`obj`, `weak`, `enum`/`match`,
`Option`/`Result`) is memory-managed and bounds-checked. **Low level** (`ptr`, `alloc`/`realloc`/`free`, `heap` variables,
`extern` FFI) is C-like and can corrupt memory. V24 makes the boundary between them explicit, the same idea as Rust's `unsafe`.

## `unsafe` and `--safe`

```fac
unsafe function int peek(ptr int p) { return [p] }      # whole body is an unsafe context

public function void main() {
    unsafe {                                            # unsafe block
        ptr int p = alloc(type(Int) * 4)
        [p + type(Int)] = 7
        terminal.out.println(peek(p + type(Int)))
        free(p)
    }
}
```

`unsafe` is always accepted by the parser. Compiling with **`--safe`** turns these operations into compile errors outside an
`unsafe { }` block or `unsafe function`:

| operation | message starts with |
|---|---|
| `[p]` dereference of a raw `ptr` | `deref [..] ของ ptr ดิบ` |
| `p + n`, `p - n`, `n + p` | `การคำนวณ pointer` |
| `alloc(...)`, `realloc(...)` | `alloc(...)` / `realloc(...)` |
| `free(x)` of a `ptr`, heap `array` or heap variable (`free` of `string`/`list` stays safe) | `free(x) ของ ...` |
| calling an `extern function` (FFI) | `การเรียก extern function` |
| calling an `unsafe function` | `การเรียก unsafe function` |

Rules:
- A lambda does **not** inherit the enclosing `unsafe` context; write `unsafe` inside it.
- `--safe` cannot be combined with `--no-bounds-check`, `--no-div-check` or `--unsafe-fast`.
- Modules from `stdlib/` are trusted by default, but since V30 none of them needs it: every stdlib module compiles under
  `--safe --no-trust-stdlib` (checked by `tests/run_safe.sh`; `sync.fac` keeps its raw pointers inside explicit `unsafe` blocks).
  A user file that shadows a stdlib module name is **not** trusted. Use `--no-trust-stdlib` to audit the library.
- `unsafe` is contextual (not a reserved word), so existing identifiers named `unsafe` keep working.
- Without `--safe` behavior is exactly V23 (the generated IR is identical).


## `--safe` is not an operating-system sandbox

`--safe` / `--strict-safe` are compiler static checks for FAC raw-pointer, FFI and thread-closure rules. They do **not** sandbox the process, restrict filesystem access, disable network access, prevent OS process creation, or validate data passed into trusted Runtime APIs. In particular, `sys.run` and `sys.output` still invoke the operating-system shell and must never receive command strings assembled from untrusted input. Use OS-level sandboxing, least-privilege accounts, containers/VMs, filesystem permissions and network policy when executing untrusted programs.

Trusted Runtime / standard-library code is not automatically memory-safe merely because the caller was compiled with `--safe`; it is part of the trusted computing base and must be audited and tested separately. `--safe` also does not provide general CPU, memory, file-size, network or wall-clock quotas.

## Threads (`--safe`): closures must be isolated

`thread.start(...)` and `thread.parallelFor(...)` take a closure that runs on another thread. FAC closures capture by value,
but `ptr`, `obj`, `weak` and `function` values are *shared*, and global variables are shared, so these are the ways two
threads can touch the same memory without synchronisation (a data race). In `--safe` code outside `unsafe`, the closure passed
to these two calls must be isolated:

- it must be a lambda written at the call site (a stored function value cannot be inspected);
- it may capture only copied values (numbers, `string`, `list`, `struct`, ...), **not** `ptr`, `weak`, `function`, or an `obj`
  — except objects of classes in module `sync` (below);
- the closure, and everything it can reach, must not touch non-`const` global variables. "Reach" means: functions called by name
  (`f(x)`, `mod.f(x)`); **every user method whose name matches a method call** (`o.run()`, which also covers virtual dispatch and
  overrides); and the constructors / destructors of `new X()` including parent constructors.

V67 extends this with call-site lock-context propagation: a directly called FAC function is analyzed with the mutex set held at the call site, and must return with that same set. Global mutex identities are module-qualified; the summary distinguishes a common lock across all observed ordinary accesses from mixed locked/unlocked accesses and accesses protected by different locks. Parameter/local shadowing, unknown mutex identity, loop lock-state changes and try-region lock operations fail closed. This remains diagnostic evidence only; it does not establish whole-program race freedom, and mutable global payloads remain rejected in `--safe`.

V66 reports a typed effect summary for the globals it finds: ordinary read/write, address/alias, recognized atomic read/write, and mutex acquire/release observations. It follows statically known named calls and methods; a mutex handle used only with `mutex.lock`/`mutex.unlock` is treated as a synchronization primitive, not shared payload. This metadata improves diagnostics but is not a proof that all accesses use the same lock or that an atomic protocol is complete. The existing conservative rule remains: mutable global payload access is rejected even when the current function appears to hold a lock or uses an atomic call. Anything else needs `unsafe { thread.start(...) }`, which means *you* guarantee the synchronisation.

`sync.Atomic` (`stdlib/sync.fac`) is the audited shared type: an `int` with `get`, `set`, `add`, `cas`, implemented only with atomic operations.

```fac
import sync.fac
obj sync.Atomic hits = new sync.Atomic(0)
thread.parallelFor(1000, function void(int i) { hits.add(1) })
terminal.out.println(hits.get())
```

`sync.Channel` (V26) carries results and work between threads without `unsafe`: a bounded, thread-safe queue of `string`
messages (copied in and out, capacity 1..1048576, every blocking call has a timeout, `close()` wakes all waiters). Use `json`
to send structured data. `recv(timeoutMs)` returns `Option<string>`; `done()` becomes true once the channel is closed and drained.

```fac
obj sync.Channel jobs = new sync.Channel(4)
ptr thread consumer = thread.start(function void() { drain(jobs, got) })      # jobs / got: sync objects, allowed
thread.parallelFor(50, function void(int i) { jobs.send("job", -1) })
jobs.close()
thread.join(consumer)
```

`sync.Cell` (V31) is one shared `string` value: `get`, `set`, `swap(v)` (store and return the old value in one step) and
`cas(expected, desired)` are atomic, the lock is internal and never held across calls, so it cannot deadlock. Use it for "latest
result / current config" shared by threads (`json` for structure). Like `sync.Atomic` and `sync.Channel` it may be captured by
`--safe` thread closures.

**Limits of this check (it is conservative but not a proof):** a method call is matched by *name* against all user classes, so it may
reject a closure because an unrelated class has a method of the same name that touches a global (rename it or use `unsafe`). It does
not follow calls through function values or `dyn` dispatch, and it does not look inside stdlib modules (they are trusted). Reading a
mutable global is also rejected (a concurrent writer would race with it). If the call graph exceeds 64 levels, the compiler rejects
the closure rather than treating the unverified tail as safe. To avoid a scope-related false negative, a local declaration does not
mask a same-named mutable global for this scan; this can conservatively reject a local that shadows that global. There is still no
mutex that owns the data it guards: sharing anything richer than `sync.Atomic` / `sync.Channel` messages needs `unsafe`.

## `--strict-safe`: indirect-call hardening (V37)

`--strict-safe` implies `--safe`. In addition to the checks above, a thread closure is rejected when it calls a function-valued local/global/imported variable, a callable field, or a computed callee whose target cannot be verified statically. This is intentionally conservative: a harmless function value may also be rejected. Prefer a direct call to a named function so the compiler can walk the call graph, or isolate the operation behind an audited API.

This closes a known blind spot in the ordinary `--safe` call-graph scan. It does not prove the behavior of trusted runtime/stdlib code, foreign code, or calls deliberately placed inside `unsafe`; it is not a borrow checker and does not implement ownership or lifetime analysis.

## What is and is not covered (honest status)

In `--safe` code, memory errors can only come from:
- the contents of `unsafe` blocks/functions (as in Rust);
- data races the thread check above cannot see (calls through function values / `dyn`, and state hidden in trusted stdlib modules);
- the conservative cycle collector (`memory.collectCycles()`), which can only keep memory alive, not free it early.

Checked at run time by default: array/list bounds, divide by zero, null `obj` access; `--check-overflow` adds integer overflow checks.
FAC has an opt-in bounded ownership/borrow analysis through `--strict-ownership` / `--secure` (local loans, selected direct-call effects and pointer provenance). It is not a complete borrow checker or general lifetime solver; safety for managed types also relies on the compiler/runtime ownership machinery, reference counting and `weak`.

## `--warn-unsafe`: let the compiler tell you first

`--warn-unsafe` runs the same checks as `--safe` but reports each place as a **warning** on stderr and keeps compiling, so you see
every raw-pointer use / FFI call / thread-sharing problem in one pass (`--safe` stops at the first). The generated code is identical
to a normal build. A summary line shows the count.

```
$ facc prog.fac --warn-unsafe
prog.fac:3: warning: alloc(...) เป็นการทำงานที่ไม่ปลอดภัย: ต้องอยู่ใน unsafe { ... } หรือ unsafe function (โหมด --safe จะไม่ผ่าน)
prog.fac:4: warning: deref [..] ของ ptr ดิบ เป็นการทำงานที่ไม่ปลอดภัย: ...
facc: 2 จุดที่ --safe จะปฏิเสธ (ครอบด้วย unsafe { ... } หรือย้ายไปไว้ใน unsafe function)
```

If both flags are given, `--safe` wins (errors).

## Suggested migration

1. Build with `--warn-unsafe` to list every raw-pointer use outside `unsafe` (then `--safe` to enforce it).
2. Wrap each in the smallest `unsafe { }` block, or move it into an `unsafe function` behind a safe API.
3. Keep `unsafe` blocks small and comment the invariant they rely on.

## V38: stricter standard-library audit and sanitizer workflow

V38 extends `tests/run_safe.sh` to compile every `stdlib/*.fac` module with
`--strict-safe --no-trust-stdlib`. This is a regression guard against accidental
reliance on the trusted-stdlib exemption for indirect calls reachable from
thread closures. Run it with `make test`.

For managed-lifetime and closure cleanup checks, run `make test-sanitize` with
Clang/ASan/UBSan available. This supplements (and does not replace) the regular
runtime tests and `make test-tsan`. FAC still does not provide a static borrow
checker or lifetime checker; do not treat this audit as a proof of memory safety.


## `--strict-ownership`: direct mutable-borrow overlap check (V39)

`--strict-ownership` performs an optional AST pass over loaded FAC modules. When a statically named function or method has two or more `ref` parameters, a call is rejected if two corresponding arguments have the same simple storage root. For example, `update(value, value)` is rejected for `function void update(ref int a, ref int b)`. It also conservatively rejects `update(pair.left, pair.right)` because both arguments are rooted in `pair`; this may reject disjoint fields, by design.

The pass only knows simple lvalues (`name`, `name.field`, `name[index]`) and direct function/method names. It does not prove alias-freedom for pointer expressions, function values, imported/foreign callbacks, dynamic dispatch, or aliases hidden in runtime code. Same-name method candidates are considered ambiguous and only checked when all matching signatures agree that both positions are `ref`. This is a guardrail, not a complete borrow checker, move checker, lifetime checker, or Rust-equivalent guarantee.

Run `make test-ownership` for the focused checks. The feature is opt-in and does not change compilation unless `--strict-ownership` is supplied. Pair it with `--safe` or `--strict-safe` for the independent raw-pointer and thread-isolation rules.


## Explicit move checking (V40)
`--strict-move` enables explicit `move(local)` for managed local variables and rejects detected use-after-move/double-move. This is a conservative, limited flow analysis; see [MOVE_SEMANTICS.md](MOVE_SEMANTICS.md). It does not prove all ownership, aliasing, or lifetime properties.


## Cooperative thread cancellation (V126)

`thread.cancel(handle)` only requests a stop; it never kills a native thread. A `thread.start` callback must periodically call `thread.cancelled()` and return at a safe point. The caller may inspect `thread.isDone(handle)` / `thread.isCancelled(handle)` before consuming the handle with `thread.join(handle)`. A callback that does not poll keeps running and join still waits. Do not race `cancel` or handle queries against `join`, and never use the handle after join. The request flag is per `thread.start` worker; it is not automatically propagated into `thread.parallelFor` workers.
