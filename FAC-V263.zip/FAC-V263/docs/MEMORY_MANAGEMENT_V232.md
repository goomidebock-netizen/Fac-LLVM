# FAC Memory Management Direction — V232

V232 adds a bounded **Verified-Null fact for standalone pointer locals** and uses it during closure-capture checking. It does not add general closure lifetime inference or general heap/container escape analysis.

## 1. Verified Null versus Unknown for pointer locals

The flow-sensitive `pointerOrigins` map now uses map membership to distinguish three states:

- **Known origins:** the entry exists and contains one or more possible pointer origins.
- **Verified Null:** the entry exists and its origin vector is empty. The current pointer value is proven null.
- **Unknown:** the entry is absent. The checker cannot prove the pointer's current value/provenance.

A pointer local initialized directly with `null`, assigned `null`, or assigned from another pointer value that has an exact Verified-Null fact receives an empty entry. A pointer write whose provenance cannot be tracked removes the current fact instead of preserving an old Verified-Null fact. Exact verified-null pointer fields inside local value structs can also be used as a source for this fact.

## 2. Closure capture behavior

A closure may capture a pointer local only when its current flow-sensitive fact is Verified Null. A known non-null origin remains rejected because the current closure analysis does not prove that the closure cannot escape beyond the referent's lifetime. A missing fact remains Unknown and is rejected.

The current flow-sensitive fact takes precedence over the declaration-wide historical may-origin summary. This prevents an earlier local address from contaminating the analysis after the pointer has been overwritten with `null`. It does not make arbitrary historical or untracked sources safe: an unknown write removes the exact fact, and a branch join retains Verified Null only when every possible predecessor has a verified fact. May-origins are unioned across known predecessors; an unknown predecessor keeps the result Unknown.

The existing rules for captured value structs remain: pointer-free aggregates and aggregates with exact verified-null pointer-field facts may be captured; incomplete/unknown pointer-field provenance and any known frame-restricted pointer origin remain rejected.

## 3. Conservative boundaries

V232 does **not** allow closures to capture non-null local pointers, named-lifetime pointers, or arbitrary pointer-bearing aggregates with live pointer origins. It does not prove that a closure is non-escaping, introduce closure lifetime syntax, resolve arbitrary indirect calls, or add general escape analysis for heap objects, containers, globals or returned closures. Unknown pointer writes, incomplete branch facts and unsupported alias paths remain fail-closed.

No FAC source syntax, Runtime implementation, ARC, Cycle Collector, public API, C ABI or Runtime ABI changed. `--memory-safe` acceptance is unchanged. These are bounded strict-ownership improvements, not a complete or Rust-equivalent borrow/lifetime proof.

## 4. Regression coverage

`tests/lifetimes/run.sh` adds five V232 checks:

- capture of a pointer initialized to `null` is accepted;
- capture after a frame-derived pointer is overwritten with `null` is accepted;
- a branch join where every path leaves the pointer null is accepted;
- copying a verified-null pointer local or exact verified-null aggregate field preserves the fact;
- a possibly-unknown pointer write after null invalidates the fact and capture is rejected;
- a branch join between null and an unknown pointer is rejected.

The five positive fixtures were also compiled and executed, exercising the generated closure runtime path.
