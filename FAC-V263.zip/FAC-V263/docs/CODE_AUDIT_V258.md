# FAC V258 — focused source-code audit

## Finding

**Severity: Medium — strict-ownership analysis precision / lexical scope**

The V257 `auto`-return pointer-payload check carries a set of names whose
current pattern bindings may contain raw pointers while it recursively checks
nested result-producing `match` expressions. When a nested match introduced a
binding with the same spelling as an outer binding, the implementation copied
the outer set and only inserted inner pointer-capable names. It did not remove
an inherited fact when the inner payload was known to be scalar.

A reproducer with an outer `MaybePointer.Value(p)` branch and a nested
`MaybeInt.Value(p)` branch returning the inner `p` was rejected with
`cannot return pointer from match payload binding`, even though lexical
shadowing means the returned value is the inner scalar. This was an
unnecessary rejection of valid code.

## V258 change

In `findUntrackedPointerMatchPayloadResult`, each named binding introduced by
a match branch now shadows an inherited fact with the same name before the
inner payload's metadata is classified. The checker then adds the name back
only if the inner payload is pointer-capable, generic, unknown or ambiguous.
Wildcard `_` remains ignored.

Two regression cases cover both directions:

1. A scalar inner payload shadows an outer pointer binding and is accepted.
2. A pointer inner payload shadows an outer scalar binding and is rejected
   because its payload provenance remains untracked.

The fix changes neither the fail-closed policy for raw pointer payloads nor
source syntax, Runtime, ARC/GC, public API, ABI or `--memory-safe` acceptance.

## Validation

- Build: `make CXX=clang++ COMPILER_CXXFLAGS='-std=c++17 -O0 -g0' -j2` passed.
- `facc --version` reports FAC V258 and Core/Lib/API/Lang/Runtime/Stdlib V258.
- `tools/check_versions.py` passed.
- Lifetime: 130 PASS.
- Ownership: 261 checks; Secure Profile: 6/6; Memory-Safe: 39/39.
- Move: 20/20; Partial Move: 28/28; Compile-time: 57/57.
- Lexer: 18/18; Parser: 68 + AST 1/1; Codegen checks passed; Generic: 3/3.
- Semantic suite: exit code 0 (ancestry model: 17 checks passed).
- Runtime regression suite: exit code 0.
- Tools: 91 tests passed.
- API check passed; 663 built-ins and 1,014 source declarations audited;
  5 findings all in baseline; 950 public source functions satisfy contract
  annotations; V128 compatibility: 0 breaking, 132 warnings.
- Formatter check passed. Standards check passed for 5 OS and 6 architecture
  families.
- Legacy output matrix: 132/132 at `-O0` and 132/132 at `-O2`.
- Negative tests: 134/134; limits tests: 21/21.
- Safe-profile integration: 433 passed, 4 failed. The same four failures were
  reproduced with the unmodified V257 compiler binary, so they are existing
  baseline failures rather than V258 regressions:
  `worker_join_struct_move.fac` and `worker_join_struct_helpers.fac` each fail
  both their strict-ownership and plain-compile/IR-equivalence checks.

## Remaining qualification limits

The four Safe-profile baseline failures above remain unresolved. Full
CMake/CTest, ASan/UBSan/TSan, Windows/macOS cross-platform qualification and
production qualification are not claimed.
