# FAC Memory Management — V263

## Body-verified noescape forwarding for pointer fields in value structs

V263 adds a bounded call-boundary summary for non-`ref` value-struct
parameters whose pointer-bearing fields are used only as exact arguments to
verified `noescape` pointer parameters.

The compiler recursively enumerates pointer fields through known nested value
struct layouts. For each pointer leaf, the checked function body must pass that
exact field projection directly to a uniquely resolved, non-generic helper
parameter whose type exactly matches the field pointer type and whose
`noescape` contract is present. The helper's own body must independently
satisfy the existing body-verified noescape contract. A value-struct parameter
is not summarized if it is `ref`, has an unknown/cyclic layout, has no pointer
leaves, contains `ptr thread`, or contains pointer-bearing array/container or
opaque layouts whose element paths are not modeled.

The summary is fail-closed. Passing the whole aggregate, aliasing or returning
it, storing/capturing it, directly reading a pointer field outside the verified
forwarding call, using an unsupported projection, or forwarding to a normal
pointer parameter without `noescape` does not qualify. Overloaded, generic,
ambiguous, unresolved or arity-mismatched helpers do not qualify. Scalar
sibling fields can still be read; pointer-bearing nested aggregate prefixes
cannot be used as aliases. The new rule does not replace or weaken the separate
`ptr thread` join-only lifecycle proof: thread handles remain governed by the
V261/V262-specific checks.

A positive nested-struct regression forwards a `ptr int` field through a
verified `readonly noescape ptr int` helper and executes with the expected
result `41`. A negative regression confirms that forwarding the same kind of
field to an ordinary retaining-capable `ptr int` helper is rejected. No source
syntax, Runtime semantics, public API, C ABI, Runtime ABI, or
`--memory-safe` accepted subset was intentionally changed.

This is a narrow body-verified noescape forwarding summary, not general pointer
provenance, heap escape analysis, arbitrary aggregate alias analysis, pointer
container analysis, a complete interprocedural lifetime system, or a complete
borrow checker. It does not prove data-race freedom or general resource
lifecycle correctness.

## Validation

- Clang 17 / C++17 Release compiler and Runtime build completed; version checks
  confirm Compiler/Core/Lib/API/Lang/Runtime/Stdlib all report V263.
- Ownership suite: ownership 12/12; const-method ownership 8/8; local borrow
  167/167; noescape 20/20; field-sensitive borrow 25/25; effect contract
  19/19; function-effect 13/13.
- Safe Profile: 438/438.
- Move 20/20; Partial Move 28/28; Compile-time 57/57; Memory-Safe 39/39;
  Generic 3/3; Lexer 18/18; Parser 68 checks + AST 1/1; Codegen passed.
- Runtime suite completed with exit code 0; all tests in the full runtime runner
  passed in this Linux environment, including the trailing UTF-8, compiler
  driver and vector-font lifecycle cases.
- Tools suite: 91/91 passed. Negative tests: 134/134. Limits: 21/21.
- Semantic components were compiled/run individually: ancestry fast path
  17/17, HIR/model and expression tests, generic inference/free-function tests,
  scope/overload and declaration/body code-generation tests passed; generated
  LLVM IR was accepted by Clang. The combined Semantic runner did not complete
  as one uninterrupted run because it timed out during its final generated
  function-body compile. Therefore a full combined Semantic-suite pass is not
  claimed.
- Standards check passed (5 OS families, 6 architecture families); Formatter
  check passed; API manifest/docs are current (114 generated docs); API
  contract audit found 0 missing annotations across 950 public functions;
  API audit found 5 baseline findings and 0 new findings; compatibility against
  V128 reports 0 breaking changes and 132 existing warnings.
- `check_versions.py`, `facc --version`, ZIP integrity check passed.
- Full CMake/CTest, ASan/UBSan/TSan, actual Windows/macOS build and runtime
  qualification, and production qualification are not claimed.
