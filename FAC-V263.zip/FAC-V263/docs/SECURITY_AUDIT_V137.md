# FAC V137 Security Audit — managed-object liveness checks

## Scope

This release reviews the managed-object reference entry points in `runtime/fac_rt.cpp`: strong retain/release and weak-handle creation/locking. The target failure mode is dereferencing an object header through a pointer that is no longer a live registered object.

## Finding and remediation

Previously, the strong-reference operations could inspect the candidate object header before confirming that the address still belonged to a live managed object. V137 consults the synchronized registry first. The registry records `LIVE`, `DESTROYING` and `CYCLE_DESTROYING` states in the existing map entry. This lets ordinary callers reject a stale/invalid object pointer before header access, while allowing the cycle collector's internal release of an object already in its destruction batch to remain a no-op. A separate live-object counter is updated under the registry mutex. The existing registry node changes state and is erased at completion, avoiding a second per-object state-map allocation on the final-release path.

No public C declarations, function signatures or object header layout changed. This is a Runtime implementation hardening change, not a new ownership model or a proof that arbitrary pointer values are safe across the C ABI.

## Regression coverage

`tests/runtime/object_registry_safety.cpp` checks that a weak handle becomes expired after object destruction, weak-lock returns null for that expired handle, stale strong retain/release calls are rejected with FAC error code 7, and invalid native pointer values are rejected before object-header dereference. `tests/runtime/refcount_concurrency.cpp` exercises concurrent strong-reference releases, weak-lock races against object destruction, managed strings and closure reference counts. Existing `tests/runtime/finalizer_error_cleanup.cpp` continues to check cleanup after failing FAC/C++ finalizers and cycle-collection callbacks.

## Validation performed

- GCC 14.2 CMake Debug build and CTest: **13/13 passed**.
- Runtime shell suite: passed, including the new registry test and existing finalizer/cycle regression.
- Memory-safe profile: **25/25 passed**.
- Ownership/borrow/effect tests and move/partial-move tests: passed in the local suite.
- GCC `-O0 -g0 -fsanitize=address,undefined -fno-omit-frame-pointer` with `ASAN_OPTIONS=detect_leaks=1`: the object-registry safety, finalizer-error cleanup and refcount-concurrency regressions passed without ASan, UBSan or LeakSanitizer reports.
- A Clang `-O1` sanitizer build exceeded the local command time limit. The full Runtime shell suite was not run under sanitizers, and no ThreadSanitizer result is claimed.
- API declarations and object header layout are unchanged; version/API manifest checks are recorded with the release build.

## Performance observation

The one-object microbenchmark uses 9 samples of 5,000,000 `retain` + `release` pairs per sample. With Runtime built using GCC C++17 `-O2 -DNDEBUG -g0` and the benchmark executable built using `-O3 -DNDEBUG`, median time was 25.90 ns/pair on V136 and 27.13 ns/pair on V137 (about 4.75% slower). This is a narrow measurement of the synchronized registry validation path, not a general Runtime benchmark. V137 does not claim a broad speed improvement.

## Remaining risks and limitations

- **Pointer ABA:** a stale raw address can be reused by the allocator for a different live object. The registry can then see a live entry at that address; the current pointer ABI has no generation token to distinguish the old handle from the new object.
- **Weak-handle storage precondition:** checking the target object does not make dereferencing an arbitrary invalid weak-handle storage pointer safe. The weak-handle allocation itself must remain valid under the existing ownership contract.
- **Raw pointers and FFI:** unsafe/native code can still violate object ownership outside these guarded entry points.
- **Error unwinding:** Runtime paths still use `setjmp`/`longjmp`; this release does not guarantee C++ destructor execution across every non-local FAC error.
- **Language memory safety:** `--memory-safe` is still a conservative language subset. FAC does not yet have a complete Rust-style lifetime/borrow proof, `Send`/`Sync`-style type guarantees or whole-program data-race proof.

This audit records focused regression evidence, not formal verification, exhaustive fuzzing, full sanitizer coverage or a claim of Rust-equivalent memory safety.
