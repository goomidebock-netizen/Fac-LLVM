# FAC V133 — Security & Reliability Audit

## Scope and assurance level

This is a source-level engineering audit of the V132 codebase followed by targeted fixes and regression tests. It covers selected compiler/runtime interfaces and the `file`, `sys`, `net`, `json`, `graphic`, `audio`, `gpu`, `crypto`, and `ml/tensor` libraries. It is **not** a formal verification, third-party penetration test, exhaustive fuzz campaign, CVE assessment, or proof that FAC is secure. Only findings listed as fixed below have been changed in V133; other items are residual risks that require explicit policy or further work.

## Confirmed issues fixed in V133

- **PNG fuzz runner toolchain mismatch:** the fallback path consumes emitted LLVM IR, but the runner defaulted to GCC, which does not accept `-x ir`. It now defaults to Clang and exposes `FUZZ_CXXFLAGS` for constrained build hosts; the 500-case ASan/UBSan mutation run uses this path.

| Area | Finding | Remediation / regression coverage |
|---|---|---|
| Integer/time/random | `gcd`, `lcm`, `pmod`, negative timestamp conversion and Gaussian distribution parameters had signed-edge/precondition hazards. | Checked unsigned magnitude/intermediate arithmetic, validated time range and finite Gaussian parameters; regression cases cover `INT64_MIN`, zero/negative deviation and extreme timestamps. |
| JSON | Number/escape grammar accepted malformed forms; builder nodes could be adopted by more than one parent, creating double-delete risk. | Strict grammar/Unicode escape validation; per-node parent ownership; rejects reparenting and cycles; tests cover malformed numbers, surrogates, duplicate ownership and cycles. |
| File I/O | `readAll`/`readText`/`readLines` could grow memory without a bound; a single `readLine` could be arbitrarily long; text-file wrapper could skip `fclose` on FAC longjmp. | 64 MiB whole-file cap, 16 MiB line cap, 1,000,000-line cap; owned file wrappers close before raising FAC errors. |
| Subprocess capture | `sys.output` retained all child output in memory without a cap. | 64 MiB capture cap; excess bytes are drained/discarded until child exit; null commands rejected. This does not add a process timeout. |
| TCP | Null/invalid host arguments and null/closed socket handles were not consistently rejected; socket allocation failure could leak the descriptor; `recvAll` had a 1 GiB accumulation ceiling; HTTP configured only receive timeout and ignored socket-option failure. | Host validation, null/closed-handle checks, nothrow handle creation with descriptor close on failure; `recvAll` now caps at 64 MiB; HTTP configures and checks both send and receive timeouts. |
| Graphics/images | Canvas allowed 64M pixels while holding both a 32-bit pixel buffer and float64 depth buffer; raster dimensions could consume hundreds of MiB or more. | Unified cap of 16M pixels for create/load/font raster; BMP/PPM/PNG use the same bound; oversized dimensions rejected. |
| Graphics primitives | Previously identified null-handle and signed-overflow hazards in raster operations. | Null guards, widened coordinate math, bounded extreme geometry and HSV finite/range validation; ASan/UBSan focused tests cover representative boundary inputs. |
| GPU/Audio | Buffer/temporary compute/audio allocations could throw C++ allocation exceptions across the C ABI or partially allocate handles; audio fallback stop could wait indefinitely for a child that ignored SIGTERM. | GPU buffer/compute and audio create/mix allocation failures are handled; GPU write rejects null byte strings; POSIX audio stop escalates from SIGTERM to SIGKILL after a bounded grace period and retries `waitpid` on EINTR without falling into an unbounded wait. |
| ML/Tensor | Some public Tensor creation paths used raw `new` without translating allocation/length failures; CSV/training workloads needed limits. | Tensor constructors use a checked allocation helper; CSV input capped at 64 MiB and training/K-means work has a budget; tests cover excessive dimensions/epochs. |
| Crypto | PBKDF2 work and file hashing could be used for excessive work/input size. | PBKDF2 iteration/key-size and SHA-256 file-size bounds; tests cover excessive iterations and oversized sparse input. |
| File/image/audio output | Buffered writes could report failure only at flush/close. | `fwrite`, `fflush` and `fclose` results checked; `/dev/full` regression verifies delayed failure on POSIX. |

## Security-sensitive behavior that remains

1. **Shell execution:** `sys.run` and `sys.output` intentionally pass command strings to the OS shell. Untrusted interpolation can cause command injection. The output cap limits retained memory only; it does not terminate a runaway process and the call may block indefinitely. Use fixed commands/strict allow-lists or avoid shell APIs.
2. **No process sandbox:** `--safe` and `--strict-safe` are compile-time checks for selected raw-pointer, FFI and thread-closure rules. They do not restrict filesystem, process, network or resource access and do not prove trusted Runtime code safe. Use OS-level isolation and least privilege for untrusted programs.
3. **TCP exposure / timeouts:** `net.listen` binds `0.0.0.0`, not loopback-only. `connect()` and DNS resolution are blocking and are not covered by `setTimeout`; the API has no TLS/HTTPS. Firewall listener ports and never send secrets over the cleartext HTTP helpers.
4. **Regex ReDoS:** the ECMAScript regex engine uses backtracking. Existing pattern/subject size limits do not eliminate exponential-time patterns such as nested unbounded quantifiers. Do not execute attacker-controlled patterns.
5. **C ABI allocation coverage:** Tensor constructor allocation paths and selected GPU/Audio paths were hardened, but not every allocation in every ML/DataFrame/model/FFI/Font/SDL path has been normalized into a FAC error boundary. Allocation failure in an unaudited legacy path may still escape as a C++ exception or skip non-local cleanup. This requires a separate systematic C ABI exception/cleanup conversion.
6. **Non-local FAC errors:** FAC's longjmp-based error transfer can skip C++ destructors for temporaries not registered with the runtime cleanup stack. The Runtime remains a trusted computing base; do not assume C++ RAII applies across FAC `throw` boundaries.
7. **Dynamic libraries / FFI:** SDL, Pango/Cairo and external FFI integrations load platform libraries and inherit the host loader/search-path trust model. Only load trusted libraries and restrict DLL/shared-library search paths in deployment.
8. **Image decoding:** PNG/BMP/PPM inputs are bounded and validated, but this round does not claim exhaustive PNG format conformance or a fresh high-volume coverage-guided fuzz run. Maintain fuzzing under ASan/UBSan in CI.
9. **Cross-platform status:** Windows/macOS compile/runtime behavior was not exercised by a hosted runner in this audit. POSIX-specific delayed-write tests use `/dev/full` and are skipped where unavailable.

## Validation performed

The targeted runtime security regression executable covers integer/time/random boundaries, malformed JSON and ownership, ML workload limits, PBKDF2 limits, malformed/truncated image inputs, graphics null/extreme coordinates, file read caps, null command/host handles, and POSIX delayed output failures. V133 also ran the complete `tests/runtime/run.sh` suite, a 500-case PNG mutation corpus using ASan/UBSan, a focused Security Regression binary using ASan/UBSan, API gates, and GCC CMake/CTest (8/8). A green focused test means only that its tested cases passed; it does not establish that every runtime library or deployment configuration is secure.
