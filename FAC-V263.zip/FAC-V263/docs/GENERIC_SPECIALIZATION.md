# Generic specialization in FAC (V220)

FAC materializes closed generic types when they are encountered in declarations and signatures. For example, each concrete use of `Box<int>` resolves to a single specialized type symbol. The compiler keeps a per-compilation cache keyed by the generic template name and normalized concrete type arguments. Recursive generic fields publish the specialization key before walking substituted fields, allowing self-recursive closed types to resolve without creating duplicate copies.

V220 accepts bounded `const int` arguments on generic `struct`/`class` declarations, free functions and methods. Ordered generic arguments can mix types and compile-time integer expressions:

```fac
public struct FixedBuffer<T, const int N> {
    public array var T values[N]
}

public function<T, const int N> T keepSized(T value) { return value }

struct FixedBuffer<int, (2 * 8)> first
struct FixedBuffer<int, (4 * 8)> second
var int result = keepSized<int, (PAGE_SIZE / 2)>(7)
```

The specialization key encodes a const argument as a canonical signed-64-bit integer value, so different evaluated values are distinct specializations while repeated uses of the same value share the cache entry. Arguments must be integer constant expressions accepted by the bounded constant evaluator; arbitrary runtime expressions and user-defined compile-time function execution are not supported. The value is substituted throughout generic type/function/method bodies and can participate in dependent types and fixed-array dimensions. Resulting array dimensions are checked by the existing constant-evaluation and layout rules. Generic methods and generic struct/class instantiations with const generic parameters do not infer omitted arguments; trailing generic defaults may supply omitted parameters. Generic free functions may omit the entire generic argument list when each const parameter is exposed directly as a fixed-array extent (`[N]`) and a fixed-size array argument supplies a known extent; ordinary type parameters may be inferred from the same argument. Callers may otherwise use positional arguments in declaration order, named arguments (`N = value`), or positional arguments followed by named arguments; omitted parameters are filled from defaults when declared. Mixing positional arguments after the first named argument is rejected. Names are resolved against the declaration's parameter list; unknown, duplicate and missing required arguments are diagnosed. The resulting argument vector is normalized to declaration order before specialization-key construction, so equivalent positional/named spellings share one specialization. Inferred const values are encoded with the same canonical signed-64-bit specialization value as explicit const arguments. The inference boundary is documented in [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md).
Const integer parameters may carry value predicates such as `const int N: positive & power_of_two`. Supported predicates are `positive`, `nonnegative`, `nonzero`, `negative`, `even`, `odd` and `power_of_two`; predicates joined with `&` are an intersection (logical AND). They are checked against the evaluated signed-64-bit value before specialization, including before dependent field-array layout is materialized for generic struct/class types. See [`CONST_GENERIC_CONSTRAINTS_V220.md`](CONST_GENERIC_CONSTRAINTS_V220.md) for exact semantics and diagnostics. These value predicates do not add type/interface bounds to const parameters.

Generic methods are specialized by source method identity, explicit/inferred type and const arguments and the receiver specialization. Repeated calls with the same specialization reuse the cached `FuncInfo` and emit the method body once.

## Resource limits

- Generic type argument depth: 24 levels.
- Nested materialization depth: 64 levels.
- Distinct concrete generic type specializations: 5,000 per compilation.

The 5,000 ceiling applies to new specializations only. A cache hit does not consume budget. This distinction matters when a common type appears in many fields, function parameters, return types or container elements: 5,001 references to `Box<int>` still represent one specialization, not 5,001. The limit still rejects a program requesting more than 5,000 distinct closed generic types.

The template lookup, concrete type-specialization cache and method-specialization cache are lookup-only hash maps. They are not iterated to determine emitted function/type order. Emission remains driven by the original source and instantiation traversal, preserving deterministic names and source semantics.

## Regression and benchmark

Run:

```sh
make test-generic
make bench-generic
```

`tests/generic/run.sh` verifies repeated use, the distinct-specialization ceiling and generic method deduplication. `benchmarks/compiler_generic.py` generates 100 generic struct templates with 40 references each and reports median compile-to-IR time and IR size. The result is a synthetic compile-time indicator, not a general performance promise.
