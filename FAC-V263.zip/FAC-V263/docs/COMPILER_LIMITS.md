# Compiler resource and complexity limits

FAC places explicit limits on untrusted or generated source so pathological input fails with a diagnostic rather than exhausting process resources or overflowing recursive compiler passes.

| Resource / operation | Current limit | Enforced by |
|---|---:|---|
| One source file | 64 MiB | Compiler source loader (`src/main.cpp`) |
| Total source text across imported modules | 128 MiB | Loader (`src/main.cpp`) |
| Emitted tokens from one lexed source unit | 1,000,000 | Lexer (`src/lexer.cpp`, `src/lexer.hpp`) |
| Emitted tokens across one compilation | 2,000,000 | Lexer + Loader (`src/lexer.cpp`, `src/lexer.hpp`, `src/main.cpp`) |
| Source modules including entry file | 4,096 | Loader (`src/main.cpp`) |
| Import nesting | 128 levels | Loader (`src/main.cpp`) |
| Parser nesting budget | 1,500 recursion units | Parser `NestGuard` (`src/parser.hpp`) |
| Operators/postfix steps in one chain | 1,000 | Parser (`src/parser.hpp`) |
| Struct/array object layout | 1 TiB | Layout arithmetic checks (`src/codegen.hpp`) |
| One stack allocation | 1 GiB | Stack allocation validation (`src/codegen.hpp`) |
| Generic type argument nesting | 24 levels | Generic instantiation (`src/gen_stmt.inc`) |
| Nested generic instantiation | 64 levels | Generic instantiation (`src/gen_stmt.inc`) |
| Distinct materialized generic type specializations per compilation | 5,000 | Generic instantiation (`src/gen_stmt.inc`) |
| Static thread-closure call-graph depth | 64 levels | Safe worker analysis (`src/gen_expr.inc`) |

The per-source token budget supplements the byte-size limit: a small source can still contain a very large number of short tokens. V94 also applies an aggregate token budget across all imported source units and nested interpolation parsers, so splitting a token flood across many modules does not bypass the limit. Synthetic end-of-file markers are not counted. Source bytes, module count and import recursion are independently bounded across the import graph.

The loader releases each parsed source buffer before following imports; the AST remains retained for compilation. These are defensive compiler limits, not promises that a program below every limit is inexpensive to compile or safe to execute. Runtime allocation, recursion at execution time, stack usage in generated programs, and concurrency behavior still require their own runtime checks and testing.

The generic type specialization ceiling counts distinct concrete specializations actually materialized. References to an already-cached specialization do not consume the budget. Generic method specializations are separately deduplicated by their method/type-argument cache. The depth and nesting limits still apply while resolving nested generic arguments and recursive materialization.
