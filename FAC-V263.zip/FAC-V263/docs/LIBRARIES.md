## V206 — managed file owner (`file_resource.fac`)

`import file_resource.fac` provides `FileHandle(path, mode = "r")`, a managed class wrapper around the existing `file.open` handle. Use `readLine()`, `readAll()` and `write(text)` while open. `close()` is explicit and idempotent; the class destructor also closes the native stream when its final managed object reference is released. Copying an `obj FileHandle` shares the owner, so an inner alias does not close the file while another strong reference remains. Methods reject operations after close. The wrapper is synchronous and its managed object field is not thread-safe; do not race wrapper methods with mutation/close of the same object. The underlying low-level `ptr file` token serializes concurrent native I/O and close, and rejects I/O through a closed/stale token. It has no detach method, and low-level handles remain caller-managed.

`file.liveHandles()` reports the number of active streams opened through FAC's built-in `file.open` and is intended for diagnostics/tests, not as a process-wide OS descriptor count. The managed module is additive. V218 retains the low-level file function signatures and pointer-sized opaque ABI, but the pointer value is now a stable Runtime token rather than a native `FILE*`. Closed token records remain as process-lifetime tombstones to prevent stale-alias ABA reuse. Regression: `tests/cases/t85_file_resource.fac`.

## V158 — BinaryReader fail-closed validation

`deserialize.BinaryReader` records malformed input as a terminal failed state, reports it through `isFailed()`, and refuses further decode operations. API misuse remains a recoverable InvalidArgument. Record field counts are checked against the minimum serialized bytes remaining before the reader enters the record. A deterministic FACB malformed-input mutation corpus exercises valid-CRC but invalid record bodies through the FAC runtime. No FACB wire-format, field-tag, or Runtime ABI change.

# FAC Library Catalog

## V157 — field rename, checked numeric migration and user-defined schema hooks

`tools/facserde.py` now supports historical field names (`renameFrom`, `renameSince`), explicit numeric wire-type changes (`convertFrom`, `convertSince`) for signed Int32/Int64 only, and user-defined migration hooks declared outside a Struct with `# @serde-migrate struct=TYPE from=N function=NAME`. Generated code chooses old/current field names and type tags according to the schema version, checks Int64→Int32 narrowing and legacy Int32 downgrade ranges, then invokes migration hooks in ascending order. No changes were made to FACB headers, stable record field tags or Runtime ABI. Renamed/converted fields require an explicit default initializer. This remains build-time source generation and does not add runtime reflection.

## V156 — schema evolution for generated Struct serializers

`tools/facserde.py` supports append-only optional fields using `# @serde since=N default=VALUE` comments directly above a field. Generated encoders accept an optional schema-version argument and emit only fields present in that version. Generated decoders fill defaults for fields introduced after the payload version, read fields already present, and skip validated unknown trailing fields. The reader rejects missing fields required by the declared version. Existing fields must preserve order and type. Scalar defaults (byte, boolean, integer, floating-point and string) are supported; optional collections/nested Structs and automatic rename/type migrations are not. See the V156 section in README.md and `examples/api/24_schema_evolution_source.facsrc`.


## V155 — generated Struct serializers and nested records

`tools/facserde.py` is a build-time source generator, not a runtime library. It scans FAC struct declarations and appends `fac_encode_Type(struct Type value)` / `fac_decode_Type(list dyn int encoded)` functions to a generated source file. The generated file includes the original declarations; compile that output instead of separately importing/compiling the model source so Struct types are not defined twice.

Usage:

```sh
python3 tools/facserde.py models.fac build/models_serde.fac --schema-prefix game.save --version 1
python3 tools/facserde.py models.fac /tmp/models_serde.fac --check
```

Supported field declarations: `var byte`, `var boolean`, `var int`, `var long`, `var float`, `var double`, `dyn string` / `string`, `list var int`, `list dyn string`, `hashmap dyn string, string`, and `struct NestedType`. Unsupported declarations fail closed. It also rejects private/protected fields, explicit constructors and recursive Struct dependency graphs. Generated decoders construct the Struct using its field-order constructor, then validate the enclosing stream and nested substreams.

Nested Struct fields are carried by the existing `Bytes` record tag (tag 8). The byte payload contains an independent FACB V2 stream with schema id `<prefix>.<NestedType>`, the selected schema version and its own CRC32. This allows nested Structs to be independently validated/skipped by older readers without changing V1/V2 wire headers or existing record tags. Each generated struct requires an exact schema version; automatic migration/defaulting is still the application's responsibility. Arrays, enums, pointer/object graphs, arbitrary nested collections, mutual/self-referential Structs and automatic native reflection are not supported.

Generated helper names are `fac_encode_Type` and `fac_decode_Type`. The generator accepts `--schema-prefix` (default `app.models`) and `--version` (default 1, range 1..65535). It is source generation, not compile-time metaprogramming and not runtime reflection.

Regression: `tests/api/a32_v155_struct_serde.fac`; generator tests: `python3 tests/tools/test_tools.py FacSerdeGeneratorTests`; generated example: `examples/api/23_struct_serde_generated.fac`.

## V154 — named records and typed binary collections

`BinaryWriter.beginRecord(typeName, fieldCount)` begins a flat named record. Write exactly the declared number of fields in schema order using `writeFieldByte`, `writeFieldBoolean`, `writeFieldI32`, `writeFieldI64`, `writeFieldF32`, `writeFieldF64`, `writeFieldString`, `writeFieldBytes`, `writeFieldI32List`, `writeFieldStringList` or `writeFieldStringMap`, then call `endRecord()`. The matching reader calls `beginRecord(expectedType[, maxFields])`, reads fields in that same order with `readField*`, then calls `endRecord()`. Field names are limited to 128 UTF-8 bytes; a record has at most 65,535 fields. Nested records are provided by V155 source-generated nested Struct byte fields; see the V155 section above.

The sequence helpers `writeI32List` / `readI32List` and `writeStringList` / `readStringList` encode U32 element counts followed by values. The map helpers `writeStringMap` / `readStringMap` serialize string-to-string maps; keys are sorted lexicographically before writing so equivalent maps have deterministic bytes independent of insertion order. Decoding rejects duplicate keys. List counts are capped at 1,048,576 and string-map entries at 262,144; the global stream cap remains 64 MiB and string/byte fields remain capped at 16 MiB. Reader APIs accept a lower caller-defined `maxCount` to reduce resource use.

`BinaryReader.skipField()` returns the next field's name and skips its validated payload for known type tags. It is useful when a newer schema appends optional fields that an older application does not need: `beginRecord()` returns the total declared field count, so the old reader can read its known prefix and call `skipField()` for the remaining fields. Existing fields must retain their order; inserting/reordering fields breaks the positional schema contract. New unknown type tags are rejected, not silently skipped. This is not automatic migration: the application must still select an accepted schema version and decide whether skipping a field is semantically safe. Field order, unique field names and type tags are checked; an unexpected name/type is rejected.

Stable V154 field tags are: `1=Byte`, `2=Boolean`, `3=I32`, `4=I64`, `5=F32`, `6=F64`, `7=String`, `8=Bytes`, `9=I32List`, `10=StringList`, `11=StringMap`. While a record is open, use only `writeField*` / `readField*` or `skipField`; raw primitive read/write calls are rejected so they cannot silently desynchronize the record.

Records are explicit and portable: they do not serialize native Struct memory, padding, pointers or compiler-specific layout. V220 adds compile-time structural field metadata queries, but they do not provide a runtime serializer, serialize native memory, or create an automatic `serialize(struct)` method. V155 adds build-time generated nested Struct helpers by placing each nested value in an independent FACB V2 stream inside an existing Bytes field (tag 8); it does not add nested record markers or runtime reflection. Arbitrary typed maps/lists and object graphs remain unsupported. Existing V1/V2 headers, primitive encodings and V154 field tags are unchanged.

## V153 — binary serialization v2, floating-point and integrity

`serialize.BinaryWriter.beginV2(schemaId, schemaVersion = 1)` starts the opt-in FACB format v2. The header contains magic, format version 2, flags (CRC32 required), a U16 schema version, and the length-prefixed schema identifier. `toBytes()` appends CRC-32/ISO-HDLC over all preceding bytes. V1 `begin()` and its byte layout remain unchanged.

V2 adds `writeF32` / `writeF64` and matching reader methods using IEEE-754 little-endian encodings. Finite values, infinities and signed zero round-trip; NaN is canonicalized to a quiet NaN. The implementation does not copy host-native struct memory. `readHeaderV2(expectedSchema, minSchemaVersion = 1, maxSchemaVersion = 65535)` checks the CRC before exposing any fields, validates the schema/version range and returns the stored schema version. Applications must branch on that version to supply defaults or perform migrations; there is no automatic object/struct migration.

CRC32 is an accidental-corruption check, not a security boundary: it does not prevent deliberate modification. Use a cryptographic MAC or signature for untrusted data. V2 stream size remains capped at 64 MiB including the four-byte CRC trailer; strings/byte fields remain limited to 16 MiB. V153 readers retain V1 support. V152 readers cannot read V2.

# V150 — optional TLS and integrated WebSocket Upgrade

## `tls` + `tls_stream.fac` — optional native TLS transport

The native `tls` module is an optional Runtime backend loaded dynamically from OpenSSL 1.1.1+ / 3.x on POSIX systems. It adds `tls.available`, `wrapClient`, `wrapServer`, `sendBytes`, `recvExactBytes`, `version`, `cipher` and `close`. There is no link-time OpenSSL dependency: the backend is discovered when first queried/used and `tls.available()` reports whether all required symbols are present. Windows is explicitly unavailable in this release; a Schannel backend is not implemented.

Client wrapping requires system CA trust and verifies both the peer chain and the supplied ASCII DNS hostname; SNI is sent. IP literals and IDN hostnames are not supported by the current hostname-validation path. Server wrapping loads a PEM certificate chain and matching PEM private key. Both endpoints require TLS 1.2 or newer. Set a socket timeout using `net.setTimeout` before wrapping. A successful wrap transfers ownership of the TCP socket; a failed handshake leaves the raw socket caller-owned. TLS handles own the OpenSSL context/session and close the underlying TCP socket when closed. Streams are blocking, synchronous and not thread-safe; there is no client-certificate authentication, async I/O, ALPN configuration or total-operation deadline.

`tls_stream.fac` wraps the native handle in `TlsStream(socket,serverMode,identity,privateKey="")`. In client mode, `identity` is a DNS hostname and `privateKey` must be empty. In server mode, `identity` is the certificate PEM path and `privateKey` is the private-key PEM path. The wrapper offers `send`, `sendBytes`, `recvExactBytes`, `recvLineStrict`, `version`, `cipher`, `isOpen`, `detach` and `close`. `detach()` transfers the underlying native TLS handle; the wrapper becomes inactive and must not be reused. Its destructor closes an attached handle exactly once.

## `websocket.fac` — TCP/TLS HTTP Upgrade and RFC 6455 connection

`WebSocketHandshake.createClientRequest(hostHeader,path)` generates a fresh 16-byte CSPRNG nonce and retains its canonical Base64 form. `verifyClientResponse` checks the exact HTTP/1.1 101 status line, `Upgrade: websocket`, the `Connection: Upgrade` token and the expected accept value with constant-time comparison. `clientUpgrade(socket,hostHeader,path)` and `serverUpgrade(socket)` perform the full cleartext HTTP/1.1 Upgrade on an existing TCP socket. `clientUpgradeTls(stream,hostHeader,path)` and `serverUpgradeTls(stream)` do the same over an open `TlsStream`. Header parsing is bounded to 64 fields and 8192 bytes per line, requires CRLF, rejects duplicate/invalid ASCII token field names, transfer encoding and nonzero Content-Length; it does not provide general-purpose HTTP parsing, subprotocol selection or Origin policy.

After a successful TLS upgrade, transfer ownership into `WebSocketConnection`:

```fac
obj WebSocketConnection ws = new WebSocketConnection(secure.detach(), true, 16777216, true)
```

The fourth constructor parameter selects the TLS transport; omit it or pass `false` for raw TCP. `WebSocketConnection` owns and closes the passed socket/TLS handle. The transport keeps bounded frame/message processing, client masking, server unmasked frames, fragmentation, text UTF-8 validation, automatic ping/pong handling and close echo. It remains synchronous and not thread-safe; negotiated extensions, permessage-deflate, subprotocol negotiation, asynchronous I/O and a callback-driven server are not included. Apply socket timeouts before TLS wrapping.

Built-in TLS reference: `api/meta.json` and section 38 of `syntax/fac_spec.fac`; source API reference: `docs/api/tls_stream.md` and `docs/api/websocket.md`.
Regression: `tests/api/a27_v150_tls_websocket_upgrade.fac`; runtime TLS: `tests/runtime/tls_loopback.cpp` (`make test-tls`); example: `examples/api/18_tls_websocket.fac`.

---

# FAC V149: byte-oriented networking and WebSocket transport

## Runtime byte APIs

- `net.sendBytes(socket, bytes)` sends a `list dyn int`, requiring each element to be in `[0,255]`. It validates the entire list before sending, returns the byte count and is limited to 16 MiB per call.
- `net.recvExactBytes(socket,count)` reads exactly `count` bytes or throws on timeout/EOF; it returns an owned `list dyn int`. The limit is 16 MiB.
- `string.toBytes(text)` exposes the exact stored UTF-8 bytes. `string.fromBytes(bytes)` creates a string only after strict UTF-8 validation. Both use an explicit `list dyn int` representation; FAC strings remain text, not arbitrary binary buffers.

## `websocket.fac` — synchronous TCP frame and message transport

`WebSocketConnection(transport,clientSide,maxFrameBytes=16MiB)` takes ownership of an already connected TCP socket. Set a timeout using `net.setTimeout` before transferring it. A client connection masks outgoing frames with a cryptographically random key and expects unmasked incoming frames; a server connection does the reverse. `sendFrame` / `receiveFrame` expose one frame at a time. `sendText`, `sendBinary`, `sendPing`, `sendPong` and `sendClose` are convenience methods. `receiveMessage()` handles ping/pong/close control frames and reassembles continuation frames into a complete text or binary message. `messageText`, `messageBytes` and `messageOpcode` expose the last complete message; text payloads are rejected unless they are valid UTF-8.

The application must perform and validate the HTTP/1.1 Upgrade handshake separately using `WebSocketHandshake` and `HttpRequest`/`net.send`; the wrapper does not authenticate peers or own the HTTP upgrade process. It is blocking, synchronous and not thread-safe. It supports no TLS, negotiated extensions, permessage-deflate, async I/O, keepalive scheduler or automatic ping intervals. Maximum frame/message size is 16 MiB even though the frame codec can be configured up to 64 MiB.

Regression: `tests/api/a26_v149_socket_bytes_websocket.fac`; example: `examples/api/17_websocket_transport.fac`.

---

# FAC V148: WebSocket protocol codec and message queue

## `websocket.fac` — RFC 6455 handshake and single-frame codec

`obj WebSocketHandshake handshake = new WebSocketHandshake()` provides `validateUpgrade(method,upgrade,connection,version,key)`, `acceptKey(key)` and `responseHeader(key)`. Validation requires GET, the `websocket` Upgrade token, an `Upgrade` token in the comma-separated Connection header, version `13`, and a canonical Base64 key decoding to exactly 16 bytes. `acceptKey` implements the RFC 6455 GUID/SHA-1/Base64 calculation; `responseHeader` returns the complete HTTP/1.1 101 header block.

`obj WebSocketFrameCodec codec = new WebSocketFrameCodec(maxFrameBytes=16MiB)` encodes a single frame with `encodeFrame(opcode,payload,fin,masked,maskKey)` and decodes exactly one complete wire frame with `decodeFrame(wire,expectMasked)`. The decoder exposes `hasFrame`, `isFinal`, `opcode`, `wasMasked` and a copied `payload`. Short, 16-bit and 64-bit lengths are supported with canonical-length checks. Client frames must be masked and server frames unmasked when the matching strict expectation is passed. `randomMaskKey()` returns four cryptographically random bytes for a client mask. Control frames must be final and at most 125 bytes; close payload length one is rejected. RSV bits must be zero because extensions are not negotiated.

This is a frame-level protocol helper, not a WebSocket transport: it does not own sockets, convert TCP byte strings to integer lists, assemble/validate fragmented message sequences, validate UTF-8 text payloads, negotiate extensions or manage close/ping/pong state. Callers must enforce continuation ordering and control-frame semantics across multiple frames. The Runtime currently does not expose a direct byte-list socket adapter, so `HttpServer` cannot be treated as a ready WebSocket server. Do not expose this preview codec as an internet-facing WebSocket service without additional protocol and security work.

## `message_queue.fac` — bounded lease-based in-memory work queue

`obj MessageQueue queue = new MessageQueue(capacity=1024,maxAttempts=5,maxDeadLetters=4096,maxPayloadBytes=65536)` provides `enqueue(payload,nowMs)`, `claim(nowMs,visibilityTimeoutMs)`, `payload(id)`, `attempts(id)`, `ack(id)`, `nack(id,nowMs,delayMs=0)` and `reapExpired(nowMs)`. All times are caller-supplied non-negative monotonic milliseconds. `claim` returns a positive message ID or `-1`; a claimed message is hidden until acknowledged, nacked, or its lease expires. Expired leases can be claimed again; once the configured attempt limit has already been used, the message moves to the dead-letter list.

The active message count is bounded by `capacity`; each payload is limited by `maxPayloadBytes` (default 64 KiB, maximum 16 MiB), and dead letters have their own `maxDeadLetters` bound. Inspect dead letters with `deadLetterSize`, `deadLetterId`, `deadLetterPayload` and `deadLetterAttempts`; use `redriveDeadLetter(index,nowMs)` to requeue one with a reset attempt count, or `purgeDeadLetters()` to clear them. If the dead-letter list is full, expiry processing raises Resource and leaves the affected message active rather than dropping it. The queue is in-memory only, single-process and not thread-safe; it does not persist across restarts, coordinate multiple processes, provide exactly-once delivery, scheduling guarantees or background lease timers. It is a point-to-point work queue, unlike `pubsub.PubSubBus`, which duplicates each publication to matching subscribers.

Regression: `tests/api/a25_v148_websocket_message_queue.fac`; example: `examples/api/16_protocol_and_queue.fac`.

---

# FAC V146: application framework primitives

# FAC V147: networking and service observability

## `http_server.fac` — synchronous HTTP/1.x server primitives

`HttpServer(port)` owns a listener created with `net.listen`; `port()` returns the bound port (port 0 asks the OS to choose), `accept()` blocks and returns an owned client socket, and `close()` closes only the listener. `HttpRequest.readFrom(socket, timeoutMs=5000)` parses one HTTP/1.0/1.1 origin-form request line, up to 64 headers, and an optional Content-Length body up to 8 MiB. Header names are validated as HTTP tokens and normalized to lowercase; HTTP/1.1 requires a non-empty Host header; duplicate headers, `Transfer-Encoding`, and `Expect` are rejected. `HttpResponse` supports `setStatus`, `setHeader`, `setBody`, `toWire` and `writeTo(socket)`. It calculates Content-Length from `string.byteLength`, reserves Content-Length/Connection/Transfer-Encoding for the serializer, and writes `Connection: close`. The caller must close accepted sockets. This is one-request-per-connection synchronous HTTP; chunked requests, keep-alive, TLS, WebSocket upgrade, callback dispatch, request routing and multipart parsing are not implemented. `net.listen` binds all IPv4 interfaces, so use a firewall or trusted network boundary.

## `rpc.fac` — JSON-RPC 2.0 envelope codec

`JsonRpcCodec` provides `request(idJson,method,paramsJson)`, `notification`, `success`, `failure`, `isRequest`, `isResponse`, `method` and `responseId`. IDs must parse as JSON string/number/null; params must be an object or array. Result payloads may be any valid JSON value. This module validates/envelopes JSON only: it does not dispatch methods, execute callbacks, implement an RPC transport, authentication, batching or authorization.

## `pubsub.fac` — bounded in-process polling bus

`PubSubBus(maxPendingPerSubscriber=1024)` supports exact-topic `subscribe`/`unsubscribe`, `publish`, `hasMessage`, `nextTopic`, `nextPayload`, `consume`, `pending`, `subscriptionCount` and `clearPending`. Each subscription gets its own FIFO message copy. A publish preflights matching subscriber queues before appending, so queue-full rejection does not partially deliver. Consumers poll and explicitly consume; there are no callbacks, wildcard topics, persistence, process boundaries or thread-safety. Capacity is a per-subscriber message count.

## `health.fac` — caller-reported component health

`HealthRegistry` registers named checks and accepts `report(name,state,detail)`, `markHealthy`, `markUnhealthy`, `state`, `detail`, `summary`, `isHealthy` and `size`. States are `healthy`, `degraded`, `unhealthy` and `unknown`; overall precedence is unhealthy, degraded, unknown, healthy. An empty registry is unknown/not healthy. The host application must run probes and report their outcomes; the registry does not execute checks.

## `telemetry.fac` — in-memory metrics and simple Prometheus exposition

`TelemetryRegistry` supports non-negative `increment` counters, finite `setGauge` values, finite `observe` samples, `counter`, `gauge`, sample count/sum/mean/min/max, `prometheusText` and `clear`. It exports counters, gauges, and observation `_count`/`_sum` lines. It is not an OTLP exporter, label system, histogram bucket engine, timer, HTTP endpoint or background collector. Names are restricted to Prometheus-compatible letters/digits/underscore/colon; instances are synchronous and not thread-safe.

## Runtime additions

`net.recvExact(socket,count)` reads exactly count bytes or throws on timeout/early close; count is bounded to 64 MiB. `net.recvLineStrict(socket)` requires CRLF and distinguishes a blank line from EOF before the terminator. `string.byteLength(text)` returns stored byte length, distinct from Unicode code-point/grapheme length. HTTP request parsing uses strict CRLF lines and applies a stricter 8 MiB body limit. Its timeout applies per socket operation, not as a total request deadline.

V147 intentionally defers `tls` and `websocket`: the Runtime currently exposes TCP but does not yet provide a vetted TLS transport or a complete WebSocket masking/fragmentation/control-frame parser. Do not mistake HTTP primitives for a hardened internet-facing server.

Regression: `tests/api/a24_v147_networking_services.fac`; example: `examples/api/15_networking_services.fac`.

---


## `rate_limit.fac` — fixed-window rate limiting

`obj FixedWindowRateLimiter limit = new FixedWindowRateLimiter(maxRequests, windowMs)` provides `allow(nowMs)`, `remaining()`, `used()`, `resetAtMs()`, `limit()`, `windowDuration()`, `configure()` and `reset()`. The clock is a non-negative monotonic Int64 millisecond value supplied by the caller. The first call after initialization/reset begins the window; expiry starts a new window at the current poll time. This is a single-process fixed-window limiter, not a sliding window, token bucket, per-key limiter or distributed quota service. The instance is not thread-safe.

## `circuit_breaker.fac` — dependency failure circuit

`obj CircuitBreaker breaker = new CircuitBreaker(threshold, resetTimeoutMs)` supports `allow(nowMs)`, `recordSuccess()`, `recordFailure(nowMs)`, `state()`, `failures()`, `pending()`, `threshold()`, `resetTimeout()` and `reset()`. A successful `allow` reserves one in-flight call; the caller must finish every admitted call with `recordSuccess` or `recordFailure`. At threshold, the breaker opens; after the timeout and after pre-open in-flight calls finish, one half-open probe is admitted. Success closes; failure reopens. The caller executes the operation and supplies the outcome. This module does not run callbacks, retries, measure latency or coordinate across threads/processes. The clock must be monotonic and the instance is not thread-safe.

## `middleware.fac` — declarative middleware order

`obj MiddlewarePipeline pipeline = new MiddlewarePipeline()` supports `add(name,priority)`, `remove(name)`, `setEnabled(name,bool)`, `isEnabled(name)`, `orderedNames()`, `size()`, `enabledCount()` and `clear()`. Enabled descriptors are returned in ascending priority; equal priorities preserve registration order. Names are metadata only. A host router/framework must resolve and invoke the actual functions; this module does not expose callback execution, request/response contexts or short-circuit semantics.

## `service.fac` — service lifecycle registry

`obj ServiceRegistry services = new ServiceRegistry()` supports `register(name)`, `has(name)`, `start(name)`, `pause(name)`, `fail(name,message)`, `stop(name)`, `state(name)`, `lastFailure(name)`, `isRunning(name)`, `unregister(name)`, `size()` and `revision()`. The registry tracks explicit states (`stopped`, `running`, `paused`, `failed`) but does not create service instances, execute startup/shutdown hooks, restart automatically, supervise processes, or spawn threads. `start` also resumes a paused service. Running/paused/failed services must be stopped before unregistering.

## `di.fac` — typed pre-created dependency registry

`obj InstanceRegistry<T> container = new InstanceRegistry<T>()` stores already-created values using `register(key,value)`, checks with `has(key)`, resolves with `resolve(key) -> Option<T>`, and supports `remove`, `size` and `clear`. Each registry instance has one static T, avoiding unsafe type erasure. Lookup is linear in the number of entries. It can store ordinary values and FAC managed objects under their normal T semantics, but it does not construct factories, scan dependency graphs, provide transient/singleton scopes or define an independent lifetime system. The registry is not thread-safe.

Regression: `tests/api/a23_v146_framework_primitives.fac`; example: `examples/api/14_application_framework.fac`.

---

# FAC V145: application-service primitives

## `cache.fac` — caller-clock TTL cache

`obj CacheStore store = new CacheStore()` provides `set(key,value)` for entries without expiration and `setFor(key,value,nowMs,ttlMs)` for finite lifetime entries. `hasAt(key,nowMs)` and `get(key,nowMs[,fallback])` lazily remove an entry once `nowMs >= expiresAt`; `prune(nowMs)` removes all expired entries and returns the count. `remove`, `size` and `clear` manage storage. The clock is supplied by the caller in non-negative milliseconds; TTL must be positive and timestamp addition must fit signed Int64. There is no background expiry thread, LRU policy, capacity limit or persistence. The cache is not thread-safe.

## `retry.fac` — retry decision and backoff policy

`obj RetryPolicy policy = new RetryPolicy(maxAttempts,initialDelayMs,maxDelayMs)` defines the maximum total operation attempts (including the original attempt) and deterministic exponential backoff. `shouldRetry(completedAttempts)` reports whether another attempt is allowed. `delayFor(retryNumber)` uses a one-based retry number, doubles the initial delay and caps at the maximum. This module does not run an operation, call a callback, sleep, add jitter or classify errors; the application owns execution and error policy.

## `transaction.fac` — staged StateStore batch

`obj StateTransaction tx = new StateTransaction(stateStore)` stages `setString`, `remove` and read-your-writes `getString`. `commit()` applies staged operations in insertion order; `rollback()` discards them; `isActive()` and `size()` expose transaction state. A repeated operation on the same key replaces its staged operation without changing its insertion position. This is a convenience batch for the in-memory `StateStore`, not a database/ACID transaction: it has no isolation or durability, does not protect against concurrent target mutation, and a runtime/allocation failure during `commit()` can leave a partially applied batch. Synchronize externally and do not use as a substitute for `sqlite`/database transactions.

## `router.fac` — declarative route registry

`obj RouteRegistry routes = new RouteRegistry()` registers `add(method,pattern,handlerName)`, removes exact registrations, supports `setFallback(handlerName)`, and resolves via `resolve(method,path)`. Methods are case-insensitive tokens normalized to uppercase. Paths must be absolute and exclude query/fragment. Routes may be exact or use one trailing `/*` wildcard; exact routes win, otherwise the longest matching wildcard prefix wins, then fallback/empty. Handler values are names only: this class neither invokes a handler nor parses query strings/route parameters, normalizes paths, or hosts HTTP. It is not a web security boundary.

## `scheduler.fac` — caller-polled task scheduler

`obj PollScheduler scheduler = new PollScheduler()` accepts `scheduleOnce(id,dueMs)` and `scheduleEvery(id,firstDueMs,intervalMs)`, supports replacement by ID and `cancel(id)`, and returns due IDs from `pollDue(nowMs)`. All times are caller-supplied non-negative signed Int64 milliseconds. Repeating jobs coalesce missed ticks and set their next due time to `nowMs + intervalMs`; they do not emit one event for each missed interval. The scheduler never creates threads, sleeps or invokes callbacks. It is not thread-safe.

## `workflow.fac` — explicit finite-state workflow

`obj Workflow flow = new Workflow(initialState)` records allowed pairs with `allow(from,to)`, checks with `canMoveTo(to)`, changes state using `moveTo(to)`, and exposes `state()`, `history()`, `historySize()` and `reset(initialState)`. Undeclared transitions return false and leave the current state unchanged. The module records state names only; it does not perform side effects, persist history, enforce roles or synchronize concurrent callers.

## V145 scope note

At V145, middleware invocation, service factories and type-erased DI were deliberately deferred. V146 adds the narrower primitives documented above: middleware ordering metadata, service lifecycle tracking and typed pre-created instance registries. They do not claim callback invocation, factories or type-erased lifetime scopes. `transaction` remains a staged `StateStore` helper, not a database transaction.

Regression: `tests/api/a22_v145_application_services.fac`; example: `examples/api/13_application_services.fac`.

---

# FAC V144: application architecture helpers

## `events.fac` — explicit polling event queue

`obj EventQueue pending = new EventQueue()` provides `publish(topic,payload)`, `hasNext()`, `size()`, `peekTopic()`, `peekPayload()`, `consume()` and `clear()`. Events are FIFO; consumers inspect the first item and then explicitly consume it. Topics must be non-empty, single-line strings. Payloads are opaque FAC strings. This is not callback dispatch: there is no subscribe/unsubscribe API, wildcard routing, automatic handler invocation or async execution. The queue is not thread-safe.

## `observer.fac` — polling observable values

`obj ObservableValue<T> value = new ObservableValue<T>(initial)` exposes `get()`, `set(value)`, `version()` and `changedSince(revision)`. The revision starts at zero and increments only when `set` changes the value according to FAC equality. A consumer stores the revision it last observed and polls `changedSince`; multiple consumers can hold independent revision tokens. Negative or future revisions throw InvalidArgument (4). This does not invoke callbacks and is not thread-safe. Generic equality follows the capabilities of `T`; reference-like values follow FAC copy/equality behavior.

## `state.fac` — in-memory application state

`obj StateStore app = new StateStore()` stores string-keyed values with `setString`, `setInt`, `setBoolean`, `getString`, `getInt`, `getBoolean`, `has`, `remove`, `keys`, `size`, `revision` and `clear`. Integer values are stored as decimal text; boolean values are written as lowercase `true`/`false`, while reads also accept `1/0`, `yes/no` and `on/off`. Invalid/missing typed reads return the caller's fallback. Mutation revision increments only when contents actually change. This store is in-memory only and is distinct from persistent `config`/INI. It is not thread-safe.

## `validation.fac` — accumulating scalar/string rules

`obj Validator rules = new Validator()` supports `required(field,value)`, `minLength/maxLength(field,value,n)`, `integer(field,value)`, `number(field,value)`, `oneOf(field,value,allowed)` and `emailLike(field,value)`. Each method returns a boolean and records a failure when false. Inspect with `valid()`, `errorCount()`, `errors()` and `errorAt(index)`; reset with `clear()`. Length uses FAC string grapheme length. `integer` parses signed Int64, `number` parses a FAC double, and `emailLike` is a conservative form-level check (one `@`, non-empty sides, a dot in the domain, and no whitespace), not full RFC validation or mailbox verification. This module does not replace `schema.fac`: `schema` validates scalar fields in Config/TOML/YAML documents; `validation` validates individual values and records errors. The validator is not thread-safe.

### Deliberately deferred in V144

Callback-based event subscriptions and observer callbacks, dependency injection (DI), and service factories are not exposed yet. Current FAC source APIs can use function/closure values in supported contexts, but there is not yet a stable general-purpose callable registry plus type-erased managed-object storage contract suitable for safe long-lived DI/service containers. V144 avoids disguising a string alias map as real dependency injection.

Regression: `tests/api/a21_application_architecture.fac`; example: `examples/api/12_application_architecture.fac`.

---

# FAC V143: XML, templates and reflection helpers

- `xml.fac`: `XmlDocument.parse()` reads one-root, element-only XML with simple ASCII names, comments, an optional XML declaration, self-closing tags and predefined `amp/lt/gt/quot/apos` entities. All element paths include zero-based indexes, e.g. `root[0].item[1]`; use `rootPath()`, `childCount()`, `childPath()`, `has()` and `getText()`. Attributes, namespaces, DTDs, CDATA, numeric entities, arbitrary processing instructions and full mixed-content preservation are unsupported. This is a safe subset reader, not a full XML 1.0 implementation.
- `template.fac`: `TemplateEngine.set(name,value)` feeds `render()`, `renderHtml()`, `renderStrict()` or `renderHtmlStrict()`. Placeholders use `{{name}}`. Non-strict modes preserve unknown placeholders; strict modes throw. HTML modes escape inserted values for HTML text context only, not for URL, CSS or JavaScript contexts. Templates are plain text and cannot evaluate expressions or load includes.
- `reflection.fac`: `Reflector<T>` wraps `typeof`, `type` and `DSof` to return type/category enums, their display names and compile-time size (for arrays/lists `typeof` reports the element type, so this is not the container allocation size). The source-library `Reflector<T>` API itself does not expose declared struct/class names, member lists, dynamic construction or reflection-based invocation. Separate V220 compiler intrinsics provide bounded compile-time queries for public non-static fields of resolved struct/class records; they are not runtime reflection and are documented in `docs/STRUCTURAL_REFLECTION_V220.md`.

Regression: `tests/api/a20_xml_template_reflection.fac`; example: `examples/api/11_xml_template_reflection.fac`.

# FAC Library API Reference (V144)

API policy: [`API_CONVENTIONS.md`](API_CONVENTIONS.md). Generated source declaration index: [`generated-api.md`](generated-api.md) (run `make docs-api`). Built-in APIs are described below; signatures and ownership notes should be maintained here alongside implementation changes.

## V142 structured data and exact decimal APIs

### `decimal.fac`

`obj Decimal amount = new Decimal()` stores a signed Int64 count of millionths (six fractional places). `parse(text)` accepts a signed base-10 value with at most six fractional digits and returns false for malformed/out-of-range input. `toString()` emits exactly six fractional digits. `scaledValue()` exposes the underlying millionths; `setScaledValue()`, `addScaled()`, `subtractScaled()`, `multiplyInt()`, `divideInt()` and `compareScaled()` operate on those scaled units. `addScaled()`/`subtractScaled()`/`compareScaled()` require another value's `scaledValue()`, not a Decimal object. Arithmetic overflow is left to FAC checked-integer behavior; division by zero throws. No exponent notation, currency, rounding modes or arbitrary precision is provided.

### `toml.fac`

`obj TomlDocument doc = new TomlDocument()`; `parse(text)`, `has(table,key)`, `getRaw/getString/getInt/getBoolean(table,key[,fallback])`, `setRaw(table,key,value)`, `clear()` and `toText()`. Supported TOML is intentionally limited to single-level `[table]` sections, bare non-dotted keys, quoted single/double-line strings, signed integers and booleans. Arrays, inline tables, floats, dates/times, dotted keys, multiline strings, escape decoding and array-of-tables are not supported; `parse` returns false on unsupported input and leaves entries parsed before the error.

### `yaml.fac`

`obj YamlDocument doc = new YamlDocument()`; `parse(text)`, `has(path)`, `getRaw/getString/getInt/getBoolean(path[,fallback])` and `clear()`. Supported input is a mapping of scalar values with at most one nested mapping level, full-line comments, optional document markers and simple quoted values. Sequences, anchors, aliases, tags, flow collections, block scalars, directives, deeper nesting and tab indentation are rejected. This is not a complete YAML 1.2 parser and does not claim general YAML interoperability.

### `schema.fac`

`obj DataSchema schema = new DataSchema()`; declare fields using `addString(name[,required])`, `addInteger(name[,required])` and `addBoolean(name[,required])`. A dotted field name maps to a section/key in INI/TOML and to a flattened mapping path in YAML. `validateConfig(Config)`, `validateToml(TomlDocument)` and `validateYaml(YamlDocument)` return lists of error messages; optional fields may be absent. This is a small scalar-field validator, not JSON Schema, and it does not yet enforce unknown-field policy, arrays, nested object constraints or numeric ranges.

### Existing formats: no duplicate wrappers

`config.fac` is the current INI reader/writer (`Config.parse/toText/load/save`); the module name is `config`, not `ini`. Native `json.encode(value)` and `json.decode(Type,text)` provide existing JSON serialization/deserialization for supported structs, maps and lists. Dedicated `serialize.fac`/`deserialize.fac` aliases would only duplicate those built-ins, so they are intentionally not added.

## result — Language Core result types (`stdlib/result.fac`)

`import result.fac just Option, Result` exports native generic payload enums `Option<T> { None, Some(T) }` and `Result<T,E> { Ok(T), Err(E) }`. Construct with `Option<int>.Some(7)` / `Option<int>.None` and `Result<int, ErrorCode>.Err(ErrorCode.Invalid)`; inspect values with `match` and destructure payloads in variant patterns. Postfix `?` propagates `None`/`Err` from functions returning the same family; `Result` propagation requires the exact same error type. Payloads support scalar, unit-enum, raw-pointer, string, list, struct, object/weak, function/closure and nested payload-enum types. The compiler generates tag-aware copy/drop/trace callbacks for managed payloads. Payload enums can be stored in lists (for example `list var Option<string>`); fixed-size arrays of payload enums are not supported yet. Raw pointers remain non-owning and are not automatically retained or freed. This is Language Core, not OOP. See [`LANGUAGE_CORE.md`](LANGUAGE_CORE.md).

# Library API (import X.fac) — built-in modules และ source-level standard libraries
ค่า `S`=string `L`=list dyn string `p`=handle (เช่น `ptr graphic`, `ptr three`, `ptr gpu`, `ptr audio`, `ptr font`) `U`=uint

## Core data structures (built into FAC)

All containers support `size()` / `length()`, `isEmpty()`, `clear()`, and `copy()` unless noted. `ptr` storage is not supported for these containers; use `var`, `dyn`, or `heap`.

- `arraylist <kind> <type> name = {...}` — resizable array: `add(v)`, `insert(i,v)`, `remove([i])`, `get(i)`, `set(i,v)`, `first()`, `last()`, `capacity()`, `reserve(n)`, `shrink()`, bracket indexing.
- `linked <kind> <type> name = {...}` — doubly linked list: `addFirst/addLast`, `removeFirst/removeLast`, `first/last`, `find(v)`, `insert(i,v)`, `remove(i)`, bracket indexing.
- `stack <kind> <type> name = {...}` — LIFO: `push/add(v)`, `peek/top()`, `pop()`. `pop()` transfers an owned string value out of the stack.
- `queue <kind> <type> name = {...}` — FIFO: `enqueue/add(v)`, `front/peek()`, `back()`, `dequeue()`. `dequeue()` transfers an owned string value out of the queue.
- `heap <kind> <type> name = {...}` — binary min-heap: `push/add(v)`, `peek/min()`, `pop()`. `maxheap` provides the max-heap counterpart with `peek/max()`.
- `trie <kind> string name = {...}` — string prefix tree: `insert/add(s)`, `has/contains(s)`, `startsWith(prefix)`, `remove(s)`, `words(prefix)`.
- `hashmap <kind> <keyType>, <valueType> name = {}` — `set/get/getOr/has/remove/keys/values`. `keys()` and `values()` return lists.
- `hashset <kind> <type> name = {...}` — unique values: `add/has/remove/toList/union/intersect/diff`.
- `tree <kind> <type> name = {...}` — binary search tree: `add/has/remove/min/max/height/inorder/preorder/postorder`.
- `graph <kind> <type> name = {}` — graph: `addNode/addEdge/addArc/neighbors/hasEdge/removeEdge/removeArc/removeNode/bfs/dfs/shortest`. Weighted `addEdge` / `addArc` accepts only finite, non-negative weights because `shortest` uses Dijkstra; negative, NaN or infinite weights raise Resource/Argument error 8. `removeArc` removes one direction; `removeEdge` removes both.
- `matrix <kind> <type> name[rows][columns] = {{...}, {...}}` — fixed-size, row-major 2D matrix; index with `m[row][column]`, or use `get/set/fill/rows/cols`. Dimensions must be positive compile-time constants.

`heap` in the first position is the collection name in `heap var int h`; `heap int value` remains the scalar heap-storage declaration. `maxheap` is a separate container type.

## Import selection

`import math.fac just sqrt, sin` imports only the named APIs. `import math.fac without sqrt, sin` imports the module except those APIs. Both selectors also work with `as name` and `global`.

## terminal input helpers

`terminal.out.answer(prompt, Type)` prints the prompt without a newline, then reads a typed value. `terminal.out.anwser(prompt, Type)` is a spelling-compatible alias. `String` reads the full line; `Char` and `Unichar` return the first Unicode code point in the next token; numeric and boolean types use the same parsing rules as `terminal.in.Scanner(Type)`.

Example: `var int x = terminal.out.anwser("Number: ", Int)` or `dyn string name = terminal.out.answer("Name: ", String)`.

## time
`now()`→ulong ms · `nowSec()` · `mono()`→ulong ns (นาฬิกาไม่ย้อน ใช้จับเวลา) · `sleep(ms)`
`format(ms, "%Y-%m-%d %H:%M:%S")` (เวลาท้องถิ่น) · `formatUtc(ms, fmt)` · `iso(ms)`→"2023-11-14T22:13:20Z" · `parse(text, fmt)`→ms (UTC; รองรับ %Y %y %m %d %H %M %S)
`year month day hour minute second weekday(ms)` (ท้องถิ่น, weekday 0=อาทิตย์) · `utcOffset()`→นาที

## crypto  (string = ไบต์ UTF-8; ผลแฮชเป็น hex)
`sha256 sha512 sha1 md5 (s)` · `hmacSha256(key,msg)` · `hmacSha512` · `sha256File(path)` · `crc32(s)`→uint
`base64Encode/base64Decode` · `hexEncode/hexDecode` (ผลเป็นไบต์ดิบใน string)
`randomHex(n)` · `randomBytes(n)` · `randomInt(a,b)` · `uuid()` (v4) — สุ่มจาก std::random_device (entropy ของ OS) · `constantTimeEq(a,b)`
*ไม่มี AES/RSA/TLS* — ต้องใช้ผ่าน FFI (OpenSSL/libsodium) ดู FFI.md · sha1/md5 ใช้เพื่อ checksum เท่านั้น ไม่ปลอดภัยสำหรับรหัสผ่าน · `sha256File` รับไฟล์ไม่เกิน 64 MiB · PBKDF2 จำกัด iteration 1..10,000,000 และ key length 1..65,536 bytes เพื่อจำกัดต้นทุน CPU/หน่วยความจำ

## graphic  (canvas ซอฟต์แวร์ 0xRRGGBB ไม่ต้องพึ่ง library ภายนอก)
`create(w,h)` · `open(w,h,"title")` (หน้าต่างจริง: Windows ผ่าน Win32 GDI (ยังไม่ได้ทดสอบ) · Linux/macOS ผ่าน SDL2 โหลดตอนรันด้วย dlopen — ต้องติดตั้ง libSDL2 เฉพาะเครื่องที่เรียก `open`; ทดสอบจริงบน Linux/X11 (Xvfb) แล้ว, macOS ยังไม่ได้ทดสอบ) · `free(c)` · `width/height(c)`
`rgb(r,g,b)`→uint · `clear(c,col)` · `pixel(c,x,y,col)` · `get(c,x,y)` · `line` · `rect/fillRect(c,x,y,w,h,col)` · `circle/fillCircle(c,cx,cy,r,col)` · `fillTriangle(c,x1,y1,x2,y2,x3,y3,col)`
`text(c,x,y,"HELLO",col[,scale])` (ฟอนต์ 3x5: A-Z 0-9 และ . , : - + = ! ? / ( ) % _ * # < >) · `save(c,"a.png|a.bmp|a.ppm")` (PNG ไม่บีบอัด)
ลูปหน้าต่าง: `while(graphic.poll(c)) { ...วาด...; graphic.present(c); graphic.delay(16) }` · `key(c,"left|right|up|down|space|esc|enter|a..z")` · `mouseX/mouseY/mouseDown(c)`
Canvas / โหลด PNG, BMP และ PPM จำกัดไม่เกิน 16M พิกเซล; ไฟล์ภาพไม่เกิน 256 MiB. เพดานนี้คำนึงถึงทั้ง pixel buffer และ float64 depth buffer ของ Canvas ไม่ใช่แค่ขนาดไฟล์. ถ้าไม่มี SDL2: `open` throw Error พร้อมวิธีติดตั้ง — ใช้ `create`+`save` ได้เสมอ (ไม่ต้องมีหน้าต่าง)

## three (พื้นฐาน 3D แบบ software rasterizer)
`camera(x,y,z,yaw,pitch,fov)` → handle กล้อง (มุม yaw/pitch เป็น radians, fov เป็น degrees) · `free(camera)`
`begin(canvas,camera)` ล้าง depth buffer ก่อนวาดเฟรม · `projectX/projectY(canvas,camera,x,y,z)` คืนพิกัดจอ หรือ `-2147483648` เมื่อจุดอยู่หลังกกล้อง · `projectDepth(...)` คืนระยะหน้า/หลังกกล้อง (`-1` เมื่อมองไม่เห็น)
`point(canvas,camera,x,y,z,color,size)` · `line(canvas,camera,x1,y1,z1,x2,y2,z2,color)` · `triangle(canvas,camera,x1,y1,z1,x2,y2,z2,x3,y3,z3,color)` · `cube/sphere/plane(canvas,camera,x,y,z,size,color)` · `grid(canvas,camera,x,y,z,extent,divisions,color)`
ปรับกล้องด้วย `moveCamera(camera,dx,dy,dz)`, `rotateCamera(camera,yawDelta,pitchDelta)` (radians) และ `setFov(camera,degrees)` (1..179) ได้; พิกัดกล้องมองไปทาง +Z, วาดลง `graphic` canvas ด้วย z-buffer ไม่มี lighting/material/texture/clipping ขั้นสูง และสามเหลี่ยมที่ตัดระนาบ near อาจถูกข้ามทั้งชิ้น

## gpu (resource API / software reference backend)
`backend()` → `"software-reference"` · `hardware()` → false · `createBuffer(bytes)` · `freeBuffer(buffer)` · `bufferSize(buffer)`
`writeBuffer(buffer,offset,bytes)` → boolean · `readBuffer(buffer,offset,count)` → string แบบ raw bytes · `copyBuffer(dst,dstOffset,src,srcOffset,count)` → boolean
ขอบเขตสำคัญ: นี่เป็น API จัดการ buffer บน CPU เพื่อเป็นฐานสำหรับ backend ต่อไป **ยังไม่ได้ส่งคำสั่งไปยัง GPU จริง**; ขนาด buffer สูงสุด 256 MiB

## game  (ไลบรารี Fac ล้วน: `stdlib/game.fac` — import game.fac)
ลูปเกมแบบ **fixed timestep**: `update(dt)` ถูกเรียกด้วย dt คงที่ (ค่าเริ่มต้น 60 Hz) 0..N ครั้งต่อเฟรม แล้ว `draw()` 1 ครั้ง แยกอัตราตรรกะออกจากอัตราวาด
- `run(w, fps, update, draw)` — ลูปเวลาจริง: poll event → update → draw → present → หน่วงให้ได้ fps (1..1000) ใช้ได้กับหน้าต่าง (`graphic.open`) และ canvas ที่ไม่มีหน้าต่าง (จบเมื่อ `quit()`); หน้าต่างปิด = จบลูป
- `simulate(frames, fps, update, draw)` — เดินเกมแบบกำหนดผลโดยไม่แตะนาฬิกาจริง (เฟรมละ 1/fps วินาที) สำหรับเทสต์/replay/เซิร์ฟเวอร์; `stepNs(elapsedNs, update, draw)` — เดิน 1 เฟรมด้วยเวลาที่ระบุ (เขียนลูปเองได้)
- `setUpdateRate(hz)` (1..1000) · `setMaxCatchUp(n)` (ค่าเริ่มต้น 5: ถ้าเฟรมช้าเกินจะ update ย้อนหลังได้ไม่เกิน n ครั้ง แล้วทิ้งเวลาที่ค้างกัน spiral of death; เฟรมเดียวนับเวลาจริงไม่เกิน 250 ms) · `quit()` · `quitting()` · `reset()`
- ข้อมูล: `dt()` วินาทีต่อ update · `alpha()` 0..1 ส่วนที่ค้างระหว่าง update (ใช้ interpolate ตอนวาด) · `elapsed()` เวลาจำลองสะสม (วินาที) · `frame()` · `updates()` · `fps()` (วัดทุก 0.5 วินาที)
- เวลาภายในเป็นจำนวนเต็มนาโนวินาที จึงนับจำนวน update ได้แน่นอนไม่คลาดเคลื่อนสะสม (ที่ 60 Hz หนึ่ง update = 16,666,666 ns)
- **ข้อควรจำ:** lambda ของภาษาจับตัวแปรตามค่า (copy) — สถานะเกมที่ update/draw ใช้ร่วมกันให้เก็บเป็นตัวแปร global ระดับไฟล์ แล้วส่งฟังก์ชันที่มีชื่อเข้ามา (ดู `examples/pong.fac`)
- หน่วงเฟรมด้วย `time.sleep` (ความละเอียด ms) แล้ว spin ช่วงท้าย: แม่นแต่ใช้ CPU ราว <1 ms ต่อเฟรม; ยังไม่มี vsync (SDL ตั้งปิดไว้)

## fs (Result-based filesystem wrappers — `import fs.fac`)
`exists(path)` · `isFile(path)` · `isDir(path)` เป็น predicate สำหรับ filesystem metadata และอาจ stale ได้ทันทีหลังเรียก; `list(path)` → `Result<list dyn string, FsError>` คืนชื่อ entry ที่ sort แล้ว (ไม่ใช่ absolute path) หรือ `Err(NotFound|Io)`; แนะนำเก็บผลไว้ในตัวแปรก่อน `match` เช่น `enum Result<list dyn string, FsError> r = fs.list("assets");`; `readText/readLines/size/modified` คืน `Result<T,FsError>` เช่นกัน. `writeText/appendText/makeDir/rename/copy/remove` คืน `Result<boolean,FsError>` โดย `makeDir` สร้าง parent directories ให้ด้วย. ใช้ `match` หรือ `?` กับ Result; `fs.describe(error)` คืนข้อความสำหรับคนอ่าน ไม่ใช่ข้อความสำหรับ parse. `FsError.NotFound` จัดประเภทจากการตรวจ `path.exists` หลัง failure จึงอาจมี race กับการเปลี่ยนแปลง filesystem.

## tilemap / camera / anim / input  (ไลบรารี Fac ล้วน — `stdlib/*.fac`, import tilemap.fac ฯลฯ)
ทั้งหมดเขียนด้วยภาษา FAC เอง (พกพาข้าม OS/สถาปัตยกรรมโดยธรรมชาติ) ใช้ร่วมกับ `game`, `collide`, `graphic` — ตัวอย่างครบวงจร: `examples/explorer.fac`

**tilemap** — `obj tilemap.Tilemap m = new tilemap.Tilemap(cols, rows, tileSize)` · ไทล์ id 0 = ว่าง; id n ≥ 1 วาดจากช่อง n-1 ของ atlas (เรียงซ้าย→ขวา บน→ล่าง)
`get(c,r)` (นอกแผนที่ = 0) · `set(c,r,id)` · `fill(id)` · `fillRect(c,r,w,h,id)` (clip กับขอบแผนที่; ปฏิเสธ id/w/h ติดลบ) · `clear()` · `occupiedCount()` · `inside(c,r)` · `widthPx()/heightPx()` · `colAt(x)/rowAt(y)` (พิกเซลโลก → ช่อง, ปัดลงถูกต้องกับค่าติดลบ)
ไทล์ตัน: `setSolid(id, bool)` · `isSolidId(id)` · `solidAt(c,r)` (**นอกแผนที่นับเป็นตัน; id 0 ว่างเสมอ**) · `hitsSolid(x,y,w,h)` (สี่เหลี่ยมซ้อนไทล์ตัน; แตะขอบไม่นับ)
`move(x,y,w,h,dx,dy)` → `(x',y')` เคลื่อนสี่เหลี่ยมแล้วถูกกำแพงกั้น: แยกแกน X แล้ว Y ต่อก้าวย่อย (≤ ครึ่งไทล์ ไม่ทะลุกำแพงบาง), ชิดผิวกำแพงพอดี, เดินเลียกำแพงได้; ถ้าเริ่มซ้อนกำแพงอยู่แล้วจะไม่ขยับในแกนที่ติด; รับ rectangle/delta ที่ finite และจำกัดไม่เกิน 100,000 substeps
`draw(dst, atlas, atlasCols, camX, camY)` วาดเฉพาะส่วนที่มองเห็น (camX/camY = พิกเซลโลกของมุมซ้ายบนจอ, ติดลบได้) ด้วย `blitRegion` (เคารพ alpha); `atlasCols` ต้อง ≥ 1 — หลายชั้น = หลาย Tilemap วาดเรียงกัน
**entity** — `interface Entity { update(dt), draw(g,camX,camY), alive() }` + `new entity.World()`: `add(e)` · `count()` · `clear()` · `update(dt)` (ตามลำดับที่ add; ของที่ add ระหว่าง update เริ่มเฟรมถัดไป; ตัวที่ `alive()` เป็นเท็จหลัง update ถูกถอดโดยคงลำดับ) · `draw(g,camX,camY)` — ดู docs/OOP.md

**camera** — `new camera.Camera(viewW, viewH)` · `x`,`y` = มุมซ้ายบนจอในพิกัดโลก · `setBounds(worldW, worldH)` / `clearBounds()` (กล้องถูกบีบในโลก; โลกเล็กกว่าจอ → จัดกึ่งกลาง) · `snapTo(tx,ty)` · `follow(tx,ty,speed,dt)` (exponential: ผลเท่ากันไม่ว่า frame rate; speed ≤ 0 = snap; dt ติดลบ/ค่าไม่ finite = throw) · `moveBy(dx,dy)` · `px()/py()` (ปัดลงเป็นพิกเซลจำนวนเต็ม กันภาพสั่น) · `screenX/screenY/worldX/worldY` · `sees(x,y,w,h)` — ยังไม่มี zoom/หมุน/shake
**anim** — `new anim.Anim(sheetCols, fw, fh, firstCell, count, fps, loop)` · `update(dt)` / `updateNs(ns)` · `setLooping(bool)` · `setFrame(index)` · `durationNs()` · `frameProgress()` (เศษส่วนของเฟรมปัจจุบัน) · `frame()` · `cell()` · `finished()` (loop=false) · `reset()` · `draw(dst, sheet, x, y, flipX)` (flipX พลิกเฉพาะช่องที่ตัดมา ผ่าน `graphic.blitRegionEx`) — clock ใช้ integer ns พร้อมการอัปเดตแบบ modulo/saturating ที่ไม่ overflow; dt/ns ≤ 0 เป็น no-op และ dt ที่เป็น NaN/Infinity จะ throw
**input** — ผูก action กับคีย์: `bind(action,key)` (หลายคีย์ต่อ action) · `unbind(action)` · `clearBindings()` · `update(w)` (เรียกต้นทุก update) · `down/pressed/released(action)` · `axis(neg,pos)` → -1.0/0.0/1.0 · `inject(key,down)` / `releaseAll()` (คีย์เสมือน OR กับคีย์จริง: เทสต์ บอท replay) — ชื่อคีย์ตาม `graphic.key`; สถานะเป็น singleton ของโปรแกรม; ยังไม่มีเมาส์/เกมแพด
**graphic.blitRegionEx**`(dst,src,x,y,sx,sy,sw,sh,flags)` — เหมือน `blitRegion` แต่ flags bit0 = พลิกแนวนอน, bit1 = พลิกแนวตั้ง (พลิกเฉพาะบริเวณที่ตัด)

## collide  (ไลบรารี Fac ล้วน: `stdlib/collide.fac`)
สี่เหลี่ยม = (x, y, w, h) มุมซ้ายบน, วงกลม = (cx, cy, r); ใช้ `double` ทั้งหมด; การชนเป็นแบบ **ซ้อนทับจริง** (แตะขอบเฉยๆ ไม่นับ)
`overlapRect(ax,ay,aw,ah, bx,by,bw,bh)` · `overlapCircle(ax,ay,ar, bx,by,br)` · `circleRect(cx,cy,r, x,y,w,h)` · `pointInRect(px,py, x,y,w,h)` (รวมขอบซ้าย/บน ไม่รวมขวา/ล่าง) · `pointInCircle(px,py, cx,cy,r)` · `distance(x1,y1,x2,y2)`
`separate(a..., b...)` → `(dx, dy)` เวกเตอร์เล็กที่สุดที่ต้องเลื่อน A ให้พ้น B (ไม่ซ้อน = `(0,0)`; เลือกจาก 4 ทิศ เท่ากัน → ซ้าย, ขวา, ขึ้น, ลง) · `rayRect(ox,oy, dx,dy, x,y,w,h)` → t ≥ 0 ที่รังสีเริ่มเข้าสี่เหลี่ยม (จุดชน = o + t·d) หรือ -1.0 ถ้าไม่โดน (แตะขอบนับว่าโดน; จุดเริ่มอยู่ข้างใน = 0.0)
**V102:** `rayCircle(ox,oy,dx,dy,cx,cy,r)` → t ของรังสีชนวงกลม (ทิศไม่ต้อง normalize; เริ่มอยู่ในวงกลม = 0); `closestPointOnSegment(px,py,ax,ay,bx,by)` → `(x,y)`; `pointSegmentDistance(...)`; `segmentRect(ax,ay,bx,by,x,y,w,h)` → t ในช่วง segment 0..1 หรือ -1. `distance` ใช้ `hypot` เพื่อลด overflow จาก dx²+dy²; area-overlap predicates คืน false เมื่อ radius/width/height ≤ 0; ray/segment queries ยังใช้ทดสอบเส้นหรือจุดขนาด 0 ได้
**V103:** `segmentCircle(ax,ay,bx,by,cx,cy,r)` → t แรกที่ segment แตะวงกลม; `sweepCircle(ax,ay,ar,dx,dy,bx,by,br)` → continuous collision ของวงกลมที่ A เคลื่อนด้วย displacement `(dx,dy)` ในเวลา normalized 0..1 กับ B ที่อยู่นิ่ง; `sweepRect(ax,ay,aw,ah,dx,dy,bx,by,bw,bh)` → `(t,nx,ny)` สำหรับ AABB ที่เคลื่อนที่ โดย normal ชี้ออกจาก B, ไม่ชนคืน `(-1,0,0)`, เริ่มซ้อนคืน `(0,0,0)`; กรณีเคลื่อนขนานกับหน้าที่แตะอยู่จะคง normal ของหน้านั้นเพื่อไม่ให้การไถลตามกำแพงถูกตีความเป็นการชนพื้น; `overlapOrientedRect(acx,acy,ahw,ahh,angleA,bcx,bcy,bhw,bhh,angleB)` → SAT สำหรับ oriented rectangles โดย angle เป็น radians และขนาดเป็น half-extents. Contact ใน swept queries นับเป็นชน แต่การแตะขอบแบบ static ยังไม่ถือว่า overlap; invalid/ไม่ finite คืน miss/false.
**V104:** `pointInPolygon(px,py,vertices)` รับ `array double` ที่เก็บพิกัดสลับ x/y และรองรับ simple polygon ทั้งเว้า/นูน โดยนับจุดบนขอบว่าอยู่ข้างใน; `overlapConvexPolygons(a,b)` ใช้ SAT สำหรับ convex polygons โดยต้องเรียง vertex ตามขอบเขตตามเข็มหรือทวนเข็ม (strict overlap: แตะขอบไม่นับ). Polygon API ปฏิเสธ input เสียรูป, non-finite, ซ้ำ/เส้นตัดกัน, concave หรือเกิน 512 vertices; ตัวตรวจ self-intersection ใช้ O(n²), จึงควรใช้ collision hull ที่มี vertex ไม่มาก.

`obj collide.SpatialHash grid = new collide.SpatialHash(cellSize)` เป็น broad-phase สำหรับ AABB: `insert(id,x,y,w,h)` ใส่ object ID ลงทุก cell ที่กรอบครอบคลุม, `query(x,y,w,h)` คืน `list int` ของ candidate IDs แบบไม่ซ้ำ, `clear()` ใช้ล้างเพื่อ rebuild รายเฟรม, `objectCount()` / `membershipCount()` ใช้ตรวจขนาด index. Candidate อาจมี false positive และต้องเรียก narrow-phase เช่น `overlapRect` ต่อ; ไม่รับประกันการชนจริง. Insert/query ปฏิเสธกรอบผิดรูปหรือกินเกิน 65,536 cells; index จำกัดรวม 1,048,576 object-cell memberships. ลำดับ candidate ไม่รับประกัน และไม่รองรับ concurrent writer.
ตัวอย่างสร้าง index ใหม่ในแต่ละเฟรม: `obj collide.SpatialHash grid = new collide.SpatialHash(64.0)` → `grid.clear()` → เรียก `grid.insert(id,x,y,w,h)` ให้ครบทุก entity → `list var int candidates = grid.query(playerX,playerY,playerW,playerH)` → วน ID ที่ได้แล้วกรองด้วย `overlapRect` กับ AABB จริงของ entity. ค่า `cellSize` เป็น private/คงที่หลังสร้าง object เพื่อป้องกัน index เสียความสอดคล้อง.

`tests/cases/t42_collide` ยังคงเทียบ oracle Python 400 เคสสุ่ม; V103 coverage อยู่ใน `tests/cases/t120_collide_continuous` และ `tests/api/a10_v103_collision`; V104 เพิ่ม `tests/api/a11_v104_collision_broadphase`.

### graphic: ภาพ PNG + sprite (V12)
- `load("a.png")` — ตัวถอดรหัส PNG ในตัว (ไม่พึ่ง library ภายนอก): color type 0/2/3/4/6, bit depth 1/2/4/8/16, tRNS, Adam7 interlace; ตรวจ CRC และ Adler-32; 16-bit ลดเป็น 8-bit (ตัด byte สูง); ภาพ ≤ 16M พิกเซล (ใช้เพดานเดียวกับ Canvas/Depth Buffer); ไฟล์เสียหายหรือเกินขีดจำกัด → throw `Error` code 14 (มี targeted mutation fuzz 500 ไฟล์ภายใต้ ASan/UBSan ใน V133; ไม่ใช่ exhaustive fuzzing)
- ภาพที่มี alpha เก็บ alpha แยกต่อพิกเซล: `hasAlpha(c)` · `alphaAt(c,x,y)` (255 ถ้าภาพไม่มี alpha หรือ ถ้านอกภาพคืน 0)
- `blitAlpha(dst,src,x,y)` — วาดโดยเคารพ alpha (สูตรผสมเดียวกับ `blend`: (s·a + d·(255−a)) / 255); ภาพไม่มี alpha = ทึบ
- `blitRegion(dst,src,x,y,sx,sy,sw,sh)` — วาดเฉพาะสี่เหลี่ยม (sx,sy,sw,sh) ของ src (sprite sheet / texture atlas / tile); ส่วนที่เกินขอบ src ถูก clip และเลื่อนตำแหน่งตาม
- `blitScaled(dst,src,x,y,w,h)` — ย่อ/ขยายแบบ nearest-neighbor (เหมาะ pixel art); `w` หรือ `h` ติดลบ = พลิกแนวนอน/แนวตั้ง (`x` คือขอบซ้ายบนของสี่เหลี่ยมที่วาดเสมอ)
- ทุกฟังก์ชันวาด clip ตามขอบ canvas และวาดจากภาพลงภาพเดียวกันได้ (ใช้สำเนาชั่วคราว)
- `blit`/`blitKey` เดิมไม่เปลี่ยนพฤติกรรม (ไม่สนใจ alpha) · `save("a.png")` เขียนเป็น RGBA ถ้าภาพมี alpha (เขียนแบบ zlib stored ไม่บีบอัด)
- ยังไม่มี: alpha ใน BMP 32 บิต, gamma/ICC/APNG, การหมุนภาพ, การบีบอัด PNG ตอนบันทึก

## audio (PCM 16-bit)
`create(rate,channels,frames)` · `tone(frequency,durationSeconds,rate,volume)` → mono clip · `load(path)` · `saveWav(clip,path)` · `play(clip)` → boolean · `playLoop(clip)` → boolean (วนจนกว่า `stop()`) · `stop()` (หยุดทุกเสียง) · `volume(v)` master 0..1 · `playing()` → จำนวนเสียงที่กำลังเล่น · `mix(dst,src,gain)` · `gain(clip,value)` · `free(clip)`
`frames(clip)` · `rate(clip)` · `channels(clip)` · `duration(clip)` · `available()`; WAV รองรับ PCM 16-bit mono/stereo
**Linux/macOS:** mixer ในตัวผ่าน SDL2 (dlopen) — `play` เล่น **ซ้อนกันได้สูงสุด 64 เสียง** (เปลี่ยนจากเดิมที่ `play` ตัดเสียงก่อนหน้า), clip ถูกคัดลอกและแปลงเป็น stereo 44100 Hz ตอนสั่งเล่น (free clip ทีหลังได้), รองรับ clip ทุก sample rate (linear resample). ถ้าไม่มี SDL2 จะถอยไปใช้ `aplay`/`paplay` (เล่นได้ครั้งละเสียง, ไม่มี `playLoop`/`volume`/`playing`)
**Windows:** `PlaySound` (ครั้งละเสียง; `playLoop` ใช้ได้ แต่ `volume`/`playing` ยังไม่มีผล และ Windows ยังไม่ได้ทดสอบ)

## font (bitmap + optional vector font)
`create(scale)` creates the portable 3×5 bitmap font. `load(path,size)` loads a local TTF/OTF file through the optional Pango/Cairo/Fontconfig backend (size 1..512 px); `backendAvailable()` reports whether that backend is present. `family(font)`, `size(font)` and `isVector(font)` inspect a font; `setSize(font,px)` changes vector size; `draw`, `measure`, `height` and `free` work with either font kind. `setScale` remains bitmap-only.

The vector backend is loaded dynamically at runtime on supported Unix-like hosts and does not add a mandatory build-time dependency. If libraries are missing, bitmap fonts continue to work. The V116 backend was tested on Linux; Windows currently uses the bitmap fallback. Font files are registered for the current process only, not installed system-wide. Vector font handles and their Pango layouts are not thread-safe; synchronize access and do not free a font while a `TextLayout` borrows it.

## keyboard / mouse (window input)
`keyboard.down(canvas,keyName)` เช่น `"left"`, `"right"`, `"home"`, `"end"`, `"delete"`, `"backspace"`, `"tab"`, `"shift"`, `"ctrl"`, `"space"`, `"esc"`, `"a"` · `mouse.x/y/down/button(canvas,...)`
`graphic.startTextInput(canvas)` / `stopTextInput(canvas)` ควบคุมการรับข้อความ; `graphic.textInput(canvas)` คืน UTF-8 ที่ commit ใน `graphic.poll` รอบปัจจุบัน (snapshot ถูกล้างเมื่อ poll ครั้งถัดไป, สูงสุด 64 KiB) · `graphic.clipboardGet(canvas)` คืน string ว่างเมื่ออ่านไม่ได้ · `graphic.clipboardSet(canvas,text)` คืน boolean
backend: Windows (Win32 WM_CHAR/WM_IME_CHAR, Unicode clipboard) และ Linux/macOS (SDL2 SDL_TEXTINPUT/clipboard); clipboard ต้องมี active window และอาจไม่มีใน headless environment

## json
`encode(x)` (struct/list/array/hashmap/hashset/tree/linked) · `decode(Type, s)` (struct ซ้อน/list/enum/ตัวเลข/string/bool)
แบบ dynamic: `ptr json j = json.parse(s)` · `get(j,"k")` · `at(j,i)` · `str int float bool(node)` · `len kind has keys` · `free(j)` · `valid(s)` · `pretty(s)` · `compact(s)`
(ใน string literal ใช้ `\{` `\}` แทน { } เพราะ { } คือ interpolation)

## csv · file · sys · path · regex
`csv.parseLine(line)`→list · `csv.formatLine(list)`
`file.readLines readText writeAll append size mkdir rename copy delete exists` + open/readline/readall/write/close. `readAll/readText/readLines` cap input at 64 MiB, `readLine` caps one line at 16 MiB, and `readLines` caps output at 1,000,000 lines; larger input returns FAC Error rather than growing without bound.
`sys.run(cmd)`→exit code · `output(cmd)` · `cwd chdir pid platform cpuCount hostname env exit args`

> **Security:** `sys.run` / `sys.output` hand `cmd` to the OS shell. Never build `cmd` from untrusted input (user text, network data, file names you did not create); validate or avoid the shell for such values. `sys.output` captures at most 64 MiB, then drains/discards excess output until the child exits; this is not an execution timeout. `sys.run` and `sys.output` can block indefinitely if the child process does. `--safe` is not an OS sandbox and does not disable these trusted Runtime calls.
`path.join name ext parent exists isDir list` · `regex.match find findAll replace` (ECMAScript)

> **regex limits:** subject up to 256 KiB, pattern up to 2048 bytes (larger → FAC error). Matching is backtracking, so patterns with nested unbounded quantifiers such as `(a*)*b` can take exponential time: never apply an untrusted pattern, and be careful applying your own to untrusted text.

## math / random / string เพิ่ม
math: `asin acos atan atan2 sinh cosh tanh exp cbrt hypot fmod trunc lerp clamp sign isNaN isFinite degToRad radToDeg smoothstep wrap` + ค่า `PI E TAU INF NAN`
random: `uniform(min,max)` · `weighted(values,weights)` · `normal(mean,sd)` · `triangular(min,mode,max)` · `exponential(lambda)` · `poisson(lambda)` · `perlin(x[,y])` · `simplex(x[,y])` · `fbm(x[,y],octaves)` · `markov(state,matrix,count)` · legacy `gauss(mean,sd)` · string: `repeat padLeft padRight(s,w,ch) reverse count lastFind lines capitalize isNumber`
**String performance:** strings are immutable; assignment, parameter passing, and managed copies share storage with an atomic reference count (O(1), no byte-buffer copy). Dynamic strings store the header and UTF-8 bytes in one contiguous allocation. The compiler flattens a chain of 3+ string `+` operands into one allocation/copy. For a dynamically sized batch, prefer `string.join(parts, separator)`.

## net  (TCP + HTTP/1.1; **ไม่มี TLS/https**)
`connect(host,port)` (host 1..253 bytes; rejects whitespace/control) · `listen(port)` (0 = สุ่มพอร์ต, `localPort(s)`) · `accept(s)` · `send(s,str)` · `recv(s,max)` · `recvLine(s)` · `close(s)` · `setTimeout(s,ms)` (ms ต้อง >= 0; 0 = ไม่จำกัดเวลา; applies to socket send/receive; `recvAll` caps response at 64 MiB) · `httpGet(url)` · `httpPost(url,body)` (status ≥400 → throw Error; validates status/header syntax and exact `Content-Length`; checks chunk terminator/trailers; 64 MiB cap; socket send/receive timeout 30s and total response deadline 60s; cleartext only, no HTTPS). `listen(port)` binds `0.0.0.0` (all IPv4 interfaces), not loopback-only. DNS resolution and `connect()` are blocking and not covered by `setTimeout`; configure firewalls and do not expose an untrusted listener without an application-level access policy.

# เพิ่มรอบที่ 4 (API ที่ขาด)
**terminal** `out.answer(prompt, Type)` / `out.anwser(prompt, Type)` · `out.flush()` · `in.eof()` · `in.readAll()` · `in.readChar()`→int(-1=EOF) · `clear()`
**string** `trimLeft trimRight equalsIgnoreCase chars indexOf compare` · **char** `isUpper isLower isAlnum isPunct toUpper toLower`
**math** `deg rad gcd lcm mod(บวกเสมอ) isInf` · **random** `shuffle(arrayหรือlist)` `choice(arrayหรือlist)` · **memory** `zero(p,n)`
**file** `isFile modified eof writeLine flush remove` · **sys** `setEnv tempDir` · **path** `stem absolute isFile isAbsolute normalize`
**regex** `groups split count` · **net** `get post urlEncode urlDecode setTimeout recvAll sendLine`
**json builder** `object array newStr newInt newFloat newBool newNull set(obj,key,node) push(arr,node) stringify stringifyPretty` (set/push รับ node ลูกไปเป็นเจ้าของ — free เฉพาะราก)
**thread** `id yield atomicAdd/atomicGet/atomicSet/atomicCas(ptr int,...)` (ค่าเริ่มต้น `seq_cst`; มีชื่อ explicit `*SeqCst`) · `atomicGetRelaxed/Acquire`, `atomicSetRelaxed/Release`, `atomicAddRelaxed/Acquire/Release/AcqRel`, `atomicCasRelaxed/Acquire/Release/AcqRel` สำหรับกำหนด memory order · `parallelFor(n, function void(int i){...})` แบ่งงานข้ามทุก core
**crypto** `pbkdf2(password,salt,iterations,keyBytes)`→hex (HMAC-SHA256) · **csv** `field(line,i)`
**graphic** `blit blitKey(dst,src,x,y[,key]) blend(c,x,y,col,alpha) load("a.png|a.bmp|a.ppm") hsv(h,s,v) textWidth blitAlpha blitRegion blitScaled hasAlpha alphaAt`

## TUI Engine (source module)
`import tui.fac` — lightweight secondary helpers for ANSI/truecolor styling, cursor control, panels, borders, tables, progress/status, semantic text colors, keyboard hints, semantic notices and line-input menus. It is not a full raw-key widget framework. See `docs/TUI.md`.

## easing / color (source modules — `import easing.fac`, `import color.fac`)
**easing**: `linear/smoothstep/smootherstep(t)` · `inQuad/outQuad/inOutQuad(t)` · `inCubic/outCubic/inOutCubic(t)` · `inSine/outSine/inOutSine(t)` — easing รับ t แล้ว clamp ให้อยู่ใน 0..1; `lerp(a,b,t)` (ไม่ clamp t) · `inverseLerp(a,b,value)` (a==b คืน 0) · `remap(value,inA,inB,outA,outB)` · `damp(current,target,speed,dt)` (exponential, frame-rate independent; speed/dt <= 0 ไม่ขยับ) · `moveTowards(current,target,maxDelta)` (ไม่ overshoot) · `repeat(value,span)` (modulo บวก) · `pingPong(value,length)` (คลื่นสามเหลี่ยม 0..length; length <= 0 คืน 0)
**color**: สีเป็น packed RGB `0xRRGGBB` ไม่มี alpha ในค่าเดียวกัน; `rgb(r,g,b)` (clamp channel 0..255) · `red/green/blue(c)` · `withRed/withGreen/withBlue(c,v)` · `invert(c)` · `grayscale(c)` (luma 299/587/114) · `lerp(a,b,t)` (clamp t 0..1) · `multiply(c,factor)` · `over(foreground,background,alpha)` (alpha 0..255)


## motion / theme / ui (source modules — `import motion.fac`, `import theme.fac`, `import ui.fac`)

**motion.Tween**: `new motion.Tween(initial)` · `to(target,seconds,easingId)` · `update(dt)` · `value()` · `progress()` · `isAnimating()` · `snap(value)` · `setReduceMotion(bool)`. Easing IDs: 0 linear, 1 smoothstep, 2 outQuad, 3 outCubic, 4 inOutCubic. Retargeting begins from the current interpolated value; each update is capped at 0.1 seconds. **motion.Spring**: `new motion.Spring(initial,stiffness,damping)` · `setTarget(value)` · `update(dt)` · `position` · `settled()` · `snap(value)` · `setReduceMotion(bool)`; stiffness 0–2000, damping 0–200, bounded substep integration. See `docs/MOTION.md`.

## theme / ui (source modules — `import theme.fac`, `import ui.fac`)

`theme.Theme` เป็นชุด design tokens สำหรับ GUI: dark/light palette, surface/text/border/accent/semantic colors, radius, control sizing และ text scale. ใช้ `new theme.Theme()`, `setDark()`, `setLight()`, `setAccent(r,g,b)`.

`ui.fac` เป็น immediate-mode component library หลักสำหรับ GUI ที่วาดผ่าน `graphic` canvas (ไม่ใช่ native OS widgets):
Animated counterparts: `animatedButton`, `animatedSidebarItem`, `animatedToolbarButton`, `animatedToggle`, `animatedTabs` and `animatedPanel` take persistent per-widget state objects (`ButtonMotion`, `SidebarMotion`, `ToggleMotion`, `TabsMotion`, `PanelMotion`). `ui.beginFrame()` updates the monotonic `frameDelta()` once per frame; `theme.setReduceMotion(true)` makes these controls snap to target state. See `docs/UI.md` and `examples/ui_motion.fac`.
- Frame/input: `beginFrame(canvas)`, `mouseX/Y`, `mouseDown/Pressed/Released`, `hovered`
- Surfaces/layout: `roundedRect`, `card`, `divider`, `verticalDivider`, `sectionTitle`, `statCard`, `navItem`, `tabs`
- Text/status: `text`, `mutedText`, `title`, `centeredText`, `badge`, `alert`, `avatar`
- Controls: `button`, `checkbox`, `toggle`, `slider`, `progress`, `dropdown`, `radioGroup`, `inputField` (วาดอย่างเดียว), `textField` (single-line), `textArea` (multiline) และ `blurTextField`. TextField/TextArea ใช้ focus ID และ bounded undo/redo history ร่วมกัน; TextArea รองรับ Enter เป็น newline, Up/Down preferred column, selection, clipboard, Tab order และ vertical scrolling.
- CSS-inspired style objects: `ui.Style`, `ui.Styles`, `panel`, `label`, `buttonStyle`; style fields include `background`, `color`, `borderColor`, `borderWidth`, `borderRadius`, `padding`, `fontScale`, hover/pressed colors and `shadow`. `ui.Row` / `ui.Column` provide cursor-based layout; `ui.Grid` calculates indexed grid cells; `ui.Flex` splits a rectangle into equal row/column cells with deterministic remainder distribution; `contentX/Y/Width/Height` calculate padded content bounds.

เรียก `ui.beginFrame(canvas)` **ครั้งเดียวต่อเฟรม หลัง `graphic.poll(canvas)`**. `button/navItem/tabs` ตรวจ mouse press edge; `checkbox/toggle/slider/dropdown/radioGroup` คืน state/value ใหม่ จึงควร assign กลับ. คีย์บอร์ดของ dropdown เป็น navigation เฉพาะ widget ไม่ใช่ระบบ focus ทั่วทั้งแอป. ดู API เต็มและข้อจำกัดที่ `docs/UI.md`; ตัวอย่าง `examples/ui_showcase.fac`, `examples/ui_interactive.fac`, `examples/ui_styles.fac` และ `examples/ui_advanced_controls.fac`.

`ui.textField(canvas,x,y,w,h,label,value,id,nextId,prevId,maxLength,theme)` และ `ui.textArea(...)` คืน string ใหม่ ต้อง assign กลับเข้า `dyn string`; ใช้ `nextId/prevId` ระบุ Tab order เอง และ `maxLength` นับ supported grapheme clusters (0 = cap 65,535). TextField เป็น single-line; TextArea เป็น multiline รองรับ Enter/newline, Up/Down preferred column และ vertical scrolling. ทั้งคู่รองรับ UTF-8 event, mouse/Shift selection, Ctrl+A/C/X/V/Z/Y และ Backspace/Delete. `ui.focusTextField` / `focusedTextField` ตั้งหรืออ่าน focus ID; `ui.canUndoText` / `canRedoText` ตรวจสถานะ history; `ui.undoText(value)` / `redoText(value)` คืนค่าที่กู้คืนเพื่อใช้กับปุ่ม toolbar ได้. History จำกัด 64 snapshots ต่อทิศทางสำหรับ focus session ปัจจุบัน และถูกล้างเมื่อเปลี่ยน focus หรือ blur. `string.graphemeLength/Slice` รองรับ combining/Thai marks/emoji ZWJ/flag pairs แบบ practical subset ไม่ใช่ UAX #29 เต็มรูปแบบ.
ขอบเขตปัจจุบัน: UI ยังวาดบน software canvas ไม่ใช่ native OS widgets. `font.create()` ใช้ bitmap font 3x5; V116 เพิ่ม TTF/OTF และ Thai/complex-script shaping ผ่าน optional Pango/Cairo/Fontconfig backend เมื่อ runtime libraries พร้อมใช้งาน. `typography.TextLayout.reflowWithFont()` ใช้ metrics ของ vector font ได้. อย่างไรก็ตาม full Unicode UAX #29 grapheme segmentation, retained component tree, accessibility tree, native controls และ blur/vibrancy ยังไม่มี; Windows ใช้ bitmap fallback ใน V116.

## sync (`import sync.fac`) — ชนิดที่แชร์ข้าม thread ได้ปลอดภัย
`obj sync.Atomic a = new sync.Atomic(0)` → `get() set(v) add(d) cas(expected, desired)` (int, atomic)
`obj sync.Channel c = new sync.Channel(capacity)` → `send(msg, timeoutMs)`→boolean · `recv(timeoutMs)`→`Option<string>` · `close()` · `done()` · `len()`
`obj sync.Cell c = new sync.Cell("init")` → `get()`→string · `set(v)`→boolean · `swap(v)`→ค่าเดิม · `cas(expected, desired)`→boolean (ทุกตัว atomic, lock อยู่ข้างใน)
(timeout ติดลบ = รอจนกว่าจะได้, 0 = ไม่รอ · ข้อความต้องไม่มีไบต์ NUL · capacity 1..1048576) — ดู `docs/SAFETY.md` หัวข้อ Threads


## V43 API contract migration

V43 does not silently rewrite legacy API signatures. Use `make api-contract-audit` to inventory
public declarations that still need explicit return/error/ownership/thread-safety documentation.
Follow `docs/API_OWNERSHIP_MIGRATION.md`; migrate resource-owning APIs first. The audit is
advisory until each legacy module has been reviewed against its implementation.


## V98 — expanded numerical, data analysis and machine learning APIs

All tensor handles are stored as row-major float64 matrices and are capped at 16,777,216 elements. Results from tensor-producing APIs are newly owned and must be released exactly once with `tensor.free`. Numeric APIs currently execute on CPU; no GPU hardware execution is implied.

### tensor — numerical arrays and matrix operations

`create(rows,cols)`, `zeros`, `ones`, `rows`, `cols`, `size`, `get`, `set`, `fill`, `clone`, `reshape` and `transpose` provide construction and access. `row(t,index)` and `column(t,index)` return copies with shapes `[1,cols]` and `[rows,1]`. `concatRows(a,b)` requires equal column counts; `concatCols(a,b)` requires equal row counts. `dot(a,b)` computes a flattened inner product when element counts match. `add`, `sub`, `hadamard`, `divide`, `addScalar`, `scale`, and `matmul` provide arithmetic. `abs`, `exp`, `log`, `sqrt` and `clip` are elementwise copies; `log` requires strictly positive values and `sqrt` non-negative values. `sumAxis(t,axis)` and `meanAxis(t,axis)` accept axis 0 (reduce rows, return `[1,cols]`) or axis 1 (reduce columns, return `[rows,1]`). Flattened reductions include `sum`, `mean`, `min`, `max`, `std`, `argmin` and `argmax`.

### data — numeric CSV and preprocessing

`parseCSV(text)` / `loadCSV(path)` read headerless rectangular numeric CSV; headers, missing cells, ragged rows and non-finite fields are rejected. `toCSV` / `saveCSV` export numeric data. `selectRows`, `selectColumns` and `dropColumn` return copies. `shuffleRows(t,seed)` mutates rows deterministically. `standardize` and `normalize` operate per column; constant columns become zero. `oneHot(labels,classCount)` expects labels shaped `[N,1]` containing integer class IDs from `0` to `classCount-1`. `trainTestSplit(data,trainRatio,seed)` shuffles row indices deterministically and returns an opaque split handle; extract owned copies with `splitTrain` and `splitTest`, then release the split using `data.freeSplit` and each tensor copy with `tensor.free`.

### stats and metrics

`stats.sum`, `mean`, `min`, `max`, `stddev`, `median`, `variance`, `quantile`, `covariance`, `correlation`, `describe`, `iqr`, `mad`, `skewness` and `kurtosis` operate on flattened values. Variance/covariance use population denominator N; kurtosis is excess kurtosis. Constant-valued data returns zero skewness and kurtosis. `metrics.mse`, `mae`, `rmse`, `r2`, `mape`, `maxError` and `medianAbsoluteError` evaluate regression. Binary classification metrics are `accuracy`, `precision`, `recall`, `specificity`, `balancedAccuracy`, `f1`, `logLoss` and `confusionMatrix`; threshold metrics use 0.5, while logLoss consumes probabilities and exact 0/1 targets. MAPE skips zero-target entries and fails when all targets are zero.

### ml — CPU estimators

`linearFit` and `logisticFit` train batch-gradient-descent models. `ridgeFit(X,y,learningRate,epochs,lambda)` adds L2 regularization to weights but not the intercept. `linearPredict` returns linear predictions; `logisticPredict` returns probabilities; `logisticClassify` returns 0/1 labels. `linearWeight` and `linearBias` inspect coefficients. `kmeans(data,k,epochs,seed)` trains a seeded Euclidean k-means model. `knnFit(X,y,k)` trains a numeric-label k-nearest-neighbor classifier; `knnPredict` uses majority voting and breaks ties by choosing the smallest numeric label. Release ridge/linear/logistic handles with `ml.freeModel`, k-means with `ml.freeKMeans`, and kNN with `ml.freeKNN`.

### nn and optim — neural-network primitives and optimizers

`nn.dense(X,W,b)` computes `X*W+b`, expecting X `[N,I]`, W `[I,O]`, and bias `[1,O]`. Activations include `relu`, `sigmoid`, `tanh`, `softmax`, `leakyRelu`, `elu`, `gelu` (tanh approximation) and `softplus`, plus seeded inverted `dropout`. Explicit backward functions cover ReLU, sigmoid, tanh, softmax, Leaky ReLU, ELU and Softplus; dense input/weight/bias gradients and loss gradients support manual backprop. There is no automatic differentiation engine or high-level model graph. `optim.sgdStep` mutates parameters. Adam, Momentum and RMSProp each have a create/step/free state lifecycle. `clipNorm` and `clipValue` return new clipped tensor copies; the originals are unchanged.

### math — portable scalar helpers added in V98

`isFinite(x)` checks for finite values; `degToRad(degrees)` and `radToDeg(radians)` convert angles; `smoothstep(edge0,edge1,x)` computes clamped cubic interpolation and requires `edge1 > edge0`; `wrap(x,min,max)` wraps into the half-open interval `[min,max)` and requires finite ordered bounds.

### usage example
```fac
import terminal.fac
import tensor.fac
import data.fac
import stats.fac
import metrics.fac
import ml.fac

public function void main() {
    ptr tensor samples = data.parseCSV("1,2\n2,4\n3,6")
    ptr tensor x = data.selectColumns(samples, 0, 1)
    ptr tensor y = data.selectColumns(samples, 1, 1)
    ptr ml model = ml.linearFit(x, y, 0.01, 1000)
    ptr tensor predicted = ml.linearPredict(model, x)
    terminal.out.println("Target mean: ", stats.mean(y))
    terminal.out.println("MSE: ", metrics.mse(y, predicted))
    ml.freeModel(model)
    tensor.free(predicted)
    tensor.free(x)
    tensor.free(y)
    tensor.free(samples)
}
```



## V99 — named numeric DataFrame and scalar automatic differentiation

### dataframe — numeric named-column tables

`dataframe.fromTensor(t,names)` copies a finite float64 Tensor and assigns unique, non-empty column names separated by `|` (for example `"age|height|score"`). `dataframe.fromCSV(csv,names)` reads numeric headerless CSV and applies the supplied names, or accepts a quoted header row that exactly matches those names (so `toCSV` output round-trips). The current schema is numeric-only: no string/null cells or type inference.

`rows` / `cols` return dimensions; `columnIndex` returns the zero-based index or `-1`; `get(frame,row,name)` reads a named cell; `column` returns an owned `[N,1]` Tensor. `select` keeps the names listed in the same `|` format; `drop` removes one column and cannot remove the last remaining column. `filter(frame,name,op,value)` returns a new frame where `op` is 0 `==`, 1 `!=`, 2 `<`, 3 `<=`, 4 `>`, or 5 `>=`. Empty filtered results are valid. `sort(frame,name,ascending)` returns a stable-sorted copy (`1` ascending, `0` descending); `head` / `tail` return row slices; `concatRows` requires identical column names and order. `mean`, `min`, `max`, and `stddev` operate on one named numeric column; standard deviation uses population denominator N. `toTensor` rejects an empty frame because Tensor requires positive dimensions; `toCSV` emits a quoted header and numeric rows. A DataFrame is limited to 16,777,216 stored float64 values; grouped aggregations return two-column frames and therefore allow at most 8,388,608 distinct keys. Runtime handle checks validate non-negative rows, bounded columns, overflow-safe element counts, and exact backing-storage length before data access. Group reductions use one accumulator per distinct key rather than retaining a second copy of every grouped value. DataFrame handles must be released with `dataframe.free`; Tensor copies with `tensor.free`.

### autograd — scalar reverse-mode automatic differentiation

`autograd.create()` creates an owned tape. `variable(tape,value)` appends a finite scalar leaf and returns an integer node ID local to that tape. Operations append nodes: `add`, `sub`, `mul`, `div`, `neg`, `exp`, `log`, `tanh`, `sigmoid`, `relu`, `softplus`, and `pow` (positive base, finite exponent). `value(tape,node)` reads the forward value. `backward(tape,output)` clears gradients, seeds the scalar output with 1 and propagates reverse-mode gradients; `backwardSeed` supplies a custom finite scalar seed. Read gradients using `grad(tape,node)` and clear them using `zeroGrad(tape)`. Node IDs are invalid after `autograd.free(tape)`. Tape mutation requires external synchronization.

This is scalar DAG autograd. It is not Tensor autograd, convolution/attention training, a high-level optimizer/model engine or GPU compute.


## V100 — tensor autodiff, extended numeric DataFrame and float64 compute dispatch

`autograd` now provides a tensor reverse-mode tape with matrix and elementwise operations, reductions, activations, owned gradient tensors and optimizer interop. `dataframe` adds column derivation/rename, quantiles and grouped aggregations. `gpu` retains typed float64 buffer access and transactional add/subtract/multiply/scale/matmul operations on the CPU. V170 removes native GPU/OpenCL device loading and dispatch; SIMD and scalar CPU paths remain. See the generated module pages under `docs/api/`.



## V141 — date/time, configuration, URL, IP and locale

`datetime.fac` wraps the existing `time` built-ins using Unix epoch **milliseconds**. `DateTime(milliseconds=0)` provides `setNow`, `toUnixMilliseconds`, `toUnixSeconds` (floors to the containing Unix second, including negative sub-second timestamps), local getters (`yearLocal`, `monthLocal`, `dayLocal`, `hourLocal`, `minuteLocal`, `secondLocal`, `weekdayLocal`), `toIsoUtc`, `formatLocal`, `formatUtc`, `setUnixMilliseconds`, and elapsed-duration additions (`addMilliseconds`, `addSeconds`, `addDays`). `datetime.nowMilliseconds`, `parseUtc`, `isLeapYear`, `daysInMonth` and `isValidDate` are module helpers. `addDays` means exactly 86,400,000 elapsed milliseconds; it is not a civil-day operation across daylight-saving transitions. Local getters depend on the process timezone.

`config.fac` provides `Config`: `parse`, `load`, `save`, `toText`, `has`, `getString`, `getInt`, `getBoolean`, `set`, `remove`, `clear`, `size` and `keys`. The supported file format is a small INI subset: full-line `#`/`;` comments, `[section]` headers and `key=value` lines. Duplicate keys use the last value. Inline comments, escaping, multiline values, dotted keys/sections and full TOML/JSON/YAML semantics are not implemented. `toText` normalizes section headers; key order is unspecified. Parse failures return `false` and leave entries parsed before the failing line in place.

`url.fac` defines `Url` with `parse`, `isSecure` and `toString`, plus `url.encodeComponent`, `decodeComponent` and `decodeQueryValue`. It accepts absolute hierarchical `scheme://authority` URLs, lowercases scheme/host, supports explicit ports and bracketed IPv6 literals, and rejects user-info credentials. It is not a complete RFC 3986 parser: relative references, opaque schemes, IDNA conversion, host validation beyond the current checks and full normalization are not provided. `decodeComponent` preserves `+`; `decodeQueryValue` follows `application/x-www-form-urlencoded` plus-to-space behavior.

`ip.fac` defines `IpAddress` with `parse`, `parseIPv4`, `parseIPv6`, `version`, `byteAt`, `isLoopbackV4`, `isLoopbackV6` and `toString`. IPv4/IPv6 values are stored as scalar byte fields. `toString` preserves the original accepted text and does not canonicalize it. A failed parse clears the address object. IPv6 zone IDs and IPv4-mapped/embedded IPv4 tails are currently rejected.

`locale.fac` defines `LocaleTools`: `isValidTag`, `language`, `region`, `decimalSeparator`, `groupSeparator`, `datePattern` and `firstWeekday`. It implements a simplified language-plus-subtags shape and a small deterministic convention table; it is not a complete BCP 47 validator or ICU/CLDR data set and does not change the process locale.

## V140 — binary, Unicode, encoding, compression and UUID

`bytes.fac` defines `ByteBuffer`, an owned growable sequence of integer byte values constrained to 0..255. It offers append/set/get/copy/clear/size and U16/U32 reads/writes in both endian orders. This intentionally uses integer bytes rather than a FAC string: `string` is UTF-8 text and must not be used as a general binary buffer.

`encoding.fac` converts between `list dyn int` byte data and printable text: `encoding.hexEncode/hexDecode` and `encoding.base64Encode/base64Decode`. Hex decoding requires even-length hexadecimal text. Base64 decoding requires canonical padded RFC 4648 input and rejects whitespace, non-alphabet characters and invalid padding bits. Decoded values remain integer bytes.

`unicode.fac` exposes `UnicodeTools`: `codePointLength`, `graphemeLength`, `codePointAt`, `sliceCodePoints`, `toCodePoints`, `fromCodePoints`, `graphemeAt`, `isAscii`, `isAsciiAlpha` and `isAsciiNumeric`. Code-point operations follow FAC's UTF-8 scalar access. Grapheme grouping is the Runtime's practical subset (including combining marks, Thai marks, emoji modifiers/ZWJ and flag pairs), not a complete Unicode UAX #29 implementation. Unicode normalization is not provided by this module.

`compress.fac` provides `compress.rleEncode` and `compress.rleDecode`. The wire format is repeated `[count,value]` byte pairs; counts range from 1 to 255 and decoding is capped at 16 MiB by default (configurable). This is lossless RLE, not a general-purpose compression format or ZIP/gzip/DEFLATE/zstd implementation.

`uuid.fac` provides `uuid.v4`, `uuid.isValid`, `uuid.version` and `uuid.hasRfcVariant`. Generation delegates to the existing Runtime `crypto.uuid()` provider; validation checks the canonical 8-4-4-4-12 hex text shape and RFC variant nibble.

## V139 core utility source libraries

The native collection declarations already cover `array`, `list`, `arraylist`, `linked`, `hashmap`, `hashset`, `tree`, `graph`, `stack`, `queue`, `heap`, `maxheap`, `trie` and `matrix`; do not import a duplicate container implementation. `collections.fac` provides `CollectionOps<T>` for list `indexOf`, `contains`, `count`, `copy`, `distinct` and `reversed`. `distinct` preserves first occurrence order and is O(n²); copy/reverse are O(n).

`iter.fac` provides `ListIterator<T>` and `RangeIterator`. This is explicit pull iteration (`hasNext` plus `next` returning `Option<T>`), because FAC does not yet have foreach/yield syntax. `RangeIterator(start,end,step=1)` yields the half-open integer range `[start,end)`; negative steps count downward and zero step throws AssertionFailed (4).

`algorithm.fac` provides `Algorithms<T>` with linearSearch, binarySearch, lowerBound, upperBound and isSorted. Binary search/bounds require ascending input; binarySearch returns a matching index, not necessarily the first duplicate. Ordered methods require T to support ordering. Native `sort(list)` and `reverse(list)` remain available.

`option.fac` adds `OptionTools<T>` helpers over the native enums in `result.fac`: `isSome`, `isNone`, `unwrapOr` and `unwrap`. `error.fac` adds `ResultTools<T,E>` (`isOk`, `isErr`, `unwrapOr`, `unwrap`) and `ErrorTools.codeName/describe`. Unwrapping an empty/error value throws AssertionFailed (4); it does not replace postfix `?` or `match`.

`io.fac` contains in-memory `TextReader` and `TextWriter`, not disk streams: the reader returns line content as `Option<string>` without the line terminator; the writer buffers chunks and joins once in `toString()`. Use `file.fac`/`fs.fac` for filesystem access and `terminal.fac` for console input/output.

`logging.fac` provides a synchronous stderr `Logger` with `LogLevel` filtering. `debug.fac` provides explicit labelled value/trace output to stderr (no stack inspection). `assert.fac` supplies condition and scalar equality assertions using Runtime error code 4. `testing.fac` provides a small in-process `TestSuite` accumulator/report; it does not replace the repository test harness. These stateful utility objects are not thread-safe unless externally synchronized.


## V152 — versioned binary serialization

`import serialize.fac`: create `obj serialize.BinaryWriter writer = new serialize.BinaryWriter()`, then call `begin(schemaId[, version])` before writing any fields. Version 1 emits `FACB`, U16 version, U16 reserved flags (zero), then a length-prefixed UTF-8 schema identifier. The writer supports `writeByte`, `writeBoolean`, `writeU16`, `writeU32`, `writeI32`, `writeI64`, `writeString`, `writeBytes`, `size` and `toBytes`.

`import deserialize.fac`: construct `obj deserialize.BinaryReader reader = new deserialize.BinaryReader(bytes)`, call `readHeader(expectedSchema)` and read the fields in exactly the same order using matching `readByte`, `readBoolean`, `readU16`, `readU32`, `readI32`, `readI64`, `readString` and `readBytes` methods. `readRawBytes(count)` reads an unprefixed bounded segment; `remaining`, `position`, `isAtEnd` and `requireEnd` expose/validate reader state.

All multi-byte integer fields are little-endian. `writeI32` checks the signed 32-bit range; `writeI64` and `readI64` preserve two's-complement signed 64-bit values. U32 is represented by a non-negative `long`. Each string/byte field has a U32 byte-length prefix. Whole streams are capped at 64 MiB; one string/byte field or raw read is capped at 16 MiB; schema identifiers are capped at 128 bytes. Invalid byte values, truncated input, invalid UTF-8, unknown flags/versions, bad magic, schema mismatch, noncanonical booleans and trailing bytes are rejected.

This binary API is deliberately explicit: it does not inspect or dump FAC object memory, and it does not automatically serialize structs, pointers, floats or object graphs. The writer and reader must use the same field order; change the schema identifier when an incompatible layout changes. It is not encryption, authentication, compression or a checksum. For human-readable interchange and automatic typed struct/map/list support, use the existing `json.encode` / `json.decode` APIs instead.

## V151 — SQLite database and SQL helpers

`import database.fac` provides `database.ConnectionOptions`: `setReadOnly`, `setCreateIfMissing` and `setTimeoutMs` configure a connection before it is opened.

`import sqlite.fac`: call `sqlite.available()` before opening a database when the system SQLite library is optional. `new sqlite.Database(path[, options])` owns a native connection. `execute(sql)` executes trusted DDL/DML or a SQL batch and returns `void`; query data through `prepare(sql)`. A `Statement` binds values using 1-based placeholders: `bindInt`, `bindFloat`, `bindText` and `bindNull`; call `step()` until it returns false (`SQLITE_DONE`), then read `columnCount`, `columnName`, `columnType`, `columnInt`, `columnFloat`, `columnText` or `columnBytes`. `reset`, `clearBindings`, `close` and `isOpen` manage statement state. `Database.changes()` reports the most recent DML row count; `lastInsertRowId()` reports SQLite's connection-local row ID. `begin`, `commit` and `rollback` execute real SQLite transaction commands; `begin` uses `BEGIN IMMEDIATE`. Both classes have destructors and idempotent explicit close.

`import sql.fac` provides `quoteIdentifier(name)`, `placeholder(index)`, `placeholders(count)` and `likeContains(value)`. Identifier quoting is only for table/column identifiers; values must be bound. `likeContains` escapes backslash, `%` and `_`; use the returned pattern with SQLite `LIKE ?1 ESCAPE '\'` (one backslash in the SQL literal; in FAC source, write `\\` inside a double-quoted string).

The Runtime loads SQLite dynamically (`sqlite3.dll` on Windows; `libsqlite3` on Linux/macOS); it is not linked at build time. The program still needs a compatible SQLite shared library installed when it runs. The driver is synchronous and SQLite-specific, not an ORM, pool or universal database layer. Text/path/SQL use NUL-terminated UTF-8; embedded NUL and BLOB binding are not supported by this API. SQL NULL returns an empty string from `columnText`, so inspect `columnType` first. Individual native calls are FULLMUTEX serialized, but one connection's logical transactions must not be interleaved between threads.
