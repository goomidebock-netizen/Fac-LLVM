# FAC Language Core V209 — aggregate callback lifetime contracts

## Scope

V209 extends the V208 function-value lifetime contract checker to callable fields declared directly on statically known `struct` and `class` types. The work spans the static aggregate field model, strict ownership/lifetime checking, function-value storage validation and call code generation. It does not add a new source-language syntax, Runtime wrapper, built-in API or native ABI.

## Supported field declarations

A function-valued field may declare named lifetimes and `where` constraints using the V208 function-value type syntax:

```fac
function lifetime<a> ptr<a> int identity(ptr<a> int value) {
    return value
}

struct CallbackBox {
    var function lifetime<a> ptr<a> int callback(ptr<a> int value)
}

function lifetime<outer> ptr<outer> int invoke(
    struct CallbackBox box,
    ptr<outer> int input
) {
    return box.callback(input)
}
```

The same contract can be invoked through nested statically typed value fields, such as `tree.leaf.callback(input)`, and through class fields. The checker retrieves the field's declared callback contract, substitutes the actual pointer origins at the call site, validates the declared outlives graph, and carries return provenance only from eligible callback arguments.

## Assignment and initialization compatibility

Function-valued aggregate fields are checked consistently across storage paths:

- Struct/class constructor initialization validates the target field's complete function signature.
- Assignment to an existing callback field validates the same signature before the managed function value is stored.
- Parameter and return types, named lifetime shape, and independent `noescape` / `readonly` requirements must satisfy the declared field type.

This closes a storage-path gap where aggregate construction or field reassignment could otherwise bypass the compatibility check used for ordinary function-value declarations. Lifetime parameter names remain alpha-equivalent when the indexed binding and `where` graph match.

## Code generation

A call such as `box.callback(value)` is emitted as a call through the stored function value using the existing closure/function-value ABI. The compiler distinguishes a function-valued field from an instance method by resolving the receiver's static aggregate type and checking that the named field has function type. Other member calls keep their existing method dispatch, including `super.method()`.

## Proof boundary and limitations

This is a bounded static contract implementation, not a general aggregate borrow checker:

- Contracts are resolved for direct and nested member paths when each receiver has a statically known aggregate type.
- Arbitrary computed or returned receivers and unresolved dynamic dispatch do not gain target-aware proof.
- A callback field's function-type `noescape` annotation is not treated as evidence that its concrete target body was verified not to retain a pointer. Indirect pointer-retention checks remain fail-closed.
- This does not add general safety for raw pointer fields, heap-stored references, aliasing through arbitrary aggregate graphs, or all possible nested object ownership patterns.
- `--strict-safe` and `--strict-ownership` remain distinct analyses; success under one is not a formal proof of whole-program memory safety.

No Runtime source, pointer representation, calling convention, ABI, built-in API or UI changed in V209.

## Validation

Linux x86-64, GCC C++17. Compiler rebuilt with `-O0`. The lifetime integration suite passed **37 checks**; complete compiler fixtures passed **129/129** at FAC `-O0` and **129/129** at FAC `-O2`; the four new positive aggregate-callback fixtures also compiled and ran separately at FAC `-O2` (**4/4**). Negative tests passed **132/132**, resource limits **21/21**, safe/strict-safe **437/437**, memory-safe profile **25/25**, ownership/local-borrow/effect tests passed (ownership 11, const-method ownership 8, local borrow 167, noescape 17, field-sensitive borrow 19, effect contracts 19, function effects 13), move/partial move passed **48/48**, parser 58/58, lexer 18/18, semantic ancestry 17/17, comptime 7/7, codegen guards passed and generic specialization 3/3. Runtime source was not changed; the aggregate runtime shell suite was attempted but exceeded the command time limit after numerous runtime groups had reported pass, so a complete Runtime-suite pass is not claimed. Compiler `-O2` binary, ASan/UBSan and cross-platform qualification are not claimed.
