# FAC V235 — branch-aware pointer-return provenance

V235 extends the bounded strict-ownership return-lifetime inference for source-defined functions returning `ptr T` to conditional and match result expressions. `ifv / eiv / elv` and `match` result arms may participate when every possible non-null value resolves to the same unique verified pointer parameter or an eligible local pointer alias. Match inference requires an explicit `default` arm so the bounded inference sees every result path. Mixed-source expressions do not receive a guessed single-source lifetime; caller-side provenance remains conservative and a store is rejected when any possible source is too short-lived.

Pointer provenance is collected from result expressions only. `ifv` predicates, the `match` scrutinee, pattern values and match guards select a result but are not themselves returned pointer origins. This avoids false lifetime failures when a `noescape` pointer is read only by a condition. A return that references a pointer payload binding from a `match` remains rejected: this release does not yet track pointer provenance through enum payload storage, and an untracked binding must not be treated as a verified empty/null origin set.

The proof remains deliberately bounded. It does not infer from calls, field loads, pointer arithmetic, casts, arbitrary computed expressions, match payload bindings, or match expressions without an explicit default. Extern/abstract declarations and function-value callback signatures are not inferred by this rule. Functions with explicit named lifetimes continue to validate every tracked origin against the declared return region.

No source syntax, first-class `ref T` return type, Runtime, ARC, Cycle Collector, public API, C ABI, Runtime ABI or `--memory-safe` accepted subset changes. This is not general reference-return support, heap escape analysis, whole-program escape analysis or a complete borrow checker.

## Regression coverage

- A pointer return through `ifv / eiv / elv` is accepted when all result arms resolve to one verified input/alias; a `noescape` pointer used only in a predicate does not contaminate the returned origin.
- Mixed-source conditional returns do not receive an inferred lifetime and remain rejected when a possible source is shorter-lived.
- A pointer return through `match` is accepted when all value arms resolve to the same verified source; a `noescape` pointer used only in a guard is not treated as a return origin.
- Mixed-source match returns remain rejected when a possible source is shorter-lived.
- Returning a pointer from an enum payload binding is rejected until its payload provenance is tracked explicitly.
- Existing direct parameter, local alias, nested alias, named-lifetime, aggregate-field, loop and closure lifetime fixtures remain in the regression suite.

## Validation

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler build): Compiler reports V235 for Core/Lib/API/Lang/Runtime/Stdlib; lifetime regression 121/121; ownership 261 checks (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect); secure profile 6/6; move/partial-move 48/48; `--memory-safe` 39/39; Tools 91 tests; parser 68 checks plus AST model 1/1; lexer 18/18; CTest 37/37. `make fmt-check` and `make standards-check` passed. API manifest and contract checks passed; 950 public source functions had the required documentation annotations; API audit covered 663 built-ins and 1,014 source declarations with 5 existing baseline findings and 0 new findings; compatibility against V128 reported 0 breaking changes and 132 warnings. `tools/check_versions.py` passed and `facc --version` reported V235 for every component. The broad legacy semantic suite, ASan/UBSan/TSan qualification, cross-platform testing and production qualification are not claimed.
