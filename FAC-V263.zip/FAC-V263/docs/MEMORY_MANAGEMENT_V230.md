# FAC Memory Management Direction — V230

V230 extends the bounded return-lifetime elision already used by strict ownership for functions with multiple pointer inputs. When exactly one input is eligible to be returned and all other pointer inputs have a body-verified `noescape` contract, a returned local pointer alias can now inherit the selected input lifetime under a narrow static proof.

## 1. Supported alias form

The eligible alias must be declared directly in the function's outer block, have pointer type, and initialize directly from the selected pointer parameter or an earlier eligible alias. The alias name must be unique throughout the function body and must never be assigned. Every non-null return must still directly name the selected parameter or one of these verified aliases; `null` returns remain permitted.

The proof deliberately rejects aliases that are declared in nested blocks, shadowed anywhere in the function, assigned on any path, or passed as an argument to a call. Passing a candidate pointer through a call could expose its storage through a mutable `ref` parameter; V230 does not attempt target-specific mutation analysis for alias inference, so the whole candidate source is disabled in that case. A source parameter that is assigned inside the function is likewise not eligible.

## 2. Fail-closed boundaries

The inference does not apply to multiple returnable pointer inputs, unverified/indirect calls, pointer arithmetic, casts, computed expressions, member/field loads, aggregate returns, nested-scope alias declarations, alias assignment, variable shadowing, call-exposed aliases, or unverified `noescape` bodies. Such functions must use an explicit named lifetime contract where the language supports it, or remain outside the inferred-return subset.

The existing one-pointer-input elision rule is unchanged. Extern/abstract declarations and function-value types are not inferred. `noescape` parameters cannot become return sources; their body contract continues to be checked by the existing verifier.

## 3. Implementation boundary

This is a compile-time source-analysis refinement in `FacBorrowChecker::inferredReturnLifetimeParamIndex`. It adds no syntax, no new runtime state, no ARC or Cycle Collector behavior, no public API, no C ABI change and no Runtime ABI change. It does not claim general aggregate escape analysis, general heap borrow analysis, whole-program pointer alias analysis or complete raw-pointer/FFI safety.

## 4. Regression coverage

V230 adds positive runtime tests for a direct top-level local pointer alias and a two-alias chain, where the selected pointer input is the only possible return source and all other pointer inputs are verified `noescape` parameters. Negative tests verify that inference is disabled when an alias is assigned, shadowed, the source parameter is assigned, or a candidate alias is passed to a call. A separate negative verifies that a `noescape` pointer cannot escape through a local alias.

## 5. Validation

Validated on Linux with Clang 17: Compiler built with C++17 at `-O0 -g0`; Runtime built at `-O2 -g0`. After bumping the canonical `VERSION.toml` from V229 to V230, the Compiler and Runtime were rebuilt and the targeted tests were rerun with the V230 binary. Results: lifetime 89 checks; ownership 261 checks (12 base ownership, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract and 13 function-effect); move/partial-move 48 checks; `--memory-safe` 39/39; Tools 91/91; parser 68 checks plus AST model 1/1; lexer 18 checks; focused codegen constant-fold and recursion-guard checks passed; formatter and standards checks passed. `make api-check` passed with 663 built-in entries, 1,014 source declarations, 950 fully annotated public source functions, 0 compatibility breaking changes and 132 compatibility warnings against V128; the 5 API findings were already present in the baseline (0 new). `tools/check_versions.py` and `facc --version` reported V230 for all components.

The broader legacy `tests/run_safe.sh` run reported 433 passes and 4 failures; the same four failures were reproduced with the unmodified V229 baseline, so they are not introduced by V230 but remain unresolved. This release does not claim that the entire legacy suite passes, nor does it claim complete Sanitizer, cross-platform or production qualification.
