# API contract migration plan (V43)

The V42 convention defines the target contract. V43 adds a source inventory so migration can
be evidence-driven instead of guessing ownership from names.

## Required per-function contract

1. **Inputs:** borrowed read-only, borrowed mutable, copied, or consumed.
2. **Outputs:** scalar/value, owned, borrowed view, shared/retained, or non-owning handle.
3. **Failure:** direct/infallible, `Option<T>`, `Result<T,E>`, or documented legacy behavior.
4. **Lifetime:** validity after mutation/destruction of source; release function if applicable.
5. **Concurrency:** thread-safe, externally synchronized, or not thread-safe.

## Migration order

1. Resource-owning modules: `file`, `net`, `graphic`, `audio`, `gpu`, `font`, `thread`.
2. Containers and strings: document whether getters copy, borrow, or return retained values.
3. Pure modules: `math`, `time`, `random`, `bit`, `regex`.
4. Compatibility aliases: identify canonical implementation and deprecation window.
5. Run `make api-audit api-contract-audit docs-api tools-check`.

Do not change a legacy return type or ownership behavior in a minor release. Add a `try...`
or explicitly named owned/borrowed API, deprecate the old name, and reserve semantic breaks
for a major release.
