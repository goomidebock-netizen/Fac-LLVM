# FAC V263

## V263 — verified noescape forwarding for pointer fields in value structs

The ownership checker now grants a bounded, body-verified summary to a
non-`ref` value-struct parameter only when each known pointer field is passed
exclusively as an exact argument to a uniquely declared, non-generic helper
parameter with a matching pointer type and a verified `noescape` contract.
Nested value-struct paths are supported. Whole-aggregate use, aliases,
returns/stores/captures, direct pointer-field use, ordinary retaining helpers,
overloads, generic helpers, unknown/cyclic layouts, pointer-bearing
containers/arrays and `ptr thread` remain outside this rule and fail closed.
The dedicated thread-handle join-only analysis from V261/V262 is unchanged.
The new positive nested-struct regression runs and returns `41`; the negative
retaining-helper regression is rejected. No syntax, Runtime, public API, ABI
or `--memory-safe` accepted-subset change.

Validation: Safe Profile 438/438; Ownership 12/12; const-method ownership
8/8; local borrow 167/167; noescape 20/20; field-sensitive borrow 25/25;
effect contract 19/19; function-effect 13/13; Move 20/20; Partial Move
28/28; Compile-time 57/57; Memory-Safe 39/39; Generic 3/3; Lexer 18/18;
Parser 68 + AST 1/1; Codegen passed. Runtime suite completed with exit code 0;
Tools 91/91; Negative 134/134; Limits 21/21. Semantic component tests passed
individually, including HIR, generic, scope/overload, declaration/body codegen
and LLVM IR checks; the combined Semantic runner timed out during its final
generated-function-body compilation, so no full uninterrupted Semantic-suite
pass is claimed. Standards (5 OS families, 6 architecture families),
Formatter, API manifest, strict API contract, compatibility and generated-doc
checks passed. API audit: 5 baseline findings, 0 new; compatibility against
V128: 0 breaking changes, 132 existing warnings; 114 generated docs current.
Full CMake/CTest, sanitizers, Windows/macOS build/run and production
qualification are not claimed. See [`MEMORY_MANAGEMENT_V263.md`](MEMORY_MANAGEMENT_V263.md)
and [`CODE_AUDIT_V263.md`](CODE_AUDIT_V263.md).


## V262 — verified join-only helpers for thread handles in value structs

The strict-ownership checker now recognizes a narrow, body-verified effect for
non-`ref` `ptr thread` parameters used only as the direct argument of
`thread.join`. It propagates that proof to value-struct parameters only when
all raw-pointer leaves are exact `ptr thread` fields and each field is unused
or passed only to `thread.join` / a uniquely declared, non-generic join-only
helper. This permits checked direct/nested helper paths and explicit
`move(aggregate)` transfers without treating arbitrary helpers as noescape.
Overloaded/generic helpers, unknown layouts, other raw-pointer fields,
aliases, aggregate escapes and extra parameter uses remain fail-closed. A new
negative regression confirms that an observer using `thread.isDone` is not
trusted as a join-only helper. `move(value)` retains its operand's static type
for call-boundary aggregate provenance checking; move and active-loan rules
remain unchanged. No syntax, Runtime, public API, ABI or `--memory-safe`
accepted-subset change. See [`MEMORY_MANAGEMENT_V262.md`](MEMORY_MANAGEMENT_V262.md)
and [`CODE_AUDIT_V262.md`](CODE_AUDIT_V262.md).

Validation: Safe Profile 438/438; Ownership 12/12; const-method ownership
8/8; local borrow 167/167; noescape 17/17; field-sensitive borrow 25/25;
effect contract 19/19; function-effect 13/13; secure profile 6/6; Move
20/20; Partial Move 28/28; Compile-time 57/57; Memory-Safe 39/39; Generic
3/3; Lexer 18/18; Parser 68 + AST 1/1; Codegen passed. Runtime runner
reported many individual PASS cases but did not complete within the time
limit. Semantic reported 17 ancestry checks before timeout; Tools did not
complete. These suites are not claimed as full passes. Full CMake/CTest,
sanitizers, Windows/macOS build/run and production qualification are not
claimed.


## V261 — owned thread-handle provenance through value-struct moves

The strict-ownership checker recognizes the owned handle returned by the exact
qualified call `thread.start` as an independently allocated origin. That
handle may be stored in local pointer-bearing value structs and transferred
through explicit nested `move(...)` operations. The exact `thread.join` call
consumes its first argument when its static type is `ptr thread`, matching the
API ownership contract that it joins and frees the handle. `move(value)` is
checked as an intrinsic transfer rather than as an ordinary escaping call;
source-expression checks and active-loan restrictions remain in effect.
Arbitrary incoming `ptr thread` values stay untracked and cannot be retained in
value-struct fields. This is a bounded resource-origin rule, not general heap
escape analysis, resource lifecycle verification, helper-summary inference,
or a complete borrow checker. No syntax, Runtime, public API, ABI or
`--memory-safe` accepted-subset change. See
[`docs/MEMORY_MANAGEMENT_V261.md`](MEMORY_MANAGEMENT_V261.md) and
[`docs/CODE_AUDIT_V261.md`](CODE_AUDIT_V261.md).

Validation: Lifetime 147 PASS; Ownership 12/12; const-method ownership 8/8;
local borrow 167/167; noescape 17/17; field-sensitive borrow 25/25; effect
contract 19/19; function-effect 13/13; Move 20/20; Partial Move 28/28;
Compile-time 57/57; Memory-Safe 39/39; Generic 3/3; Lexer 18/18; Parser 68
+ AST 1/1; Codegen passed. Safe Profile: 435 passed, 2 V76 helper-provenance
failures remain; V75 struct-move checks now pass. API checks: 5 baseline
findings, 0 new; 0 breaking changes and 132 warnings against V128; 114 API docs
current. Standards and Formatter passed. Runtime full-run exit, Semantic full
suite and Tools full suite are not confirmed; Semantic reported 17 ancestry
checks before timeout. Full CMake/CTest, sanitizers, Windows/macOS build/run
and production qualification are not claimed.


## V260 — pointer-field provenance through enum payloads

V260 closes a bounded strict-ownership gap in inferred (`auto`) returns: a
pointer-valued aggregate field read through an untracked pointer-capable enum
payload binding could previously escape. The checker now resolves known
aggregate member projections using field metadata and rejects pointer-valued
fields, including nested projections, while retaining scalar-field returns.
Unknown field layouts fail closed. This does not add general enum-payload
provenance, method/call result analysis, heap escape analysis, or a complete
borrow checker. No syntax, Runtime, ARC/GC, public API, ABI or
`--memory-safe` accepted-subset change. See
[`docs/MEMORY_MANAGEMENT_V260.md`](docs/MEMORY_MANAGEMENT_V260.md) and
[`docs/CODE_AUDIT_V260.md`](docs/CODE_AUDIT_V260.md).

Validation: Clang 17 C++17 Compiler/Runtime build passed; Lifetime 144 PASS;
Ownership passed (function effects 13/13); Move 20/20; Partial Move 28/28;
Memory-Safe 39/39; Compile-time 57/57; Generic 3/3; Lexer 18/18; Parser 68 +
AST 1/1; Codegen and Runtime regression passed; Legacy 132/132 at both `-O0`
and `-O2`; Negative 134/134; Limits 21/21; Tools 91/91; Formatter,
Standards, API manifest/audit/contract/compatibility and generated-doc checks
passed. API audit: 5 baseline findings, 0 new; compatibility against V128: 0
breaking changes, 132 warnings. Safe Profile: 433 passed, 4 failures; all four
reproduced with the V259 baseline. Semantic suite reported 17 ancestry checks
before timing out; full Semantic success is not claimed. Full CMake/CTest,
ASan/UBSan/TSan, cross-platform and production qualification are not claimed.


## V259 — pointer arithmetic in inferred enum-payload returns

V259 closes a strict-ownership gap where an `auto` function could return an
untracked raw pointer from an enum payload after pointer-preserving arithmetic,
such as `pointer + 0`. The checker now rejects pointer-valued `+`/`-`, assignment, compound
assignment (`+=`/`-=`), and prefix/postfix increment/decrement result forms
derived from such payload bindings. Scalar pointer difference
(`pointer - pointer`) and pointer comparisons remain non-pointer result forms.
The guard remains bounded; it does not implement general enum-payload
provenance or general expression/heap escape analysis. No syntax, Runtime,
ARC/GC, public API, ABI or `--memory-safe` accepted-subset change. See
[`docs/MEMORY_MANAGEMENT_V259.md`](docs/MEMORY_MANAGEMENT_V259.md) and
[`docs/CODE_AUDIT_V259.md`](docs/CODE_AUDIT_V259.md).

Validation: Lifetime 141 PASS; Ownership passed (function-effect 13/13);
Move 20/20; Partial Move 28/28; Memory-Safe 39/39; Generic 3/3; Codegen,
Lexer 18/18, Parser 68 + AST 1/1 and Runtime regression passed; Tools 91/91;
Negative 134/134; Limits 21/21; Formatter, Standards, API manifest, API audit,
strict API contract and generated-doc checks passed. API audit: 5 baseline
findings, 0 new; compatibility against V128: 0 breaking changes, 132 warnings.
Safe Profile: 433 passed, 4 known V258-baseline failures. Semantic suite
reported 17 ancestry checks before timing out; full Semantic success is not
claimed. Full CMake/CTest, ASan/UBSan/TSan, cross-platform and production
qualification are not claimed.



## V258 — nested match pattern-binding shadowing

V258 fixes a strict-ownership false positive in the `auto`-return enum payload
check. A nested match binding now shadows an inherited same-named binding
before the checker classifies its own payload type. Thus a known scalar inner
binding is not tainted by an outer pointer binding, while a pointer inner
binding remains fail-closed even when it shadows an outer scalar. Unknown,
generic and ambiguous payload layouts remain conservative. No syntax,
Runtime, ARC/GC, API, ABI or `--memory-safe` accepted-subset change. See
[`MEMORY_MANAGEMENT_V258.md`](MEMORY_MANAGEMENT_V258.md) and
[`CODE_AUDIT_V258.md`](CODE_AUDIT_V258.md).

Validation: Lifetime 130 PASS; Ownership 261; Secure Profile 6/6;
`--memory-safe` 39/39; Move/Partial Move 48; Compile-time 57/57; Lexer 18/18;
Parser 68 + AST 1/1; Codegen and Generic 3/3 passed; Semantic suite exited 0;
Runtime regression exited 0; Tools 91/91; formatter and Standards checks passed.
API audit: 5 findings, all in baseline; compatibility against V128: 0 breaking,
132 warnings. Legacy output matrix: 132/132 at both `-O0` and `-O2`; Negative
134/134; Limits 21/21. Safe profile: 433 passed, 4 failures, all reproduced
with the V257 baseline binary. Full CMake/CTest, sanitizers, cross-platform
and production qualification are not claimed.


## V257 — auto-return enum pointer payload fail-closed check

The strict-ownership return checker now recognizes a direct raw-pointer enum
payload returned through `match` or nested `ifv / eiv / elv` result expressions
from an `auto` function. V256 checked explicit `ptr` return types but missed
this inferred-return form because the parsed return TypeSpec still says
`auto` at ownership-check time. Enum payload pointer provenance remains
unsupported, so these returns now fail closed. Scalar payload returns and
pointer payloads used only in comparison/condition expressions remain
accepted. No Runtime, ARC/GC, public API, ABI or `--memory-safe` accepted-subset
change is intended. See [`MEMORY_MANAGEMENT_V257.md`](MEMORY_MANAGEMENT_V257.md)
and [`CODE_AUDIT_V257.md`](CODE_AUDIT_V257.md).

Validation: Clang 17 C++17 Compiler/Runtime build passed; Lifetime 128 PASS;
Ownership 261; Secure Profile 6/6; Move/Partial Move 48; Compile-time 57/57;
Generic 3/3; `--memory-safe` 39/39; Tools 91/91; Lexer 18; Parser 68 + AST
1/1; Codegen checks and Runtime regression passed. API audit: 5 findings, all
in baseline, 0 new; API compatibility against V128: 0 breaking and 132
warnings; 950 public source functions pass contract annotations. Standards,
formatter and version checks passed. Semantic suite did not complete within
the command time limit during a generic HIR regression compile; isolated
translation units compile. ASan/UBSan/TSan, full CMake/CTest, cross-platform
and production qualification are not claimed.


## V256 — nested match-payload pointer-return fail-closed check

The strict-ownership return checker now finds untracked enum payload bindings in nested result expressions, including `match` expressions inside `ifv / eiv / elv` result arms. Conditions, match scrutinees, patterns and guards remain excluded because they select a value rather than supply the returned pointer. Enum payload pointer provenance is still unsupported; these returns fail closed. No syntax, Runtime, ARC/GC, API, ABI or `--memory-safe` accepted subset change. See [`MEMORY_MANAGEMENT_V256.md`](MEMORY_MANAGEMENT_V256.md) and [`CODE_AUDIT_V256.md`](CODE_AUDIT_V256.md).

Validation: Clang 17 C++17 Compiler build; lifetime 123; ownership 261; secure profile 6/6; `--memory-safe` 39/39; move/partial move 20/20 and 28/28; compile-time 57/57; generic 3/3; parser 68 + AST 1/1; lexer 18; Codegen checks passed; API/standards checks passed. Semantic and Tools suites timed out after partial execution; CMake/CTest, sanitizers, cross-platform and production qualification are not claimed.

## V235 — branch-aware pointer-return lifetime validation

V235 extends bounded return-lifetime inference through `ifv / eiv / elv` and `match` result expressions when every possible non-null result resolves to one unique verified pointer parameter or eligible local alias. Only value arms contribute pointer origins; predicates, match scrutinees, pattern values and guards are selection logic, not return values. Mixed-source expressions do not receive guessed lifetime metadata, so call-site may-origins remain conservative. Match inference requires an explicit `default`. Returning a pointer from an enum payload binding is rejected because pointer payload provenance is not yet tracked and must not be treated as a verified empty origin set. This remains bounded `ptr T` analysis, not a first-class `ref T` return feature or general heap/whole-program escape analysis. Runtime, ARC/GC, API, ABI and `--memory-safe` acceptance are unchanged. See [`MEMORY_MANAGEMENT_V235.md`](MEMORY_MANAGEMENT_V235.md).

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler build): Compiler reports V235 for Core/Lib/API/Lang/Runtime/Stdlib; lifetime regression 121/121; ownership 261 checks (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect); secure profile 6/6; move/partial-move 48/48; `--memory-safe` 39/39; Tools 91 tests; parser 68 checks plus AST model 1/1; lexer 18/18; CTest 37/37. `make fmt-check` and `make standards-check` passed. API manifest and contract checks passed; 950 public source functions had the required documentation annotations; API audit covered 663 built-ins and 1,014 source declarations with 5 existing baseline findings and 0 new findings; compatibility against V128 reported 0 breaking changes and 132 warnings. `tools/check_versions.py` passed and `facc --version` reported V235 for every component. The broad legacy semantic suite, ASan/UBSan/TSan qualification, cross-platform testing and production qualification are not claimed.


## V234 — bounded nested-closure lifetime proof

V234 extends the V233 local direct-call-only closure proof to nested local closures. A nested closure may capture a verified pointer only when its function-valued binding is local, every use is an immediate direct call, and each enclosing closure independently satisfies the same proof. Closure copies, assignment, return, argument passing, shadowing, self-capture, nested named-function references and cyclic proof dependencies remain rejected. Existing provenance and outlives checks are unchanged. This is not general closure lifetime inference or heap escape analysis. No syntax, Runtime, ARC/GC, public API/ABI or `--memory-safe` acceptance changed. See [`MEMORY_MANAGEMENT_V234.md`](MEMORY_MANAGEMENT_V234.md).

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler/Runtime build): Compiler reports V234 for every component; Lifetime 116 checks; ownership 261 checks (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect); secure profile 6/6; move/partial-move 48 checks; `--memory-safe` 39/39; Tools 91 tests (6 skipped, no failures); parser 68 checks plus AST model 1/1; lexer 18 checks; codegen constant-fold and recursion-guard checks passed. Full CMake build completed and CTest passed 37/37, including lifetime integration, Runtime safety/cycle-collector/concurrency, frontend/runtime fuzz and package-install consumer tests. `make fmt-check`, standards, API manifest, API contract, API compatibility, generated docs and version checks passed. API audit covered 663 built-ins and 1,014 source declarations, with 5 existing baseline findings and 0 new findings; compatibility reported 0 breaking changes and 132 warnings against V128. The broad semantic suite was only partially run (17 ancestry checks passed before the overall command timed out); no full semantic-suite success is claimed. ASan/UBSan/TSan qualification, cross-platform testing and production qualification are not claimed.

## V233 — bounded local closure captures for verified pointer lifetimes

V233 permits a non-null pointer or pointer-bearing local value struct to be captured by a lambda only when all source origins are known and outlive the closure binding's lexical region, and the lambda directly initializes one local function-valued variable whose uses are exclusively direct calls in the owning function. Copies, assignment, return, argument passing, aggregate/container/global storage, nested-closure capture, shadowing, `noescape` sources, Unknown provenance and shorter-lived sources remain rejected. This is a bounded syntactic escape proof, not general closure lifetime inference or heap/whole-program escape analysis. The `--memory-safe` profile, Runtime, ARC/GC, public API and ABI are unchanged. See [`MEMORY_MANAGEMENT_V233.md`](MEMORY_MANAGEMENT_V233.md).



Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler build): Compiler reports V233 for every component; Lifetime 112 checks; ownership 261 checks; secure profile 6/6; move/partial-move 48 checks; `--memory-safe` 39/39; Tools 91 tests (6 skipped, no failures); parser 68 checks plus AST model 1/1; lexer 18 checks; focused codegen checks passed. Full CMake build completed and CTest passed 37/37, including Runtime safety/cycle-collector/concurrency regressions, fuzz regressions and package install consumer. `make fmt-check`, `make standards-check`, `make api-check` and version checks passed; API audit reported 0 breaking changes and 132 compatibility warnings against V128, with 5 existing baseline findings and 0 new findings. Sanitizer qualification, cross-platform testing and production qualification are not claimed.

## V232 — verified-null pointer locals in closure captures

V232 adds an exact Verified-Null state for standalone pointer locals. An entry in the flow-sensitive `pointerOrigins` map with an empty origin vector means the current value is proven null; an absent entry means Unknown. Direct null initialization/assignment and copies from another exact verified-null pointer/field establish the fact. An untracked pointer write invalidates it. Closure capture may use the exact Verified-Null state, but still rejects known non-null frame origins and missing/unknown provenance. Current flow facts supersede declaration-wide historical summaries so earlier pointer origins do not reappear after a null overwrite. Branch joins retain the fact only when every predecessor is known; a mixed null/unknown branch remains Unknown. This is a bounded closure-capture refinement, not general closure lifetime/escape analysis. No source syntax, Runtime, ARC, Cycle Collector, public API or ABI changes; `--memory-safe` acceptance is unchanged. See [`MEMORY_MANAGEMENT_V232.md`](MEMORY_MANAGEMENT_V232.md).

Validation on Linux x86-64 with Clang 17 C++17: pre-release Compiler built at `-O0 -g0` and Runtime at `-O0 -g0`; Lifetime suite passed 105 checks (98 existing plus 7 V232 checks); ownership passed 261 checks; secure profile 6/6; move/partial-move 48/48; `--memory-safe` 39/39; Tools 91/91; parser 68 checks plus AST model 1/1; lexer 18 checks; focused codegen checks passed; full Runtime regression completed successfully. The five positive V232 closure fixtures compiled and executed. `make fmt-check`, `make standards-check` and `make api-check` passed; API audit reported 5 findings, all in the existing baseline, with no new findings. These are Linux-host results; full legacy compiler suite, ASan/UBSan/TSan qualification, cross-platform and production qualification are not claimed.

## V231 — nested pointer-alias returns and fail-closed closure capture

V231 combines two bounded strict-ownership changes. First, return-lifetime inference now accepts simple pointer aliases declared in nested lexical blocks when each alias is initialized directly from the unique returnable parameter or an earlier alias visible in that block. Child blocks inherit parent aliases but do not export child declarations outward or into sibling scopes. Body-wide unique names, no reassignment, no call exposure, exactly one eligible return source and verified `noescape` on all other pointer inputs remain required. Second, closure capture fails closed for pointer locals/parameters with either frame-restricted or missing/unknown provenance. A captured value struct with pointer fields requires an exact provenance fact for every pointer-bearing field; Unknown is not treated as verified null. Pointer-free and explicitly verified-null aggregates remain capturable. Standalone pointer locals have no dedicated verified-null state yet and are conservatively rejected when captured if no origin is recorded. This is not general closure lifetime inference, declaration-identity resolution, heap/container escape analysis or whole-program pointer safety. No syntax, Runtime, ARC, Cycle Collector, public API or ABI changed; `--memory-safe` acceptance is unchanged. See [`MEMORY_MANAGEMENT_V231.md`](MEMORY_MANAGEMENT_V231.md).

Validation on Linux x86-64 with Clang 17 C++17: Compiler rebuilt with `-O0 -g0`; Runtime rebuilt with `-O2 -g0`; `facc --version` reports V231 for every component. `tests/lifetimes/run.sh`: 98 checks passed; ownership: 261 checks passed; `tests/ownership/secure_profile.sh`: 6/6; move/partial-move: 48 checks; `tests/memory_safe/run.sh`: 39/39; Tools: 91 tests, 6 skipped, no failures; parser: 68 checks plus AST model 1/1; lexer: 18 checks; codegen constant-fold and recursion-guard checks passed; formatter passed. `make api-check` passed: 663 built-in entries and 1,014 source declarations audited, 950 public source functions had required documentation annotations, 0 compatibility breakings and 132 warnings against V128; all 5 API findings were present in the baseline (0 new). `tools/check_versions.py` passed. Full semantic/legacy-suite, sanitizer, cross-platform and production qualification are not claimed.

## V230 — verified local pointer-alias return lifetime inference

V230 extends multi-pointer return-lifetime elision to a narrow set of top-level local pointer aliases. A function may have one eligible return source while all other pointer inputs are body-verified `noescape`; the selected source may be returned directly or through one or more top-level pointer locals initialized directly from the selected parameter/earlier alias. Alias names must be unique in the function body and may not be assigned. The source parameter may not be assigned, and any candidate alias/source passed to a call disables inference because this pass does not prove call-side pointer-storage mutation. Nested-scope aliases, shadowing, computed initializers, multiple candidate sources, pointer arithmetic/casts, field loads and unverified noescape remain fail-closed. The existing single-pointer elision behavior is unchanged. No syntax, Runtime, ARC, Cycle Collector, public API, C ABI or Runtime ABI changed.

Validation on this Linux host: Clang 17 C++17 Compiler build at `-O0 -g0` and Runtime build at `-O2 -g0`; after the V230 version bump, the rebuilt V230 compiler passed lifetime 89 checks, ownership 261 checks, move/partial-move 48 checks, `--memory-safe` 39/39, Tools 91/91, parser 68 checks plus AST model 1/1, lexer 18 checks, focused codegen constant-fold/recursion-guard checks, formatter, standards and `make api-check`. API audit covered 663 built-in entries and 1,014 source declarations; 950 public source functions had required annotations; compatibility reported 0 breaking changes and 132 warnings against V128, with 5 baseline findings and 0 new findings. Version check and `facc --version` reported V230 for every component. The broad legacy `tests/run_safe.sh` reported 433 passes and 4 failures; the same four failures reproduced on the unmodified V229 baseline, so they are not introduced by V230 but remain unresolved. Full legacy-suite success, complete Sanitizer coverage, cross-platform and Production Safety qualification are not claimed. See [`MEMORY_MANAGEMENT_V230.md`](MEMORY_MANAGEMENT_V230.md).

## V229 — loop-carried pointer provenance fixed point

V229 replaces blanket invalidation of changed loop-carried pointer facts with a bounded may-origin fixed-point analysis for local pointer variables and exact pointer-field paths in local value structs. The loop transfer follows execution order for `while`, `do-while` / `until`, C-style `for`, foreach and compact `ForPP`; C-style `for` now analyzes condition, body and step in that order. Each iteration joins loop entry and back-edge facts, unions possible origins, and retains an exact field fact only when every predecessor has a verified fact. Known-null is distinct from Unknown. Lexical lifetime regions are memoized by parent and AST node identity so repeated analysis uses stable IDs; duplicate lifetime constraints are suppressed. The solver is capped at 32 passes and invalidates changed visible facts if it cannot converge. Any loop containing `break` retains conservative one-pass invalidation because break exits are not yet distinct provenance predecessors; `continue` is not yet a separate edge. The pass changes no ARC, Cycle Collector, Runtime, public API, C ABI, Runtime ABI or `--memory-safe` acceptance.

Validation on this Linux host: Clang 17 C++17 Compiler build at `-O0` and Runtime build at `-O2`; lifetime regression passed 83 checks, including 9 V229 loop cases; ownership passed 261 checks (12 base + 8 const-method + 167 local-borrow + 17 noescape + 25 field-sensitive + 19 effect-contract + 13 function-effect); secure profile passed 6/6; move/partial-move passed 48 checks; `--memory-safe` passed 39/39; parser passed 68 checks plus AST model regression 1/1; lexer passed 18 checks; focused codegen constant-fold and recursion-guard checks passed. These test suites were rerun with the rebuilt V229 compiler at `build-v229-clang/facc` and its V229 Runtime archive. `facc --version` and `tools/check_versions.py` reported V229 for every component. `make api-check` passed: 663 built-in entries, 1,014 source declarations, 950 public functions with required documentation tags, 0 compatibility breaking changes, 132 compatibility warnings and 5 baseline findings (0 new findings). Version-bump unit tests passed 2/2. The complete Tools suite, full legacy suite, all sanitizers, cross-platform and Production Safety qualification are not claimed.

## V228 — aggregate lifetime propagation across control-flow joins

V228 propagates aggregate pointer-field provenance out of lexical blocks when the root declaration is the same outer binding, and joins origins across `if`, `switch` / `match`, and `try` / `catch` alternatives. Every predecessor must provide an exact field fact; origins are unioned, so a return is accepted only when every possible pointer source satisfies the return lifetime. Pointer-local origins are propagated by declaration identity as well. Branches without `else` / `default` include the incoming state. Known-null stays distinct from unknown. Since V228 does not compute loop fixed points, changed visible aggregate/pointer facts are invalidated after a loop to prevent stale pre-loop provenance. This remains local and fail-closed; general heap aggregate contracts, closure/global/container escapes, loop fixed-point analysis and whole-program escape proof remain unsupported. ARC, Cycle Collector, Runtime, API and ABI are unchanged. See [`MEMORY_MANAGEMENT_V228.md`](MEMORY_MANAGEMENT_V228.md).

Validation on this Linux host: GCC C++17 Compiler build at `-O0 -g0`; lifetime suite passed 74 checks (9 new V228 cases); ownership passed 261 checks (12 base + 8 const-method + 167 local-borrow + 17 noescape + 25 field-sensitive + 19 effect-contract + 13 function-effect); move/partial-move passed 48 checks; `--memory-safe` passed 39/39; secure-profile passed 6/6; lexer passed 18 checks; parser passed 68 checks plus AST model regression 1/1; focused codegen constant-fold and recursion-guard checks passed. `make api-check` passed standards, manifest, audit, contract and generated-doc checks: 663 built-in entries, 1,014 source declarations, 950 public source functions fully annotated, 0 compatibility breaking changes and 132 warnings against V128. Version-bump unit tests passed 2/2; `tools/test_tools.py` full suite exceeded the local command time limit and is not claimed. Runtime source, ARC/GC, public API and ABI are unchanged; a separate Runtime rebuild was not completed within the available command window. Full legacy-suite, sanitizers, cross-platform and production qualification are not claimed.

## V227 — validated nested aggregate borrow graph

V227 validates each nested local reborrow edge before installing its child alias. Parent and child must resolve to the same original storage identity; an exact parent projection must contain the child projection; the parent loan region must outlive the child; and the existing parent chain must be present and acyclic. This formalizes the local nested-borrow graph while preserving conservative overlap for inexact child paths. Regression coverage includes three-level nested structs, simultaneous mutable borrows of disjoint leaf fields, same-leaf conflict rejection, parent suspension while a grandchild is live, and NLL retention of ancestor aliases. It does not introduce general heap-stored references or change ARC, Cycle Collector, Runtime, API or ABI behavior. See [`MEMORY_MANAGEMENT_V227.md`](MEMORY_MANAGEMENT_V227.md).

Validation on this Linux host: GCC C++17 Compiler/Runtime build via Makefile; expanded field-sensitive borrow suite passed 25 checks; full ownership script passed 261 checks (12 + 8 + 167 + 17 + 25 + 19 + 13); lifetime suite passed 65 checks; move/partial-move passed 48 checks; `--memory-safe` passed 39/39; parser passed 68 checks plus AST model regression; lexer passed 18 checks; focused codegen checks passed; secure-profile passed 6/6. `make api-check` passed standards, manifest, audit/contract and generated-doc checks; compatibility audit against V128 reported 0 breaking changes and 132 warnings. version-bump unit tests passed 2/2. `tests/tools/test_tools.py` exceeded the local command time limit during execution, so its full 91-test result is not claimed for V227. Full legacy-suite, sanitizer and cross-platform qualification are not claimed.

## V226 — field-sensitive aggregate pointer provenance

V226 replaces the local value-struct root-level pointer-origin union with exact field-path provenance. Constructor arguments are mapped using AST declaration-order field metadata; nested value-struct fields and local copies preserve the source paths. Pointer-field overwrite kills the prior path fact before installing the new origin, and `null` overwrite records a known-null fact. Replacing a nested or whole aggregate removes the prior subtree before rebuilding it. Missing facts are not treated as null: pointer-field reads and pointer-bearing aggregate copy/pass/return operations without complete verified field facts are rejected. The release remains limited to local value structs and does not change ARC, Cycle Collector, Runtime, public API or ABI behavior. See [`MEMORY_MANAGEMENT_V226.md`](MEMORY_MANAGEMENT_V226.md).

Validation on this Linux host: GCC C++17 Compiler/Runtime build at `-O0 -g0`; lifetime suite passed 65 checks; ownership suites passed 255 checks; move/partial-move suites passed 48 checks; `--memory-safe` passed 39/39; tools passed 91/91; parser passed 68 checks plus AST model regression; lexer passed 18 checks; focused codegen checks passed. The semantic suite was started but exceeded the available command time during the ancestry group; a complete semantic/full legacy-suite pass is not claimed. Sanitizer, cross-platform and full runtime qualification are not claimed.

## V225 — pointer provenance in local value-struct fields

V225 extends `--strict-ownership` / `--secure` so a local value `struct` may store a tracked pointer in a direct or nested by-value pointer field when the pointer origin outlives the struct's lexical storage. It covers constructor initialization, direct field assignment, local value-struct copying, reads/dereferences, and verified named-lifetime inputs. The analysis records a conservative union of pointer origins per aggregate root; scalar member reads do not inherit pointer provenance. This may over-approximate sibling pointer fields and is not a field-sensitive aggregate borrow graph.

Untracked non-null pointers, `noescape` retention, shorter-lived owners, aggregate returns, unverified retaining calls, closure capture, `class` / `obj` fields, weak/managed-object boundaries, globals, containers, array/index paths and alias-based stores remain rejected. `--memory-safe` still excludes raw pointer types and `addr`; this release does not change its accepted subset. No Runtime, ARC, Cycle Collector, API or ABI change. See [`MEMORY_MANAGEMENT_V225.md`](MEMORY_MANAGEMENT_V225.md).

Validation on this Linux host: GCC C++17 build with `-O0 -g0`; lifetime suite passed 55 checks; ownership suites passed 255 checks (12 + 8 + 167 + 17 + 19 + 19 + 13); `--memory-safe` passed 39/39; move and partial-move suites passed 48 checks (20 + 28); tools suite ran 91 tests (6 skipped by suite conditions); lexer passed 18 checks; parser passed 68 checks plus AST model regression; codegen constant-fold and recursion-guard checks passed. `api-check` passed standards, manifest freshness, API audit/contract checks, and generated-doc freshness; compatibility audit against V128 reported 0 breaking changes and 132 warnings. Sanitizer runs, cross-platform builds and the complete legacy compiler/runtime suite are not claimed.


## V224 — body-proven multi-pointer return lifetime elision

V224 extends implicit pointer return-lifetime inference to a deliberately narrow multi-input case. One non-`noescape` pointer input must be the sole return source, every other pointer input must have a body-verified `noescape` contract, and all explicit non-null returns must directly name that selected input. The compiler checks the function body against a synthetic lifetime for the selected source and propagates only that argument's provenance to direct callers. Multiple possible sources and computed/aliased return expressions remain rejected or conservative. No FAC syntax, Runtime, public API or ABI changed. See [`MEMORY_MANAGEMENT_V224.md`](MEMORY_MANAGEMENT_V224.md).

Validation on this Linux host: GCC C++17 compiler build at `-O0 -g0` succeeded; `tests/lifetimes/run.sh` passed 46 checks; `tests/memory_safe/run.sh` passed 39/39 (unchanged profile); `tools/check_versions.py` passed for V224; the 91-test `tests/tools` unit/integration suite passed, including generated API-doc freshness and version-bump consistency. The ownership suites passed 255 checks in total (12 + 8 + 167 + 17 + 19 + 19 + 13). Full legacy-suite, sanitizer and cross-platform qualification are not claimed.

## V223 — nested value-field borrowing through managed objects

V223 fixes `canonicalAggregateType()` so field metadata lookup recognizes the `obj ` root type used by tracked strong managed handles. This allows the local loan checker to retain exact nested value-field projections beneath a strong object root: disjoint fields such as `actor.stats.health` and `actor.stats.mana` no longer collapse to one unknown whole-object path. Overlapping field borrows and owner writes remain rejected.

The checker deliberately does not follow a field whose type is another `obj` reference. That child is a separately shareable heap identity and can be aliased through another strong handle; treating it as a nested projection from the parent could miss cross-root aliases. Borrowing through `weak obj` is also rejected because the weak handle alone does not prove referent liveness. The release adds positive runtime tests and negative overlap/boundary regression cases. No syntax, API, Runtime source, C ABI or Runtime ABI changed.

Validation: GCC C++17 compiler and Runtime built at `-O0`; memory-safe profile passed 39/39; lifetime suite passed; ownership suite passed all configured groups. The full legacy compiler/runtime suite, sanitizers and cross-platform qualification were not completed, and no complete memory-safety proof is claimed. See [`MEMORY_MANAGEMENT_V223.md`](MEMORY_MANAGEMENT_V223.md).

## V222 — bounded pointer lifetime elision and managed heap-field borrow coverage

V222 adds a narrow lifetime-elision rule to `FacBorrowChecker`/`FacLocalBorrowChecker`. A function receives an implicit return lifetime only when it is a source-defined, non-extern, non-abstract function with a `ptr T` return, no named lifetime parameters, and exactly one non-`noescape`, non-defaulted, non-variadic pointer parameter. The compiler creates a synthetic abstract region for that parameter, seeds its pointer provenance, checks the function body against that region, and carries the inferred lifetime contract into direct call-site validation. This accepts a verified one-input pointer identity/wrapper function without requiring explicit lifetime spelling.

The inference is deliberately withheld from multi-pointer functions, `noescape` parameters, extern/abstract declarations and function-value/callback type shapes. Local stack addresses returned from such functions and pointers whose source region is shorter than the destination remain rejected. Existing explicit named-lifetime contracts are unchanged. This is bounded direct-call lifetime elision, not a general lifetime solver or a claim of Rust-equivalent pointer safety.

The memory-safe suite adds a managed heap-object field borrow fixture. It demonstrates that a local `ref` alias can borrow a metadata-resolved field through a tracked local `obj` handle, writes through the alias mutate the same field, and overlapping owner mutation is rejected. Aggregate/object fields and containers still cannot store local `ref` bindings; arbitrary heap reference graphs and cross-object lifetime transfer remain unsupported.

Validation on this Linux host: GCC C++17 compiler rebuilt with `-O0`; `tests/lifetimes/run.sh` passed all 42 checks; `tests/ownership/run.sh` passed 254 checks across its ownership, const-method, local-borrow, noescape, field-sensitive, effect and function-effect suites; `tests/memory_safe/run.sh` passed 34 checks; `tools/check_versions.py` passed for V222. The broad `tests/run.sh -O0` run exceeded the local command time budget after test `t68`; no complete pass is claimed for that full suite. The default `-O1` compiler build also exceeded the local command time budget, so the tested compiler build used `-O0`. No Runtime source or public API/ABI was changed in V222.

See [`MEMORY_MANAGEMENT_V222.md`](MEMORY_MANAGEMENT_V222.md), [`MEMORY_MODEL.md`](MEMORY_MODEL.md), and the new `v222_*` lifetime fixtures.

## V221 — Ownership-first checked borrows

V221 expands the fail-closed `--memory-safe` source subset to permit `ref` parameters and function-local `ref` / `ref const` bindings when they pass the existing strict ownership and local-loan analyses. Borrow bindings remain forbidden in module globals and aggregate fields because those storage lifetimes are not modeled by the function-local loan checker. Raw/opaque pointers, manual heap, pointer primitives, FFI/extern/export, unsafe code, native link inputs and native-handle built-in modules remain excluded. This does not claim a complete region solver, Rust-equivalent safety or whole-program data-race freedom.

The release also introduces `tools/bump_version.py` and `make bump-version`. `VERSION.toml` remains the single release source of truth; the command advances all component versions by exactly one, updates the compiler version header and current release docs/metadata, regenerates the API manifest/reference, and verifies consistency. Historical milestone references are deliberately retained.

Validation on Linux x86-64 with GCC 14.2 / C++17: compiler and Runtime built at `-O0 -g0`; `tests/memory_safe/run.sh` passed 31/31; `tests/ownership/run.sh` passed all groups (11 + 8 + 167 + 17 + 19 + 19 + 13 checks); `tests/lifetimes/run.sh` passed all configured cases; the release manifest/header/API-doc consistency check passed. Cross-platform qualification and sanitizer coverage for these changes are not claimed.

See [`MEMORY_MANAGEMENT_V221.md`](MEMORY_MANAGEMENT_V221.md), [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md), and [`OWNERSHIP.md`](OWNERSHIP.md).

## V220 — generated function body Codegen integration

V220 now provides the internal C++ `fac_hir::TypedFunctionBodyBuilder` for a bounded body on an already registered generated non-generic free function. A body may reference plain scalar value parameters, declare immutable or mutable scalar locals initialized by exact-TypeId generated expressions, assign only to mutable locals with exact TypeIds, build nested `if/else` regions with builtin-bool conditions, use supported typed literals/unary/binary expressions, call resolved non-generic same-module functions with exact signatures, and finish with exactly one explicit value or void return. Locals are declared before statements; every `if` requires both branches; branches cannot return independently. TypeIds, bindings, mutability, statement nesting/count, call targets/signatures and return type are checked by the builder and `SemanticModel::validate()`.

The Codegen bridge structurally projects the typed expressions and generated statement tree into temporary backend AST nodes and emits normal internal module-qualified LLVM function definitions. A generated function with no body remains an external C-ABI prototype with a deterministic `facgen_...` symbol. The original parser-owned source Program is not mutated. Mutable scalar locals, exact-TypeId assignments and nested bool-conditioned `if/else` are supported; loops, branch-local declarations/returns, multiple return paths, aggregate/pointer values, generic functions/calls, classes/methods, cross-module calls, FAC syntax/`consteval` builder access and full post-generation HIR re-analysis remain unsupported. See [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md) and [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md).

## V220 — generated declaration Codegen integration

V220 connects the compiler-internal C++ `fac_hir::TypedDeclarationBuilder` and `TypedFunctionBodyBuilder` to a bounded Codegen projection. `Gen::generate` accepts an optional `SemanticModel`, validates it, and projects eligible `DeclarationOrigin::Generated` declarations into short-lived synthetic `Program` objects. Source parser Programs and their AST nodes remain unchanged. Generated non-generic structs are lowered through the normal LLVM record layout/helper path. A body-less generated free function becomes a deterministic external C-ABI prototype; a generated function with an eligible scalar body becomes an internal LLVM function definition, with mutable-local stores and nested if/else branches lowered through the normal LLVM basic-block path. `Gen::generatedFunctionSymbols` continues to track external prototype symbols.

The generated struct subset currently rejects static/protected/fixed-array fields and unsupported TypeIds/layouts. Generated free functions reject `main`, protected visibility, reference/readonly/noescape/variadic/default parameters and signatures outside the supported backend contracts. Body-less functions use external C-ABI prototypes; generated function bodies are supported through the bounded scalar/control-flow subset described in `GENERATED_FUNCTION_BODY_V220.md`. Generated classes, interfaces, enums, globals, methods, generic/nested declarations, general imported-type resolution and post-generation HIR re-analysis remain unsupported. Codegen resolves call sites against its registered module/name/overload table after generated prototypes are registered. The bridge copies module import metadata into temporary backend Programs and emits each module's functions once to avoid duplicate source-function emission. See [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md) and [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md).

The builder still consumes pre-resolved TypeIds, assigns append-order SymbolIds, marks records with `DeclarationOrigin::Generated`, and registers them in the model declaration vector, owning module and qualified-name index. It validates identifiers, duplicate fields/parameters/declarations, TypeId validity, void-field/parameter rejection, parameter flags and same-module named-type references; `SemanticModel::validate()` runs after each commit with registration rollback if validation fails. TypeArena TypeIds are monotonic and are not recycled.

Validation for this source snapshot: compiler-only and runtime-only builds passed with GCC C++17; FAC V220 version check passed; `tests/comptime/run.sh` passed 57/57; parser regression passed 68 checks; `tests/codegen/run.sh` passed; legacy compiler/runtime suite passed 132/132 at both FAC `-O0` and `-O2`; targeted HIR/declaration tests (`hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir`, `typed_decl_builder`, `generated_declaration_codegen`) passed individually at GCC C++17 `-O0`; the generated declaration fixture's LLVM IR compiled with Clang; ancestry checks passed 17/17. The full `tests/semantic/run.sh` wrapper exceeded the local 180-second command limit after the ancestry check, so the wrapper is not claimed as passing. These are Linux-host results, not cross-platform qualification.

### Generated function-body validation snapshot

For this update, `tests/semantic/generated_function_body.cpp` compiled and ran with GCC C++17 `-O0`; Clang successfully compiled its emitted LLVM IR. Six existing targeted HIR fixtures (`hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir` and `typed_decl_builder`) passed individually. The full semantic wrapper exceeded the local command time budget after the ancestry check, and the full compiler-only Make build exceeded its command time limit. No full semantic-wrapper or complete compiler-driver build pass is claimed for this update. The new fixture is wired into `tests/semantic/run.sh`.

## V220 — typed constants and structural field queries

V220 provides `typeOf<T>()`, `sizeof<T>()` and `alignof<T>()` as compiler intrinsics. `typeOf<T>()` returns the built-in `enum Type` category; `sizeof<T>()` and `alignof<T>()` return integer constants from the active compiler layout. `typeOf` follows the existing `typeof(value)` convention for arrays/lists by classifying the element type; unclassified kinds produce `Type.None`. The layout queries reuse the compiler's record, enum, array and object-handle layout rules.

This milestone adds bounded structural reflection over resolved struct/class records: `fieldCount<T>()`, `fieldName<T, I>()`, `fieldType<T, I>()` and `fieldOffset<T, I>()`. `T` must be a resolved `struct` or class-object type (`obj`). The index `I` is a nonnegative compile-time integer into the public, non-static instance-field sequence. Private/protected and static fields are omitted from enumeration. Inherited public instance fields of a class are included. `fieldType` returns the existing `Type` category (array/list fields are classified by element type); `fieldName` returns a static string literal; `fieldOffset` returns the field's byte offset in the compiler's active record layout, which accounts for preceding non-public fields and alignment. These are metadata queries, not a security boundary.

The numeric queries (`fieldCount`, `fieldType`, `fieldOffset`) can participate in `static_assert`, supported scalar `consteval` bodies and const generic expressions. `fieldName` is materialized as a static string expression and is not accepted by the scalar integer/bool constant evaluator. The queries reject runtime arguments, unknown/non-constant/out-of-range indices, non-struct/class targets and unresolved layouts. Generic specialized records, interfaces, enums, mutation, source-level AST values and declaration generation are not supported by this reflection subset. Unsized arrays have no fixed `sizeof`; `sizeof`/`alignof` reject `void`, inferred/auto, null, tuple and function types.

V220 also materializes an immutable typed-expression AST projection after HIR type, scope and overload refinement. It admits only supported expressions with known types and fully represented typed children (literals, local identifiers, unary/postfix/binary operators, resolved/builtin-contract calls, object construction and tuples). Nodes retain a TypeId, source expression/location, spelling, side-effect bit and immutable child references. Unsupported or unresolved forms are omitted. This is compiler-internal semantic data, not a FAC source-level AST construction API and is not consumed by code generation. V220 additionally provides the internal C++ `fac_hir::TypedAstFactory` for validated immutable generated expression nodes and `fac_hir::TypedDeclarationBuilder` for non-generic generated struct/free-function records in an existing semantic model. The declaration builder consumes already-resolved TypeIds, registers generated HIR declarations/module indexes and revalidates the model; the bounded Codegen bridge now lowers eligible generated structs, external free-function prototypes and generated scalar bodies with mutable locals, assignments and nested `if/else` without modifying parser AST ownership. See [`TYPED_AST_BUILDER_V220.md`](TYPED_AST_BUILDER_V220.md), [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md), [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md) and [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md).

Validation for this source snapshot: compiler-only and runtime-only builds with GCC C++17 `-O0 -g0`; FAC V220 version check passed; compile-time suite 57/57; parser regression 68 checks passed; runtime/compiler case suite 132/132 at both FAC `-O0` and `-O2`; six targeted semantic executables (`ancestry_fast_path`, `hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir`) passed individually with GCC C++17 `-O0`. The typed-expression HIR fixture covers generated factory nodes and type-mismatch/foreign-child rejection; the new typed-declaration fixture covers struct/function registration, generated TypeId reuse, overload uniqueness and validation failures. The full semantic wrapper exceeded the local command time budget and was not run to completion, so the targeted test results are reported separately. These are Linux host results, not cross-platform qualification.

See [`TYPED_CONSTANT_VALUES_V220.md`](TYPED_CONSTANT_VALUES_V220.md), [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md), [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md), [`tests/comptime/typed_constant_values.fac`](../tests/comptime/typed_constant_values.fac), [`tests/comptime/structural_reflection.fac`](../tests/comptime/structural_reflection.fac), and [`tests/comptime/run.sh`](../tests/comptime/run.sh).

## V220 — immutable typed-expression AST projection

The semantic pipeline now builds `SemanticModel::typedAst` after the final expression type/call refinement pass. `fac_hir::TypedAstBuilder` creates immutable `TypedAstNode` objects with a resolved `TypeId`, source `ExprId` and location, spelling, side-effect metadata and immutable child references. The first supported set is scalar literals, local identifiers with resolved bindings, unary/postfix/binary operations, resolved or builtin-contract calls, object construction and tuples. The tree is stored child-before-parent; `TypedAstModel::validate` verifies TypeIds, unique source mappings, node/child identity and ordering, operator arity and roots.

Unresolved/dependent expressions, unresolved calls, and syntax kinds not yet modeled are omitted rather than assigned guessed types. Codegen still consumes the original source AST. There is no FAC-level AST value, AST mutation API, declaration generation or macro expansion in this milestone; the separate field-query intrinsics provide only the bounded public-field metadata described above.

Validation for this source snapshot: compiler-only and runtime-only builds with GCC C++17 `-O0 -g0`; FAC V220 version check passed; `tests/comptime/run.sh` passed 57/57; parser regression passed 68 checks; legacy compiler/runtime cases passed 132/132 at both FAC `-O0` and `-O2`; six targeted semantic executables (`ancestry_fast_path`, `hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir`) passed with GCC C++17 `-O0`. The full semantic wrapper was not run to completion, so the targeted results are reported separately. Structural-reflection fixtures verify field visibility, inheritance, static-field exclusion, field categories, layout offsets, consteval/static_assert integration and rejection diagnostics. These are Linux host results, not cross-platform qualification.

See [`TYPED_AST_BUILDER_V220.md`](TYPED_AST_BUILDER_V220.md), [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md) and [`tests/semantic/typed_expr_hir.cpp`](../tests/semantic/typed_expr_hir.cpp).

## V220 — internal typed AST factory

`fac_hir::TypedAstFactory` appends immutable generated expression nodes to a validated `SemanticModel`. The supported first set includes integer/floating/character/string/boolean/null literals, supported unary and binary expressions, tuples and exact calls to pre-resolved non-generic free functions. It checks TypeIds, literal representability, operator/type contracts, same-model child ownership, tuple component descriptors and resolved call signatures. Generated nodes have `TypedAstOrigin::Generated`, no source `ExprId`, and a caller-supplied location; the validator distinguishes them from source-projected nodes and revalidates generated call targets. Calls must already have passed name, overload, import and access resolution. The factory does not implement those checks itself.

The generated tree is still a semantic artifact only: it is not exposed to FAC or `consteval`, does not mutate source AST, does not create declarations and is not consumed by code generation. Assignment/control-flow/match/member/index nodes, generic/method calls, implicit conversions and source-level builders remain unsupported. See [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md).

## V220 — bounded `consteval` for scalar free functions

V220 adds an explicitly marked `consteval function` subset that executes only during compile-time evaluation. The interpreter supports scalar integer/bool/char/unichar/enum parameters and returns, local initialized scalar variables, lexical blocks, `if`/`else`, `return`, supported integer expressions, local assignment/compound assignment/increment, nested consteval calls and recursion. It can read eligible module-level scalar `const` values and enum members. Public consteval free functions may be called from imported user modules through a qualified path or module alias, subject to import selection. Calls require compile-time-evaluable arguments; the declarations are not emitted as runtime functions.

The evaluator is bounded to depth 64 and 100,000 counted steps per top-level constant evaluation. It rejects runtime-dependent arguments, methods, generic/overloaded/unsafe/exported functions, non-scalar signatures, loops, aggregate mutation, I/O, runtime calls, FFI and unsupported expressions/statements. It is not general compile-time execution, typed AST generation, reflection or a macro system.

Validation for this source snapshot: compiler-only build with GCC C++17 `-O0 -g0`; FAC V220 version check passed; compile-time/const-generic suite 47/47; negative suite 134/134; parser regression 68 checks passed; legacy runtime/compiler case suite 132/132 at both FAC `-O0` and `-O2`. The full semantic wrapper was not run to completion, so no full semantic-suite pass is claimed. These are Linux host results, not cross-platform qualification.

See [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md), [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md), [`tests/comptime/consteval_functions.fac`](../tests/comptime/consteval_functions.fac), and [`tests/comptime/run.sh`](../tests/comptime/run.sh).

## V220 — Generic default arguments

V220 adds trailing defaults to generic parameters. Type defaults (`T = int`) are supported on generic struct/class/interface/enum declarations, free functions and generic methods; `const int` defaults (`const int N = 16`) are supported on struct/class declarations, free functions and generic methods. Defaults are resolved in declaration order before constraints, substitution and specialization. Defaults may refer to earlier parameters of the same kind, such as `U = T` and `const int M = (N * 2)`; forward references are rejected by the left-to-right resolution model. Once a default appears, every later generic parameter must also have a default.

Omitted generic arguments are filled from defaults for positional/named partial argument lists. A bare generic type name is accepted only when every parameter has a default. For generic free-function calls without an explicit generic argument list, supported argument inference happens first and defaults fill only unresolved parameters; inferred values/types therefore override defaults. When an explicit partial generic argument list is present, omissions are default-filled rather than inferred from ordinary function arguments. This does not broaden the bounded const-value inference rules or add general generic type/class/method inference.

Validation for this source snapshot: compiler built with GCC C++17 `-O0 -g0`; FAC V220 version check passed; parser regression 68 checks passed; compile-time/const-generic suite 39/39; negative suite 134/134; generic specialization 3/3; memory-safe profile 25/25; legacy compiler/runtime case suite 132/132 at FAC `-O0` and `-O2`; targeted HIR tests `hir_model`, `generic_inference_hir` and `generic_free_function_hir` passed with GCC C++17 `-O0`. The updated comptime fixture covers type/const defaults on structs, classes, free functions and methods, type defaults on interfaces/enums, dependent defaults, inference precedence, partial named/positional arguments and constraint failures. Parser regressions also reject forward references in type and const defaults. The full semantic wrapper exceeded the local command time budget; targeted HIR tests passed, but no full semantic-suite pass is claimed. These are Linux host results, not cross-platform qualification.

See [`GENERIC_DEFAULT_ARGUMENTS_V220.md`](GENERIC_DEFAULT_ARGUMENTS_V220.md), [`tests/comptime/generic_default_arguments.fac`](../tests/comptime/generic_default_arguments.fac) and [`tests/comptime/run.sh`](../tests/comptime/run.sh).

## V220 — Const generic value inference from fixed-array extents

V220 adds bounded const-value inference to generic free functions. When a `const int N` parameter appears directly as the extent in a function parameter such as `array var T values[N]`, a call without an explicit generic argument list may infer `N` from a fixed-size array argument. Ordinary type parameters such as `T` may be inferred from that same argument's element type. Repeated occurrences of one const parameter must agree, and existing const predicates are checked against the inferred value before specialization. The value is part of the specialization key and is substituted through the function body, including local fixed-array dimensions.

The boundary is deliberately narrow: inference is for generic free functions only; generic methods and generic struct/class instantiations still require explicit arguments. The extent must be a direct identifier `[N]`; algebraic inverse solving (`[N * 2]`), list/dynamic lengths, runtime integers and arbitrary expression results are not inference evidence. Defaults are applied after supported inference, and an explicit partial generic argument list is completed from defaults rather than inferring omitted parameters. HIR records inferred values as const-value substitutions, but its source analysis is conservative and recognizes local fixed arrays with supported integer-constant extents. Codegen remains authoritative.

Validation for this source snapshot: compiler built with GCC C++17 `-O0 -g0`; version check passed; compile-time/const-generic tests 33/33; runtime/compiler case suite 132/132 at both FAC `-O0` and `-O2`; negative tests 134/134; generic specialization 3/3; parser regression 62 checks; memory-safe profile 25/25; targeted HIR tests `generic_inference_hir.cpp` and `generic_free_function_hir.cpp` both compiled with GCC C++17 `-O0` and passed. The full `tests/semantic/run.sh` wrapper was not run to completion, so no full semantic-suite pass is claimed. These are Linux host results, not cross-platform qualification.

See [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md), [`tests/comptime/const_generic_inference.fac`](../tests/comptime/const_generic_inference.fac) and [`tests/semantic/generic_free_function_hir.cpp`](../tests/semantic/generic_free_function_hir.cpp).

## V220 — Named generic arguments

V220 accepts named generic arguments on generic struct/class types, free functions and methods. Use `parameter = argument` inside the generic argument list, for example `FixedBuffer<N = (2 * 4), T = int>`, `keepSized<N = 12, T = int>(42)` and `utility.capacity<N = 9>()`. Positional arguments may appear before named arguments; positional arguments after the first named argument are rejected. Every required generic parameter must be supplied; omitted parameters are filled from declared defaults. Unknown, duplicate and missing required parameter names receive targeted diagnostics. The compiler maps accepted arguments to declaration order before specialization and cache lookup, preserving deterministic specialization identity. This does not add named arguments to ordinary runtime calls. Const-value inference was added in a later V220 update for fixed-array extents in generic free functions; see [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md).

Validation for this update: compiler built with GCC C++17 `-O0 -g0`; named generic runtime fixture output `8 4 42 9`; compile-time/const-generic tests 29/29; parser regression 62 checks; semantic runner passed using a local GCC `-O0` wrapper; generic specialization 3/3; version check passed. The full general case runner was not requalified in this update. These are Linux host results, not cross-platform qualification.

See [`NAMED_GENERIC_ARGUMENTS_V220.md`](NAMED_GENERIC_ARGUMENTS_V220.md), [`GENERIC_SPECIALIZATION.md`](GENERIC_SPECIALIZATION.md) and [`GENERIC_INFERENCE_HIR_V220.md`](GENERIC_INFERENCE_HIR_V220.md).

## V220 — Const Generic value constraints

V220 extends `const int` generic parameters on generic struct/class types, free functions and methods with built-in value predicates. Supported predicates are `positive` (`N > 0`), `nonnegative` (`N >= 0`), `nonzero` (`N != 0`), `negative` (`N < 0`), `even`, `odd` and `power_of_two`. A declaration may combine predicates with `&`; all predicates must pass for the concrete signed-64-bit const argument. For type/class specializations, predicates are checked before materializing dependent fields and array layout. Unknown predicate names are parser errors. HIR preserves const predicates as value-constraint metadata rather than attempting to resolve them as types. Named generic arguments are supported for generic struct/class types, free functions and methods. At this earlier V220 generic-constraints milestone, user-defined `consteval`, general const-expression solving and type/interface bounds on const parameters were not included; bounded fixed-array inference and the restricted scalar free-function `consteval` interpreter were added in later V220 updates (see the sections above).

Validation for this source snapshot: compiler built with GCC C++17 `-O0 -g0`; const-generic/comptime tests 24/24; parser regression 58 checks; semantic ancestry 17 checks; targeted HIR model regression passed with Clang C++17 `-O0`; memory-safe profile 25/25; generic specialization 3/3; negative tests 134/134; runtime/compiler case suite 132/132 at both FAC `-O0` and `-O2`; version check passed. The O0/O2 case suites exercise ordinary program compatibility, while the dedicated comptime suite exercises the new value predicates and failure diagnostics. The full semantic wrapper exceeded the local command time budget during its additional large C++ test compilations, so no full-wrapper pass is claimed. These are Linux host results, not cross-platform qualification.

See `docs/CONST_GENERIC_CONSTRAINTS_V220.md`, `docs/CONST_GENERIC_FUNCTIONS_V220.md` and `tests/comptime/const_generic_constraints.fac` for syntax and regression scope.

## V220 — Socket/TLS handle lifetime and concurrency safety

V220 converts TCP `Sock*` and TLS `FacTlsHandle*` values into stable opaque tokens resolved through process-wide registries. Runtime code never dereferences a caller-supplied token. Token objects remain allocated as tombstones for process lifetime so stale aliases cannot become valid after a later handle allocation. Native socket/TLS state is stored separately in shared state records.

TCP socket records track lifecycle, active-operation leases, and synchronization. Reads and writes use separate mutexes, preserving full-duplex TCP; socket options use a separate lock. Close prevents new operations, waits for active operations to drain, closes the native descriptor exactly once, and retires the token. A successful TLS handshake reserves and drains the socket, transfers shared ownership to TLS, and retires the original socket token. A failed handshake leaves ownership with the caller.

TLS records retain socket state and own the OpenSSL context/session. All OpenSSL operations and close serialize through a per-stream mutex; close first sets an atomic closing flag so later calls fail closed, then waits for an in-flight operation before freeing SSL/context and closing the transferred socket. TLS therefore remains single-flight per stream: a blocking TLS read delays a send on that same TLS handle. FAC cleanup callbacks release operation/mutex guards and local shared-state references when Runtime errors longjmp past C++ destructors. Public API signatures, pointer-sized opaque-handle ABI, and exported C ABI symbol names are unchanged.

Regression coverage: `tests/runtime/socket_handle_concurrency.cpp` covers close-vs-I/O, stale aliases after 256 handle churn cycles, repeated close, and TCP full-duplex read/write. `tests/runtime/tls_loopback.cpp` / `tests/runtime/tls_loopback.sh` cover TLS negotiation and hostname verification, successful/failed ownership transfer, stale aliases, repeated close, TLS close racing a timed read, and WebSocket TLS loopback. The TCP test is included in Runtime, TSan, and ASan/UBSan harness scripts.

Validation (Linux x86-64): Clang built Compiler with `-O0 -DNDEBUG` and Runtime with `-O1 -DNDEBUG` using `make all`; `facc --version` and `make check-version` report all seven components as V220. The full Runtime regression (`CXX=clang++ sh tests/runtime/run.sh`) passed all 56 reported test groups after the final cleanup-guard changes. The socket stress test passed close-vs-I/O serialization, stale-token rejection across 256 socket handle churn cycles, idempotent close, and full-duplex read/write. `CXX=clang++ sh tests/runtime/tls_loopback.sh` passed TLS 1.3 loopback, hostname mismatch rejection, stale socket/TLS tokens after subsequent TLS allocation, TLS close racing a timed read, and two encrypted WebSocket loopback cases.

Compiler fixtures passed 129/129 at FAC `-O0` and 129/129 at `-O2`; negative tests 132/132; resource limits 21/21; safe/strict-safe 437/437; ownership 11/11; const-method ownership 8/8; local borrow 167/167; noescape 17/17; field-sensitive borrow 19/19; effect contracts 19/19; function effects 13/13; move 20/20; partial move 28/28; compile-time assertions 7/7; memory-safe profile 25/25; lifetime tests passed with `FAC_COMPILER=./build/facc`; lexer 18/18; parser 58/58; semantic ancestry 17/17; generic specialization 3/3; codegen guards passed; Java-style entry 10/10 at both `-O0` and `-O2`. API regression passed 41/41 at both FAC `-O0` and `-O2`; polygon SAT oracle 60/60 and SpatialHash oracle 70 queries / 80 objects with no missed overlaps or duplicate IDs. `tests/tools/test_tools.py` passed 89/89.

`make fmt-check`, `make check-version`, `make api-check`, and `make standards-check` passed. Standards validation covers 5 OS families and 6 architecture families. The API manifest is current (653 built-ins, 1,014 source declarations); API audit reports 4 baseline findings and 0 findings outside the baseline (one previous baseline finding is no longer reported); strict contract audit found 0 missing annotation blocks across 950 public source functions; compatibility reports 0 breaking changes and 132 warnings against V128; generated API docs are current (114 files).

The lifetime runner's default `build-cmake/debug/facc` path was not present in this workspace, so the first invocation could not start; rerunning with `FAC_COMPILER=./build/facc` passed the lifetime cases. The test-tools check initially exposed a stale generated `docs/API_AUDIT.md`; the report was regenerated and the complete tools suite then passed 89/89.

Limitations: the complete Runtime TSan and ASan/UBSan harness scripts each exceeded the 300-second command limit while building instrumented Runtime objects; no sanitizer pass is claimed for V220. Targeted non-sanitized Socket and TLS concurrency tests passed, but sanitizer coverage of these final source changes remains outstanding. Cross-platform qualification (Windows/macOS) and GCC Runtime build qualification are not claimed. The POSIX OpenSSL TLS backend remains unavailable on Windows. Socket and TLS token objects are retained as tombstones until process shutdown, so metadata memory usage grows with the number of handles created. TLS calls on a single stream are serialized; a blocking TLS read delays a send on that same stream. Managed wrapper objects must not be concurrently mutated/destroyed while another thread calls methods on those same object fields.
### V220 — generated function control-flow validation snapshot

`TypedFunctionBodyBuilder` now represents mutable scalar locals, exact-TypeId assignments and nested bool-conditioned `if/else` regions in the generated statement HIR. All locals are declared before statements; every generated `if` requires both branches; branches cannot return independently; one explicit terminal return remains required. Codegen projects the structured statement tree to ordinary FAC block/if/assignment nodes and reuses the backend LLVM basic-block path. Loops, branch-local declarations/returns, multiple return paths, aggregates and post-generation HIR re-analysis remain unsupported.

For this update, GCC C++17 compiler-only and runtime-only builds passed; FAC V220 version check passed; compile-time tests passed 57/57; parser regression passed 68 checks; Codegen constant-fold and recursion-guard tests passed; six existing targeted HIR fixtures (`hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir` and `typed_decl_builder`) passed individually at `-O0`; the updated `generated_function_body` and `generated_declaration_codegen` fixtures compiled/ran at `-O0` and their emitted LLVM IR compiled with Clang. The full legacy runtime test runner was attempted at both FAC `-O0` and `-O2` but exceeded the local command time limit before a completion summary; neither full-runtime pass is claimed. The full semantic wrapper was not completed. These are Linux-host checks, not cross-platform qualification.
