# SQLite Runtime handle safety (V219)

## Handle model

`fac_sqlite_open` and `fac_sqlite_prepare` return pointer-sized opaque tokens. The Runtime stores the actual C++ records in registries and checks the token before reading mutable state. Tokens increase monotonically and are not reused during a process lifetime; registry entries are removed on free, so stale tokens resolve as invalid without retaining a tombstone record for each closed handle.

## Synchronization and lifetime

Every connection record has one mutex. Connection-level operations and statement-level native calls acquire that same mutex, serializing use of the SQLite connection, statement execution/finalization, and connection close/free. Statement records own a `shared_ptr` to their connection record. This keeps the mutex and deferred SQLite connection state alive while an outstanding statement remains after `sqlite3_close_v2`; a prepared FAC `Statement` may therefore continue after its `Database` connection token has been closed/freed.

A successful `fac_sqlite_close` closes the Database-facing connection token, but already prepared statements may continue according to SQLite `close_v2` semantics until finalized. `fac_sqlite_connection_free` removes the connection token and prevents further connection-handle operations. Outstanding statement tokens remain valid until their own finalize/free operations. Statement free removes its token before waiting for the connection lock, so operations that already looked up the state either finish before free or observe an inactive statement after free. The regression also races statement free against multiple concurrent `step` callers.

## Returned column data

Column text and column names are copied to thread-local strings while the connection mutex is held. The returned C string remains valid until that thread calls the same column accessor again or exits. The high-level FAC `Statement.columnText` and `columnName` wrappers copy into owned FAC strings.

## Boundaries

The lock protects individual native calls, not a complete sequence of multiple calls. Applications must not interleave logical transactions on one connection or a bind/step/reset sequence on one statement across threads unless they coordinate that sequence externally. Managed `Database` and `Statement` object fields must not be destroyed or mutated concurrently with methods on the same object. Tokens are not native SQLite pointers and must never be cast to `sqlite3*`/`sqlite3_stmt*`.
