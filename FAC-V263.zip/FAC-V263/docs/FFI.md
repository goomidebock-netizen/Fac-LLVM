# เรียก C / C++ (FFI)
```
link "m"                                  # ลิงก์ -lm (หรือใช้ flag -lSDL2 / --pkg sdl2 ตอนรัน facc)
extern function double hypot(double a, double b)
extern function int printf(string fmt, ...)         # C variadic
extern function ptr char getenv(string name)
extern function void SDL_Delay(uint ms) as "SDL_Delay"   # as "..." = ชื่อ symbol จริง
```
- ใช้ได้กับ function แบบ `extern "C"` (C++ ต้องห่อด้วย `extern "C"` เอง)
- ชนิด: `int`=int32 · `long`=int64 (**ไม่ใช่ C long บน Windows**) · `float/double` · `boolean`=1 byte · `ptr T` · `string` ส่งเป็น `const char*` (NUL-terminated อัตโนมัติ)
- `array`/`list` ส่งเป็น pointer ข้อมูล · struct ส่งเป็น pointer: `addr(x)` (layout ตรงกับ C struct แบบ natural alignment)
- return `string` ไม่ได้ → รับเป็น `ptr char` แล้ว `cstr(p)` แปลงเป็น string (copy)
- callback: `cfn(ชื่อ function)` ได้ function pointer ดิบ (function ต้อง parameter/return เป็นชนิดเข้ากับ C) ใช้กับ `qsort`, callback ของ SDL ฯลฯ
- compile ไฟล์ C/C++ ไปด้วย: `facc prog.fac helper.c lib.cpp -lSDL2 -L/path -I/path --pkg sdl2` (ส่งต่อให้ clang++)
- FAC เรียก C ผ่าน `extern function`; การ export FAC function เป็น C ABI มีข้อจำกัดชนิดข้อมูลตามหัวข้อถัดไป
- ตัวอย่างเต็ม: tests/cases/t12_ffi.fac

## Lifetime contracts สำหรับ FFI (V205)

ตั้งแต่ V205 สามารถระบุ named lifetime บน pointer parameter/return ของ `extern function` และระบุความสัมพันธ์ `where longer: shorter` ได้เหมือนฟังก์ชัน FAC ปกติ:

```fac
# สัญญาว่า pointer ที่คืนมามีอายุไม่เกิน pointer ที่รับเข้ามา
extern function lifetime<a> ptr<a> int ffi_identity(ptr<a> int value) as "ffi_identity"

# สัญญาว่า `longer` มีอายุยาวกว่า `shorter`
extern function lifetime<a, b> void ffi_consume(ptr<a> int longer, ptr<b> int shorter) where a: b as "ffi_consume"
```

Compiler จะตรวจ contract ที่ direct call ซึ่ง resolve ได้แน่นอน และใช้ contract ที่ประกาศเพื่อจำกัด provenance ของ pointer return แต่ **ไม่สามารถพิสูจน์ implementation ฝั่ง C/C++** ได้ สัญญา lifetime ของ `extern` จึงเป็น trusted FFI promise: ผู้ประกาศต้องตรวจสอบ API/implementation ต่างประเทศเองว่าไม่คืน pointer จากแหล่งที่ไม่เกี่ยวข้องและไม่เก็บ pointer เกินอายุที่สัญญาไว้ หากประกาศไม่ตรงกับพฤติกรรมจริง การตรวจความปลอดภัยฝั่ง FAC จะตั้งอยู่บนสมมติฐานที่ผิด

การไม่ใส่ lifetime annotation ยังคงใช้พฤติกรรมเดิม ข้อจำกัดเรื่อง indirect/function-value calls และ pointer provenance ใน aggregate/container ยังมีอยู่ ดูรายละเอียดและตัวอย่างการตรวจผ่าน/ไม่ผ่านที่ [`LANGUAGE_CORE_V205.md`](LANGUAGE_CORE_V205.md) และ `tests/lifetimes/v205_extern_*.fac`.

# เรียก Fac จาก C/C++ (export)
```
# mylib.fac
export function int fac_add(int a, int b) { return a + b }       # ชื่อ symbol = fac_add (ไม่ mangle)
```
```
facc mylib.fac --lib --shared --emit-header mylib.h -o libmylib.so   # shared library (รวม runtime แล้ว)
facc mylib.fac --lib --obj    --emit-header mylib.h -o mylib.o       # object (ต้องลิงก์ libfacrt.a -lstdc++ -lm -pthread เอง)
```
- เรียก `fac_lib_init()` ก่อนใช้ function อื่น (รัน global initializer) และ `fac_lib_shutdown()` ก่อนจบ (flush output) — มีอยู่ใน header ที่สร้างให้
- export ได้เฉพาะ parameter/return เป็นตัวเลข, boolean, char, enum, ptr, void · ไม่รองรับ string/list/struct/ref ที่ขอบเขตนี้ (ส่งเป็น ptr แทน)
- ตัวอย่างและเทสต์: tests/lib/ + `tests/run_lib.sh`


## ข้อควรระวังด้าน ABI และ portability
- FAC V16 ใช้ pointer-sized storage และ runtime assumptions แบบ 64-bit; ให้ใช้ target 64-bit (เช่น x86_64 หรือ aarch64) เท่านั้นในรุ่นนี้. 32-bit targets ยังไม่รองรับอย่างเป็นทางการ.
- `long` ของ FAC คือ signed 64-bit เสมอ ไม่ใช่ C `long`; เวลาเชื่อม C ให้ใช้ชนิด fixed-width (`int32_t`/`int64_t`) ใน header ฝั่ง C หรือ `ptr`/`struct` ตาม layout ที่ตกลงกัน.
- `struct` ที่ส่งผ่าน FFI ต้องตรงกับ C layout; ใช้ `addr(x)` และตรวจ field order, field size, padding/alignment ใน header ฝั่ง C. อย่าสมมติว่า C++ class ใช้ ABI เดียวกับ C struct.
- `volatile` ใช้สำหรับ memory-mapped I/O / hardware registers เท่านั้นเมื่อ address และสิทธิ์ถูกต้อง. มันไม่ได้แทน atomic, lock หรือ memory barrier ระหว่าง threads.
- weak object values ที่ได้จาก `memory.weak` เป็น opaque pointer-sized generation tokens ไม่ใช่ address ของ object/control block; ให้ copy/pass กลับเข้า weak APIs เท่านั้น ห้าม dereference, ทำ pointer arithmetic หรือคาดว่า cast กลับเป็น `FacWeakControl*` ได้.
- `align(N)` จัดแนว storage ของตัวแปร/array `var` ที่ประกาศ; ไม่ได้เปลี่ยน layout ของ struct และไม่ได้รับประกันว่า address ของ hardware/device memory ใช้ได้.


## V45 ABI requirements

Treat the target's C ABI as the primary supported foreign boundary. Do not assume that a C++ class ABI is portable across compilers or OSes. Record target triple, calling convention, fixed-width scalar types, aggregate layout/alignment, symbol spelling, string encoding, callback lifetime, allocator pairing, unwind behavior, library/SDK dependencies and minimum OS version for each binding. The platform/ABI matrix and external references are in [`PLATFORM_STANDARDS.md`](PLATFORM_STANDARDS.md).
