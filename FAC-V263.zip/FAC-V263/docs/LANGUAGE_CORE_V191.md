# FAC Language Core V191 — explicit primitive cast array-index projections

## Scope

V191 extends only the bounded strict local-borrow fixed-array projection evaluator. It does not add a general constant evaluator or execute arbitrary compile-time code.

The evaluator recognizes `cast(Type, value)` when `Type` is a primitive integer (`Byte`, `Short`, `Int`, `Long`, `Ubyte`, `Ushort`, `Uint`, `Ulong`), `Boolean`, `Char`, or `Unichar`, and `value` resolves to a supported pure integer-like constant. Nested casts are evaluated from the innermost expression outward.

The folded result follows the conversion rules used by FAC code generation:

- Narrowing integer casts retain the low target-width bits (truncation).
- Widening signed integer values use sign extension.
- Widening unsigned values, `char` and `unichar` use zero extension.
- Conversion to `Boolean` maps zero to false and any nonzero value to true.
- A cast to a signed target interprets the final target-width bit pattern using the target sign bit.

Example:

```fac
ref var int direct = values[cast(Int, 1)]
ref var int narrowed = values[cast(Byte, 258)]       # Byte truncates to 2
ref var int unsigned = values[cast(Ubyte, 259)]      # Ubyte truncates to 3
ref var int nested = values[cast(Long, cast(Short, 4))]
ref var int conditional = values[ifv(cast(Boolean, 2)){5}elv{6}]
```

## Conservative boundaries

- Floating-point to integer conversion is not folded, including FAC's saturating float-to-integer conversion path.
- Pointer, opaque, class, enum and payload-enum casts are not folded.
- Calls other than the recognized primitive `cast` form, side effects, mutable variables, unresolved identifiers and unsupported source expressions remain unknown/may-alias.
- Unsigned intermediate values above `INT64_MAX` cannot be represented by the existing projection value type and remain conservative even when a later cast might narrow them into range.
- The final projection must still be a non-negative value representable by the existing signed 64-bit index representation.
- This does not add array bounds checking, general lifetime analysis, dynamic alias analysis or complete borrow checking.

## Regression coverage

- `good_array_cast_constant_indices.fac` checks direct and nested casts, signed and unsigned truncation, boolean conversion, character conversion, cast-derived conditional predicates and runtime writes through the resulting aliases.
- `bad_array_cast_constant_same_index.fac` verifies two syntactically different casts that produce the same index still conflict.
- `bad_array_cast_dynamic_index.fac` verifies mutable source values wrapped in casts remain dynamic and cannot be treated as exact projections.

Validation results are recorded in `docs/STATUS.md`.
