# FAC V138 Security Audit — generation-tagged weak handles

## Scope

This audit covers the opaque weak-reference values returned by `fac_obj_weak()` and consumed by `fac_obj_weak_retain()`, `fac_obj_weak_release()`, `fac_obj_weak_alive()` and `fac_obj_weak_lock()`. It addresses use-after-free and address-reuse ABA in the weak-control-block handle representation. It does not redesign the raw strong-object pointer ABI.

## Finding

Before V138, the public weak value was the address of a heap-allocated `FacWeakControl`. A synchronized registry could reject a value after its control block had been removed, but it could not distinguish an old stale pointer from a newly allocated control block that later reused the same address. That was a pointer ABA gap.

## Remediation

V138 makes the public weak value an opaque integer token carried through the existing pointer-sized C ABI:

- On 64-bit targets, bits 0–22 encode a one-based slot value (up to 8,388,607 slots) and bits 23–46 encode a nonzero 24-bit generation. The token occupies only the low 47 bits.
- On 32-bit targets, bits 0–11 encode a one-based slot value (up to 4,095 slots) and bits 12–30 encode a nonzero 19-bit generation. The token occupies only the low 31 bits.
- Tokens are integer values carried through `void *`; they are never dereferenced. The implementation and regression test select the layout from `UINTPTR_MAX`.
- The slot table, free-list updates, weak-control lookup, handle counts and object detach are serialized by `g_obj_mu`.
- When the final handle is released, the slot is cleared and its generation increments before the slot is returned to the free list.
- If a slot reaches the maximum generation, it is retired permanently rather than wrapping. A stale token can therefore never become valid again through slot reuse.

`FacWeakControl` stores its slot index and generation for anchor removal. The weak control allocation itself is still freed once the object anchor and all public weak handles are gone. The slot vector retains its capacity up to the peak simultaneous number of weak-control slots; it does not allocate a permanent tombstone per expired weak handle.

Public C function signatures are unchanged and the managed-object header remains 64 bytes. However, the value returned by `fac_obj_weak()` is no longer an actual address. Native callers must treat it as an opaque pointer-sized token and copy/store/pass it unchanged. Dereferencing it, doing pointer arithmetic on it or assuming it identifies `FacWeakControl` is unsupported. This relies on supported targets preserving pointer-sized integer values through the implementation-defined `uintptr_t`/`void *` conversions used by the existing ABI. Both 32-bit and 64-bit token layouts are implemented, although the validation reported below was run on a 64-bit Linux host; no 32-bit build result is claimed.

## Regression coverage

`tests/runtime/object_registry_safety.cpp` covers:

- Expired weak handles after object destruction.
- Invalid native values passed to weak APIs.
- Stale strong object references rejected before header dereference.
- Forced weak-slot reuse: the second weak value must differ from the stale first token.
- Stale token retain/release/alive/lock operations after slot reuse must not observe or modify the new weak handle.
- The new token must still lock the second object and expire when that object is destroyed.

Existing `tests/runtime/weak_refs.cpp` and `tests/runtime/refcount_concurrency.cpp` cover weak retain/release and weak-lock races. `tests/runtime/finalizer_error_cleanup.cpp` remains part of the Runtime cleanup regression set.

## Validation performed

- GCC 14.2 CMake Debug build: completed from a clean external build directory.
- CTest: **13/13 passed**, including the memory-safe profile and package-install consumer.
- Runtime shell suite: completed successfully after the weak-handle generation-token implementation was in place.
- Compiler checks: `tests/run_safe.sh` passed **316/316**; ownership, local-borrow, field-sensitive borrow, noescape, effect-contract and move/partial-move suites passed. The focused object-registry test also verifies invalid/stale strong handles, stale weak handles, slot reuse and generation mismatch.
- GCC `-O0 -g0 -fsanitize=address,undefined -fno-omit-frame-pointer` with leak detection: `object_registry_safety`, `weak_refs`, `refcount_concurrency` and `finalizer_error_cleanup` passed without ASan, UBSan or LeakSanitizer reports.
- Targeted GCC ThreadSanitizer runs passed for `refcount_concurrency` and `object_registry_safety`. The full Runtime shell suite was not run under sanitizers or TSan. No 32-bit build, hosted Windows/macOS build or optimized Clang full-project build is claimed.
- API signatures and the managed-object header layout were not changed. The weak value's opaque representation contract did change and is documented here.

## Performance

A dedicated benchmark is provided at `benchmarks/weak_handle.cpp`. It reports weak-alive latency and weak-retain/release pair latency over warmed samples. The benchmark was compiled with `-O3 -DNDEBUG`, the V137 and V138 Runtime objects were compiled with identical GCC `-O2 -DNDEBUG` flags, and the same harness was run in alternating order for three process runs; each process run used nine samples of 3,000,000 iterations per operation. The median of the three process medians was:

| Operation | V137 | V138 | Change |
|---|---:|---:|---:|
| `weak_alive` | 2.14 ns | 14.07 ns | 6.57× slower |
| weak retain + release pair | 22.15 ns | 30.50 ns | 37.7% slower |

The main cost is validation through a mutex and slot-table lookup instead of a direct weak-control pointer load. This is an uncontended single-handle microbenchmark, not a whole-program result; the measured latency increase is a real trade-off for rejecting stale/ABA weak tokens. Future optimization should preserve generation validation and concurrency correctness rather than remove them.

## Residual risks and limitations

- **Raw strong object pointer ABA remains:** strong managed-object values are still raw payload addresses. The current ABI cannot distinguish a stale object pointer from a new object allocated at the same address. Closing that gap needs a different opaque object-handle representation or an ABI-wide handle indirection design.
- **Native misuse:** an unsafe/native caller can still violate ownership rules, corrupt memory or misuse weak values. Opaque tokens are not a sandbox.
- **Pointer/integer conversion:** opaque weak tokens use the existing pointer-sized ABI as a carrier. The code defines 64-bit and 32-bit layouts, but only 64-bit Linux was built and tested in this release. They are not memory addresses.
- **Generation exhaustion:** a slot is retired at its generation maximum (24 bits on 64-bit; 19 bits on 32-bit); it is not reused with a wrapped generation. This is safe but can consume another slot after an extreme number of reuses.
- **Memory-safe profile:** FAC still lacks a complete lifetime/borrow proof, Rust-style `Send`/`Sync` guarantees and a whole-program data-race proof.
- **Error unwinding:** portions of Runtime error handling still use `setjmp`/`longjmp`; this release does not guarantee C++ destructor execution across every non-local error path.

This audit records focused regression evidence, not formal verification, exhaustive fuzzing, complete sanitizer coverage or a claim of Rust-equivalent memory safety.
