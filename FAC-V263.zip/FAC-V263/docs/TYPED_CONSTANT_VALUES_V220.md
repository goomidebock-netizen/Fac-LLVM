# FAC V220 — Typed Constant Queries

## Status

Implemented in the V220 compiler source tree as compile-time type/layout intrinsics. This is a bounded typed-constant foundation; it is **not** a general reflection or typed AST/metaprogramming facility.

## 1. Syntax

The compiler provides three type-argument queries:

```fac
const var int INT_BYTES = sizeof<int>()
const var int INT_ALIGNMENT = alignof<int>()

static_assert(typeOf<int>() == Type.Int, "int category")
static_assert(sizeof<int>() == 4, "int size in the active target layout")
static_assert(alignof<int>() == 4, "int alignment in the active target layout")

public struct RecordLayout {
    public var int count
    public var byte marker
    public var long stamp
}

static_assert(sizeof<struct RecordLayout>() == 16, "record layout includes padding")
static_assert(alignof<struct RecordLayout>() == 8, "record alignment")
```

Each query uses exactly one type argument and no runtime value arguments. They are compiler intrinsics, not ordinary library functions.

## 2. Result types and meaning

- `typeOf<T>()` yields a value of the built-in `enum Type`. It classifies the resolved type using the existing FAC `typeof(value)` categories: `Byte`, `Short`, `Int`, `Long`, `Ubyte`, `Ushort`, `Uint`, `Ulong`, `Float`, `Double`, `Boolean`, `Char`, `Unichar`, `String`, `Ptr`, `Struct`, `Enum` or `None`.
- For an `array T` or `list T` type argument, `typeOf` follows the existing `typeof(value)` convention and reports the element type category, because the current `Type` enum has no Array/List category. Unmapped type kinds report `Type.None`; this is a category query, not a structural type descriptor.
- `sizeof<T>()` yields an `int` constant equal to the compiler's current object-layout size for `T`.
- `alignof<T>()` yields an `int` constant equal to the compiler's current object-layout alignment for `T`.

The size/alignment intrinsics reuse the compiler's `sizeOf`/`alignOf` layout implementation, including record field padding, fixed-array element layout, enum payload representation and object-handle layout. The result describes the active compiler target/layout; it is not by itself a promise of a universal cross-platform C ABI.

## 3. Supported contexts

The queries are evaluated during compilation and can be used in:

- module-level `const` initializers;
- `static_assert` expressions;
- supported scalar `consteval` free-function bodies;
- supported const generic value expressions and specialization arguments;
- ordinary function expressions, where the result is emitted as a compile-time constant rather than a runtime reflection call.

For user-defined structs, layout queries require the record layout to have been resolved. Class/object handles use the existing object-handle layout. `typeOf` returns an enum value and can therefore be compared with `Type.*` members or returned from a supported scalar `consteval` function.

## 4. Restrictions and diagnostics

- A call must be written as `typeOf<T>()`, `sizeof<T>()` or `alignof<T>()` with exactly one type argument and no runtime arguments.
- `sizeof<array T>()` is rejected because an unsized array type has no fixed object size. `alignof<array T>()` may still query the element alignment.
- `sizeof` and `alignof` reject `void`, inferred/auto, null, tuple and function types; `sizeof` also rejects incomplete/unsized array types.
- A struct whose layout is not resolved cannot be queried yet.
- These three type/layout queries do not themselves expose field names, offsets as a field list, generic declarations, AST nodes, source locations or declaration-generation APIs. A separate bounded set of V220 structural field queries is documented in [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md).
- No runtime reflection registry, dynamic type inspection, macro expansion or arbitrary compile-time execution is introduced.

## 5. Regression coverage

`tests/comptime/typed_constant_values.fac` checks scalar categories, struct/enum/pointer categories, array category compatibility, record padding/alignment, object-handle layout, `consteval` integration, `static_assert`, and use of query results as const generic values. Negative fixtures cover unsized-array size, `void` size and forbidden runtime arguments. Run with:

```sh
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O0 -g0' -j1
make runtime-only CXX=g++ CXXFLAGS='-std=c++17 -O0 -g0' -j1
sh tests/comptime/run.sh
```

The full typed-metaprogramming roadmap remains separate: typed declaration builders, AST reflection, source maps and deterministic generated declarations are not implemented by these intrinsics.
