# FAC LLVM V136 — focused Runtime security audit

## Scope

This audit covers the object-finalization and cycle-collection error paths changed in V136. It is not a whole-project security certification or a proof of memory safety.

## Finding addressed

A FAC error raised by a user finalizer or field-drop callback could previously leave object destruction incomplete. In the cycle collector, propagating a non-local error while temporary C++ containers were still in scope could also skip their destructors, leak their allocations, and leave the collector's re-entry flag set.

## Changes

- `fac_obj_release()` now invokes finalizer/drop callbacks behind a local FAC error boundary. It records the first callback failure, continues the required drop and storage-release steps, and only then propagates the error.
- Cycle collection similarly records the first callback failure while completing finalization, field drops, and object storage release for all unreachable peers.
- The collector's temporary STL containers and lock are scoped so their destructors run before the retained error is propagated. The collection gate is restored before returning an error to the caller.
- C++ exceptions raised by callbacks are translated to a FAC Runtime error after cleanup; the original FAC callback error remains the first error when one was already recorded.

## Regression coverage

`tests/runtime/finalizer_error_cleanup.cpp` covers:

1. A single object's finalizer raising FAC error code 23; verifies drop and storage cleanup occur before the error is observed.
2. A single object's finalizer throwing a C++ exception; verifies cleanup occurs and the caller receives FAC Runtime error code 7.
3. An unreachable two-object cycle whose finalizers both raise FAC error code 29; verifies both objects are finalized/dropped, object and allocator counters return to baseline, and the collector can be called again.

## Validation performed

- GCC C++17 CMake Debug build.
- CTest: 12/12 passed.
- Runtime shell regression suite: passed, including the new finalizer-error regression.
- The parallel worker-pool identity regression was made deterministic with a callback rendezvous; it passed 10 consecutive isolated runs and the full Runtime shell suite. Runtime scheduling code was not changed for this test adjustment.
- Ownership/borrow contract tests: 178/178 passed.
- Move and partial-move tests: 43/43 passed.
- The focused finalizer-error regression passed under GCC AddressSanitizer + UndefinedBehaviorSanitizer with LeakSanitizer enabled (`detect_leaks=1`).
- API compatibility against V128: 0 Breaking / 27 Warnings / 0 Added. The warnings are error-contract changes; `memory.collectCycles()` is specifically documented as throwing while preserving the original dynamic FAC error code.

These are local results for the configurations stated above. They do not imply that every Runtime error path has been covered by sanitizers.

## Remaining limitations

- FAC still uses `setjmp`/`longjmp` in other Runtime paths. This targeted change does not ensure that arbitrary C++ destructors run across every FAC error boundary.
- The new regression was not run under ThreadSanitizer, and this audit does not establish a whole-program race-freedom guarantee.
- No Windows/macOS hosted CI result, optimized whole-project `-O2` benchmark, or broad performance improvement is claimed for V136.
- The `--memory-safe` compiler profile remains a conservative subset, not a complete lifetime/borrow proof and not equivalent to Rust's memory-safety guarantees.
