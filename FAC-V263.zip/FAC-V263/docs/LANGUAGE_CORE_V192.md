# FAC Language Core V192 — local const character identifiers in array-borrow projections

## Scope

V192 extends the bounded strict local-borrow fixed-array projection evaluator so initialized local `const char` and `const unichar` bindings can be used as exact array indexes when their initializer can be resolved by the existing pure integer-like constant evaluator.

FAC represents `char` as an 8-bit scalar and `unichar` as a 32-bit scalar. Both are unsigned integer-like types in the compiler's type model. The checker stores these constants with the corresponding width and unsigned flag before placing them in the declaration-identity keyed constant map. Supported arithmetic, primitive casts and integer comparisons can reuse the binding; supported `ifv / eiv / elv` predicates can therefore use character constants too.

Example:

```fac
array var int values[256] = {}
const char ascii = 'A'
const unichar codePoint = 'é'
const unichar following = codePoint + 1
ref var int a = values[ascii]
ref var int b = values[codePoint]
ref var int c = values[following]
```

## Conservative boundaries

- Only initialized local scalar `const char` and `const unichar` declarations are recorded.
- The initializer must resolve through the existing bounded pure integer-like evaluator.
- A value is associated with the exact declaration node; shadowing or a mutable same-name declaration cannot inherit a prior value.
- Mutable characters, parameters, globals/statics, uninitialized constants, arbitrary calls, side effects and unsupported expressions remain unknown/may-alias.
- The projection representation remains signed 64-bit; values that cannot be represented there remain conservative.
- This does not validate that every `unichar` value is a Unicode scalar, add array bounds checking, implement general constant evaluation, or complete lifetime/borrow checking.

## Regression coverage

- `good_array_const_character_indices.fac` covers ASCII `char`, non-ASCII `unichar`, constant chaining, narrowing casts, comparison-derived conditional indexes and runtime writes through aliases.
- `good_array_const_character_shadowing.fac` covers separate same-name character declarations in nested scopes and initializer-before-shadow lookup (the initializer resolves the outer declaration before the new declaration takes effect).
- `bad_array_const_character_same_index.fac` verifies a character identifier and numeric literal that resolve to the same index still conflict.
- `bad_array_mutable_character_shadowing_const.fac` verifies a mutable shadow is not treated as the outer constant and remains conservative.
