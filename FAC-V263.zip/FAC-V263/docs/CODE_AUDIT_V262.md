# FAC V262 — focused source-code audit

## Finding

**Severity: Medium — verified `thread.start` handles could not pass through a bounded join-only value-struct helper**

The V261 lifecycle summary pass already modeled direct and nested `ptr thread`
fields in value-struct parameters. However, the strict-ownership pointer-provenance
checker treated a field read through a by-value struct parameter as Unknown, even
when the field was passed only to a helper whose checked body called
`thread.join` on that exact `ptr thread` parameter. The call-boundary checker also
treated an aggregate containing an independently allocated `thread.start`
handle as an arbitrary pointer-bearing value passed to an ordinary retaining
function, including the explicit `move(aggregate)` case.

## V262 change

- `CallContract` now records a narrow `threadHandleJoinOnly` body fact for a
  non-`ref`, exact `ptr thread` parameter only when every occurrence of that
  parameter in the function body is the direct argument of the exact
  `thread.join(...)` call. Shadowing, captures, aliases, extra uses, unresolved
  paths and other types do not receive the fact.
- A value-struct parameter receives `threadHandleStructJoinOnly` only when its
  fully resolved pointer-bearing field layout consists exclusively of exact
  `ptr thread` leaves (including nested value structs), and each such field is
  either unused or passed only to `thread.join` or a uniquely declared,
  non-generic join-only helper. Overloaded helpers, generic helpers, unknown
  layouts, other raw-pointer field types, aggregate aliases/returns/stores,
  captures and unsupported projections remain unverified.
- The check is applied only when every selected call-contract candidate carries
  the corresponding verified fact. It is not a general `noescape` annotation,
  lifetime contract, or permission for arbitrary pointer fields.
- `move(value)` is unwrapped only to recover its operand's static value type for
  call-boundary aggregate provenance validation. Existing move/source and
  active-loan checks remain in place.
- Added a negative fixture proving that a helper which merely calls
  `thread.isDone(handle)` does not receive the join-only exception.

No source syntax, Runtime behavior, public API, C ABI, Runtime ABI, or
`--memory-safe` accepted subset changed. This is still bounded thread-resource
handling, not general pointer provenance, heap escape analysis, or a complete
borrow checker. It does not prove thread safety, happens-before, or data-race
freedom.

## Regression tests

- Existing `tests/safe/worker_join_struct_helpers.fac` now passes, including
  direct and nested field summaries, explicit aggregate moves, conditional
  joins, no-op helpers, repeated joins, and `try`/`catch` helper paths.
- Added `tests/safe/worker_join_struct_unconsumed_helper_rejected.fac`; a
  helper that only observes a handle is rejected when it tries to read an
  unverified pointer field from a by-value aggregate parameter.
- `tests/run_safe.sh`: 438 passed, 0 failed.

## Validation

- Release build completed with Clang 17 / C++17 / `-O0 -g0`; the Runtime
  object and archive were rebuilt after the V262 version bump. `facc --version`
  and `tools/check_versions.py` both confirm Compiler/Core/Lib/API/Lang/Runtime/
  Stdlib all report V262.
- Safe Profile: 438/438, including the new negative control. Ownership 12/12;
  const-method ownership 8/8; local borrow 167/167; noescape 17/17;
  field-sensitive borrow 25/25; effect contract 19/19; function-effect 13/13;
  secure profile 6/6.
- Move 20/20; Partial Move 28/28; Compile-time 57/57; Memory-Safe 39/39;
  Generic 3/3; Lexer 18/18; Parser 68 checks + AST 1/1; Codegen passed.
- Tools tests: all 91 tests passed when run in bounded unittest groups
  (VersionBump/Lexer/Formatter/Manifest/Audit/Contract/Compat/Docs: 48;
  Package/Diagnostics/LSP: 17; CompilerIntegration/FacSerdeGenerator/
  RepositoryConsistency: 26).
- Standards check passed (5 OS families, 6 architecture families); API manifest
  and generated docs are current (114 files); strict API contract audit found
  0 missing annotations across 950 public source functions. API audit examined
  663 built-ins and 1,014 source declarations, with 5 findings all in the
  existing baseline. Compatibility reports 0 breaking changes and 132 existing
  warnings against baseline V128. Formatter check passed.
- Runtime suite exercised many passing cases, but the full runner exceeded the
  execution time limit; therefore a full Runtime-suite pass is not claimed.
  The trailing checks were separately run and passed: strict UTF-8, compiler
  driver argument/special-path validation, vector-font backend, and three
  vector-font thread lifecycle runs. This does not replace a full Runtime run.
- Semantic: ancestry fast-path reported 17 checks passed, then the remaining
  runner timed out with both the default C++ compiler and Clang 17. Full
  Semantic success is not claimed.
- Full CMake/CTest, ASan/UBSan/TSan, actual Windows/macOS builds and runtime
  testing, and production qualification are not claimed.
