# CMake build and integration

FAC supports both the original GNU Make build and an optional CMake build. Both
produce the same compiler driver (`facc`) and static C ABI Runtime (`libfacrt`).
The Compiler and Runtime are independent targets; CMake tracks the included
`.hpp` and `.inc` implementation dependencies automatically.

## Configure and build

Requirements: CMake 3.20+, Ninja or another CMake generator, and GCC/Clang with
C++17 support.

```sh
cmake -S . -B build-cmake -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_COMPILER=clang++
cmake --build build-cmake --parallel 2
ctest --test-dir build-cmake --output-on-failure
```

For a low-cost local validation build that does not spend time optimizing the
large Compiler translation unit:

```sh
cmake -S . -B build-cmake-debug -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  '-DCMAKE_CXX_FLAGS_DEBUG=-O0 -g0'
cmake --build build-cmake-debug --parallel 2
ctest --test-dir build-cmake-debug --output-on-failure
```

The repository also provides `ninja-debug` and `ninja-release` presets. The
Debug preset is intended for fast correctness/build-system checks, not runtime
performance measurements.

## Targets

- `facc`: FAC compiler driver.
- `facrt`: static Runtime library (`FAC::Runtime` after export).
- `fac_runtime_graph_regression`: focused Graph/shortest-path Runtime test.

The Runtime target links its platform dependencies transitively: Threads and
`dl` where required on Unix-like platforms, or Winsock/GDI/User32/WinMM on
Windows. The Runtime disables CET branch protection only when the selected
compiler accepts `-fcf-protection=none`, preserving the existing longjmp error
boundary compatibility requirement.

## Install

```sh
cmake --install build-cmake --prefix /opt/fac
```

This installs `facc`, `libfacrt.a`, and `include/fac/version.h`, plus exported
CMake targets under `lib/cmake/FAC`. The exported Runtime target is named
`FAC::Runtime`.

## Validation scope

CTest includes the compiler version smoke test, release manifest verification,
API compatibility against the V128 baseline (when Python is available), and
Graph Runtime, Lexer and Parser regression. The broader language/runtime suites remain available
through the existing scripts and Make targets; a successful CMake/CTest run is
not a claim that every repository test has run.

V132 compiles `src/lexer.cpp` as a separate Compiler translation unit. The
Parser/AST remain together in `src/parser.hpp`, and the driver still includes
the inline Ownership/Move/Codegen implementation. This is the first staged
module boundary, not a complete Frontend/Backend split.

## Current verification

The V132 development-host checks completed with GCC 14.2 and Clang 17 using
CMake Debug builds (`-O0 -g0`): all seven CTest checks passed for each toolchain.
The package-consumer test installs FAC, configures a separate project with
`find_package(FAC)`, links `FAC::Runtime`, and runs the installed compiler
through `FAC::Compiler`. The same focused Graph and codegen checks were also
run through the Make build. Optimized CMake builds and hosted macOS/Windows
runners are not claimed as locally verified; the CI matrix configures Linux
GCC, Linux Clang and macOS Apple Clang jobs.
