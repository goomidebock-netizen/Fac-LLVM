# FAC Language Core V194 — bounded floating-point arithmetic constants

## Scope

V194 extends V193's strict local-borrow fixed-array index evaluator with a bounded pure floating arithmetic evaluator. Supported binary operators are:

- Addition (`+`)
- Subtraction (`-`)
- Multiplication (`*`)
- Division (`/`)
- Remainder (`%`, matching FAC's LLVM `frem` behavior)

Operands may be floating literals, visible initialized local `const float` / `const double` bindings, supported integer-like constants, or expressions composed from those forms. Unary `+` / `-` and explicit `Float` / `Double` casts remain supported. The evaluator then feeds the existing V193 explicit cast-to-integer / Boolean path, so a folded value can be used as a fixed-array index.

## Numeric representation rules

The evaluator carries a small internal expression-kind tag alongside each value: integer-like, float32 or float64. It follows the compiler's `commonT()` rule:

- If either operand is float64/double, the operation is evaluated as float64.
- Otherwise, if at least one operand is float32, operands are converted to float32 and the result is rounded to float32 after that operation.
- Integer-like operands are converted to the selected floating representation.

This distinction is observable at rounding boundaries. The regression fixture uses two float32 constants whose sum rounds to exactly `2.0f`; the corresponding sum performed as double remains below 2 and would truncate to a different index. Runtime writes through the resulting references verify that the static projection matches the generated program.

## Conservative boundaries

- This is not a general floating-point constant evaluator.
- Exponentiation (`**`) is not folded because FAC lowers floating exponentiation through `pow.f64`, whose host-library rounding is not treated as an exact compile-time proof here.
- Division or remainder by zero remains unknown/may-alias.
- Non-finite arithmetic results remain unknown/may-alias.
- Arbitrary calls, mutable values, globals/statics, side effects and unsupported casts remain unknown.
- The existing unsigned-64-to-signed-projection boundary and visit budget remain unchanged.
- This feature does not add floating comparisons to `ifv / eiv / elv`, array bounds checking, general lifetime analysis or a complete borrow checker.

## Regression coverage

- `good_array_const_floating_arithmetic_indices.fac` covers float32 rounding, double `+ - * / %`, mixed float32/double promotion, chained expressions, casts to integer indexes and runtime alias writes.
- `bad_array_const_float_arithmetic_same_index.fac` verifies that two syntactically different expressions resolving to the same exact index still conflict while their mutable borrows are live.
- `bad_array_const_float_power_unfolded.fac` verifies that unsupported exponentiation is left conservative rather than guessed.
- `bad_array_const_float_zero_division_unfolded.fac` verifies division by zero is not evaluated by the host checker.
- `bad_array_const_float_nonfinite_unfolded.fac` verifies an overflowing/non-finite arithmetic result remains conservative.
- Existing V193 floating-cast and declaration-shadowing tests remain active.

## Release boundary

V194 adds no public API signatures and does not change syntax, runtime ABI or the behavior of programs outside the opt-in strict local-borrow analysis. It does not claim that the complete borrow checker or general const evaluation is implemented.
