# FAC V220 — Generated Function Bodies and Control Flow

## 1. Scope

V220 extends the compiler-internal C++ `fac_hir::TypedFunctionBodyBuilder` for an already registered, non-generic generated free function. The body is stored in `SemanticModel::generatedFunctionBodies` as immutable typed expressions plus a structured statement tree. Codegen projects the validated body to ordinary backend AST nodes only for the duration of `Gen::generate`; the parser-owned source `Program` and its AST are not modified.

This is a compiler-internal C++ API, not FAC syntax, a `consteval` feature, a general macro system or arbitrary compile-time execution. The supported body now includes scalar locals, explicit mutation of mutable locals, nested `if/else` statements and one terminal return.

## 2. Supported function signatures and values

The generated function must be a non-generic free function. Its parameters must be plain scalar value parameters. The scalar builtin set is `byte`, `ubyte`, `short`, `ushort`, `int`, `uint`, `long`, `ulong`, `float`, `double`, `bool`, `char` and `unichar`; the return type may additionally be `void`.

Supported expressions include:

- parameter references and references to declared locals;
- integer, floating, character and boolean literals;
- validated unary and binary typed expressions;
- resolved, non-generic, same-module free-function calls with exact argument and return TypeIds.

No implicit conversion, overload lookup, generic substitution or imported-function resolution is performed by the builder. Call targets must already be resolved to a `SymbolId`.

## 3. Statements and builder API

The body builder provides:

- `addLocal(name, type, initializer)` for immutable scalar locals;
- `addMutableLocal(name, type, initializer)` for scalar locals that may be assigned later;
- `assignLocal(name, expression)` for an exact-TypeId assignment to a mutable local;
- `beginIf(boolExpression)`, `beginElse()` and `endIf()` for structured nested branches;
- `returnValue(expression)` or `returnVoid()` as the single terminal return;
- `commit()` to validate and register the completed body.

All locals must be declared at the top level before the first statement. This first control-flow increment deliberately does not create branch-local declarations or alter lexical scopes. Every `if` must have both a then and an else branch. Conditions must have the builtin `bool` TypeId. Each branch may contain assignments and nested `if/else` regions; branches cannot return or otherwise terminate independently. The function ends with one explicit return after all statements.

Example:

```cpp
fac_hir::TypedAstFactory expressions(model);
fac_hir::TypedFunctionBodyBuilder body(model, expressions, generatedFunction.symbol);

auto value = body.parameter(0); // int value
body.addMutableLocal("result", intType, value);

auto zero = expressions.integerLiteral(0, intType);
auto isNegative = expressions.binary("<", value, zero, boolType);
body.beginIf(isNegative);
body.assignLocal("result", zero);
body.beginElse();
body.assignLocal("result", value);
body.endIf();

body.returnValue(body.localReference("result"));
body.commit();
if (!model.validate())
  throw std::logic_error("generated function body is invalid");
```

The builder also allows nested `if/else` regions up to a nesting depth of 64. Statement-tree validation has a 10,000-node cap.

## 4. Validation rules

The builder requires a valid `SemanticModel` and a generated non-generic free-function SymbolId. It checks:

- valid scalar TypeIds and supported parameter flags;
- local names, duplicate names and conflicts with parameters;
- local initializers that exactly match the declared TypeId and refer only to earlier locals;
- assignments only to mutable locals and exact assignment TypeIds;
- `bool` conditions and paired then/else regions;
- resolved call target, same-module restriction, non-generic function kind, exact argument count/types and exact return TypeId;
- parameter/local binding ownership and expression-tree membership;
- one explicit terminal return whose value TypeId matches the function return TypeId (or `returnVoid()` for `void`);
- maximum expression/statement nesting and statement-count limits.

Mutation is represented as an explicit statement in the generated body. The `TypedAstNode` expression tree itself remains immutable. `SemanticModel::validate()` rechecks statement targets, mutability, TypeIds, conditions, nested branches and expression ownership before Codegen.

## 5. Codegen behavior

The Codegen bridge projects each generated local into a normal FAC local declaration. Immutable locals become `const`; mutable locals remain assignable. Assignment statements are projected to ordinary assignment-expression statements. `if/else` regions become ordinary backend `NK::If` and `NK::Block` nodes, then use the existing LLVM branch/basic-block lowering path.

A generated function with a body is emitted as an internal module-qualified LLVM definition, for example:

```llvm
define internal i32 @fac.generated_body_app.generatedSelect(i32 %p0)
```

Nested branches emit LLVM conditional branches and basic blocks. A generated function without a body remains a deterministic external C-ABI prototype using a `facgen_<module>_<name>_<signature-hash>` symbol, and its implementation must be supplied by linked native code. A body-bearing generated function does not use the external C-ABI prototype.

The bridge uses temporary synthetic `Program` objects. It does not append projected nodes to the source Program. The body builder validates the typed statement contract and Codegen applies the existing backend checks; this still does not run a full second HIR name-resolution, overload, ownership or effects-analysis pass over generated declarations.

## 6. Not included

- FAC syntax or `consteval` access to AST/declaration/body builders;
- assignment to parameters, compound assignment, increment/decrement or mutable aggregate values;
- branch-local declarations, lexical scopes introduced by generated blocks or local shadowing;
- `if` without `else`, branch-local returns, multiple return paths or general control-flow graphs;
- `while`, `for`, loops, `break`, `continue`, `switch`, `match`, exceptions or `defer`;
- generated function bodies with strings, null, tuples/aggregates, pointers, references, structs, arrays or function values;
- constructors, methods, lambdas, generated classes, generic generated functions or generic/cross-module generated calls;
- implicit conversions, overload selection, default-argument filling, ref/variadic/noescape/readonly parameters;
- source-level typed AST/declaration builders, general macros or arbitrary compile-time execution;
- full post-generation HIR/type/effect/ownership re-analysis.

## 7. Regression coverage and validation snapshot

`tests/semantic/generated_function_body.cpp` creates generated functions for arithmetic, nested direct calls, mutable locals, assignment in both branches, nested `if/else` and a single terminal return. It verifies rejection of return-TypeId mismatch, use-before-declaration, assignment to immutable locals, assignment TypeId mismatch, non-bool conditions and incomplete `if/else` regions. It also checks the emitted LLVM IR for function definitions, arithmetic, nested calls, comparisons, conditional branches and stores; Clang compiles the resulting LLVM IR when available. The original source Program is checked for immutability.

Validation commands used for this update:

```sh
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O0 -g0' -j1
make runtime-only CXX=g++ CXXFLAGS='-std=c++17 -O0 -g0' -j1
sh tests/comptime/run.sh
sh tests/parser/run.sh
sh tests/codegen/run.sh
g++ -std=c++17 -O0 -g0 -I. tests/semantic/generated_function_body.cpp \
  -o /tmp/fac_generated_function_body
/tmp/fac_generated_function_body /tmp/generated_function_body.ll
clang -Wno-override-module -x ir -c /tmp/generated_function_body.ll \
  -o /tmp/generated_function_body.o
```

On the recorded Linux source snapshot, compiler-only and runtime-only builds passed; compile-time tests passed 57/57; parser regression passed 68 checks; Codegen constant-fold and recursion-guard tests passed; the generated-function-body HIR fixture compiled/ran at GCC C++17 `-O0` and its LLVM IR compiled with Clang. Six existing targeted HIR fixtures (`hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir` and `typed_decl_builder`) passed individually at GCC C++17 `-O0`. The legacy runtime suite was started at both `-O0` and `-O2` but exceeded the local command time budget before printing a completion summary, so neither full runtime-suite pass is claimed. A combined generated-declaration semantic run also exceeded the local command limit while compiling its next fixture. The attempted GCC `-O2` build of the large generated-function fixture exceeded the command time budget; the targeted `-O0` run is the verified result. These are Linux-host checks, not cross-platform qualification.
