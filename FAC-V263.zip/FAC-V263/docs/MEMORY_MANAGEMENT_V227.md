# FAC Memory Management Direction — V227

V227 strengthens the local nested-borrow graph used by strict ownership analysis. A nested reborrow is now validated as an explicit edge from its parent loan before the child alias is installed.

## 1. Parent-edge invariants

Each reborrow edge must retain the same original storage identity as its parent. When the parent has an exact metadata-validated field projection, the child projection must remain at that path or a descendant path; a child cannot move sideways to a sibling or escape to an unrelated owner. The check also requires the parent's lexical loan region to outlive the child's region.

The checker walks the existing parent chain before inserting the edge. A missing parent record, repeated node/cycle, or edge that changes the root owner is rejected. This makes the loan-parent relationships an explicitly validated DAG rather than relying only on later overlap checks.

## 2. Nested aggregate paths

The graph works with the existing metadata-resolved `StoragePath` model. For example, a local chain such as `rootView -> branchView -> leafView -> leftView` retains one original storage owner while progressively narrowing the field projection. Independent sibling leaves can be borrowed mutably at the same time; overlapping leaf borrows remain rejected. When a grandchild loan remains live, its intermediate and root aliases remain suspended even if their names are no longer used directly.

Dynamic or otherwise inexact child projections are only allowed beneath the known exact parent path and continue to use conservative overlap rules. This does not make arbitrary indexes precise.

## 3. Regression coverage

V227 adds three-level nested-struct borrow cases covering: disjoint sibling leaves through multiple parent aliases; NLL retention of otherwise-unused parent aliases while a grandchild remains live; rejection of two mutable loans for the same leaf; and rejection of direct parent access while a grandchild mutable reborrow remains active. The existing field-sensitive suite is expanded to 25 checks.

## 4. Explicit boundaries

This is a local loan-graph validation improvement, not a general heap borrow graph. The checker still does not permit local ref bindings to escape into aggregate fields, globals, containers or closures; it does not cross separately shareable nested `obj` or weak-object boundaries. Unknown/dynamic projections remain conservative. It does not change ARC, Cycle Collector, allocation, Runtime, public API, C ABI or Runtime ABI behavior, and it is not a whole-program concurrency/data-race proof.

## 5. Validation

V227 was built on Linux with GCC C++17 using the repository Makefile (`-O1` compiler, `-O2` Runtime defaults). The expanded field-sensitive borrow suite passed 25 checks; the complete ownership script passed 261 checks (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract and 13 function-effect checks); the lifetime suite passed 65 checks; move/partial-move passed 48 checks; `--memory-safe` passed 39/39; parser passed 68 checks plus AST model regression; lexer passed 18 checks; focused codegen checks passed; secure-profile passed 6/6. `make api-check` passed standards, manifest, API audit/contract and generated-doc checks; compatibility audit against V128 reported 0 breaking changes and 132 warnings. the version-bump unit tests passed 2/2. `tests/tools/test_tools.py` exceeded the local command time limit during execution, so its full 91-test result is not claimed for V227. Full legacy-suite, sanitizer, cross-platform and complete runtime qualification are not claimed.
