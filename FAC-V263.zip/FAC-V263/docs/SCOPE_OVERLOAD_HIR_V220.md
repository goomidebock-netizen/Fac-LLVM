# FAC V220 Scope and Overload HIR (development)

## Lexical scopes

`fac_hir::LexicalScopeResolver` builds a scope tree over the existing AST while
retaining the AST as the source of truth. Scope kinds are `Module`, `Function`,
`Block`, `Loop`, `Lambda`, `Catch` and `MatchArm`. Each scope has a stable
`ScopeId`, parent scope, owning declaration and module name.

Parameters, local declarations, foreach variables, catch bindings and match
payload bindings receive stable `LocalSymbolId` records. The records retain the
source declaration, type (when known), const/reference flags, source location,
owner declaration and source-order index. Identifier expressions bind to the
nearest visible local. A later declaration does not shadow a name before its
declaration point; a nested block can shadow an outer local without changing
the outer binding after the block.

The initializer of a local is visited before that local enters scope. A local
whose declared type is `auto` can inherit its initializer's type after the
first overload pass makes that initializer type known. Expression types are
then refined and overload selection runs again to permit calls using inferred
locals.

## Free-function overload resolution

`fac_hir::OverloadResolver` resolves direct non-generic free-function calls and
statically identifiable class method calls. Free-function candidate lookup
supports the current module, imported modules, module aliases, `just`/`without`
filters and public visibility for imported functions. Method lookup currently
uses a known class receiver or a same-module static type name.
Local value names shadow same-named free functions at the source use site.

Candidate matching checks required/default parameter counts, argument types,
exact semantic type identity and conservative numeric widening. The storage
kind `var` is normalized to the default value category for overload comparison;
`ptr`, `dyn`, `heap`, lifetimes and function effects remain distinct. A unique
lowest-cost candidate is selected. Ties are `Ambiguous`, incompatible candidate
sets are `NoViableCandidate`, and candidates that need unsupported generic
inference or unknown argument types remain `Deferred`.

## Deliberate limits

This pass does not emit diagnostics and does not replace Codegen's own call
checking. Generic free functions are deferred. Method calls additionally
support explicit named type arguments, `auto` inference from direct/list/array
argument positions, generic class receiver substitution, and known built-in or
named interface/base constraints. Unsupported or unproven generic evidence is
kept `Deferred`; a proven constraint violation is recorded as a constraint
failure. Indirect function-value calls, receiver conversions, inherited method
lookup, full access-control validation, variadic ABI conversions and argument
conversion diagnostics are not yet migrated. Those features need dedicated
semantics and tests before Codegen can stop being authoritative.

## Regression coverage

`tests/semantic/scope_overload_hir.cpp` verifies nested block shadowing,
source-order declaration visibility, parameters, `for-each` locals, catch and
match bindings, inferred locals, exact and widening overloads, imported module
aliases, default arguments, ambiguous/no-viable calls, generic free-function
deferral and local-callable shadowing. The same executable is registered as
`scope-overload-hir-regression` in CMake and run by `tests/semantic/run.sh`.
