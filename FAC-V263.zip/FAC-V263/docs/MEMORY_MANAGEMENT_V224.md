# FAC Memory Management Direction — V224

V224 extends the bounded pointer-return lifetime-elision rule to a narrow multiple-pointer-input case. It remains Ownership/Lifetime analysis in the compiler; Runtime, ARC, Cycle Collector, public API and ABI are unchanged.

## 1. Return-source-directed lifetime elision

A source-defined FAC function returning `ptr T` may now omit an explicit named return lifetime when it has more than one pointer parameter only if all of the following hold:

1. Exactly one pointer parameter is eligible as the return source: it is not marked `noescape`, has no default value and is not variadic.
2. Every other pointer parameter is marked `noescape`. Its function body is checked, so passing that pointer to a retaining/unverified call violates the `noescape` contract.
3. At least one explicit non-null `return` exists, and every explicit non-null `return` in the function body directly names that same eligible pointer parameter. Explicit `return null` is allowed because it has no referent. Returns inside nested lambda bodies are not treated as returns from the containing function.
4. The function has a body, is not `extern` or `abstract`, returns a raw pointer without an explicit lifetime annotation, and declares no named function lifetimes.

When the rule applies, the compiler synthesizes a single abstract return lifetime for the identified source parameter, checks the function body against that region, and carries the same parameter selection into direct-call lifetime validation and pointer provenance propagation.

## 2. Cases that remain conservative

The compiler does not infer through a local pointer alias, helper call, field/index load, pointer arithmetic, cast, conditional/computed expression, or an unresolved return expression. Multiple non-`noescape` pointer parameters remain ambiguous even if a particular test call passes equal or same-scope addresses. A `noescape` parameter cannot be the inferred return source. If a secondary `noescape` parameter is passed to a retaining or unverified call, the body check rejects it.

Extern/abstract declarations, function-value/callback type shapes, functions with explicit named lifetimes and functions with unmodeled pointer-return shapes do not receive this inference. Existing explicit `lifetime<...>` and `where` contracts are unchanged. The single-non-`noescape`-pointer-parameter V222 rule remains supported.

## 3. Example

```fac
function ptr int firstOrNull(ptr int first, noescape ptr int scratch, boolean useFirst) {
    if (useFirst) { return first }
    return first
}
```

The return source is unambiguous: both non-null returns name `first`, while `scratch` is required to be non-retaining and its body contract is verified. At a direct call, the result inherits provenance only from the `first` argument. This does not mean the compiler accepts arbitrary multi-pointer return functions.

## 4. Compatibility and scope

No FAC syntax, Runtime implementation, public API, C ABI or Runtime ABI changed. This is a compile-time-only extension of direct-call lifetime contracts. It does not add reference-valued aggregate fields, general heap borrow graphs, arbitrary alias analysis, complete lifetime inference, raw-pointer support in `--memory-safe`, whole-program data-race freedom, or a Rust-equivalent safety guarantee.

## 5. Validation

The V224 lifetime regression suite contains 46 passing checks, including a positive two-pointer case with one verified `noescape` input and a shorter-lived scratch argument, a negative case with two possible return sources, and a negative case that attempts to pass the `noescape` input to a retaining/unverified call. The V223 baseline lifetime suite contained 42 passing checks. The V224 memory-safe suite remains unchanged at 39/39 because raw pointers and `addr` are excluded from that profile. These results are focused Linux-host tests; they are not a full compiler/runtime, sanitizer, cross-platform or formal memory-safety qualification.

See [`MEMORY_MODEL.md`](MEMORY_MODEL.md), [`OWNERSHIP.md`](OWNERSHIP.md), and the `v224_multi_pointer_elision_*` fixtures under `tests/lifetimes/`.
