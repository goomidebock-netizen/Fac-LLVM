# FAC Memory Management — V257

## Auto-return enum payload pointer rejection

V257 closes a strict-ownership gap for functions whose declared return type is
`auto`. The parsed function signature still carries `auto` while the local
borrow checker validates return escapes, so a check that only inspects an
explicit `ptr T` return type cannot recognize every inferred pointer return.

The checker now retains enum variant payload type metadata and inspects the
bounded result-producing expression forms `match` and `ifv / eiv / elv`. When
an expression directly returns a match binding whose declared payload is a
raw `ptr` type, the compiler rejects the return because pointer provenance
through enum payload storage is not tracked. The check also covers a `match`
nested in a conditional result arm.

The analysis remains value-sensitive:

- Scalar enum payloads returned from `auto` functions remain accepted.
- A pointer payload used only in a comparison/result condition is not treated
  as the pointer returned by the function.
- Match scrutinees, patterns and guards do not become return-value origins.
- Nested lambda/function return domains remain independent.

This is a fail-closed guard, not general enum payload provenance tracking. It
does not implement `ref T` returns, whole-program heap escape analysis, or a
complete borrow checker. Generic enum payload parameters and unknown/ambiguous enum payload layouts are
treated conservatively for this bounded auto-return check.

## Validation

The V257 lifetime suite adds four regressions:

- Direct `auto` return of a raw enum pointer payload is rejected.
- An `auto` return with a pointer payload nested under `ifv` is rejected.
- A scalar enum payload returned from `auto` remains accepted.
- A pointer payload used only to compute a boolean condition remains accepted.
- A generic enum instantiated with a pointer payload is rejected conservatively.
