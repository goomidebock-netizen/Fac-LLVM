# FAC Language Core — V183

## Scope

V183 is the next sequential release after V182. It extends field-sensitive local borrowing to a deliberately narrow indexed-storage case.

## Implemented

- Fixed-size `array` storage rooted at a tracked named local can use a non-negative integer literal index as an exact borrow projection.
- Different constant indexes are disjoint, including multi-digit values such as `[1]` and `[10]`.
- Equal indexes conflict when an overlapping mutable/shared loan is still live.
- Whole-array access overlaps every element; distinct element indexes do not overlap.
- The same projection model is used for loan creation, owner reads/writes, reborrows and active-loan overlap checks. Arrays of structs remain unsupported by the current compiler and are not enabled by this release.
- Index-expression operands are still checked as expressions; checking a precise array element no longer rechecks its named base as a whole-array read.

## Conservative boundary

The analysis does not make these paths exact: variable or computed indexes, negative indexes, lists, matrices, pointer indexing, computed/function-returned bases, untracked storage, globals/statics and opaque aliases. These remain conservative may-alias paths. The change does not add indexed move semantics, reference-valued fields/containers, reference return/store types, general lifetime parameters, raw-pointer alias proofs or Rust-equivalent memory safety.

## Compatibility

No syntax, code-generation layout, Runtime source, public API, C ABI or Runtime ABI changed. The new behavior is part of the existing opt-in strict local-borrow analysis (`--strict-ownership` and the existing secure profile). Default legacy compilation behavior is unchanged. Array bounds checking remains in the existing code-generation path.

## Regression coverage

- `good_array_disjoint_indices.fac`: simultaneous mutable borrows at indexes 1 and 10, followed by a sibling owner write/read; runtime output validates the aliasing behavior.
- `bad_array_same_index.fac`: two live mutable borrows at the same index are rejected.
- `bad_array_dynamic_index.fac`: dynamic indexes remain conservative and conflicting live borrows are rejected.

The release record in `docs/STATUS.md` records the exact build and test results actually run for this archive.
