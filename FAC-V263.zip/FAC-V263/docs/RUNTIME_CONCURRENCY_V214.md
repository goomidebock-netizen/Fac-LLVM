# V214 Runtime concurrency safety: Autograd and ML inference

## Autograd tapes are thread-confined

`autograd.create` and `autograd.tensorCreate` capture the creating `std::thread::id` in their opaque Runtime handles. Every scalar and tensor tape operation checks that owner before reading or mutating the tape. `autograd.free` and `autograd.tensorFree` apply the same check before releasing it. A cross-thread operation or release throws FAC `Error` code **16 (`Concurrency`)**. The check occurs before node-vector access, so a foreign worker gets a deterministic FAC error instead of racing a mutable vector.

Create one scalar/tensor tape per worker. A tape may be used, differentiated and freed by its creator thread. The owner check does not provide a general handle-lifetime registry: callers must not race a handle's release against any in-flight operation, including an operation from the owner thread. Likewise, any input Tensor copied into a tape must remain valid while the creating-thread API call is in progress.

No lock is held around Autograd operations. FAC Runtime errors use `setjmp`/`longjmp`; holding a C++ mutex across an operation that can throw this way could leave the lock permanently held. Thread confinement is the fail-closed policy for mutable tapes.

## Immutable fitted ML inference can be shared

After a successful fit, Linear/Ridge/Logistic, K-means and KNN model state is read-only during prediction. Multiple threads may call the corresponding prediction API on the same completed model concurrently, provided:

- no thread trains, mutates, or frees the model while prediction is in flight;
- the input Tensor is not modified or freed while prediction is in flight; and
- each prediction result is treated as independently owned by the calling thread and released with `tensor.free`.

This is a read-only inference guarantee, not blanket thread safety for the full ML module. Model construction, model release, Tensor mutation/release, optimizer state, DataFrame mutation and other shared mutable handles remain subject to caller synchronization.

## Regression coverage

`tests/runtime/ml_autograd_concurrency.cpp` exercises foreign-thread scalar/tensor tape use and free (expected `Concurrency`, code 16), verifies the owner can continue to use and free each tape, creates independent scalar/tensor tapes in worker threads, and runs 8 workers × 24 rounds of Linear/K-means/KNN prediction over shared fitted model handles and a shared read-only input Tensor. Every prediction is compared with a single-thread baseline. The same test is included in the Runtime regression runner and focused ThreadSanitizer runner.

This release's stress test does not race model or Tensor destruction against active predictions. That lifetime pattern is not supported or claimed safe. On the Linux x86-64 GCC validation host, `tests/runtime/run_tsan.sh` completed successfully with the V214 test included and emitted no ThreadSanitizer diagnostics. ASan/UBSan and cross-platform qualification are not claimed.
