# FAC Language Core V204 — Call-Site Lifetime Contract Checking

## Scope

V204 extends the V203 named-lifetime and pointer-provenance checker from function bodies to resolved direct calls. It uses the existing `lifetime<...>`, `ptr<name> T`, `where longer: shorter`, and `noescape` declarations; no new FAC syntax is introduced.

## Call contract representation

For each direct function candidate, the compiler records:

- The ordered named lifetime parameters and their outlives edges.
- The lifetime-parameter index attached to each pointer parameter.
- The lifetime parameter associated with a pointer return, when present.
- Existing `noescape`, `ref`, and parameter type information.

A lifetime contract is used for call-site checking only when all resolved overload candidates share the same lifetime names, edges, return lifetime, and parameter lifetime-index pattern. Otherwise, the checker keeps the prior conservative behavior rather than assuming one candidate's contract applies to every possible target.

## Substitution at the caller

At a call site, the checker collects the possible pointer origins for each annotated argument and maps those origins to the caller's concrete lexical/abstract regions. Arguments assigned to the same named lifetime parameter must have one representable common region; when different nested regions are supplied, that common region is the shorter region that every possible origin outlives. The checker then validates each callee `where longer: shorter` edge against the caller's region graph. Reachability is transitive, so constraints may be satisfied through more than one edge.

If a required argument's actual provenance is unknown or cannot be represented as a caller region, the contract fails closed. A literal `null` has no referent and does not manufacture a shorter-lived origin.

## Pointer return provenance

When a resolved direct call returns a named-lifetime pointer, the call expression inherits origins only from pointer parameters whose declared lifetimes can outlive the declared return lifetime, following the callee's transitive `where` graph. Parameters marked `noescape` are excluded. This avoids combining unrelated pointer arguments into the provenance of the returned pointer.

If the call does not expose one unambiguous lifetime contract or has no named return lifetime, the previous conservative provenance behavior remains in place.

## Example

```fac
function lifetime<a, b> ptr<a> choose(ptr<a> int preferred, ptr<b> int other) where a: b {
    return preferred
}

public function void main() {
    var int longLived = 41
    ptr int longPtr = addr(longLived)
    {
        var int shortLived = 9
        ptr int shortPtr = addr(shortLived)
        ptr int selected = choose(longPtr, shortPtr)
        if ([selected] != 41) { throw "wrong result provenance" }
    }
}
```

The call is valid because the caller's region for `longPtr` outlives the region for `shortPtr`, satisfying the callee's `where a: b` contract. Reversing the arguments violates that relationship and is rejected at the call site.

## Explicit limitations

- This milestone covers resolved direct calls. Indirect calls and function-value invocation retain conservative handling.
- Ambiguous overload sets are not assigned a guessed lifetime contract; candidates must agree exactly.
- Lifetime annotations remain limited to direct pointer types in function signatures; extern/function-value lifetime signatures are not added here.
- Pointer provenance stored in aggregate fields or arbitrary containers is not modeled by this change.
- The checker does not attempt general interprocedural inference or prove arbitrary aliasing relationships.
- Runtime behavior, Runtime source, and Runtime ABI are unchanged; the checks happen before code generation.

This is a conservative extension of FAC's current lifetime analysis, not a complete general-purpose borrow checker.

## Validation

`tests/lifetimes/run.sh` includes positive checks for transitive call-site outlives substitution, same-lifetime argument unification, nested wrapper calls, and precise pointer-return source propagation. It includes negative checks for reversed outlives arguments and untracked pointer provenance. `docs/STATUS.md` records the broader compiler, language-core, and Runtime regression results for this milestone.
