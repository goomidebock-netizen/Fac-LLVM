# FAC Language Core V202 — Lifetime Outlives Relationships

## Scope

V202 extends V201's named lifetime binding with explicit relationships between declared lifetime parameters. The relationship is recorded in the function AST as pairs of stable parameter indices.

## Syntax

Place a `where` clause after the function parameter list and before any trailing function qualifiers or body:

```fac
function lifetime<a, b> ptr<b> shorten(ptr<a> int value) where a: b {
    return value
}
```

The clause `a: b` means that lifetime `a` outlives lifetime `b`. Multiple clauses are comma-separated:

```fac
function lifetime<a, b, c> ptr<c> shorten(ptr<a> int value) where a: b, b: c {
    return value
}
```

All names in the clause must be declared by the function's `lifetime<...>` list. A repeated directed edge is rejected. The `where` keyword is reserved for this syntax.

## Relationship semantics

- Every lifetime outlives itself (reflexivity).
- A declared edge `a: b` means `a` outlives `b`.
- Relationships compose transitively: `a: b` and `b: c` imply `a: c`.
- A pointer parameter annotated with lifetime `a` can supply a pointer return annotated with lifetime `b` only when `a` outlives `b`.
- The reverse direction is not permitted unless separately established by the declared relationships.
- Cycles are treated as mutually-outliving lifetimes; self-edges are harmless but redundant.

The AST stores each relationship as `(longerIndex, shorterIndex)` in `Node::lifetimeOutlives`, and AST cloning copies the relationships. The parser validates the return signature using reachability over these edges.

## Explicit limitations

V202 checks signature relationships only. It does not yet prove that a returned expression actually originates from the pointer parameter that supplies the declared lifetime. It does not yet instantiate lifetime relationships at call sites, infer caller/callee outlives constraints, or change local pointer escape analysis. The relationship contract therefore must not be interpreted as completed borrow-checker proof of function-body provenance. Annotations remain limited to the direct pointer forms supported in V201; extern declarations and function-value signatures are not expanded by this release.

## Validation

Parser regression now covers direct and transitive outlives relations, correct directionality, unknown names, missing declarations, duplicate constraints, and AST cloning. The focused parser suite reports **58 checks passed**. Full build and CTest results are maintained in `docs/STATUS.md`.
