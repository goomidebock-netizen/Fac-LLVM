# FAC V220 Semantic Diagnostics HIR (development)

## Purpose and migration boundary

The semantic frontend stores structured, source-mapped diagnostic records in
`fac_hir::SemanticModel`. The collector currently focuses on generic free-
function call resolution, whose outcomes can be determined conservatively from
the declaration and expression HIR. These records are analysis metadata only:
they are not printed by the compiler driver and do not replace Codegen's
existing user-facing error decisions.

## Record model

Each `SemanticDiagnostic` contains:

- a stable diagnostic code;
- `Note`, `Warning` or `Error` severity;
- a concise message;
- file, module and line source location;
- the associated `ExprId` when the diagnostic originates from an expression.

`SemanticModel::validate()` verifies source and expression references and
checks the aggregate note / warning / error counts. The collector rebuilds the
list deterministically during semantic analysis.

## Current diagnostic codes

| Code | Severity | Meaning |
|---|---|---|
| `FAC-HIR-GEN-INFO-001` | Note | Generic free-function type arguments inferred from arguments |
| `FAC-HIR-GEN-INFO-002` | Note | Inference deferred because type evidence is incomplete |
| `FAC-HIR-SEM-ERROR-001` | Error | Generic free-function call is ambiguous |
| `FAC-HIR-GEN-ERROR-001` | Error | Known generic constraint failure |
| `FAC-HIR-SEM-ERROR-002` | Error | No generic free-function candidate accepts known argument types |

A `Deferred` result is not treated as a definite error. A constraint is marked
failed only when the available declaration/type evidence proves that it cannot
be satisfied.

## Next migration steps

Before these records become CLI diagnostics, the frontend still needs broader
coverage for method and indirect calls, member/index expressions, argument
conversion ranking, generic inference through arbitrary nested type
constructors, and stable diagnostic ordering/wording across all existing
negative tests. The driver must then compare new semantic diagnostics against
Codegen diagnostics and suppress duplicates while preserving current compiler
behavior. Codegen remains authoritative until that migration is complete.

## Regression

`tests/semantic/generic_free_function_hir.cpp` checks diagnostic codes,
severity counts, source locations and expression references for inferred,
deferred, ambiguous, no-viable and constraint-failure generic calls. CMake
registers it as `generic-free-function-hir-regression`.
