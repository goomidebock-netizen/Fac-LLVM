# FAC Memory Management — V261

## Owned thread-handle provenance through nested value-struct moves

V261 makes a narrow extension to `--strict-ownership` for the owned handle
returned by the exact qualified call `thread.start`. The API manifest declares
that result as an `owned-handle` released by `thread.join`, and the Runtime
allocates the thread handle independently of the caller's stack frame. The
checker now records a distinct root-region origin for that result so it can be
stored in a local value-struct pointer field and transferred through explicit
`move(...)` operations, including nested value structs.

The matching exact qualified call `thread.join` is treated as consuming its
single `ptr thread` argument, consistent with the API ownership contract that
it joins and frees the handle. This permits a typed handle field from a
by-value value-struct parameter to be passed to `thread.join`; it does not
classify `thread.join` as a general noescape or lifetime contract for arbitrary
pointers. The special case is restricted to argument zero of the exact
`thread.join` call and the static type `ptr thread`.

The checker also treats the language intrinsic `move(value)` as a transfer
operation rather than as an ordinary potentially escaping function call. The
source expression is still checked, and the existing active-loan prohibition
for moves remains in force. This avoids incorrectly invalidating verified
field provenance merely because a checked aggregate is moved.

The boundary remains deliberately narrow. An arbitrary incoming `ptr thread`
parameter with unknown provenance is still rejected when stored in a local
value-struct field. This does not add general heap escape analysis, general
resource-handle tracking, automatic join insertion, general interprocedural
aggregate summaries, alias analysis, or a complete borrow checker. In
particular, nested helper summaries that need to reconstruct pointer-field
provenance across multiple by-value struct parameters remain incomplete. It
does not prove data-race freedom or validate arbitrary handle values at
runtime. No source syntax, Runtime semantics, ARC/GC behavior, public API, ABI,
or `--memory-safe` accepted subset is changed.

## Validation

- Compiler and Runtime archive build: Clang 17, C++17, `-O0 -g0`; succeeded.
- `facc --version` and `tools/check_versions.py`: FAC/Core/Lib/API/Lang/Runtime/Stdlib all V261.
- Lifetime regression runner: 147 PASS, 0 FAIL. New tests cover nested
  value-struct handle moves, fail-closed rejection of an arbitrary incoming
  `ptr thread`, and consumption of a typed handle field by `thread.join`.
- Safe Profile: 435 passed, 2 failed. Both remaining V76 checks concern
  unverified nested aggregate-field provenance in helper summaries; the V75
  struct-move checks that failed in V260 now pass.
- Ownership suites: Ownership 12/12; const-method ownership 8/8; local borrow
  167/167; noescape 17/17; field-sensitive borrow 25/25; effect contract
  19/19; function-effect 13/13.
- Move 20/20; Partial Move 28/28; Compile-time 57/57; Memory-Safe 39/39;
  Generic 3/3; Lexer 18/18; Parser 68 checks; AST model 1/1; Codegen checks
  passed.
- API check: 663 built-ins and 1,014 source declarations audited; 5 findings,
  0 beyond baseline. Strict contract audit covered 950 public functions with
  0 missing required annotations. Compatibility against V128: 0 breaking
  changes, 132 warnings. Generated API docs: 114 files up to date.
- Standards check: 5 OS families and 6 architecture families passed.
  Formatter check passed.
- Runtime tests produced PASS results for the cases completed in the run log,
  but the complete chained Runtime/Semantic/Tools command exceeded its time
  limit; a complete Runtime runner exit status is therefore not claimed.
- Semantic suite: 17 ancestry checks passed before the run timed out; full
  Semantic success is not claimed. Tools suite also timed out before a
  complete result was collected.

Full CMake/CTest, ASan/UBSan/TSan, actual Windows/macOS builds and runtime
qualification, and production qualification are not claimed.
