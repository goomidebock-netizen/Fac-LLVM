# Typography and text layout (V116)

FAC keeps its small built-in 3×5 bitmap font for games and pixel-art output. Since V195, `graphic.text()` and the reusable UI renderer use normal system typography by default. A dynamically loaded Pango/Cairo/Fontconfig backend supplies vector metrics, shaping and anti-aliased glyph coverage on POSIX hosts; Windows uses native GDI with Segoe UI preferred.

## Default UI font (V195)

The reusable canvas UI (`render.text`, `ui.text`, `ui.title`, labels, buttons and controls) now selects a native/system sans font by default and uses anti-aliased vector glyphs when the host backend is available. Windows uses GDI with Segoe UI preferred; Linux/macOS use Pango/Cairo/Fontconfig with `Sans` and normal system fallback. The `graphic.systemTextAvailable()` query reports backend availability. No custom font asset is required for this default path.

If the native backend is unavailable, UI text falls back to the legacy bitmap renderer. On Linux/macOS, install the Pango, Cairo and Fontconfig runtime libraries to enable vector output. For a specific TTF/OTF face, applications may continue to use the explicit `font.load()` / `font.draw()` API. `graphic.text()` and `render.text()` use the system-font path. Use `graphic.bitmapText()` / `graphic.bitmapTextWidth()` when the legacy pixel font is required.

## Loading a font

```fac
import font.fac
import graphic.fac

public function void main() {
    if (!font.backendAvailable()) {
        # Keep the application usable on systems without Pango/Cairo.
        ptr font fallback = font.create(2)
        font.free(fallback)
        return
    }

    ptr font face = font.load("assets/fonts/Interface-Regular.otf", 22)
    terminal.out.println(font.family(face), " ", font.size(face), "px")
    ptr graphic canvas = graphic.create(480, 160)
    graphic.clear(canvas, graphic.rgb(248, 249, 252))
    font.draw(canvas, face, 16, 16, "สวัสดี FAC — Typography", graphic.rgb(30, 36, 48))
    graphic.save(canvas, "typography.png")
    graphic.free(canvas)
    font.free(face)
}
```

`font.load(path, size)` accepts a local regular TTF/OTF file and a pixel size from 1 to 512. On Linux it registers the font file with the process-local Fontconfig configuration, finds the font family and creates a Pango layout. It does not copy or install the font into the operating system. The application remains responsible for shipping fonts and complying with each font's licence.

`font.backendAvailable()` reports whether the runtime libraries needed for the vector backend were found. The backend is optional and dynamically loaded, so the compiler and Runtime do not require Pango development headers or link-time Pango libraries. If the backend is unavailable, `font.create(scale)` and the bitmap renderer continue to work; `font.load` raises a Media error rather than silently returning a bitmap font.

The vector APIs are `font.family`, `font.size`, `font.isVector`, `font.setSize`, `font.measure`, `font.height`, `font.draw` and `font.free`. `font.setScale` is for bitmap handles only. Measurement returns the maximum pixel width of the layout; invalid UTF-8 or text over 1 MiB returns zero. Height is the Pango logical height for a representative line. Drawing uses the same layout metrics and alpha-blends glyph coverage into the software canvas; invalid UTF-8, oversized text or an excessive raster area raises a Media error. Multi-line strings are handled by Pango.
On the Linux/macOS Pango backend, Runtime calls that operate on font handles are serialized by a process-wide backend lock. This includes loading/registering faces, layout creation, `font.setSize`, `font.measure`, `font.height`, `font.draw`, metadata queries and `font.free`. A live `FacFont` may therefore be used by multiple threads without racing its mutable Pango layout; vector-font operations on different handles are also serialized. Keep the handle alive until all concurrent calls have returned: freeing a handle while another thread may still be using it remains unsupported. Canvas buffers are separate caller-owned state and must not be concurrently modified/read without their own synchronization. Backend serialization is a safety measure, not a promise of parallel font-rendering throughput.

The V116 backend has been exercised with TTF and OTF files, including Thai Waree OTF. Pango supplies shaping and glyph fallback for the selected font environment, so Thai vowel/diacritic placement is handled by the shaping engine rather than by FAC's old bitmap cell advance. Actual coverage still depends on installed or registered fallback fonts. This does not claim full Unicode UAX #29 segmentation or equivalent output across different font installations.

## `typography.TextLayout`

Import `typography.fac` and call `reflow(text, width, scale, lineGap)` for the default system-font renderer, or `reflowWithFont(text, width, face, lineGap)` for a caller-owned font handle. The latter calls `font.measure` for word wrapping and `font.draw` when painting, so measurement and output use the same font metrics. Variable-width glyphs are supported; long unbroken tokens are divided at the runtime's supported grapheme boundaries using measured candidate widths.

```fac
import font.fac
import graphic.fac
import typography.fac

public function void main() {
    ptr font face = font.load("assets/fonts/Interface-Regular.otf", 22)
    obj typography.TextLayout paragraph = new typography.TextLayout()
    paragraph.reflowWithFont("A paragraph with Thai: ภาษาไทย and a long_identifier_that_may_wrap.", 360, face, 4)
    ptr graphic canvas = graphic.create(400, 220)
    graphic.clear(canvas, graphic.rgb(250, 250, 252))
    paragraph.draw(canvas, 20, 20, graphic.rgb(32, 38, 50))
    graphic.save(canvas, "paragraph.png")
    graphic.free(canvas)
    font.free(face)
}
```

`TextLayout` borrows the font handle; it does not retain or free it. The font must outlive the layout and must not be changed/freed while the layout is being used. `reflow()` switches back to the default system-font renderer. The cached line strings and content metrics are rebuilt only when `reflow` or `reflowWithFont` is called.

## Current limits

- The V195 default UI path uses GDI on Windows for system fonts; the explicit `font.load()` TTF/OTF backend remains unavailable on Windows. Linux/macOS use Pango/Cairo/Fontconfig when the runtime libraries are installed. The macOS runtime path is not validated in this release.
- No native macOS/Win32/GTK controls, vibrancy/blur, retained component tree or accessibility tree is added.
- POSIX Pango vector-font operations are serialized by the V215 process-wide backend lock, including operations on the same live handle and different handles. Keep each handle alive until all calls using it have returned; concurrent `font.free()` with in-flight use remains unsupported. Canvas buffers still require caller-side synchronization when shared. The Windows GDI path is not covered by the V215 Pango change.
- Bitmap font coverage remains the legacy small glyph set; vector glyph coverage depends on the font and system fallback configuration.
- FAC's grapheme splitting remains a practical supported subset rather than a full Unicode UAX #29 implementation.
