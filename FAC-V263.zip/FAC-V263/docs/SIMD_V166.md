# FAC V166 — public two-lane CPU SIMD API

## Public surface

Import `simd.fac` and `gpu.fac`. Buffers are allocated with `gpu.createBuffer`; each element is a little-endian IEEE-754 binary64 value.

- `simd.widthF64()` returns the logical vector width (2).
- `simd.backend()` reports `x86-sse2`, `arm-advanced-simd`, `compiler-vector-128` or `scalar-fallback`.
- `simd.nativeF64x2()` reports whether the native 128-bit vector implementation was compiled in.
- `simd.addF64x2(dst, a, b, count)` computes `a + b`.
- `simd.subF64x2(dst, a, b, count)` computes `a - b`.
- `simd.mulF64x2(dst, a, b, count)` computes `a * b`.
- `simd.divF64x2(dst, a, b, count)` computes `a / b`.
- `simd.scaleF64x2(dst, src, count, scale)` computes `src * scale`.

The operation count is the number of float64 elements, not the number of vectors. It must be non-negative, even, and in range for every buffer. `count == 0` is valid. All output is staged and validated before commit. Invalid ranges, odd element counts, zero divisors and non-finite results return `false` without modifying any destination bytes. Input/output aliases, including `dst == a` or `dst == b`, are supported.

## Backend scope

This is a CPU SIMD API. It reuses the existing `gpu` buffer format to avoid a new storage ABI and is vectorized using the compiler's 128-bit vector extension on supported GCC/Clang x86-64 and AArch64 targets. Other builds keep a correct scalar fallback. The API does not promise a stable machine-vector ABI or expose a first-class vector value type.

V170 intentionally keeps this interface CPU-only. The experimental OpenCL device backend that was added in later releases has been removed: `gpu.hardware()` is always `false`, `gpu.backend()` is always `software-reference`, and the compatibility-only `gpu.openclStatus()` returns `disabled`. Do not interpret `simd.nativeF64x2()` as a GPU capability query.

## Tests

`tests/runtime/simd_language.cpp` covers all five arithmetic operations, zero-count no-op, negative/odd/out-of-range validation, two-lane width, aliasing, division-by-zero rejection and transactional overflow handling. `tests/api/a37_v166_simd_language.fac` validates that the new API is callable from FAC source and interoperates with `gpu.readF64`/`writeF64`.
