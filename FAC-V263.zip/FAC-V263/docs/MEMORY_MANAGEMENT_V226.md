# FAC Memory Management Direction — V226

V226 makes local value-struct pointer provenance field-sensitive. It replaces the V225 aggregate-root union with facts keyed by a local aggregate declaration and an exact metadata-validated field projection. This is a compile-time analysis improvement; it does not change ARC, Cycle Collector behavior, Runtime allocation, public APIs, C ABI or Runtime ABI.

## 1. Exact field provenance

For a checked local value struct, pointer origins are tracked independently for each pointer-bearing path, including nested by-value value-struct fields. A read of `pair.left` therefore uses the origins of `left`, not the union of `left` and `right`. Struct constructor arguments are associated with declaration-order fields retained from the AST. Copying a local value struct remaps the source's exact field paths to the destination, including nested paths.

A known-null pointer field is represented by an explicit empty provenance fact. This is intentionally distinct from a missing fact: an empty fact means the compiler verified that the field contains no tracked pointer origin; no fact means the compiler does not know where the pointer came from.

## 2. Overwrite / kill behavior

An assignment to a tracked pointer field removes the previous fact for that exact field before installing the new origin. Assigning `null` kills the old origin and records a known-null field. Replacing a nested value-struct field kills the old nested subtree before copying the new field facts. Replacing the whole local aggregate kills all previous field facts before rebuilding them from the new value.

This removes V225's conservative stale-origin behavior after field overwrites. It does not claim path-sensitive control-flow merging for every branch/loop shape; unsupported expressions remain conservative.

## 3. Missing provenance fails closed

The analysis must not interpret missing provenance as `null`. Reading a pointer field from a value-struct parameter or other aggregate source without verified field facts is rejected. Copying, passing or returning a pointer-bearing aggregate with incomplete field facts is also rejected. Constructors with untracked non-null pointer arguments remain rejected. Verified `null` field writes remain usable.

## 4. Remaining boundaries

The analysis remains limited to tracked local value structs and metadata-resolved by-value field paths. It does not add general heap-stored references, pointer-bearing `class` / `obj` fields, globals, containers, arbitrary indexes, alias-based stores, closure capture, unsafe/FFI provenance, or a general heap borrow graph. Managed-object boundaries remain outside this proof. `--memory-safe` continues to exclude raw pointer types and `addr`.

## 5. Validation

V226 adds regression cases for sibling fields with independent lifetime parameters, nested field paths, aggregate copies, pointer-field overwrite, null overwrite, unknown pointer-field reads, incomplete aggregate copies, the distinction between known-null and missing provenance, and nested aggregate replacement with verified all-null pointer leaves. On the delivered Linux host, GCC C++17 `-O0 -g0` Compiler/Runtime builds succeeded. The lifetime suite passed 65 checks; ownership suites passed 255 checks; move and partial-move suites passed 48 checks; `--memory-safe` passed 39/39; tools passed 91/91; parser passed 68 checks plus AST model regression; lexer passed 18 checks; focused codegen checks passed. The semantic suite was started but exceeded the available command time during the ancestry group; no complete semantic/full legacy-suite pass is claimed. Sanitizers, cross-platform builds and full runtime qualification are not claimed.
