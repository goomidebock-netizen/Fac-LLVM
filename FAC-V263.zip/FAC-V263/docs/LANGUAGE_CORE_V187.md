# FAC Language Core — V187

## Scope

V187 extends the bounded local-constant array-index subset to unsigned integer declarations. The purpose is to make strict local borrowing more precise for code that naturally uses FAC's unsigned integer types while keeping unknown or potentially wrapping expressions conservative.

## Implemented

- Visible initialized local `const ubyte`, `const ushort`, `const uint` and `const ulong` declarations may be used as fixed-array indexes when their initializer is proven by the checked integer evaluator.
- The resolved value must be non-negative and fit the declared 8-, 16-, 32- or 64-bit unsigned width.
- Chained constants are supported; exact declaration identity prevents a shadowed name from inheriting an outer binding's value.
- Different exact non-negative indexes are disjoint, and equivalent values produce the same projection and conflict when simultaneously mutably borrowed.
- Runtime tests verify borrowed references still write through to the original array storage.

## Conservative boundary

The projection evaluator stores indexes as `int64_t`, so unsigned `ulong` values above `INT64_MAX` cannot be represented and remain unknown/conservative. Unary negation of an unsigned constant is not folded. Negative results, values outside the declared unsigned width, uninitialized constants, mutable locals, parameters, globals/statics, calls, side effects and unsupported expressions remain unknown/conservative. The evaluator is not general constant propagation, general unsigned compile-time evaluation, dynamic range analysis or array bounds checking.

This release does not add indexed partial moves, reference return/store types, general lifetime parameters, general region/outlives inference, a complete borrow checker or a Rust-equivalent memory-safety proof. It does not change array layout, code generation, public API signatures or Runtime ABI.

## Regression coverage

- `good_array_const_unsigned_integer_indices.fac`: chained `const ubyte`, `const ushort`, `const uint` and `const ulong` indexes borrow distinct elements; runtime writes verify aliasing to original storage.
- `bad_array_const_unsigned_same_index.fac`: two unsigned constants resolving to the same index are rejected as conflicting mutable borrows.
- `bad_array_const_unsigned_negative.fac`: a negative initializer is not accepted as an exact unsigned index, so overlap remains conservative.
- Existing V182–V186 local-borrow positive and negative cases remain in the regression runner.

Validation results for this archive are recorded in `docs/STATUS.md`.
