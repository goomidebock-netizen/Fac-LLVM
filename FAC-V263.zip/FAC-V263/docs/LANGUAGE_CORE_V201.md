# FAC Language Core V201 — Named Lifetime Parameter Binding

## Scope

V201 advances the named lifetime syntax introduced in V200 from declaration-only metadata to signature-level binding.

### Syntax

A function may declare named lifetime parameters:

```fac
function lifetime<a, b> int select(int value) {
    return value
}
```

A direct pointer type in the function return type or parameter list may bind to one of those names:

```fac
function lifetime<a> ptr<a> int choose(ptr<a> int left, ptr<a> int right) {
    return left
}
```

The syntax is `ptr<name> T`. A type annotation is accepted only in a function signature and only for a direct `ptr T` type. The binder resolves the name against the function's declared lifetime parameter list and records its zero-based index in `TypeSpec::lifetimeParamIndex`; the original name remains in `TypeSpec::lifetime`. AST cloning preserves both fields.

### Validation rules

- Lifetime parameter names remain unique and cannot be reserved words or type names.
- Every annotated pointer type must refer to a lifetime declared by its enclosing function.
- A pointer annotation requires a `lifetime<...>` declaration.
- Only direct pointer types may carry annotations; arrays, lists, aggregate types and non-pointer kinds are rejected.
- A pointer return annotated with lifetime `x` requires at least one pointer parameter annotated with the same lifetime `x`.
- Multiple pointer parameters may bind to the same lifetime.

## Explicit limitations

V201 binds signature names to declared pointer types. It does **not** yet prove that a function body returns a pointer originating from a parameter carrying the annotated lifetime. It does not yet infer outlives relationships across function calls, relax conservative local-pointer escape checks, or introduce reference-valued return types. Those are later stages of the lifetime roadmap. V201 also does not yet expose lifetime annotations in `extern` declarations or function-value signatures.

## Validation

The parser regression suite adds positive binding/index assertions and negative checks for unknown names, missing function lifetime declarations, unmatched return lifetimes and non-pointer annotations. Linux x86-64 Debug build completed with GCC 14.2. The parser regression binary reports **45/45**, and CTest passed **29/29**. A sample annotated pointer-return function compiled with `--strict-ownership` and its executable exited with code 0. This validates parsing, signature binding and integration with the existing compiler pipeline; it does not establish body-origin checking or cross-function lifetime safety.
