# FAC `noescape` Pointer Contracts — V59

## Purpose

`noescape` is a compile-time parameter effect for raw pointer parameters. It promises that the callee does not retain the incoming pointer or any pointer value derived from it beyond the dynamic extent of the call.

The spelling is deliberately explicit and Java-like:

```fac
function void writeNow(noescape ptr int destination) {
    [destination] = 42
}

function void forwardNow(noescape ptr int destination) {
    writeNow(destination)
}

public function void main() {
    var int value = 10
    writeNow(addr(value))
    forwardNow(addr(value))
}
```

The pointer is still an ordinary pointer passed by value. `noescape` does not change its ABI, ownership, mutability, nullability or alignment.

## Syntax and restrictions

A parameter may be written as:

```fac
noescape ptr T name
```

The modifier is permitted only on a by-value `ptr` parameter. It cannot be combined with `ref`, a default value or a variadic parameter. It is not yet supported on lambda parameters or function-type signatures. A FAC function must have a body that the checker can inspect.

Every source file containing a `noescape` declaration must be compiled with `--strict-ownership` or `--secure`. The compiler rejects use without one of those modes so the effect cannot silently become documentation-only.

## What the FAC body checker enforces

For a FAC function body, the strict ownership pass seeds pointer provenance at every `noescape` parameter and follows it through local pointer variables and expression trees. It rejects:

- returning the parameter or a local pointer alias derived from it;
- storing the pointer into a global, field, aggregate, container or other untracked/external destination;
- capturing a pointer alias in a closure;
- forwarding it to a direct function parameter without a `noescape` contract;
- using a computed/indirect call whose noescape effect cannot be established.

A pointer may be copied to a local `ptr` variable when the local storage remains inside the function. Since V65, it may be forwarded to a direct call when the best applicable overload marks that parameter `noescape`.

This is a bounded escape check, not a proof that dereferencing the pointer is valid, non-null, aligned, race-free or synchronized. It does not yet model all pointer/integer transformations, opaque inline assembly, hidden FFI aliases or every form of dynamic dispatch.

## Overloads and methods

V65 retains the parameter types and effects of each direct overload. When argument types are known, the checker filters candidates and applies the effect attached to the best-scoring candidate; pointer pointee types are considered, so an exact `ptr T` match outranks a non-exact pointer-compatible overload. The same selected-candidate result feeds local-borrow and pointer-provenance checks. If any argument type is unknown, the receiver/call target cannot be resolved, or multiple candidates remain tied, all arity-compatible candidates must promise `noescape`. This fail-closed fallback can still reject safe calls; it must not silently treat an unresolved call as safe.

Indirect function values and dynamically computed callees do not currently carry noescape effects in their function type. Passing a frame-derived pointer through those calls is rejected.

## FFI trust boundary

An `extern` declaration may include `noescape`:

```fac
extern function void consumeNow(noescape ptr int data)
```

This is an explicit trusted FFI promise. The compiler cannot inspect the foreign implementation, so it does **not** verify that the foreign function refrains from retaining the pointer. The annotation should be used only when the external API documentation or audited implementation guarantees synchronous/non-retaining use. A false FFI promise can still cause use-after-scope or memory corruption, including in `--secure` builds.

An unannotated extern pointer parameter is treated as potentially retaining. A frame-derived pointer cannot be passed to it in strict ownership mode.

## Compatibility and implementation boundary

`noescape` is parameter metadata in the source AST only. It adds no runtime checks and no ABI parameter. Existing declarations remain unchanged unless a caller needs to pass a frame-derived pointer. Such calls must now provide a verified FAC contract or a trusted `extern noescape` declaration.

This is the first direct-call pointer effect. It is not a general `nothrow`, `readonly`, `noalias`, `send`, `suspend-safe` or full effect system. Partial move, reference-valued fields/returns and interprocedural provenance summaries remain future work.

## V61 extension: independent `readonly` effect

V61 adds `readonly ptr T name`, and permits it to be combined with `noescape` in either modifier order. `readonly` promises no writes through the pointee; it does not promise non-retention. The combined `readonly noescape ptr T name` is suitable for a verified FAC function that reads caller storage synchronously. For the complete syntax, body restrictions, abstract/interface contracts, override compatibility and FFI trust boundary, see [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).
