# FAC V259 — focused source-code audit

## Finding

**Severity: High — inferred pointer return / enum payload provenance**

The V257/V258 fail-closed check recognized an untracked pointer payload when
that payload was the direct result of an `auto` function's `match`/`ifv` arm.
It did not recognize pointer-preserving expressions around the binding. For
example:

```fac
function auto choosePayload(enum MaybePointer value) {
    return match (value) {
        case (MaybePointer.Value(pointer)) => pointer + 0,
        default => null
    }
}
```

The V258 compiler accepted this under `--strict-ownership`, even though enum
payload pointer provenance is not tracked and the returned pointer could not
be proven to outlive the function. Additional reproductions showed related
forms using reversed addition, subtraction by an integer, assignment, compound
assignment, and prefix/postfix increment/decrement.

## V259 change

`findUntrackedPointerMatchPayloadResult` now follows bounded pointer-valued
result forms inside result-producing `match`/`ifv` trees:

- Binary `pointer + integer`, `integer + pointer`, and `pointer - integer`.
- Assignment expression `pointer = pointer` (the assigned RHS is the result).
- Compound pointer updates `pointer += integer` and `pointer -= integer`.
- Prefix and postfix `++`/`--` on the pointer binding.

Pointer subtraction (`pointer - pointer`) remains a scalar result and is not
rejected by this guard. Comparisons and other scalar operators remain outside
this pointer-result check, so pointer values used only to select/compare a
result are not automatically treated as the returned value.

Eleven focused regressions cover ten rejected pointer-result forms (direct and
reversed addition, subtraction by integer, assignment, compound addition and
subtraction, postfix and prefix increment, and postfix and prefix decrement),
while a pointer difference result (`left - right`) remains accepted as a
scalar.

The change is intentionally bounded; it does not add general enum-payload
provenance, general expression typing, heap escape analysis, or first-class
`ref T` returns. It does not change source syntax, Runtime, ARC/GC, public API,
ABI, or the `--memory-safe` accepted subset.

## Validation

- Compiler build: Clang 17, C++17, `-O0 -g0`; build succeeded.
- `facc --version`: FAC/Core/Lib/API/Lang/Runtime/Stdlib all report V259.
- Version consistency check: passed.
- Lifetime regression suite: 141 checks PASS, including ten rejection cases
  and the scalar pointer-difference acceptance case.
- Ownership suite: passed; function-effect regressions: 13/13.
- Move: 20/20; Partial Move: 28/28.
- `--memory-safe`: 39/39.
- Generic specialization: 3/3.
- Codegen focused checks: constant-fold and recursion guard passed.
- Lexer: 18/18.
- Parser: 68 checks; AST model: 1/1.
- Runtime regression script: exited 0.
- Tools: 91/91.
- Negative tests: 134/134; Limits: 21/21.
- Formatter check: passed.
- Standards check: passed for 5 OS families and 6 architecture families.
- API manifest and generated documentation checks: passed.
- API audit: 663 built-ins and 1,014 source declarations; 5 findings, 0 new
  findings beyond baseline. Strict API contract audit: 950 public source
  functions, 0 missing required annotations. Compatibility against V128:
  0 breaking changes, 132 warnings.
- Safe-profile integration: 433 passed, 4 failed. The four failures are the
  known V258 baseline cases in `worker_join_struct_move.fac` and
  `worker_join_struct_helpers.fac` (strict-move / value-struct provenance and
  plain-compile/IR-equivalence checks); they remain unresolved and are not
  claimed as passing.
- Semantic suite: ancestry model reported 17 checks passed, but the full suite
  did not complete within the execution time limit; no full semantic-suite
  success is claimed.

Full CMake/CTest, ASan/UBSan/TSan, Windows/macOS cross-platform qualification,
and production qualification are not claimed.
