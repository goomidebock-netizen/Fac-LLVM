# FAC Language Core V190 — local const-boolean conditional predicates

## Scope

V190 extends only the bounded strict local-borrow fixed-array projection evaluator. It does not introduce general constant evaluation or a general-purpose compile-time execution facility.

An initialized local scalar `const boolean` declaration is recorded when its initializer can be proven by the existing conservative condition evaluator. Supported forms include boolean literals, integer constant truth values, logical NOT/AND/OR (including FAC short-circuit behavior), integer comparisons, and references to earlier visible local const integer or const boolean declarations whose exact declaration identity is still in scope.

Example:

```fac
const boolean enabled = true
const boolean disabled = !enabled
const boolean useSlot = enabled && !disabled
ref var int first = values[ifv(useSlot){1}elv{2}]
```

The recorded predicate is keyed to the AST declaration identity, not only the identifier spelling. Initializers are evaluated before the new declaration shadows an outer name. A declaration that shadows an existing binding but cannot itself be proven as a constant clears the previous same-name constant record. This prevents mutable or unknown inner bindings from inheriting an outer constant value.

## Conservative boundaries

- Only initialized local scalar `const boolean` bindings are recorded.
- Mutable booleans, parameters, globals/statics, uninitialized constants and values produced by calls or side effects remain unknown.
- Expressions that exceed the existing 64-node visit budget remain unknown.
- The selected `ifv / eiv / elv` result arms must still resolve to pure integer constants with identical integer width and signedness.
- The final array projection must still be a non-negative index representable by the existing signed 64-bit projection representation.
- Dynamic aliasing, array bounds checking, general lifetime solving, return/store/capture lifetime analysis and complete borrow checking are unchanged.

## Regression coverage

- `good_array_const_boolean_predicates.fac` proves direct and chained const-boolean predicates and checks runtime writes reach the original array slots.
- `good_array_const_boolean_shadowing.fac` verifies that a shadowed const boolean uses its own declaration's value.
- `bad_array_const_boolean_same_index.fac` verifies equal selected indexes still conflict.
- `bad_array_const_boolean_shadowed_mutable.fac` verifies a mutable shadow does not inherit an outer const-boolean value and therefore remains conservative.
- The existing dynamic-condition negative fixture remains in the suite to ensure mutable conditions are not treated as compile-time constants.

Validation results are recorded in `docs/STATUS.md`.
