# FAC V213 — ML training and autograd allocation safety

## Scope

V213 hardens allocation and cleanup on selected ML and reverse-mode autograd paths. It does not add public functions, FAC syntax, compiler semantics, Runtime ABI changes, platform-support claims or GPU execution.

## Model fitting and workspaces

Linear, ridge and logistic fitting allocate the model with its weight vector already constructed under the Runtime cleanup guard. The per-feature long-double gradient buffer is also guarded and reused across epochs, with its contents reset between passes. This avoids repeated per-epoch allocation and ensures a failed model or gradient allocation unwinds any earlier temporary through FAC's cleanup stack.

K-means now constructs its center Tensor inside a guarded model constructor and registers the shuffled row index, cluster assignments, center sums and counts. The buffers are reused across epochs. KNN fit constructs the copied feature and label tensors within the guarded model allocation. KNN prediction guards its result Tensor, distance workspace and vote map; allocation failure during vote-map growth is translated into a FAC allocation/resource error and all registered objects are dropped.

## Autograd transaction boundaries

Scalar tape append catches vector growth failures and reports a FAC Resource error while preserving the existing tape. Tensor tape append first constructs a copied value and zeroed gradient vector in a guarded temporary node. It then appends the node and updates `stored_elements` only after the append succeeds. Tensor backward allocates detached gradient vectors for all nodes, performs and validates the reverse pass, and only then swaps the gradients into the tape. Allocation or numeric failure therefore leaves previously committed gradients unchanged.

## Regression coverage

`tests/runtime/ml_autograd_exception_safety.cpp` overrides C++ allocation for deterministic fail-at-N injection. It covers linear/ridge/logistic fit, K-means model and workspace construction, KNN fit and vote-map growth, scalar/tensor tape append, and scalar/tensor backward. Each failure is checked for FAC error translation and cleanup-stack balance; failed backward is retried without injection and must produce the expected gradient.

The complete `tests/runtime/run.sh` suite remains the Runtime integration boundary. The test does not claim comprehensive process-heap leak detection or whole-Runtime memory-safety proof.

## Validation record

Linux x86-64, GCC: the host Compiler built at `-O1 -DNDEBUG` and Runtime at `-O2 -DNDEBUG`. The complete `tests/runtime/run.sh` suite passed. API regression passed 41/41 at FAC `-O0` and 41/41 at `-O2`. Compiler fixtures passed 129/129 at both optimization levels; negative tests 132/132; resource limits 21/21; safe/strict-safe 437/437; memory-safe 25/25; and ownership/borrow/effect suites passed at their recorded counts in `docs/STATUS.md`. Format, version, standards, manifest, API audit, strict contract and generated-doc checks passed. API compatibility reports 0 breaking changes and 124 warnings against V128. The aggregate `make test` command hit the 300-second command limit; the resource-limit suite was run separately and passed.

## Qualification boundary

V213 is a targeted exception-safety improvement, not a universal proof of Runtime allocation safety. ASan/UBSan, TSan, cross-platform validation and device/GPU qualification are not claimed unless separately run and recorded.
