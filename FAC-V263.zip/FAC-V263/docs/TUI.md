# FAC TUI — lightweight secondary terminal UI

TUI remains a **secondary, dependency-free utility layer** for terminal dashboards, build tools, diagnostics, and small command-line menus. The main UI investment is the canvas GUI in [`UI.md`](UI.md). TUI provides ANSI/VT styling and ready-made text layouts; it is not intended to become a second full GUI framework.

## Quick start

```fac
import tui.fac
import terminal.fac

public function void main() {
    terminal.out.print(tui.clear())
    terminal.out.println(tui.title("FAC BUILD"))
    tui.section("COMPILER", 54)
    tui.status("ok", "Compiler ready")
    tui.progress("tests", 87, 100, 24)
    tui.notice("RESULT", "All smoke tests passed", "success")
    terminal.out.println(tui.keyHint("q", "quit") + "  " + tui.keyHint("r", "rerun"))
}
```

## API groups

- **Terminal control:** `clear`, `reset`, cursor movement/visibility, alternate screen, erase and scroll-region helpers.
- **Text styles:** `bold`, `dim`, `italic`, `underline`, `inverse`, `title`, `muted`, `success`, `warning`, `error`, `info`, and `kbd`.
- **Layout:** `header`, `panel`, `banner`, `section`, `rule`, `keyValue`, `tableHeader`, `tableRow`, `boxLine`, `top`, `hr`, and `bottom`.
- **Status/progress:** `status`, `notice`, `progress`, `progressBar`, `spinner`, `bullet`, and `keyHint`.
- **Simple input:** `menu` reads a numeric choice from standard input.

## Scope and limitations

- Output uses ANSI/VT escape sequences. Color support depends on the terminal; redirected output preserves the escape sequences.
- Current width calculations use FAC string length, not terminal grapheme/display-cell width. CJK wide characters, emoji, combining marks, and some Thai sequences may not align in strict tables.
- `menu` is line/numeric input. There is no raw-key event loop, terminal resize event handling, mouse input, focus model, or retained widget tree in this lightweight module.
- Always restore terminal state before leaving a full-screen app: reset styles, show the cursor, and leave the alternate screen. For a robust interactive TUI, a future backend can be added separately without holding back the primary Canvas GUI.
