# FAC UI + Graphics Architecture

## Responsibilities

- `ui.fac` owns widgets, themes/styles, layout helpers, and UI interaction.
- `graphic.fac` owns the window/canvas lifecycle, input polling, and the current software canvas implementation.
- `three.fac` owns 3D camera/depth setup and software-rasterized 3D primitives.
- `render.fac` is the shared drawing contract used by UI-facing code. Its V16 software backend delegates to `graphic.fac`.

The modules remain separate at the public API/responsibility level. They share a canvas and can be composed in one frame. UI is optional; a Graphics-only program does not need to import `ui.fac`.

## Renderer contract

`render.fac` currently exposes:

- `clear`, `pixel`, `line`, `rect`, `fillRect`
- `circle`, `fillCircle`, `fillTriangle`
- `text`, `measureText`, `image`
- `present`

The current backend is the existing software renderer. This is a renderer facade/contract, **not yet a runtime-selectable plugin system**. A future GPU backend can implement the same operations, after which backend selection and resource ownership can be added without changing widget APIs.

## Frame composition

1. Poll the `graphic` window.
2. Call `ui.beginFrame(win)` once to snapshot mouse state.
3. Clear the canvas with `render.clear` or `graphic.clear`.
4. Draw the 3D scene with `three.begin` and `three.*` calls.
5. Draw UI widgets with `ui.*`; UI drawing primitives route through `render.fac`.
6. Present once with `render.present` or `graphic.present`.

Draw order determines layering: UI drawn after the scene appears as an overlay. Both modules use the same canvas and window input coordinates.

## UI + Graphics helpers

- `ui.image(canvas, source, x, y, w, h)` scales/blits a Graphics image.
- `ui.viewportFrame(canvas, x, y, w, h, caption, theme)` draws a border/title decoration.

`viewportFrame` is decorative only. It does not clip the 3D scene or create an independent render target. The 3D renderer remains software-based; there is no hardware GPU backend in this release.

## Example

Build `examples/ui_graphics_integration.fac`. It draws a 3D scene, then composes toolbar/sidebar/widgets over the same canvas. The UI module is optional for Graphics-only applications.
