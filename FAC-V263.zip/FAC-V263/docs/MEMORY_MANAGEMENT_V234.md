# FAC V234 — bounded nested-closure lifetime proof

V234 extends the V233 local direct-call-only closure proof to nested local closures. A pointer or pointer-bearing value struct may be captured by a nested lambda only when the nested lambda is directly bound to one local function-valued variable, every use of that variable is an immediate direct call, and every enclosing lambda that contains such a call independently satisfies the same local-direct-call-only proof. This establishes that the nested closure environment cannot outlive its already-verified parent closure region.

The proof is deliberately conservative. It rejects closure copies, assignments, returns, argument passing, shadowing, self-capture, references from nested named functions, and parent/child closure-use cycles. A recursion guard makes mutually-referential proof dependencies fail closed. Pointer origins must still be fully known, must not come from `noescape` parameters, and must outlive the closure's lexical region. Verified-null and pointer-free captures retain their existing behavior.

This is a bounded syntactic proof for local nested closures, not general closure lifetime inference, heap escape analysis, closure storage in aggregates/containers/globals, or whole-program escape analysis. No source syntax, Runtime, ARC, Cycle Collector, public API, ABI or `--memory-safe` acceptance changed.

## Regression coverage

- A three-level local closure chain directly invoked at each level compiles and executes.
- Copying a nested closure into another function variable is rejected.
- Passing a nested closure as a function argument is rejected.
- Existing V233 positive and negative closure-capture fixtures remain in the lifetime suite.

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0`): Lifetime 116 checks; ownership 261; secure profile 6/6; move/partial-move 48; `--memory-safe` 39/39; Tools 91 tests (6 skipped); parser 68 plus AST 1/1; lexer 18; focused codegen checks passed; full CMake build and CTest 37/37 passed. API audit: 0 breaking changes, 132 compatibility warnings against V128, 5 existing baseline findings and 0 new findings. The broad semantic suite was only partially run (17 ancestry checks passed before the overall command timed out); no full semantic-suite success is claimed. ASan/UBSan/TSan, cross-platform and production qualification are not claimed.
