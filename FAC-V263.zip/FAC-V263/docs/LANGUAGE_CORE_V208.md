# FAC Language Core V208 — Function-value lifetime contracts

## Scope

V208 carries named lifetimes into explicit function-value types and applies those contracts when a statically typed callback is invoked indirectly. The implementation is in the Parser, Compiler type model and strict local-borrow/lifetime checker. It does not change generated calling conventions or Runtime behavior.

## Function-value syntax

A function-value type may declare named lifetime parameters before its return type. Pointer parameters and the pointer return may bind to those names, and `where` defines outlives edges in the callback's own lifetime graph:

```fac
function lifetime<a> ptr<a> int callback(ptr<a> int)

function lifetime<longer, shorter> ptr<shorter> int choose(
    ptr<longer> int,
    ptr<shorter> int
) where longer: shorter
```

The same type syntax may be used for a local variable or a function parameter:

```fac
function lifetime<a> ptr<a> int identity(ptr<a> int value) {
    return value
}

function lifetime<outer> ptr<outer> int invoke(
    function lifetime<callback> ptr<callback> int callback(ptr<callback> int),
    ptr<outer> int input
) {
    return callback(input)
}

public function void main() {
    var int value = 208
    ptr int source = addr(value)
    var function lifetime<a> ptr<a> int local(ptr<a> int) = identity
    ptr int result = local(source)
}
```

Parameter names in a function-value type are optional; positional types and lifetime indices carry the contract. Function types with named lifetimes must include a complete parameter signature. The return lifetime must be backed by a pointer parameter whose lifetime outlives it through the declared `where` graph. Unknown or duplicate lifetime names/edges and annotations on non-pointer parameters are rejected.

## Assignment compatibility

A function value assigned to a named-lifetime callback type must itself carry a matching lifetime shape. A target without a named lifetime contract cannot satisfy a callback type that requires one. Lifetime parameter names are alpha-equivalent: `lifetime<a, b>` and `lifetime<x, y>` are compatible when their indexed parameter bindings, return source and outlives edges have the same shape. Return/parameter types and independent `noescape` / `readonly` effect requirements must also be compatible.

The Compiler preserves the nested return `TypeSpec` through cloning, generic substitution and normalization. Function type specialization keys include return type, parameter types/effects and lifetime shape so distinct callback contracts do not collide in the generic cache.

## Indirect call checking

Under `--strict-ownership` / `--secure`, the checker carries a callback signature contract for function-typed parameters and local function variables. At the indirect call it maps actual pointer argument origins into callback lifetime indices, checks the `where` constraints against the caller's known region graph, and propagates a returned pointer only from eligible arguments whose declared lifetime outlives the callback return lifetime.

The checker fails closed when a required argument origin is untracked, a `where` relation is not satisfied, a target lacks the required named-lifetime signature, or a callback result could outlive its source region. The lifetime return-source rule does not mean every argument may be retained or returned: unrelated pointer arguments are not used as return sources.

## Deliberate proof boundary

`noescape` and `readonly` remain function-value type metadata and participate in assignment compatibility. However, an indirect function-type `noescape` annotation is not promoted to a verified call-site noescape effect. Until the compiler can resolve a function value to the checked target body and prove that body does not retain the pointer, a frame-derived pointer passed through an indirect callback without a separately verified noescape path remains rejected. Named return-lifetime provenance and non-retention are separate properties.

This milestone does not yet track contracts in function-valued aggregate/member fields, callbacks returned from functions or produced by arbitrary computed expressions, arbitrary dynamic dispatch, or general target-aware indirect effect verification. It does not add a runtime function wrapper, ownership transfer, function pointer ABI change, `async` model or Runtime API. It is a bounded static contract checker, not a complete borrow checker or proof of memory safety.

## Validation

Linux x86-64, GCC C++17. Compiler rebuilt at `-O0`; the complete FAC fixture suite passed 129/129 at FAC `-O0` and 129/129 at FAC `-O2`. Lifetime suite passed 28/28; Parser 58/58; Lexer 18/18; semantic ancestry 17/17; ownership 11/11; const-method ownership 8/8; local borrow 167/167; noescape 17/17; field-sensitive borrow 19/19; effect contracts 19/19; function effects 13/13; move 20/20; partial move 28/28; generic specialization 3/3; safe/strict-safe 437/437; memory-safe 25/25; Runtime regression shell suite passed. Compiler `-O2` binary, sanitizer and cross-platform qualification are not claimed.
