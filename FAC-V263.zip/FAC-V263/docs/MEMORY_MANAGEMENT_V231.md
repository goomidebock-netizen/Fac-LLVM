# FAC Memory Management Direction — V231

V231 contains two bounded strict-ownership improvements: nested-block pointer-alias return inference and fail-closed closure capture when pointer provenance is unknown.

## 1. Nested-block pointer-alias return inference

For a source-defined function returning `ptr T` with multiple pointer inputs, the checker may infer the unique returnable input when every other pointer input has a body-verified `noescape` contract. The function may return the selected parameter directly or through a simple local pointer alias declared in a nested lexical block.

A child block inherits aliases visible in its parent. Aliases declared in the child do not flow outward to the parent or into sibling scopes. Alias candidates must be direct pointer-local declarations initialized directly from the selected parameter or an earlier visible alias, their names must be unique throughout the function body, and they must never be assigned or passed to a call. The source parameter must also remain unassigned. Ambiguous sources, computed initializers, pointer arithmetic/casts, field loads, nested alias shadowing, call exposure, extern/abstract bodies and unverified `noescape` remain fail-closed. This is still a bounded name-based local proof, not declaration-identity resolution or general return/escape analysis.

## 2. Closure capture with unknown pointer provenance

When a lambda body references a visible pointer local or pointer parameter, strict ownership rejects the capture if one or more origins are known (the current closure model does not prove those origins outlive the closure) **or if no origin is recorded**. An empty origin set may mean Unknown, so it cannot be interpreted as proof of a null pointer.

When a closure references a value struct containing pointer fields, the checker requires an exact provenance fact for every pointer-bearing field path. Missing facts and wildcard-only summaries are insufficient. If any field has a known pointer origin, capture remains rejected because the closure lifetime has not been proven to fit inside the referent lifetime.

The checker continues to allow capture of value structs with no pointer fields and structs whose pointer fields are all explicitly verified null (each field has an exact fact with an empty origin set). This preserves the V226 distinction between Verified Null and Unknown.

## 3. Conservative boundaries

Standalone pointer locals do not yet have a dedicated verified-null state; therefore a pointer local with no recorded origin is rejected when captured, even if its initializer may have been `null`. V231 does not infer closure non-escape, add closure lifetime parameters, prove arbitrary global/external pointer lifetimes, or add general heap/container escape analysis. The nested alias return proof remains name-based and does not resolve arbitrary computed aliases, call effects or indirect targets.

No syntax, Runtime, ARC, Cycle Collector, public API, C ABI or Runtime ABI changed. `--memory-safe` remains unchanged and continues to exclude raw pointer types and `addr`.

## 4. Regression coverage

Nested alias tests cover simple aliases and alias chains declared in nested blocks, with negative cases for reassignment and call exposure. Closure-capture tests reject an unannotated pointer parameter and a pointer-bearing aggregate parameter with missing field facts. Positive controls permit capture of a verified-null pointer-bearing struct and a pointer-free struct. The complete `tests/lifetimes/run.sh` script passed 98 checks, including a sibling-scope negative proving that a child-block alias is not visible in a sibling block.

## 5. Validation

Validated on Linux x86-64 with Clang 17 C++17: Compiler rebuilt with `-O0 -g0`; Runtime rebuilt with `-O2 -g0`; `facc --version` reports V231 for every component. `tests/lifetimes/run.sh`: 98 checks passed; ownership: 261 checks passed; `tests/ownership/secure_profile.sh`: 6/6; move/partial-move: 48 checks; `tests/memory_safe/run.sh`: 39/39; Tools: 91 tests, 6 skipped, no failures; parser: 68 checks plus AST model 1/1; lexer: 18 checks; codegen constant-fold and recursion-guard checks passed; formatter passed. `make api-check` passed: 663 built-in entries and 1,014 source declarations audited, 950 public source functions had required documentation annotations, 0 compatibility breakings and 132 warnings against V128; all 5 API findings were present in the baseline (0 new). `tools/check_versions.py` passed. Full semantic/legacy-suite, sanitizer, cross-platform and production qualification are not claimed.
