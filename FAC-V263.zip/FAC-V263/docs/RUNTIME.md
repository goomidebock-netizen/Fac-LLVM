# FAC Runtime Architecture and V162 Status

## V129 Graph and recursion invariants

Graph node metadata grows geometrically. Adjacency uses compact vectors, with a secondary hash index only for rows of 48 or more neighbors. Every edge mutation path (`addEdge`, `addArc`, `removeArc`, `removeEdge`, `removeNode`) keeps that index coherent; failed edge publication rolls back both adjacency and any active-index insert. `clone` copies active indexes along with adjacency. Weighted Graph insertion accepts only finite, non-negative weights, which is the precondition required by `shortest` (Dijkstra).

Generated FAC functions check stack distance and recursion depth through inline thread-local operations. The slow failure helper is entered only when a limit is exceeded. A FAC `try` boundary snapshots both values; `throw` restores them before the non-local jump, and the outermost normal return clears the stack anchor. This does not change the underlying `setjmp`/`longjmp` model: C++ automatic destructors are still not run across FAC throws, so C++ Runtime code must continue to release non-trivial resources before calling `do_throw`.


The FAC runtime is a C++17 implementation behind a C-linkage ABI. It is responsible for managed allocation, strings/lists, class object lifetime, closure capture lifetime, runtime error transfer, thread primitives and selected I/O/media helpers. It is not a garbage-collected VM and it does not make arbitrary foreign pointers safe.


## V218 stable file tokens and per-handle I/O synchronization

Each `file.open` call returns a stable opaque token backed by a process-lifetime registry record. The C ABI still uses `void*` / `ptr file`, but the value is no longer a native `FILE*`; foreign callers must pass the token only back to FAC `file.*` operations. One mutex on each record serializes `readLine`, `readAll`, `write`, `writeLine`, `flush`, `eof` and `close`. Close waits for in-flight I/O, releases the native stream exactly once and leaves the record closed. Further I/O through the token raises Io (7); repeated close is harmless.

The registry keeps closed records as tombstones until process shutdown to prevent pointer-address ABA: an old token cannot become a later file even when libc or the allocator reuses an address. The native stream itself is released at close, but the small token record and registry entry remain; metadata usage therefore scales with the total number of `file.open` calls in one process. `FileHandle` methods can share the token for concurrent I/O while the managed object remains alive and its handle field is not concurrently changed. Do not race wrapper methods, `isOpen`, `close`, or final-owner destruction on the same managed object.

## V207 managed thread-task owner

`import thread_resource.fac` provides `obj thread_resource.Task`, a managed owner for the raw `ptr thread` returned by `thread.start`. Create `Task` before starting work, then call `adopt(thread.start(lambda))`; this keeps callback capture checking at the caller site and avoids starting a worker before its owner allocation succeeds. `cancel()`, `isDone()` and `isCancelled()` delegate to the existing cooperative task control block. `join()` is one-shot: it clears the shared managed object's handle before consuming the native handle, so aliases cannot join the same task twice. The last strong owner joins any still-owned native handle during destruction. A `Task` must not be captured by the worker it owns or destroyed from that worker, because final-owner cleanup would attempt a self-join. `isDone()` returns true when no handle is owned (before adoption or after join) as well as after the worker reaches a terminal state.

The destructor catches and suppresses a worker error during fallback cleanup; this prevents an unobserved exception from interrupting object cleanup, but means explicit `join()` is required when the caller needs worker failures propagated. Destruction can block until the callback returns. Since cancellation is cooperative, a callback that never polls `thread.cancelled()` may keep it blocked indefinitely. Do not race `cancel`, status queries, `join`, or final-owner destruction; the wrapper does not make raw handle aliases concurrently safe. Do not capture a `Task` in its own worker or destroy it from that worker, because final-owner cleanup would attempt a self-join. No detach, timed join, async/await or typed result API is added. The original raw thread API and ABI remain available. The existing `--memory-safe` profile still rejects the raw `thread` built-in module; this wrapper does not bypass that restriction.

## V206 managed file-resource owner

`import file_resource.fac` provides a managed `FileHandle(path, mode = "r")` wrapper around the built-in `file.open` handle. It reads and writes while open, closes idempotently, and closes from the managed destructor when the last strong object reference is released. Copying an `obj FileHandle` shares the owner; methods reject use after explicit close. In V206 the low-level built-in continued to expose its native `FILE*` as the opaque `ptr file` value, with explicit caller-managed close and no automatic compiler cleanup. The managed wrapper was documented as synchronous and not thread-safe.

`file.liveHandles()` counts active handles registered through FAC's `file.open`; foreign streams are excluded. This is a diagnostic count, not a count of all process file descriptors.

## V126 task control block and cooperative cancellation

`thread.start` now owns an explicit task state: Starting, Running, Succeeded, Failed, Cancelled, then Joined when the caller consumes the handle. State is published atomically; cancellation requests are serialized with the transition out of Running. Worker errors retain precedence over cancellation and are still re-raised by `thread.join` with the original FAC error code.

`thread.cancel(handle)` sets a cooperative request only while a task is Starting/Running. `thread.cancelled()` lets the current `thread.start` callback poll that request. Once the callback observes it and returns normally, the task reaches Cancelled. `thread.isDone(handle)` and `thread.isCancelled(handle)` expose terminal status before join. They do not make handle aliases safe: the owning caller must serialize all handle queries/cancel requests with the consuming join, and no alias may be used after join. No native thread is forcibly terminated; callbacks that do not poll continue to completion.

The new `tests/runtime/task_lifecycle.cpp` checks accepted/rejected requests, cooperative stop, non-polling completion, terminal-state observation and worker-error precedence. This does not add `async/await`, typed task results, detach, or cancellation of `parallelFor` pool workers.

## V95 Trie stack-safety change

The Runtime Trie stores one node per key byte. Earlier traversal, removal and implicit `unique_ptr` destruction followed that depth recursively, so an unusually long string key could overflow the native C++ stack even though FAC-managed function recursion had its own depth guard.

V95 makes all depth-sensitive Trie paths iterative:

- `words(prefix)` uses an explicit depth-first frame stack and preserves byte-lexicographic output order.
- `remove(key)` follows the key iteratively and prunes empty suffix nodes through stable parent links; it does not allocate a second path stack.
- `clear()` and the Trie destructor detach child ownership edges into an intrusive worklist before deleting nodes, preventing nested `unique_ptr` destruction from recursing.

A Runtime test inserts a 100,000-byte key, looks it up, enumerates it, clones it, removes it, clears it, reinserts it, and destroys the Trie. With a 256 KiB native stack, the V94 harness segfaulted during enumeration while the V95 stress test passed. This change preserves the existing Trie API and C ABI. It does not make all Runtime STL allocation failures recoverable, nor does it claim a global recursion-free Runtime.

## V117 Runtime clone and container insertion rollback

V117 closes targeted allocation-failure gaps in the existing Linked List, Stack, Queue, Heap, AVL Tree, Trie and Matrix implementations:

- Clone operations retain the not-yet-published copy under `std::unique_ptr`. If cloning a later element fails, the partially built container's destructor releases all managed FAC string references already copied. AVL node cloning also explicitly destroys completed child subtrees when a sibling clone fails.
- Container insertion first creates an owned blob, then moves it into the STL container. If the container cannot allocate its node/block/capacity, the pending FAC string handle is released before the C ABI reports the error. This covers Linked List insertion and Stack/Queue/Heap push paths.
- AVL insertion keeps a new node under RAII until its key blob is complete. Two-child deletion prepares the successor key before replacing the current key, then transfers the blob with a no-throw string move so the managed handle has exactly one owner.
- Trie insertion remembers the first newly-created edge. If any deeper node or child-vector allocation fails, it detaches and iteratively destroys the entire unpublished suffix; the Trie word count and visible prefixes remain unchanged.
- The audited create/insert/push/clone/traversal entry points translate caught `std::bad_alloc` and `std::length_error` into FAC Resource error 5 after C++ exception objects and local RAII scopes have unwound. This includes Graph `neighbors`, `bfs`, `dfs` and `shortest`, whose temporary STL work buffers are now guarded at the C ABI boundary.

`tests/runtime/ds_clone_exception.cpp` uses deterministic one-shot global `operator new` fault injection. It checks rollback/retry for managed-string Linked List/Stack/Queue/Heap insertion, Queue deque block growth, Trie partial-path rollback, and clone failure sweeps for Linked List, Stack, Queue, Heap, AVL Tree, Trie and Matrix. It also checks the FAC managed-allocation block count returns to its pre-test baseline after all source containers and strings are released.

This remains a targeted guarantee. It does not prove every Runtime API is OOM-safe, does not change the longjmp-based FAC error model, and does not make arbitrary C++ objects safe across `do_throw`. In particular, unguarded APIs and paths that call `do_throw` while C++ non-trivial automatic objects are live still require separate audit. No public API signature, Syntax, C ABI or Runtime ABI changed.

## V101 FAC cleanup-stack integration for numeric/API workspaces

FAC errors use non-local control transfer. A `do_throw`/FAC `throw` does not run C++ automatic-object destructors, so a local `std::vector`, `std::string`, stream, or `unique_ptr` can leak if a runtime API calls `do_throw` while that object is alive. This is distinct from ordinary C++ exception unwinding.

V101 adds an explicit cleanup-stack guard for heap-backed temporary workspaces used by the audited Tensor, Statistics, Metrics, Optimizer, Neural Network, CSV/DataFrame, and Autograd paths in `runtime/fac_ml.inc`. A guarded workspace registers its type-specific destructor with the current FAC cleanup stack before performing work. On success, the guard is removed before the result is returned or ownership is committed; on FAC error, the runtime cleanup stack invokes the destructor before transferring control to the nearest FAC handler. Workspace allocation and cleanup-stack exhaustion are reported as `Resource` (8). Output handles are guarded until their computation succeeds, then ownership is transferred to the caller.

The V101 error-path regression repeats numerical overflow, dense-layer overflow, malformed CSV and ragged DataFrame CSV failures inside FAC `try/catch` blocks. It checks 400 caught failures and is also run under ASan/UBSan/LSan. This is a targeted guarantee for the guarded API paths, not a universal C++ unwinding guarantee: other Runtime/FFI code must still avoid calling `do_throw` while unguarded non-trivial C++ automatic objects are live.

## 1. Runtime components

| Component | Current mechanism | Main contract / limitation |
|---|---|---|
| Managed allocator | `malloc`/`calloc`/`realloc` with opt-in side-table tracking | Tracking starts one-way; pre-tracking allocations stay untracked. Counters exclude STL/libc/OS overhead. |
| Temporary and cleanup stacks | Per-thread small-buffer stacks with heap spill | LIFO cleanup for generated managed temporaries; bounded at 16,384 entries per stack. `trimThread()` only works when idle. |
| Strings | Immutable UTF-8 byte buffer plus atomic reference count | Shared copies are cheap; payload is NUL-terminated, but FAC length is byte-based and code-point count is stored separately. |
| Lists | Runtime header plus dynamically resized element storage and optional copy/drop callbacks | Capacity arithmetic is checked; custom element callbacks must preserve the zero-initialized/partial-cleanup contract. |
| Class objects | Atomic strong references, generation-tagged weak tokens, weak-slot table and explicit object registry | Weak lock is synchronized with object destruction. Weak values are opaque tokens, not addresses. Cycle collection is explicit and only traces class fields / nested by-value structs. |
| Closures | Atomic reference count and generated capture-drop callback | Static closures are immortal; captured values are retained/copied according to generated code. |
| Errors | Thread-local error state, cleanup stacks and `setjmp`/`longjmp`-style transfer | FAC throws do not unwind C++ automatic objects. Runtime code must release C++ resources before calling `do_throw`. |
| Threads | Native `std::thread`, join handles, and a lazily-grown reusable worker pool for `parallelFor` | `thread.start` retains closures through worker completion; `parallelFor` reuses up to 32 workers, joins every submitted batch before return, and captures FAC/C++ callback failures. |
| Synchronization | C++ atomics, mutex, bounded string channel and string cell | Channels copy messages; lifetime of opaque handles must outlive all concurrent calls. |


### V162 bounded `parallelFor` queues

The reusable worker pool now bounds each private worker queue to 64 pending job tickets. A `parallelFor` caller waits for capacity across all selected queues before it publishes its batch. This applies back-pressure under concurrent submissions instead of allowing queued scheduler metadata to grow with the number of waiting callers. Workers notify capacity waiters after dequeuing a ticket; shutdown also wakes them. Queue insertion remains atomic from the workers' point of view: if any queue allocation fails, partial tickets from that batch are rolled back while the pool mutex is still held. Nested calls from pool workers continue to execute inline, avoiding a worker waiting for capacity in its own pool.

The bound applies to pending scheduler tickets, not callback payload memory or memory allocated inside callbacks. There is no priority or fairness guarantee, and callbacks must not synchronously wait for work that requires the same saturated pool. This change keeps the existing synchronous API, up-to-32 worker cap and C ABI unchanged.

### V161 weak-handle fast path

`memory.weak(obj)` still returns the same opaque pointer-sized slot+generation token and retains the 64-bit (23 slot / 24 generation) and 32-bit (12 slot / 19 generation) layouts. Slot storage is now allocated in fixed-size blocks that never move or free individual cells. A slot's atomic state packs its generation, the object-anchor bit, and the external weak-handle count into one 64-bit word. `weak_alive`, `weak_retain`, and `weak_release` validate and update the generation/count in atomic operations rather than taking the global object lifecycle mutex on their normal path. Including the generation in the same compare-and-exchange prevents an operation using an old token from changing a later generation of the same slot. `weak_lock` still takes the object lifecycle mutex while checking the object registry and promoting the object to a strong reference; final object release also updates the slot anchor under that mutex.

A block is allocated only when the slot high-water mark reaches it; slots are reused through a free list, but allocated blocks remain reserved until process exit. This trades a bounded-per-high-water persistent slot directory for lower hot-path synchronization and no per-control-block allocation/free. The 39-bit external handle count is capped at `2^39-1`; generation never wraps, and a slot at its maximum generation is permanently retired. Treat weak values as opaque copyable handles: do not convert them to an address, dereference them, or perform pointer arithmetic in native code. Public C signatures and the 64-byte managed-object header remain unchanged. Raw strong object pointers retain their existing pointer ABI and are not covered by this generation scheme.

### V138 weak-token introduction (historical)

V138 replaced the public `FacWeakControl*` representation with opaque slot+generation tokens to close address-reuse ABA. V161 retains that token contract while moving hot-path validation from the global object mutex to generation-aware atomic slot state. The historical design and original validation are recorded in `docs/SECURITY_AUDIT_V138.md`.

## 2. V48 runtime changes

`thread.start` and `thread.join` now form an error-propagating worker boundary:

- The worker installs its own FAC `setjmp`/`longjmp` error handler. A FAC `throw` raised inside the worker is captured after the worker's FAC cleanup and temporary stacks are unwound to the handler boundary.
- The worker stores the original FAC error code and a bounded message in its thread handle. The caller observes that result when it calls `thread.join`; `join` re-raises the original FAC error code on the caller thread.
- Uncaught C++ exceptions from foreign callbacks are caught in the worker and converted to `Resource` (8), then reported by `thread.join`.
- Error capture uses a fixed-size buffer and does not allocate while recording an error. Messages longer than 1023 bytes are truncated for the join diagnostic; the error code is preserved.
- `thread.start` rejects null closures and missing entry functions, handles thread-handle allocation failure, and converts thread construction failure into `Resource` (8).
- A successful `thread.join` consumes and frees the thread handle. Worker callback errors are not observed until the handle is joined. An OS join failure that leaves a thread joinable remains fatal; detaching would risk letting the worker outlive memory captured by the closure.

This boundary catches FAC errors raised by FAC-generated worker code and ordinary C++ exceptions. It does not make `longjmp` across arbitrary foreign C++ frames safe: FFI callbacks must not invoke FAC non-local error transfer while non-trivial C++ automatic objects are live. At V48 this path had no cancellation or typed `Result`-returning join; V126 later adds cooperative cancellation/status observation to `thread.start` handles, but still does not add timeouts or a typed task result.

## 3. V47 runtime changes

`thread.parallelFor(n, closure)` was hardened against partial worker-launch failure:

- Reject a null closure or null entry function when `n > 0` (`NullPointer`, code 6).
- Use a 64-bit atomic work cursor even though the public count/index is `Int32`.
- Reserve the worker vector before starting threads.
- V125 supersedes per-call thread creation with a persistent pool. If the pool cannot create the requested worker count, it raises the established FAC runtime error (`Resource`, code 8). Pool threads are reused and joined at process shutdown.
- Catch C++ exceptions thrown by a foreign callback inside the worker entry. After all workers have joined, report a deterministic FAC `Resource` error (code 8) on the calling thread.
- Add positive tests for zero/negative, one, and 10,000 work items; every valid index must execute exactly once. Add negative tests for null closure, null entry and a throwing C++ callback.

V124 later added a worker-local FAC error boundary for `parallelFor`, so FAC errors and C++ callback exceptions are captured on workers, all participants complete/join, and the original error is re-raised on the caller. V125 replaces per-call thread creation with a reusable pool; see the current pool contract below. A typed Task/JoinResult and a general asynchronous scheduler remain future work. V126 adds cooperative cancellation only to `thread.start` handles; it does not add cancellation to the synchronous `parallelFor` API.

## V125 reusable `parallelFor` worker pool

The pool is internal to the Runtime and does not change the API or ABI. It lazily creates up to `min(requested workers, hardware concurrency, 32)` workers and reuses them across calls. Each worker has a private FIFO ticket queue; a shared 64-bit atomic cursor dynamically distributes callback indices. Each batch submits tickets to only the requested worker count (bounded by the pool limit), even if earlier calls grew the pool larger. Multiple caller threads can submit concurrently, and the pool rotates the selected worker range. Nested calls made by a pool worker execute inline with their own FAC/C++ error boundary to avoid waiting on the parent worker set. If pool growth cannot reach the requested count, or queue allocation fails, `parallelFor` raises the established Resource error (8). Partial queue insertion is rolled back before workers can observe it. All work is complete before the borrowed closure returns to the caller. Worker threads are stopped and joined when the pool is destroyed during process shutdown.

The `parallelFor` worker pool is not an Async Task/JoinHandle system. Pool jobs have no public cancellation or priority API, and the scheduler offers no fairness guarantee or proof against deadlock in arbitrary blocking callbacks. V126 cancellation applies only to `thread.start` handles, not to pool workers. The fixed 32-worker cap is a resource policy; fewer workers may be available when the operating system cannot create them.

## 4. Runtime safety rules

1. A handle returned by a `create/open/start` API must be released exactly once using its documented paired release API.
2. A thread, callback, or asynchronous operation must not outlive the owner of any raw pointer it uses.
3. A `sync.Channel` or `sync.Cell` handle must not be freed while another thread is inside one of its operations. `close()` wakes blocked channel waiters; the owning class must remain alive until those waiters return.
4. A mutex must be unlocked by the owning thread. Do not use `volatile` for synchronization.
5. `memory.collectCycles()` must be called at a quiescent point; it is not a concurrent stop-the-world collector.
6. C++ exceptions must not unwind through FAC-generated frames. FAC runtime functions that may throw C++ exceptions must catch them and convert them only after C++ resources in the relevant scope have been released.
7. `do_throw` uses non-local control transfer and bypasses C++ destructors. Runtime code must not call it while non-trivial C++ automatic objects are live unless it first releases/moves their resources explicitly or registers the resources with a FAC cleanup guard.
8. A cleanup guard must be removed only after success/ownership transfer; every failure path must leave its guard registered so the FAC cleanup stack can release the temporary.

## 5. ABI and portability boundary

- Runtime/compiler layouts must be built from the same source release and target data model.
- The supported foreign boundary is the target C ABI, not a universal C++ object ABI.
- The current runtime uses a 64-bit pointer-size model; 32-bit and Wasm runtimes are not claimed.
- A target is supported only after building the compiler and runtime for that target and passing compile/link/run, ABI, ownership, sanitizer and concurrency tests on it.
- `gpu.fac` remains a CPU reference buffer API in this release; a device backend requires a separate implementation and conformance suite.

## 6. Known Runtime gaps / roadmap

| Area | Gap | Next step |
|---|---|---|
| Error propagation | Worker errors are saved on the thread handle and re-raised by `thread.join`; there is no async task result type | Introduce a typed `Task<Result<T,E>>` API and cancellation-safe state machine before adding a scheduler. |
| Thread handles | Raw opaque pointer handle has no static affine type | Add a managed `Thread` type with one-shot join/detach semantics and leak-safe shutdown policy. |
| Channel lifetime | Caller must ensure no operation races with handle destruction | Add managed shared-handle ownership or an explicit close-and-wait protocol. |
| Allocator | Tracking is diagnostic and opt-in; no pool API or allocator injection interface | Specify allocator traits and per-domain allocation only after measuring workload needs. |
| Borrow/lifetime | Runtime refcounts do not replace static lifetime checking | Build CFG loan analysis in the compiler; keep raw FFI pointers unsafe. |
| Cycle collection | Explicit and partial trace coverage | Add trace coverage for additional managed aggregates only with proof and stress/sanitizer tests. |
| Async runtime | No general async scheduler, typed task result/future contract or cancellation propagation to `parallelFor` | Design task state machine, ownership transfer and cancellation-safe destruction before adding `async/await`. |
| GPU/media | Cross API abstractions are not complete hardware backends | Implement independent platform backends and report capability fallback. |

Do not describe any row as completed until its implementation and required tests are part of a release.
