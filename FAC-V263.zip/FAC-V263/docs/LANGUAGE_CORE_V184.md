# FAC Language Core — V184

## Scope

V184 is the next sequential release after V183. It broadens exact fixed-array borrow projections from a single integer literal to a carefully bounded subset of pure integer constant expressions.

## Implemented

- A fixed-size array index is exact when it is a non-negative integer literal or a pure constant expression composed of integer literals, unary `+`/`-`, and binary `+`, `-`, `*`, `/`, `%`.
- Evaluation is bounded to 64 AST nodes and uses checked signed arithmetic.
- Intermediate results must fit their FAC signed width: 32-bit `int` or 64-bit `long`, selected from the integer literals and promoted through the expression.
- Equivalent constant expressions normalize to the same projection. For example, `values[1 + 1]` and `values[2]` overlap; `values[3 * 2]` and `values[2]` are disjoint.
- The normalized projection is used for loan creation, reborrows, owner access and active-loan overlap checks through the existing projection path.

## Conservative boundary

Negative final values, overflow at any intermediate step, division/remainder by zero, expressions deeper than the fixed visit budget, identifiers/variables, calls, increments, assignments, short-circuit/comparison/bitwise operators, computed bases, pointer indexing, lists, matrices, globals/statics and opaque aliases remain conservative may-alias paths. This increment does not add dynamic range analysis, bounds proofs, indexed move semantics, reference-valued containers, general lifetime parameters or Rust-equivalent borrow checking.

## Compatibility

No syntax, code-generation layout, Runtime source, public API, C ABI or Runtime ABI changed. This is part of the existing opt-in strict local-borrow analysis (`--strict-ownership` and the existing secure profile); default legacy compilation behavior remains unchanged. Runtime array bounds checking remains in its existing path.

## Regression coverage

- `good_array_constant_expression_indices.fac`: simultaneous borrows through `+`, `-`, `*`, `/`, `%`, and unary `+`/`-` constant expressions, with runtime writes proving each alias targets the original array storage.
- `bad_array_constant_expression_same_index.fac`: `values[1 + 1]` conflicts with `values[2]`.
- `bad_array_constant_expression_overflow.fac`: overflowing `int` arithmetic is not treated as an exact projection and therefore cannot be used to prove disjointness.
- Existing dynamic-index and same-literal-index negative fixtures remain in the suite.

The release record in `docs/STATUS.md` records only validation commands completed for this archive.
