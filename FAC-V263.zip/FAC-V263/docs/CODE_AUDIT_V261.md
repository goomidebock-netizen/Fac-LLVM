# FAC V261 — focused source-code audit

## Finding

**Severity: Medium — owned `thread.start` handle could not retain provenance through local aggregate moves**

The strict-ownership checker already tracked pointer origins in local value
struct fields and required complete verified field facts when a pointer-bearing
aggregate was passed to a function. However, the checker did not recognize the
exact `thread.start` result as an independently allocated owned handle. The
value was therefore treated as an unverified pointer when placed in a struct
field. Moving the checked struct (especially through a nested value-struct
field) could also be treated like an ordinary call that might let pointer
arguments escape. This blocked a valid, explicit ownership transfer followed
by the documented release operation `thread.join`.

A related supported use case is a typed `ptr thread` field taken from a
by-value struct parameter and passed directly to `thread.join`. The API
contract says `thread.join` consumes and frees the handle; it does not retain
an arbitrary pointer. The checker previously treated that argument as an
unknown pointer escape even though it is the consumed resource itself.

## V261 change

- The checker builds an exact qualified call path for a direct identifier/member
  callee. Only the exact `thread.start` call receives the synthetic owned
  handle origin.
- That origin is independent of caller-frame storage and is rooted at the
  outer function region, allowing it to be carried in a local pointer-bearing
  value struct and through explicit `move(...)` transfers.
- `move(value)` is handled as a language intrinsic, not as a potentially
  escaping ordinary function call. The argument expression remains checked,
  and active-loan move restrictions still apply.
- Only argument zero of the exact `thread.join` call, when its static type is
  exactly `ptr thread`, is treated as the consumed opaque handle described by
  the API ownership contract.
- Arbitrary incoming `ptr thread` parameters remain untracked and are still
  rejected when stored in value-struct fields.

This is not general pointer or resource provenance. It does not implement
whole-program/heap escape analysis, generic handle ownership, automatic join,
interprocedural nested-struct summaries, complete helper effect inference,
all aliasing cases, or a complete borrow checker. It also does not prove
thread safety or data-race freedom. No language syntax, Runtime semantics,
ARC/GC behavior, public API, ABI or `--memory-safe` accepted subset was
changed.

## Regression tests

Added three focused fixtures:

- `tests/lifetimes/v261_thread_owned_handle_struct_move_allowed.fac` — an
  owned `thread.start` handle is placed in a nested local value struct, moved
  twice, and consumed with `thread.join`.
- `tests/lifetimes/v261_untracked_thread_pointer_field_rejected.fac` — an
  arbitrary incoming `ptr thread` cannot be retained in a value-struct field.
- `tests/lifetimes/v261_thread_handle_parameter_consumed_allowed.fac` — a
  typed `ptr thread` field from a by-value struct parameter can be passed to
  the consuming `thread.join` operation.

## Validation

- Clean versioned compiler build and forced Runtime archive rebuild succeeded
  with Clang 17 / C++17 / `-O0 -g0`.
- Version check: FAC, Core, Lib, API, Lang, Runtime and Stdlib all V261.
- Lifetime suite: 147 PASS, 0 FAIL.
- Ownership/local-borrow/effect suites: 12/12, 8/8, 167/167, 17/17,
  25/25, 19/19 and 13/13 respectively.
- Move 20/20; Partial Move 28/28; Compile-time 57/57; Memory-Safe 39/39;
  Generic 3/3; Lexer 18/18; Parser 68 checks + AST 1/1; Codegen passed.
- Safe Profile: 435 passed, 2 failed. Both remaining failures are V76 nested
  aggregate helper-provenance checks. The V75 struct-move checks now pass.
- API checks passed: 663 built-ins, 1,014 source declarations, 5 findings
  (0 beyond baseline), 950 public function contracts (0 missing annotations),
  0 breaking changes against V128 (132 warnings), 114 generated docs current.
- Standards and Formatter checks passed.
- Runtime test output showed PASS for completed individual cases, but the
  complete runner did not produce a confirmed exit status after the overall
  chained command hit its time limit. Semantic reported 17 ancestry checks
  before timeout. The Tools test timed out before completion. These suites are
  not claimed as complete passes.

Full CMake/CTest, sanitizers, actual Windows/macOS builds and runtime testing,
and production qualification are not claimed.
