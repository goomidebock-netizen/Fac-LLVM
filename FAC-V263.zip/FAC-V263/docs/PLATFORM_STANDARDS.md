# FAC Platform, Architecture, Object Format and ABI Standards — V53

This document selects external standards that FAC should interoperate with. It is not a claim that every target is implemented. A standard is a compatibility target; FAC must still pass target-specific compiler, runtime, linker, loader, and conformance tests. The expanded machine-readable inventory, including calling-convention and GPU interop contracts, is `api/standards.json` schema 2. V53 does not claim additional OS/architecture backends merely by listing their standards.

## 1. OS interface families

| Family | Baseline to follow | FAC layer | V53 status |
|---|---|---|---|
| Windows desktop/server | Win32 API, Windows SDK, PE/COFF, Microsoft x64 ABI | `native.win32`; cross adapters where possible | Partial host toolchain/FFI path; not a complete native module |
| POSIX systems | POSIX.1-2024 where implemented by the OS/libc | `native.posix` | Design target; not validated across POSIX OSes |
| Linux | POSIX plus Linux-specific interfaces; prefer libc interfaces over raw syscalls | `native.linux` | Linux host development is possible; target-wide parity unverified |
| Apple macOS/iOS | Darwin APIs, Mach-O, Apple platform SDKs; Cocoa/Metal where relevant | `native.cocoa`, `native.metal` | Planned; not validated |
| Android | Android NDK, Bionic, JNI where needed, ELF/AArch64 ABI | `native.android` | Planned; not validated |

Do not treat Linux syscalls as a portable POSIX API. Use the POSIX/libc layer for portable operations and place Linux-only interfaces behind `native.linux`.

## 2. Architecture and data model

Initial architectural families to design and test:

| Architecture | ABI / data-model reference | Notes |
|---|---|---|
| x86-64 | System V AMD64 psABI on ELF/Mach-O Unix-like systems; Microsoft x64 ABI on Windows | These are distinct calling conventions; target OS selects the default |
| AArch64 | AAPCS64; platform supplement such as Windows ARM64 or Apple arm64 rules | Do not assume all AArch64 OSes use identical runtime/linker rules |
| RISC-V 64 | RISC-V ELF psABI | Validate floating-point ABI and extension set |
| PPC64 / PPC64LE | Platform ABI and ELFv2 where applicable | Endianness and calling convention must be explicit |
| s390x | System z ELF ABI | Validate vector/floating-point calling rules |
| LoongArch64 | LoongArch ELF ABI | Validate ABI/toolchain maturity before claiming support |

The current compiler/runtime has 64-bit pointer-size assumptions. Until that is removed and tested, FAC must not claim 32-bit, wasm32, or 16-bit MCU support. A target triple being accepted is not the same as a complete platform being supported.

## 3. Object and executable formats

- **ELF**: Linux and many Unix-like targets. Respect the target's ELF ABI, relocations, dynamic loader, TLS, and unwind conventions.
- **PE/COFF**: Windows object files, import libraries, and executables. Respect Windows SDK/linker conventions and x64/ARM64 calling conventions.
- **Mach-O**: Apple targets. Respect platform deployment targets, code signing, dyld, and Apple SDK conventions.
- **Wasm module formats**: future target only; require a separate WASI/Web host and pointer-width/runtime redesign. Not supported by the current V45 runtime.

## 4. Calling convention and FFI

The first supported foreign-function boundary should be the target's **C ABI**. C++ object ABI is compiler- and platform-sensitive and must not be treated as a stable universal interface.

Required FFI contract fields:

- target triple and ABI (for example SysV AMD64, Microsoft x64, AAPCS64);
- calling convention and symbol name/mangling;
- integer widths and signedness (`int32_t`, `uint64_t` etc. at C boundaries);
- struct size, field offsets, alignment, padding, and packing;
- aggregate argument/return lowering;
- string encoding and NUL-termination policy;
- callback lifetime and thread entry rules;
- ownership of returned/borrowed pointers and allocator pairing;
- exception/unwind boundary (do not unwind a C++ exception through FAC frames unless explicitly supported);
- library name, search path, SDK minimum, and link flags.

FAC `long` is a fixed 64-bit signed integer, not necessarily the platform C `long`. Keep using fixed-width C types in public C headers. Do not export managed `string`, `list`, or object internals directly as C ABI values; use opaque handles and explicit create/retain/release functions.

## 5. LLVM target contract

FAC's compiler target identity must be a full LLVM target triple in the form `architecture-vendor-os-environment` (vendor/environment may be omitted only where LLVM defines a canonical default). The driver must verify:

1. target triple is supported by the selected LLVM/Clang toolchain;
2. the runtime archive is built for the same target and data model;
3. headers, libc/C++ runtime, linker, sysroot and system libraries match;
4. selected CPU/features are valid for the target;
5. output format and platform deployment target match the requested OS.

`--target` alone does not cross-compile a host-built runtime archive. `--cpu native` is a local optimization choice, not a portable distribution default.

## 6. GPU and compute standards

| API / standard | Intended role | FAC status in V45 |
|---|---|---|
| Vulkan 1.4 | Cross-vendor graphics and compute; native explicit API | Planned native binding; not implemented by `gpu.fac` |
| Direct3D 12 | Windows graphics/compute | Planned Windows-native binding |
| Metal | Apple graphics/compute | Planned Apple-native binding |
| WebGPU | Portable graphics/compute abstraction for Web/WASM hosts and supported native implementations | Future cross API backend; current `gpu.fac` is not WebGPU |
| SPIR-V | Portable intermediate representation for graphics/compute shaders | Planned shader toolchain; not currently emitted by FAC |
| WGSL | WebGPU shader language | Planned interop/translation target; no current compiler support |

The current `gpu.fac` API uses CPU-side reference buffers and reports no hardware acceleration in this build. It must not be described as a GPU compute implementation. A production GPU layer needs device discovery, queue submission, explicit synchronization, resource lifetime, shader compilation, memory barriers, validation, and per-backend conformance tests.

## 7. Audio, UI and media interoperability

- Audio device backends should use the platform-native systems: WASAPI on Windows, Core Audio on Apple systems, and an ALSA/PipeWire-compatible route on Linux. Keep the FAC cross API around streams, formats, buffers, callback/thread rules and device capability negotiation.
- UI should keep a platform-independent event/widget model separate from native windowing and rendering backends. Desktop and mobile input/lifecycle are not identical; report capability differences rather than flattening them away.
- Font/text rendering requires explicit UTF-8 handling, Unicode segmentation, shaping, fallback and glyph metrics. A simple bitmap font renderer is not a complete typography system.

## 8. Conformance gate for a platform claim

A platform may be labelled **supported** only after:

- compiler bootstrap/build on the host;
- FAC runtime built for the target;
- compile, link, and run smoke tests;
- FFI/ABI layout and callback tests;
- memory/ownership tests under sanitizers where available;
- concurrency tests under ThreadSanitizer or an equivalent tool where available;
- shared cross-API behavior tests;
- native API tests for that OS/architecture;
- release CI artifact inspection.

## 9. Standards references

- IEEE/Open Group POSIX.1-2024: <https://standards.ieee.org/ieee/9945/12489/>
- LLVM Language Reference (target triple and IR contract): <https://llvm.org/docs/LangRef.html>
- Clang Cross Compilation: <https://clang.llvm.org/docs/CrossCompilation.html>
- Arm ABI specifications (AAPCS64, ELF and related ABI): <https://github.com/ARM-software/abi-aa>
- Microsoft x64 calling convention: <https://learn.microsoft.com/en-us/cpp/build/x64-calling-convention>
- Microsoft PE/COFF format: <https://learn.microsoft.com/en-us/windows/win32/debug/pe-format>
- Apple Mach-O documentation: <https://developer.apple.com/documentation/kernel/mach-o>
- Khronos Vulkan specification: <https://registry.khronos.org/vulkan/specs/latest/html/vkspec.html>
- W3C WebGPU status and current draft: <https://www.w3.org/TR/webgpu/>

Standards and drafts evolve. Release engineering must re-check the official specification version before freezing any target contract.


## 10. V171 CPU-only numeric-buffer contract

V165 configured hosted CI smoke coverage for Linux ARM64 (`ubuntu-24.04-arm`) and macOS ARM64 (`macos-15`) using native runners. Linux x86-64 GCC/Clang and Windows x64 lanes remain in the workflow. These jobs verify builds and selected CTest/runtime paths only when a workflow run actually passes; they do not independently certify the full OS/architecture/API matrix.

In V170 and V171, the historical `gpu.*` namespace is a compatibility surface for host-resident float64 buffers and CPU numeric operations only. The active Runtime contains no OpenCL loader, platform/device discovery, device allocation, queue, kernel compilation, or hardware dispatch. CPU SIMD is used where supported with a portable scalar fallback. `gpu.hardware()` is always false; `gpu.openclStatus()` is a deprecated compatibility query that always returns `disabled`. The machine-readable GPU standards inventory describes future interoperability targets, not active Runtime dependencies or current hardware support.

## 11. V53 ABI and API-layer policy

- FAC's internal LLVM calling/lowering conventions are implementation details and are not a stable plugin ABI.
- The external interoperability baseline is the target C ABI. Exports should use C linkage and fixed-width integer types; managed FAC values remain opaque and cross the boundary only through wrappers/handles.
- The C++ ABI is not treated as a universal stable interface. Catch/translate foreign C++ exceptions before control returns through FAC frames.
- x86-64 System V AMD64 and Microsoft x64 are separate contracts. AArch64 follows AAPCS64 plus each OS's ABI supplements. The target triple, sysroot, C runtime, C++ runtime, linker and FAC Runtime archive must match.
- CPU atomics and GPU queue/fence/barrier semantics are separate synchronization domains. `volatile` is not an atomic primitive.
- `cross.*` and `native.*` remain reserved namespaces in V53; they are not yet shipped importable module families. Existing `stdlib/*.fac` imports remain the compatibility API.
- The build and release conformance matrix must be keyed by OS × architecture × ABI × toolchain. A family-level allowlist is not a support claim.

See [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md) for the complete target matrix and support status.
