# FAC LLVM V135 — Runtime error-path ownership audit

**Release:** V135  
**Scope:** two C ABI Runtime functions that construct managed string lists (`sys.args` and JSON array conversion)  
**Public API / ABI:** no signature, type layout or standard-library declaration changed

## Finding

FAC Runtime errors currently transfer control with `setjmp`/`longjmp`. A direct jump out of a C ABI function bypasses ordinary C++ automatic-object destructors. The V134 Runtime already uses an explicit cleanup stack for managed values that must survive FAC error paths, but two list builders did not register their partially constructed result:

- `fac_args` could leave the list header, backing storage and strings already copied into the list allocated if a later argument-string allocation or list growth failed.
- `fac_jd_list` could leave the result list allocated if a later JSON array element had the wrong type. For string lists, already-converted FAC strings were also owned by that abandoned list and leaked with it.

These are error-path resource leaks, not evidence of an invalid free or a dangling pointer in the normal successful path.

## Fix

Both functions now push the result list onto the Runtime cleanup stack immediately after allocation. On successful return, the cleanup entry is popped and ownership transfers to the caller. On FAC error, the normal cleanup runner releases the partially populated list; `fac_list_free` releases every completed string element as well. `fac_args` grows the list before creating the next string, so a failed growth cannot strand a newly created element outside list ownership.

## Regression coverage

`tests/runtime/list_error_cleanup.cpp` creates malformed numeric and string JSON arrays. It starts FAC allocator tracking immediately before conversion, triggers each error inside a FAC try frame, and checks both allocated bytes and block counts return to the exact pre-call baseline. The string case first converts a valid string element, then fails on a later non-string element, verifying cleanup of both the list and the already-converted string. The test also checks successful JSON conversion and the `sys.args` result path.

The test is wired into the Runtime shell suite and CTest as `runtime-list-error-cleanup`.

## Validation performed for this release

- Compiler + Runtime build: Clang 17, C++17, `-O0 -g0` — passed; `facc --version` reports V135 for all components.
- CMake/CTest: Clang 17 Debug (`-O0 -g0`) — **11/11 passed**, including the new `runtime-list-error-cleanup` test and package install consumer.
- Full Runtime shell suite (`CXX=clang++ sh tests/runtime/run.sh`) — passed on the second full run. The first run had one transient worker-pool reuse failure; the worker-pool test passed three isolated reruns and the full suite passed on rerun. This remains a test-stability observation, not a claimed V135 code fix.
- Focused Runtime cleanup regression — passed; the same test passed under Clang ASan+UBSan with `detect_leaks=1` and `halt_on_error=1`.
- Memory-safe profile: **25/25** passed on the V135 compiler.
- Safe-language suite: **316/316** passed.
- Core compiler cases (`tests/run.sh -O0`): **127/127** passed.
- Negative diagnostics: **132/132** passed; input/resource limits: **21/21** passed.
- Ownership checks: ownership **11/11**, const-method **8/8**, local-borrow **91/91**, noescape **17/17**, field-sensitive borrow **19/19**, effect-contract **19/19**, function-effect **13/13** — passed.
- Move checks: **20/20** and partial-move **23/23** — passed.
- API/standards checks: 623 built-in and 384 source declarations audited; 381 source functions satisfy contract metadata; compatibility remains **0 breaking / 26 warnings / 0 added** versus V128. Those 26 warnings predate V135 and reflect validation/error-contract changes.

Validation limits: a GCC 14.2 `-O2` compiler build exceeded the command execution window; a full optimized compiler build is therefore not claimed. The Runtime ASan+UBSan run covered the new targeted cleanup regression, not every Runtime function. Windows/macOS and a full Runtime TSan pass were not run. No benchmark-based runtime speedup is claimed.

## Remaining limitations

This is not a general Runtime unwind redesign. Any other C++ object left alive across a `do_throw` path may still need the same kind of explicit cleanup or a broader architectural solution. FAC continues to use `setjmp`/`longjmp`; arbitrary C++ destructors are not automatically run by that mechanism. The `--memory-safe` profile remains a conservative source subset, not a proof of Runtime correctness, whole-program race freedom, or equivalence to Rust. No runtime speedup is claimed; performance should be benchmarked separately with representative workloads.
