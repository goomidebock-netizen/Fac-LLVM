# FAC Compile-time, Template and Metaprogramming — V220

## 1. Implemented compile-time behavior

FAC already evaluates a deliberately limited set of integer constant expressions for array dimensions, match patterns and generic specialization metadata. V52 introduced (and V53 retains) a user-visible module-level assertion:

```fac
const var int PAGE_SIZE = 4096
const var int ALIGNMENT = 64

static_assert(PAGE_SIZE == 4096, "page size contract")
static_assert(PAGE_SIZE % ALIGNMENT == 0, "page alignment")
static_assert((ALIGNMENT & (ALIGNMENT - 1)) == 0, "alignment must be a power of two")
static_assert(!(false && (1 / 0)), "short-circuit is preserved")
```

The syntax is `static_assert(constant_expression, "message")` at module top level. The second argument is a required string literal. It emits no runtime code. The expression must evaluate to a nonzero integer/bool for the assertion to pass. A false result is a compile error containing the user message.

The current evaluator supports integer/boolean literals, eligible scalar `const` globals in the same module, unary `+ - ! ~`, arithmetic `+ - * / %`, shifts, bitwise `& | ^`, comparisons, equality and logical `&& ||`. Logical operators preserve short-circuit semantics, so a dead right-hand expression is not evaluated. Overflow, division or remainder by zero, `INT64_MIN / -1`, invalid shift counts and non-constant expressions are rejected rather than evaluated by the host compiler with undefined behavior.

The base constant-expression evaluator remains side-effect-free. V220 additionally supports an explicitly marked, bounded `consteval` interpreter for scalar free functions; it does not make ordinary user functions executable at compile time. The interpreter has a restricted statement/expression subset and hard depth/step budgets, and it provides no file/environment, network, process/thread, device, allocation, runtime-function or FFI capabilities. The typed constant intrinsics are `typeOf<T>()`, `sizeof<T>()` and `alignof<T>()`; bounded structural field queries are `fieldCount<T>()`, `fieldName<T, I>()`, `fieldType<T, I>()` and `fieldOffset<T, I>()`. The latter require a resolved struct/class type and enumerate only public, non-static instance fields (including inherited public fields); the field index is a compile-time integer. `fieldType` reports the existing `Type` category, `fieldName` returns a static string literal, and `fieldOffset` reports the active record-layout byte offset. Numeric field queries can participate in `static_assert`, supported scalar `consteval` bodies and const generic expressions. They do not expose private/protected or static declarations, generic specialized records, interfaces, enums, mutable metadata or source-level AST values. The compiler separately materializes an immutable, source-mapped typed-expression AST projection from fully typed HIR expressions; unresolved or unsupported expressions are omitted. V220 also provides an internal C++ `TypedAstFactory` that can append immutable, type-checked generated expression nodes to a validated semantic model. Neither AST facility is exposed to FAC source code or `consteval`; TypedAstFactory-generated expression nodes are not yet consumed by Codegen. Separately, the C++ `TypedDeclarationBuilder` can create a bounded set of non-generic struct and free-function declarations in HIR, and the V220 Codegen bridge lowers eligible generated structs plus external free-function prototypes through temporary backend Programs without mutating source AST ownership. This does not generate function bodies or expose declaration construction to FAC code. See [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md), [`TYPED_CONSTANT_VALUES_V220.md`](TYPED_CONSTANT_VALUES_V220.md), [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md), [`TYPED_AST_BUILDER_V220.md`](TYPED_AST_BUILDER_V220.md), [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md), [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md) and [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md). Assertions are evaluated during compiler generation after module constants have been registered.

## 2. Generic and template programming

- **Generic programming** parameterizes code over types and interface/type constraints. FAC supports generic classes, structs, interfaces, methods, multiple bounds (`T: A & B`) and compile-time specialization.
- **Template programming** additionally parameterizes declarations over compile-time values (for example fixed-array dimensions). V220 supports a bounded `const int` subset for generic struct/class types, free functions and methods.
- Generic specialization is monomorphized to concrete LLVM types/functions. It is not a runtime type-erasure or universal dynamic generic system. Generic inference, variance, generic interface methods and generic virtual/override method type parameters remain incomplete.

Implemented V220 subset:

```fac
public struct FixedBuffer<T, const int N> {
    public array var T values[N]
    public array var T doubled[N * 2]
}

public function<const int N> int capacity() { return N }
public function<T, const int N> T keepSized(T value) { return value }

public function void main() {
    struct FixedBuffer<int, (2 * 8)> samples
    var int count = capacity<(3 * 4)>()
    var int value = keepSized<int, (PAGE_SIZE / 2)>(7)
}
```

The supported contract is intentionally restricted:

- Generic `struct`/`class` declarations, generic free functions and generic methods may declare `const int` parameters mixed with type parameters. The declaration order defines the call-site argument order.
- A const argument is an integer constant expression supported by the bounded evaluator above, rather than an arbitrary runtime expression. Parentheses disambiguate expressions in generic argument lists. Eligible module-level `const` values can participate where the constant evaluator can resolve them. The value is represented as signed 64-bit integer; overflow, divide-by-zero and invalid shift operations are rejected.
- Generic methods and generic struct/class instantiations with const parameters do not infer omitted arguments; trailing generic defaults may supply omitted parameters (for example `keepSized<int>(7)` when the const parameter has a default). Generic free functions may omit the entire generic argument list when a const parameter is used directly as a fixed-array extent (`[N]`) and a fixed-size array argument supplies that extent; type parameters may be inferred from the same argument. This does not infer from runtime lengths, integer arguments or algebraic extent patterns such as `[N * 2]`. Explicit arguments may be positional, named (for example `keepSized<N = (2 * 8), T = int>(7)`) or positional followed by named; omitted parameters with defaults are filled in declaration order. Free-function inference occurs before default fallback when the generic argument list is omitted. See [`GENERIC_DEFAULT_ARGUMENTS_V220.md`](GENERIC_DEFAULT_ARGUMENTS_V220.md) for resolution rules. Type-only generic free functions retain their existing inference path (for example `identity(7)`). See [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md) for the exact boundary.
- Const values are part of specialization identity and are substituted throughout function/method bodies and dependent type arguments. They can control fixed-array field and local-array dimensions. A resulting array dimension must be positive; existing array/record layout checks reject oversized layouts and overflow. Generic instantiation still obeys the 64-level nesting and 5,000 distinct-specialization budgets.
- Const parameters do not yet support type/interface bounds. Only `const int` is supported; enums/interfaces cannot declare their own const parameters. Generic virtual/override dispatch and generic interface methods remain unsupported.

This is a bounded value-parameter specialization feature, not a general C++-style template engine. V220 also provides the separate restricted `consteval` free-function subset documented in [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md), plus bounded public-field structural queries described in [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md). Generic `consteval`, arbitrary compile-time execution, source-level typed AST/declaration builders, unrestricted macros and compile-time I/O remain unsupported. Internally, V220 builds an immutable typed-expression AST projection and provides a bounded C++ factory for generated expression nodes, a `TypedDeclarationBuilder` for non-generic generated struct/free-function records in HIR, and a `TypedFunctionBodyBuilder` for scalar bodies with mutable locals, exact-type assignments and nested `if/else` branches on generated free functions. These APIs are not exposed to FAC programs or `consteval`. Eligible generated structs, body-less external prototypes and supported generated function bodies are lowered by a bounded Codegen bridge; loops, multiple return paths, branch-local declarations, aggregate bodies and broader declaration kinds remain unsupported. See [`TYPED_AST_BUILDER_V220.md`](TYPED_AST_BUILDER_V220.md), [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md), [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md), [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md) and [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md). See [`CONST_GENERIC_FUNCTIONS_V220.md`](CONST_GENERIC_FUNCTIONS_V220.md) for function/method call rules and regression coverage.

## 3. Planned CTM phases

### Phase A — stronger constant language

V220 implements bounded typed-query subsets: `typeOf<T>()` returns an enum `Type` category, while `sizeof<T>()` and `alignof<T>()` return active layout size/alignment as integer constants. Structural queries expose only public non-static instance fields of resolved struct/class records through `fieldCount`, `fieldName`, `fieldType` and `fieldOffset`; they do not enumerate or mutate arbitrary declarations. Full typed constant values (including aggregate/enum payload values), target-independent overflow semantics, generic structural reflection and richer compile-time assertions over type structure remain planned.

### Phase B — broader bounded `consteval`

V220 implements an initial scalar free-function interpreter with local variables, branches, return, nested calls and recursion, bounded by depth 64 and 100,000 counted steps. Further work: broader typed constant values, wider control flow only where determinism and budgets can be enforced, more precise effect/diagnostic contracts, and target-independent constant semantics. Generic functions/methods and aggregate/heap operations remain outside the current subset.

### Phase C — typed metaprogramming

V220 has an internal immutable typed-expression projection and a bounded C++ `TypedAstFactory` for literals, supported unary/binary expressions, tuples and exact pre-resolved non-generic free-function calls. It also has a C++ `TypedDeclarationBuilder` for non-generic generated struct/free-function declarations registered in HIR after TypeId, identifier, duplicate and model validation. Neither API is available from FAC source or `consteval`. The Codegen bridge now projects eligible generated non-generic structs, external free-function prototypes and a limited scalar body subset with mutable locals, exact-TypeId assignments and nested `if/else` over predeclared locals into the existing backend; it does not expose builders to FAC programs. Next: loops, multiple returns, branch-local scopes, broader generated declaration kinds and a full post-generation semantic contract under the same validation boundary. Prefer typed builders over unrestricted string macros.

## 4. Non-goals

- Arbitrary C++/host execution during compilation.
- Network/package downloads during constant evaluation.
- Reading secrets or ambient environment variables at compile time.
- Unrestricted macro expansion that can bypass type checking.
- Native compiler plugins loaded without a sandbox or explicit trust model.

## 5. Validation requirements

Every CTM phase needs positive and negative tests, deterministic-build tests, arithmetic/overflow tests, recursion and resource-budget tests, malformed-input diagnostics, target-independent results and a guarantee that rejected compile-time code cannot perform external side effects. V220 regression coverage includes consteval recursion-budget rejection and imported-module calls, typed-query categories, record padding/alignment, object-handle layout, consteval integration, const-generic expression integration, structural field enumeration/name/category/offset queries, class inheritance and static/private field filtering, plus rejection of runtime query arguments, invalid target types and out-of-range/non-constant field indexes.
