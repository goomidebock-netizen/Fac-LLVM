# FAC V220 Expression HIR (development)

## Purpose

The declaration HIR and name/type resolution passes establish canonical type
IDs and declaration identities. This document describes the next frontend
boundary: a source-mapped expression index with conservative, syntax-provable
type facts.

The Expression HIR is built by `fac_hir::ExpressionHirBuilder` as part of
`fac_hir::analyze()`. It is available in `SemanticModel::expressions` and is
validated before Codegen consumes the parsed program.

## Expression records

Each expression occurrence has:

- a stable `ExprId` within the semantic model;
- its source `Node*`, source line and containing module;
- its owning declaration `SymbolId` when it belongs to a function, method,
  global initializer or type member;
- parent and child expression IDs;
- a `TypeId` and a type state (`Known`, `Dependent` or `Unresolved`);
- a type origin (`Literal`, `OperatorRule`, `BuiltinContract`,
  `ExplicitSyntax`, `LocalBinding` or `OverloadResolution`);
- lexical `ScopeId`, source-order index and optional `LocalSymbolId` binding;
- call-resolution state, candidate symbols, selected symbol and conversion cost;
- conservative lvalue and side-effect hints.

The parsed `Program` owns all referenced AST nodes. Consequently the expression
records are non-owning and must not outlive the parsed programs.

## Currently typed expression forms

The initial inference set is deliberately limited to facts that can be
established without consulting Codegen's mutable lexical scopes:

- integer, floating-point, character, string, boolean and null literals;
- unary `!`, unary numeric `+`/`-`, and integer `~` when the operand type is
  known;
- common numeric promotion for supported arithmetic/bitwise operators;
- boolean results for comparisons, logical operators and `instanceof`;
- string concatenation when both operands are known strings;
- tuple literals when every element has a known type;
- `new Class` expressions, represented as named object types;
- `str`, `size`, `sizeof`, `strcmp`, `math.abs`, `math.min` and `math.max`
  according to their fixed or argument-dependent builtin result contracts;
- lambdas with an explicit return type and parameter signature.

`Known` means the type is established by one of these explicit rules. It does
not mean the entire expression has passed every semantic validation performed
by the legacy compiler.

## Deliberately unresolved forms

The current extraction boundary still leaves these cases to later passes:

- module-global and other non-local value-name lookup;
- generic function inference/specialization and explicit type argument
  substitution;
- instance/static method selection, indirect function-value calls, receiver
  conversion and full access validation;
- member access, indexing, slicing, dereference and flow-dependent expressions;
- match/conditional result unification and propagation operators.

Lexical local/parameter bindings and non-generic free-function calls are now
represented in HIR when enough type information is available. Generic or
incompletely typed candidate sets remain deferred rather than selecting a
possibly incorrect overload. HIR records no new diagnostics; the existing
Codegen path remains authoritative for all source diagnostics and LLVM IR
generation. This extraction is additive and does not alter source-language
behavior. See `docs/SCOPE_OVERLOAD_HIR_V220.md` for supported binding and
overload rules.

## Validation and regression

`SemanticModel::validate()` checks expression IDs, source ownership references,
parent/child consistency, owner SymbolIds, and known/unresolved TypeId states.
The standalone `tests/semantic/typed_expr_hir.cpp` test verifies literal types,
numeric promotion, builtin contracts, tuple/lambda type shapes, tree links,
and conservative unresolved cases. `tests/semantic/scope_overload_hir.cpp`
verifies lexical bindings, source-order visibility, shadowing, inferred local
types, overload ranking, imports, default arguments, and conservative deferral.
