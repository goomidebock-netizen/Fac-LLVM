# Compiler Frontend Architecture

## Current module boundaries (V220)

```text
src/main.cpp
  ├── src/parser.hpp ────────> src/ast.hpp + src/lexer.hpp
  ├── src/codegen.hpp ──────> src/ast.hpp + src/lexer.hpp
  │     └── gen_*.inc (LLVM IR generation methods)
  ├── src/ownership.hpp ────> src/ast.hpp + src/lexer.hpp
  └── src/move.hpp ─────────> src/ast.hpp + src/lexer.hpp

src/lexer.cpp ──────────────> src/lexer.hpp
```

`lexer.hpp` owns `CompileError`, `Tok`, UTF-8 helper functions, token budgets,
and the `lex()` declaration. `lexer.cpp` owns the implementation. The Parser
uses the same `Tok` layout and `lex()` contract as before. Make, CMake and the
Windows batch build compile and link the two Compiler objects independently.

This boundary gives incremental-build isolation: changing only `lexer.cpp`
rebuilds the Lexer object and relinks `facc` without recompiling the LLVM
Codegen implementation in `main.cpp`. A change to `lexer.hpp` rebuilds its
direct dependents (`main.cpp` and `lexer.cpp`), as expected.

## Deliberate remaining coupling

- `ast.hpp` owns the shared AST / TypeSpec / Program data model and deep
  clone helpers. `parser.hpp` includes it and owns the Parser methods.
- `codegen.hpp`, `ownership.hpp` and `move.hpp` consume `ast.hpp` directly;
  they no longer include the Parser implementation. They still use the shared
  `CompileError` contract from `lexer.hpp`.
- `codegen.hpp` defines the `Gen` implementation in a class body and includes
  the `gen_*.inc` fragments before closing the class. These methods rely on
  shared private state and direct access to AST details.
- `ownership.hpp` and `move.hpp` remain header-defined implementations and
  are tightly coupled to AST members.

Moving these components mechanically into `.cpp` files would create linkage
and declaration-order problems. The AST data-model boundary is now established
without changing syntax or semantics. The next refactor should expose
semantic/ownership/move interfaces that consume the shared AST, and only then
split `Gen` declarations from definitions. Each stage must keep a baseline
compiler available for LLVM-IR differential comparison and run focused
diagnostics plus the full available compiler regression set.

## Differential comparison

Build the previous release and the candidate compiler from their respective
source trees, then run:

```sh
make test-differential DIFF_BASELINE=/path/to/v131/build/facc

# Or invoke the script directly:
python3 tools/compare_compilers.py \
  --baseline /path/to/v131/build/facc \
  --candidate ./build/facc
```

The script compiles the same representative FAC fixtures with `--emit-ll`
and requires byte-identical LLVM IR. Build both compiler binaries with the same
host C++ compiler and equivalent flags; different host toolchains may emit the
same semantics with a different instruction order. A mismatch prints the first
differing lines. This catches accidental changes to tokenization, parsing, name
handling or code generation, but does not replace runtime tests, negative tests,
ownership/Move checks, sanitizer runs or platform CI.

## Declaration HIR boundary (V220 development)

`src/hir.hpp` introduces a declaration-level HIR and semantic index between
loading/parsing and LLVM Codegen:

```text
AST (ast.hpp)
  └── SemanticAnalyzer (hir.hpp)
        ├── TypeArena: canonical structural TypeId interning
        ├── Module/import/alias/link/static-assertion metadata
        ├── Declaration symbols and overload index
        ├── NameResolver: module aliases, imports, just/without and visibility
        └── TypeResolver: use-site SymbolId bindings and semantic type kinds
              └── existing Codegen (codegen.hpp + gen_*.inc)
```

The first HIR stage records module-level functions, methods, globals, records,
classes, interfaces and enums. Qualified-name indexes map to *lists* of symbol
IDs so legal overload sets are preserved rather than silently collapsed.
`TypeArena` interns structural `TypeSpec` shapes, including pointer qualifiers,
named lifetime bindings, function callback effects and generic arguments. Array
extent expressions remain borrowed references in `TypeUse`, because those
expressions belong to the source AST and may be needed by later lowering.

The HIR also contains a source-mapped expression index. Each expression
occurrence has an `ExprId`, parent/child links, owner declaration, source file
and line, a conservative lvalue/side-effect hint, and a type state. Literal
results, syntax-provable unary/binary operations, tuple literals, explicit
lambda signatures, `new Class`, and selected builtin result contracts receive
canonical `TypeId` values.

The next additive passes are now present in the same semantic pipeline:
`LexicalScopeResolver` builds module/function/block/loop/lambda/catch/match-arm
scopes, binds parameters and locals to stable `LocalSymbolId` values, applies
source-order visibility and shadowing, and propagates known local types into
identifier expressions. Locals declared with `auto` can inherit a proven
initializer type after call resolution. `OverloadResolver` currently resolves
non-generic free-function calls when argument types and candidate signatures
are sufficient, including local and imported module names, import aliases,
`just`/`without`, default parameters, exact matches and conservative numeric
widening. It records the candidate set, selected `SymbolId`, conversion cost,
and unresolved/ambiguous/no-viable states without emitting new diagnostics.

The next bounded extraction now handles statically identifiable instance and
static class method calls. `OverloadResolver` records method candidates,
selected symbols, conversion costs and generic substitutions. Named method
type parameters continue to require explicit type arguments; `auto` parameter
positions, including `list auto` and `array auto` element positions, can be
inferred from known arguments. Generic parameters in `list T` and `array T`
are matched against their element types. Generic class parameters are
substituted from concrete receiver types, including accessible named type
arguments. Nested generic return shapes are re-interned structurally. Built-in
and resolved named constraints distinguish proven failures from unresolved
cases. Complex imported receiver paths, inherited/virtual lookup, indirect
function-value calls, map key/value inference, variadics, and member/index/flow-dependent
typing remain incomplete.

The driver builds and validates the semantic model before calling
`Gen::generate`; Codegen remains authoritative for source diagnostics,
conversion checking, method dispatch, generic specialization, ownership/lifetime
checking and LLVM lowering. These rules will move only with focused
positive/negative coverage and differential comparison against the legacy
compiler path. See `docs/EXPRESSION_HIR_V220.md`,
`docs/SCOPE_OVERLOAD_HIR_V220.md` and
`docs/GENERIC_INFERENCE_HIR_V220.md` for the exact extraction boundary.

The HIR model owns its symbol/type/expression records and does not copy
move-only AST `TypeSpec` values. Source expression pointers, array extent
references and module-level static assertion references are non-owning and are
valid only while the corresponding loaded `Program` objects remain alive. Keep
that lifetime boundary explicit when introducing later expression-lowering
stages.

Regression coverage is provided by `tests/semantic/hir_model.cpp`,
`tests/semantic/typed_expr_hir.cpp`, `tests/semantic/scope_overload_hir.cpp`
and `tests/semantic/generic_inference_hir.cpp`. The generic inference test
covers list/array element binding, named user-defined type arguments, interface
constraints and unresolved constraint deferral.
The `scope-overload-hir-regression` test covers source-order visibility,
parameters, nested shadowing, `for-each`, catch and match bindings, inferred
locals, imported aliases, exact/widening overload ranking, defaults, ambiguous
and no-viable overloads, generic deferral and local-callable shadowing. The
`generic-inference-hir-regression` test covers explicit method type arguments,
`auto` inference, static methods, generic receiver substitution, nested generic
returns, supported constraints and conservative deferral.

### Next safe extraction stages

1. Extend method lookup to inherited members, imported receiver aliases and
   complete access checks.
2. Complete generic constraint solving and method-level type inference for
   supported receiver/call forms.
3. Extend typed expression HIR to member/index/flow-dependent forms and refine
   value category, mutability, ownership and lifetime facts.
4. Move conversion checking and semantic diagnostics with focused
   positive/negative fixtures and byte-identical LLVM IR differential checks.
5. Make Codegen consume typed HIR only after the AST-based path can be retired.
