# V215 Runtime shared-state safety: Pango vector fonts

## Concurrency gap

The POSIX font backend stores one Pango `Layout` inside each opaque `FacFont`. `font.measure()` calls `pango_layout_set_text()` and then reads layout dimensions; `font.height()` replaces the text with `Mg`; `font.draw()` changes layout text, queries extents, and renders through Cairo; and `font.setSize()` changes the layout description. These are mutable operations even when their FAC signatures appear observational. The process-wide Pango default font map and Fontconfig registry are also shared between independently-created handles. Before V215, only Fontconfig registration was protected, so simultaneous calls on one handle or simultaneous registration/layout creation could overlap unsafely.

## Change

`facfont::Api` now owns a process-wide `std::recursive_mutex backendMutex`. The POSIX font Runtime takes it around Fontconfig registration/map invalidation; Pango font-map/context/layout creation; description and text updates; layout measurement/height/extents; Cairo rendering; metadata access; and layout/context release. Lower-level helpers also guard themselves, hence the recursive mutex. The lock is internal: public declarations, C ABI signatures and opaque `FacFont` layout are unchanged.

The lock is deliberately process-wide because the font map and Fontconfig registry are shared. This prevents concurrent backend operations from racing but serializes vector-font work across all handles. It does not make a `Canvas` generally thread-safe: a canvas and its pixel buffer still need caller-side synchronization if shared by drawing/clearing/reading operations. As with other opaque handles, the caller must not free a `FacFont` until every operation using it has returned.

## Regression

`tests/runtime/font_vector_threads.cpp` exercises concurrent font load/registration, a single shared font handle, concurrent size and layout mutation, Latin/Thai measurements, height queries, draw operations on per-worker canvases and thread-local system-font caches. The ordinary Runtime suite builds and executes it when a test font and Pango stack are available. The generic ThreadSanitizer suite deliberately does not include it because the host Pango/GLib/Fontconfig shared libraries are not sanitizer-instrumented.


## Sanitizer limitation

A manual GCC ThreadSanitizer build of `font_vector_threads.cpp` could not provide a clean qualification for this optional stack. It reported conflicting allocator accesses whose stacks are entirely inside the host's uninstrumented GLib/Fontconfig/Pango shared libraries (including a library-created `[pango] fontcon` worker); retrying with third-party suppression entries caused a ThreadSanitizer nested-signal failure. The font stress test therefore remains in the ordinary Runtime suite but is not wired into the generic TSan suite. This is reported as an instrumentation limitation, not as evidence that the third-party report is a confirmed FAC Runtime race or that the backend has passed TSan.
