# FAC V220 — Generic Default Arguments

## Status and scope

V220 supports default values on generic parameters for generic `struct`/`class`/`interface`/`enum` declarations, free functions and generic methods. Type defaults are supported across these generic declarations. `const int` defaults are supported on `struct`/`class` declarations, free functions and generic methods (not on interfaces or enums). The compiler fills omitted parameters in declaration order before constraint checks, type substitution, specialization and cache lookup.

A default is not a new inference rule. For a generic free function called without an explicit generic argument list, supported argument inference is attempted first; a default is used only for a parameter that remains unresolved. Thus an inferred type/value overrides its declared default. When the call supplies a partial positional/named generic argument list, omitted parameters are filled from defaults; the remaining parameters are not inferred from function arguments in that explicit-list path.

## Syntax

```fac
public struct Buffer<T = int, const int N = 16> {
    public array var T values[N]
    public function int capacity() { return N }
}

public function<T = int, const int N = 12> T keepSized(T value) {
    return value
}

public function<T = int> T defaultValue() {
    var T value
    return value
}

public class Utility {
    public function<const int N = 9> int capacity() {
        return N
    }
    public function<T = int, const int N = 9> T keep(T value) {
        if (N > 0) { return value }
        return value
    }
}

public interface DefaultSource<T = int> {
    public function T get();
}

public class DefaultSourceImpl implements DefaultSource {
    public function int get() { return 23 }
}

public enum DefaultMaybe<T = int> {
    None,
    Some(T)
}

public function void main() {
    // Every parameter has a default: no argument list is needed.
    struct Buffer defaultBuffer

    // An explicit type overrides the first default; N uses its default.
    struct Buffer<double> doubles

    // Named partial arguments may omit parameters with defaults.
    struct Buffer<N = 4> small

    // Function defaults are applied after supported type/value inference.
    var double value = keepSized(2.5) // T is inferred as double, not defaulted to int

    // Explicit partial generic arguments use defaults for omitted parameters.
    var int count = keepSized<int>(42)          // N = 12
    var int defaultedType = defaultValue()      // T = int

    obj Utility utility = new Utility()
    var int standard = utility.capacity()       // N = 9
    var int smaller = utility.capacity<4>()     // N = 4
    var int methodValue = utility.keep(7)       // T = int, N = 9
    var double namedMethod = utility.keep<T = double>(2.5) // N = 9

    // Interface and enum type defaults are type-only defaults.
    obj DefaultSourceImpl source = new DefaultSourceImpl()
    enum DefaultMaybe maybe = DefaultMaybe<int>.Some(5)
}
```

## Declaration rules

1. A parameter with a default must be followed only by parameters that also have defaults. For example, `<T = int, U = string>` is valid; `<T = int, U>` is rejected.
2. Type defaults are written as ordinary type specifications (`T = int`). Const defaults use the existing `const int` form (`const int N = 16`).
3. Const defaults are evaluated by the bounded integer constant evaluator. Parenthesized integer expressions and supported earlier const parameters are allowed, for example `const int M = (N * 2)`.
4. A type default may refer to an earlier type parameter, for example `U = T`. Defaults are resolved in declaration order; forward references are not supported.
5. Existing const value predicates are checked after the effective value has been selected. A default that violates `positive`, `even` or another declared predicate is rejected just like an explicit value.
6. Named and positional argument rules remain in force. Positional arguments may precede named arguments, but may not follow the first named argument. Omitted parameters must have defaults.

## Resolution precedence

For generic free functions called without an explicit generic argument list:

1. Infer eligible type parameters and direct fixed-array const extents from call arguments using the existing bounded inference rules.
2. Use a declared default for each parameter that remains unresolved.
3. Reject any required parameter that is still unresolved.
4. Apply const constraints and ordinary type checks, then specialize.

For a call with an explicit positional/named generic argument list, the supplied arguments are mapped to declaration order and omitted parameters are filled from defaults. This path does not add mixed explicit-and-inferred omissions.

For generic types and methods, supplied arguments are mapped and defaults fill omitted slots. A type may be named without angle-bracket arguments only when every generic parameter has a default. Existing named argument normalization means equivalent positional and named calls resolve to the same concrete specialization key.

## Dependent defaults

Defaults are resolved from left to right and may refer to earlier parameters of the same kind:

```fac
public struct Dependent<T = int, U = T, const int N = 4, const int M = (N * 2)> {
    public array var T first[N]
    public array var U second[M]
}
```

For `Dependent` with all defaults, the effective bindings are `T = int`, `U = int`, `N = 4` and `M = 8`. Later parameters cannot be referenced from an earlier default.

## Diagnostics and regression coverage

The comptime regression `tests/comptime/generic_default_arguments.fac` covers type and const defaults on struct/class/function/method declarations, type defaults on interfaces and enums, bare type use when all parameters have defaults, partial positional and named arguments, defaults depending on earlier type/const parameters, inference taking precedence over defaults, and explicit method overrides.

Negative fixtures cover a required parameter with no argument/default, a non-trailing default, a forward reference, an unknown/wrong-kind named argument and a default that fails a const predicate. The parser regression also verifies that defaults survive AST cloning and that the ordering helper distinguishes supplied parameters from default-filled parameters.

## Limits

- Only the existing `const int` compile-time value category has defaults; this does not expand the separate bounded scalar free-function `consteval` subset or add arbitrary compile-time values.
- Generic inference remains bounded by `CONST_VALUE_INFERENCE_V220.md`. In particular, const inference is limited to a direct `[N]` fixed-array extent on generic free functions; this update does not add generic type/class inference or generic method inference.
- Defaults do not make non-trailing required parameters optional, and omitted required parameters remain errors.
- Explicit partial generic arguments are completed by defaults rather than inferred from ordinary call arguments.
- This feature does not add variadic generic parameters, implicit conversions between different generic argument kinds or general dependent-expression solving.

## Validation record

Validation for the source snapshot accompanying this document:

- Compiler build: GCC C++17 `-O0 -g0`; FAC V220 version check passed.
- Parser regression: 68 checks passed, including type- and const-default forward-reference rejection.
- Compile-time/const-generic suite: 39/39 passed, including the generic-default positive fixture and negative diagnostics.
- Generic specialization suite: 3/3 passed.
- Memory-safe profile: 25/25 passed.
- Negative suite: 134/134 passed.
- Legacy compiler/runtime case suite: 132/132 passed at FAC `-O0` and 132/132 at FAC `-O2`.
- Targeted HIR tests: `hir_model`, `generic_inference_hir` and `generic_free_function_hir` passed when compiled with GCC C++17 `-O0`.
- The general `tests/semantic/run.sh` wrapper exceeded the local command time budget; a full semantic-suite pass is not claimed.
- These are Linux host results, not cross-platform qualification.
