# FAC UI — primary canvas GUI + reusable styles

FAC's main UI direction is a **canvas-based GUI/component library**. The normal API is imperative and familiar to application code (`ui.button`, `ui.card`, `ui.tabs`, `ui.checkbox`). A CSS-inspired styling layer lets applications keep presentation reusable in `ui.Style` objects and a `ui.Styles` sheet.

This is deliberately not a new CSS parser or a web browser engine: style declarations are regular FAC code, checked by the FAC compiler and available without loading/parsing a second language.

## Quick start: component API

```fac
import graphic.fac
import theme.fac
import ui.fac

public function void main() {
    ptr graphic win = graphic.open(640, 400, "FAC App")
    obj theme.Theme t = new theme.Theme()
    var boolean enabled = true

    while (graphic.poll(win)) {
        ui.beginFrame(win)             # exactly once after polling
        if (graphic.key(win, "esc")) { break }
        graphic.clear(win, t.background)
        ui.card(win, 24, 24, 360, 220, t)
        ui.title(win, 44, 44, "SETTINGS", t)
        ui.mutedText(win, 44, 70, "Application component API", t)
        enabled = ui.toggle(win, 44, 112, 34, 19, enabled, t)
        if (ui.button(win, 44, 166, 130, 32, "SAVE", "primary", t)) {
            # Handle the action in application code.
        }
        graphic.present(win)
        graphic.delay(16)
    }
    graphic.free(win)
}
```


## Visual direction: modern desktop workspace

V109 shifts the built-in theme away from saturated dashboard styling. The palette uses neutral graphite surfaces in dark mode and soft gray/white surfaces in light mode. Blue is reserved for primary actions, selection and focus; separators are thin; corner radii are restrained; ordinary panels are flat and bordered. This is an original FAC workspace style informed by common macOS/VS Code desktop conventions, not a pixel copy of either application.

`Theme()` starts in dark mode. Call `theme.setLight()` for the light palette, or `theme.setAccent(r, g, b)` to replace the blue accent. The `Theme` fields keep their V108 names, so existing applications can continue using them. `ui.card()` and the default `ui.Styles.card` preset no longer add a shadow automatically. Set `Style.shadow = true` only when a particular surface needs elevation.

The new source-level workspace primitives are:

| API | Purpose |
|---|---|
| `ui.workspaceBar(canvas, x, y, w, h, appName, context, theme)` | Flat application/context header with a bottom separator |
| `ui.sidebarItem(canvas, x, y, w, h, label, active, theme)` | Quiet sidebar selection and hover state; returns true on press |
| `ui.toolbarButton(canvas, x, y, w, h, label, active, theme)` | Flat compact toolbar action; returns true on press |
| `ui.workspaceRow(canvas, x, y, w, h, title, detail, trailing, selected, theme)` | Two-line row with optional right-aligned metadata; returns true on press |

These functions follow the existing immediate-mode contract: call `ui.beginFrame()` once per frame after `graphic.poll()`, draw the component, and store a returned interaction value in application state. They draw into the same software canvas as the older controls; they do not create native title bars, OS menus, accessibility semantics or automatic layout constraints.

`examples/ui_showcase.fac` now renders a source workspace instead of a fake analytics dashboard. `examples/ui_styles.fac` demonstrates a restrained preferences surface and reusable style objects. Use these as starting points, then make the information architecture specific to the application instead of repeating the same sidebar/cards layout everywhere.

## Default system typography

V195 switches the reusable UI renderer (`render.text` and all `ui.*` text components) to a normal anti-aliased system sans font by default. On Windows this uses the native GDI font mapper with Segoe UI as the preferred family; on Linux/macOS it uses the optional Pango/Cairo/Fontconfig vector backend with the `Sans` family and system font fallback. Text measurement uses the same backend as drawing, so buttons, labels and workspace rows measure the glyphs they actually render.

No font file needs to be created or bundled for the default UI. The host still needs its system fonts; Linux/macOS also need the Pango/Cairo/Fontconfig runtime libraries for vector text. When the vector backend is unavailable, the renderer falls back to FAC's built-in bitmap font so the program remains usable. `graphic.systemTextAvailable()` reports whether the native/system renderer is available.

`graphic.text()` and the UI renderer both use normal system text by default. `graphic.bitmapText()` and `graphic.bitmapTextWidth()` explicitly retain the legacy 3×5 bitmap font for games and pixel-art use. `textScale` remains a multiplier: the system renderer maps it to a readable pixel size while preserving existing drawing signatures.

## CSS-inspired style objects

Style properties are normal public fields. Colors are packed RGB integers; dimensions are pixels; `fontScale` is the system-font size multiplier; `bitmapText` can be used where pixel glyphs are desired. A negative `background`, `color`, `borderColor`, or `borderRadius` means use the theme fallback.

```fac
obj theme.Theme t = new theme.Theme()
obj ui.Styles css = new ui.Styles(t)

css.card.background = graphic.rgb(24, 31, 46)
css.card.color = t.text
css.card.borderColor = t.border
css.card.borderWidth = 1
css.card.borderRadius = 14
css.card.padding = 18
css.card.shadow = true

css.primaryButton.background = t.accent
css.primaryButton.color = t.onAccent
css.primaryButton.hoverBackground = t.accentHover
css.primaryButton.pressedBackground = t.border
css.primaryButton.borderRadius = 8

ui.panel(win, 24, 24, 360, 220, css.card, t)
ui.label(win, 42, 44, "Styled heading", css.text, t)
if (ui.buttonStyle(win, 42, 100, 132, 34, "CONTINUE", css.primaryButton, t)) {
    # Handle click.
}
```

`ui.Styles` supplies reusable `page`, `card`, `text`, `mutedText`, `primaryButton`, and `secondaryButton` presets. Applications can modify the fields or create independent `new ui.Style()` objects. Style classes are ordinary FAC classes, so an app can keep its own design tokens, variants, and theme switching logic.

Supported style fields:

| Field | Meaning |
|---|---|
| `background` | Fill color; negative inherits from the theme |
| `color` | Text color; negative inherits from the theme |
| `borderColor`, `borderWidth` | Border color and thickness |
| `borderRadius` | Corner radius in pixels; negative uses theme radius |
| `padding` | Inset for styled button labels; `contentX/Y/Width/Height` calculate padded container bounds |
| `fontScale` | System text size multiplier; zero uses theme text scale |
| `hoverBackground`, `pressedBackground` | Interactive button states; negative disables override |
| `shadow` | Draw a restrained shadow for boxes/panels |

Styled primitives: `ui.panel`, `ui.label`, and `ui.buttonStyle`. Existing theme-based widgets remain available and are still the fastest way to get started.

## Layout helpers

`ui.Column` and `ui.Row` are small cursor-based layout helpers. Their `next(size)` method returns the next child's Y or X coordinate and advances by the supplied size plus the configured gap.

```fac
obj ui.Column content = new ui.Column(24, 80, 420, 12)
var int y = content.next(28)
ui.label(win, content.x, y, "Account", css.text, t)
y = content.next(34)
ui.buttonStyle(win, content.x, y, 140, 34, "PROFILE", css.secondaryButton, t)
```

They intentionally do not impose a retained DOM/widget tree. The application owns state and calls components each frame, which keeps the API straightforward for game tools and custom desktop apps.

`ui.Grid` provides index-based multi-column placement when children have a common height:

```fac
obj ui.Grid tiles = new ui.Grid(24, 80, 420, 3, 12, 10, 72)
var int i = tiles.next()
var int x = tiles.cellX(i)
var int y = tiles.cellY(i)
var int w = tiles.cellWidth()
ui.card(win, x, y, w, tiles.itemHeight, t)
```

The constructor clamps invalid layout dimensions to safe practical bounds. `next()` returns the current zero-based item index; `reset()` restarts it. `cellX(index)` and `cellY(index)` are also usable for random-access placement.

## Interactive selection controls

`ui.dropdown(canvas, x, y, w, h, labels, selected, id, theme)` returns the selected index. IDs must be unique and non-negative for dropdowns in the same UI. Clicking the closed field opens it; clicking an option selects it. While open, Up/Down moves the selection, Enter closes and accepts it, and Esc closes it. At most eight rows are visible; keyboard movement scrolls the visible range to keep the selected item in view. One dropdown is open at a time.

`ui.radioGroup(canvas, x, y, rowHeight, labels, selected, theme)` draws a vertical list and returns the selected index. Both controls leave the application's state model explicit: assign their return value back to the state variable each frame.

## Editable single-line text fields

`ui.textField(canvas, x, y, w, h, label, value, id, nextId, prevId, maxLength, theme)` returns the updated string; assign it back to the application's `dyn string` state each frame. IDs must be stable and unique within the view. `nextId` and `prevId` explicitly define Tab / Shift+Tab order; pass `-1` to leave the form when focus reaches an edge. `maxLength` counts supported grapheme clusters; `0` selects the 65,535-cluster safety cap. `ui.blurTextField(canvas)` releases focus and stops platform text input.

```fac
import graphic.fac
import theme.fac
import ui.fac

public function void main() {
    ptr graphic win = graphic.open(480, 180, "Profile")
    obj theme.Theme t = new theme.Theme()
    dyn string name = ""
    dyn string email = ""

    while (graphic.poll(win)) {
        ui.beginFrame(win)
        graphic.clear(win, t.background)
        name = ui.textField(win, 24, 20, 400, 30, "DISPLAY NAME", name, 1, 2, -1, 32, t)
        email = ui.textField(win, 24, 78, 400, 30, "EMAIL", email, 2, -1, 1, 128, t)
        if (ui.button(win, 24, 132, 110, 30, "DONE", "primary", t)) {
            ui.blurTextField(win)
        }
        graphic.present(win)
        graphic.delay(16)
    }
    graphic.free(win)
}
```

The focused field supports committed UTF-8 text events, mouse cursor placement/drag selection, Left/Right, Home/End, Shift+Arrow selection, Ctrl+A/C/X/V/Z/Y, Backspace/Delete, Enter/Esc to blur, Tab/Shift+Tab using the explicit IDs, and horizontal scrolling. Newline characters pasted into this single-line control are replaced with spaces. `graphic.poll(canvas)` clears the text snapshot and collects text events; `graphic.textInput(canvas)` returns the committed UTF-8 text for that poll frame. Call `graphic.startTextInput(canvas)` / `stopTextInput(canvas)` to control platform text collection directly. Clipboard access is `graphic.clipboardGet(canvas)` (empty string on unavailable/error) and `graphic.clipboardSet(canvas, text)` (boolean success).

On Linux/macOS the SDL2 backend consumes `SDL_TEXTINPUT`, so platform IME commits arrive as UTF-8 text. On Windows the Win32 backend accepts `WM_CHAR` / `WM_IME_CHAR` UTF-16 units and converts surrogate pairs. Clipboard uses SDL's clipboard API or Win32 Unicode clipboard. The per-poll text buffer is capped at 64 KiB. Clipboard access requires an active window and may be unavailable in headless/dummy environments.

`string.graphemeLength(s)` and `string.graphemeSlice(s, start, end)` provide grapheme-aware indexing for UI editing. This is a practical subset covering combining marks, Thai vowel/tone marks, variation selectors, emoji modifiers, ZWJ emoji sequences, and regional-indicator flag pairs; it is not a full Unicode UAX #29 implementation.

The source UI keeps one active text-field ID. `ui.focusTextField(canvas, id)` moves focus programmatically and starts platform text input; `ui.focusedTextField()` returns the active ID or `-1`. `ui.blurTextField(canvas)` clears focus and history. `ui.canUndoText()` / `ui.canRedoText()` report whether the current focus session has history; `ui.undoText(value)` / `ui.redoText(value)` return the restored string. Ctrl+Z / Ctrl+Y call the same history operations. History is bounded to 64 snapshots per direction and is cleared when focus moves to another field or is blurred. A new edit clears the redo branch. One changed frame becomes one undo step; this is frame/event batching, not word-aware coalescing. For toolbar buttons, call `ui.canUndoText()` / `ui.canRedoText()` and assign `ui.undoText(value)` / `ui.redoText(value)` back to the string belonging to `ui.focusedTextField()`; these helpers operate only on the currently focused text field's history. Editing remains single-line and does not support word-wise navigation, multiline selection, IME candidate-window customization, or a retained component/accessibility tree.

## Multiline text editor

`ui.textArea(canvas, x, y, w, h, label, value, id, nextId, prevId, maxLength, theme)` returns the updated string; assign it back to the caller's `dyn string` every frame. It uses the same editor focus ID and history APIs as `textField`, so IDs must be unique across both control types. `ui.focusTextField` / `focusedTextField` can also focus/query a TextArea; the legacy names are retained for source compatibility.

```fac
import graphic.fac
import theme.fac
import ui.fac

public function void main() {
    ptr graphic win = graphic.open(720, 520, "Notes")
    obj theme.Theme t = new theme.Theme()
    dyn string notes = "First line\nSecond line"

    while (graphic.poll(win)) {
        ui.beginFrame(win)
        graphic.clear(win, t.background)
        notes = ui.textArea(win, 24, 24, 660, 400, "NOTES", notes, 10, -1, -1, 12000, t)
        if (ui.button(win, 24, 446, 120, 34, "CLOSE", "secondary", t)) { break }
        graphic.present(win)
        graphic.delay(16)
    }
    graphic.free(win)
}
```

TextArea supports UTF-8 commit events, mouse selection, Shift+Arrow selection, Left/Right by supported grapheme, Home/End at the current line, Up/Down with a retained preferred column, Backspace/Delete (including joining adjacent lines), Enter to insert a newline, Ctrl+A/C/X/V/Z/Y, explicit Tab/Shift+Tab links and vertical scrolling. Ctrl+Enter or Esc leaves the editor; plain Enter inserts a line break. Pasted CRLF and CR are normalized to LF. The maximum is capped at 65,535 supported grapheme clusters. The same bounded history (64 snapshots per direction) is used by TextField and TextArea; one changed frame is one undo step. Horizontal scrolling follows the active cursor line; there is no per-line horizontal viewport state, syntax highlighting, word wrapping, soft tabs, IME candidate-window customization, or full Unicode UAX #29 support. The optional bitmap font still has limited non-ASCII glyph coverage and no Thai/complex-script shaping. The default system-font renderer uses Pango shaping on supported POSIX hosts and native GDI font rendering on Windows.

## Equal-share Flex layout

`ui.Flex` splits a fixed rectangle into equal main-axis cells. Direction `0` means horizontal row; direction `1` means vertical column. Remainder pixels are distributed one-by-one to the earliest cells, so the final cells exactly fill the usable main-axis space after gaps.

```fac
obj ui.Flex row = new ui.Flex(24, 80, 660, 44, 0, 12, 3)
var int i = row.next()
ui.button(win, row.itemX(i), row.itemY(i), row.itemWidth(i), row.itemHeight(i), "ONE", "primary", t)
i = row.next()
ui.button(win, row.itemX(i), row.itemY(i), row.itemWidth(i), row.itemHeight(i), "TWO", "secondary", t)
i = row.next()
ui.button(win, row.itemX(i), row.itemY(i), row.itemWidth(i), row.itemHeight(i), "THREE", "secondary", t)
```

Methods: `next()` returns the next zero-based item index, `reset()` restarts iteration, and `itemX/Y/Width/Height(index)` return cell geometry. Constructor parameters are `(x, y, width, height, direction, gap, itemCount)`. Dimensions, gap, count and coordinates are clamped to bounded ranges. Flex is an equal-share splitter, not a full Flexbox engine: it has no grow/shrink weights, wrapping, alignment, intrinsic measurement or nested component lifecycle.

## Motion and animated components (V114)

FAC UI now has a small, explicit motion layer. It follows the same immediate-mode model as the rest of the UI: create one state object per widget **outside** the frame loop, then pass that object to the animated widget on every visible frame. Do not construct state objects inside the loop or the animation will restart every frame.

```fac
import graphic.fac
import theme.fac
import ui.fac

public function void main() {
    ptr graphic win = graphic.open(640, 420, "FAC Motion")
    obj theme.Theme t = new theme.Theme()
    obj ui.ButtonMotion buildState = new ui.ButtonMotion()
    obj ui.ToggleMotion switchState = new ui.ToggleMotion()
    obj ui.TabsMotion tabsState = new ui.TabsMotion()
    list dyn string labels = {"GENERAL", "DISPLAY", "ABOUT"}
    var int selected = 0
    var boolean enabled = false

    while (graphic.poll(win)) {
        ui.beginFrame(win)   # updates input edges and monotonic frame delta
        graphic.clear(win, t.background)
        if (ui.animatedButton(win, 24, 24, 140, 34, "BUILD", "primary", buildState, t)) {
            # Start the build.
        }
        enabled = ui.animatedToggle(win, 200, 28, 44, 24, enabled, switchState, t)
        selected = ui.animatedTabs(win, 24, 88, 420, 36, labels, selected, tabsState, t)
        graphic.present(win)
        graphic.delay(16)
    }
    graphic.free(win)
}
```

Animated widgets:

| API | Motion |
|---|---|
| `ui.animatedButton(..., obj ui.ButtonMotion state, theme)` | Hover color interpolation and a short pressed-state response |
| `ui.animatedSidebarItem(..., obj ui.SidebarMotion state, theme)` | Hover/selection surface and growing selection marker |
| `ui.animatedToolbarButton(..., obj ui.ButtonMotion state, theme)` | Quiet toolbar hover/active surface |
| `ui.animatedToggle(..., obj ui.ToggleMotion state, theme)` | Thumb slides between on/off positions |
| `ui.animatedTabs(..., obj ui.TabsMotion state, theme)` | Underline glides between tab positions |
| `ui.animatedPanel(..., obj ui.PanelMotion state, theme)` | Small upward entrance; call `state.restart()` to replay |

`ui.beginFrame()` samples `time.mono()` and stores the elapsed seconds. `ui.frameDelta()` exposes that value to custom animation code. The delta is capped at 0.1 seconds so a paused/background window does not jump through an entire transition after it resumes. The first frame uses a 1/60 second fallback. Each animated widget advances its own state when that widget is drawn.

### Reduce Motion

The theme has a `reduceMotion` preference. Call `t.setReduceMotion(true)` to make all the built-in animated UI widgets snap to their target values instead of transitioning. The preference is read from the theme on each animated widget call, so toggling it at runtime takes effect without recreating widget state. It also applies to explicit motion states through their `setReduceMotion()` methods.

### Reusable motion primitives

`motion.fac` provides two general-purpose classes:

- `motion.Tween(initial)` interpolates one scalar value. `to(target, seconds, easingId)` retargets from the current interpolated value, so reversing a transition does not jump back to the original start. `update(dt)`, `value()`, `progress()`, `isAnimating()`, and `snap(value)` manage/read it. Easing IDs are `0` linear, `1` smoothstep, `2` ease-out quadratic, `3` ease-out cubic, and `4` ease-in-out cubic. Duration must be finite and 0–60 seconds; IDs must be 0–4. A single update is capped at 0.1 seconds.
- `motion.Spring(initial, stiffness, damping)` provides a damped spring for custom spatial motion. Call `setTarget(value)` and `update(dt)`, then read `position` or `settled()`. Integration is bounded to small substeps, and the class has the same Reduce Motion support.

These are scalar primitives, not a general animation timeline or keyframe editor. They do not schedule callbacks, interpolate arbitrary structs or colors automatically, or own the widget lifecycle. Use `color.lerp()` for packed RGB color interpolation.

The interaction style takes inspiration from restrained desktop interfaces: short ease-out responses, soft selection movement and subtle entrance motion. It is not a replica of macOS animation curves or native controls. The renderer remains FAC's canvas renderer: there is no window blur/vibrancy, OS-level sheet animation, automatic accessibility tree or TTF/OTF text shaping yet.

## Built-in component API

The existing library includes `beginFrame`, `button`, `badge`, `progress`, `slider`, `checkbox`, `toggle`, `dropdown`, `radioGroup`, `card`, `divider`, `verticalDivider`, `title`, `text`, `mutedText`, `centeredText`, `statCard`, `sectionTitle`, `inputField`, `navItem`, `tabs`, `alert`, and `avatar`.

## Event contract

- Call `graphic.poll(canvas)` before `ui.beginFrame(canvas)`.
- Call `ui.beginFrame(canvas)` exactly once each frame; it snapshots mouse position and press/release edges.
- `button`, `navItem`, `tabs`, and `buttonStyle` react to the press edge.
- `checkbox`, `toggle`, `tabs`, and `slider` return updated state; assign the result back to application state.
- `dropdown` samples Up/Down/Enter/Esc key edges in `beginFrame`; this is local dropdown navigation. `radioGroup` is mouse-driven.
- TextField and TextArea share one active text-editor ID with explicit Tab/Shift+Tab links and programmatic focus APIs. Other widget classes do not participate in a general focus traversal system.
- `inputField` is visual-only; use `textField` for single-line editing and `textArea` for multiline editing. There is no retained component tree, automatic layout/focus discovery, accessibility tree or native OS widget backend.

## Weighted FlexBox layout (V115)

`ui.Flex` remains the equal-share splitter for simple grids/toolbar rows. Use `ui.FlexBox` when children need preferred sizes, growth/shrink weights, min/max constraints, padding, or cross-axis alignment:

```fac
obj ui.FlexBox row = new ui.FlexBox(20, 80, 700, 48, 0, 12)
row.setPadding(16, 4, 16, 4)
row.add(120, 0, 1, 100, 180, 0, 0)   # fixed-ish navigation width
row.add(240, 1, 1, 180, 1000, 0, 0) # flexible content
row.add(96, 0, 0, 96, 96, 32, 1)    # fixed action, vertically centered
row.resolve()

var int i = 0
while (i < row.count()) {
    # Query itemX/Y/Width/Height(i), then draw the corresponding component.
    i++
}
```

Constructor: `(x, y, width, height, direction, gap)` where direction `0` is horizontal and `1` is vertical. `setBounds(x, y, width, height)` updates the outer rectangle; `setGap(pixels)` changes spacing; `setPadding(left, top, right, bottom)` sets inner insets; `clearItems()` resets registered children. `add(basis, grow, shrink, minSize, maxSize, crossSize, crossAlign)` returns the item index (`-1` after the 4096-item cap). `basis`, `minSize`, `maxSize` and `crossSize` are pixels; `grow` and `shrink` are relative nonnegative integer weights. A `crossSize` of zero stretches to the available cross-axis size; `crossAlign` is `0=start`, `1=center`, or `2=end` for a fixed cross size.

Call `resolve()` after changing bounds, padding, or children. It calculates the main-axis sizes once; then read `itemX/Y/Width/Height(index)`. Growth/shrink uses proportional allocation with integer pixel rounding. Min/max constraints take precedence, so unused space or overflow can remain when the constraints make the requested total impossible. Width/height and child count are bounded, and allocation is reserved before parallel item records are appended. This is a single-level layout calculator, not a retained component tree or full CSS Flexbox implementation; nested layouts are created by composing additional FlexBox objects.

## Text measurement and paragraph wrapping (V116)

`typography.fac` provides `TextLayout`, `lineCount`, and `measureHeight`. The layout wraps at word boundaries, preserves explicit newlines, and splits long unbroken tokens at supported grapheme boundaries. Use `reflow(text, width, scale, lineGap)` for the default system font or `reflowWithFont(text, width, face, lineGap)` for a caller-owned bitmap/vector font. The font-aware path uses actual per-line font measurements for wrapping and the same font handle for drawing.

`TextLayout` exposes `count()`, `lineAt(index)`, `lineWidth(index)`, `lineHeight()`, `contentWidth`, and `contentHeight`. See [Typography](TYPOGRAPHY.md) for optional Pango/Cairo TTF/OTF loading and its fallback behavior.

## Rendering / font scope

- UI widgets still draw to the existing `graphic` software canvas. They are not native Win32/GTK/Cocoa controls.
- Linux/macOS builds can dynamically use Pango/Cairo/Fontconfig for vector fonts, anti-aliased glyph rendering and shaping/fallback (including Thai when suitable fonts are installed). Windows uses GDI with Segoe UI preferred. The bitmap font remains the fallback when a native backend is unavailable.
- The GPU API is not yet a hardware-accelerated GUI renderer. Native controls, vibrancy/blur, a retained component tree and accessibility integration remain separate work.

## Example and tests

- `examples/ui_interactive.fac`: component API and interaction example.
- `examples/ui_styles.fac`: CSS-inspired style objects, shared styles, and layout cursor.
- `examples/ui_showcase.fac`: deterministic static FAC Studio workspace screen (`fac_ui_showcase.png`).

### FAC Studio screen foundation (V203)

The showcase is a screen-only scaffold, not an application/backend implementation. It uses the existing `Theme`, `Styles`, `FlexBox`, and workspace components to establish a repeatable page shell:

- application bar and navigation rail;
- flexible page region with a project list and selected-project inspector;
- shared style tokens for surfaces and buttons;
- clear boundaries between sample presentation data and future services.

The project names and descriptions are illustrative screen data. The preview does not create projects, persist settings, invoke the compiler, or read repository state at runtime. Extend it by replacing the sample data and attaching real actions only after the screen structure and component responsibilities are agreed. Compiler and Runtime sources are unchanged by this example.
- `tests/cases/t59_ui_kit.fac`: original widgets/theme rendering coverage.
- `tests/cases/t60_ui_styles.fac`: style objects, layout cursor, and styled components.
- `tests/gui/ui_interaction.fac`: injected mouse interaction checks.
- `tests/gui/ui_controls.fac`: injected dropdown mouse/keyboard, radio selection and grid geometry checks.
- `tests/gui/ui_text_field.fac`: injected UTF-8 text events, cursor insertion, select-all replacement, Tab focus, Thai grapheme deletion and emoji handling.
- `tests/gui/ui_text_undo.fac`: programmatic focus, Ctrl+Z/Ctrl+Y, undo/redo branch invalidation and focus cleanup.
- `tests/gui/ui_text_area.fac`: multiline insertion, vertical navigation, replace-all, undo, line joining and Flex geometry.

## Graphics integration

UI and Graphics are separate **API responsibilities**, but the current V16 implementation intentionally shares the same `graphic` canvas and software renderer:

- `graphic` owns the window/canvas, primitive drawing, images/textures, input polling, and presentation.
- `three` draws a 3D scene into that same canvas and depth buffer.
- `ui` reads mouse state from the same canvas and draws widgets after the scene, so the widgets appear as an overlay.
- `ui.image(canvas, source, x, y, w, h)` scales an existing Graphics image into a UI layout.
- `ui.viewportFrame(...)` decorates a region intended to contain a Graphics scene.

Typical frame order:

```fac
ui.beginFrame(win)       # snapshot shared input once
 graphic.clear(win, bg)
 three.begin(win, camera)
 three.cube(win, camera, 0.0, 0.0, 5.0, 2.0, color)
 ui.card(win, 20, 20, 220, 120, theme)
 ui.button(win, 36, 60, 120, 32, "PAUSE", "primary", theme)
 graphic.present(win)
```

The UI and Graphics APIs can be selected independently at the source level, but UI currently imports and draws through `graphic`; this is **not yet a renderer-backend-neutral abstraction**. Both use the same software canvas. `viewportFrame` is an overlay frame only: it does not provide a clipped render target, independent viewport, GPU acceleration, or 3D scene embedding into a sub-rectangle. A future shared renderer interface can replace the current direct `graphic` calls without changing the high-level widget API.

See `examples/ui_graphics_integration.fac` for a complete 3D scene with UI overlay and shared mouse/input frame.
