# FAC V220 — Immutable Typed Expression AST

## Status

Implemented as a compiler-internal HIR projection in V220. This is the first typed-AST construction layer, not a user-facing FAC metaprogramming API, declaration generator, macro system, or general reflection facility.

## 1. Pipeline

After declaration/type resolution, lexical-scope analysis, overload resolution, and final expression type refinement, `fac_hir::TypedAstBuilder` builds an immutable typed-expression view from the semantic model.

The source `Node` AST remains the parser and code-generation representation. The new tree is stored in `SemanticModel::typedAst` and is a read-only, source-mapped semantic artifact. Code generation continues to use the existing source AST in this milestone.

## 2. Node contract

Each `TypedAstNode` carries:

- a deterministic `TypedAstId`;
- a `TypedAstKind`;
- an immutable origin marker (`Source` or `Generated`);
- a resolved HIR `TypeId`;
- the originating source `ExprId` for `Source` nodes (the invalid sentinel for `Generated` nodes);
- file, module and line information;
- the operator/name/literal spelling;
- immutable child references (`shared_ptr<const TypedAstNode>`);
- the source expression's side-effect flag.
- a resolved `SymbolId` for source/generated calls when the call has a concrete declaration target.

The node's data members are `const`. Children are materialized before parents, so the stored node sequence is deterministic and child edges point only to earlier node IDs. `TypedAstModel::validate` checks type IDs, source-expression uniqueness, source mappings, child ownership/order, node arity and root references.

## 3. Supported node kinds

The first projection currently admits:

- integer, floating-point, character, string, boolean and null literals;
- identifiers with a resolved local binding;
- unary, postfix and binary operators with known operand/result types;
- calls whose overload/local-call resolution is complete, plus calls already typed by a fixed builtin contract;
- object construction with a resolved named/heap type;
- tuple expressions whose component types are all known.

The builder preserves resolved types and source locations but does not re-run or replace the language's authoritative semantic/type checker.

## 4. Conservative omission rules

An expression is not promoted when its type is unresolved/dependent, a required child has no typed node, a call has no completed resolution, or its syntax kind is not covered by the current typed-AST contract. Examples not yet represented include unresolved/member/index/slice/deref forms, assignment/control-flow expression forms, match expressions, lambdas with typed statement bodies, and declaration nodes.

Omission is intentional: the builder does not invent types or synthesize missing semantic facts. The original expression HIR and source AST remain available.

## 5. What this does not provide

This milestone does **not** expose AST construction from FAC source code, `consteval` AST values, AST mutation, source rewriting, macro expansion, plugin hooks, or arbitrary compile-time execution. A separate compiler-internal C++ `TypedDeclarationBuilder` supports a bounded set of generated struct/free-function HIR declarations, and `TypedFunctionBodyBuilder` supports scalar bodies with mutable locals, exact-TypeId assignments and nested `if/else` for generated free functions. The generated declarations/bodies can be projected into Codegen under the limits documented in [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md) and [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md); neither builder is exposed as a source-level API. See [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md). Separate V220 compiler intrinsics now provide bounded public-field metadata queries for resolved struct/class records; these are documented in [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md) and do not expose or construct AST nodes. `typeOf<T>()`, `sizeof<T>()` and `alignof<T>()` remain the existing bounded type/layout constant queries; they are not structural reflection by themselves.

Broader source-level generation still requires a FAC-level typed AST/declaration value model, imported-type/access contracts, loops and multiple-return CFG support in generated bodies, classes/methods/generics, source maps, recursion/resource budgets and a full post-generation semantic contract. The current generated-body subset supports only nested `if/else` over predeclared scalar locals with one terminal return.

## 6. Regression coverage

`tests/semantic/typed_expr_hir.cpp` checks immutable source-node fields, literal and binary projection, typed child edges, tuple/call construction, source mapping, summaries, and omission of an unresolved tuple expression. It also exercises the generated-node factory; see [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md). The existing semantic test runner executes this fixture as part of `tests/semantic/run.sh`.

Build and focused check:

```sh
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O0 -g0' -j1
g++ -std=c++17 -O0 -g0 -I. tests/semantic/typed_expr_hir.cpp -o /tmp/fac_typed_expr_hir
/tmp/fac_typed_expr_hir
```
