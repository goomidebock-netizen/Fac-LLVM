# FAC Language Core — V189

## Constant conditional-expression fixed-array borrow projections

V189 extends the bounded strict local-borrow fixed-array projection evaluator to resolve integer indexes selected by FAC's `ifv / eiv / elv` conditional expression.

### Supported condition forms

- `true` and `false` boolean literals.
- Supported pure integer constant expressions as truth values (`0` is false; non-zero is true).
- Logical NOT: `!`.
- Logical AND/OR: `&&` and `||`, preserving FAC short-circuit evaluation.
- Integer comparisons: `==`, `!=`, `<`, `<=`, `>` and `>=`, when both operands are supported pure integer constants. Comparisons use the evaluator's promoted common integer width and signedness.

The evaluator selects the first arm whose condition is provably true. If each tested condition is provably false, it selects `elv`.

### Conservative result typing

Every value arm, including the `elv` arm, must resolve to a supported pure integer constant. All result arms must have the same integer bit width and signedness. This intentionally avoids guessing the language's branch type-join result in the borrow checker. If any condition is unknown, an arm is non-constant, or result representations differ, the index remains unresolved and is treated as a may-alias projection.

Calls, side effects, mutable variables, unsupported comparisons and arbitrary compile-time execution are not evaluated. The pre-existing bounded expression-visit budget still applies.

### Examples

```fac
array var int values[8] = {0, 1, 2, 3, 4, 5, 6, 7}
const int threshold = 2
ref var int first = values[ifv(1 < threshold){1}eiv(false){2}elv{3}]
ref var int second = values[ifv(2 < 1){2}eiv((2 + 2) == 4){4}elv{3}]
ref var int third = values[ifv((false || true) && !false){5}elv{6}]
```

The resolved projections are `values[1]`, `values[4]` and `values[5]`; they are disjoint. Writes through these aliases still update the original array storage.

### Regression coverage

- `good_array_ifv_constant_indices.fac` checks constant first-arm, `eiv`, logical predicate, unsigned comparison, short-circuit suppression of an unreachable side-effecting call and `elv` selection, then verifies runtime aliasing.
- `bad_array_ifv_constant_same_index.fac` checks that two different conditional expressions resolving to the same index conflict.
- `bad_array_ifv_dynamic_condition.fac` checks that a mutable condition remains unresolved and conservatively conflicts with another borrow.

### Boundaries

V189 does not implement general constant evaluation, compile-time function execution, dynamic range analysis, bounds checking, reference return/store lifetimes, global alias analysis, general region/outlives inference or a complete/Rust-equivalent borrow checker. It changes only the precision of strict local-borrow fixed-array projections and does not alter array layout, Runtime ABI or public API signatures.
