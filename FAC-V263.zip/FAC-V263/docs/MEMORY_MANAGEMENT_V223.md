# FAC Memory Management Direction — V223

V223 refines field-sensitive borrowing through strong managed object handles. The release fixes a type-normalization gap in the local borrow checker that caused metadata-resolved fields of `obj T` to be treated as unknown whole-object paths.

## 1. Nested value-field projections through a strong object handle

The local borrow checker now normalizes the `obj ` type prefix when resolving field metadata. Once the root is a tracked local strong `obj` handle, it can follow nested **by-value** aggregate fields using metadata-known projections. For example, with `obj Actor actor` and a value field `Stats stats`, the paths `actor.stats.health` and `actor.stats.mana` can be tracked separately.

These paths reuse the existing segment-aware overlap rules. A mutable borrow of `actor.stats.health` therefore does not block an access to the disjoint `actor.stats.mana` field, while a second borrow of `actor.stats.health` or a direct owner write to that same field is rejected while the first loan remains live.

## 2. Managed-object alias boundaries remain fail-closed

A nested `obj Child` field is a separate shareable heap identity. The checker must not treat `parent.child.value` as an ordinary projection rooted only at `parent`, because another strong handle may alias the same `Child`. V223 therefore rejects a local borrow that crosses a nested managed-object reference boundary. Borrowing through a `weak obj` handle is also rejected: a weak handle alone does not keep its referent alive.

Borrowing a direct field stored in the tracked root object remains supported, as does following nested by-value `struct` fields below that root. This is not a general heap graph, cross-object alias analysis, reference-valued aggregate storage, or lifetime-transfer implementation.

## 3. Memory-management policy

Ownership and Borrow remain the primary static mechanism. ARC continues to serve intentional shared ownership, and the cycle collector remains a runtime recovery mechanism for unreachable managed cycles. The proposed 75–80% Ownership/Borrow with limited ARC and minimal GC is a design goal, not a measured ratio.

## 4. Compatibility

No FAC syntax, public API, Runtime implementation, C ABI, Runtime ABI or Standard Library implementation changed. The change is compiler-side alias-path analysis plus regression tests. The `--memory-safe` subset still excludes raw pointers, manual heap operations, FFI, unsafe code, native handles, and borrowed-reference storage in globals/aggregate fields.

## 5. Validation

On the current Linux host, the compiler and Runtime were rebuilt with GCC C++17 at `-O0`. `tests/memory_safe/run.sh` passed 39/39 checks, including disjoint nested value-field borrows, same-field conflicts, nested-object-boundary rejection, and runtime aliasing. `tests/lifetimes/run.sh` passed all configured cases. `tests/ownership/run.sh` passed the ownership, const-method, local-borrow, noescape, field-sensitive, effect-contract and function-effect groups. The complete legacy `tests/run.sh` suite and cross-platform/sanitizer qualification were not completed for this release; no claim is made that all compiler or Runtime paths are proven memory-safe.
