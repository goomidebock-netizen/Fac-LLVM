# FAC V257 — focused source-code audit

## Finding carried forward from V256

**Severity: High — strict-ownership memory-safety analysis correctness**

The V256 guard identified untracked enum payload pointer returns only when the
function's parsed return TypeSpec was explicitly `ptr`. A function declared
with `auto` retains `ts.base == "auto"` at the local ownership-check stage.
Consequently, the explicit-pointer guard did not run even when the returned
`match` arm directly selected an enum payload declared as `ptr int`.

A minimal reproduction using `enum MaybePointer { Empty, Value(ptr int) }`
and `function auto choosePayload(...) { return match (...) { ... } }` was
accepted by the V256 compiler under `--strict-ownership`. This means the
checker accepted a pointer return for which enum payload provenance had not
been established.

## V257 change

- Retain enum variant payload type keys in `FacBorrowChecker` during program
  collection, including generic payload parameters and ambiguous duplicate enum
  names (which are treated conservatively).
- Add a value-sensitive check for direct pointer-payload results in `match`
  and `ifv / eiv / elv` expressions returned from `auto` functions.
- Keep conditions, comparisons, match scrutinees, patterns and guards outside
  the returned-value analysis.
- Preserve the existing explicit-pointer-return guard from V256.
- Add five lifetime regressions covering direct rejection, nested rejection,
  generic-enum rejection, scalar acceptance and pointer-condition acceptance.

This remains a bounded fail-closed check. It does not implement provenance
through enum storage, generic `ref T` return inference, general heap escape
analysis or a complete borrow checker.

## Validation

Completed on Linux x86-64 with Clang 17 / C++17:

- Compiler and Runtime build: passed; `facc --version` reports V257 for Core,
  Lib, API, Lang, Runtime and Stdlib.
- Lifetime regression script: 128 PASS results, including all five V257 cases.
- Ownership suites: 261 checks passed (12 base, 8 const-method, 167 local-borrow,
  17 noescape, 25 field-sensitive, 19 effect-contract and 13 function-effect).
- Secure Profile: 6/6; `--memory-safe`: 39/39.
- Move: 20/20; partial move: 28/28; compile-time/const-generic: 57/57;
  generic specialization: 3/3.
- Tools: 91/91; Lexer: 18/18; Parser: 68 plus AST model 1/1.
- Codegen constant-fold and recursion-guard checks passed.
- Runtime regression script completed successfully, including concurrency,
  allocation-failure, cycle-collector, task, numeric, SQLite and networking
  cases.
- API manifest and API contract checks passed: 663 built-ins, 1,014 source
  declarations, 950 public source functions with complete contract annotations.
  API audit reported 5 findings, all in the existing baseline; compatibility
  against V128 reported 0 breaking changes and 132 warnings.
- Standards check passed for 5 OS families and 6 architecture families;
  formatter and version checks passed.

The Semantic suite remains uncompleted: both Clang 17 and GCC 14 runs exceeded
 the command time limit during sequential compilation of a generic HIR
 regression, although the corresponding individual translation units compile
 successfully in isolation. This is recorded as an unresolved semantic-suite
 runner/environment issue; no full Semantic-suite success is claimed.

ASan/UBSan/TSan, full CMake/CTest, Windows/macOS cross-platform and production
qualification are not claimed.
