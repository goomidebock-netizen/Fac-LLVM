# FAC V256 — focused source-code audit

## Scope

This audit focused on the V235 strict-ownership pointer-return path: `collectPointerReturnExpressionSource`, `collectPointerOrigins`, `checkReturnEscape`, the relevant AST traversal helpers, lifetime regressions, release metadata and generated API documentation. It is a focused audit of the affected ownership/lifetime path, not a line-by-line security audit of every Runtime, standard-library or platform backend source file.

## Finding: nested match payload could bypass fail-closed return check

**Severity: High — memory-safety analysis correctness**

The V235 checker explicitly rejected a pointer return that directly used an enum match payload binding because enum payload pointer provenance is not tracked. However, that guard ran only when the return expression's top-level AST node was `MatchExpr`. A payload pointer returned from a `match` nested in an `ifv / eiv / elv` result arm avoided that guard. The branch binding was deliberately removed from the provenance context, so the return-value analysis could observe no origin and fail to validate the actual payload pointer against the declared return lifetime.

The V235 compiler accepted the nested form during reproduction. V256 changes the guard to search result-producing nested expressions before collecting pointer origins. It rejects an untracked payload binding regardless of whether its `match` is the top-level return expression or nested in a conditional result arm.

The traversal is intentionally value-sensitive: it ignores `ifv` conditions and match scrutinees, patterns and guards, because these choose a result rather than provide the returned pointer. It also does not cross lambda/function boundaries, whose returns belong to separate functions.

## Change made

- Added `FacBorrowChecker::findUntrackedMatchPayloadBinding` to inspect nested result expressions.
- Updated `checkReturnEscape` to use the recursive check for pointer-bearing return types.
- Added `v256_nested_match_payload_pointer_return_rejected.fac` to prove the nested payload case is rejected.
- Added `v256_match_condition_not_returned_pointer.fac` to prove a match used only as an `ifv` condition remains accepted.
- Added both cases to `tests/lifetimes/run.sh`.

This is a fail-closed fix. It does **not** implement pointer provenance through enum payload storage. Such returns remain unsupported until that analysis can be modeled explicitly.

## Validation

The following completed successfully on Linux x86-64:

- `make -j2 all` with Clang 17 / C++17 / `-O0 -g0` for Compiler and Runtime.
- Lifetime tests: 123 checks passed.
- Ownership tests: 261 checks passed (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect).
- Secure profile: 6/6; `--memory-safe`: 39/39.
- Move: 20/20; partial move: 28/28; compile-time/const-generic: 57/57; generic specialization: 3/3.
- Lexer: 18/18; parser: 68 checks plus AST model 1/1; Codegen constant-fold and recursion-guard checks passed.
- `make api-check`: passed; 663 built-in entries and 1,014 source declarations; 950 public source functions satisfy documentation annotation checks; 0 compatibility breakings and 132 warnings against V128; 5 API findings, all in the existing baseline.
- `make fmt-check` and version checks passed. `facc --version` reports V256 for Core, Lib, API, Lang, Runtime and Stdlib.

## Not claimed / remaining work

- The semantic suite reached and passed 17 ancestry checks but did not complete within the command time limit.
- `tests/tools/test_tools.py` did not complete within the command time limit.
- Full CMake/CTest, ASan/UBSan/TSan qualification, Windows/macOS cross-platform qualification and production qualification were not completed for V256.
- General enum payload provenance, general heap escape analysis and a complete borrow checker remain unsupported.
- A project-wide LICENSE decision is still needed; no license was invented or added in this release.
