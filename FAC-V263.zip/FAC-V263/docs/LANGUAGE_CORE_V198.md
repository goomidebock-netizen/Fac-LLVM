# FAC Language Core V198 — unified outlives constraints for pointer storage

## Goal

V197 introduced a lexical region tree for control-flow branches. V198 extends the lifetime-constraint pass so pointer provenance stores are represented as explicit outlives constraints and solved together with local `ref` borrow constraints at function end.

## Behavior

- Initializing a local pointer from `addr(local)` records `owner-region : destination-region`.
- Assigning one tracked pointer to another propagates the source pointer's may-origin facts and records the same outlives relationship for every possible origin.
- A destination in the same or a descendant lexical region is valid when every source origin outlives it.
- Storing an inner-region origin into an outer pointer, aggregate/container storage, a global/unmodeled destination, or a return value is rejected by the lifetime-constraint solver.
- Returning a `noescape` parameter keeps its dedicated noescape-contract diagnostic.
- Existing local-ref parent/child constraints use the same solver and retain their established diagnostics.

This unifies the enforcement point; it does not infer named lifetime variables or change FAC's source syntax. The analysis remains intraprocedural and conservative. Pointer-valued aggregate fields, arbitrary aliasing, references in return types, raw-pointer proofs, and interprocedural lifetime inference remain unsupported.

## Regression coverage

- `good_pointer_nested_chain.fac`: an outer owner is referenced through two nested local pointer variables and passed to a `noescape` callee while the owner remains alive.
- `bad_pointer_chain_escape.fac`: a pointer to inner-scope storage is copied through a second pointer and assigned to an outer pointer; the solver must reject the escaping origin.
- Existing same-region, outer-owner, branch/match escape, return, aggregate, global and closure-capture tests remain in the local-borrow suite.

## Validation boundary

A feature is not a general lifetime solver merely because constraints are collected. V198 checks concrete lexical region IDs already assigned by the current scope analysis. No named lifetime parameters, region inference across function signatures, or cross-function lifetime constraints are introduced.
