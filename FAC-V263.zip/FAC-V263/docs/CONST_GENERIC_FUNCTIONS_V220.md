# FAC V220 — Const Generic Functions and Methods

## Status

V220 extends the bounded const-generic implementation from generic `struct` / `class` types to generic free functions and methods. This supports compile-time integer values as specialization inputs. It is not a general `consteval` facility or arbitrary compile-time execution engine.

## Declaration syntax

A const parameter is written `const int Name` in the ordered generic parameter list. It may appear alone or alongside type parameters:

```fac
public function<const int N> int capacity() {
    return N
}

public function<T, const int N> T keepSized(T value) {
    if (N > 10) {
        return value
    }
    return value
}

public class BufferTools {
    public function<const int N> int methodCapacity() {
        return N
    }
}
```

## Call syntax and specialization

A const argument is an integer constant expression evaluated by the existing bounded evaluator. Parentheses make a value expression explicit in a generic argument list:

```fac
public const int BASE_CAPACITY = 5

public function void main() {
    var int a = capacity<(3 * 4)>()
    var int b = keepSized<int, (BASE_CAPACITY + 7)>(42)

    obj BufferTools tools = new BufferTools()
    var int c = tools.methodCapacity<(2 * 5)>()
}
```

Generic methods and generic struct/class instantiations that declare const parameters do not infer omitted arguments, but may omit parameters covered by declared generic defaults. Generic free functions can omit the entire generic argument list only when each const parameter can be inferred from a fixed-size array parameter whose extent is written directly as `[N]`; ordinary type parameters can be inferred from the same argument's element type. For example, `getCapacity(data)` may infer `N` from `array var int data[8]`. This rule is limited to fixed-size array arguments and does not infer from runtime lengths, integer arguments or algebraic patterns such as `[N * 2]`. When inference is not available, callers can provide arguments explicitly or rely on declared defaults for omitted parameters, for example `keepSized<int, (2 * 8)>(42)` or `keepSized<N = (2 * 8), T = int>(42)`. Type-only generic free functions continue to support their existing inference path and may also be explicitly specialized, such as `identity<int>(42)`.

The evaluated signed 64-bit integer is part of the specialization key. Different values produce different specializations; calls with the same type/value argument sequence reuse the same specialization. Const values are substituted into the specialized function or method body before ordinary type normalization and code generation.

## Dependent types and arrays

Const parameters can be used in local fixed-array dimensions and in dependent type arguments. For example:

```fac
public struct FixedBuffer<T, const int N> {
    public array var T values[N]
}

public function<T, const int N> int bufferCapacity(
    struct FixedBuffer<T, (N)> buffer
) {
    array var int scratch[N]
    return N
}
```

The const argument is substituted before the normal type/layout pass. Resulting array dimensions must be positive. Existing array and record layout checks continue to enforce overflow and maximum-layout limits.

## Constant-expression boundary

Accepted arguments must be evaluable by the bounded integer constant evaluator. In addition to its literal/operators/module-constant subset, V220 can call explicitly marked scalar free functions that satisfy the separate restricted `consteval` contract in [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md). Ordinary runtime function calls remain rejected, as do arithmetic overflow, division by zero and invalid shifts. Const generic evaluation does not execute arbitrary user functions.

The value parameter is currently only `const int`. Built-in value predicates are supported as described in [`CONST_GENERIC_CONSTRAINTS_V220.md`](CONST_GENERIC_CONSTRAINTS_V220.md); type/interface constraints on const parameters are not supported. Generic arguments may be positional, named, or positional followed by named. The bounded fixed-array inference rule for generic free functions is documented in [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md); generic methods and generic struct/class instantiations do not infer arguments but may use declared defaults, and runtime arguments/lengths are not inference evidence. Enums and interfaces cannot declare their own const parameters. Generic virtual/override dispatch and generic interface methods remain outside this feature.

## Compiler implementation notes

- The AST stores generic const expressions as a deferred expression node, distinct from ordinary type arguments and already-evaluated integer values.
- Parser handling recognizes value expressions in generic argument lists; parentheses disambiguate expressions from type syntax.
- Codegen evaluates each const argument using the existing constant evaluator, validates type/value argument kinds, includes the evaluated integer in the specialization key, substitutes const identifiers throughout the cloned declaration, and re-runs generic type normalization after substitution.
- HIR records const literal values and unevaluated const-expression descriptors separately. It records explicit argument types/values and checks const-versus-type parameter positions; Codegen remains authoritative for evaluation and final diagnostics.

## Regression coverage

Run:

```sh
sh tests/comptime/run.sh
sh tests/generic/run.sh
```

The const-generic regression set covers free functions, methods, mixed type/value parameters, arithmetic and module-constant expressions, local arrays, dependent generic types, invalid argument kinds, missing arguments, runtime-only expressions and overflow. HIR coverage also verifies that const-expression arguments remain represented as value expressions in `TypeDescriptor` and that ordinary structural type canonicalization is preserved.
