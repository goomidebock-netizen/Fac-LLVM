# FAC V220 — Generated Declaration Codegen Integration

## 1. Scope

V220 adds a bounded bridge from compiler-internal `fac_hir::TypedDeclarationBuilder` output to the existing LLVM Codegen pipeline. `Gen::generate` accepts an optional `const fac_hir::SemanticModel *`, validates the model, and projects eligible `DeclarationOrigin::Generated` records into short-lived synthetic `Program` objects. These temporary Programs are owned by the Codegen call; parser-owned source `Program` objects and their AST nodes are not modified.

The bridge reuses the existing record registration/layout/helper path and normal function registration/call path. Generated functions may remain external prototypes, or may carry a bounded scalar body created by the internal `TypedFunctionBodyBuilder`, including mutable locals, exact-TypeId assignments and nested `if/else` regions. Neither builder is a FAC language feature. The bridge does not run a second full HIR analysis pass. Call sites are resolved by the existing Codegen module/name/overload lookup after the generated function has been registered. See [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md) for the body contract.

## 2. Supported generated declarations

### Generated structs

- Non-generic `struct` declarations in a module that has exactly one source `Program` in the Codegen input.
- Ordinary fields whose resolved HIR TypeIds can be represented by the existing backend TypeSpec/type resolver. The integration regression covers scalar `int`/`double` fields and a field whose type is another generated struct in the same module.
- Public and private field metadata. Private fields still participate in physical layout; visibility is not a memory-layout filter.
- The existing Codegen record-layout and generated helper paths emit the LLVM record type and helpers (including the drop helper where applicable).

Generated struct fields are rejected when they are static, protected, fixed-size arrays (the HIR TypeId alone does not retain the source dimension expression), or otherwise outside the existing backend type contract. Class, interface, enum, generic, nested declaration, inheritance and generated method support are not included.

### Generated free functions

- Non-generic free-function declarations may be emitted as external prototypes when no generated body is registered. Each external function receives a deterministic `facgen_<module>_<name>_<signature-hash>` C symbol derived from its module, name, return TypeId descriptor and parameter signature. `Gen::generatedFunctionSymbols` maps the generated HIR `SymbolId` to its emitted LLVM symbol. The external implementation must be supplied by a linked native object/library using the expected C ABI.
- A generated function may instead receive a body through `fac_hir::TypedFunctionBodyBuilder`. Eligible bodies are projected to ordinary backend AST nodes and emitted as internal module-qualified LLVM function definitions through the normal Codegen path. They do not use the external `facgen_...` C ABI symbol. Calls to resolved, non-generic same-module functions are supported when exact scalar argument and return TypeIds match.
- Generated free functions cannot be named `main` and cannot use protected visibility. The body builder accepts plain scalar value parameters, scalar immutable/mutable locals, exact-TypeId assignments to mutable locals, bool-conditioned nested `if/else` regions, supported typed literals/unary/binary expressions, resolved same-module calls and one terminal return. The exact scalar set and exclusions are documented in [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md).
- Body-less external prototypes continue to follow the existing external-function backend contract. Ref, immutable-reference, variadic, `noescape`, `readonly` and default-argument parameters are rejected; unsupported external ABI forms are rejected by Codegen.

## 3. Lowering and validation

The lowering path is:

1. Validate the supplied `SemanticModel` before reading generated declarations.
2. Require one source `Program` for each module containing generated declarations.
3. Convert resolved HIR TypeIds into backend TypeSpecs, rejecting unresolved, unknown, unsupported or dimension-dependent types.
4. Create temporary synthetic Programs that copy the owning source module's import metadata but contain only projected generated declarations.
5. Register generated structs and functions through existing Codegen passes.
6. Emit each module's function bodies once, even when both source and generated projection Programs exist for that module.

The synthetic Program projection does not append nodes to the caller's original parser AST. The integration test checks that the source Program still contains only its original function after Codegen. Generated type references are currently limited to declarations resolvable within the same module; the builder's bare-TypeId contract does not supply a full imported-type/access-resolution model.

Generated function bodies and call sites remain a bounded Codegen-time bridge. Since the source HIR model was analyzed before generated declarations were added, this milestone does not re-run full name resolution, overload analysis or effect analysis over source expressions after declaration generation. The body builder validates generated typed expressions and Codegen performs its existing module/name/signature/type checks against the projected backend nodes.

## 4. Not included

- FAC syntax or `consteval` access for declaration builders.
- Generated function bodies beyond the bounded scalar subset: loops, branch-local declarations/returns, multiple return paths, general CFGs, constructors, methods or lambdas.
- Generated classes, interfaces, enums, globals, generic declarations or nested declarations.
- Static/protected/fixed-array generated struct fields.
- General cross-module generated TypeId resolution, import/access re-analysis or generic substitution.
- Full post-generation HIR/type/effect re-analysis.
- A general macro system or arbitrary compile-time execution.

## 5. Regression coverage

`tests/semantic/generated_declaration_codegen.cpp` builds a source HIR model, registers a generated `Record`, a generated `Wrapper` containing `Record`, and an external `generatedValue(int) -> int` declaration. `tests/semantic/generated_function_body.cpp` separately creates generated function bodies with typed locals, nested direct calls, mutable-local assignment, nested if/else branches and a same-module call. The fixtures verify:

- emitted `%S.Record` and `%S.Wrapper` LLVM record types;
- deterministic generated external symbol registration;
- external function declaration and FAC call-site emission;
- generated struct helper emission;
- no mutation of the original source Program;
- generated function definitions with arithmetic, immutable/mutable typed locals, return values, nested direct calls, conditional branches and assignment stores; and
- successful parsing/compilation of both emitted LLVM IR fixtures with Clang when Clang is available.

Both fixtures are included in `tests/semantic/run.sh`. Commands used for the focused validation in this source snapshot:

```sh
make compiler-only
make runtime-only
sh tests/comptime/run.sh
sh tests/parser/run.sh
sh tests/codegen/run.sh
sh tests/run.sh -O0
sh tests/run.sh -O2

g++ -std=c++17 -O0 -g0 -I. tests/semantic/generated_declaration_codegen.cpp \
  -o /tmp/generated_declaration_codegen
/tmp/generated_declaration_codegen /tmp/generated_declaration_codegen.ll
clang -Wno-override-module -x ir -c /tmp/generated_declaration_codegen.ll \
  -o /tmp/generated_declaration_codegen.o
g++ -std=c++17 -O0 -g0 -I. tests/semantic/generated_function_body.cpp \
  -o /tmp/generated_function_body
/tmp/generated_function_body /tmp/generated_function_body.ll
clang -Wno-override-module -x ir -c /tmp/generated_function_body.ll \
  -o /tmp/generated_function_body.o
```

For the recorded Linux source snapshot, the compile-time suite passed 57/57, parser regression passed 68 checks, Codegen regression passed, and the legacy compiler/runtime case suite passed 132/132 at both FAC `-O0` and `-O2`. Seven targeted HIR/declaration executables (`hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir`, `typed_decl_builder` and `generated_declaration_codegen`) passed individually at GCC C++17 `-O0`; the generated-declaration fixture also passed with Clang LLVM IR parsing. The ancestry check reported 17/17. The full `tests/semantic/run.sh` wrapper exceeded the local 180-second command limit after the ancestry check, so no full-wrapper pass is claimed. These results are Linux-host checks, not cross-platform qualification.


### Generated function-body validation snapshot

For the subsequent generated-body update on Linux, `tests/semantic/generated_function_body.cpp` compiled and ran with GCC C++17 `-O0`, and Clang compiled the emitted LLVM IR. Six existing targeted HIR fixtures (`hir_model`, `typed_expr_hir`, `scope_overload_hir`, `generic_inference_hir`, `generic_free_function_hir`, `typed_decl_builder`) passed individually with GCC C++17 `-O0`. The generated-body test checks arithmetic, immutable typed locals, parameter/local bindings, a nested same-module generated call, a source call to the generated function, source-AST immutability and rejection of a return-TypeId mismatch/use-before-declare. The semantic wrapper exceeded the local command time budget after the ancestry check and the full compiler-only Make build exceeded its command time limit; neither full-suite completion nor a complete compiler-driver build is claimed for this update.
