# FAC Language Core V193 — bounded floating-point cast constants

## Scope

V193 extends the strict local-borrow fixed-array projection evaluator to fold explicit casts from statically known floating-point values to integer-like and Boolean primitive types.

Accepted floating sources are deliberately bounded:

- floating-point literals;
- initialized local `const float` and `const double` declarations whose initializer is a supported scalar literal, local constant identifier, unary sign, or explicit `Float` / `Double` cast;
- float32 declarations are rounded to their stored IEEE-754 single-precision value before the checker records them.

Integer-like targets use FAC's LLVM saturating conversion intrinsics. The checker mirrors the target's behavior: truncate toward zero, clamp signed/unsigned results to the destination range, and map NaN to zero. For `Boolean`, the conversion follows the compiler's unordered-not-equal comparison with zero, so NaN is true and both signed zeros are false.

Examples:

```fac
array var int values[256] = {}
const double precise = 3.99
const float rounded = 5.99
const double chained = cast(Double, cast(Float, 8))

ref var int a = values[cast(Int, precise)]  # index 3
ref var int b = values[cast(Int, rounded)]  # index 5
ref var int c = values[cast(Int, chained)]  # index 8
ref var int d = values[cast(Ubyte, 999.0)]  # index 255 (saturated)
ref var int e = values[cast(Byte, 300.0)]   # index 127 (saturated)
```

## Conservative boundaries

- This is not a general floating-point constant evaluator; floating arithmetic expressions are not folded in V193.
- Mutable values, parameters, globals/statics, arbitrary calls, side effects and unsupported casts remain unknown/may-alias.
- Every local constant is keyed to its exact declaration node. Shadowing and initializer-before-shadow lookup are tested.
- Unsigned-64 results above `INT64_MAX` cannot be represented by the borrow projection model and remain conservative.
- The checker does not perform array bounds checking and does not claim complete lifetime or borrow safety.

## Regression coverage

- `good_array_const_floating_cast_indices.fac` exercises double literal casts, float32 rounding, const double chaining, integer-to-double cast, nested float/double casts, Boolean casts and signed/unsigned saturation. It performs runtime writes and checks the values read through the aliases.
- `good_array_const_floating_shadowing.fac` exercises distinct local const float/double declarations with the same names in nested scopes and initializer-before-shadow lookup.
- `bad_array_float_cast_same_index.fac` verifies a float constant cast and an integer literal resolving to the same index conflict when both loans are live.
- `bad_array_mutable_float_cast_index.fac` verifies mutable float values remain dynamic/conservative.
- `bad_array_mutable_float_shadowing_const.fac` verifies a mutable shadow cannot inherit an outer const floating value.
