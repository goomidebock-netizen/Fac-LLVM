# OOP ใน FAC: access control, inheritance, interface, abstract/final, virtual dispatch (V20)

syntax ยึดแบบเดิมของภาษา (method ใช้ `function RET name(params)`) โดยมี access control และกฎ inheritance แบบ Java ที่รองรับใน V20

## class, access modifier และ constructor

```fac
public class Account {
    public var int id
    private var int balance
    protected var int branchCode

    public constructor Account(int accountId, int initial) {
        this.id = accountId
        this.balance = initial
    }
    public function int getBalance() { return this.balance }
    protected function int internalCode() { return this.branchCode }
    private function int secret() { return this.balance + 100 }
    public static var int accountCount = 0
    private static const int MAX_SECRET = 1000
}

private class InternalAccount { }
final class ImmutableAccount { }
```

- Field ของ `class` เป็น `private` โดยปริยาย; method/constructor เป็น `public` โดยปริยาย
- `static function` และ `static field` เป็นสมาชิกของ class ไม่ใช่ object; เรียก/อ่าน/เขียนผ่าน `Class.member` และไม่ใช้ `this`
- Static field รองรับ scalar, enum และ pointer; initializer ทำงานใน module initialization หลัง global variables ของ module และตามลำดับ class/field ที่ประกาศ; field ที่ไม่มี initializer เริ่มเป็นศูนย์
- `const static` ต้องมี initializer และเขียนค่าใหม่ไม่ได้; static field ใช้ `public/private/protected` ได้ตามปกติ
- `public` เข้าถึงได้จากทุกที่, `private` เข้าถึงได้เฉพาะ class ที่ประกาศ, `protected` เข้าถึงได้ใน class ที่ประกาศและ class ลูก
- `struct` field/method เป็น `public` โดยปริยาย แต่ระบุ `public`/`private` ได้; `protected` ใช้กับ class เท่านั้น
- Constructor ระบุ `public`/`private`/`protected` ได้ และชื่อหลัง `constructor` ต้องตรงกับชื่อ class
- `private` ไม่ได้แปลว่า compile-time hidden เฉพาะ field เท่านั้น: type ระดับไฟล์ก็ระบุ `private` ได้เช่นกัน
- `final class` ห้ามมี class อื่น `extends`; `final function` ห้ามถูก override และ override ห้ามลดสิทธิ์จาก `public`/`protected`
- `abstract class` ไม่สามารถเป็น `final` หรือสร้างด้วย `new` ได้

## top-level type visibility และ import

```fac
# Library.fac
public class User { ... }
private class UserCache { ... }
public struct Point { public var int x; public var int y }
private struct InternalPoint { var int x }
public enum Color { Red, Green, Blue }
private enum InternalState { Ready, Busy }

# app.fac
import Library.fac just User, Point, Color
obj Library.User u = new Library.User()
struct Library.Point p = Library.Point(2, 3)
enum Library.Color c = Library.Color.Green
```

- Type ระดับ top-level เป็น `public` โดยปริยายเพื่อรักษาความเข้ากันได้; ระบุ `private` เพื่อใช้ได้เฉพาะภายใน module เดียวกัน
- `public/private` ใช้กับ `class`, `abstract class`, `interface`, `struct` และ `enum`
- `import ... just ...` และ `import ... without ...` กรองการเข้าถึง user-defined type ด้วย ไม่ได้จำกัดเฉพาะ function/global
- ใช้ type ที่ import ด้วยชื่อ `Module.Type`; import alias ก็ใช้ได้ เช่น `import Library.fac as Lib` แล้วอ้าง `Lib.Point`
- `extends` และ `implements` ตรวจ import และ visibility ของ parent/interface ด้วย

## interface
```
interface Shape {
    function double area()                 # abstract contract: ไม่มี body
    function string name()
    function string describe() {            # default method: มี body
        return "Shape: " + this.name()
    }
}
interface Entity extends Named, Scorable { # interface สืบจาก interface ได้หลายตัว
    function string describe()
}
```
- Interface รับเฉพาะ method ไม่มี field/constructor; method ที่ไม่มี body เป็น abstract contract ส่วน method ที่มี body เป็น default method
- Interface method เป็น public instance method เสมอ; ห้าม private/protected/static/final/override
- Class ใช้ default method ได้โดยไม่ต้องเขียนซ้ำ; class ที่รับ default ชื่อเดียวกันจากหลาย interface ต้อง override เพื่อแก้ความกำกวม
- `class Rect implements Shape, Other { ... }` — implements ได้หลาย interface; class ต้อง implement ครบทุก method ด้วย **signature เดียวกันทุกตัว** (ชื่อ, ชนิดพารามิเตอร์, ชนิดคืนค่า) และเป็น public instance method ไม่งั้น compile error ที่ชี้ class/method/signature ที่ต้องเป็น
- `obj Shape s = new Rect(...)` — ตัวแปร/พารามิเตอร์/ฟิลด์/ค่าคืนชนิด interface รับ object ของ class ที่ implements (หรือ interface ลูก); `new Shape()` ไม่ได้
- `override` ใช้กับ method ที่ implement interface ได้ด้วย (และตรวจว่ามี method นั้นจริงใน parent หรือ interface)

## abstract class
```
abstract class Base implements Entity {
    public abstract function int power()                          # ไม่มี body
    public function int score() { return this.hp * 10 + this.power() }   # template method: เรียก method ของลูกผ่าน this
}
```
- `new` abstract class ไม่ได้; class จริงที่สืบต่อต้อง implement ครบทุก abstract method และ method ของ interface ที่ยังค้าง
- abstract class ที่ `implements` interface ไม่ต้อง implement เอง แต่เรียก method ของ interface ผ่าน `this` ได้

## virtual dispatch
- method instance ที่ไม่ใช่ `private` และไม่ใช่ `static` เลือก implementation ตาม **ชนิดจริง** ของ object ตอนรัน: `obj Animal a = new Dog()` แล้ว `a.sound()` เรียก `Dog.sound` ถ้า Dog ประกาศ method นั้นซ้ำ (signature ต้องตรงกับของ parent ไม่งั้น error)
- compiler วิเคราะห์ทั้งโปรแกรม: เรียกแบบ virtual เฉพาะ method ของ interface/abstract หรือที่มี class ลูกหลานประกาศซ้ำ — ที่เหลือเรียกตรงเหมือนเดิม จึงโค้ดเดิมไม่เสียความเร็ว
- `super.method(args)` เรียก implementation ของ class แม่โดยตรง (ไม่ผ่าน virtual) ใช้ต่อยอดพฤติกรรมที่ override
- การเรียกใน constructor ไปถึง override ของ class ลูกได้ (ชนิดจริงถูกกำหนดตั้งแต่ `new`) เหมือน Java — ฟิลด์ของลูกอาจยังไม่ถูกกำหนดค่า
- เรียก method ผ่าน object ที่เป็น `null` แบบ virtual → `Error` code 7; การเรียกตรง (ไม่ virtual) ผ่าน null ยังเป็นพฤติกรรมเดิม (ไม่ตรวจ)
- ต้นทุน: virtual call ≈ +4–5 ns ต่อครั้งบน x86-64 (วัด 20 ล้านครั้ง ~0.18 s เทียบการเรียกตรง ~0.10 s)

## กลไก (สำหรับผู้พัฒนา compiler)
object มี header `{refcount, drop, vtbl, pad}` (32 ไบต์) ก่อน payload; `vtbl` ชี้ตารางต่อ class ที่ compiler สร้าง `void*[2N+1] = {N, selector1, fn1, ...}` โดย selector = ชื่อ + signature ของ method; `fac_vcall(obj, selector)` ค้นหา function (เส้นตรง ตารางเล็ก) — ใช้กลไกเดียวกันทั้ง class และ interface

## list ของ object
`list dyn obj Shape xs` (ต้องเป็น `dyn`; element เป็น class หรือ interface): `add insert set get remove clear` · `xs[i]` · `sizeof(xs)` · `for (var auto s : xs)` · slice `xs[a:b]` · คัดลอก/ส่งเข้าฟังก์ชัน/คืนจากฟังก์ชัน; ใส่ object ผิดชนิดเป็น compile error; list ถือ 1 reference ต่อ element และปล่อยตอน remove/clear/ปล่อย list; เป็นฟิลด์ของ class ได้ (`public list dyn obj Shape items`)

## ตัวอย่างครบวงจร
`stdlib/entity.fac` — `interface Entity { update(dt), draw(g, camX, camY), alive() }` + `class World` เก็บ entity หลายชนิดไว้ในลิสต์เดียว (`add`, `update` — ถอดตัวที่ตายแล้ว, `draw`) ดู `tests/cases/t47_entity_world.fac`

## instanceof และ downcast (V20)
```
if (s instanceof Square) { ... }          # boolean; true เมื่อชนิดจริงเป็น Square หรือลูกหลาน
if (s instanceof Solid)  { ... }          # interface ก็ได้
obj Square q = cast(Square, s)            # downcast ตรวจตอนรัน: ผิดชนิด -> throw Error code 7 ; null ผ่านเป็น null
```
กลไก: `instanceof` เทียบ vtbl ใน header ของ object กับ `@vtbl.<Class>` ของ class จริง (ไม่ abstract) ทุกตัวที่เป็นชนิดนั้นซึ่ง compiler รู้ตอนคอมไพล์ จึงไม่มี runtime type table เพิ่มและไม่มีต้นทุนตอนสร้าง object · `null instanceof T` = false · ซ้ายมือต้องเป็น obj · ดู `tests/cases/t75_instanceof.fac`

## Generic methods

```fac
class Box {
    public function<T> T identity(T value) { return value }
    public static function<T> T same(T value) { return value }
    public function auto inferred(auto value) { return value }
}
obj Box box = new Box()
var int x = box.identity<int>(42)
dyn string y = Box.same<dyn string>("FAC")
```

- `function<T> ReturnType method(T value)` ประกาศ type parameter ของ method; ระบุ type argument เมื่อเรียก เช่น `box.identity<int>(42)`.
- `auto` ใน parameter หรือ return ยังคงเป็น generic method แบบ inference เดิม; ทั้งสองรูปแบบสร้าง specialization ตามชนิด argument.
- Generic method `<T>` ใช้ได้กับ instance/static method รวมถึง method ภายใน generic class; V46 เพิ่ม method-level constraints เช่น `function<T: IReadable> T copy(T value)`. ยังไม่รองรับ generic method ใน interface, virtual dispatch หรือ `override`.
- Generic class/interface ใช้ type parameter แบบ compile-time specialization; ดูหัวข้อ **Generic classes และ interfaces** ด้านล่าง

## Generic classes และ interfaces

```fac
public interface IValue<T> {
    function T get()
    function T copyValue() { return this.get() }
}

public class Box<T> implements IValue<T> {
    public T value
    constructor Box(T item) { this.value = item }
    public function T get() { return this.value }
    public function<U> U echo(U item) { return item }
}

public struct Pair<K, V> {
    public K key
    public V value
    public function V getValue() { return this.value }
}

obj Box<int> number = new Box<int>(42)
obj Box<dyn string> text = new Box<dyn string>("FAC")
struct Pair<int, dyn string> pair = Pair<int, dyn string>(1, "one")
dyn string copy = number.echo<dyn string>("generic method")
```

- Generic class, interface และ struct ประกาศ type parameter ด้วย `<T>`; รองรับหลาย parameter เช่น `Pair<K, V>` และ type argument แบบซ้อน เช่น `Box<obj Box<int>>`
- ใช้ type argument แบบชัดเจนใน type position, constructor และ generic method; compiler ทำ compile-time monomorphization สร้าง layout, methods, vtable และ runtime trace/drop callbacks แยกตาม concrete arguments
- Type parameter ใช้ใน field, constructor/method parameter และ return type, method body, parent class, `implements`, interface `extends` และ nested generic types ได้
- Generic inheritance/interface specialization รองรับ เช่น `class Child extends Base<int>` และ `class Box<T> implements IRead<T>`; interface default methods และ abstract contract ยังคงใช้ได้หลังแทนค่า type parameter
- Generic struct เป็น value type และรองรับ field/method ที่ใช้ type parameter เช่น `struct Pair<int, dyn string>`; managed members ใช้ copy/cleanup ของ struct ตามระบบเดิม
- Constraints รองรับหลาย bounds ต่อ type parameter ด้วย `&` เช่น `T: IReadable & ISerializable`; ทุก bound ต้องผ่าน (intersection/AND). รองรับ `Interface`, `BaseClass`, `StructName` และ built-ins `numeric`, `integral`, `reference`, `value`; ตรวจที่ compile time รวมถึง imported bounds
- Generic method ระบุ type parameters หลัง keyword `function` เช่น `function<T> T identity(T value)` และเรียกด้วย type arguments ชัดเจน เช่น `box.identity<int>(42)` หรือ `Box.same<dyn string>("FAC")`; ใช้ได้กับ instance/static method และ method ภายใน generic class
- Generic class/struct ที่ import ได้ใช้ `import Lib.fac as L just Box, Pair` แล้วอ้าง `obj L.Box<int>` หรือ `struct L.Pair<int, dyn string>`; `public/private` และ `just/without` ตรวจที่ declaration ต้นทาง
- Generic class ใช้เป็น element type ของ `list dyn obj`, เก็บ object/weak reference fields และถูก trace โดย explicit cycle collector ได้ตามข้อจำกัดของ collector เดิม
- ยังไม่มี type-argument inference, variance, generic enum/payload variants หรือ runtime reflection ของ generic arguments. Method-level constraints ตรวจตอน compile-time specialization; generic interface method และ generic virtual/override dispatch ยังไม่รองรับ
- Generic method `<T>` ยังไม่รองรับใน interface contract หรือ virtual/override dispatch; generic method ใน interface ถูกปฏิเสธอย่างชัดเจน. Constraints บน generic method และ multiple bounds ใช้ได้กับ method ปกติที่ถูก specialize แบบ static; method-level bounds ที่เป็น generic-interface specialization ยังไม่รับรองใน V46

## Destructor และ object lifetime

```fac
class Resource {
    public dyn string name
    constructor Resource(string value) { this.name = value }
    destructor Resource() {
        terminal.out.println("release: ", this.name)
    }
}
```

- Class มี `destructor ClassName()` ได้หนึ่งตัว; ไม่มี parameter และไม่มี return value. ผู้ใช้เรียกเองไม่ได้
- Runtime เรียกเมื่อ reference count ลดเหลือศูนย์เท่านั้น; alias ที่ยังถือ object อยู่จะเลื่อนเวลาทำลายออกไป
- ลำดับ inheritance คือ destructor ของ class จริงก่อน แล้วไล่ไป base class; จากนั้น runtime จึง release managed fields และคืน storage
- ห้าม `throw` โดยตรงจาก destructor และควรเขียน destructor ให้ไม่เกิด runtime error เพราะทำงานอยู่ใน release callback
- `memory.collectCycles()` สามารถเก็บกวาด unreachable cycle ที่ประกอบจาก strong `obj` fields ใน class และ field แบบ by-value `struct` ที่ซ้อนอยู่ได้ โดย runtime ใช้ trace callback ที่ compiler สร้างและ trial-deletion จาก reference count
- Collector ทำงานแบบ explicit เท่านั้น ไม่ได้รันอัตโนมัติ; เรียกเมื่อไม่มี thread อื่นกำลังอ่าน/แก้ object graph (โดยเฉพาะ field ของ object) อยู่
- Local variables, `list dyn obj` และ closures ที่ trace ไม่ได้จะถูกนับเป็น external roots แบบ conservative จึงอาจทำให้ cycle ที่ผ่านโครงสร้างเหล่านี้ไม่ถูกเก็บกวาด. Foreign raw pointer ไม่ได้ถูก register/retain อัตโนมัติ จึงห้ามเก็บ pointer ให้มีอายุเกิน reference ที่ FAC ถืออยู่หรือใช้ข้ามการ collection
- Collector ทำ destructor ทั้งหมดของชุดที่เก็บกวาดก่อน release managed fields ของสมาชิกใด ๆ; จากนั้นจึง free storage. Object ที่มี reference count ไม่ตรงกับจำนวน edge ที่ trace ได้จะถูกเก็บเป็น root เพื่อความปลอดภัย.

## Weak references

```fac
class Node { public var int value }
obj Node strong = new Node()
weak obj Node observer = memory.weak(strong)
obj Node locked = memory.weakLock(observer)  # คืน strong reference หรือ null
if (locked != null) {
    terminal.out.println(locked.value)
}
```

- `weak obj ClassName name` เป็น handle แบบ managed; การ copy/assign/return/เก็บใน field จะ retain/release control block อัตโนมัติ
- `memory.weak(obj)` สร้าง weak handle โดยไม่เพิ่ม strong reference ให้ object; type ของ handle ระบุด้วย `weak obj ClassName` และใช้เป็น parameter, return value, local หรือ field ได้
- `memory.weakAlive(handle)` เป็นการตรวจสถานะเพื่อ diagnostics; ใน concurrent code ให้ใช้ `memory.weakLock(handle)` โดยตรง แล้วตรวจผลกับ `null` ก่อนเข้าถึง object เพราะสถานะอาจเปลี่ยนหลัง `weakAlive` ได้. `weakLock` atomically ขอ strong reference และคืน `obj ClassName` หรือ null
- weak handle ไม่ใช่ `ptr` ดิบ; ไม่ต้องเรียก `free` หรือ release เอง
- object จะถือว่า expired ตั้งแต่เริ่ม finalization; `weakLock` จึงไม่สามารถเข้าถึง object ระหว่าง destructor
- Weak fields ไม่ถูกนับเป็น strong edges ของ cycle collector และไม่ทำให้ object อยู่รอด; compiler สร้าง retain/release ของ weak-control block สำหรับ local, parameter, return, lambda capture และ nested by-value struct field

## ข้อจำกัดที่ยังเหลือ
Generic enum และ payload variants, type-argument inference, variance, generic interface methods, generic virtual/override dispatch และ runtime reflection ของ generic arguments ยังไม่รองรับ. V46 เพิ่ม multiple bounds (`T: A & B`) และ method-level constraints สำหรับ generic methods ที่ specialize แบบ static. Generic specialization เป็น compile-time monomorphization. Weak references รองรับเฉพาะ class object ที่จัดการโดย FAC runtime; cycle collection รองรับเฉพาะขอบเขตที่อธิบายด้านบน. Inline cache ยังไม่มี (virtual ทุกครั้งค้นตารางเส้นตรง).
Static field ในรุ่นนี้จำกัดเป็น scalar/enum/pointer; ยังไม่รองรับ managed type เช่น string/list/object เพื่อหลีกเลี่ยง ownership และ shutdown-order ที่ไม่ชัดเจน


## Java-style application entry point (V49)

FAC accepts a Java-like class entry declaration while retaining the original top-level `public function void main()` form:

```fac
import terminal.fac

public class main {
    public static function void main(list dyn string args) {
        terminal.out.println("Hello, World!")
    }
}
```

The class may have another name (for example `App`). The entry method must be a directly declared public static method returning `void`; it accepts either no parameters or exactly `list dyn string args`. The list contains command-line arguments excluding the executable name. The compiler initializes the runtime/modules, invokes the method, and shuts down the runtime. A program cannot mix this form with top-level `main`. See [`JAVA_STYLE_ENTRY.md`](JAVA_STYLE_ENTRY.md) for the full contract and limitations.


## Const-qualified methods (V50)

FAC supports read-only instance-method contracts with a trailing qualifier:

```fac
public function int getValue() const {
    return this.value
}
```

Const methods cannot directly mutate `this`, call a non-const method on `this`, or capture `self` in a closure when `--strict-ownership` is enabled. The qualifier participates in interface/override signature matching. It is a compiler-enforced conservative contract, not a guarantee against mutation through raw pointers or foreign code.
