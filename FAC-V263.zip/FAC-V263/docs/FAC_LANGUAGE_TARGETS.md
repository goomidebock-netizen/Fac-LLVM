# FAC Language and Platform Target Matrix — V165

## V220 multi-paradigm Language Core alignment

The paradigm-level status and usage contract is now consolidated in [`LANGUAGE_PARADIGMS.md`](LANGUAGE_PARADIGMS.md). The current source tree supports procedural programming; a substantial OOP subset; type-level generic specialization; function values/lambdas and selected functional constructs; bounded compile-time constant evaluation with restricted scalar free-function `consteval`, type/layout queries and public-field structural queries for resolved struct/class records; and a documented low-level pointer/FFI surface. These areas have different maturity levels and must not be marketed as complete parity with other languages.

V220 adds bounded `const int` generic parameters to generic struct/class declarations, free functions and methods. Call sites may pass integer constant expressions; const values participate in specialization keys and are substituted through bodies and dependent types, including fixed-array dimensions. Generic struct/class instantiations and generic methods with const parameters do not infer omitted arguments, but may omit parameters with declared defaults; generic free functions may infer const values when a parameter declares a fixed array extent directly as `[N]` and the corresponding argument has a known fixed size. Type and const arguments may be inferred together, and conflicting extents are rejected. Trailing type defaults may be declared on generic struct/class/interface/enum declarations, free functions and methods; trailing `const int` defaults are supported on struct/class declarations, free functions and methods; inference takes precedence over defaults on free-function calls without explicit generic arguments. This is not general compile-time execution: inference does not solve arithmetic extent patterns, dynamic lengths or runtime integer arguments. V220 separately supports a restricted `consteval` interpreter for scalar free functions with local scalar variables, branches, returns, nested calls and recursion, bounded to depth 64 and 100,000 steps. Bounded structural queries (`fieldCount<T>()`, `fieldName<T,I>()`, `fieldType<T,I>()`, `fieldOffset<T,I>()`) enumerate public non-static instance fields of resolved struct/class records, including inherited public class fields. Generic specialized records, interfaces/enums, private/protected/static field enumeration, generic/method consteval, source-level typed AST or declaration builders, unrestricted macros (an internal immutable typed-expression HIR projection and C++ `TypedAstFactory` for validated generated expressions are implemented; neither is exposed to FAC nor connected to code generation; see `TYPED_AST_BUILDER_V220.md` and `TYPED_AST_FACTORY_V220.md`), type/interface bounds on const parameters, reference-capturing closures, generic virtual/interface methods, and a universal safe raw-pointer/FFI proof remain unsupported.


## V165 SIMD and platform CI foundation

V170 keeps the float64 compute API CPU-only. Bounded little-endian CPU SIMD and portable scalar paths remain; native GPU/OpenCL device loading and dispatch are paused and are not part of the current Runtime.

# FAC Language and Platform Target Matrix — V124

## V124 concurrency error propagation and channel receive safety

V124 adds worker-local FAC error boundaries for `thread.parallelFor` and makes `sync.Channel.recv` preserve queued messages if result-buffer allocation fails. Worker cleanup completes and all workers join before the original FAC error is propagated to the caller. No new API, syntax, platform support claim or atomic-order contract is introduced. See `docs/CONCURRENCY.md` and `docs/STATUS.md`; TSan/full Runtime sanitizer qualification remains incomplete.

## V123 generic specialization reliability/performance

V123 changes only compiler-internal generic specialization accounting and lookup: cache hits do not consume the 5,000 distinct type-specialization budget, and lookup-only specialization caches use hash maps. The actual distinct-specialization ceiling and generic syntax/semantics are unchanged. No API, Runtime or platform-support claim changed. See `docs/GENERIC_SPECIALIZATION.md` and `docs/STATUS.md`.

## V122 compiler memory lifetime

V122 releases frontend AST/symbol/generic state after IR generation and before invoking the backend. A glibc-specific best-effort trim is used only on large builds; other platforms retain their native allocator behavior. No language syntax, API, Runtime or platform support claim changed. See `docs/COMPILER_MEMORY.md` and `docs/STATUS.md` for measurements and validation scope.

## V120 semantic subtype-check performance

V120 removes temporary worklist/set allocations from concrete class-to-class ancestry checks and protected-member parent traversal. Interface assignability keeps its cycle-safe multi-edge traversal. The type system and all public API layers remain unchanged. See `docs/STATUS.md` and `docs/PERFORMANCE.md` for benchmark and validation scope.

## V119 Parser performance and source diagnostics

V119 optimizes parser hot paths while preserving the established grammar: assignment operator recognition uses exact fixed-vocabulary checks instead of a `std::set` lookup per expression, binary precedence dispatches by the operator's leading character, and parsing string tokens avoids an extra full-token copy. Parser errors now carry a 1-based UTF-8 byte column and the compiler driver prints `file:line:column`. The synthetic benchmark and validation limits are documented in `docs/PERFORMANCE.md` and `docs/STATUS.md`. No Syntax, API, C ABI or Runtime ABI changes were made.

## V212 Runtime Tensor shape and backing-store safety

V212 applies a central opaque-handle validation boundary to Tensor objects: dimensions must be positive, their product must remain within the shared 16,777,216-value limit without overflow, and the backing vector must contain exactly the declared number of values. Nested optimizer state tensors, train/test split handles, and tensor-autograd node values/gradient storage receive corresponding invariant checks. The existing software-reference float64 buffer API remains bounded and transactionally validates numeric operations; its range/aliasing regressions are included in the Runtime suite. This is targeted validation of Tensor and buffer boundaries, not a universal Runtime memory-safety guarantee. No public API or ABI changed.

## V211 Runtime DataFrame shape and grouped-storage safety

V211 validates every non-null DataFrame handle at the central Runtime access boundary: row counts must be non-negative, column counts must be positive and bounded, the row/column product must fit the shared 16,777,216-value budget without overflow, and the backing value count and column-name count must match the declared shape. Grouped reductions now use one accumulator per distinct key rather than a vector of every value in each group; because each result has two columns, the implementation rejects a ninth millionth distinct key before growing the result map beyond the 16,777,216-value ceiling. C++ allocation and length failures during grouped aggregation are translated into FAC Resource errors, with temporary workspaces released through the FAC cleanup stack. This is targeted DataFrame hardening, not a universal Runtime memory-safety proof. No public API, C ABI, Runtime ABI or language semantics changed.

## V117 Runtime exception-safety and managed-memory hardening

V117 hardens Runtime allocation-failure paths in Linked List, Stack, Queue, Heap, AVL Tree, Trie and Matrix. Clone operations now keep unpublished results under RAII; failed container insertion releases pending managed-string references; AVL node creation and successor-key replacement are failure-safe; and Trie insertion rolls back a partially-created path. Targeted deterministic fault-injection tests verify failed clone cleanup, retry behavior and managed allocator balance. The existing C ABI entry points translate caught `std::bad_alloc` / `std::length_error` into FAC Resource error 5.

This is targeted Runtime exception-safety coverage, not a universal guarantee. FAC errors still use non-local transfer in some paths, and unguarded C++ automatic objects can still be skipped by `do_throw`. V117 does not change Syntax, API declarations, C ABI or Runtime ABI. Validation details and limits are recorded in `docs/STATUS.md` and `docs/RUNTIME.md`.


## V100 Tensor Autograd, DataFrame analytics and software compute abstraction

V100 extends V99 with tensor-wide reverse-mode differentiation on CPU float64, additional numeric DataFrame transformations and grouped reductions, and float64 compute dispatch through the software-reference GPU abstraction. The compiler built-in module registry, opaque pointer types, LLVM declarations, Runtime implementations, standard-library surfaces and API metadata are updated together and covered by FAC-level tests. This does not claim hardware GPU acceleration, mixed-type/null DataFrame cells or a complete neural-network training framework.

## V98 expanded tensor, data, ML/DL and optimizer library surface

V98 extends the V97 portable CPU numerical foundation. Tensor APIs now include extraction, concatenation, dot product, axis reductions and elementwise math; data APIs add one-hot encoding, column removal and deterministic train/test splitting; statistics and metrics cover additional robust and classification measures; ML adds ridge regression and kNN classification; NN adds GELU/ELU/Leaky ReLU/Softplus and explicit gradients; optim adds Momentum, RMSProp and gradient clipping. The existing syntax style is retained and API contracts remain cross-platform.

All new numerical implementations are CPU float64 operations. They do not imply hardware GPU support, automatic differentiation or production-scale training infrastructure. The `gpu` module remains a software-reference buffer API. No native/platform-specific API was added.

## V96 Runtime allocation-failure and exception safety (previous release)

V96 hardens the Runtime HashMap/HashSet/Graph paths against C++ STL allocation failures. HashMap insertion publishes its item and index together with rollback on index-allocation failure; value replacement constructs the new value before releasing the old one; failed tombstone compaction leaves the old valid representation intact. Graph node creation reserves parallel storage/index capacity before publishing, and undirected edge insertion reserves both adjacency sides before either edge is committed. Graph and HashMap clone operations clean up incomplete copies. Guarded C ABI entry points translate caught `std::bad_alloc` / `std::length_error` to FAC OutOfMemory (5). This remains targeted exception-safety coverage, not a universal Runtime allocation-failure guarantee.

## V95 Runtime Trie stack-safety (previous release)

Trie `remove()`, prefix enumeration (`words()`), and subtree destruction are iterative rather than recursive in key-byte length. The regression test exercises a 100,000-byte key and passes with a 256 KiB native stack (the V94 path segfaulted under the same limit). This removes one depth-proportional native-stack risk; it does not establish that all Runtime operations are recursion-free or that the whole Runtime is memory-safe.

## V94 compiler resource budgets (historical)

V94 adds compilation-wide limits on top of the V93 per-source lexer budget: at most 2,000,000 emitted tokens across all imported source units (including tokens re-lexed for interpolation), 128 MiB of aggregate source text, 4,096 source modules including the entry file, and 128 levels of import nesting. The loader releases each parsed source buffer before descending into its imports, avoiding retention of the complete ancestor source chain. Exceeding a budget produces a deterministic compile diagnostic. These defensive limits do not change valid source syntax or generated program behavior below the limits.
This is the product contract and engineering map for FAC V101. It separates what the V101 source tree actually implements from what FAC is intended to become. A feature marked partial or planned must not be described as complete merely because a related syntax or API name exists.

## 1. Product identity and priorities

FAC is intended to be one statically typed, native-code, general-purpose language for low-level systems, command-line tools, desktop/mobile applications, backend services, audio, 2D/3D games, UI, and ML/DL/AI workloads, from small utilities to large systems. It is not intended to replace HTML/CSS/JavaScript or SQL as specialist technologies.

The quality priorities are:

1. **Correctness and stability first**: deterministic semantics, compiler diagnostics, reproducible builds, versioned APIs and regression coverage.
2. **Memory and concurrency safety next**: safe-by-default high-level operations, ownership transfer, complete borrow/lifetime checks at safe boundaries, and explicit unsafe escape hatches.
3. **Very high native performance**: direct LLVM code generation, specialization, low-overhead runtime paths, predictable allocations, and benchmark-driven optimization.
4. **Broad capability without a fragmented language**: one language core and two explicit API layers.
5. **Readable explicit syntax**: Java-like declarations where they improve clarity (for example `array var int values[10]`, `public function int run(...)`, and explicit class constructors); concise forms are acceptable where they do not obscure types or ownership.

These are goals, not measured V101 guarantees. Performance must be established through controlled benchmarks; safety must be established through concrete analyses and tests.

## 2. Language core and paradigms

| Area | V117 source-tree state | Target direction |
|---|---|---|
| Basic language core | Implemented broad subset: modules/imports, declarations, scalar/aggregate values, functions, visibility, errors, arrays/lists/tuples, structs/enums | Freeze evaluation order, overflow/conversion, initialization, nullability and compatibility rules in a normative spec |
| Control flow | `if/else`, `for`, foreach, while/do-while, `for++`/`for--` forms, `switch`, `match`, guards, labels, `break`/`continue`, `try/catch/finally`, `defer`, propagation | More complete nested patterns, iterator contracts, effects and precise exceptional CFG edges |
| Functions | Free functions, methods, overloads, default/variadic args, function values and lambdas; V64 preserves function-value effects; V65 resolves direct-call `ref`/`noescape`/`readonly` effects against the best statically applicable overload with fail-closed ambiguity handling | Better inference, target-aware indirect-call proof, return-value lifetime/effect contracts, explicit capture modes and async/task function model |
| OOP | `class`, `obj`, `struct`, `enum`, constructors/destructors, access modifiers, inheritance, interfaces, abstract/final/override/static, const methods | Stronger field initialization guarantees, sealed hierarchies, generic virtual interface design, explicit resource/RAII policy |
| Generic programming | Generic class/struct/interface/method specialization, bounded generic free-function inference, fixed-array const-value inference, and multi-bounds (`T: A & B`) | Nested constructor inference, broader method/type inference, associated types where useful, better constraint diagnostics and specialization cache controls |
| Functional programming | Lambdas, higher-order callbacks, function types, expression `match`, `Option<T>` and `Result<T,E>` payload enums | Closure return/capture completeness, immutable collection APIs, lazy iterators and composable error/result operations |
| Type system | Static scalar/aggregate types, explicit `var/ptr/dyn/heap`, generic constraints, aliases, enum payloads, const method contracts | Inference, nullable distinctions, variance rules, trait/effect solving, typed lifetime/ownership capabilities |
| Template programming | Type-level specialization plus `const int` generic struct/class parameters substituted in declaration-body expressions and usable for fixed-array field dimensions | Named/expression const arguments, additional value types, const parameters on functions/methods/enums, type-level value constraints |
| CTM / metaprogramming | V52 `static_assert`; V220 restricted scalar free-function `consteval`; bounded type/layout and public-field structural queries; immutable typed-expression AST plus C++ expression/declaration/body builders; bounded LLVM Codegen projection for generated non-generic structs, external free-function prototypes and scalar free-function bodies with mutable locals, assignments and nested `if/else` | Full/generic reflection, typed/aggregate constants, generic/method consteval, FAC source-level AST/declaration builders, loops, branch-local declarations and multiple generated return paths, generated classes/methods/generics, full post-generation re-analysis and deterministic macros; no arbitrary host execution |
| Low-level programming | Raw pointers, dereference, pointer arithmetic, allocation/free, `volatile`, alignment, `extern`, `link`, target-driven LLVM output | Stable `repr(C)`/layout contract, explicit calling convention selection, atomics/SIMD/intrinsics and eventually assembly; all unsafe surfaces documented |

### Syntax style contract

- Preserve current grammar when possible; an improvement should be additive unless a compatibility proposal explicitly says otherwise.
- Keep declaration types visible where useful: `array var int samples[256]`, `list dyn string names`, `ref const Counter counter`.
- Keep ownership operations explicit (`move(value)`); do not silently convert borrowed values into owned values or vice versa.
- Keep `class` for identity/reference semantics, `struct` for value semantics, and `enum` for tagged sum types.
- New syntax must have grammar, semantic rules, diagnostics, code generation/runtime semantics, positive and negative tests, and updated `syntax/fac_spec.fac` before it can be called implemented.

## 3. Memory safety, ownership and borrowing

| Feature | V65 state | Exit criterion for completion |
|---|---|---|
| Managed values / deterministic cleanup | Implemented for supported strings, lists, structs, objects, closures and enum payloads | Destructor/unwind/exception tests for every aggregate shape |
| Safe profile | `--safe`, `--strict-safe`, `--secure`; raw pointer/FFI operations are gated and worker closures checked conservatively | Safe APIs and FFI wrappers have explicit unsafe contracts and call-graph summaries |
| Move semantics | `move(local)` plus nested named value-struct paths such as `move(record.inner.payload)`; CFG tracks moved projections and subtree reinitialization; runtime fields use null/zero sentinels | Add indexed projections only with precise alias/drop semantics; complete partially initialized array/enum/custom-resource drop state |
| Ownership transfer | Move into supported calls/returns and runtime-managed values; not a universal borrow-aware type qualifier | Explicit consume/take contract in type and API metadata, no hidden copy on consume path |
| Immutable borrow | `ref const T`, const instance methods, declaration-identity CFG liveness, shared local aliases and nested projection-aware shared reborrows | Complete escape boundaries, indirect-call and container lifetime summaries |
| Mutable borrow | `ref T` parameters, declaration-identity CFG liveness, local exclusive aliases, mutable reborrows and parent suspension | Full alias-aware transfer/effect model and exact path-sensitive release |
| Lifetime checker | V57 adds lexical block/loop regions (retained in V65) and owner/parent outlives constraints; V62 adds nested projection-aware loans, but no general lifetime parameters or reference-return solver | Extend the region model to returns, stores, closures, callbacks, async and FFI |
| Dangling-reference detection | Partial: V58 tracks direct `addr(local)` provenance; V59 adds `noescape`, and V61 adds `readonly` pointer effects plus override/interface promise checks. Extern effects remain trusted | Add target-aware indirect-call/FFI summaries, alias provenance for untracked values, and container invalidation/lifetime contracts |
| Partial move | V63 supports partial moves of managed handles and managed value-struct subaggregates along metadata-validated local field paths; branch/loop state is tracked per projection, and recursive drop uses zero/null sentinels. Arrays, indexes, enum payloads, classes and raw pointers remain unsupported | General per-field drop flags, nested/enum/array/class fields, partial initialization and deeper field-sensitive borrow analysis |
| Static data-race analysis | Partial: typed global read/write/alias/atomic effects; V67 adds call-site lock-context propagation; V68 records per-side atomic read/write memory orders, compare-exchange failure order, SeqCst aliases, and mixed atomic/non-atomic conflicts; V70 adds per-storage may-read-from pairs, CAS failure-Acquire candidates and possible RMW bridge diagnostics; V71 adds a whole-program static worker registry across loaded modules, canonical imported-global storage identity, cross-worker atomic candidate pairs, `parallelFor` self-replication candidates and ordinary conflict-pair counts; V72 classifies direct launch sites as per-activation, loop-repeatable or parallel-replicated and tracks direct local `ptr thread` handles through bounded structured flow; V73 adds bounded join-effect summaries across unique direct free-function calls and helper chains; V78 adds dependency-worklist propagation for field-by-field lifecycle summaries when eligible free functions forward whole or nested value-struct parameters through uniquely resolved helpers. The summary no longer depends on source declaration order; reverse-declared multi-hop wrappers converge, while recursive and ambiguous forwarding remain unknown. V75 explicit whole-aggregate `move(...)` tracking remains available. V79 added exact literal argument types and the regular overload score for struct-helper overloads; V81 adds call-site lexical binding for explicitly-declared primitive identifiers; V82 recognizes direct scalar-literal initializers of local `var auto` declarations; V83 additionally follows simple scalar identifier value-copies through already-known lexical bindings; V85 recursively recognizes exact result types for unary-operator chains rooted in supported scalar literals, such as `!!false` and `-~1`, when selecting helper overloads; V86 recognizes the explicit result type of built-in primitive `cast(Type, value)` expressions, including nested casts and eligible `auto` initializers; V87 recognizes the fixed `String` result of direct built-in `str(value)` expressions; V88 recognizes fixed-result parse/size/sizeof/strcmp calls; V89 reuses scalar return contracts from the existing built-in API table when canonical path and arity match; V90 additionally mirrors `random.int`'s `Int`/`Long` result selection only when both source arguments are proven integer types, with `Long` selected if either is wider than 32 bits. V92 preserves this result through eligible `var auto` initializers with proven bounds and subsequent scalar `auto` value-copies; unsupported calls and computed bounds remain unknown. Unsupported argument forms remain unknown; void/pointer/list results remain unknown. Arbitrary user-defined calls, computed expressions, member paths, globals and conflicting shadow declarations remain unknown. Return/escape/alias and unresolved calls remain unknown. The graph remains candidate-only, and lifecycle labels are not runtime execution counts or happens-before proofs | Prove actual runtime multiplicity/thread identity, concrete read-from and modification order, release sequences, complete interprocedural handle ownership, general struct parameter/return ownership contracts, raw-pointer partial moves, alias equivalence, lock ordering, and FFI/trusted-code effects |

V64 improves the local proof boundary by identifying both borrow aliases and owner storage by declaration identity, then assigning owner and loan declarations to a lexical region tree. The alias must resolve to tracked local, parameter or receiver storage visible at its declaration; the owner region must equal or outlive the loan region, and the parent region must outlive a reborrow child. Local aliases cannot be stored as fields or returned as references in the current grammar. This is a bounded lexical outlives solver, not a general lifetime-parameter inference system. The intended safe model is: one owner may mutate; immutable aliases may coexist; mutable access is exclusive; ownership may be transferred; sharing mutable state across threads requires audited synchronization. `unsafe`, raw pointers and FFI remain available for systems work, but their contracts must be explicit. A successful `--secure` build must not be marketed as a formal proof until the listed analyses are complete. V63 rejects direct frame-pointer escapes unless the callee has a checked or explicitly trusted noescape contract, but immediate FFI/call retention and opaque pointer transformations remain outside the proof.

## 4. Concurrency and Runtime

The language should support native threads, tasks, parallel work, atomics, channels, locks, async I/O and cancellation. V101 retains threads, `parallelFor`, atomic integer functions, `sync.Atomic`, `sync.Channel`, `sync.Cell`, worker error propagation, static launch-multiplicity labels, bounded local thread-handle lifecycle summaries for local variables and value-struct fields, direct-call `ptr thread` effects, and V78 dependency-worklist per-field value-struct forwarding summaries. V68 added per-side atomic memory-order summaries; V70 added per-storage read-from and RMW bridge candidates; V71 collects statically visible worker launch sites across loaded modules and joins their effects by canonical global storage identity. V79 does not turn candidate edges into actual read-from, modification-order, synchronizes-with or happens-before proofs, and join labels are not a data-race guarantee. A fully typed task/async runtime, cancellation-safe async cleanup and scheduler contract remain planned.

Runtime engineering requirements:

- checked allocation arithmetic, alignment and bounds before allocation;
- deterministic release/drop semantics, including partial initialization and exception paths;
- per-thread temporary/cleanup isolation and safe worker shutdown;
- documented allocator ownership and compatible allocate/free pairs across FFI;
- no blocking, locks, allocation, exceptions or unbounded work in real-time audio callbacks;
- CPU atomics must not be confused with GPU memory barriers or `volatile`;
- sanitizer, stress, fault-injection and deterministic concurrency tests for sensitive paths.

Runtime changes are required when semantics need them, but every release must audit Runtime even when no Runtime code change is justified.

## 5. The two API layers

### Cross-platform API: `cross.*`

The same FAC source, exported names, types, ownership behavior, error model and observable semantics must work on every target claimed supported. The portable API may expose fewer advanced capabilities than the native layer. Capability differences must be queried or returned as documented `Option`/`Result`; they must not silently change behavior. It should hide HWND, `FILE*`, `JNIEnv*`, `VkDevice` and equivalent native handles behind opaque portable resources.

### Native API: `native.*`

This layer exposes OS-, architecture-, ABI-, SDK-, driver- and vendor-specific capability. Names and signatures may differ. Every module must declare target triple, OS, CPU architecture, ABI, minimum SDK/OS, linked libraries, handle ownership and unsafe operations. Wrong-target imports must fail at compile time.

**Current reality (unchanged since V58):** `stdlib/cross/` and `stdlib/native/` are reserved namespaces with design documents, not shipped importable APIs. Existing `stdlib/*.fac` modules and old imports remain the compatibility surface. Do not treat a legacy façade as fully portable until its shared behavior suite passes on multiple targets.

## 6. OS, architecture, ABI and GPU standards

The standards inventory in `api/standards.json` is a set of interoperability targets, not proof of implementation. Current planning references:

- OS: Win32/Windows SDK; POSIX.1-2024; Linux-specific libc/kernel interfaces; Darwin/Mach-O/Cocoa/Metal; Android NDK/Bionic/JNI.
- CPU architecture: x86-64 (System V AMD64 vs Microsoft x64 calling convention), AArch64 (AAPCS64 plus platform supplements), RISC-V 64 (ELF psABI), PPC64, s390x and LoongArch64.
- Object/debug formats: ELF, PE/COFF, Mach-O; DWARF on common ELF targets and CodeView/PDB where the Windows toolchain uses it.
- FFI: target C ABI is the external baseline; C++ ABI is not a universal stable boundary; fixed-width C integer types, layout, alignment, string encoding, callback lifetime, ownership, and exception boundaries must be specified.
- Graphics/compute: Vulkan, Direct3D 12, Metal and WebGPU; shader/interchange standards include SPIR-V and WGSL. Current `gpu.fac` is reference/CPU-buffer oriented, not a hardware backend.
- 32-bit and WebAssembly: not supported by the current 64-bit-pointer runtime contract. A target triple or accepted backend option is not sufficient to claim a runnable target.

Platform status is per OS × architecture × ABI × toolchain × runtime combination, not one blanket claim per OS family.

## 7. Standard library and capability roadmap

| Domain | Required functional surface | Required resource/OOP surface | Current V101 reality / caution |
|---|---|---|---|
| Collections | `map`, `filter`, `reduce`, `sort`, `find`, `zip`, `range` | `ArrayList<T>`, `LinkedList<T>`, `Stack<T>`, `Queue<T>`, `HashMap<K,V>`, `HashSet<T>`, trees, graphs, heaps, trie, `Matrix<T>` | Compiler-supported collection syntaxes and existing APIs; audit complexity, invalidation and value ownership before calling the set complete |
| Text / Unicode | split/join/search, UTF-8 encode/decode, normalization, grapheme iteration | builders and regex objects | UTF-8 and regex exist; full Unicode normalization/grapheme shaping is not claimed |
| Error / configuration | `Option`/`Result` combinators, typed config decode/validation | structured `Error`, config resource | `Option`/`Result` core support; wider config layer planned |
| Files / process | path, metadata, env, args, clock, process helpers | `File`, `Directory`, `Process`, watcher resources | existing modules provide partial surface; platform parity and lifecycle need conformance |
| Network / backend | DNS, TCP/UDP, TLS, HTTP, WebSocket, timeout, backpressure | clients/servers, request/response, middleware, DB drivers | net API exists partially; no claim of full production web/backend framework; SQL remains external |
| Audio | PCM conversions, mix, resample, filters, FFT, codecs | `Clip`, `Stream`, devices, mixers | existing audio is early PCM/WAV/reference plus platform-dependent playback; not a complete real-time engine/DAW |
| UI / frontend application | events, accessibility, layout, localization, clipboard, input methods | app/window/widget/theme/render surfaces | UI is canvas/immediate-mode; not a complete native widget toolkit; FAC does not replace HTML/CSS/JS |
| 2D games | input, sprites, tilemaps, animation, collision, asset loading | scene/world/resources | modules exist; validate end-to-end game workflow and platform backends |
| 3D / GPU | geometry, materials, shaders, compute, synchronization | meshes, textures, buffers, device/queue | software/reference capabilities only; hardware graphics/compute is future |
| ML / DL / AI | tensors, dtype/shape/stride, CPU kernels, import/export, tokenization, datasets | model/session/device/execution resources | no full ML framework or CUDA/ROCm/ONNX Runtime claim in V60 |

Stateless transformations should generally be functions. Stateful resources (files, sockets, audio streams, windows, GPU buffers, ML sessions) should generally be explicit owned objects with close/drop and error contracts. All functions/methods must specify ownership, errors, blocking, allocation, thread safety, target availability and cancellation behavior.

## 8. Release gates

A language/API feature is implemented only when grammar, semantic validation, code generation/runtime behavior, diagnostics, tests, specification and compatibility effects are all covered. A platform is supported only after target compiler/runtime build, link/run smoke tests, FFI/ABI checks, sanitizers where available, cross API behavior tests and native API tests. A GPU backend is supported only after device discovery, allocation, queue/barrier/fence semantics, shader validation, resource lifetime, device-loss handling and conformance tests.


## V53 implementation history

V53 introduced local scoped borrow aliases for tracked local/parameter/receiver roots and recognized fields/elements. Mutable borrows from const/untracked roots and global/static roots are rejected. Reborrow from an existing borrow was not supported. Closure bodies were checked under active loans, non-scalar local-borrow alias captures were rejected, and owner reads inside a closure were blocked while a mutable loan was active. V53 loans lasted through the lexical block; V54 added statement-level last-use shortening; V55 adds CFG may-liveness and local reborrowing.

## V55 implementation delta (historical) (previous release)

V55 builds a per-function CFG for local-borrow liveness. A backwards may-liveness fixed point propagates alias uses across branch edges, loop back-edges, switch/match dispatch, structured exits and conservative try/finally routing. Local loans are pruned at CFG program points, so a loan used only on one branch does not automatically block unrelated access on a disjoint branch; a use after a join keeps it live on every incoming path. `defer` and aliases appearing inside `try` regions are pinned conservatively because deferred and per-operation exceptional edges are not fully modeled.

Local alias-to-alias reborrowing is supported. Each child loan records its parent alias/declaration and shares the parent's tracked storage root. Shared children may originate from shared or mutable parents; mutable children require a mutable parent. A mutable parent is suspended until its active child reborrow expires. The liveness sets are name-based and intentionally conservative around shadowing, so some programs may retain loans longer than necessary.

This is CFG-based local-borrow liveness and reborrow tracking, not a complete Rust-style Borrow Checker or full Lifetime Checker. V183 proves disjointness for non-negative literal indexes into fixed-size arrays, but computed/dynamic indexes, list/matrix indexes, pointer/FFI/indirect-call escape proof, reference return/store types, general lifetime parameters, partial moves and whole-program data-race analysis remain incomplete. The local-borrow suite covers branch separation, post-join liveness, shared/mutable reborrows, parent suspension, field/array-element projections and runtime storage aliasing.


## V57 implementation retained through V65

V57 added a per-function lifetime-region tree. Function parameters and the instance receiver use the function root region; each lexical block and loop creates a child region. Local declarations are associated with their storage region. A loan records the region where the alias is declared and the region of its owner; the checker collects an owner-outlives-loan constraint. Reborrowing also adds a parent-region-outlives-child-region constraint. Constraints are solved by checking the ancestor relation in the lexical region tree.

The borrow CFG now has explicit `throw` successors to the nearest catch/outward exception target, conservative exceptional edges for expressions evaluated in protected regions, and routed cleanup edges for `finally`. Catch bodies run with the outer exception context, so a new throw passes through the current try's finally before reaching an outer catch. Finally bodies are built with the enclosing exception context, so a throw from cleanup is not caught by the try whose cleanup is executing. `return`, `break` and `continue` still route through exited finalizers. Because try/catch/finally paths are represented in CFG, local aliases used there are no longer globally pinned; `defer` remains pinned until lexical scope exit.

The exception edges deliberately over-approximate because FAC has no complete per-call `nothrow` effect contract. The local-borrow suite contains 76 positive, negative and runtime cases, including throw/call exceptions, catch/finally last-use release, nested region reborrows and owner writes rejected before exceptional-path uses.

Still incomplete: source-level lifetime parameters, reference returns/stores, interprocedural outlives inference, `defer` execution-edge precision, raw-pointer/FFI escape proofs, field/index-disjoint analysis, partial moves and whole-program static race analysis. These V57 semantics did not require a grammar change; V58 likewise adds pointer-provenance checks without changing source syntax, and the syntax specification records those semantic restrictions.

Validation for that work is recorded in [`STATUS.md`](STATUS.md) and [`STATUS.md`](STATUS.md).

## V55 ownership maturity note (previous release)

Implemented in this release: CFG-based local alias may-liveness, branch/loop fixed-point propagation, local reborrow parent/child relationships and mutable-parent suspension. Still partial: exact declaration-identity NLL, lifetime parameters, reference returns/stores, field-disjoint proofs, raw-pointer/FFI escapes, and static whole-program data-race detection.



## V58 implementation update (retained through V65)

- Bounded stack-pointer provenance for direct `addr()` expressions, keyed by pointer-variable declaration identity.
- Compile-time rejection of returned frame-derived pointers, inner-frame pointer stores into longer-lived pointer variables, aggregate initialization/field/element/global stores, closure capture, and arguments to known retaining collection mutators (`add`, `insert`, `set`, `put`, `push`, `enqueue`, and related operations).
- The V58 local-borrow/escape suite contains 90 cases. V58 introduced pointer-provenance checks; V59 adds parameter-level noescape syntax, so syntax changed but public API/Runtime ABI did not. Direct pointer expressions are traversed, but indirect calls, arbitrary pointer/integer round-trips and untracked aliases remain outside the proof.


## V59 implementation update (retained through V65)

- Added `noescape ptr T name` parameter effects, enforced only when `--strict-ownership` or `--secure` is enabled.
- FAC function bodies are checked for return, storage, closure-capture and unverified-call escapes of a noescape parameter and its tracked local aliases.
- At the V59 release boundary, direct call forwarding used every same-name/same-arity declaration. V65 supersedes that conservative rule when argument types identify a best overload; unknown types or ties still require effect consensus.
- `extern noescape` is an explicit trusted FFI promise and is not verified against foreign code.
- No runtime checks, ABI changes, public stdlib API entries or Runtime source changes were required.
- At the end of V59, `move(local)` was still whole-variable only; V60 below introduces the bounded first-level field subset.

The dedicated noescape suite contains 17 positive/negative/runtime/profile checks; the V61 pointer-effect suite additionally covers readonly, interface contracts and override preservation. See [`NOESCAPE_CONTRACTS.md`](NOESCAPE_CONTRACTS.md), [`STATUS.md`](STATUS.md) and [`STATUS.md`](STATUS.md).


## V60 implementation update — bounded partial field move

V60 supports `move(record.field)` for the direct first-level managed leaf fields of a local mutable value `struct`. The checker resolves the owner declaration identity and the field identity, marks the field moved, and marks the aggregate as partially moved. Reads of the moved field, repeated moves, whole-aggregate use, method calls on the aggregate, and closure/defer use of the aggregate are rejected while the partial state remains. Assigning a new value to the moved field clears that field state; once no moved fields remain the whole aggregate becomes usable again. CFG joins union the moved-field facts, while loop back-edges permit a move only when the field is reinitialized before the next iteration.

Code generation moves the existing managed leaf handle out of the struct field and stores null in the source slot. This is safe for the supported string/list/data-structure/function/object/weak-object drop routines because they accept null. The temporary cleanup stack assumes ownership of the moved handle, so an exception during later expression evaluation does not leak it. The struct's ordinary drop helper can then release remaining fields and safely ignore the null moved field. This is not general field-drop flags: nested structs/enums/arrays/classes, scalar/raw pointer fields, direct nested paths, heap/indirect roots and parameters are rejected. FAC `ptr T` remains an unmanaged raw pointer. Borrow analysis still treats sibling fields as potentially aliasing.

The focused partial-move suite contains 15 tests. No Runtime source changes or public API entries were needed.


## V62 implementation delta

V62 adds projection-aware loans for distinct direct first-level fields of the same resolved owner declaration. It permits disjoint mutable/shared local borrows, sibling-field owner access and disjoint sibling reborrows. Whole-root, same-field, nested, indexed, dereferenced and computed paths remain conservative. The pass is not a general alias analysis and does not prove disjointness for overlapping/union layouts.

V62 adds the independent `readonly ptr T` parameter effect. It promises no writes through the pointee; `noescape` continues to promise no retention beyond the call. Combined `readonly noescape ptr T` expresses synchronous read-only access. FAC bodies are checked under strict ownership; extern annotations are trusted FFI promises. Abstract/interface contracts are accepted and concrete overrides/implementations may not weaken them. V65 resolves direct-call `ref`/`noescape`/`readonly` effects against known argument types; unknown-type and ambiguous calls remain fail-closed. V64 carries function-type effects; indirect-call target verification remains conservative. See [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).


## V63 implementation delta — nested partial move and per-projection drop state

V63 extends `move()` to metadata-validated named field paths rooted at a local mutable value `struct`, including nested paths such as `move(record.inner.payload)`. A final field may be a managed handle (string/list/data-structure/function/object/weak object) or a managed value struct. Every intermediate path segment must be a value struct; classes/interfaces, objects as intermediate receivers, parameters, `self`, borrow aliases, globals, heap/indirect storage, scalar fields, arrays/indexes, enum payloads and raw pointers are rejected.

The CFG move checker identifies a projection by `(root declaration identity, dotted field path)`. Equal and prefix/descendant projections overlap; sibling paths do not. A moved projection blocks reads of that path and containing/contained aggregates while leaving disjoint siblings usable. Reinitializing the exact path clears that move; assigning a containing subaggregate clears moved descendants after its old value is safely dropped. Branch joins conservatively union moved-path facts. Lambda/defer capture and aggregate method calls remain conservative while a root or receiver subtree is partially moved.

Code generation transfers managed handles by loading and nulling the exact field. Moving a managed value struct copies it into an owned temporary and zeroes the source field. Existing recursive `drop.Struct` helpers release remaining live managed fields and safely traverse null/zero sentinels, including nested structs. The existing Runtime cleanup stack owns the moved temporary and the root cleanup entry remains registered; this preserves exception cleanup without new Runtime functions, ABI changes or public API entries. This is a bounded per-projection state scheme, not a general bitmap/drop-flag implementation for arrays, unions, enums, partially initialized arbitrary objects or user-defined resource fields.

New regression tests cover nested leaf moves, moving a nested struct as a unit, disjoint sibling moves, reinitialization, use-after-move, overlapping/repeated moves, method access on a partially moved subaggregate and exception unwind. Runtime source remains unchanged because the existing aggregate drop callbacks and cleanup stack already support the zero/null sentinel model.


## V65 implementation delta — overload-aware ownership effects

V65 stores each overload's parameter types together with its `ref` mode and pointer effects. Static call analysis filters candidates using known argument types, including exact pointer pointee matches, then applies the selected candidate's noescape/readonly/ref guarantees. The code generator also ranks exact pointer-pointee overloads above generic pointer-compatible candidates. Unknown argument types and unresolved ties remain conservative: all arity-compatible candidates must satisfy the effect. The proof remains limited to direct calls with statically known type information; indirect calls, general type inference, full virtual-dispatch target resolution and whole-program data-race proof remain unimplemented.


## V66 implementation delta — typed concurrency effect summaries

V66 adds compiler-internal per-storage effect summaries to the `--safe` worker-closure call-graph scan. For mutable globals reachable through statically followed calls, the checker records ordinary reads, writes, address/alias exposure, and atomic read/write operations separately. It also records mutex lock acquire/release operations and associates the active lexical lock set with direct global accesses. A balanced mutex handle used only by `mutex.lock`/`mutex.unlock` is treated as a synchronization primitive rather than ordinary shared payload.

These summaries improve diagnostics and provide typed inputs for a future race analysis; they do **not** prove that all accesses to a storage location use the same lock, do not build an atomic happens-before graph, and do not certify FFI/trusted Runtime/stdlib effects. A mutable global access still fails `--safe`, including an access observed while a lock is held or marked atomic, because the current pass cannot prove that every other access is synchronized. Indirect calls remain subject to the existing `--strict-safe` rule. No new FAC syntax, public API, Runtime source, or ABI was added.

## V64 implementation delta — effect-aware function values

Function-value signatures preserve per-parameter `noescape` and `readonly` effects for explicit function types, named function values, and lambda values. Function compatibility checks result and parameter types (including pointer pointee types) and applies effect guarantees monotonically: an implementation may promise stronger effects than required, but may not weaken a required effect. Function values passed to typed callback parameters are checked by the same rule. These effects are compile-time metadata and do not alter closure layout or ABI. Calls through indirect function values still fail closed for stack-derived pointer escape analysis because the checker does not yet prove the concrete target body.


## V67 implementation delta — lock-aware concurrency summaries

V67 propagates the syntactically held mutex context from a direct call site into a statically followed callee. A callee must return with the same held-lock set it received; an acquire/release imbalance is rejected. For each mutable global, the summary keeps the union of observed lock identities and the intersection common to every ordinary read/write access, and separately records any unprotected ordinary access. Global lock identities are module-qualified; local lock handles are scoped to the analyzed function body. Parameter/local shadowing, unsupported mutex expressions, loop lock-state changes and try-region lock operations fail closed. Branch joins retain only locks held on every analyzed branch.

This remains diagnostic evidence, not permission to share mutable globals in `--safe`: all mutable global payload access is still rejected. The analysis does not prove every access in the entire program, pointer alias equivalence, FFI/trusted implementation effects, lock fairness/deadlock freedom, or atomic happens-before. No source syntax, public API, Runtime source or ABI changed.


## V68 implementation delta — atomic memory-order summaries

V68 records per-storage atomic read-side and write-side order sets for statically recognized `thread.atomic*` operations. It distinguishes Acquire RMW (`read=acquire`, `write=relaxed`) from Release RMW (`read=relaxed`, `write=release`) and records compare-exchange failure order separately. The legacy atomic names remain SeqCst; explicit `*SeqCst` names are additive source aliases to the same Runtime symbols. Diagnostics identify mixed ordinary/atomic access and release/acquire-capable effects, but do not claim a synchronizes-with or happens-before edge without proving the acquire read-from relation. Mutable global payloads remain rejected by `--safe`.

## V68 validation evidence

On Linux x86_64, GCC and Clang C++17 `-O0` clean builds passed. Main regression was 120/120 at FAC `-O0` and `-O2`; atomic-order runtime cases were 2/2 at both levels; safe profile 228/228; negative 124/124; limits 15/15; ownership, borrow, effect, move, comptime and Runtime suites passed; API, tooling (69/69), docs and format checks passed. API compatibility is 0 breaking / 0 warning / 4 additive SeqCst aliases. Sanitizer/ThreadSanitizer and cross-platform builds were not run. These test results validate the bounded implementation, not a whole-program race-freedom guarantee.



## V76 implementation delta — interprocedural value-struct parameter lifecycle summaries

V76 adds a bounded per-field summary for eligible free functions whose parameters are value structs containing direct or nested `ptr thread` fields. Calls are followed only when the function target and actual struct type are uniquely resolvable in the current module/import scope. A helper may join a parameter field directly or pass that field to a uniquely summarized `ptr thread` helper; the resulting `must-join`, conditional, may-outlive or unknown effect is applied to the caller's corresponding dotted path. This supports nested fields and existing explicit `move(aggregate)` arguments without adding syntax. A repeated helper join is detected as unknown after the first join.

This is a lifecycle-effect summary, not a general borrow/ownership contract: aggregate returns, assignments/aliases, lambda captures, unresolved or overloaded targets, recursive aggregate forwarding, method/dynamic calls and FFI remain unknown. No struct return transfer is inferred. The existing strict-move checker remains responsible for explicit move validity; raw `ptr thread` field partial moves remain unsupported. `--safe` rules are unchanged. No Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed.

## V75 implementation delta — local struct-field thread-handle lifecycle

V75 tracks direct and nested `ptr thread` fields in local value structs as dotted storage paths. Direct `thread.start` assignments to fields, `thread.join(field)`, and unique direct helper calls receiving the field are connected to the existing live/joined flow lattice. Copies of handle fields/containing structs, aggregate parameter or return escapes without a field-aware summary, untracked destinations, duplicate/shadowed paths and unresolved aliases become unknown rather than being treated as safe ownership moves. The analysis does not cover class/object fields, arrays/index paths, struct parameter/return summaries, arbitrary pointers, indirect calls, FFI or general exception CFG paths. It does not weaken `--safe` or prove data-race freedom. No source syntax, API, Runtime source or ABI changed.

## V75 validation evidence

See `docs/STATUS.md` for exact test and ZIP smoke results.

## V73 implementation delta — interprocedural thread-handle join summaries (historical)

V73 adds bounded parameter-effect summaries for direct free-function calls that receive a tracked `ptr thread`. A summary distinguishes a handle joined on every modeled exit, a branch-dependent join, a handle left live without consumption, and unknown/escaped behavior. Summaries are propagated through a bounded iterative pass so wrapper/helper chains can forward join behavior across same-module and explicitly imported or module-qualified calls. The resolver filters candidate overloads using the tracked argument's formal `ptr thread` type and requires one unique candidate after filtering.

Methods, virtual dispatch, function-value calls, unresolved module aliases, arbitrary pointer aliases, handle return/store, foreign calls and recursive/non-convergent summaries remain unknown. This is an interprocedural parameter effect, not a complete thread-handle ownership model and not a happens-before or data-race-freedom proof. `--safe` remains unchanged and continues rejecting mutable global payloads where existing rules require it.

V73 introduced no syntax change and no API change. In particular, no Cross-Platform API was added or modified, and no native/platform-specific API was implemented or expanded. Runtime source and ABI are unchanged.

## V73 validation evidence (historical)

Exact build/test results and ZIP qualification limits are recorded in `docs/STATUS.md`.

## V72 implementation delta — worker multiplicity and join-aware lifecycle (historical)

V72 extends the V71 whole-program worker registry with two bounded lifecycle facts. First, each direct launch site is classified as per-activation (`thread.start` outside a syntactically repeating loop), loop-repeatable (`thread.start` in a loop condition/body/step), or parallel-replicated (`thread.parallelFor`, whose Runtime creates multiple worker threads when the workload and hardware permit). Per-activation is not a process-wide exact count: callers may invoke the containing function repeatedly, and recursion, indirect calls and dynamic dispatch are not solved by this pass.

Second, direct local `ptr thread name = thread.start(lambda)` handles are tracked through structured blocks, `if` branches, bounded loops, switch/match branches and function exits. The summary distinguishes `must-join` on all modeled exits, `may-outlive`, `conditional`, `unknown` (including handle escape to another function or unsupported exceptional/defer control flow), `untracked` (no direct local handle binding), and `runtime-joined` for `thread.parallelFor`. The Runtime implementation joins all threads created by `parallelFor` before the API returns; this is a Runtime lifecycle fact, not a proof that callback memory accesses are race-free. The pass does not infer interprocedural handle ownership, parameter/return transfer, aliasing, cancellation, detach semantics or arbitrary CFG paths.

The registry continues to emit candidate-only cross-worker atomic and ordinary-conflict relations. `--safe` continues rejecting mutable global payloads; lifecycle classifications do not weaken that policy. V72 adds no FAC syntax, public API, Runtime source or ABI change.

## V72 validation evidence

See `docs/STATUS.md` for exact build/test evidence and qualification limits.

## V71 implementation delta — whole-program worker registry and cross-worker candidate graph

V71 collects statically visible direct `thread.start` and `thread.parallelFor` callback sites from loaded function and method bodies, module global initializers and static-field initializers. It scans direct lambda callbacks with the existing bounded direct-call analysis and retains unsupported callback forms or scan failures as unresolved registry entries. The inventory is conservative over loaded source and is not limited to dynamically reachable functions.

Each worker effect is keyed by the declaring module and global name, so unqualified imported globals and explicit `module.global` / import-alias references resolve to the same canonical storage. The graph reports shared storages, cross-worker atomic modification/read candidates, Release-Acquire and CAS-failure-Acquire subsets, possible ordinary read/write conflict pairs, and same-template `parallelFor` replication candidates. The `unresolved-sites` count is separate from known mutable-global diagnostics and partial known effects remain visible.

These remain may-candidates. Static AST sites are not runtime thread IDs; this release does not prove repeated `thread.start` execution count, overlapping lifetimes, joins, actual read-from values, modification order, release sequences, synchronizes-with/happens-before, arbitrary pointer aliases, dynamic dispatch or FFI/trusted-code effects. Mutable global payload access remains rejected under `--safe`. No source syntax, public API, Runtime source or ABI changed.

## V71 validation evidence

Linux x86_64: GCC and Clang C++17 `-O0` clean builds passed. GCC-host main regression passed 120/120 at `-O0` and `-O2`; Clang-host main regression passed 120/120 at `-O0`. Safe suite passed 255/255 on both compiler hosts. Negative 124/124, limits 15/15, ownership/borrow/effect suites, move 20/20, partial move 23/23, comptime 7/7, Runtime regression, Java-style entry 10/10 at both modes, tooling 69/69 and API/standards/docs/format/version checks passed. API compatibility against V63 baseline: 0 breaking, 0 warning, 4 existing V68 SeqCst aliases. Sanitizers, ThreadSanitizer, cross-OS and compiler-host `-O2` qualification were not run. These tests validate the bounded static inventory and diagnostics, not whole-program race freedom.

## V70 implementation delta — static atomic synchronization graph candidates

V70 records a node for each statically recognized atomic call site on a resolved global storage reachable from one checked worker closure and its followed direct-call graph. Nodes retain operation name, source line, read order, write order and compare-exchange failure order. Distinct Release-capable and Acquire-capable nodes on the same storage produce directed candidate edges; Acquire failure ordering on compare-exchange is included. SeqCst node pairs are counted separately. Call-site identities are deduplicated when helper traversal reaches the same AST site more than once.

The graph is a bounded diagnostic candidate graph, not a cross-thread synchronization proof. It does not prove that an acquire reads from a release or release sequence, enumerate peer worker executions, or establish arbitrary pointer alias equivalence. Diagnostics state `candidate edges only; read-from/thread identity unresolved`; mutable global payloads remain rejected by `--safe`. No source syntax, public API, Runtime source or ABI changed.

## V70 validation evidence

Validation is recorded in `docs/STATUS.md`. The new safe tests verify a Release-store/Acquire-load candidate edge, a SeqCst pair, an Acquire compare-exchange failure-order candidate, and call-site deduplication when a helper is reached under distinct lock contexts while preserving fail-closed rejection.


## V70 implementation delta — read-from and release-sequence candidates

Each event now records whether it reads, modifies, or performs an RMW on its resolved storage, plus the checked worker-closure template and direct-call path. For each pair of distinct events on one storage, the pass creates a may-read-from candidate from a modification to a read. It separately counts Release-to-Acquire candidates and Acquire compare-exchange failure candidates. If a third RMW event exists, it records a possible RMW bridge candidate between those endpoints; it does not assert that the RMW is actually ordered between them. Deduplication is scoped by `(worker template, AST call site)`.

This is still a conservative diagnostic graph, not a C++/FAC modification-order or synchronizes-with proof. The compiler does not resolve runtime values, assign actual read-from sources, enumerate runtime thread instances, prove release-sequence membership or arbitrary pointer aliases. `--safe` continues rejecting mutable global payload access. V70 adds no FAC syntax, public API, Runtime source or ABI changes.


## V75 implementation delta — explicit whole-aggregate move transfer

V75 recognizes existing `move(sourceAggregate)` syntax when moving a managed local value struct containing tracked direct/nested `ptr thread` fields. The lifecycle state moves to the destination projections and the worker launch path is rebound through explicit move assignments/declarations. Plain copies remain unknown. The feature does not enable raw `ptr thread` leaf-field partial moves, struct parameter/return contracts, class/object fields, arrays or arbitrary pointer aliases. It does not prove runtime scheduling, happens-before or data-race freedom, and does not relax `--safe`. No Cross-Platform API, native API, stdlib declaration, Runtime source or ABI changed.

## V78 implementation delta — fixed-point struct thread-handle forwarding

V78 replaces V77's whole-set fixed-point scan (at most 32 rounds) with a reverse-dependency worklist over eligible free functions. A helper can forward a whole tracked value struct or a nested struct field to another uniquely resolved free function; when a callee summary changes, only its callers are re-analyzed. A 40-helper imported chain verifies convergence beyond the old round cap. If the deterministic analysis budget is exhausted, all partial aggregate summaries reset to `unknown`. The existing nested dotted field mapping is retained.

The escape scan treats only a syntactically rooted aggregate argument and a uniquely resolved matching struct-helper target as a recognized forward. Unresolved targets, ambiguous overloads, recursive cycles that do not converge, aliases, returns/stores, methods/dynamic calls, captures and FFI remain unknown. A recursive fixture confirms that a branch that joins on one path but recursively forwards on another does not become `must-join`. This is still a bounded lifecycle summary, not general interprocedural ownership, borrow checking, happens-before or data-race proof. No syntax, Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed.


## V84 implementation delta — direct unary scalar-literal type facts

V84 extends the bounded struct-helper overload resolver to recognize the exact type of a single unary operation applied directly to a supported scalar literal. Logical negation (`!`) of a numeric/boolean literal is known as `boolean`; unary plus/minus on a direct integer or floating literal retains that literal's numeric type; bitwise complement (`~`) on a direct integer literal uses the language's normal integer promotion. These facts feed the existing `scoreArg` overload ranking and apply only to lifecycle-summary candidate selection.

Nested unary expressions, identifier operands, casts, binary/computed expressions, function calls, member paths, globals, strings/null in `auto`, and unresolved or tied candidates remain unknown. This is not general expression type inference, constant evaluation or an ownership/lifetime/happens-before/race proof. No grammar, API, Standard Library declaration, Runtime source or ABI changed; no safety flag was weakened.

## V83 implementation delta — scalar `auto` value-copy facts

V83 extends the bounded call-site resolver so a local `var auto` initialized directly from a previously-known scalar identifier may reuse that identifier's proven primitive type. This includes explicitly declared primitive locals/parameters and earlier `auto` locals whose type was established from an eligible scalar literal or another eligible value-copy. Resolution occurs before installing the new declaration, so the initializer reads the binding visible at that exact point; normal lexical shadowing and block exit continue to apply.

Only a simple identifier initializer is eligible. This is a primitive value copy, not an alias. Calls (including boolean-returning calls), operators, casts, member paths, globals, unsupported/inferred source declarations, ambiguous bindings and unknown source values remain unknown. This is not general `auto` inference, ownership transfer, borrow/lifetime proof, happens-before proof or data-race freedom. No syntax, API, Standard Library declaration, Runtime source or ABI changed; `--safe` acceptance rules are unchanged.

## V82 implementation delta — literal-initialized `auto` overload facts

V82 extends V81's call-site lexical binding resolver to recognize a local `var auto` declaration only when its initializer is a direct scalar literal with an exact compiler-known type (integer, floating-point, boolean, character or Unicode character). The binding is installed only after evaluating the initializer and remains subject to ordinary lexical shadowing. It reuses the existing literal typing and `scoreArg` overload ranking; no separate conversion or ranking rules are introduced.

An `auto` initialized by a call, operator, cast, alias or other computed expression remains unknown even when a human can infer its eventual type. String/null literals are not admitted as `auto` scalar facts by this bounded pass. This is not general type inference and changes no FAC syntax, API, Runtime source or ABI.

## V81 implementation delta — declared-identifier struct-helper overloads

V81 extends V79's struct-helper overload resolver from literal arguments to simple identifiers with explicit primitive declarations. The analyzer gathers the matching function parameter and local declaration types in the owning function, and uses the normal `scoreArg` ranking only when every matching declaration is a supported primitive type and all such types are identical. This safely covers common `var boolean flag` and `var int mode` arguments without relying on code-generation scope or guessing from expression values.

Conflicting declarations (including different-typed shadow declarations), inferred or dynamic types, globals, member paths, operators, calls, indirect calls and unresolved candidates remain unknown. This is still a bounded thread-handle lifecycle summary, not a general type-inference engine, ownership/borrow contract, happens-before proof or data-race guarantee. No grammar, Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed; `--safe` acceptance rules are unchanged.

## V79 implementation delta (historical) — literal-aware struct-helper overloads

V79 augments the V78 dependency-worklist resolver with literal argument typing and the same `scoreArg` viability/score used by ordinary overload resolution. This allows the analyzer to pick a uniquely best struct-helper overload when non-struct arguments are known literals. If every argument is known, it uses the unique highest score; if some expressions are unknown, it only removes impossible candidates and retains unresolved ties as `unknown`. Identifiers, computed expressions, indirect calls, aliases, recursive forwarding, returns/stores and FFI are not upgraded by this release. This remains lifecycle-effect analysis, not a general interprocedural ownership or borrowing proof. No syntax, Cross-Platform API, native/platform-specific API, stdlib declaration, Runtime source or ABI changed.


## V85 implementation delta — recursive unary scalar-literal type facts

V85 extends V84's unary literal rule recursively across unary AST nodes. Each operator is validated against the resolved operand type, including boolean logical negation, numeric unary plus/minus and integer promotion for bitwise complement. For example, `!!false` resolves to boolean and `-~1` resolves to an integer type. The analysis still rejects identifiers, function calls, casts, binary/computed expressions and unsupported operators as unknown. This remains bounded argument-type evidence for existing helper overload ranking, not general expression inference or constant evaluation.


## V86 implementation delta — explicit primitive-cast type facts

V86 extends the bounded struct-helper overload resolver to recognize the result type of the existing `cast(Type, value)` form when `Type` is an explicitly named built-in primitive type (`Byte`, `Short`, `Int`, `Long`, unsigned integer variants, `Float`, `Double`, `Boolean`, `Char`, `Unichar` or `String`). This is a result-type fact supplied by the cast's explicit target, not inference from the value expression. It also applies when such a cast initializes a supported scalar `auto` local, and nested casts are recognized. The existing `scoreArg` continues to decide candidate compatibility and ranking.

Arbitrary calls, class/enum casts, identifiers without a supported declaration fact, binary/computed expressions, aliases and unresolved/tied overloads remain unknown. The rule is used only for the existing bounded thread-handle lifecycle helper summaries; it is not general expression inference, constant evaluation, ownership transfer, a happens-before proof or a data-race guarantee. No grammar, public API, Standard Library declaration, Runtime source/ABI or safety acceptance rule changed.


## V87 implementation delta — fixed-result `str(...)` type facts

V88 extends the bounded struct-helper overload resolver to recognize the fixed `String` result type of a direct built-in `str(value)` expression. This allows the existing `scoreArg` ranking to select a `string` helper overload without guessing the type of the `str` argument. Ordinary user-defined function calls, unsupported `auto` string initializers, computed expressions and unresolved overload ties remain unknown. The analyzer does not infer arbitrary call return types and does not alter ownership or lifetime rules.


## V88 implementation delta — fixed-result scalar built-in facts

V88 recognizes the explicit result type of `parse(Type, value)` for supported numeric/boolean targets, plus `Int` results from `size(...)`, `sizeof(...)` and `strcmp(...)`. These facts are used only by the existing struct-helper overload ranking and can flow through supported scalar `var auto` initializers. Source text and argument values are not evaluated; arbitrary user-defined calls and unsupported expressions remain unknown.

## V89 implementation delta — scalar result facts from the existing built-in API table

V89 reuses the return-code contract of existing built-in API-table entries when a direct call's canonical path and argument count match. Only scalar result codes are admitted (`Int`, `Long`, `ULong`, `UInt`, `Unichar`, `Double`, `Boolean` and `String`). Value-dependent (`random.int`), void, pointer and list result codes remain unknown. Fixed-result runtime built-ins `terminal.in.readline`/`readLine`, `cstr`, `memory.weakAlive`, `memory.sizeof`, `find` and `type` are also recognized. The test covers `string.length`, `string.contains`, `time.nowSec`, `crypto.crc32` and `string.upper`, while a user-defined function and `random.int` remain unknown. Existing `scoreArg` ranking and `--safe` acceptance rules are unchanged.


## V90 implementation delta — bounded `random.int` result facts

V90 recognizes the existing `random.int(min, max)` result rule for the integer-only cases whose source argument types are proven. It reports `Int` when both known integer arguments are at most 32 bits wide and `Long` when either known integer argument is wider than 32 bits, matching the compiler's existing `tableCall()` rule. The same fact works for direct literal/unary arguments, explicit scalar identifiers visible at the call site, and eligible literal-backed `var auto` initializers.

Calls whose argument type comes from an arbitrary user-defined function, floating-point arguments, unresolved identifiers and other unsupported forms remain unknown. The analyzer does not execute calls, inspect numeric values, or infer general function returns. The change only affects the existing `scoreArg` ranking for bounded worker-lifecycle helper summaries; it does not change syntax, APIs, Runtime, ABI, ownership rules or `--safe` acceptance.


## V92 implementation delta — `random.int` result facts through `auto` value copies

V92 extends the bounded worker-lifecycle overload analyzer so a local `var auto` initialized by `random.int(min, max)` can retain its existing `Int`/`Long` result contract when each bound is either an exact supported scalar expression or an identifier whose primitive type is already proven in the lexical scope at the declaration. A later `auto` value-copy may reuse that established scalar result type. An argument derived from an arbitrary function call, a computed expression, an unsupported declaration or an unresolved identifier remains unknown.

The change only feeds exact facts into the existing `scoreArg` overload ranking; it does not add general expression inference or change `random.int` code generation. No grammar, public API, Cross-Platform API, native/platform-specific API, Standard Library declaration, Runtime source/ABI, ownership rule or `--safe` acceptance rule changed.


## V92 implementation delta

The compiler's bounded worker-lifecycle struct-helper overload resolver now recognizes the existing numeric result rules for `math.abs`, `math.min` and `math.max` when each operand is an exact scalar value or a visible lexical scalar identifier with a proven numeric type. `math.abs` uses the same `promote` rule as code generation; `math.min` and `math.max` use the same `commonT` rule. Unknown calls and computed/unresolved operands remain unknown. This is not general expression inference and does not change the implementation of these math functions.


## V93 implementation delta — bounded lexer token budget

V93 limits each lexed source unit to 1,000,000 emitted tokens. The compiler already limits an individual source file to 64 MiB and guards parser nesting/operator-chain depth; the token ceiling closes a separate resource-exhaustion path where a relatively small source can contain an extreme number of short tokens. Exceeding the ceiling raises a normal source diagnostic before parser/AST construction continues. The limit is enforced in the lexer and does not alter valid programs below the ceiling. `tests/run_limits.sh` includes a 1,000,001-token rejection case.

This is a compiler resource guard, not a FAC language syntax or type-system change. No public API, Cross-Platform API, native/platform-specific API, Standard Library declaration, Runtime source/ABI, ownership rule or `--safe` acceptance rule changed.


## V98 numerical / ML library expansion

V98 extends the V97 portable CPU numerical foundation with 54 new built-in API names. `tensor` adds row/column extraction, concatenation, dot product, axis reductions, elementwise math and clipping. `data` adds column removal, one-hot encoding and seeded train/test split handles. `stats` adds IQR, median absolute deviation, skewness and excess kurtosis. `metrics` adds specificity, balanced accuracy, MAPE, maximum/median absolute error and binary log loss. `ml` adds ridge regression and k-nearest-neighbor classification. `nn` adds Leaky ReLU, ELU, GELU and Softplus, including explicit backward operations. `optim` adds Momentum, RMSProp and gradient clipping. The portable `math` module adds finite checks, angle conversion, smoothstep and range wrapping.

Tensor storage is row-major float64 and limited to 16,777,216 elements per tensor. The new implementations execute on CPU. CSV parsing remains numeric and headerless; kNN uses numeric class labels; neural-network training remains explicit manual backpropagation rather than automatic differentiation. No GPU acceleration, automatic differentiation engine, convolution, Transformer, graph serialization or complete deep-learning trainer is claimed. API contracts are cross-platform, but a shared cross-OS conformance run is still required before claiming validated parity. No native/platform-specific APIs were added.


## V99 DataFrame and automatic differentiation

V99 adds `dataframe` as an owned numeric table abstraction. A DataFrame stores finite float64 values in row-major order and unique pipe-delimited column names. It supports named column lookup, selection, drop, row filtering, stable sorting, head/tail slices, row concatenation, per-column mean/min/max/population standard deviation and conversion to/from Tensor or numeric CSV. The current implementation does not support string/null cells, schema inference, joins, group-by, SQL or streaming ingestion. Concatenation is bounded to the same 16,777,216-element ceiling used by Tensor.

V99 adds `autograd` as a scalar reverse-mode tape. The tape stores a directed acyclic graph in node-creation order and supports arithmetic, selected scalar math/activations, backward propagation and gradients. Node IDs are local to one tape and are valid only while it lives. Each backward pass resets gradients before propagation; `backwardSeed` supplies a custom scalar seed. A tape is bounded to 1,048,576 nodes and a backward pass commits gradients only after all propagated values remain finite. This is not tensor-wide automatic differentiation, an optimizing graph compiler, a complete training loop or GPU autograd.

Both features are CPU implementations and require external synchronization when a mutable handle is shared between threads. No native/platform-specific API or GPU acceleration is introduced.


## V100 Tensor Autograd, DataFrame analytics and GPU compute abstraction

V100 extends V99 with CPU float64 tensor reverse-mode automatic differentiation. Each tape node stores a tensor value and gradient and supports exact-shape elementwise add/subtract/Hadamard, matrix multiplication, scalar scaling, sum/mean reduction, ReLU, sigmoid and tanh. A backward target must have exactly one element; callers normally reduce with sum or mean. Tensor values and gradients are returned as owned Tensor handles. Each tape is bounded to 65,536 nodes and 16,777,216 stored value elements (gradient storage is additional). This remains a CPU eager tape, not graph compilation or a full training engine; it can supply gradients to existing optimizers such as SGD.

DataFrame now includes derived-column and rename copy operations, median, population variance, interpolated quantile, and grouped mean/sum/min/max/count. Group keys are numeric exact-value keys and output groups are ascending; DataFrames remain numeric float64 only, without nullable/mixed-type cells, SQL joins or streaming ingestion.

The GPU-oriented buffer API exposes little-endian IEEE-754 float64 read/write and add/subtract/multiply/scale/matmul dispatch. V170 executes all float64 numeric buffer operations on the CPU, using SIMD where supported and a portable scalar fallback. Native GPU device loading and dispatch are not included in the current Runtime.
