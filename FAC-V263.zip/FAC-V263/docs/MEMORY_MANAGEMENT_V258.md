# FAC Memory Management — V258

## Nested match-binding shadowing in auto-return provenance checks

V258 corrects the name-scope handling in the bounded strict-ownership check for
`auto` functions that return result-producing `match` expressions. Before
classifying an inner match payload binding, the checker now removes any
same-named pointer-capability fact inherited from an outer match branch. It
then classifies the inner binding from that branch's own enum payload metadata.

This respects lexical pattern-binding shadowing:

- A known scalar inner payload that reuses an outer pointer-binding name is
  treated as a scalar, so a scalar return is not rejected because of the outer
  binding.
- A raw-pointer inner payload that reuses an outer scalar-binding name is
  still considered pointer-capable and its return is rejected when provenance
  is not tracked.
- Unknown, generic or ambiguous payload layouts remain conservative.
- `_` remains a wildcard and does not shadow a named binding.

This is a precision correction to the existing fail-closed enum payload guard.
It does not add enum-payload pointer provenance, general borrow checking,
`ref T` return inference, or whole-program heap escape analysis. It does not
change source syntax, Runtime behavior, ARC/GC, public API, ABI or the
`--memory-safe` accepted subset.

## Validation

- V258 compiler build: Clang 17, C++17, frontend `-O0 -g0`; Runtime object
  compiled with Clang 17 C++17 `-O2`.
- Lifetime regressions: 130 PASS, including both V258 shadowing directions.
- Ownership: 261 checks; Secure Profile: 6/6; `--memory-safe`: 39/39.
- Move: 20/20; Partial Move: 28/28; Compile-time/const-generic: 57/57.
- Lexer: 18 checks; Parser: 68 checks plus AST model 1/1; Codegen checks passed;
  Generic specialization: 3/3.
- Semantic suite exited successfully; ancestry model reported 17 checks passed.
- Runtime regression script exited 0 and completed all its cases.
- Tools: 91/91; formatter passed; Standards check passed for 5 OS families and
  6 architecture families.
- API audit: 663 built-ins and 1,014 source declarations; 5 findings, 0 new
  findings beyond baseline. Strict contract audit: 950 public source
  functions, 0 missing required annotations. Compatibility against V128:
  0 breaking changes, 132 warnings.
- `tools/check_versions.py` passed; all six public components report V258.

- Legacy output matrix: 132/132 at `-O0` and 132/132 at `-O2`; Negative
  134/134; Limits 21/21.
- Safe-profile integration: 433 passed, 4 failed; the same 4 failures reproduce
  with the V257 baseline compiler and are not V258 regressions.

The four existing Safe-profile failures remain unresolved. Full CMake/CTest,
ASan/UBSan/TSan, Windows/macOS qualification and production qualification are
not claimed.
