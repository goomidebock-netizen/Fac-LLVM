# FAC Standard Library Architecture — V53

## 1. Rules for every public API

Every public function and method must specify:

- parameter and return types;
- whether parameters are copied, borrowed immutably, borrowed mutably, or consumed;
- whether the return value is owned or borrowed;
- expected errors and error codes;
- whether it blocks, allocates, performs I/O, or calls native code;
- thread-safety and synchronization requirements;
- supported OS/architecture/backend and fallback behavior;
- cancellation and resource cleanup behavior for long-running operations.

Functions should use lowerCamelCase and types/classes UpperCamelCase. Prefer `Result<T, E>` for expected I/O/device/network failures. Prefer classes for stateful resources and free functions for stateless transformations.

## 2. Core language-adjacent libraries

| Module family | Functional APIs | Resource/OOP APIs | Priority |
|---|---|---|---|
| Collections | `array`, `sort`, `find`, `map`, `filter`, `reduce`, `zip`, `range` | `ArrayList<T>`, `LinkedList<T>`, `Stack<T>`, `Queue<T>`, `HashMap<K,V>`, `HashSet<T>`, `TreeMap`, `Graph`, `Heap`, `Trie`, `Matrix<T>` | High |
| Text / Unicode | UTF-8 encode/decode, search, split/join, normalization, grapheme iteration | `TextBuilder`, `Regex` | High |
| Error/result | `Option.map`, `Option.andThen`, `Result.map`, `mapError`, `andThen`, `orElse`, `unwrapOr` | `Error` value with stable codes | High |
| Filesystem | path normalization, metadata, read/write helpers | `File`, `Directory`, `FileWatcher` | High |
| Process / system | env, arguments, exit, clocks | `Process`, `Environment` | Medium |
| Concurrency | atomics, channel, select, timeout helpers | `Mutex`, `RwLock`, `Semaphore`, `Task`, `ThreadPool` | High |

All collection APIs must state iterator invalidation, complexity, allocation behavior, equality/hash requirements, and mutation safety. Matrix should support explicit row/column dimensions, with checked multiplication before allocation.

## 3. Application, backend and networking

- `net`: DNS, TCP, UDP, TLS, HTTP client/server, WebSocket, cancellation, timeouts and backpressure.
- `backend`: routing, middleware, request/response, JSON serialization, authentication hooks and database connector interfaces. Database wire protocols remain drivers; FAC does not replace SQL.
- `crypto`: standards-based primitives through vetted implementations; no home-grown production cryptography. Key material ownership and zeroization must be explicit.
- `config`: TOML/JSON/environment loading and typed validation.
- `logging`: structured levels, spans, sinks and redaction controls.

## 4. UI and frontend-oriented application code

FAC UI target is native desktop/mobile/application UI, not a claim that it replaces HTML/CSS/JavaScript. Provide:

- `ui.Window`, `ui.App`, `ui.Widget`, `ui.Layout`, `ui.Theme`;
- event handling with typed events and deterministic ownership;
- accessibility tree/semantics, keyboard navigation and localization;
- text shaping, clipboard, drag/drop, input method and DPI scaling;
- renderer abstraction with software fallback and optional Vulkan/Direct3D/Metal/WebGPU backends;
- native adapters for Win32, Cocoa, Android and Linux desktop stacks.

The current UI module is an early immediate-mode layer over a graphic canvas. It is not a complete cross-platform native widget toolkit.

## 5. Audio and media

- `audio.Clip` for offline PCM data; `audio.Stream` for low-latency device I/O;
- sample formats and channel layouts as enums;
- input/output device discovery and capability query;
- real-time callback rules: no blocking allocation, locks, exceptions or unbounded work on an audio callback thread;
- mixing, resampling, gain, filters, FFT and codec integration;
- separate native backend modules for WASAPI, Core Audio and Linux audio systems.

V44/V45 audio functions are early PCM16/WAV/reference capabilities. Do not label them a full DAW, codec or real-time audio engine.

## 6. Games and 2D/3D graphics

- 2D: window, input, texture, sprite, batch, camera, tilemap, animation, collision and asset loading;
- 3D: mesh, material, texture, camera, lighting, scene graph, animation, skeletal rig, shader, render pass and resource management;
- deterministic game loop, fixed timestep, event input and frame pacing;
- GPU resource ownership, command queue synchronization and device-loss handling;
- software rendering only as a portable fallback/reference path.

Current `three.fac` includes a software rasterizer and is not a hardware 3D engine. Current `gpu.fac` is not a GPU compute backend.

## 7. ML / DL / AI

Treat ML as a layered library, not a promise that the core language must implement every accelerator itself:

- tensor shape/stride/dtype/device abstraction;
- CPU tensor backend first, then native GPU adapters;
- kernels and vectorized operations with deterministic numerical contracts;
- model import/export (for example ONNX), tokenizer and dataset APIs;
- inference runtime integration and optional training/autograd APIs;
- explicit memory pools, zero-copy interop, device synchronization and mixed precision;
- backend capability discovery and clear fallback behavior.

No V45 claim of CUDA, ROCm, oneDNN, ONNX Runtime, model training, or hardware-accelerated ML should be made unless a real adapter is present and tested. Native APIs may expose vendor features, while cross APIs expose portable tensor semantics.

## 8. API maturity states

Use these values consistently in module documentation and the manifest:

- `stable`: tested and compatibility-protected;
- `preview`: implemented, likely to evolve, not compatibility-protected;
- `experimental`: proof-of-concept, limited backends;
- `reference`: testing/software implementation, not production acceleration;
- `planned`: design only;
- `deprecated`: retained during the compatibility window.

## 9. V45 audit priority

Before adding a large set of new methods, audit current APIs for consistent names, correct parameter/return types, ownership transfer, error behavior, thread-safety, target coverage, overflow/bounds behavior, and tests. The generated `api/manifest.json` and contract tags remain the authoritative inventory of current public APIs; this roadmap does not silently add those planned names to the public manifest.


## 10. V53 capability discipline and expansion order

The V53 source tree includes modules for terminal, strings/Unicode primitives, math, random/time, memory, filesystem/path/file, process/system, regex/JSON/CSV, networking, synchronization/threads, crypto, graphics/rendering, audio, font/input, UI/TUI, animation, camera, collision, tilemaps, entities, 3D reference rendering and GPU reference buffers. Presence of a module is not proof of a complete standard library or production backend. The generated `api/manifest.json`, API contract tags, module tests and target conformance matrix are the authoritative evidence.

Recommended expansion order:

1. Complete safety and value contracts for core collections, strings, Option/Result, iterators and I/O.
2. Add consistent functional algorithms and resource-oriented classes alongside them; do not force everything into OOP.
3. Add missing data structures (ArrayList, LinkedList, Stack, Queue, Graph, Tree, Heap, Trie, HashMap, HashSet, Matrix) only with documented complexity, equality/hash requirements, capacity behavior, invalidation and ownership semantics.
4. Improve filesystem/network/process APIs and a composable backend service layer; SQL remains a driver/protocol integration rather than a language replacement.
5. Establish low-latency audio contracts and platform device adapters. Real-time callbacks may not block, allocate unpredictably, lock, throw or perform unbounded work.
6. Separate native windowing/input/text shaping from the cross UI model; add accessibility, localization, DPI, clipboard and input-method support.
7. Add 2D/game workflows first, then a real hardware 3D/GPU backend with explicit device and resource synchronization.
8. Build CPU tensor primitives and a clear ML model/runtime integration boundary before promising accelerator training or CUDA/ROCm/ONNX support.

For every public function and OOP resource method, publish argument/return ownership, error behavior, allocation/blocking, thread safety, cancellation, target availability and ABI boundaries. See [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md).


## V139 implementation note — first core utility batch

Implemented as source-level FAC modules: `collections`, `iter`, `algorithm`, `option`, `error`, `io`, `logging`, `debug`, `assert` and `testing`. The native collection declarations and existing `result`, `string`, `time`, `file`, `sys`, `thread` and `net` built-ins are reused rather than duplicated. Iteration is currently pull-based (`hasNext`/`next` returning `Option<T>`); foreach/yield, lazy generator state machines, general callback-based map/filter/reduce and async/await are not added by this batch. The in-memory I/O helpers are not filesystem stream handles. Logging/debug output is synchronous stderr and must be externally synchronized when shared between threads.


## V143 implementation note — XML, templates and limited reflection helpers

V143 adds preview source modules `xml`, `template` and `reflection`. The XML parser is explicitly an element-only subset and indexes repeated children; it is not a standards-complete XML parser. Template rendering uses explicit values and contextual HTML text escaping; it never evaluates template code. Reflection wraps existing compile-time type/category builtins and does not provide user-defined member metadata.

## V144 implementation note — polling application architecture

V144 adds `events.EventQueue` as an explicit FIFO poll/peek/consume abstraction, `observer.ObservableValue<T>` with revision-token polling, an in-memory string-backed `state.StateStore`, and an accumulating scalar/string `validation.Validator`. These APIs intentionally do not advertise callback delivery or thread safety. Callback subscriptions, DI object factories and service lifecycles remain planned until FAC has a stable callable registry and type-erased managed-object lifetime contract; do not simulate them with string-only aliases and call that dependency injection.


## V146 implementation note — application framework primitives

V146 adds a caller-clock `FixedWindowRateLimiter`, an explicit `CircuitBreaker` state machine with in-flight completion accounting, a stable-priority `MiddlewarePipeline` metadata registry, a `ServiceRegistry` lifecycle tracker, and a typed `InstanceRegistry<T>` for pre-created values. These are intentionally not described as a distributed limiter, automatic retry runner, callback pipeline, service supervisor or full DI framework.


## V147 implementation note — synchronous networking and observability

V147 adds bounded HTTP/1.x request/response primitives on the existing TCP socket API, a JSON-RPC 2.0 envelope codec, bounded in-process polling Pub/Sub, caller-reported health registry and in-memory telemetry exposition. The Runtime adds exact byte reads and string byte-length reporting to make Content-Length framing byte-correct. The HTTP server is one-request-per-connection, does not handle chunked request bodies or keep-alive, and inherits `net.listen`'s all-interface bind behavior. TLS and WebSocket remain deferred; raw TCP and hash/base64 primitives are not evidence of a complete secure transport or frame implementation. See `docs/STATUS.md` and `docs/LIBRARIES.md` for the full capability boundary.
