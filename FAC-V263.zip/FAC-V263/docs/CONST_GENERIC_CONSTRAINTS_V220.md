# FAC V220 — Const Generic Value Constraints

## Status and scope

V220 adds built-in value predicates to `const int` generic parameters declared by generic `struct`, `class`, free functions and methods. A predicate is checked against the evaluated signed-64-bit const argument during specialization. These are value constraints, not type/interface bounds, and they do not add arbitrary compile-time execution.

## Syntax

A const parameter may add one or more predicates after `:`. Join multiple predicates with `&`; every predicate must pass:

```fac
public struct AlignedBuffer<const int N: positive & power_of_two> {
    public array var int values[N]
}

public function<const int N: positive & even> int evenCapacity() {
    return N
}

public function<T: numeric, const int N: positive & even> T keepNumeric(T value) {
    return value
}

public function void main() {
    struct AlignedBuffer<8> buffer
    var int n = evenCapacity<(2 * 3)>()
    var int value = keepNumeric<int, (2 + 4)>(42)
}
```

The same value constraints are available on method-level const parameters:

```fac
public class Utility {
    public function<const int N: positive & odd> int oddCapacity() {
        return N
    }
}
```

The value is either an explicit integer constant expression or, for generic free functions only, an inferred fixed-array extent when a parameter declares `[N]` directly and a fixed-size array argument supplies the extent. Generic methods and generic struct/class instantiations do not infer omitted arguments; parameters with declared defaults may be omitted. Explicit arguments may be positional, named, or positional followed by named; omitted parameters are completed from defaults when declared; see [`NAMED_GENERIC_ARGUMENTS_V220.md`](NAMED_GENERIC_ARGUMENTS_V220.md). Constraints are checked against inferred values too, but they do not make runtime lengths or integer arguments usable as inference evidence; see [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md).

## Built-in predicates

| Predicate | Requirement |
|---|---|
| `positive` | `N > 0` |
| `nonnegative` | `N >= 0` |
| `nonzero` | `N != 0` |
| `negative` | `N < 0` |
| `even` | `N % 2 == 0` |
| `odd` | `N % 2 != 0` |
| `power_of_two` | `N > 0` and exactly one bit is set |

Negative integers are valid `const int` values for predicates that permit them, such as `negative`, `nonzero`, `odd` and `even`. A separate array/layout rule may still reject a value when it is used as an array dimension; the value predicate does not override those rules.

## Diagnostics and evaluation order

Unknown predicate names are rejected during parsing. At a concrete specialization boundary, each predicate is evaluated against the already-evaluated const value. A failed condition reports the parameter, predicate and actual value, for example:

```text
const generic constraint N: power_of_two ไม่ผ่านสำหรับค่า 6
```

For generic `struct`/`class` specializations, const predicates are checked before dependent fields and array layout are materialized. This keeps a failed value constraint from being obscured by a secondary array-size diagnostic. Multiple predicates are evaluated as an AND condition.

The bounded constant evaluator still governs the argument expression: supported scalar `consteval` calls are allowed under the separate restrictions in [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md), while ordinary runtime calls, overflow, division by zero and invalid operations are rejected. The resulting argument is a signed 64-bit integer; this does not enable arbitrary user-function execution during compilation.

## HIR and compiler phases

- The parser stores each value predicate against its const generic parameter and accepts only the built-in predicate names listed above.
- Generic specialization evaluates the const expression first, then checks all predicates before publishing a struct/class specialization or function/method body.
- AST generic metadata retains const-vs-type argument identity. HIR represents const value predicates as named predicate metadata rather than attempting to resolve them as types.
- The existing type/interface bound mechanism for ordinary type parameters is unchanged.

## Boundaries

This release does not support type/interface bounds on const parameters, user-defined predicates, general const-value inference beyond fixed-array extents on generic free functions, const parameters on enum/interface declarations, general `consteval` beyond the bounded scalar free-function subset, arbitrary compile-time execution, typed AST/declaration construction or macro expansion. Named generic arguments are supported for the generic struct/class/function/method forms described in [`NAMED_GENERIC_ARGUMENTS_V220.md`](NAMED_GENERIC_ARGUMENTS_V220.md). Generic virtual/override dispatch and generic interface methods remain outside the supported surface.

## Regression coverage

Run:

```sh
sh tests/comptime/run.sh
sh tests/parser/run.sh
sh tests/semantic/run.sh
sh tests/memory_safe/run.sh
sh tests/generic/run.sh
```

The const-generic suite covers all seven predicates, multiple-predicate conjunctions, type and const parameters in one declaration, struct/function/method specializations, unknown names and failed values. Existing case suites verify generic/runtime behavior at `-O0` and `-O2`.
