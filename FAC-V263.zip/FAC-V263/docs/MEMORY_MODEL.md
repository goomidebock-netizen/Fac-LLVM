# V88 concurrency-analysis precision note

V88 recognizes only fixed result-type contracts from the existing `parse`, `size`, `sizeof` and `strcmp` built-ins when resolving struct-helper overloads in bounded worker-lifecycle summaries. This does not change ownership, borrowing, drop behavior, memory ordering, synchronization, thread safety or `--safe` acceptance. A `must-join` summary remains lifecycle evidence, not a data-race proof.

## V74 local struct-field thread handles

The compiler now tracks a bounded set of `ptr thread` fields stored in local value structs, including nested value-struct fields. The tracked projection is a dotted path rooted at a local declaration. Direct `thread.start` field initialization and `thread.join` on that field update the existing live/joined state lattice; unique direct helper summaries can be applied when the field is passed as a `ptr thread` argument.

This is not a general move/ownership implementation for raw handles. Copying a field or containing aggregate, passing/returning a containing aggregate without a field-aware contract, assignment to an untracked destination, duplicate/shadowed paths, and unmodeled aliases invalidate affected paths to unknown. Class/object fields, array/index paths, struct parameter/return summaries, indirect calls, FFI, arbitrary pointer aliasing and lifetime transfer remain unsupported. The analysis does not change `--safe` acceptance rules or establish data-race freedom. No syntax, public API, Cross-Platform API, native API, Runtime source or ABI changed.

## V228: aggregate provenance propagation and branch escape joins

V228 propagates exact local value-struct pointer-field facts out of lexical blocks and performs may-origin joins for `if`, `switch` / `match`, and `try` / `catch` predecessors. Every path must provide a verified field fact; origins are unioned and every possible source must satisfy the later return/store lifetime. Pointer-local origins are also propagated by declaration identity. Missing facts stay Unknown, while explicit known-null facts stay known. Loops do not yet have a fixed-point analysis: if a loop changes a visible aggregate or pointer-local fact, the fact is invalidated after the loop so later reads fail closed rather than using a stale pre-loop source. This does not provide general heap or interprocedural aggregate escape analysis. See [`MEMORY_MANAGEMENT_V228.md`](MEMORY_MANAGEMENT_V228.md).

# FAC Memory, Ownership, Borrowing and Lifetime Model — current V263 (history begins V45)

## V263 body-verified noescape forwarding for value-struct pointer fields

Strict Ownership may forward the known pointer fields of a non-`ref` value
struct through a function parameter only when the callee body uses each exact
field projection solely as the direct argument to a uniquely resolved,
non-generic helper parameter whose pointer type matches and whose body-verified
contract is `noescape`. Nested value-struct field paths are enumerated from
known aggregate metadata. The whole aggregate, pointer-bearing subtree
prefixes, aliases, returns/stores/captures, direct pointer-field reads, ordinary
retaining-capable helpers, overloads/generic helpers, unknown/cyclic layouts,
pointer-bearing containers/arrays, and `ptr thread` fields are not admitted by
this summary. Unknown cases remain conservative. `ptr thread` continues to use
the dedicated join-only proof from V261/V262. This is a bounded noescape
forwarding fact, not general pointer provenance, heap escape analysis, or a
complete interprocedural lifetime/borrow system. See
[`MEMORY_MANAGEMENT_V263.md`](MEMORY_MANAGEMENT_V263.md).

## V262 join-only helper proof for thread handles in value structs

A verified direct helper parameter may receive a `ptr thread` field from a
by-value value struct only when every use of that pointer parameter in the
helper body is the direct argument to `thread.join`. A struct parameter is
join-only when its fully-known pointer leaves are all exact `ptr thread`
fields, and each is unused or passed only to `thread.join` or one uniquely
declared, non-generic helper with the verified join-only parameter fact. Other
raw-pointer fields, aliases, stores/returns, captures, overloads, generic or
unknown callees, and unsupported projections remain unverified. This is a
bounded non-retention/consumption rule for thread handles, not a general
noescape/lifetime contract or pointer-provenance system. Explicit `move`
continues to obey existing move and loan checks. No syntax, Runtime, public
API, ABI or `--memory-safe` accepted-subset change. See
[`MEMORY_MANAGEMENT_V262.md`](MEMORY_MANAGEMENT_V262.md).

## V261 owned thread handles through local value-struct moves

The exact qualified `thread.start` call contributes an independently
allocated owned-handle origin. Strict Ownership can preserve that origin in
local pointer-bearing value-struct fields through nested explicit `move(...)`
transfers. The exact `thread.join` call consumes argument zero when its static
type is `ptr thread`, according to the API contract that it joins and frees
the handle. Arbitrary incoming thread pointers remain untracked and cannot be
stored in local value-struct fields without a verified origin. `move(value)`
is treated as an intrinsic transfer while its source expression and active
loan restrictions remain checked. This is a bounded thread-resource case, not
general resource lifecycle inference, heap/interprocedural escape analysis or
a complete borrow checker. See
[`MEMORY_MANAGEMENT_V261.md`](MEMORY_MANAGEMENT_V261.md).

## V260 pointer-valued fields reached through enum pointer payloads

The inferred-return fail-closed check now resolves aggregate member projections
rooted at pointer-capable enum match payload bindings. A raw pointer field, or a
nested field projection ending in a raw pointer field, cannot be returned from
an `auto` function unless its provenance is tracked by a broader supported
analysis. Unknown field layouts remain conservative; known scalar fields are
not treated as pointer returns. This is a bounded field-type check, not general
enum-payload provenance or heap/interprocedural escape analysis. See
[`MEMORY_MANAGEMENT_V260.md`](MEMORY_MANAGEMENT_V260.md).



## V258 nested pattern-binding shadowing in return provenance checks

When a nested `match` branch binds a name already marked pointer-capable by an
outer branch, the inner binding first shadows the outer fact. The inner
payload's own metadata then decides whether that name remains pointer-capable.
This prevents scalar inner payloads from inheriting an outer pointer fact while
still rejecting untracked pointer payload returns. Unknown/generic/ambiguous
payloads remain conservative. This is a scoped precision correction, not enum
payload provenance tracking or general escape analysis. See
[`MEMORY_MANAGEMENT_V258.md`](MEMORY_MANAGEMENT_V258.md).


## V256 nested match-payload fail-closed return validation

The return checker searches result-producing nested `match` and `ifv / eiv / elv` expressions for payload bindings that do not yet have provenance tracking. Such pointer-bearing returns are rejected even when the `match` is not the top-level return expression. Selection expressions (conditions, scrutinees, patterns and guards) remain excluded. This prevents an untracked payload value from being treated as a verified empty origin set; it does not add enum-payload provenance support. See [`MEMORY_MANAGEMENT_V256.md`](MEMORY_MANAGEMENT_V256.md).

## V235 branch-aware pointer-return provenance

Strict Ownership may infer a bounded return source through `ifv / eiv / elv` or `match` expressions when all value arms map to one unique verified pointer input/alias. Predicates, match scrutinees, pattern values and guards are excluded from pointer-result origins. Match inference requires an explicit default; pointer results taken from enum payload bindings are rejected until payload origins can be tracked. Mixed sources remain conservative. This does not introduce `ref T` returns or general heap/whole-program escape analysis. See [`MEMORY_MANAGEMENT_V235.md`](MEMORY_MANAGEMENT_V235.md).

## V234 bounded nested-closure lifetime proof

V234 allows a pointer-bearing capture in a nested local closure only when that closure and each enclosing closure are independently proven local and direct-call-only. The proof follows lexical closure ancestry and rejects any parent closure whose function value can be copied, assigned, returned, passed as an argument, shadowed, or referenced in a nested named function. A proof recursion guard rejects mutual/cyclic closure-use dependencies. Existing pointer-origin completeness, `noescape` rejection and region-outlives checks still apply at every closure level. This remains a bounded syntax/use proof, not general closure or heap escape analysis.

## V233 bounded local closure capture

A non-null pointer or pointer-bearing local value struct may be captured only by a lambda that directly initializes one local function-valued variable, whose every use is a direct call within the same function. Every possible source origin must outlive the closure variable's lexical region, checked through the existing region graph; `noescape`, Unknown, and shorter-lived origins remain rejected. Copying, returning, passing, assigning, aggregate/container storage, nested-closure capture and shadowing make the escape proof fail. The check is deliberately bounded and name-based; it is not general closure lifetime inference or heap/whole-program escape analysis. `--memory-safe`, Runtime, ARC/GC, API and ABI behavior are unchanged. See [`MEMORY_MANAGEMENT_V233.md`](MEMORY_MANAGEMENT_V233.md).


## V232 standalone pointer Verified-Null closure capture

The flow-sensitive pointer-origin map distinguishes a present empty fact (the current pointer is proven null) from an absent fact (Unknown). Null initialization/overwrite and copies from another exact verified-null pointer or aggregate field preserve this state; untracked pointer writes invalidate it. A closure may capture the pointer only in the Verified-Null state. Known non-null frame origins and unknown values remain rejected, and joins keep Verified Null only when all predecessors establish it. This is not general closure non-escape or lifetime inference. See [`MEMORY_MANAGEMENT_V232.md`](MEMORY_MANAGEMENT_V232.md).


## V231 local pointer-alias return inference

Strict ownership may now propagate a verified pointer return source through a direct local pointer alias in nested lexical blocks. Parent aliases are visible in child blocks, but child aliases are not exported to parent/sibling scopes. Alias names must be unique in the function body and cannot be assigned or passed to calls. Closure capture fails closed when a pointer local/parameter has missing or unknown provenance; a captured value struct with pointer fields requires an exact fact for every pointer-bearing field. Pointer-free and fully verified-null aggregates remain capturable. These are bounded local checks, not general closure, heap, container or interprocedural escape analysis. See [`MEMORY_MANAGEMENT_V231.md`](MEMORY_MANAGEMENT_V231.md).


## V229 — loop-carried pointer provenance fixed point

V229 performs a bounded may-origin fixed-point analysis over local pointer variables and exact pointer-field paths in local value structs. It transfers loop conditions, bodies and C-style `for` steps in execution order and joins the zero-iteration entry with possible back-edges. Every possible origin is retained, missing exact facts remain Unknown, and known-null remains a separate verified fact. Stable lexical region IDs allow repeated body analysis to converge, while duplicate lifetime constraints are suppressed. After at most 32 passes, a non-convergent state is invalidated. Explicit `break` loops remain fail-closed under the prior invalidation rule because their exit states are not yet separate graph predecessors; `continue` is not modeled as a distinct provenance edge. This is not general heap alias analysis, whole-program escape proof or data-race analysis. ARC, Cycle Collector, Runtime, public API and ABI are unchanged. See [`MEMORY_MANAGEMENT_V229.md`](MEMORY_MANAGEMENT_V229.md).

## V227: validated nested aggregate borrow graph

V227 models nested local reborrows as validated parent-child loan edges. Each child must keep the same original owner, remain inside the parent's exact field projection when one is known, and be contained by the parent's lifetime region. Parent links are checked for missing nodes and cycles before the child loan is added. This supports multi-level local value-struct borrowing while maintaining disjoint-field precision and conservative overlap for dynamic/inexact paths. NLL liveness keeps ancestor aliases suspended while a descendant remains live. This remains a function-local loan graph; it does not prove general heap aliasing, arbitrary pointer safety or whole-program data-race freedom. See [`MEMORY_MANAGEMENT_V227.md`](MEMORY_MANAGEMENT_V227.md).

## V226 — field-sensitive pointer provenance in local value structs

V226 tracks pointer origins by exact local value-struct field path rather than one union per aggregate root. Constructor arguments are associated with declaration-order fields, nested by-value struct paths and local aggregate copies preserve field-specific facts, and reads of a pointer field use only that field's sources. Overwriting a pointer field kills its prior fact; assigning `null` records a verified empty fact, distinct from missing provenance. Replacing nested/whole aggregates clears the affected subtree before rebuilding it. Pointer-field reads and aggregate copy/pass/return operations without complete verified field facts fail closed. This remains a bounded compile-time local value-struct analysis, not a general heap borrow graph or a proof for raw pointer dereferences, concurrency, unsafe code or FFI. ARC, Cycle Collector and Runtime semantics are unchanged. See [`MEMORY_MANAGEMENT_V226.md`](MEMORY_MANAGEMENT_V226.md).

## V225 — pointer provenance in local value-struct fields

V225 allowed a local value `struct` to retain a pointer only when the source provenance was tracked and outlived the struct's lexical storage. Its checker used a conservative provenance union per aggregate root, which could over-approximate sibling fields. V226 replaces that root-level summary with exact field-path facts. See [`MEMORY_MANAGEMENT_V225.md`](MEMORY_MANAGEMENT_V225.md).

## V224 — body-proven multi-pointer return lifetime elision

V224 allows a verified source-defined function with multiple pointer parameters to omit a named return lifetime only when exactly one non-`noescape` pointer parameter is eligible as the return source, every other pointer parameter is `noescape`, and every explicit non-null return directly names that same parameter. The body checker verifies the secondary `noescape` contracts; direct callers inherit result provenance only from the selected input. Multiple candidate return inputs and computed/aliased/call/field return expressions remain conservative. This extends the bounded V222 one-pointer rule; it is not general pointer provenance inference or an aggregate reference lifetime system. See [`MEMORY_MANAGEMENT_V224.md`](MEMORY_MANAGEMENT_V224.md).

## V223 — nested value-field borrowing through managed objects

V223 normalizes the `obj ` prefix during field metadata resolution so a tracked strong object handle can root exact nested **by-value** field paths. A borrow of `actor.stats.health` is disjoint from `actor.stats.mana`, but overlapping borrows and direct writes to an actively borrowed field remain rejected.

The checker stops when a path crosses into a nested `obj` reference, because that child may be aliased through another managed handle and is a distinct heap identity. A `weak obj` handle is not accepted as a borrow root because it does not prove that the referent remains alive. This remains a bounded local loan analysis, not a general heap object graph or cross-object alias solver. See [`MEMORY_MANAGEMENT_V223.md`](MEMORY_MANAGEMENT_V223.md).

## V222 — bounded pointer return lifetime elision and managed heap-field borrows

A verified direct FAC function with a pointer return and exactly one non-`noescape` pointer parameter may omit an explicit named lifetime. The checker creates a synthetic abstract input region, validates that pointer return origins outlive it, and propagates that contract through direct calls. Functions with multiple pointer inputs, `noescape` pointer parameters, extern/abstract bodies or function-value callback signatures do not receive this inference. Shorter-lived local pointers remain rejected at return and at stores to longer-lived pointer variables. See [`MEMORY_MANAGEMENT_V222.md`](MEMORY_MANAGEMENT_V222.md).

A local `ref` alias can borrow a metadata-resolved field through a tracked local managed-object (`obj`) handle. The object handle remains the loan root, so overlapping owner writes are rejected while a mutable borrow is live. This does not enable reference-valued aggregate/object fields, container-stored borrows, arbitrary heap reference graphs or general cross-object lifetime transfer. Module globals and aggregate fields still cannot store local `ref` bindings in `--memory-safe`.

## V221 — checked borrows in the fail-closed memory-safe profile

`--memory-safe` now allows `ref` parameters and function-local `ref` / `ref const` aliases only inside function scopes that are checked by strict Ownership/Move and the local loan CFG analysis. The profile still rejects borrow bindings in module globals and aggregate fields, and it continues to exclude raw pointers, manual heap, pointer primitives, FFI, unsafe code and built-in native-handle modules. Unknown roots, conflicting/ambiguous aliases and unmodeled escapes remain rejection cases. The change reuses the existing checker; it does not add a general heap/aggregate lifetime solver or a whole-program data-race proof. See [`MEMORY_MANAGEMENT_V221.md`](MEMORY_MANAGEMENT_V221.md) and [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md).

## V164 — managed payload-enum partial move boundary

V164 permits a managed payload enum as the final leaf of the existing metadata-validated local value-struct partial-move path. The source field is zero-initialized after the complete enum representation is transferred, allowing its generated drop callback to ignore the moved-from sentinel while recursively dropping remaining fields. CFG moved-path facts still reject use-after-move and overlapping/repeated moves until a valid reinitialization. This closes one managed-field gap but does not add general runtime drop flags, array/index moves, reference-valued fields, returned references, general lifetime parameters or a whole-program dangling-reference proof.

## V91 — argument-dependent result facts through `auto` value copies

The bounded struct-helper analyzer can now preserve `random.int`'s `Int`/`Long` result in a local scalar `auto` initialized from visible, already-proven integer bounds; a later scalar `auto` value-copy can reuse that fact. Unsupported calls and computed bounds remain unknown. This changes only overload candidate precision and adds no ownership, borrowing, lifetime, synchronization or race-freedom guarantee.

## V90 — bounded argument-dependent built-in result facts

The struct-helper lifecycle analyzer now recognizes the existing `random.int` result-width rule only for proven integer arguments: `Int` for two arguments no wider than 32 bits, `Long` if either is wider. Unsupported argument forms stay unknown. This affects only bounded overload candidate selection; it does not transfer ownership, establish lifetimes, prove synchronization or change safe-mode acceptance.

## V89 — scalar results from the existing built-in API table

V89 reuses scalar result contracts already declared by the built-in API table for exact canonical paths and arities. This remains bounded overload evidence, not arbitrary function return inference or a memory-safety guarantee.


## V206 — managed file-resource ownership

`file_resource.fac` adds a managed `FileHandle` class over the existing low-level `ptr file` API. The class stores one native file handle and closes it from its destructor; normal explicit `close()` clears the field before calling `file.close`, so repeated calls and later destruction do not close it twice. `obj` copies share the same object reference, and the file remains open until the final strong reference is released. The Runtime diagnostic `file.liveHandles()` counts handles created via the built-in `file.open` path. This is an additive library wrapper, not compiler ownership inference for raw pointers: direct `ptr file` remains unmanaged, foreign `FILE*` values are outside the counter, and the managed wrapper is not thread-safe even though V218's underlying opaque Runtime tokens serialize native I/O/close. V218 stores a small closed-token tombstone per handle opened until process shutdown so stale pointer aliases cannot become valid again; retained metadata therefore scales with total opens. The general FAC longjmp limitation is unchanged.

## 1. Goals

FAC targets native performance with memory safety as a default. Raw pointers and foreign interfaces remain available for systems work, but their use must be explicit. The long-term safety target is a statically enforced ownership/borrowing model with a small, auditable `unsafe` boundary.

## V134 fail-closed memory-safe source subset

The `--memory-safe` option rejects raw/opaque pointer and manual heap types, raw dereferences/address primitives, local and parameter `ref` borrows, FFI/export/native-link directives, unsafe blocks/functions, native linker inputs and built-in module imports/function references whose declarations expose native handles (plus the process-capable `sys` module). It enables strict Ownership/Move, bounds/division checks, integer-overflow checks and checks source standard-library modules instead of automatically trusting them. The exact rule set and tests are in [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md).

This is an intentionally limited safe subset, not a complete borrow checker or Rust-equivalent memory-safety guarantee. It does not prove the compiler or C++ Runtime correct, eliminate all use-after-free paths, or prove thread race freedom. The current `setjmp`/`longjmp` runtime exception model remains a trusted-runtime limitation.


## V87 — fixed-result string conversion facts for helper overloads

V87 lets the bounded struct-helper lifecycle resolver use the exact `String` result type of a direct built-in `str(value)` argument. The fact only affects overload candidate selection. It does not infer arbitrary function return types and does not add ownership, lifetime, happens-before or data-race guarantees.

## V86 — explicit primitive-cast facts for helper overloads

V86 lets the bounded struct-helper lifecycle resolver use the explicit primitive result type of `cast(Type, value)` when selecting among overloads. The same fact may feed a supported scalar `auto` initializer and nested cast. It changes only which known helper candidate contributes an existing lifecycle summary; it does not add ownership, lifetime, happens-before or data-race guarantees. Uncertain cast targets and non-primitive casts remain unknown.

## V73 interprocedural thread-handle parameter effects

The V73 compiler computes bounded summaries for `ptr thread` parameters of eligible direct free functions. The summary records whether a parameter is joined on all modeled exits, joined on only some exits, left live without being consumed, or becomes unknown due to an escape/unsupported path. Summaries are propagated through a bounded number of direct calls, including imported and module-qualified functions when the target is unique. Handle argument types are used to filter overload candidates; unresolved ambiguity remains unknown.

This is not a complete ownership model for thread handles. It does not track general aliases, arbitrary moves/returns/stores, instance-method dispatch, indirect calls, FFI, detach/cancellation or arbitrary recursion. The summary describes only the parameter's observed lifecycle at the analyzed function boundary; it does not prove that worker-captured memory is safe or establish all happens-before edges. `--safe` policy is unchanged.

## V72 worker multiplicity and join lifecycle

The whole-program registry now records the launch multiplicity class of each static site: per-activation, loop-repeatable, or parallel-replicated. These classes describe the syntactic launch context only; they are not runtime instance counts. A function may be called repeatedly, and recursion/indirect calls can expand the number of runtime launches beyond one static site.

A bounded local flow analysis tracks handles declared directly as `ptr thread name = thread.start(...)`. Its state lattice distinguishes not-started, live, joined and unknown/escaped alternatives at branch joins. A handle is `must-join` only when no modeled exit retains a live or unknown alternative. `may-outlive` means a live alternative remains; `conditional` means some modeled paths join while others may not; `unknown` means an escape, ambiguous declaration or unsupported cleanup/control-flow region prevents proof. A direct `thread.parallelFor` call is `runtime-joined` based on the current Runtime implementation's join-before-return behavior. The pass does not track thread handles across function parameters/returns, aliases, detach/cancellation, or arbitrary exceptional CFG edges.

These facts describe handle lifecycle, not synchronization ordering for shared payloads. `must-join` does not on its own prove the correct ownership or synchronization of every accessed object; candidate atomic edges remain unproven. `--safe` continues rejecting mutable global payloads.

## V71 whole-program worker and cross-worker candidate model

V71 collects statically visible `thread.start` and `thread.parallelFor` callback sites from loaded function/method bodies and module/static initializers. It follows the bounded direct-call analysis from each direct lambda callback, then unifies global accesses by declaring-module storage identity, including explicit module-qualified references and imported globals. Per-storage aggregation reports which launch sites share mutable storage, cross-worker atomic write/read candidates, the Release-to-Acquire and CAS-failure-Acquire subsets, possible ordinary read/write conflict pairs, and `parallelFor` self-replication candidates.

The registry is an over-approximation of statically visible launch sites, not a dynamic call graph or runtime thread registry. Unreachable functions can be included; non-lambda callbacks and scan failures are counted as unresolved. The graph does not establish execution multiplicity of repeated `thread.start` call sites, overlapping lifetimes, runtime thread identity, join ordering, actual read-from values, modification order, release sequences, synchronizes-with or happens-before. Arbitrary pointer aliases, dynamic dispatch, FFI and trusted code are not proven. Mutable global payloads remain rejected in `--safe`.

## V70 atomic read-from candidate model (historical)

For each statically resolved global storage, V70 considers each atomic modification node (atomic store, RMW or compare-exchange) as a possible source for every distinct atomic read node. The diagnostic separates the total `read-from-candidates` count from the subset whose source has Release semantics and whose destination has Acquire semantics. An Acquire compare-exchange failure load is counted independently. A distinct RMW node may be reported as a possible bridge between a Release and Acquire endpoint, but the pass does not know whether it lies between them in modification order.

Worker-template and direct-call-path metadata distinguish static source contexts; a worker template is not a runtime thread identity. Source/AST traversal order is not modification order. The current analysis does not establish a concrete read-from assignment, release-sequence membership, synchronizes-with or happens-before. Mutable global payloads remain rejected in `--safe`.

## 2. V45 implemented behavior

| Feature | Current implementation | Guarantee / limitation |
|---|---|---|
| Managed values | Runtime retain/release and cleanup for strings, lists, closures, objects, weak handles and managed aggregate types | Runtime-managed lifetime, not static proof of all aliases |
| Move semantics | `move(local)` under `--strict-move` | Limited managed local variables; parameters, fields, globals, loops, lambda and defer moves remain restricted |
| Mutable borrow | `ref T parameter`; V53 local `ref var T alias = lvalue` | Direct-call contracts plus local loans with bounded statement-level last-use expiration; no persistent CFG loan graph |
| Immutable borrow | `ref const T parameter`; V53 local `ref const var T alias = lvalue` | Shared local loans with bounded last-use expiration and const receiver checks; not a full const object model |
| Lifetime | Borrowed `ref` parameters are call-scoped in the current type surface; reference values are not first-class/returnable | No general Lifetime Checker for arbitrary stored references or raw pointers |
| Dangling references | Managed references are retained/released; raw pointer validity remains caller responsibility | No general static Dangling Reference Detection for arbitrary pointer arithmetic/FFI |
| Unsafe boundary | `unsafe {}` / `unsafe function`, enforced with `--safe` | Raw pointer operations and FFI must be explicit; `unsafe` code remains caller-audited |
| Cycle collection | Explicit `memory.collectCycles()` for a limited graph | Not concurrent; untraced container/closure references are conservative roots |

The V45 `ref const` addition is additive and opt-in through `--strict-ownership`; normal legacy compilation is unchanged.

## 3. Ownership rules

1. A managed value has one or more runtime-owned references. Copying a managed value follows the type's copy/retain contract.
2. `move(value)` transfers the managed value out of a mutable local slot. The source becomes unusable until reinitialized.
3. `ref T x` is an exclusive mutable borrow for a call. V53 local `ref var T x = owner` creates an exclusive local loan that V54 may end after the last possible use in a straight-line block; it must not overlap another shared or mutable loan of the same root.
4. `ref const T x` is a shared immutable borrow for a call. V53 local `ref const var T x = owner` creates a shared local loan that V54 may end after the last possible use in a straight-line block; multiple shared loans may overlap.
5. A shared borrow must not be directly assigned to or incremented/decremented. Under `--strict-ownership`, direct writes through the named parameter and passing it to a known mutable-ref parameter are rejected.
6. Different field/index expressions rooted in the same variable are treated as possibly aliasing. This is conservative and may reject safe disjoint fields.
7. `ptr T` remains a raw non-owning pointer. It is not made safe by a `ref` annotation elsewhere.

Examples:

```fac
function int sum(ref const int left, ref const int right) {
    return left + right
}

function void exchange(ref int left, ref int right) {
    var int tmp = left
    left = right
    right = tmp
}

public function void main() {
    var int a = 10
    var int b = 20
    var int total = sum(a, a)       # two shared borrows are permitted
    exchange(a, b)                  # two distinct mutable borrows
    # exchange(a, a)                # rejected by --strict-ownership
}
```

Build with:

```sh
facc app.fac --strict-ownership --strict-move --safe
```

## 4. What `--strict-ownership` proves and does not prove

It now checks:

- same-root argument overlap when a direct call's known signature requires at least one mutable borrow;
- direct writes (`=`, postfix `++/--`, prefix `++/--`) rooted in a `ref const` parameter;
- a named `ref const` parameter passed as an argument to a known direct function/method whose matching signatures all require a mutable `ref` at that position.

It does **not** prove:

- aliasing through raw pointers, pointer arithmetic, indirect calls, foreign callbacks, dynamic dispatch, or hidden runtime state;
- that a method called on a reference-like object does not mutate interior state;
- that different field/index paths are truly disjoint;
- a general outlives relation, heap-stored references, closure escape, or full lifetime inference;
- race freedom or thread-safe access to shared objects.

When overloads share a name, the checker only rejects cases that every same-arity candidate classifies as conflicting. This avoids assuming an overload that may not be selected.

## 5. Planned full borrow checker

A later release must not call the checker Rust-equivalent until all these items are implemented and tested:

1. Explicit borrow regions in the typed IR, including reborrows and borrow origin tracking.
2. Control-flow graph (CFG) and data-flow analysis for loan creation, use, and expiration.
3. Exclusive mutable loan and shared immutable loan conflict detection across statements, branches, loops and closures.
4. Lifetime/outlives checking for returns, fields, globals, containers, async tasks and callbacks.
5. Move-state analysis for fields, tuple/array elements and partial initialization.
6. Escape analysis and dangling-reference diagnostics at every safe boundary.
7. Send/Sync-style thread transfer rules and alias-aware data-race analysis.
8. Negative tests for each accepted rule and fuzzing of borrow graph/CFG transitions.

Do not add a source-level lifetime annotation until the inferred-lifetime model is stable. If annotations become necessary, prefer Java-readable named lifetimes such as `function ref const T first<'a>(ref const array T values[])` only after the parser, type checker and diagnostics can enforce them end-to-end.

## 6. Move and ownership transfer roadmap

The next ownership milestone should extend `move` only when static analysis can prove the source slot and destination cleanup behavior. Priority order:

- support move from parameters with explicit ownership-taking parameter syntax;
- support struct fields and collection element extraction without double-drop;
- partial moves and reinitialization per field;
- move across match/if branches and loop back-edges using CFG dataflow;
- closure capture modes (`copy`, `move`, immutable borrow, mutable borrow) with explicit escape checks;
- async task ownership transfer and cancellation-safe destructors.

A future API may provide a named `take` operation for collection extraction, but it must not duplicate the semantics of `move` or make a borrowed value appear owned.

## 7. Unsafe policy

Use `unsafe` only at the smallest boundary that must perform raw memory, FFI, OS-native operations, inline assembly, or hardware register access. A safe wrapper must document and enforce:

- pointer validity and alignment;
- allocation/deallocation pairing;
- object and buffer lifetime;
- aliasing and synchronization;
- length/range checks;
- whether callbacks can re-enter FAC or outlive their caller.

`volatile` is not atomic and is not a memory barrier. Use atomics or synchronization APIs for thread coordination.


## V69 atomic synchronization graph candidates (historical)

V69 adds per-storage atomic event nodes for statically resolved global addresses in checked worker call graphs. Each node records the call-site identity and line plus its operation and read/write/failure memory orders. Distinct Release-capable and Acquire-capable nodes on the same storage form a directed candidate edge; SeqCst node pairs are counted independently. This is a candidate graph for diagnostics, not a synchronization proof: the analysis does not prove read-from, release-sequence membership, peer-thread identity, or arbitrary alias equivalence. Mutable global payload access remains rejected by `--safe`.

## V68 atomic memory-order analysis

V68 records read-side and write-side orders of statically recognized atomic calls, plus compare-exchange failure-load order. Legacy `atomicGet/Set/Add/Cas` APIs remain SeqCst, and explicit `*SeqCst` aliases are available. Acquire and Release RMW effects are not conflated: Acquire is an acquire read plus relaxed write; Release is a relaxed read plus release write. A release/acquire-capable summary is only candidate synchronization evidence. The compiler does not yet prove which release value an acquire reads, so it does not construct a sound cross-thread happens-before graph. Mixed ordinary and atomic access is diagnosed as a potential race; mutable global payload access is still rejected from safe worker closures.

## V67 lock-aware concurrency analysis

V67 carries the held-lock context from a direct call site into a statically followed callee and rejects any callee whose normal return changes the caller's lock set. Global lock identities are module-qualified; local and parameter shadowing, unsupported mutex expressions, loop changes and direct mutex operations in `try` regions are conservative rejection cases. Per-global summaries compute the intersection of locks common to all observed ordinary accesses and separately flag unprotected accesses. Different lock identities are not treated as interchangeable.

This still does not prove that all program threads use the same lock, resolve pointer aliases, validate FFI/trusted-library behavior or construct atomic happens-before edges. `--safe` continues to reject mutable global payload access regardless of the lock summary.

## V66 concurrency effect-summary foundation

V66 adds typed summaries for mutable globals reachable from checked worker closures: read, write, address/alias, recognized atomic read/write, and lexical mutex observations. This is diagnostic and analysis metadata, not a complete race detector. It does not yet substitute actual/formal pointer aliases, verify that every access uses the same lock, model atomic happens-before, or inspect all FFI/trusted-library behavior. The existing worker policy still rejects mutable global payload access in `--safe`. See [`CONCURRENCY.md`](CONCURRENCY.md).


## V48 strict-borrow guardrails

When `--strict-ownership` is enabled, an instance/member call whose receiver is rooted in a `ref const` parameter is rejected. FAC does not yet provide `const`-qualified instance methods, so the compiler cannot distinguish read-only methods from methods that mutate the object. This rule is intentionally conservative; it may reject a pure getter. `ref` parameters with default values or variadic capture are also rejected by this opt-in check because implicit temporary/pack lifetime and alias semantics are not yet modeled. These rules do not apply to ordinary compilation without `--strict-ownership`.

This is not a general Lifetime Checker: it does not track references through arbitrary fields, containers, pointer aliases, function values, FFI, return values or concurrency.


## V50 const receiver contracts

Instance methods may now end in `const`, for example `function int size() const`. This qualifier permits a `ref const` receiver to call that method under `--strict-ownership`. The checker treats `self` as immutable and rejects direct receiver writes, non-const calls on `self`, known mutable-ref escapes, and closure captures of `self`. Interface and override signatures include the qualifier. This is not deep constness: raw pointers, FFI, global state, hidden aliases and arbitrary callee effects are not fully analyzed.

## V51: CFG move-state analysis

`--strict-move` now operates over a control-flow graph with a forward fixed-point analysis. Its state is a conservative set of local symbols that may already have been moved. The graph represents branch joins, loop back-edges and exits, so a repeated move or later read through a cycle is detected. A direct assignment to the whole local clears its moved fact and allows safe reinitialization before a later read or iteration. Lexical bindings are assigned unique IDs so shadowed variables do not share move state.

For `try/catch/finally`, V51 models exceptional paths conservatively: every local that may be moved syntactically in the try body is considered potentially moved on the catch/finally edge, and possible moves from a catch body are propagated to its exceptional/finally edge. `return`, `break` and `continue` leaving the protected region are routed through `finally`. This may reject some safe programs but prevents these paths from assuming that all moves were skipped. Literal boolean conditions are used to prune unreachable branches.

This work improves explicit move checking but does not add partial moves, returned-borrow lifetime inference, stored-loan tracking, dangling-reference detection, raw-pointer/FFI escape analysis, or static data-race proof. `ref` / `ref const` remains an opt-in direct-call alias/contract checker. A passing `--secure` compile is not a formal proof of memory safety.


## V52 compile-time assertion boundary

V52 adds top-level `static_assert` over the compiler's integer/bool constant-expression subset. It does not change runtime ownership or borrowing and emits no runtime code. Its evaluator is intentionally side-effect-free and rejects non-constant expressions, arithmetic overflow, division/remainder by zero and invalid shift counts. This feature is a compile-time invariant tool, not a lifetime checker or a proof of memory safety. V220 later adds a separate bounded scalar free-function `consteval` interpreter; it is not general compile-time execution. See [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md). See [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md).


## V53 local borrow bindings

With `--strict-ownership` or `--secure`, a function may declare `ref var T alias = owner` or `ref const var T alias = owner`. These are storage aliases, not copied values. The compiler emits the original lvalue address and does not create an additional owner/drop record. The first V53 implementation uses lexical regions: a loan lasts to the closing brace of its block, not merely to its last use.

V53 supports local/parameter/receiver roots and recognized fields/elements. It rejects mutable borrowing from const or untracked storage, globals/statics, local alias declarations from another alias or `ref` parameter, `addr()` escape, and moves/accesses that conflict with active loans. A mutable loan blocks owner access; a shared loan permits owner reads but blocks writes. All fields/elements under one root are treated as potentially overlapping, so disjoint-field mutation is conservatively rejected. Shared aliases cannot be written or call non-const methods. Class/struct aliases cannot be passed by value or to an unverified call; statically known direct `ref` calls may use a temporary reborrow subject to their mutability contract.

This is not a persistent CFG loan graph or NLL. It does not validate reference returns, stored references, unsafe pointer aliases, FFI, hidden indirect effects, dynamic-dispatch escape or static data races. The alias analysis and type/lifetime model should be expanded before enabling local borrows by default.

Closure boundary: V53 checks closure bodies under currently active loans. Capturing a non-scalar local borrow alias is rejected because a managed/aggregate value may retain access beyond the lexical loan. Scalar captures are value snapshots, while access to the owner from inside a closure is still checked under the active shared/mutable loan. This is conservative and does not establish general closure escape or callback lifetime safety.


## V54 bounded NLL / last-use expiration

V54 retires local loans declared in a block after the statement that contains their last possible alias use. Uses inside structured control-flow statements (`if`, `match`, `try`, loops) are conservatively kept live through the whole statement. A local loan referenced by `defer` remains active through block exit. Inherited loans are not retired by nested blocks. V56 supersedes the name-based use discovery with a lexical identifier-to-declaration resolver; see the V56 section below.

The checker does not construct a persistent CFG loan graph or run a fixed-point NLL analysis. It does not provide precise edge-sensitive loan joins, loop-internal last-use expiration, reborrow declarations, arbitrary lifetime inference, reference-return/store validation, partial move, raw pointer/FFI alias proof, dangling-reference proof or static data-race proof. The language's local borrow feature therefore remains opt-in.


## V55 borrow-analysis update

Strict ownership now combines CFG-based backwards may-liveness for local borrow aliases with parent/child reborrow records. A mutable parent is suspended while a child reborrow is active; shared reborrows remain read-only. This improves branch/loop precision but is not a complete lifetime checker: alias-use liveness uses declaration identity, while `defer` and `try` remain conservative, and raw-pointer/FFI/indirect-call escape paths remain outside the proof boundary.


## V56 declaration-identity borrow model

Borrow liveness now uses `const Node*` declaration identities for local alias symbols. The resolver maintains lexical environments and explicit shadowing entries: a non-borrow declaration shadows an outer borrow name with a non-loan binding; lambda parameters, foreach iteration names, catch variables and match bindings are also scoped independently. Therefore same-spelled identifiers do not merge their liveness facts.

Each local loan also stores `rootDecl`, the exact owner declaration when the root is a local variable. Parameter and `self` roots have no AST declaration node and are distinguished by their function-local root name. All operations which check access to the root compare both components. This closes a prior false-positive class where a nested local named like a borrowed owner was treated as the same storage, and avoids allowing writes to the real outer owner while its borrow remains live.

The current language restricts local borrow declarations to tracked storage visible at the declaration point. It does not permit reference fields or reference return types, rejects untracked global/static roots, and blocks several raw-pointer/callback escape paths. Those restrictions provide a limited lexical lifetime boundary for local aliases, but no general reference region or lifetime-parameter solver exists. Raw pointers, FFI, unsafe code, container invalidation, indirect calls and concurrency still require separate analyses and audited contracts.


## V57 lexical lifetime regions and exceptional paths

Strict local-borrow checking now assigns each function a root lifetime region, creates nested regions for blocks/loops, and associates declarations with the region where storage is introduced. A local loan must be contained by an owner region that is the same or an ancestor region. Reborrow also constrains the parent loan's region to outlive the child loan's region. This is checked as a lexical region-tree relation; it does not add a source-level lifetime syntax or general outlives inference.

The local-borrow CFG now represents explicit throw-to-catch edges, outward exception propagation, finally cleanup edges, and conservative exception edges from expressions inside try regions. An exception from a catch passes through its associated finally; an exception from a finally uses the outer exception context. `try/catch/finally` alias liveness is now path-derived rather than globally pinned, while `defer` aliases remain live until scope exit. Because calls are not yet annotated with reliable `nothrow` effects, expression exceptional edges are over-approximated. Reference returns/stores, raw pointer and FFI escapes, aliasing inside containers, and whole-program race safety remain outside the proven model.



## V58 bounded pointer provenance and dangling-frame escape checks

Under `--strict-ownership` / `--secure`, the checker tracks direct `addr()` origins for function-frame storage. Provenance is propagated through local `ptr` variables and keyed by pointer-variable declaration identity. Branch/block assignments contribute monotone may-origin facts, so a later return cannot forget an address assigned on one conditional path. Direct return of a frame address or a pointer variable carrying a frame origin is rejected. Assigning an inner-scope address to a longer-lived pointer variable is rejected using the lexical region tree.

The checker also rejects aggregate initializers containing frame-derived pointers, field/element or untracked/global stores, closure capture of a pointer carrying frame provenance, and arguments passed to a conservative name-based set of known retaining collection mutators (`add`, `addFirst`, `addLast`, `addEdge`, `append`, `emplace`, `enqueue`, `insert`, `push`, `pushBack`, `pushFront`, `put`, `set`). Aggregate stores are rejected rather than modeled field-by-field because FAC does not yet have reference-valued field/container lifetime contracts.

Immediate `addr()` call arguments remain allowed for existing APIs/FFI, because many calls consume the address synchronously. The compiler cannot prove that an unknown or foreign callee does not retain it; no `noescape`/effect contract is available yet. Direct expression trees are recursively inspected, but arbitrary pointer/integer round-trips, helper functions, indirect callbacks, opaque foreign code and values arriving from untracked storage may hide provenance. The may-origin set is conservative across control flow and may retain an origin after an overwrite, causing false positives. This is a bounded frame-escape guardrail, not a general raw-pointer verifier, complete dangling-pointer proof or memory-safety certification.

## V59 noescape pointer effects

A parameter declared `noescape ptr T p` promises that the pointer value and pointer values derived from it do not escape the call. Under `--strict-ownership` / `--secure`, FAC function bodies are checked for pointer provenance through local pointer aliases. Returning it, storing it into persistent/untracked destinations, capturing it in closures, or forwarding it to an unannotated/indirect call is rejected. Direct forwarding is permitted only to a verified FAC noescape body or an explicitly annotated trusted FFI declaration.

An extern noescape annotation is not checked against foreign implementation code. It is a trust assumption at the FFI boundary; incorrect annotation can invalidate memory-safety assumptions. The modifier adds no runtime ABI or overhead and says nothing about pointer validity, nullability, alignment, aliasing, mutation, thread-safety or exception behavior. Indirect-call function types do not yet carry effects. This is a bounded direct-call escape contract, not a complete raw-pointer lifetime proof.


## V60 bounded partial move and field initialization state

`--strict-move` / `--secure` now accepts `move(record.field)` only when `record` is a local mutable value `struct` and `field` is a first-level managed leaf handle (`dyn string`, list/data-structure, function, `obj` or `weak obj`). The compiler transfers the pointer-like handle out of the field and immediately stores null in the field slot. The returned value is owned and protected by the existing temporary cleanup stack. The ordinary `drop.Struct` helper still visits the field, but the supported release functions accept null; other still-initialized fields are dropped as usual. This makes the common move-out pattern safe without adding a second independent destructor path.

The CFG move dataflow tracks each field by `(root declaration identity, field name)` and tracks whether the containing aggregate is partially moved. A moved field cannot be read or moved again. The whole aggregate cannot be read, passed by value, moved, captured, deferred or used as a method receiver while any field is moved. An assignment to the moved field restores its initialized state; when all moved fields have been restored, whole-aggregate use becomes valid again. At branch joins the checker uses a may-be-moved union, so a moved field must be restored after the join before use. A move inside a loop is accepted only when the same field is restored before the back-edge.

The current implementation is intentionally narrower than full Rust-style partial moves. It does not move scalar/raw-pointer fields, nested fields or nested struct/enum/array/class contents. It rejects parameter, receiver, borrowed alias and heap/indirect roots. There are no general per-field drop flags, no conditional destructor graph for arbitrary nested aggregates, and no field-sensitive borrow-disjointness proof. `ptr T` is a raw unmanaged pointer and remains outside managed move/drop semantics. Runtime source and ABI did not change in V60; safety depends on the already-tested null-safe drop functions for the supported leaf types. Do not infer that arbitrary FFI handles or custom pointer resources can be partially moved.

## V61 field projections and pointer parameter effects

Borrow loans now carry a storage projection as well as owner declaration identity. The only disjointness proof currently implemented is for direct first-level named fields of the same root declaration. Different direct fields may be borrowed mutably at once; a whole-object access overlaps all projections. Same fields, nested fields, array/list indexes, computed expressions, pointer dereferences and unknown aliases remain conservative may-alias paths. This is a bounded projection analysis, not full field-sensitive alias analysis or a proof about union/overlapping-layout storage.

The `readonly ptr T` parameter modifier adds a compile-time pointee-write promise. The `noescape ptr T` modifier remains a separate retention promise; combining them expresses a synchronous read-only pointer contract. FAC bodies are checked, while extern annotations are trusted FFI assumptions. Abstract/interface declarations can publish the effects and concrete implementations must preserve them through overrides/interface implementation. V65 resolves direct-call `ref`/`noescape`/`readonly` effects against the best overload selected from known argument types; unknown arguments and unresolved ties require effect consensus across all arity-compatible candidates. V64 carries `noescape`/`readonly` through explicit function-value signatures and checks compatibility, but indirect-call pointer escape proof remains fail-closed until target-aware body verification is implemented. Detailed rules and limitations are in [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).

V61 does not change the Runtime source or ABI. Field-sensitive borrowing works alongside, but does not generalize, V60's bounded first-level managed-field Partial Move. Nested projections and arbitrary per-field drop state remain unsupported.


## V62 nested borrow projections

The local-borrow checker now represents validated member paths as dotted projections. It resolves each field segment against the preceding aggregate type before marking a path exact. Prefix/descendant pairs overlap; distinct siblings do not. A pure member chain is checked as one storage path so intermediate prefixes are not spuriously treated as independent whole-field reads. Indexed, dereferenced, dynamic and computed paths remain may-alias. Nested drop flags and nested partial move remain unsupported. Runtime and ABI are unchanged.


## V183 fixed-array index borrow projections

The V62 nested-field projection analysis is extended for one narrowly defined indexed case: a non-negative integer-literal index into a fixed-size `array` rooted at a tracked named local. The checker encodes the numeric index as a complete path segment, so `[1]` does not prefix-match `[10]`; whole-array paths still overlap every element. The shared projection overlap routine applies this proof to owner reads/writes, loan creation and reborrows. Dynamic/computed indexes, list and matrix indexes, pointer-derived bases, and all other unvalidated storage continue to overlap conservatively. This is not full array alias analysis and does not expand reference storage/return lifetimes. Regression coverage is in `tests/ownership/local_borrows/`.


## V63 nested partial moves and exception cleanup

V63 extends explicit partial move from a first-level leaf to metadata-validated nested value-struct paths. The move checker tracks state by owner declaration identity and dotted field projection. A moved path overlaps itself and its ancestors/descendants; sibling paths remain disjoint. This state is a compile-time may-be-moved set merged across CFG edges. A whole aggregate or subaggregate that contains a moved path cannot be read or consumed until the affected path is restored.

At runtime, a moved managed handle is replaced with null. A moved managed value struct is copied to an owned temporary and its source bytes are zeroed. Because generated struct drop helpers recursively visit managed fields and the existing release operations accept null, the original root can remain registered on the normal cleanup stack. The moved value is separately registered on the temporary cleanup stack; after it is stored into a local, the temporary entry is transferred to that local's cleanup entry. On exception unwind, temporary cleanup and owner cleanup therefore release each live field once. The new nested exception regression exercises a throw after a nested move and verifies that the catch path executes.

Reinitialization to the exact moved path clears that path's state. Replacing a parent subaggregate clears all moved descendants after the previous subaggregate has been dropped; writing through a moved ancestor is rejected. CFG joins remain conservative unions. Intermediate path elements must be value structs; the final value must be a managed handle or managed value struct. Parameters, receivers, borrow aliases, globals, heap/indirect roots, classes, enum payloads, arrays/indexes, scalar fields, raw pointers and untracked aliases remain outside this feature.

No new Runtime drop callback or ABI surface is introduced. The implementation does not yet add arbitrary bitmaps for partially initialized arrays/enums/classes or custom resource fields, and the zero/null sentinel argument must not be generalized to arbitrary foreign pointer resources. Runtime was reviewed and left unchanged because its existing cleanup and recursive aggregate-drop callbacks cover the implemented subset.

## V75 — bounded move-aware worker lifecycle

Explicit whole-aggregate moves of managed local value structs can transfer tracked `ptr thread` field lifecycle state to destination paths. The worker registry follows the move path when associating a later join with its launch. This is static bookkeeping over supported syntax, not a runtime ownership token, happens-before relation or data-race proof. Unresolved/copy/alias paths remain unknown. No Runtime ABI change.


## V76 — interprocedural struct-parameter thread lifecycle

The worker registry now applies bounded per-field summaries for uniquely resolved direct free-function calls receiving value structs with nested/direct `ptr thread` fields. Each field is summarized independently; direct joins and calls to a known `ptr thread` helper propagate must-join or conditional outcomes, while a no-op helper leaves the worker live. A repeated join becomes unknown. Existing `move(aggregate)` arguments are mapped back to the caller's field paths and rely on the separate strict-move checker for moved-from validity.

This does not transfer lifecycle state through struct returns, globals/stores, aliases or lambda captures; those and recursive/unresolved/dynamic calls remain unknown. The lifecycle result is not a scheduler guarantee, happens-before edge or race-freedom proof. No API surface or Runtime ABI was modified.

## V77 — fixed-point aggregate thread-handle summaries

Struct-parameter lifecycle effects now propagate through uniquely resolved helper chains by bounded fixed-point iteration (maximum 32 rounds). Whole aggregate and nested aggregate-field arguments are supported when they remain direct paths rooted at the tracked parameter. Declaration order no longer determines whether a wrapper chain can acquire the leaf helper's `must-join` or conditional summary.

Recursive cycles, ambiguous overloads and unresolved or unsupported escape paths remain unknown. The analysis tracks lifecycle effects only; it does not create a general interprocedural ownership transfer, return-value contract, borrow/lifetime proof, happens-before relation or race-freedom guarantee. No Runtime/ABI change.


## V84 — unary scalar-literal facts for helper overload resolution

V84 recognizes a single unary operator applied directly to a supported scalar literal while resolving struct-helper overloads: `!` yields `boolean`, unary `+`/`-` on integer/floating literals preserves their literal type, and integer `~` uses normal integer promotion. The analyzer does not evaluate arbitrary expressions or infer nested unary/call/cast/identifier forms. This changes only bounded lifecycle-summary candidate precision; it adds no ownership/lifetime proof, happens-before edge or data-race guarantee and changes no Runtime or ABI contract.

## V83 — scalar auto value-copy facts for lifecycle overload resolution

V83 allows a local `var auto` initialized directly from a simple identifier to reuse a proven scalar value type from the binding visible at that declaration point. Explicit primitive locals/parameters and earlier eligible `auto` facts may be copied through multiple declarations. The resolver installs the new binding only after reading the initializer, preserving lexical shadowing. Calls, operators, casts, member paths, globals and unknown source bindings remain unknown. This changes only helper lifecycle candidate precision; it adds no ownership/lifetime proof, happens-before edge or data-race guarantee, and changes no Runtime or ABI contract.

## V82 — literal-initialized auto facts for lifecycle overload resolution

V82 adds a narrowly bounded type fact for local `var auto` identifiers whose initializer is a direct scalar literal. The exact literal type is recovered after initialization and participates in the existing `scoreArg` overload ranking at the call-site lexical scope. Auto initialized from calls or computed expressions remains unknown. This affects only lifecycle-summary candidate precision; it adds no happens-before edge, ownership/lifetime proof or data-race guarantee, and changes no Runtime or ABI contract.

## V81 — call-site lexical binding for lifecycle overload resolution

V81 refines the bounded worker lifecycle resolver by recovering the explicitly declared primitive binding visible at the exact helper call site. Sibling branch declarations are analyzed in their own scopes, and outer declarations become visible again after a nested block ends. Unsupported bindings and uncertain expressions remain unknown. This changes only lifecycle-summary precision: it adds no happens-before edge, ownership/lifetime proof or data-race guarantee, and no Runtime or ABI contract changes.

## V80 — explicitly-declared scalar identifier overload resolution

V80 extends the bounded worker lifecycle overload resolver from literal types to simple scalar identifiers whose declarations are statically explicit and consistent across all matching parameters/local declarations in the owner function. It applies the existing `scoreArg` ranking; any unsupported or conflicting declaration keeps the candidate set unresolved. Calls, computed expressions, globals, member paths and indirect calls are not inferred. This is diagnostic lifecycle-effect precision only, not ownership transfer, a happens-before edge or a race-freedom proof. No Runtime or ABI change.

## V79 — literal-aware struct-helper overload summaries

The interprocedural thread-handle lifecycle pass can now distinguish struct-helper overloads when literal arguments provide exact types. It uses the same scoring function as compiler call selection. A unique best candidate contributes its per-field effect; non-literal expressions are not statically typed by this pass, and any remaining tie is still `unknown`. This improves lifecycle-summary precision but does not establish ownership transfer, a happens-before relation, or race freedom. No Runtime or ABI change.

## V78 — dependency-worklist aggregate thread-handle summaries

V78 replaces the V77 32-round whole-set scan with a reverse-dependency worklist. It queues only callers of a uniquely resolved helper when that helper's field summary changes, allowing long wrapper chains (tested at 40 functions) to converge without rescanning the full eligible function set. A deterministic work budget derived from function and field counts protects compiler time; if it is exhausted, all partial aggregate summaries are reset to `unknown`.

This remains a bounded lifecycle-effect analysis. Recursive or unresolved dependencies, ambiguous overloads, alias/return/store/capture paths, methods, dynamic dispatch and FFI remain unknown. It is not a general ownership transfer, borrowing/lifetime proof, happens-before relation or data-race-freedom guarantee. No API, Runtime source or ABI change.



V126 extends the runtime thread handle with a task lifecycle state (`Starting`, `Running`, `Succeeded`, `Failed`, `Cancelled`, `Joined`) and a cooperative cancellation flag. This does not change the existing static join analysis: `thread.join` still consumes the handle, while `thread.cancel`, `thread.isDone` and `thread.isCancelled` are non-consuming observations. The analysis does not infer that a callback will poll cancellation or eventually terminate; a cancellation request is not a proof of termination.

## V197 — implicit control-flow lifetime regions

The lexical lifetime tree now includes explicit child regions for `if` arms, each `switch`/`match` case and default arm, and `try`/`catch`/`finally` bodies. This is important for synthetic pattern bindings: their frame-storage provenance is scoped to the case that introduces them, rather than inheriting the enclosing function region. Match-expression result branches are analyzed in the same per-case context during pointer-origin collection. A pointer derived from a match payload therefore cannot be stored into an enclosing pointer variable. Same-case use and verified noescape calls remain supported. Explicit blocks still create nested child regions beneath the control-flow branch. The analysis is still lexical and bounded; it does not implement named lifetime parameters, general outlives inference, reference returns/stores, or a complete alias/lifetime proof.
