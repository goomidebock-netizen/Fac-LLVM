# V262 — body-verified join-only helper paths for value-struct thread handles

V262 aligns strict-ownership checking with the bounded V76 struct-field
lifecycle summaries. A `ptr thread` parameter qualifies as join-only only when
all of its uses in the checked body are direct `thread.join` arguments. A
by-value struct parameter qualifies only when every known raw-pointer leaf is
exactly `ptr thread`, and each such field is unused or passed only to the
builtin join or a uniquely declared, non-generic join-only helper. This allows
known nested field paths and checked `move(aggregate)` call arguments while
retaining fail-closed behavior for observers, retaining calls, overloaded or
generic helpers, aliases, stores/returns, captures and unknown layouts. This
remains lifecycle/retention bookkeeping, not a general ownership transfer
contract, happens-before relation or data-race proof. No Runtime/API/ABI or
`--safe` policy change. See `MEMORY_MANAGEMENT_V262.md`.

---

# V126 — thread task lifecycle and cooperative cancellation

V126 extends the existing `thread.start` handle into an observable one-shot task lifecycle without introducing `async/await`, futures, or a second scheduler API. The runtime state transitions are `Starting -> Running -> Succeeded | Failed | Cancelled -> Joined`. `thread.join` still consumes the handle and propagates the original worker error.

New cross-platform built-ins:

- `thread.cancel(handle) -> boolean` requests cancellation while the task is Starting or Running. It returns false for a null or already-terminal handle. It never forcibly terminates an OS thread.
- `thread.cancelled() -> boolean` is polled inside a `thread.start` callback. Outside such a callback it returns false. The callback must decide where it is safe to stop and return normally.
- `thread.isDone(handle) -> boolean` observes whether the callback has completed (successfully, with a worker error, or after acknowledged cancellation).
- `thread.isCancelled(handle) -> boolean` is true only if the callback observed the request and returned without raising an error. A worker error takes precedence over cancellation.

The handle remains valid until the owning caller invokes `thread.join`. The owner must serialize handle queries and `thread.cancel` with the consuming `thread.join`; using an alias after join or racing these operations against join is invalid. Cancellation is cooperative: a callback that does not poll `thread.cancelled()` continues running, and `join` waits for it. Pool workers used by `thread.parallelFor` do not inherit a `thread.start` task's cancellation token. This is a lifecycle foundation, not a general async/future API or forced cancellation mechanism.

Regression coverage is in `tests/runtime/task_lifecycle.cpp` and `tests/cases/t116_task_cancel.fac`; TSan and ASan/UBSan scripts include the task lifecycle test. Existing `thread.start/join`, `parallelFor` and Worker Pool semantics remain unchanged.

---

# V125 — reusable `thread.parallelFor` worker pool

V125 reuses process-lifetime Runtime workers for the existing synchronous `thread.parallelFor` API instead of constructing and joining a fresh set of `std::thread` objects for every call.

- Workers are created lazily when a call first requests concurrency and grow only to the requested count, capped at 32 and at `std::thread::hardware_concurrency()` (with a one-worker fallback when the host reports zero). A program that never calls `parallelFor` starts no pool threads.
- Each worker owns a FIFO ticket queue. A submitted job places one ticket on exactly `min(iterations, worker limit)` selected worker queues, even if the reusable pool is already larger because of an earlier batch. Submission holds the scheduler mutex; if any queue allocation fails, the partial submission is rolled back before workers can observe it. Worker selection rotates across concurrent jobs.
- A job shares a 64-bit atomic work cursor, so its participating workers dynamically claim indices and every valid index is executed at most once. The caller waits until every ticket has completed before the stack-owned job and borrowed closure can go out of scope.
- A pool worker that calls `parallelFor` recursively executes the nested job inline under a nested FAC error boundary. It does not block waiting for other workers that may be occupied by the parent job. Nested FAC/C++ failures are converted and propagated at the nested call boundary, so an enclosing FAC `try` can catch them.
- If the pool cannot create the requested number of workers or cannot enqueue the complete set of tickets, `parallelFor` raises the established Resource error (8). Partial queue submission is rolled back while the scheduler mutex is held, so no worker can observe an incomplete batch.
- Workers are joined during pool destruction at process shutdown. `parallelFor` remains synchronous; V125 does not add async Tasks, cancellation, futures, task handles, or a public ThreadPool API.

The pool has no general deadlock/starvation proof for arbitrary blocking callbacks. Callbacks should not block waiting for work that can only be scheduled onto the same saturated pool. The pool cap is a Runtime resource policy, not a promise that a requested number of threads will always be available. Regression coverage is in `tests/runtime/parallel_pool.cpp`; the repeated-small-batch benchmark is `benchmarks/parallel_for_pool.cpp` and runs via `make bench-parallel-pool`.

# V124 — concurrency callback error propagation and channel receive safety

# V124 — Concurrency callback error propagation and channel receive safety

V124 closes two Runtime concurrency failure paths without changing public APIs or syntax:

- `thread.parallelFor` now installs a worker-local FAC try/error boundary around each callback loop. A FAC `throw`/`fac_throw` is caught on that worker, its FAC cleanup and temporary stacks unwind to the worker boundary, and the first callback error's message/code are propagated on the calling thread only after every worker has joined. C++ callback exceptions retain the established `thread.parallelFor: callback raised a C++ exception` diagnostic. The worker-side failure record uses fixed storage and does not allocate while capturing the error; the caller then uses the normal FAC error-reporting path.
- `sync.Channel.recv` now allocates and copies the result buffer before popping the queue entry. If result allocation fails, it returns NULL and leaves the message queued for a later retry; successful receives preserve FIFO and wake one blocked sender after dequeue.

Regression coverage extends `tests/runtime/parallel_for.cpp` with eight repeated FAC-error/worker-cleanup rounds, and adds `tests/runtime/sync_chan_oom.cpp`, which uses deterministic malloc fault injection to verify queue preservation. Targeted GCC TSan and ASan/UBSan/LeakSanitizer runs passed `parallel_for`, `sync_chan` and `sync_cell`; the ASan/UBSan run also passed the OOM-retry test. The full Runtime sanitizer scripts were not completed. No Async API, Channel signature, Atomic ordering, Syntax, Standard Library declaration, C ABI or Runtime ABI is changed. This is improved error/lifecycle handling, not a proof of general deadlock freedom or race freedom.

# V91 `random.int` result facts through `auto` value copies

The bounded struct-helper lifecycle resolver now retains the existing `random.int(min, max)` `Int`/`Long` result contract through a direct scalar `var auto` initializer when each bound is proven either from an exact supported scalar expression or from a visible identifier with an already-proven integer type. A later `auto` value-copy may reuse that result fact. The initializer is evaluated against the lexical bindings visible at its declaration; later declarations and sibling scopes do not provide evidence retroactively. Arbitrary calls, computed expressions, non-integer bounds and unresolved identifiers remain unknown. This changes only candidate ranking through `scoreArg`; it does not change worker synchronization, ownership, borrow checking, happens-before reasoning or `--safe` acceptance.

# V90 bounded random.int result facts for helper overloads

The existing `random.int(min, max)` lowering returns `Int` when both source argument types are no wider than 32-bit integers and `Long` when either source integer type is wider. The bounded struct-helper lifecycle resolver now mirrors that rule only when both argument types are proven: direct integer literals/unary forms, explicitly-declared scalar identifiers at the call site, or supported literal-backed `auto` initializers. User-defined call results, floating-point arguments and unresolved identifiers remain unknown. This only affects candidate ranking through `scoreArg`; it is not general function return inference, an ownership proof, a happens-before proof or a data-race guarantee.

# V88 exact-result built-in facts for struct-helper lifecycle summaries

The bounded overload resolver now recognizes result types guaranteed by existing built-ins: numeric/boolean `parse(Type, value)` uses its explicit target, `size(...)` and `sizeof(...)` return `Int`, and `strcmp(...)` returns `Int`. These facts only help choose among struct-helper overload candidates through the normal `scoreArg` ranking. They do not evaluate input strings or infer arbitrary user-defined calls. Unsupported targets, computed expressions and ambiguous candidates remain conservative. This is not a whole-program join, happens-before or race-freedom proof.

# FAC V87 — fixed-result str(...) facts for struct-helper overloads

V87 adds an exact result-type fact for a direct built-in `str(value)` call: its result is `String`, so the existing `scoreArg` ranking can select a matching string helper overload. This complements V86 primitive-cast facts. User-defined function calls and unsupported computed expressions remain unknown; this refines bounded lifecycle-summary candidate selection only and does not prove ownership transfer, happens-before or race freedom. No syntax, API, Standard Library declaration, Runtime source or ABI changed.

---

# FAC V84 — unary scalar-literal facts for struct-helper overload resolution (historical)

V84 extends the call-site lexical resolver to recognize the exact type of one unary operator applied directly to a supported scalar literal. `!false` is known as `boolean`, unary `-1` retains the integer literal type, and `~1` uses the language's integer promotion; these facts participate only in helper overload ranking through the existing `scoreArg`. Nested unary expressions, identifier operands, casts, binary/computed expressions, calls, member paths and globals remain unknown. V83 scalar identifier value-copy support remains unchanged.

This models scalar value copies, not aliases. Function calls (including boolean-returning calls), operators, casts, member paths, globals, unsupported/dynamic declarations and unknown source bindings remain unknown. Candidate viability and ranking continue to use ordinary `scoreArg`. This is bounded lifecycle-summary precision, not general type inference, ownership/borrow checking, happens-before proof or race-freedom proof. No syntax, API, stdlib declaration, Runtime source or ABI changed; no safety flag was weakened.

---

# FAC V82 — bounded scalar facts for struct-helper lifecycle overloads (historical)

V82 extends the call-site lexical resolver with exact facts for local `var auto` declarations initialized directly by scalar literals: integer, floating-point, boolean, character and Unicode-character. The binding becomes visible only after its initializer is evaluated and is then resolved under the same lexical scopes used by V81. Candidate viability and ranking continue to use the compiler's ordinary `scoreArg` mechanism.

An `auto` local initialized by a function call, operator, cast, alias or other computed expression remains unknown. String and null literals are not eligible auto scalar facts. This is narrowly scoped lifecycle-summary precision, not general type inference, ownership/borrow checking, a happens-before proof or race-freedom proof. No language syntax, API, standard-library declaration, Runtime source or ABI changed, and no safety flag was weakened. The V82 regression also verifies that the boolean-returning function initializer remains unknown and that `--warn-unsafe` does not change emitted IR.

---

## FAC V81 lexical-scope-aware struct-helper overload lifecycle summaries (historical)

V81 resolves the primitive type of a simple identifier using the binding visible at the exact helper call site. Its source-order AST walk follows lexical block scopes and the relevant statement scopes, including function parameters/body, nested blocks, `if`/`else`, `for`, `foreach`, `switch`/`match`, and `try`/`catch`. Differently typed declarations in sibling branches no longer poison each other; an inner shadow is removed when its block ends. Match payload and catch bindings shadow outer names but remain unknown primitive facts.

The resolver continues to use the ordinary `scoreArg` overload ranking. It does not infer function-call results (even boolean-returning calls), computed expressions, globals, member paths, inferred/dynamic declarations, indirect targets or unresolved/tied overloads. This is a narrow improvement to the existing bounded worker lifecycle summaries, not general type inference, ownership/borrow checking, a happens-before proof or a race-freedom proof. No language syntax, Cross-Platform API, native/platform-specific API, standard-library declaration, Runtime source or ABI changed; no safety flag was weakened.

The `worker_join_struct_overload_branch_scopes.fac` regression verifies independently resolved sibling-branch declarations. `worker_join_struct_overload_scope.fac` verifies conditional joining through an inner boolean shadow and mandatory joining through the restored outer integer binding. Both check that `--warn-unsafe` output and plain emitted IR are equivalent. The existing boolean-returning helper call regression remains `unknown`.

---

## FAC V80 explicitly-declared identifier overload lifecycle summaries (historical)

V80 extended V79's literal-aware struct-helper resolver with a narrow source-declaration type fact. It scanned the owning free function's parameters and local declarations, using a fact only when every same-name declaration was an explicitly-declared supported primitive with the same exact type. V81 refines that function-wide scan into call-site lexical binding recovery.

The V80 positive fixture used separate `var boolean` and `var int` locals to select corresponding helper overloads. The former branch-shadow regression treated differently typed declarations in separate branches as a conflict and returned `unknown`; V81 replaces it with call-site-specific scope tests. Function-call expressions, inferred/dynamic declarations, globals, member paths, computed expressions, indirect calls and unresolved overloads remain unknown.

---

## FAC V79 literal-aware struct-helper overload lifecycle summaries (historical)

V79 extends V78's dependency-worklist summaries by matching literal argument types while resolving overloaded struct helpers. It reuses the compiler's `scoreArg` ordering rather than assuming all same-name/same-struct-parameter overloads are equivalent.

## V79 overload selection boundary

The analysis knows exact types for literal arguments represented directly in the AST: integer, floating-point, character, string, boolean and null literals. It scores candidates with the same overload score as `pickFunc`. If every argument is statically known, only a unique highest-scoring candidate is used. If non-literal expressions remain unknown, literal facts may discard candidates that cannot accept those literals, but any remaining tie stays `unknown`. It does not infer the type of local identifiers, computed expressions, function values or dynamic dispatch targets.

The regression has `joinByType(struct Slot, boolean)` and `joinByType(struct Slot, int)`: `true` resolves to the conditional-join overload and `1` resolves to the must-join overload. The ambiguous fixture passes a runtime `boolean` identifier, which this specific pass intentionally cannot type-resolve, and therefore remains `unknown`. This is lifecycle-effect precision only; it does not broaden `--safe`, introduce ownership contracts, or prove happens-before/data-race freedom. No syntax, API, Runtime or ABI change.

## V78 historical: dependency-driven summary propagation

The worker lifecycle analysis starts from V74's dotted-path tracking for direct and nested local value-`struct` fields of type `ptr thread`. V75 added explicit whole-aggregate `move(...)` path transfer; V76 added per-field helper summaries for value-struct parameters; V77 added multi-hop fixed-point forwarding. V78 replaces V77's repeated whole-set scan and 32-round cap with a reverse-dependency worklist.

## V78 dependency-driven summary propagation

Eligible free functions are analyzed with all aggregate parameter-field summaries initialized to `unknown`. A call dependency is recorded only when a struct helper resolves uniquely. When a callee's summary changes, its callers are re-queued; unrelated functions are not rescanned. The work budget is deterministic and based on the number of eligible functions and tracked summary fields. If the budget is exhausted before convergence, all partial struct summaries are reset to `unknown`.

The new 40-helper imported-module chain verifies propagation beyond V77's former 32-round ceiling. Recursive cycles, ambiguous overloads, unresolved calls, aliases, aggregate returns/stores, captures, methods/dynamic calls and FFI remain unknown. This is still lifecycle bookkeeping, not a general ownership/borrow contract, scheduler guarantee, happens-before proof or data-race guarantee. No syntax/API/Runtime/ABI changes were made; `--safe` policy has not been weakened.

## V77 historical boundary

V77 used a maximum of 32 whole-set fixed-point rounds. Reverse-declared multi-hop wrappers worked within that bound; longer chains could remain `unknown` even when every helper was uniquely resolvable. V78 removes that arbitrary chain-length cap with caller re-analysis driven by callee-summary changes.

## 1. Performance and safety goals


FAC should offer native threads, async I/O, task execution, parallel loops, atomics, channels and locks without making data races the default user's problem. The intended safe model is ownership transfer or immutable sharing, with controlled mutable sharing through synchronization primitives.

## 2. V45 current facilities

- `thread` supports thread creation/join and parallel loops.
- `sync.Atomic` exposes atomic integer operations.
- `sync.Channel` is a bounded message channel for strings, with timeout and close behavior.
- `sync.Cell` is a synchronized single-string cell.
- `--safe` checks raw pointers/FFI and basic closure isolation for worker-thread APIs.
- `--strict-safe` additionally rejects unverified indirect function-value calls from checked thread closures.
- `--strict-ownership` provides direct borrow overlap checks; it is not a race detector.

Use `--secure` to enable the complete set of currently available V45 guardrails (`--safe`, `--strict-safe`, `--strict-ownership`, and `--strict-move`). This does not upgrade the analysis into a complete proof.

The thread-closure analysis is conservative but incomplete. It does not inspect all behavior hidden inside trusted runtime/stdlib/native modules, function pointers, all dynamic dispatch paths, or foreign code. Passing the static checks is not a proof of race freedom.

## V81 lexical-scope-aware overload facts for struct thread-handle helpers

V81 extends the bounded helper-overload resolver to find the explicitly declared scalar binding visible at the exact call site. The resolver walks function statements in source order, respects lexical blocks, and handles function parameters, `if` alternatives, `for` initializers, `foreach` variables, switch/match case scopes, and try/catch scopes. A local shadow in one branch no longer makes a differently typed declaration in a sibling branch ambiguous; after a nested block ends, the enclosing binding becomes visible again. Match payload bindings and catch variables shadow outer names but are not assigned guessed primitive types.

This is lexical binding recovery for a narrow overload-analysis pass, not full compiler type inference or general control-flow analysis. Function-call results, computed expressions, globals, member paths, inferred/dynamic declarations, unresolved identifiers and overload ties remain unknown. It changes no language syntax, API declarations, standard-library declarations, Runtime source or ABI, and does not weaken `--safe`, `--strict-safe` or `--strict-move`. The resulting join classifications remain lifecycle evidence—not ownership/lifetime or data-race proofs.

## V76 interprocedural value-struct parameter lifecycle summaries

V76 adds bounded per-field summaries for eligible free functions whose value-struct parameters contain direct or nested `ptr thread` fields. A uniquely resolved same-module, imported or module-qualified call applies the callee's effect for each matching field to the corresponding caller dotted path. The helper may call `thread.join(parameter.field)` directly or pass that field to a uniquely summarized direct helper taking `ptr thread`. The flow distinguishes `must-join`, conditional join, unchanged live (`may-outlive`) and unknown effects. Repeating a helper that has already joined the same field is conservatively classified as unknown.

The resolver requires a unique eligible free-function target and a matching actual/formal struct type. Unused/no-op parameters preserve the caller's live handle; unsupported calls, aliases, aggregate returns/stores, lambda captures, recursive aggregate forwarding, ambiguous overloads, methods/dynamic dispatch and FFI remain unknown. Existing `move(aggregate)` call arguments are mapped to the original field paths, while `--strict-move` remains responsible for validating source consumption. V76 does **not** infer ownership transfer from a struct return or establish a general borrow contract. The summary is lifecycle bookkeeping, not runtime scheduling, happens-before or data-race proof. `--safe` continues to reject mutable global payload access. No syntax, API or Runtime contract changed.

## V73 interprocedural thread-handle join summaries

V73 tracks selected direct calls that receive a local `ptr thread` handle. Eligible free functions are summarized per thread-handle parameter, then summaries are propagated through bounded call chains. Same-module and explicitly imported/module-qualified calls are supported when one target is statically resolvable. If a call is overloaded, the analyzer filters candidates using the tracked argument's `ptr thread` parameter type; it still requires a unique remaining candidate. This lets a helper that calls `thread.join(handle)` establish a bounded `must-join` parameter effect for its caller, while branch-dependent joins remain conditional and helpers that leave a handle live preserve the caller's live state.

The pass does not infer method receiver targets, virtual/dynamic dispatch, function-value targets, handle return/store/alias behavior, FFI effects, or arbitrary recursive call-graph summaries. A missing, ambiguous or non-convergent summary becomes unknown. These parameter summaries are not a happens-before proof: they do not establish actual worker completion ordering for arbitrary shared payloads, and they do not prove data-race freedom. `--safe` retains its existing rejection of mutable global payload access. V73 changes no API surface or Runtime contract.

## V72 worker multiplicity and join-aware lifecycle

V72 classifies direct `thread.start` launch sites as per-activation or loop-repeatable and `thread.parallelFor` callbacks as parallel-replicated. A per-activation site may still execute repeatedly when its containing function is called repeatedly; the current pass does not calculate whole-program invocation counts or recursive/indirect call multiplicity.

For a direct local `ptr thread` initialized by `thread.start`, a bounded structured-flow pass follows handle state through sequential blocks, `if` alternatives, loops, switch/match alternatives and function exits. It reports whether all modeled exits join the handle (`must-join`), some path may leave it live (`may-outlive` / `conditional`), analysis is incomplete or ownership escapes (`unknown`), or no direct handle is bound (`untracked`). `thread.parallelFor` is reported `runtime-joined` because the Runtime joins every internal `std::thread` before the call returns. Join status is lifecycle evidence only, not a data-race proof.

Interprocedural handle passing/return, dynamic aliases, detach/cancellation, exact CFG exception cleanup and thread identity remain unresolved. Unknown cases do not become safe by assumption. Mutable global payloads remain rejected by `--safe`.

## V71 whole-program worker registry and cross-worker candidate graph

V71 builds a whole-program static inventory after all loaded function and module/global declarations have been registered. It collects direct `thread.start` and `thread.parallelFor` callback arguments from free functions, methods, module global initializers and static-field initializers. Only direct lambda callbacks are analyzed; a non-lambda callback is retained as an unresolved registry site. Every direct worker closure is scanned together with statically followed named direct calls. This is a conservative inventory of statically visible code, not a dynamic reachability or runtime scheduling graph: even a function that is never called by `main` may contribute a worker site.

Global storage identity is canonicalized by declaring module, so unqualified imported globals and explicit `module.global` / import-alias references are joined into the same per-storage registry. For each storage the compiler reports cross-worker atomic write/read candidates, the Release-to-Acquire subset, Acquire compare-exchange failure candidates, and possible ordinary read/write conflict pairs. A `parallelFor` callback is modeled as potentially replicated across workers, so distinct atomic sites inside one callback can form `parallelFor-self-*` candidates. Analysis failures are counted as `unresolved-sites`; already discovered partial effects remain in the summary.

All graph edges are may-candidates only. Static launch-site identity is not runtime thread identity, and the current pass does not prove how many times a `thread.start` site executes, whether two sites overlap in time, whether `join` creates an ordering edge, what value an acquire actually reads, modification order, release-sequence membership, synchronizes-with or happens-before. Arbitrary pointer alias equivalence, function-value targets, dynamic dispatch, FFI, and trusted runtime/stdlib behavior remain outside this proof. `--safe` continues to reject mutable global payload access, even when the candidate graph identifies atomic operations or locks. No source syntax, public API, Runtime source or ABI changed in V71.

## V70 read-from and release-sequence candidate analysis (historical)

V70 extends the V69 graph with a per-storage **may-read-from** relation. Every statically recognized atomic modification (store, RMW or compare-exchange) is considered a possible source for each distinct atomic read on that resolved storage. The analysis counts all read-from candidates separately from Release-to-Acquire candidates, and marks Acquire-capable compare-exchange failure loads independently. It also reports possible RMW bridge triples that could lie between a release modification and an acquire read in a release-sequence scenario.

Events retain the checked worker-closure template and their followed direct-call path; deduplication uses both worker-template identity and AST call-site identity. A worker template is **not** a runtime thread ID: parallel iterations may instantiate the same closure many times. The pass does not infer modification order from source order, assign a concrete read-from source, establish a release sequence, or produce synchronizes-with/happens-before edges. The RMW bridge count is possibility evidence only. `--safe` continues to reject mutable global payloads.

## V69 atomic synchronization graph candidates

V69 builds a bounded per-global event graph from statically recognized atomic call sites reachable in one checked worker closure and its followed direct-call graph. Nodes retain source location, operation name, read-side order, write-side order and compare-exchange failure order. For distinct nodes on the same resolved storage, a Release-capable write and an Acquire-capable read (including an Acquire compare-exchange failure load) produce a directed **candidate** edge. SeqCst event pairs are counted separately. Call-site identities are deduplicated when a helper is reached more than once.

The V69 graph was an initial Release-to-Acquire candidate graph. V70 adds all may-read-from pairs and possible RMW bridge diagnostics, but neither version proves which write an acquire reads, enumerates all worker executions, or proves arbitrary pointer aliases/FFI effects. `--safe` continues to reject mutable global payloads.

## V68 atomic memory-order summaries

V68 records the atomic contract for known `thread.atomic*` calls in the `--safe` worker effect summary. The read and write sides are tracked separately: an Acquire RMW reads with Acquire and writes with Relaxed semantics; a Release RMW reads with Relaxed and writes with Release; AcqRel applies to both sides. Compare-exchange records both its success order and failure-load order: Relaxed/Relaxed, Acquire/Acquire, Release/Relaxed, AcqRel/Acquire, and SeqCst/SeqCst. Legacy `atomicGet`, `atomicSet`, `atomicAdd`, and `atomicCas` remain SeqCst; explicit `*SeqCst` names are aliases for code that wants the order visible at the call site.

The summary can identify release-capable write effects and acquire-capable read effects that are both observed for a global, and it reports mixed ordinary plus atomic access as a potential data race. This is **not** a synchronizes-with edge or a happens-before proof: a real edge requires establishing that an acquire operation reads from the release operation (or its release sequence), and this pass does not yet solve cross-thread read-from relations, alias equivalence for arbitrary pointers, or all possible executions. Consequently, mutable global payloads continue to be rejected in `--safe` worker closures. No Runtime source, ABI or raw atomic implementation changed; the new SeqCst names lower to the existing SeqCst runtime symbols.

## V67 lock-aware effect propagation

V67 propagates the held-lock set at a direct call site into the analyzed callee, so a helper called while a caller holds `gate` records its ordinary global accesses under that same observed lock context. Every analyzed callee must return with the lock set it received; functions that acquire/release inconsistently, shadow an inherited lock name, use a mutex expression whose identity cannot be resolved, or alter lock state inside a loop are rejected. Direct mutex operations inside a `try` region are also treated as unknown because exceptional cleanup paths are not modeled by this bounded pass.

Each global effect retains the union of observed lock identities and the intersection common to all ordinary accesses. Thus two helpers that access one global under different mutexes report `no common lock`, and a mix of locked and unlocked accesses reports `unprotected ordinary access`. Global mutex identities are qualified by their declaring module; local identities are scoped to the analyzed function body. Branch merges retain only locks present on every branch.

These are analysis facts for diagnostics only. The pass still cannot enumerate all concurrent accesses in the whole program, prove arbitrary alias equivalence, certify FFI/trusted code, or construct atomic happens-before edges. `--safe` continues to reject mutable global payloads even when all observed ordinary accesses share one lock. No Runtime/ABI/API or source syntax changes were made.

## V66 typed concurrency effect summaries

V66 adds a bounded effect summary to the `--safe` worker-closure call-graph scan. Each reachable mutable global is classified by type and by observed access: ordinary `read`, `write`/`read-write`, address/alias exposure, or atomic read/write through recognized `thread.atomic*` calls. The scan separately records `mutex.lock` and `mutex.unlock` and attaches the active lexical lock names to direct global accesses within the same checked function body. It propagates the storage effects through statically followed named calls and methods.

The summary is not a whole-program race proof. In particular, it does not prove that every read/write of a global uses the same lock, that every path releases the lock, that aliases cannot escape through unmodeled calls, or that atomic operations form the required happens-before relation. It therefore still rejects mutable global payload access from a `--safe` worker closure, including accesses marked `atomic` or observed under a lock. A mutex handle used only for lock/unlock is summarized as a synchronization primitive, but that does not certify the data it protects. Unknown FFI/trusted-module behavior remains outside the proof.

## 3. Memory-order contract

Atomic APIs expose their ordering through the function name. The legacy names remain sequentially consistent for compatibility, with explicit `*SeqCst` aliases available. The supported orderings are exposed consistently across the operation families:

- `Relaxed`: atomicity only; no ordering of unrelated memory.
- `Acquire`: a load that may synchronize with a release operation only when it reads from that release or its release sequence.
- `Release`: a store that may publish earlier writes to an acquire observer that reads the published value or its release sequence.
- `AcqRel`: acquire + release for read-modify-write operations.
- `SeqCst`: sequentially consistent global order among sequentially consistent operations.

Invalid combinations (for example, release semantics for a pure load or acquire semantics for a pure store) are not exposed as API variants; compare-exchange failure orders are fixed to valid combinations and documented above.

## 4. Synchronization requirements

1. A mutable object shared by threads must be protected by a lock, atomic protocol, channel ownership, or a future verified synchronized type.
2. `volatile` is not synchronization.
3. Never hold a runtime lock while calling arbitrary user callbacks unless reentrancy is part of the contract.
4. Channel close, cancellation, timeout, and shutdown behavior must wake all blocked parties and must be testable under repeated races.
5. `async` tasks need explicit cancellation and destructor rules; task cancellation must not silently leak or double-destroy owned values.
6. GPU queue/resource synchronization is a separate memory domain and must not reuse CPU atomic guarantees without a defined bridge.

## 5. Proposed syntax direction

These examples are **design proposals**, not V45 compiler features:

```fac
shared obj Counter counter = new Counter()

synchronized (counter) {
    counter.value = counter.value + 1
}

async function Result<Response, NetError> fetch(Request request) {
    return await net.send(request)
}

var Task<Result<int, Error>> task = spawn compute()
var Result<int, Error> result = await task
```

The compiler must not accept `shared` or `async/await` as operational safety features until the runtime, scheduler, ownership transfer and cancellation semantics exist.

## 6. Static Data-Race Analysis roadmap

A sounder analysis needs a typed call graph plus effect/alias summaries, not just matching method names. Minimum requirements:

- distinguish immutable reads, mutable writes, allocation, I/O, lock acquisition and unknown effects;
- propagate effects through direct, indirect, virtual, generic and FFI calls;
- associate lock guards with protected storage and reject unsynchronized access;
- verify closure captures and transferability (`Send`-like rules);
- model atomics with explicit memory-order edges;
- report uncertain/foreign effects rather than silently treating them as safe;
- add ThreadSanitizer tests, stress tests, deterministic scheduler tests and static negative tests.

Until then, `--safe` and `--strict-safe` are guardrails, not a whole-program race-free proof.


## V48 Thread error propagation

`thread.start` retains its closure for the full worker lifetime and installs a worker-local FAC error handler. A FAC `throw` from the worker is captured with its original code; an uncaught C++ callback exception becomes `Resource` (8). Both are re-raised by `thread.join` on the joining thread. Join still consumes the handle. This is error propagation, not async scheduling or cancellation. ThreadSanitizer coverage is required for changes to this path; passing tests for this API is not a whole-program race-freedom proof.

## V47 Runtime hardening

`thread.parallelFor` originally created per-call workers, reserved worker storage before launching, and joined every successfully-created worker if a later launch failed. It has since been superseded by the V125 reusable pool described at the top of this document. The V124 worker-local FAC error boundary also supersedes the original limitation noted here: FAC callback errors are captured on the worker, cleanup runs, all submitted work is joined, and the first failure is re-raised on the caller. The separate warning about arbitrary FFI C++ frames remains applicable: FAC's non-local error transfer must not bypass non-trivial C++ automatic objects outside the protected Runtime boundaries. See [RUNTIME.md](RUNTIME.md).


## V52 static race-analysis status

V53 added local borrow checking and V54 added bounded last-use loan expiration; neither adds a whole-program data-race proof. `--safe`/`--strict-safe` continue to use conservative worker-closure isolation and call-graph checks, while `--strict-ownership` checks direct-call borrowing contracts and lexical local borrow loans. V67 now propagates observed lock context through direct calls and computes common-lock/unprotected classifications on top of V66 typed global read/write/alias/atomic effects; it still does not establish persistent lock ownership, alias sets through arbitrary pointers, atomic happens-before graphs, or race freedom through FFI and trusted Runtime/stdlib code. CPU atomics, channel/cell synchronization and GPU synchronization must remain distinct domains. The current acceptance criteria and remaining whole-program race-analysis gaps are listed in [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md).

## V75 — explicit aggregate move and worker join attribution

The worker lifecycle pass follows an explicit whole-value `move(sourceAggregate)` for a managed local value struct containing `ptr thread` fields. It transfers tracked dotted-path state to the destination and rebinds the launch-site handle path so a join through the destination field is associated with the original worker. This is bounded to local value structs and existing direct worker/join analysis. Copies, conditional/unknown transfers, aliases, parameters/returns, class fields, arrays, indirect calls and FFI remain conservative; this is not a happens-before or race-freedom proof. Raw `ptr thread` leaf-field partial moves remain rejected by strict-move. No API or Runtime change.
