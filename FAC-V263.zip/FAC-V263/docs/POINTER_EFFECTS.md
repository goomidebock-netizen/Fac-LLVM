# FAC pointer parameter effects — V61

FAC currently has two independent compile-time effects for by-value raw-pointer parameters. They are checked by `--strict-ownership` and enabled by `--secure`. They do not add runtime instructions, change a pointer's representation, or alter the native calling convention.

## `noescape`: pointer retention

```fac
function void consume(noescape ptr int data) {
    terminal.out.println([data])
}
```

`noescape` promises that the pointer value and pointer values derived from it are not retained beyond the dynamic call. A verified FAC body is checked for return, persistent/global/field/container stores, closure capture and forwarding to a call without a verified `noescape` parameter. An `extern` declaration is a trusted FFI promise; its foreign implementation is not inspected.

## `readonly`: writes through the pointer

```fac
function int readValue(readonly ptr int data) {
    return [data]
}
```

`readonly` promises that the body does not modify memory through this pointer. Direct dereference/index/member writes and increments are rejected. A pointer derived from the parameter may be forwarded only to a call whose relevant parameter is verified `readonly`. The current checker conservatively rejects copying the parameter into a local pointer alias, capturing it in a closure, or invoking methods through a dereferenced readonly pointer receiver because receiver effects are not yet verified. Dereferencing/indexing to obtain a pointee value is allowed; passing the pointer value itself to another call still requires a verified readonly contract.

`readonly` does not promise non-retention. A pointer may still escape unless the parameter also has `noescape` and the escape checker accepts the path.

## Combining effects

For a stack-derived pointer that a callee should only read during the call, use both modifiers:

```fac
function int readNow(readonly noescape ptr int data) {
    return [data]
}

public function void main() {
    var int value = 41
    terminal.out.println(readNow(addr(value)))
}
```

The parser accepts either order (`readonly noescape` or `noescape readonly`). The effects are independent: `noescape` controls retention; `readonly` controls writes through the pointee. Since V64, both effects can also be written in an explicit function-value signature, e.g. `function void callback(noescape ptr int, readonly ptr int)`. V208 additionally allows the same function-value signature to carry named pointer lifetimes; V209 carries those contracts into statically typed callback fields on aggregates. Neither release changes the `noescape` proof boundary.

## Contracts, overrides and dispatch

An abstract class or interface may declare an effect contract without a body. A concrete implementation must preserve every promised effect: it may not drop a base/interface `noescape` or `readonly` promise. A concrete implementation may provide a stronger promise. This rule is checked for class overrides and interface implementations so a virtual dispatch target cannot silently weaken a statically visible contract.

V65 resolves direct-call ownership effects against overloads selected by known argument types. The checker retains parameter types with `ref`, `noescape` and `readonly` metadata, including pointer pointee types; an exact `ptr T` match outranks a generic pointer-compatible candidate. The selected candidate's effects are applied to pointer provenance, readonly forwarding and local-borrow checks. Unknown argument types or unresolved ties remain fail-closed: every arity-compatible candidate must satisfy the effect. This is still a bounded direct-call analysis, not whole-program overload or virtual-dispatch proof. V64 carries `noescape` and `readonly` metadata through explicit function-value signatures and checks compatible callback assignments. V208 adds named-lifetime contracts to callback types and validates those contracts at statically typed indirect call sites. V209 also applies those lifetime contracts when calling a function-valued `struct`/`class` field through a statically known direct or nested member path. Indirect-call pointer escape proof for `noescape` remains conservative: a signature annotation alone does not establish the concrete target body as verified.

## FFI trust boundary

```fac
extern function int foreignRead(readonly noescape ptr int data)
```

Both annotations on `extern` are trusted promises. The compiler cannot prove foreign code does not retain or write through the pointer. A false annotation invalidates the corresponding safety assumption, including in `--secure` builds. Use the annotations only when the foreign API contract and implementation have been audited.

Since V205, named lifetime annotations and `where longer: shorter` clauses on `extern function` are trusted FFI promises as well. They are instantiated and checked at resolved direct call sites, but the compiler cannot inspect the foreign implementation to prove that a returned pointer really derives from the declared parameter or that the implementation respects the declared outlives relation. See [`FFI.md`](FFI.md#lifetime-contracts-สำหรับ-ffi-v205).

## Current proof boundary

These are bounded source-level checks, not a complete effect system or raw-pointer verifier. They do not prove non-nullness, bounds, alignment, validity, noalias, thread safety, synchronization, `nothrow`, or absence of writes through hidden aliases, global state, opaque FFI, inline assembly, pointer/integer round trips or untracked indirection. `readonly` expression analysis is conservative and does not yet support local pointer aliases or closure capture. `noescape` propagation is for statically known direct calls, not indirect callbacks. V208 indirect lifetime contracts constrain returned-pointer provenance and caller-region relationships, but do not establish non-retention; callbacks without a separately verified direct `noescape` path remain fail-closed for frame-derived pointer escape.
