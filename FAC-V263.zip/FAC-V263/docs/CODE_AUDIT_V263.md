# FAC V263 — focused source-code audit

## Finding

**Severity: Medium — pointer-bearing value structs could not be forwarded through a verified noescape helper**

The V262 call-boundary checks had a specific, body-verified exception for
`ptr thread` fields passed to join-only helpers. Other pointer fields in a
by-value value struct had no corresponding forwarding summary. As a result,
a safe wrapper that used a nested pointer field only as the direct argument to
a helper with an exact `noescape` pointer parameter could be rejected as an
unknown aggregate-pointer escape.

## V263 change

- `CallParamContract` now records `aggregatePointerFieldsNoescape` separately
  from the dedicated thread-handle join-only contract.
- The compiler recursively resolves nested value-struct field layouts and
  records exact pointer-field paths and pointer types. Unknown/cyclic layouts,
  `ptr thread`, pointer-bearing containers/arrays and opaque pointer layouts
  remain outside this rule.
- A by-value struct parameter receives the summary only when the checked body
  uses every pointer-bearing leaf exclusively as the direct argument to a
  uniquely resolved, non-generic helper parameter with an exact matching
  pointer type and verified `noescape` contract. Overloads, generic helpers,
  aliases, whole-aggregate use, returns/stores/captures, direct pointer-field
  use, unsupported projections and non-noescape helpers fail closed.
- The pointer-origin/call-boundary analysis applies the summary only when all
  selected call-contract candidates carry the verified fact. The local borrow
  checker seeds only the exact pointer-field paths admitted by this summary.
- The existing `ptr thread` join-only rule remains independent; this change
  does not broaden thread-handle forwarding.
- The positive nested-struct regression compiles and runs, producing `41`.
  The negative retaining-helper regression is rejected under
  `--strict-ownership`.
- Updated `tests/ownership/noescape/run.sh` to include both regressions.
  Added `SEMANTIC_CXXFLAGS` override to the Semantic harness, defaulting to
  C++17 `-O0 -g0`, so test-build optimization settings can be adjusted without
  changing test semantics.

No syntax, public API, Runtime source/semantics, C ABI, Runtime ABI or
`--memory-safe` accepted subset was intentionally changed. This does not
implement general pointer provenance, general heap escape analysis, pointer
container provenance, arbitrary aggregate escape summaries, or a complete
borrow checker.

## Regression tests

- `tests/ownership/noescape/good_noescape_struct_field.fac`: nested
  `PointerBox.nested.value` is passed only to an exact `readonly noescape
  ptr int` helper; executable output is `41`.
- `tests/ownership/noescape/bad_noescape_struct_retaining_helper.fac`: a
  pointer field passed to an ordinary `ptr int` helper is rejected.
- `tests/ownership/noescape/run.sh`: 20 passed, 0 failed.
- `tests/run_safe.sh`: 438 passed, 0 failed.

## Validation

- Clang 17 / C++17 Release build completed; the Runtime object/archive were
  rebuilt. All seven version surfaces report V263 and `tools/check_versions.py`
  passes.
- Ownership/local-borrow/effect suites: Ownership 12/12; const-method
  ownership 8/8; Local Borrow 167/167; noescape 20/20; Field-sensitive Borrow
  25/25; Effect Contract 19/19; Function Effect 13/13.
- Safe Profile 438/438; Move 20/20; Partial Move 28/28; Compile-time 57/57;
  Memory-Safe 39/39; Generic 3/3; Lexer 18/18; Parser 68 + AST 1/1; Codegen
  passed.
- Full Runtime runner completed successfully with exit code 0 in this Linux
  environment. Tools 91/91; Negative 134/134; Limits 21/21.
- Semantic component tests were run individually and passed, including 17
  ancestry checks, HIR/model and typed-expression tests, generic inference and
  generic free-function tests, scope/overload tests, declaration/body codegen,
  and generated LLVM IR compilation with Clang. The combined Semantic runner
  did not finish within the execution limit while compiling its final
  generated-function-body fixture, so a full uninterrupted Semantic-suite
  pass is not claimed.
- Standards check: 5 OS families and 6 architecture families; Formatter
  passed; API manifest current; API audit 663 built-ins + 1,014 source
  declarations, 5 findings all in baseline and 0 new; API contract audit 950
  public source functions with 0 missing annotations; compatibility against
  V128: 0 breaking changes and 132 existing warnings; 114 generated API docs
  current.
- Sanitizers, full CMake/CTest, Windows/macOS build and runtime testing, and
  production qualification are not claimed.
