# FAC Memory Management Direction — V233

V233 adds a bounded escape proof for closures that capture pointers or pointer-bearing local value structs. It does **not** add general closure lifetime types, general heap escape analysis, or closure storage into longer-lived containers/globals.

## 1. Local direct-call-only closure binding

A lambda may capture a pointer with known provenance only when all of the following are true:

1. The lambda is the direct initializer of one local function-valued variable in the current function.
2. The source regions of every possible pointer origin outlive the lexical region containing that local closure binding. The normal lifetime-region graph is used, so explicit named input lifetimes and enclosing lexical storage are handled by the same `regionOutlives` relation.
3. Every use of the function-valued variable in the owning function is a direct call through that variable as the callee.
4. The function value is not copied, assigned, returned, passed as an argument, stored in an aggregate, captured by another closure, or shadowed by another declaration with the same name.
5. None of the captured origins comes from a `noescape` parameter, and no origin is Unknown.

The use scan is deliberately conservative and name-based. If it cannot uniquely find the direct local initializer or prove the direct-call-only use pattern, it rejects the capture. Capturing a pointer from a shorter-lived inner scope remains rejected even if the callback is called locally.

## 2. Pointer-bearing value structs

The existing exact per-field provenance requirement remains. A pointer-bearing local value struct may be captured by the same bounded local closure only when every pointer-field fact is complete and every possible origin outlives the closure binding's lexical region. Pointer-free structs and structs whose pointer fields are all Verified Null retain their existing behavior. Unknown field provenance is never treated as Null.

## 3. Conservative boundaries

V233 does not permit a pointer-capturing closure to escape through a return, copy, parameter/argument, global, aggregate field, container, another closure, or indirect storage. Passing a function value to an unknown callback remains unsupported even when the caller expects it not to retain the value. `noescape` pointer inputs cannot be captured because storing their pointer in a closure payload is retention. Unknown provenance and origins from shorter-lived regions remain rejected.

The proof does not establish general closure non-escape for arbitrary expressions, closure-to-closure lifetime propagation, recursive closure capture, closures stored in managed objects, heap alias analysis, whole-program escape analysis, or data-race freedom. The `--memory-safe` accepted subset is unchanged; raw pointers and `addr` remain outside that profile. No FAC source syntax, Runtime, ARC, Cycle Collector, public API, C ABI, or Runtime ABI changed.

## 4. Regression coverage

V233 adds positive runtime fixtures for:

- a local pointer to a same-scope local value captured and invoked directly;
- a named-lifetime pointer parameter captured by a local closure and invoked directly;
- a local value struct with a verified pointer field captured and invoked directly;
- the earlier local pointer-bearing aggregate capture case, now accepted under the bounded proof.

Negative fixtures cover closure copies, argument passing, a pointer whose referent came from a shorter-lived inner scope, and capture of a `noescape` pointer parameter. Existing V231 unknown-provenance tests remain rejecting.


## 5. Validation

Validation on Linux x86-64 with GCC 14.2 C++17 (`-O0 -g0` Compiler build): Compiler reports V233 for every component; Lifetime 112 checks; ownership 261 checks; secure profile 6/6; move/partial-move 48 checks; `--memory-safe` 39/39; Tools 91 tests (6 skipped, no failures); parser 68 checks plus AST model 1/1; lexer 18 checks; focused codegen checks passed. Full CMake build completed and CTest passed 37/37, including Runtime safety/cycle-collector/concurrency regressions, fuzz regressions and package install consumer. `make fmt-check`, `make standards-check`, `make api-check` and version checks passed; API audit reported 0 breaking changes and 132 compatibility warnings against V128, with 5 existing baseline findings and 0 new findings. Sanitizer qualification, cross-platform testing and production qualification are not claimed.
