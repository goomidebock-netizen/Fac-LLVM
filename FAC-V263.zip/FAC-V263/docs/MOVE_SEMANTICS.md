# FAC V40 — explicit managed-value moves

`--strict-move` enables the `move(local)` expression for a managed local value. It transfers the value out of the source slot, clears the source slot, and returns an owned temporary that can be stored or returned without an additional retain/copy.

```fac
import terminal.fac

public function void main() {
    dyn string source = "one owner"
    dyn string destination = move(source)
    terminal.out.println(destination)

    // Reinitializing the source creates a new live value.
    source = "new value"
    terminal.out.println(source)
}
```

Supported managed types are strings, lists, managed data structures, function/closure values, class objects, weak object handles, managed structs, and managed payload enums. The source must be a mutable local variable with compiler-managed cleanup. A move from a parameter, `self`, a global, a field, a heap-managed variable, or a non-managed value is rejected.

## Static checks

With `--strict-move`, the compiler rejects direct uses after a move, repeated moves, and moves whose safety cannot be established in the currently supported control flow. Assignment to the moved local reinitializes it. Branches merge conservatively: when one branch moves a value, the value is considered moved after the branch unless it is reinitialized on all paths.

V40 deliberately rejects moves inside loops, `defer`, and lambda bodies. The current checker operates on named local identifiers; it is not a complete ownership/borrow/lifetime system and does not prove safety across arbitrary aliases, raw pointers, FFI, dynamic dispatch, or concurrent mutation. Continue using `--safe`, `--strict-safe`, and `--strict-ownership` as separate checks where applicable.

## Recommended use

Use `--strict-move` during development and CI. Keep ownership transfers explicit at API boundaries, reinitialize moved locals before reuse, and prefer distinct variables rather than relying on aliasing. Do not assume this flag replaces API-level lifetime design or unsafe-boundary review.


## V63 — nested value-struct partial moves

`move(record.inner.payload)` is supported when the path starts at a direct local mutable value `struct`, every intermediate field is another value `struct`, and the final field is a managed handle or managed value struct. It extends the earlier `move(record.field)` form without changing `move(local)`.

The compiler tracks each dotted path by owner declaration identity. Sibling paths may be moved independently; the same path and any parent/child path overlap. Reads of a moved path and uses of a containing aggregate are rejected. Reassigning the moved path, or replacing a containing subaggregate, restores initialization state. Branch and exceptional CFG merges remain conservative.

A moved leaf handle is set to null; a moved nested struct is copied out and zeroed. The existing recursive drop helpers and cleanup stack then handle ordinary scope exit and exception unwinding. This remains a bounded subset: no array/index moves, enum payload moves, class/object traversal, scalar/raw-pointer moves, heap or indirect roots, or general partially initialized aggregate bitmap. See [`OWNERSHIP.md`](OWNERSHIP.md) and [`MEMORY_MODEL.md`](MEMORY_MODEL.md).


## V164 — managed payload-enum field moves

The final field of a supported local value-struct path may now be a managed payload enum, such as `enum Option<string>`. For example, `move(envelope.detail.payload)` transfers the enum (including only its active payload) into an owned local and writes a zero-initialized sentinel to the source field. The ordinary recursive struct drop callback then safely drops the remaining fields and ignores the moved-from enum sentinel. Reinitializing the moved field restores the corresponding projection state.

All earlier path restrictions remain: the root must be a directly owned mutable local value struct, intermediate fields must be value structs, and the final enum must be a managed payload enum. Unit enums, scalar values, arrays/indexes, raw pointers, classes/objects, heap/indirect roots, parameters and borrow aliases are not accepted. This does not add a general per-element or runtime drop-flag bitmap.
