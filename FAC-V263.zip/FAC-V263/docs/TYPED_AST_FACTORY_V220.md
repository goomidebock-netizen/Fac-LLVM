# FAC V220 — Internal Typed AST Factory

## 1. Scope

V220 extends the immutable typed-expression AST projection with a compiler-internal factory: `fac_hir::TypedAstFactory`. It can append generated expression nodes to an already validated `SemanticModel::typedAst`. The factory is a C++ compiler API, not a FAC source-level API, macro facility, plugin API or general compile-time execution engine.

Generated nodes are marked `TypedAstOrigin::Generated`, use `kInvalidExpr` because they have no parser-owned source expression, and carry a caller-supplied `SourceLocation` for diagnostic provenance. Node objects and child references remain immutable (`shared_ptr<const TypedAstNode>`). IDs are assigned deterministically in append order and each child must already belong to the same typed-AST model.

## 2. Factory operations

The initial factory supports:

| Operation | Typed AST kind | Contract |
|---|---|---|
| `integerLiteral(value, type)` | `IntLiteral` | Requires a builtin integer TypeId (not enum) |
| `floatingLiteral(value, type)` | `FloatLiteral` | Requires `float` or `double` |
| `characterLiteral(codePoint, type)` | `CharLiteral` | Requires `char` or `unichar` |
| `booleanLiteral(value, type)` | `BoolLiteral` | Requires `bool` |
| `stringLiteral(value, type)` | `StringLiteral` | Requires the FAC `string` type |
| `nullLiteral(type)` | `NullLiteral` | Requires `null`, pointer or heap type |
| `unary(op, operand, resultType)` | `Unary` | Validates the supported unary operator/type combination |
| `binary(op, lhs, rhs, resultType)` | `Binary` | Validates supported operands and result type; numeric operands must have the same structural type |
| `tuple(elements)` | `Tuple` | Interns a tuple type from the element TypeIds |
| `call(symbol, arguments)` | `Call` | Requires a pre-resolved, exact, non-generic free-function signature |

The factory conservatively propagates side-effect metadata. Literals have no side effects; unary/tuple nodes inherit child effects; binary nodes combine child effects; generated calls are considered effectful. Calls preserve the resolved `SymbolId` and qualified function name.

Usage sketch inside compiler code:

```cpp
fac_hir::TypedAstFactory factory(semanticModel); // model must already validate
auto left = factory.integerLiteral(19, intType, {"generated.fac", "app", 1});
auto right = factory.integerLiteral(23, intType, {"generated.fac", "app", 1});
auto sum = factory.binary("+", left, right, intType);
if (!semanticModel.validate())
  throw std::logic_error("generated typed AST failed validation");
```

The factory mutates only the owning `TypedAstModel` container by appending new immutable nodes and updating its root/summary indexes. Existing nodes and child edges are not modified.

## 3. Semantic and ownership checks

Before a node is appended, the factory checks:

- every child is non-null and belongs to the same `TypedAstModel`;
- every result/operand TypeId is valid in the model's `TypeArena`;
- literal TypeIds match the literal category;
- unary/binary operator contracts are supported by the factory;
- tuple component TypeIds match the interned tuple descriptor;
- calls refer to an existing function declaration, take an exact argument count and exact parameter TypeIds, and have the declared return TypeId.

The call API deliberately does not perform name lookup, overload selection, import filtering, visibility resolution, generic substitution, implicit conversions, default-argument filling or variadic packing. Its `SymbolId` must have been resolved by the compiler pipeline before the factory is invoked. `SemanticModel::validate()` rechecks generated call target identity and signature consistency.

Generated nodes are appended after their children. When a generated parent consumes existing roots, root metadata is updated; the underlying source/generated nodes are never modified. `TypedAstModel::validate()` checks node identity, source/generated origin, TypeIds, child ownership and ordering, generated-node accounting, tuple layout and tree roots. `SemanticModel::validate()` additionally checks generated call declarations.

## 4. Important boundary

This feature only constructs immutable expression nodes inside the compiler's semantic model. It does **not**:

- expose AST values or factory calls to FAC programs or `consteval`;
- create/modify source `Node` objects or parser declarations;
- generate declarations through the expression factory; a separate internal `TypedDeclarationBuilder` supports a bounded struct/free-function HIR subset (see [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md));
- independently add arbitrary generated expression roots to code generation or emit executable code (a restricted subset can be consumed as part of a committed generated function body; see [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md));
- perform overload resolution, access control or implicit conversions on behalf of callers;
- construct assignment/control-flow/match/lambda/member/index expressions, generic calls or method calls. The separate function-body builder now represents mutable-local assignments and nested `if/else` as typed statements; it does not add these as mutable expression nodes.

The expression factory alone does not emit standalone expression nodes. A separate `TypedFunctionBodyBuilder` can assemble a restricted subset into a validated scalar body for a generated non-generic free function, including mutable locals, exact-TypeId assignments and nested if/else regions; the bounded Codegen projection then consumes that body without mutating the original source AST. This does not expose AST construction to FAC programs or `consteval`. Broader acceptance requires loops, multiple return paths, branch-local declarations, classes/methods/generics, imported-type and access contracts, source maps, ownership/lifetime validation, resource budgets and fuller post-generation semantic analysis.

## 5. Regression coverage

`tests/semantic/typed_expr_hir.cpp` exercises source projection and generated construction for integer, floating, character, string, boolean and null literals; unary/binary expressions; tuples; and a pre-resolved function call. It verifies synthetic source location, generated origin, immutable node fields, side-effect propagation, model validation and rejection of mismatched operand types, wrong literal TypeIds and children from another model.

Validation commands:

```sh
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O0 -g0' -j1
make runtime-only CXX=g++ CXXFLAGS='-std=c++17 -O0 -g0' -j1
sh tests/comptime/run.sh
sh tests/parser/run.sh
g++ -std=c++17 -O0 -g0 -I. tests/semantic/typed_expr_hir.cpp -o /tmp/fac_typed_expr_hir
/tmp/fac_typed_expr_hir
sh tests/run.sh -O0
sh tests/run.sh -O2
```

The current Linux validation snapshot is recorded in `docs/STATUS.md`. It is not cross-platform qualification.
