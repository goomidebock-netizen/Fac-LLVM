# FAC LLVM V134 — Security, Memory-Safety and Performance Audit

**Release:** V134  
**Scope:** Compiler option processing and AST gate, FAC Runtime ownership/refcounts, built-in API exposure, native/FFI boundaries, build/test integration, and selected performance paths.  
**Audit type:** source review plus targeted regression, sanitizer and differential tests. This is not a formal verification, certification, or third-party penetration test.

## Executive summary

V134 introduces an opt-in `--memory-safe` source profile. It is intentionally fail-closed and rejects a restricted set of facilities whose pointer, lifetime, native-handle or ABI behavior is not yet fully checked by FAC. The compiler enables strict Ownership/Move checks and bounds, division and integer-overflow checks in this profile. It rejects raw/opaque pointers, manual heap storage, raw memory/function-pointer primitives, all `ref` borrows, `unsafe`, extern/export/link declarations, native inputs/link flags, built-in modules whose public signatures expose raw native handles, and the process-capable `sys` module.

This is meaningful defense-in-depth, but **it is not equivalent to Rust's safe subset**. FAC still lacks a complete borrow/lifetime/type system, a whole-program data-race proof, and a verified Runtime. Its FAC error transfer still uses `setjmp`/`longjmp`; that is not C++ destructor unwinding. The C++ Runtime and all code-generation paths remain part of the trusted computing base.

No general Runtime speedup is claimed in V134. Normal compilation emits byte-identical LLVM IR to V133 for the five differential fixtures tested with the same GCC toolchain. The new safe-profile AST gate has measurable compile-time cost, quantified below.

## Changes implemented

### 1. Fail-closed language profile

- Added `--memory-safe` and CLI help.
- The option enables `--safe`, `--strict-safe`, strict Ownership/Move, `--no-trust-stdlib`, and signed integer overflow checks. Existing bounds and division checks remain enabled.
- The AST/type walk rejects raw/opaque pointer and manual heap types, volatile storage, pointer dereference/address exposure, manual allocation/free, C function-pointer and raw memory primitives, `ref`/`ref const` parameters and locals, `unsafe`, `extern`, exported native ABI, and native link directives.
- Command-line native inputs, objects, packages, external linker flags, native/shared outputs and generated native headers are rejected in this profile.
- The checker indexes the built-in API table and rejects imports or references to modules exposing raw native pointer/handle signatures. It also rejects `sys`, `sys.run` and `sys.output`, including import aliases, to close process-execution bypasses.
- Pure built-ins such as `math` remain available where their declarations do not expose excluded handles.

This policy intentionally rejects some APIs that could be safely wrapped. The objective is a small auditable subset, not maximum compatibility.

### 2. Runtime refcount stress coverage

Added `tests/runtime/refcount_concurrency.cpp` to exercise:

- concurrent release of independently owned references to a shared immutable managed string;
- concurrent final releases of references to a managed object;
- weak-handle locking racing with final strong-reference release;
- concurrent closure reference release and exactly-once drop behavior.

The test checks observable object counts and closure drop count. It covers selected refcount paths only; it does not prove every Runtime race-free.

### 3. Regression and documentation integration

- Added 25 `--memory-safe` acceptance, rejection and runtime-guard checks, including managed classes, lists, payload enums and an executable ownership smoke test.
- Added CMake/CTest integration for the profile and refcount stress test.
- Added Make targets for the profile tests and sanitizer/concurrency workflows.
- Added a dedicated profile guide and updated the safety, memory-model, security-profile, release and API metadata documentation.

## Confirmed validation results

The following results were run in the supplied Linux x86_64 environment:

| Validation | Result |
|---|---:|
| GCC 14.2 CMake Debug build | 10/10 passed |
| Clang 17 CMake no-build-type (`-O0 -g0`, serial) build | 10/10 passed |
| `tests/memory_safe/run.sh` | 25/25 passed |
| `tests/run_safe.sh` | 316/316 passed |
| Ownership checks | 11/11; const-method 8/8; local-borrow 91/91; noescape 17/17; field-sensitive borrow 19/19; effect-contract 19/19 |
| Move checks | 20/20; partial-move 23/23 |
| Codegen regression | constant-folding O0/O2 and inline recursion-guard checks passed |
| Runtime regression | selected Runtime suite passed, including Graph/OOM rollback, Thread Pool, Channel, HTTP, JSON, UTF-8, Memory and Audio controls |
| Dedicated refcount ASan+UBSan stress | passed with GCC `-O0 -g0` |
| Dedicated refcount TSan stress | passed with GCC `-O0 -g0` |
| Differential code generation V133 → V134 | 5/5 LLVM IR fixtures byte-identical with same GCC toolchain/flags |
| API compatibility vs V128 | 0 Breaking, 26 Warnings, 0 Added |

The 26 API warnings are error-contract/validation changes already introduced in V133 (e.g. operations now report invalid inputs or I/O errors). V134 adds no public API declarations. The warnings must still be treated as observable behavior changes by downstream consumers.

### Validation limits

- The full default ASan/UBSan FAC case suite did not finish within the 300-second execution limit. The dedicated Runtime refcount stress did finish under ASan+UBSan and TSan; that must not be confused with a full-suite Sanitizer pass.
- A Clang Debug build with debug symbols exceeded the execution window. The Clang plain `-O0 -g0` serial build and its complete CTest suite did pass.
- Windows/macOS hosted CI was not run in this environment.
- No optimized whole-Compiler `-O2` release build or full cross-platform performance comparison is claimed.

## Performance observations

### Normal-mode generated output

Using the same GCC toolchain and flags, V133 and V134 emitted byte-identical LLVM IR for five representative fixtures: language/operators, recursion guard, control flow, and native generic option/result coverage. This supports the claim that the new profile gate does not alter ordinary-mode output for these fixtures; it is not an exhaustive compiler equivalence proof.

### Compile-time cost of the new gate

A synthetic benchmark generated 240 chained FAC functions and measured nine compiler invocations per mode, using the GCC-built `facc` at `-O0` and LLVM output at `-O0`:

| Mode | Median compile time | Min | Max |
|---|---:|---:|---:|
| normal | 17.266 ms | 15.777 ms | 42.036 ms |
| `--secure` | 22.364 ms | 21.865 ms | 23.941 ms |
| `--memory-safe` | 24.330 ms | 22.791 ms | 25.856 ms |

For this microbenchmark, `--memory-safe` is about 8.8% slower than `--secure` and 40.9% slower than normal compilation. Most of the cost is the existing strict security/ownership work; the added fail-closed AST check is a smaller increment. These are small synthetic compile-time measurements, not runtime performance, not an estimate for large applications, and not a universal guarantee. Normal compilation does not run the extra AST walk.

## Remaining risks and engineering gaps

### Critical architectural gap: no Rust-equivalent borrow/lifetime proof

The profile currently avoids `ref` and raw pointer features rather than proving their lifetimes. To approach Rust's safe-code guarantees, FAC still needs:

1. a formally specified ownership and aliasing model;
2. lifetime/region checking for references stored in structs, containers, closures and return values;
3. sound reborrowing and non-lexical lifetime analysis across all control-flow exits;
4. prevention of dangling references, invalidated container-element references, double drops and use-after-move on all paths;
5. a type/trait contract for thread transfer and shared access (analogous in intent to `Send`/`Sync`) plus conservative race analysis;
6. a small, explicit `unsafe` boundary with verified contracts for every external/native operation;
7. a Runtime whose allocation, refcount, weak-reference, cycle-collection, closure and destructor paths are independently audited and continuously sanitizer-tested.

A successful `--memory-safe` compilation today means only that the source passed the restricted gate and existing analyses. It does not mean that FAC has already achieved Rust's language-level memory-safety theorem.

### Runtime exception model

FAC error transfer continues to use `setjmp`/`longjmp`. A non-local jump can skip C++ automatic-object destructors in intervening Runtime frames. Refactoring this safely requires an explicit error/unwind design across generated LLVM code and the C ABI; it is not fixed by merely rejecting FAC `throw` syntax. This remains an important trusted-runtime limitation.

### Concurrency

The refcount tests cover selected string/object/weak/closure lifetimes. They do not establish general data-race freedom, deadlock freedom, correct cancellation for every native operation, or safe interaction with all callbacks and foreign libraries. The memory-safe profile currently blocks built-in modules exposing raw native handles, including the thread-handle APIs, but it is not a whole-program concurrency proof.

### OS and external code boundaries

`--memory-safe` is not an OS sandbox. It does not provide filesystem confinement, network isolation, CPU quotas, memory quotas, process isolation or protection against a compromised compiler/toolchain. Normal FAC mode still exposes FFI/native linking and process/network capabilities; those require explicit trust and review.

### Other audit work still needed

- a systematic C ABI audit for exception propagation, pointer validity, length/encoding, ownership transfer and thread affinity;
- allocator failure injection at every multi-allocation/rollback boundary;
- fuzzing of JSON, regex, image, audio, CSV, archive and protocol parsers with bounded inputs and ASan/UBSan;
- full Runtime TSan coverage, beyond the targeted refcount test;
- Windows/macOS compiler/runtime/ABI jobs;
- reproducible optimized build and workload-specific runtime benchmarks;
- regex worst-case complexity controls and explicit process/network cancellation budgets.

## Release decision

V134 is suitable as a development release containing a stricter, opt-in language subset and additional Runtime regression coverage. It must not be marketed as Rust-equivalent or used as a security boundary for hostile code. The next major milestone should be a specified ownership/lifetime model and a Runtime error-unwinding redesign, followed by exhaustive cross-platform sanitizer and differential testing.
