# FAC V165 — SIMD foundation for float64 reference compute

## Scope

V165 optimizes the existing software-reference `gpu.addF64` and `gpu.scaleF64` operations. It does **not** add a hardware GPU backend, shader compiler, public FAC vector type, public intrinsic API, or stable cross-target vector ABI. `gpu.hardware()` remains `false` and `gpu.backend()` remains `software-reference`.

## Implementation

- FAC's GPU/reference buffer wire format remains little-endian IEEE-754 binary64.
- On little-endian IEEE-754 hosts, inputs are copied in bounded 512-element blocks into aligned `double` arrays. This avoids per-byte decode/encode in the arithmetic hot loop.
- On x86-64 and AArch64 with GCC/Clang, two float64 values are processed using a 128-bit compiler vector extension. This maps to SSE2 packed-double instructions on x86-64 and Advanced SIMD/NEON vector instructions on AArch64. Other 64-bit targets use the scalar block kernel; big-endian or non-IEEE hosts keep the original byte-wise scalar path.
- The full output is staged and checked for finite values before any destination byte is committed. Invalid ranges and arithmetic overflow therefore leave the destination unchanged.
- Input blocks are copied before arithmetic, so in-place source/destination aliases remain valid.

The vector path uses only 128-bit baseline vectors. It does not enable AVX/AVX2, SVE, or optional CPU features globally. The existing `--cpu` and `--features` options remain explicit target-tuning controls; `native` or optional features can reduce binary portability.

## Local validation

Linux x86-64, GCC 14.2, C++17 `-O2`:

| Benchmark | V164 median | V165 median | Ratio |
|---|---:|---:|---:|
| `gpu.addF64`, 1,048,576 elements | 11.526 ms | 1.691 ms | 6.82x |
| `gpu.scaleF64`, 1,048,576 elements | 7.864 ms | 1.340 ms | 5.87x |

Method: same host and C++ harness for both source archives; Runtime object and harness compiled with `-O2`; three alternating V164/V165 process pairs; each process used two warmups and eleven measured calls, reporting its median. The table reports the median of the three process medians. Input setup is outside the timed region, and both versions produced the same checksum (`79059.843750000`). These results are narrow CPU microbenchmarks, not whole-program or GPU performance claims.

The generated x86-64 object was inspected and contains packed-double `addpd` in `fac_gpu_add_f64`. The Runtime translation unit also built locally with Clang 17/C++17 `-O0`, and the focused GPU compute test passed against that Clang-built object. Compile-only Clang probes for both `aarch64-unknown-linux-gnu` and `arm64-apple-macosx15.0` emitted two-lane `fadd` vector instructions. Those probes validate vector lowering only; they do not validate the complete Runtime on ARM64/macOS.

## Tests and limits

`tests/runtime/gpu_simd.cpp` covers 0/1/511/512/513/1025 elements, block tails, in-place aliases, overflow rejection, invalid ranges, and transactional no-partial-write behavior. It is registered with CMake/CTest and the Runtime shell suite.

Local Linux validation: Compiler and Runtime built with GCC 14.2/C++17 `-O0`; CMake build and CTest passed 15/15; Runtime suite passed; core compiler suite passed 127/127 at `-O0`; negative tests passed 132/132; Parser 37/37, Lexer 18/18, Semantic 17/17 and Codegen constant-fold/recursion guards passed. Standards/API checks passed; API compatibility against V128 reports 0 breaking changes, 27 baseline warnings and 632 cumulative additions.

A focused Clang ASan/UBSan build of the full Runtime translation unit exceeded the available command time limit and did not produce a result. Sanitizer qualification for this new path is therefore **not claimed**. Hosted ARM64 CI jobs are configured, but their results are unknown until GitHub Actions runs them.
