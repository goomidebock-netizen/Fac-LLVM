# FAC Memory Management — V260

## Pointer-valued member fields read through enum pointer payloads

V260 closes a bounded `--strict-ownership` escape path in inferred (`auto`)
return functions. V259 already rejected direct raw-pointer enum payload
returns and selected pointer-preserving arithmetic/assignment forms. It did
not reject a pointer-valued aggregate field read through an enum payload
binding whose own pointer provenance is untracked.

The checker now carries the source type for pointer-capable match payload
bindings and resolves member projections against aggregate field metadata. A
return such as `box.value`, where `box` is an enum payload of type `ptr Box`
and `value` is a raw pointer field, is rejected because the checker cannot
prove that the returned pointer outlives the function. Nested known aggregate
projections such as `box.leaf.value` are checked in the same bounded manner.
Unknown or unresolved member layouts are treated as pointer-capable. Known
scalar fields such as `box.count` remain accepted.

This is not general enum-payload provenance tracking. It does not establish
pointer origins through arbitrary calls/methods, casts, heap/container storage,
all expression forms, or all interprocedural paths. It does not add a general
borrow checker, first-class `ref T` return, or general heap escape analysis.
No syntax, Runtime behavior, ARC/GC, public API, ABI, or `--memory-safe`
accepted subset is changed.

## Validation

- Lifetime regression suite: 144 PASS.
- V259 accepted the direct pointer-field reproducer; V260 rejects it.
- Pointer-valued direct and nested struct-field projections are rejected;
  known scalar-field projection is accepted.
- Ownership, Move, Partial Move, Memory-Safe, Compile-time, Generic, Lexer,
  Parser, Codegen and Runtime regression suites passed.
- Legacy examples: 132/132 at both `-O0` and `-O2`; Negative 134/134; Limits
  21/21; Tools 91/91.
- API audit: 5 baseline findings, 0 new; compatibility: 0 breaking changes,
  132 warnings. Standards and Formatter checks passed.
- Safe Profile: 433 passed, 4 V259-baseline failures remain.
- Full Semantic suite did not complete; only 17 ancestry checks are confirmed.
  Full CMake/CTest, sanitizer, cross-platform and production qualification are
  not claimed.
