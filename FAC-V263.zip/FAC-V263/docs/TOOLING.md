# FAC ecosystem and tooling (V44)

All tools are Python 3.11+ scripts under `tools/` with no third-party packages. None of them changes the
language or the compiler; they read FAC source, call `build/facc` and manage files. They share one lexer
(`tools/facsrc.py`) written against the compiler's own lexical rules (`#` / `##` / `#* *#` comments,
single-line strings, `for++` tokens), validated on all 197 sample/stdlib/test sources and against the
compiler's lexical errors.

| Need | Tool | Command |
|---|---|---|
| project + build | `tools/fac.py` | `fac new`, `fac build`, `fac run`, `fac test`, `fac check`, `fac clean` |
| package manager | `tools/facpkg.py` | `fac pkg add/remove/list/tree/verify/lock/pack` |
| formatter | `tools/facfmt.py` | `fac fmt [--check]`, `facfmt.py --diff FILE` |
| diagnostics | `tools/fac_diagnostics.py` | `fac check`, `fac_diagnostics.py FILE` |
| language server | `tools/fac_lsp.py` | `fac lsp` (stdio) |
| documentation | `tools/facdoc.py` | `fac doc` (project), `facdoc.py` (stdlib/built-in reference) |
| debugger | `tools/fac_debug.py` | `fac debug FILE --break mod.fn` |
| API quality | `api_manifest/audit/contract/compat` | `make api-check` |

Use as `python3 tools/fac.py ...`, or put a `fac` wrapper on PATH (`python3 /path/to/tools/fac.py "$@"`).
Build the compiler once with `make` (needs clang/LLVM); `check`, `fmt`, `doc`, `pkg`, the LSP and
`--emit-ll` builds work with the compiler front-end alone.

## Project layout

```
myapp/
  fac.toml          package manifest
  fac.lock          written by `fac pkg lock` (content hashes)
  src/main.fac      entry; every src/*.fac is a module
  vendor/util/      a dependency (its own fac.toml and src/)
  tests/t1.fac t1.out [t1.in]
  build/            outputs and incremental state (ignored)
```

```toml
[package]
name = "myapp"          # also a module name: letters, digits, _
version = "0.1.0"
entry = "src/main.fac"

[compat]
fac = ">=0.2.0,<0.3.0"  # compiler versions this code supports (checked on every build)

[dependencies]
util = { path = "vendor/util", version = "^0.1" }

[build]
flags = ["--safe"]

[fmt]
indent = 4
```

## Build system

`fac build` resolves dependencies, **stages** all modules into `build/.fac/stage/` and compiles the entry
there. Staging is how packages work without touching the compiler: FAC's `import x.fac` is flat (it looks
next to the entry file, then in the standard library). Consequences, all checked with clear errors: module
names must be unique across the project and its dependencies; a project module may not shadow a standard
library module; `src/` is flat; dependencies must live inside the project directory.

Profiles: default/`--release` = `-O2`, `--debug` = `-O0`. Rebuilds are skipped when compiler, flags,
staged sources and the standard library are unchanged. `fac build --emit-ll` stops at LLVM IR (no clang needed).
`fac test` builds each `tests/NAME.fac` as its own entry, feeds `NAME.in` if present and compares stdout with `NAME.out`.

## Package manager

Offline and path-based by design (no registry): reproducible, no network, nothing to trust but your tree.
`add` validates the dependency graph before keeping the change; `verify` checks compiler compatibility, graph,
collisions and (if present) the lock; `lock --check` fails when any dependency changed since `fac.lock` was
written; `pack` makes a deterministic `dist/NAME-VERSION.zip` plus `.sha256`.
Version requirements: `^1.2`, `~1.2.3`, `>=1.0,<2.0`, `=1.2.3`.

## Formatter

`facfmt.py` re-indents (4 spaces, one level per `{`, one extra for continuation lines inside an open `(`/`[`),
strips trailing whitespace, limits blank-line runs, normalises the final newline, keeps CRLF/BOM. It never
reflows or rewrites tokens, and **verifies** that the token stream is identical before returning; files with
lexical errors are skipped. The existing repository is already in this style (180 of 185 files unchanged).

## Language server

Diagnostics (lexical as you type, compiler front-end on open/save, errors from imported modules summarised),
completion (keywords, types, built-in and source modules with signatures, `terminal.out.`-style nesting, `this.`),
hover (signature, errors, ownership, deprecation, `##` docs), go-to-definition for local and imported modules,
document outline, formatting. Not implemented: rename, find-references, semantic tokens, incremental sync,
type-aware completion (a full semantic index would need the compiler to export its symbol table).

Editor setup (any LSP client): command `python3 /path/to/tools/fac_lsp.py`, language id `fac`, file pattern `*.fac`.
For VS Code, `syntax/vscode-fac` gives highlighting; pair it with a generic LSP client extension pointing at that command.

## Diagnostics

`fac check` = lexical rules + `facc --emit-ll` on the staged project (type errors, unknown names, ownership/safety
flags from `[build] flags`). Output is `file:line:col: severity: [source] message`; the compiler reports line only, so
its column is 1.

## Documentation generator

`python3 tools/facdoc.py` regenerates `docs/api/*.md` and `docs/ERROR_CODES.md` from the manifest. `fac doc` produces
`docs/api.md` for a project from the `##` comments (same tags as `docs/API_CONVENTIONS.md`).

## Debugger

Today (no compiler change): `fac debug prog.fac --break module.function` builds with `-O0`, checks the function exists
in the emitted IR (typos are reported with suggestions) and starts gdb/lldb with breakpoints on `fac.<module>.<function>`.
You get function breakpoints, backtraces, registers and machine-level stepping.

Not available: source-line breakpoints, FAC-line stepping, local variables. These require **DWARF line tables and
variable metadata in the emitted IR**, which `facc` does not produce (the existing `--debug` flag only enables runtime
null/double-free checks; the V43 `fac_debug.py` wrongly implied otherwise). Proposed follow-up, needing owner approval
because it changes the compiler (not the syntax): a `-g` flag adding `DICompileUnit`/`DISubprogram`/`DILocation` for
every function and statement, then `DILocalVariable` + `llvm.dbg.declare`. It must be verified against a real
clang/LLVM build; it was not attempted here because no LLVM toolchain was available.

## API quality gates

```
make api-check     # manifest fresh, audit vs baseline, compat vs last release, docs fresh, contract tags complete
make tools-check   # unit tests of every tool (tests/tools/test_tools.py)
```

## Known gaps (honest list)

* No deprecation warning from the compiler when a deprecated name is used (compiler change).
* No registry/remote packages, no semver resolution across versions (single version per package by design).
* LSP has no semantic analysis beyond declaration scanning; hover/definition for locals and fields is not provided.
* Debugger is function-level only (see above).
* The error-code analysis is a static over-approximation of the runtime source; it is a guide, not a proof.
