# FAC Memory Management — V262

## Join-only helper provenance for owned thread handles in value structs

V262 adds a narrowly verified call-boundary fact for the exact resource type
`ptr thread`. A non-`ref` pointer parameter is marked join-only only when every
use in its checked function body is the direct argument to `thread.join`.

For a by-value value-struct parameter, the checker may permit its pointer fields
to be consumed through a direct `thread.join` call or a uniquely declared,
non-generic helper whose exact `ptr thread` parameter has the join-only fact.
The aggregate layout must be fully known and every raw-pointer leaf must be
exactly `ptr thread`; nested value structs are followed by exact field paths.
Each tracked pointer field may be unused or used only by these verified join
operations. Aggregate copies/aliases, returns/stores, lambda captures, other
pointer types, unknown layouts, computed projections, overloaded or generic
helpers, and helper bodies with any additional use remain unverified and fail
closed.

This restores the V76 lifecycle-helper fixture without turning the rule into a
general noescape contract. An observing helper such as one that only calls
`thread.isDone(handle)` does not qualify; the new negative regression checks
that case. `move(value)` preserves the static operand type at the call boundary
so complete aggregate facts can be checked, while existing move and loan rules
remain active.

The change does not add general pointer/resource provenance, heap escape
analysis, arbitrary interprocedural aggregate summaries, automatic joining,
a complete borrow checker, or a data-race/happens-before proof. It does not
change syntax, Runtime source/semantics, public API, ABI, or the `--memory-safe`
accepted subset.

## Validation

- Safe Profile: 438 passed, 0 failed.
- Ownership/local-borrow/effect suites: 12/12, 8/8, 167/167, 17/17, 25/25,
  19/19 and 13/13; secure profile 6/6.
- Move 20/20; Partial Move 28/28; Compile-time 57/57; Memory-Safe 39/39;
  Generic 3/3; Lexer 18/18; Parser 68 checks + AST 1/1; Codegen passed.
- Tools tests: 91/91 passed when run in bounded unittest groups.
- Runtime suite produced many passing cases, but the full runner exceeded the
  execution time limit; strict UTF-8, compiler-driver argument/path checks, and
  vector-font lifecycle checks passed separately. Full Runtime success is not
  claimed.
- Semantic ancestry fast-path: 17 checks passed; the remaining runner timed out
  under both the default C++ compiler and Clang 17. Full Semantic success is not
  claimed.
- Release build and version checks passed; all seven version surfaces report
  V262. Standards, API manifest, strict API contract, compatibility audit, and
  formatter checks passed.
- Sanitizers, full CMake/CTest, cross-platform build/run, and production
  qualification are not claimed.
