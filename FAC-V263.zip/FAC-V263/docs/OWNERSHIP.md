# FAC ownership and borrowing model

## Current V263 safe-profile policy

V262 adds a narrow ordinary `--strict-ownership` call effect for exact `ptr thread`
values: a helper parameter qualifies only when every body use is a direct
`thread.join` argument. By-value value-struct parameters qualify only when all
known raw-pointer leaves are `ptr thread` and each leaf is unused or sent only
to `thread.join` / a unique non-generic join-only helper. Other pointer types,
unknown layouts, aliases, captures, aggregate escapes, overloaded/generic
helpers and extra uses remain rejected/unknown. This does not widen
`--memory-safe`, establish general noescape/lifetime contracts or prove race
freedom. See [`MEMORY_MANAGEMENT_V262.md`](MEMORY_MANAGEMENT_V262.md).


V256 closes a nested-expression gap in V235 pointer-return provenance checking: untracked enum payload bindings are rejected even when a `match` is nested inside an `ifv / eiv / elv` result arm. Selection expressions remain excluded; enum payload pointer provenance is still unsupported. This does not widen `--memory-safe`. See [`MEMORY_MANAGEMENT_V256.md`](MEMORY_MANAGEMENT_V256.md).

V235 extends ordinary strict-ownership pointer-return provenance through bounded `ifv / eiv / elv` and `match` result expressions. Every possible non-null value must derive from one unique verified input/alias; match inference requires a default arm; predicates and guards are excluded from result provenance; and pointer payload bindings remain fail-closed until their origins are modeled. Mixed possible sources remain conservative. This does not add a first-class `ref T` return or widen `--memory-safe`. See [`MEMORY_MANAGEMENT_V235.md`](MEMORY_MANAGEMENT_V235.md).

## V234 nested local closure policy

V233 adds a bounded direct-call-only local closure capture proof in ordinary strict-ownership analysis. A lambda may capture a pointer local or a pointer-bearing local value struct only when every pointer origin is known, every origin outlives the closure binding's lexical region, and the lambda directly initializes one local function-valued variable whose every use is an immediate direct call in the same function. Copies, assignment, return, argument passing, aggregate/container/global storage, nested-closure capture, shadowing, `noescape` origins, Unknown provenance and shorter-lived origins remain rejected. Pointer-free and fully verified-null values retain their prior behavior. This is a bounded syntactic escape proof, not general closure lifetime inference or whole-program/heap escape analysis. The `--memory-safe` accepted subset is unchanged and still excludes raw pointers and `addr`. See [`MEMORY_MANAGEMENT_V233.md`](MEMORY_MANAGEMENT_V233.md).


V228 extends ordinary strict-ownership aggregate provenance across lexical blocks and control-flow joins. A field's possible origins are unioned across every `if`, `switch` / `match`, and `try` / `catch` predecessor; missing facts remain unknown, and every possible origin must satisfy a later store or return lifetime. Pointer-local facts flow by declaration identity. Because no loop fixed point is claimed, visible aggregate and pointer-local provenance changed inside a loop is invalidated after the loop. This does not widen `--memory-safe` acceptance or add a general heap/interprocedural escape proof. See [`MEMORY_MANAGEMENT_V228.md`](MEMORY_MANAGEMENT_V228.md).

V227 validates nested local reborrow parent edges: owner identity is preserved, an exact parent projection contains the child projection, the parent loan outlives the child, and the parent chain is present and acyclic. This extends local nested value-struct borrow checking but does not permit `ref` values to escape to aggregate fields, globals, containers or closures, and does not add a general heap borrow graph. The `--memory-safe` profile permits `ref` parameters and function-local `ref` / `ref const` aliases only when strict ownership analysis can check their function-scope loan behavior. Borrow bindings remain excluded from globals and aggregate fields, and raw pointer types plus `addr` remain outside this profile. In ordinary `--strict-ownership` / `--secure` code, V226 tracks pointer provenance by exact field path in local value structs, preserves paths through nested by-value structs and local copies, and kills prior field facts on overwrite. A known-null field is distinct from an unknown field; reads/copies/passes/returns involving pointer-bearing aggregates without complete verified field facts fail closed. Pointer origins must still outlive their local aggregate, `noescape` retention is rejected, and `class` / `obj` fields, containers, globals, closure capture and arbitrary heap references remain unsupported. V223's strong-object field-borrow boundary and V224's verified pointer return-lifetime inference remain as documented. These are bounded ownership-first checks, not a general proof for every reference or thread interaction. See [`MEMORY_MANAGEMENT_V223.md`](MEMORY_MANAGEMENT_V223.md), [`MEMORY_MANAGEMENT_V224.md`](MEMORY_MANAGEMENT_V224.md), [`MEMORY_MANAGEMENT_V225.md`](MEMORY_MANAGEMENT_V225.md), [`MEMORY_MANAGEMENT_V226.md`](MEMORY_MANAGEMENT_V226.md) and [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md).

## Current reborrow rule (V199)

V199 supersedes the direct-child-only suspension wording in the historical V55 section below. A mutable borrow is suspended while **any live descendant reborrow** exists: child, grandchild or deeper. The checker walks the parent-loan chain using declaration identities, so nested aliases with shadowed names do not break ancestry. The same rule applies to parent reads/writes, member and method access, and passing the mutable parent to a call. Diagnostics identify the deepest retained descendant that currently blocks access.

NLL liveness keeps ancestor loan records available while a descendant is live, then prunes the chain after the deepest descendant’s final reachable use. This remains a local, intraprocedural analysis; it does not add named lifetime parameters or general interprocedural region inference. See `docs/LANGUAGE_CORE_V199.md` and the `good_reborrow_chain_nll_resume`, `bad_reborrow_ancestor_write`, and `bad_reborrow_intermediate_write` fixtures.


## V67: lock-aware concurrency effects (adjacent safety analysis)

V67 propagates caller-held lock context into statically followed direct callees and verifies that each callee returns with its entry lock set. Per-global summaries distinguish the lock-name union from the intersection common to all ordinary accesses and flag unprotected access. Global mutex handles are module-qualified; shadowed/ambiguous handles and unmodeled exceptional/loop lock flow fail closed. This remains evidence rather than a whole-program race proof, and `--safe` still rejects mutable global payload sharing.

## V66: typed concurrency effects (historical baseline)

The ownership checker remains focused on loans, lifetimes and pointer effects. Separately, V66 augments `--safe` thread-closure analysis with typed summaries of reachable mutable globals: read/write, address/alias exposure, recognized atomic operations, and mutex lock/unlock observations. The summaries propagate through statically followed named calls and methods. They improve diagnostics but do not prove a whole-program lock or atomic protocol; mutable global payload access continues to be rejected from safe worker closures until every alias and concurrent access can be verified.

## V209: named lifetime contracts on aggregate callback fields

V209 extends V208 callback contract tracking to function-valued fields declared on statically known `struct` and `class` types. The strict ownership checker stores each field's declared `CallContract` alongside the field's static type and resolves that contract for direct and nested member paths, such as `box.callback(value)` and `tree.leaf.callback(value)`. It substitutes actual argument origins into the field callback's named lifetime indices, enforces declared `where longer: shorter` constraints, and attributes a pointer return only to eligible declared sources. Untracked provenance and invalid outlives relationships remain rejected.

The compiler also treats a callable aggregate field as a function value rather than an instance method and dispatches it through the existing closure ABI. Constructor initialization and later field assignment validate the full callback function type before managed storage, including parameter/return types, named lifetime shape and independent `noescape`/`readonly` compatibility. Ordinary method calls and `super.method()` continue through their established dispatch paths.

This is bounded to statically typed aggregate fields. Function-valued fields reached through arbitrary computed/returned receivers, unresolved dynamic dispatch, and general target-body effect inference are not proven. In particular, a field callback's `noescape` annotation alone is not a verified body effect; indirect pointer-retention analysis remains fail-closed. Raw pointer fields, heap-stored references, and all aggregate borrowing patterns are not made generally safe by this release. No Runtime or ABI changes. See [`LANGUAGE_CORE_V209.md`](LANGUAGE_CORE_V209.md) and [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).

## V208: named lifetime contracts on function values and indirect calls

V208 allows an explicit function-value type to carry the same named lifetime shape used by ordinary function declarations. The return type and pointer parameters may use `ptr<name> T`; a callback type may declare `lifetime<a, b>` and `where a: b`. Lifetime names are bound to indices within that callback signature, and the return lifetime must be supplied by a pointer parameter whose lifetime outlives it. Function-value assignment requires a target with a compatible return/parameter type and lifetime shape; names may differ when their indexed lifetime graph is alpha-equivalent. An unannotated function value cannot be assigned to a callback type that requires named lifetimes.

Under `--strict-ownership` / `--secure`, statically typed function parameters and local function variables carry their declared callback contract into indirect calls. The caller's actual pointer provenance is substituted into the callback lifetime parameters, `where` relationships are checked against the caller's region graph, and a returned pointer is attributed only to a parameter that can outlive the declared return lifetime. Untracked origins, invalid outlives relations and pointers returned beyond their source region remain rejected.

`noescape` is deliberately separate from named return-lifetime tracking. Although `noescape` and `readonly` remain part of function-value type compatibility, an indirect call does not treat a function-type `noescape` bit alone as a verified body effect. Without target-aware proof that the concrete callback implementation does not retain the pointer, frame-derived pointer arguments still fail closed. Function-valued aggregate/member fields, callbacks obtained from computed/returned function expressions, dynamic dispatch and general indirect effect verification remain unsupported or conservative. This milestone is compile-time-only and does not change the native function-pointer ABI or Runtime. See [`LANGUAGE_CORE_V208.md`](LANGUAGE_CORE_V208.md) and [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).

## Current runtime model

FAC managed values use the compiler/runtime ownership machinery (reference counting and temporary cleanup). This is not the same as Rust's compile-time ownership model. In particular, runtime retention does not prove that every alias is exclusive or that a reference cannot outlive its intended source.

### Nested object destruction and error recovery (V176)

When a managed object's generated field-drop callback releases child objects, a child finalizer/drop failure is deferred into the outermost active destruction error sink. Nested `fac_obj_release()` calls therefore finish releasing their own fields and return to the parent drop callback instead of rethrowing through it and skipping later siblings. The first FAC/C++ callback error is rethrown only after the outermost object has completed its field drops and its storage has been removed from the live registry. This preserves the first error while completing nested cleanup; it does not make arbitrary user callbacks infallible or provide rollback of user-visible side effects.

## V39 opt-in check

`--strict-ownership` adds a conservative static check for direct calls to known functions and methods. If two formal parameters are marked `ref`, the corresponding arguments must not have the same recognized storage root.

```fac
function void swap(ref int left, ref int right) {
    var int tmp = left
    left = right
    right = tmp
}

public function void main() {
    var int a = 1
    var int b = 2
    swap(a, b)       # accepted with --strict-ownership
    # swap(a, a)     # rejected: two mutable borrows of the same root
}
```

The check understands simple roots such as `name`, `name.field`, and `name[index]`. It deliberately treats `pair.left` and `pair.right` as potentially overlapping because field-disjointness is not yet proven. Same-name candidates with ambiguous signatures are checked only if all same-arity candidates mark both positions as `ref`.

## Limits

This is a call-site alias guardrail, not a complete borrow checker. It does not reason about raw pointer aliases, indirect function values, dynamic dispatch targets, FFI, aliases hidden behind the runtime, borrow scopes, or references escaping through returns/captures. V39 does not implement `move` semantics or lifetime validation. Do not interpret a passing `--strict-ownership` run as a proof of memory safety.

Use `--safe` / `--strict-safe` for the separate raw-pointer, FFI and thread-isolation checks. The ownership checker is opt-in and does not change legacy compilation unless the flag is supplied.


## V45: immutable borrows (`ref const`)

V45 adds `ref const T name` for a shared immutable borrow parameter. The existing `ref T name` spelling remains an exclusive mutable borrow. The new mode is enforced by the opt-in `--strict-ownership` pass; it does not alter legacy compilation.

```fac
function int sum(ref const int left, ref const int right) {
    return left + right
}

function void update(ref int value) {
    value = value + 1
}
```

The checker permits two shared borrows of the same root, rejects a same-root pair containing a mutable borrow, rejects direct assignment/increment through a `ref const` parameter, and rejects passing that parameter directly to a known mutable-ref parameter. It is conservative for direct calls and may reject disjoint fields rooted in one aggregate.

It does not provide a general borrow region, lifetime inference, closure escape analysis, object const methods, pointer alias analysis, indirect-call analysis or data-race proof. See [`MEMORY_MODEL.md`](MEMORY_MODEL.md). This is a first borrow-checking step, not a Rust-equivalent guarantee.


## V48 strict-ownership guardrails (partially superseded by V50)

V48 rejected every instance/member call through a `ref const` receiver because const-qualified methods did not yet exist. V50 replaces that blanket rejection with a method contract: calls are permitted only to methods declared `const` and checked by the V50 receiver analysis. `ref` parameters with default values or variadic capture remain rejected because implicit temporary/pack lifetime and alias semantics are not modeled. The checker still does not implement a complete loan graph, control-flow lifetime inference, general escape analysis, raw-pointer alias propagation, dynamic dispatch effects or FFI effects.


## V50: const-qualified instance methods

FAC supports a trailing `const` qualifier on an instance method:

```fac
class Counter {
    public var int value
    public function int get() const { return this.value }
    public function void increment() { this.value++ }
}

function int read(ref const obj Counter counter) {
    return counter.get()       # accepted with --strict-ownership
    # counter.increment()      # rejected: method is not const
}
```

The qualifier is part of the method contract and virtual/interface signature, but does not change the native calling convention. A const method is checked as though `self` were an immutable borrow: direct writes rooted at `this`/`self`, calls to non-const methods on the receiver, passing the receiver to known mutable-ref parameters, and capturing `self` in a closure are rejected under `--strict-ownership`. Interface declarations and implementations, and class overrides, must agree on const qualification. Static methods cannot be const.

This is a conservative direct AST check, not deep constness or a complete effect system. It cannot prove that a const method does not mutate through raw pointers, FFI, globals, aliases hidden in called functions, or interior-mutability APIs. `--strict-ownership` remains opt-in; `--secure` enables it.


## V51: CFG-based move dataflow

V51 replaces the previous structured move walk with a control-flow graph (CFG). The checker tracks a *may be moved* fact for each lexical local symbol and propagates it over branch, loop, exception and exit edges until a fixed point is reached.

```fac
import terminal.fac

public function void main() {
    dyn string value = "first"
    for (var int i = 0, i < 2, i++) {
        dyn string carried = move(value)
        terminal.out.println(carried)
        value = "reused"       # reinitialization clears the moved state
    }
}
```

The loop is accepted because every path leaving the body reinitializes `value` before the back-edge. A loop that can reach another `move(value)` or a read of `value` without reinitialization is rejected. Branch joins conservatively union moved states; a move on either possible branch therefore makes a later read unsafe until the local is reinitialized. Lexical symbol IDs keep a shadowed inner variable separate from an outer variable with the same spelling.

The CFG includes structured edges for `if`, `while`, `do/while`, `for`, counter loops, foreach, `switch`, `match`, `try/catch/finally`, `break`, `continue`, `return` and `throw`. Constant `true` / `false` conditions prune the impossible branch. A `return`, `break` or `continue` that leaves a protected region is routed through the relevant `finally` block(s) first. Since FAC operations may throw, the exceptional path from a `try` body and a `catch` body conservatively assumes that any local moved syntactically in that body may already have been moved when `catch` / `finally` executes. This can produce conservative rejections, but it avoids forgetting a move on an exceptional edge.

### Loan tracking boundary

The `--strict-ownership` checker still models explicit `ref` and `ref const` parameters as call-site loan contracts: it verifies the argument roots and shared/mutable combinations for each statically known direct call. These loans are not persisted as a general graph across stored references, returned aliases, closures, raw pointers, FFI or indirect calls. V51's CFG is used for move-state dataflow; it is not yet a complete borrow-region/lifetime graph.

### V51 limits

- Whole-local moves only; partial field/index moves are not supported.
- Move inside `defer` and lambda bodies remains rejected; deferred captures prevent moving a value that may be used later.
- The try/catch exceptional edge is deliberately an over-approximation, not precise exception-effect analysis.
- No general lifetime inference, dangling-reference proof, raw-pointer alias analysis, FFI escape proof or whole-program data-race proof.

## V53: local scoped borrows (lexical loan checking; superseded in V55)

V53 adds local borrow bindings. The alias points at the original storage slot; it is not a copied value and registers no independent drop/cleanup:

```fac
import terminal.fac

public function void main() {
    var int value = 10
    {
        ref var int writeView = value
        writeView = 20
        writeView++
    } // the mutable loan ends here
    terminal.out.println(value) // 21
}

public function void readOnly() {
    var int value = 10
    ref const var int readView = value
    var int copy = readView
}
```

The declaration grammar is `ref [const] <ordinary variable type> name = lvalue` (for example, `ref var int`, `ref const var int`, or `ref const obj Counter`). It is valid only inside a function/block and requires `--strict-ownership` or `--secure`.

The checker applies these lexical rules:

- Multiple shared `ref const` local borrows of one root may coexist.
- A mutable `ref` local borrow is exclusive against shared and mutable loans of that root.
- While a mutable loan is active, access through the owner is rejected; use the mutable alias. While a shared loan is active, owner reads remain allowed but owner writes are rejected.
- A shared alias cannot be written or call a non-`const` instance method. A mutable alias may be written and may call mutable methods.
- `move(owner)` and `addr(owner/alias)` are rejected while a loan is active; exposing a pointer from an alias is rejected.
- Mutable borrowing from a const local, const field, or untracked storage is rejected. Borrow roots must be tracked locals, parameters or an instance receiver. Global/static roots are not supported yet.
- In V53, declaring a local alias from another alias or `ref` parameter was deliberately rejected. V55 supersedes that restriction with checked local parent/child reborrows; unknown/indirect aggregate calls remain rejected.
- Closure bodies are checked against the active loan context. Capturing a non-scalar local borrow alias is rejected because managed/aggregate captures may retain an alias beyond the lexical loan; scalar captures remain value snapshots. Owner reads inside a closure are still rejected while a mutable loan is active.
- Passing a class/struct alias by value, or to an unknown/unverified call, is rejected because the callee could retain the handle beyond the loan. Passing it to a statically known `ref` parameter is treated as a temporary reborrow.
- Field and element borrowing is supported where the source is a recognized lvalue. All fields/elements rooted in one aggregate are treated as potentially overlapping, even when their indices/field names differ.

As shipped in V53, this was a lexical, conservative first step—not NLL or a persistent CFG loan analysis. V54 and V55 subsequently add last-use and CFG liveness; the current limitations are described in the V55 section below. The checker does not model raw-pointer aliases, unsafe/FFI mutation, indirect/dynamic calls, runtime-hidden aliases, heap-stored references, or whole-program data races. Closure capture handling is conservative: it blocks non-scalar alias capture and checks the closure body under the current lexical loans, but it is not a general closure escape/lifetime proof. The parser/code generator does not yet expose reference return types. Use `--safe` for the separate raw-pointer/FFI checks; a successful `--secure` compile is not a formal proof of memory safety.


## V54: bounded last-use expiration (superseded by V55 CFG liveness)

V54 shortens local loan regions in straight-line statement lists. After a statement is checked, a local loan declared in the current block is retired when the alias has no possible use in later sibling statements. This allows the owner to be used again after the alias's last use rather than requiring an extra nested block.

```fac
public function void update() {
    var int value = 10
    ref var int view = value
    view = 20
    terminal.out.println(view)
    value++ // accepted: view is no longer used after the preceding statement
}
```

A use in a nested `if`, `match`, `try`, or loop is conservatively treated as a use throughout that complete statement. In particular, the checker does not expire a loan halfway through a loop body or merge loan states path-sensitively at branch joins. A local alias referenced by `defer` remains live until the enclosing block exits because deferred code executes during cleanup. A nested block cannot expire an inherited outer loan. The implementation uses declaration identity when removing a loan, avoiding accidental removal of an outer loan with the same spelling.

As shipped in V54, this was bounded statement-level last-use analysis. V55 supersedes its structured-statement approximation with CFG may-liveness and local reborrow tracking. Reference return/store types, field-disjoint loan proofs, lifetime parameters, raw-pointer/FFI escape analysis, dynamic dispatch effect inference, and whole-program data-race analysis remain incomplete. `--strict-ownership` remains opt-in and `--secure` enables it; neither profile is a formal proof of memory safety.


## V55: CFG borrow liveness and local reborrowing (historical; declaration identity added in V56)

V55 adds a per-function control-flow graph for local-borrow liveness. The graph represents `if` branches, loop back-edges, `switch`/`match` dispatch, `try`/`catch`/`finally`, and `break`, `continue`, `return` and `throw` exits. The checker computes a backwards may-liveness fixed point:

```text
liveOut(block) = union(liveIn(successor))
liveIn(block)  = uses(block) union liveOut(block)
```

At a syntax node, a local loan remains active when its alias may be used on an outgoing path or is used by the current node. This permits branch-specific expiration: an alias used only in the `then` arm does not automatically block an unrelated owner write in the `else` arm, provided the alias is not used after the branch. A later use after the join keeps the loan active on both incoming paths. Loop back-edges participate in the fixed point.

In V55 the analysis used conservative name-based alias-use sets; V56 supersedes that limitation with resolved declaration IDs for both aliases and local owner storage. `defer` and any alias referenced inside a `try` region are pinned conservatively because deferred cleanup and operation-level exceptional edges are not yet modeled precisely.

Local reborrows are now supported:

```fac
var int value = 10
ref var int parent = value
{
    ref const var int child = parent
    terminal.out.println(child)
}
parent = 20
```

- A shared child (`ref const`) may be reborrowed from either a shared or mutable parent.
- A mutable child (`ref`) may be reborrowed only from a mutable parent.
- A mutable parent is suspended while any direct child reborrow is active. Reads, writes, method calls and ref-argument use through that parent are rejected until the child expires.
- Shared parent reborrows may coexist with other shared child reborrows.
- A child keeps its ancestor loan records alive while the child remains active. When the child expires, its parent can become usable again if the parent's own loan remains live.

The CFG liveness layer tracks potential alias uses; the loan records separately retain root, mode, parent declaration and parent alias. The implementation still treats fields and indexes rooted in one aggregate as potentially overlapping. It does not yet provide reference return/store types, a complete lifetime parameter system, raw-pointer/FFI escape proofs, arbitrary indirect-call effect analysis, or a whole-program race proof. Exceptional paths through `try` and deferred cleanup intentionally remain conservative. `--strict-ownership` is still opt-in and `--secure` enables it; neither is a formal proof of memory safety.


## V56: declaration-identity loans and lexical owner lifetimes

V56 replaces the V55 alias-name liveness sets with exact AST declaration identities. The local-borrow pass now resolves each identifier against the lexical environment visible at that source position. A reference to an inner ordinary local, foreach iteration variable, lambda parameter, catch binding or match binding no longer counts as a use of an outer borrow merely because the spelling is the same. Conversely, a later use of an outer alias remains attached to that alias's declaration and keeps its loan alive across a nested shadowing scope.

The storage root is tracked separately from the borrow alias. For local owners, each loan records the exact owner `VarDecl`; parameter and receiver roots use their stable function-local name identity. Owner writes/reads, mutable-borrow conflicts, direct calls, `move()` and `addr()` compare these storage identities instead of comparing root names alone. This allows two nested locals with the same name to be independently borrowed while preserving the restriction on the actual borrowed owner.

Reborrow parent/child links are also resolved by declaration identity. A child may use the same spelling as a parent in a nested scope; the parent relationship remains intact, and the child retains the parent record until its own loan expires. Lambda parameters, foreach names and catch/match bindings are treated as lexical shadows in both liveness binding and the semantic context.

### Initial local lifetime / outlives boundary

FAC currently has no first-class reference return type or reference-valued struct field. Local borrow declarations require a tracked local, parameter or receiver that is visible at the declaration point; globals/statics and untracked roots remain rejected. `move(owner)` and `addr(owner/alias)` remain blocked while the corresponding loan is active, and non-scalar borrow-alias closure capture is rejected when escape lifetime cannot be proven. These rules establish a limited lexical owner-outlives-alias boundary for current local references. They are not a general lifetime parameter, region inference or `outlives` solver, and do not prove safety for raw pointers, FFI, indirect callbacks or hidden aliases.

V56 tests cover shadowed alias names, shadowed owner names, two same-named owners with separate loans, foreach/lambda parameter shadowing, same-name parent/child reborrows, and a negative post-shadow write when the outer alias remains live. The local-borrow suite contains 64 cases. `--strict-ownership` remains opt-in and `--secure` enables it; neither profile is a formal proof of memory safety.


## V57: lexical lifetime regions and exceptional CFG edges

V57 introduces a per-function lifetime-region tree for the local-alias feature. Parameters and the instance receiver belong to the function root region. Each lexical block and loop creates a child region. Every local declaration is associated with its region, and each local loan records both its own region and the region of its storage root. A direct borrow adds an owner-region-outlives-loan-region constraint; a reborrow adds a parent-region-outlives-child-region constraint. The constraint pass verifies that the longer region is the same region or an ancestor of the shorter region.

This is a bounded lexical region model, not a general lifetime-parameter or inference system. Local ref aliases cannot be stored in struct fields or returned as references because those type forms are not part of the current language. This region tree makes the present local owner-outlives invariant explicit, but does not prove the lifetime of raw pointers, foreign handles, container elements after reallocation, references hidden behind callbacks or aliases outside the tracked local-root set.

The V57 CFG now routes explicit `throw` to the nearest catch target and routes exceptions leaving protected regions through the applicable `finally` blocks. It also conservatively adds exceptional edges from expressions inside a protected region because a call or allocation can throw; the compiler does not yet have a per-call `nothrow` effect contract. A catch body executes under the outer exception context, so a new exception from catch passes through this try's `finally` before reaching an outer handler. A `finally` body is built under the exception context outside the try whose cleanup it represents, preventing an exception raised during cleanup from being caught by that same try. Return/break/continue cleanup routing remains active.

Because those edges are now present, alias uses inside `try/catch/finally` are not globally pinned. Their liveness flows through the CFG and a loan may end after the final catch/finally use. `defer` remains pinned to lexical scope exit because the current CFG does not model a unique deferred execution edge for every exit and cleanup ordering. Expression exception edges are deliberately conservative and may keep loans live longer than necessary.

V57 tests include a borrow read in both catch and finally followed by a legal owner write after the try, a negative owner write before an exceptional-path catch use, a negative write in catch when finally still uses the alias, and nested owner/reborrow region cases. The local-borrow suite contains 76 cases.


## V58: bounded raw-pointer provenance and frame-escape checks

V58 extends `--strict-ownership` / `--secure` with bounded provenance tracking for pointers produced by `addr()` on function-frame storage. Provenance follows local `ptr` variables by AST declaration identity and is accumulated monotonically across branches/blocks, so a return after a conditional pointer assignment cannot forget an origin from one branch.

The checker rejects:

- `return addr(local)` and returning a local `ptr` variable whose tracked origin is a function-frame object or parameter slot;
- storing an address of an inner-scope owner into a pointer variable whose storage region outlives the owner;
- storing a function-frame address into aggregate fields/elements or untracked/global storage, because FAC does not yet provide reference-valued field/container lifetime contracts;
- passing a frame-derived pointer to a conservative, name-based set of retaining collection mutators (`add`, `addFirst`, `addLast`, `addEdge`, `append`, `emplace`, `enqueue`, `insert`, `push`, `pushBack`, `pushFront`, `put`, `set`);
- capturing a local pointer variable in a closure when its tracked provenance includes function-frame storage.

A local pointer variable may hold an address when its storage is proven not to outlive the owner. `addr()` passed as an immediate expression to an API/FFI call remains permitted for compatibility, but the compiler cannot prove that an unknown callee does not retain it. No `noescape` effect contract exists yet.

The provenance pass is deliberately conservative and bounded. It recognizes direct `addr()` expressions and propagates provenance through tracked local pointer variables and simple expression trees. It does not yet prove safety through opaque foreign calls, indirect callbacks, untracked external pointers, arbitrary pointer/integer round-trips, or pointer provenance hidden behind helper functions. Direct pointer arithmetic/cast expression trees are traversed. Known collection mutators are blocked by method name, not by a general call-effect contract. Aggregate stores of frame-derived addresses are rejected rather than modeled. It may conservatively retain a may-origin fact after a pointer is overwritten on a later path. This is not a complete raw-pointer verifier, general lifetime-parameter solver or dangling-reference proof.

## V59: verified `noescape` pointer parameter contracts

V59 introduces the parameter modifier `noescape ptr T name`. It is a compile-time pointer-retention effect, not a borrow type and not an ABI change. FAC function bodies are checked under `--strict-ownership` / `--secure`: provenance entering a noescape parameter follows local pointer aliases and may not be returned, stored in a global/field/aggregate/container destination, captured by a closure, or forwarded to a call without a proven direct noescape parameter contract. At the V59 release boundary, a direct call was accepted only when every collected same-name, same-arity declaration marked that argument position noescape; parameter-type applicability and final overload selection were not yet used to narrow that set. Methods used a class-qualified summary when the receiver type was known; unresolved/computed calls failed closed. V65 supersedes this historical limitation for direct calls with known argument types.

The modifier is restricted to by-value `ptr` parameters; `ref`, default values and variadics are rejected. Lambda `noescape` parameters remain unsupported; `readonly` lambda parameters and function-type effect signatures are supported since V64. V65 supersedes the original name/arity-only call summary: known argument types now select the best applicable overload for direct-call effect and ref checks, while unknown or tied candidates remain conservative. Indirect-call pointer escape proof still fails closed until the concrete target body can be verified. Programs that declare noescape parameters must enable `--strict-ownership` or `--secure` so the annotation cannot be silently ignored.

`extern function ... (noescape ptr T p)` is a trusted FFI promise, not a verified body fact. The compiler cannot inspect foreign code, and a false annotation may still permit a dangling pointer. Only use it when the foreign API guarantees that it will not retain the pointer after the call. `noescape` does not imply non-null, valid, aligned, immutable, thread-safe, `nothrow` or `noalias` behavior.

V59 does not implement partial move. The current `move(local)` dataflow and cleanup registration operate at whole-local granularity; enabling field-level move before per-field initialization/drop flags are integrated into code generation could double-drop, leak or access uninitialized fields. Partial move remains deferred until the move checker and cleanup lowering share a field-sensitive state model. See `docs/NOESCAPE_CONTRACTS.md` for the precise call/FFI boundary.


## V60: bounded partial move of managed struct fields

V60 extends explicit `move()` from whole local values to a restricted first-level field form:

```fac
import terminal.fac

struct Record {
    dyn string first
    dyn string second
}

public function void main() {
    struct Record record = Record("alpha", "beta")
    dyn string first = move(record.first)
    terminal.out.println(first)
    terminal.out.println(record.second) // another field remains available

    record.first = "restored"             // reinitialization restores the field
    terminal.out.println(record.first + "|" + record.second)
}
```

The operation is enabled by `--strict-move` or `--secure`. It is limited to a direct first-level field of a local mutable value `struct`, where the field is a managed leaf handle whose drop operation accepts null: `dyn string`, list/data-structure handles, function handles, `obj` and `weak obj`. `ptr T` is a raw unmanaged pointer and is intentionally not accepted as an ownership-bearing field. Scalar values are not moved, as they have no managed ownership to transfer.

Code generation loads the managed handle from the field, writes `null` into the source field, and returns an owned expression that is registered with the existing temporary cleanup stack. The struct's ordinary drop helper subsequently releases all managed fields; its existing string/list/function/object/weak release helpers are null-safe, so the moved-from field is skipped while all remaining fields are released normally. No Runtime code or ABI change is required.

The CFG move checker resolves the root local by declaration identity and each field by `(root declaration, field name)`. It tracks a moved-field fact plus a partially-moved aggregate marker. A read or second move of that field is rejected. Reading/consuming the whole aggregate, calling a method/callable member on it, capturing it in a closure, or using it from `defer` is rejected while any field remains moved. Assigning a new value to a moved field clears that field fact; when every moved field is restored, the aggregate marker is cleared. CFG joins union may-be-moved field facts, so if any reachable path moves a field, later use requires reinitialization on all paths. Loop back-edges are permitted when each iteration reinitializes the moved field before the next iteration.

At the original V60 release this was deliberately not a general partial-move implementation. The V60 compiler rejected parameters, `self`, borrow aliases, heap/indirect storage, classes/objects, nested member paths, nested structs, enum payloads, arrays, raw pointers and unmanaged scalar fields. V60 had no arbitrary per-field drop flags; V63 later adds compiler-tracked nested projection state for its supported managed path subset, as described below. A moved field is represented by a null sentinel only for the supported managed leaf handle types. Borrow analysis is separate: V62 supports metadata-validated nested named-field projections for local borrows, while partial move remains limited to direct first-level managed leaves. See `STATUS.md` and `tests/move/partial/`.

## V61: field-sensitive borrowing and pointer effects

V61 initially proved disjointness only for **direct first-level named fields** of the same resolved local aggregate storage. V62 extends this to metadata-validated nested named-field paths; the V61 restrictions in this subsection describe the preceding release. For example, a mutable loan of `record.left` may coexist with a mutable loan of `record.right`, and a write to `record.right` is allowed while `record.left` is exclusively borrowed. The proof requires both paths to be direct member expressions rooted at the same declaration identity with different field names. A whole-root loan overlaps every field. Same-field loans, nested members, indexes, pointer dereferences, computed bases and untracked paths remain may-alias and are rejected when shared/mutable rules conflict. This is not a general field-sensitive alias analysis.

Local borrow loans now carry an optional exact first-level field projection in addition to owner declaration identity. Reborrows from one mutable parent may create sibling mutable children only when their proven projections are disjoint. The parent remains suspended while a child is live. Reads/writes and direct `ref` call arguments use the same projection-overlap rules. V60 partial-moved fields continue to be checked by the move-state pass; the borrow pass rejects overlap with the moved/borrowed field but allows a proven disjoint first-level field. Nested paths were conservative in V61; V62 resolves nested named-field chains segment by segment through declared struct metadata and treats sibling paths as disjoint while prefix/descendant paths overlap.

V61 also adds a separate `readonly ptr T` parameter effect. It forbids writes through the pointer in a checked FAC body and forwarding to calls without a verified readonly contract. `noescape` remains a separate pointer-retention effect. They can be combined as `readonly noescape ptr T`. Both require `--strict-ownership` or `--secure`; `extern` declarations are trusted FFI promises. Abstract/interface contracts are permitted, and concrete overrides/implementations must not weaken promised effects. Direct call effect summaries remain name/arity conservative and function-pointer types do not yet carry effects. See [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).

V61 tests cover disjoint first-level mutable/shared loans, owner access to a sibling field, direct `ref` calls, sibling reborrows, same-field and whole-root conflicts, conservative nested paths, and interaction with V60 partial move. Pointer-effect tests cover readonly writes/increments, pointer alias attempts, readonly/noescape forwarding, FFI declarations, abstract/interface contracts, virtual implementation weakening, and caller-storage runtime reads. V61 does not add public API entries or Runtime ABI changes.


## V62: nested field projections

V62 extends the V61 field-sensitive borrow proof from one field to a dotted path of named fields. Every path segment must resolve through declared aggregate metadata. Disjoint leaves such as `outer.inner.left` and `outer.inner.right` may be mutably borrowed at the same time. Equal paths and prefix/descendant pairs overlap (`outer.inner` conflicts with `outer.inner.left`). Whole-root, indexed, dereferenced, computed, unknown and untracked paths remain conservative. This does not add nested Partial Move, per-field drop flags, general alias analysis, or Runtime/ABI changes. See `tests/ownership/field_sensitive/`.


## V183: fixed-array constant-index borrow projections

V183 extends exact local-borrow projections from metadata-validated member paths to fixed-size array elements selected by non-negative integer-literal indexes. A path such as `values[1]` is recorded as an index segment, so simultaneous mutable borrows of `values[1]` and `values[10]` are disjoint. A whole-array access still overlaps every element; equal indexes overlap.

Only statically declared `array` storage with a literal non-negative index is made exact. Computed/variable/negative indexes, lists, matrices, pointer indexing, unknown bases and expressions whose storage identity is not a named tracked local remain conservative may-alias paths. This does not permit borrowing through globals/statics, storing references, returning references, or any new lifetime escape. The implementation affects strict local-borrow analysis only; it does not change code generation, array bounds checks, public APIs or the Runtime ABI. Positive and negative regressions live in `tests/ownership/local_borrows/`.

## V63: nested partial move and projection-aware moved state

With `--strict-move` (or `--secure`), FAC now accepts a nested named field path rooted at a local mutable value `struct`, for example:

```fac
struct Inner { dyn string left; dyn string right }
struct Outer { struct Inner inner; dyn string tail }

public function void main() {
    struct Outer record = Outer(Inner("left", "right"), "tail")
    dyn string moved = move(record.inner.left)
    terminal.out.println(record.inner.right, "|", record.tail)
    record.inner.left = "restored"
}
```

A final projection may be a managed handle (`string`, list/data-structure, function, object or weak-object handle) or a managed value `struct`. Each intermediate segment must resolve to a value struct; class/interface/object traversal, arrays/indexes, enum payloads, raw pointers, scalar fields and unknown/computed paths remain unsupported. The root must be a direct local mutable value struct, not a parameter, `self`, borrow alias, global or heap/indirect variable.

Move state is keyed by root declaration identity plus a dotted projection. Equal paths and prefix/descendant paths overlap. Moving `record.inner.left` prevents reads of that leaf and reads/consumption of the containing `record.inner` or `record` as a whole, while `record.inner.right` and `record.tail` remain accessible. A sibling projection can be moved independently. Method calls on a containing partially moved receiver, lambda captures and `defer` uses remain conservatively rejected.

Reinitializing the exact moved field clears its move state. Assigning a containing subaggregate restores all moved descendants beneath that path after the old aggregate is dropped. Branch joins union possibly moved projections, and loop re-entry requires reinitialization along every path where the move may have occurred.

Code generation writes `null` into moved managed-handle slots. When a complete nested value struct is moved, it copies the aggregate into an owned temporary and writes `zeroinitializer` into the source field. Existing recursive struct drop helpers then visit remaining fields and safely skip zero/null sentinels. The moved result is protected by the standard temporary cleanup stack; the original owner remains on the ordinary scope cleanup stack. Exception tests exercise this arrangement. No Runtime source, ABI or public API change was needed.

This is per-projection moved-state tracking combined with zero/null storage sentinels, not yet a general runtime drop-flag bitmap. Arrays, dynamically indexed storage, enums with payload, overlapping layouts/unions, classes and custom unmanaged resources are intentionally excluded.

## V75 — whole-struct thread-handle move tracking

The compiler now propagates thread-handle lifecycle facts across explicit `move(aggregate)` when the source is a managed local value struct and its tracked thread fields can be mapped to the destination. Source paths become moved-from in the lifecycle state; copies remain unknown. This does not extend partial-move eligibility to raw pointer leaf fields: `move(record.threadHandle)` remains rejected by strict-move. Parameter/return ownership contracts and general ownership transfer are still incomplete.


## V87 — fixed-result string conversion facts for helper overloads (not ownership transfer)

The bounded struct-helper lifecycle resolver may use the exact `String` result type of the built-in `str(value)` when it appears directly as a helper argument. This only refines overload candidate selection; it does not infer the argument's type or add ownership, borrow, move or lifetime rules. Arbitrary user-defined calls and unresolved forms remain unknown.

## V86 — explicit primitive-cast facts for helper overloads (not ownership transfer)

The bounded struct-helper lifecycle resolver may use the explicit result type of `cast(Type, value)` when the target is a built-in primitive. This only improves overload candidate selection; it does not create a new ownership, borrow, move or lifetime rule. Class/enum casts and unsupported forms remain unknown.

## V84 — direct unary scalar-literal facts for helper overloads (not ownership transfer)

V84 lets the bounded struct-helper overload resolver recover exact result types for one unary operation applied directly to a supported scalar literal. Logical negation yields `boolean`; unary plus/minus on direct integer/floating literals preserves their numeric type; bitwise complement on a direct integer literal applies normal integer promotion. These facts only prune/rank lifecycle-summary helper candidates with the existing `scoreArg`. It is not general expression inference and does not alter ownership, move, borrow or lifetime rules. Identifier operands, nested unary expressions, casts, binary expressions, calls, aliases, member paths, globals and uncertain overloads remain unknown. No happens-before or data-race proof is implied.

## V83 — scalar auto value-copy facts for helper overloads (not ownership transfer)

V83 lets the bounded helper-overload analyzer reuse a proven primitive value type when a local `var auto` initializer is a simple identifier bound to an explicitly typed scalar or an earlier eligible `auto` fact. The source binding is resolved in the active lexical scope before the destination declaration is installed, so multi-hop value copies work while inner shadows and block exits retain their normal scope behavior. Calls, computed expressions, member paths, globals and unknown source bindings remain `unknown`. This improves only thread-handle lifecycle reporting; it changes no ownership, move, borrow or lifetime rule and is not a happens-before or data-race proof.

## V82 — direct-literal auto type facts for helper overloads (not ownership transfer)

V82 permits the narrow helper-overload analyzer to recover a local `var auto` type when its initializer is one direct scalar literal. It does not infer types from function calls, operators, casts, aliases or other computed expressions. The existing lexical scope resolver and `scoreArg` ranking remain authoritative. This improves only thread-handle lifecycle reporting; it changes no ownership, move, borrow or lifetime rule and is not a data-race proof.

## V81 — lexical scope for helper-overload lifecycle facts (not ownership transfer)

V81 improves only the bounded thread-handle helper resolver: it determines which explicitly declared primitive identifier binding is visible at the call site, respecting nested blocks, sibling branches and relevant loop/try/match scopes. This can select a unique overload where V80 conservatively returned unknown because a differently typed declaration existed in another scope. It does not change ownership, move, borrow or lifetime rules and is not a data-race proof.

## V76 — interprocedural struct-field lifecycle effects (not general ownership)

V76 summarizes direct and nested `ptr thread` fields of eligible free-function value-struct parameters. A uniquely resolved call applies each field's `must-join`, conditional, may-outlive or unknown lifecycle effect to the caller's corresponding path. The summary accepts direct `thread.join(parameter.field)` and a uniquely summarized direct helper taking that `ptr thread` field. Explicit `move(aggregate)` arguments use the existing move checker and retain the original worker-path attribution.

This does not establish general borrow/ownership contracts between caller and callee. Struct returns, storing or aliasing the aggregate, lambda capture, unresolved/ambiguous calls, recursive aggregate forwarding, methods, dynamic dispatch and FFI stay unknown. Returning a tracked struct does not transfer its tracked state to the caller. Repeated join effects are downgraded to unknown. Raw `ptr thread` leaf-field partial moves remain outside strict-move eligibility. No API, Runtime source or ABI change.

## V80 — declared-identifier overload facts (not ownership transfer)

V80 allows the bounded struct-parameter thread lifecycle analysis to distinguish helper overloads using a simple identifier only when all declarations of that name in the owning function agree on one explicitly-declared primitive type. It reuses normal overload scoring. Conflicting shadow declarations, globals, inferred/dynamic values, member paths and computed/call expressions remain unknown. This refines lifecycle-summary selection only; it does not add an ownership, move, borrow or lifetime contract, and does not change `--strict-move`, `--strict-ownership` or `--safe`.

## V79 — literal-aware overloaded struct-helper lifecycle summaries

V79 lets the bounded struct-parameter lifecycle analysis use exact AST literal types when resolving overloads. Candidate viability and ranking reuse the same `scoreArg` rules as regular call resolution, so a literal such as `true` or `1` can select the matching overload when its other arguments are also statically known. When arguments remain non-literal/unknown, the pass only removes candidates contradicted by known literal types; any unresolved tie stays `unknown`. This does not infer identifier types or add a general overload-aware ownership/borrow contract. `--strict-move`, `--strict-ownership`, and `--safe` behavior is unchanged.

## V78 — dependency-driven thread lifecycle summaries are not ownership transfer

V78 replaces V77's 32-round aggregate-summary scan with a reverse-dependency worklist. A uniquely resolved callee summary change re-analyzes only callers that depend on it; a 40-helper chain is covered by regression. A deterministic work budget protects compiler time, and exhaustion resets all partial aggregate summaries to `unknown`. This analysis does not define a general move/borrow contract between functions, does not make copying a raw thread handle safe, and does not establish struct return ownership. `--strict-move` and the existing ownership checks retain their separate responsibilities. See `CONCURRENCY.md` for the exact lifecycle summary boundary.

V77 historical: the earlier fixed-point implementation was limited to 32 whole-set rounds, so longer chains could remain unknown.


## V164: managed payload-enum fields in partial moves

V164 extends the existing `move(local.field.path)` subset so the final named field may be a managed payload enum (for example `enum Option<string>` or a managed `enum Result<...>` specialization). Intermediate path segments must still be value structs and the root must still be a directly owned mutable local value struct. Unit enums, scalar fields, arrays/index paths, raw pointers, classes/objects, parameters, borrowed aliases and heap/indirect roots remain unsupported.

Code generation transfers the complete payload-enum value into an owned temporary and zero-initializes the source field. The generated enum drop callback only releases the active payload variant; zero initialization marks the moved-from field as an empty sentinel for subsequent recursive struct cleanup. The existing projection-aware CFG tracks the moved path by root declaration identity, rejects repeated/overlapping moves and reads, and clears the moved state when that field or an enclosing subaggregate is reinitialized. This is a bounded extension of per-projection moved-state tracking, not a general runtime drop-flag bitmap or complete lifetime solver.

Regression coverage includes a nested `struct` path ending in `Option<string>`, extraction of an active `Some` payload, sibling-field access, reinitialization with both `Some` and `None`, use-after-move rejection and repeated-move rejection.


## V185: local const identifier array-index projections

V185 extends the fixed-array constant-index projection evaluator to visible initialized local `const int` and `const long` declarations when the initializer is proven by the existing bounded checked integer evaluator. Earlier local constants may be referenced by later constant initializers. Folded values are associated with the exact declaration node, not only the identifier spelling, and declaration initializers are evaluated against the pre-shadowing environment. The value must fit the declared signed integer width. Initializers are evaluated before the new declaration shadows a same-named outer binding. Mutable locals, parameters, globals/statics, uninitialized consts, non-integer consts and expressions containing calls or side effects remain unknown and conservative. This does not implement general compile-time evaluation or data-flow constant propagation.


## V186: narrow signed const array-index projections

V186 extends the V185 local constant array-index subset to initialized local `const byte` and `const short` values. The evaluator recognizes signed integer widths of 8, 16, 32 and 64 bits and records the value only when it fits the declared type. The constant remains associated with the exact AST declaration, and its initializer is resolved before the declaration shadows an outer name. Unsigned types, mutable bindings, global/static values, calls, side effects and unsupported expressions remain unknown/conservative. This is still a bounded borrow-projection evaluator, not general constant evaluation.


## V187: unsigned const array-index projections

V187 extends local constant array-index projections to initialized local `const ubyte`, `const ushort`, `const uint` and `const ulong` bindings. The evaluator carries unsignedness and validates the value against the declared 8/16/32/64-bit unsigned range before recording the exact declaration binding. Chained constant identifiers and shadowing rules remain in force. The internal projection index is a signed 64-bit integer, so only non-negative values representable by `int64_t` can be resolved; `ulong` values above `INT64_MAX`, unsigned unary negation, negative values, unproven expressions and all side-effecting forms remain conservative. This is not a general unsigned constant evaluator or complete borrow/lifetime checker.


## V188: bitwise and shift constant fixed-array borrow projections

The bounded local-borrow projection evaluator now folds pure integer `&`, `|`, `^`, `<<`, `>>` and unary `~` expressions. The implementation follows FAC's integer promotion and common-width/signedness rules for these operations, masks shift counts by the promoted operation width, and distinguishes arithmetic signed right shift from logical unsigned right shift. Narrow integer operands are promoted before bitwise complement and shift evaluation. The result is still only used to identify an exact non-negative signed-64-bit fixed-array projection. Unsupported expressions, calls, side effects and values outside that representable projection remain conservative. No general const evaluator, dynamic alias analysis, bounds checking or complete lifetime solver is implied.


## V189: constant conditional-expression fixed-array borrow projections

The bounded strict local-borrow fixed-array projection evaluator recognizes constant `ifv / eiv / elv` integer expressions. Conditions may be boolean literals, integer constant truth values, logical `!`, `&&`, `||` (with FAC short-circuit behavior), or integer comparisons (`==`, `!=`, `<`, `<=`, `>`, `>=`) whose operands are supported pure integer constants. The first provably true arm is selected; if all tested arms are false, the `elv` arm is selected.

For conservative type handling, every result arm must itself resolve as a supported pure integer constant and all arms must have identical integer width and signedness. Calls, mutable/unknown conditions, unsupported condition forms, non-constant arms and differing integer representations remain unknown/may-alias projections. The evaluator is bounded by the existing expression-visit budget. This does not add general constant evaluation, bounds checking, dynamic alias analysis, lifetime parameters or a complete borrow checker.

## V190: local const-boolean conditions in fixed-array borrow projections

The bounded constant `ifv / eiv / elv` projection evaluator now resolves initialized local scalar `const boolean` bindings when their initializer is proven by supported pure condition expressions. Earlier local boolean/integer constants may be referenced, and each binding is keyed by the exact declaration identity. Initializers are evaluated against the pre-shadowing context; a same-name declaration that is not proven constant removes the older value from the current scope. Mutable booleans, parameters, globals/statics, calls, side effects, uninitialized constants and unsupported expressions remain unknown/may-alias. Result arms still must be pure integer constants with identical width and signedness. This remains a bounded projection analysis, not general constant evaluation or a lifetime solver. See `LANGUAGE_CORE_V190.md`.



## V191: explicit primitive casts in constant fixed-array borrow projections

The bounded local-borrow projection evaluator can fold `cast(Type, value)` when the target is a primitive integer, boolean, `char` or `unichar` type and the source is a supported pure integer-like constant. It follows FAC code generation: narrowing keeps target-width low bits, widening sign-extends signed sources and zero-extends unsigned/character sources, and Boolean conversion maps zero/nonzero to false/true. Nested casts and cast-derived constant `ifv / eiv / elv` conditions are supported. Float casts, pointer/opaque/class/enum casts, arbitrary calls, mutable or side-effecting values, and unsigned intermediates above `INT64_MAX` remain unknown/may-alias. The final index is still restricted to a non-negative signed-64-bit projection. This is not general constant evaluation, bounds checking, dynamic alias analysis or a complete lifetime checker. See `LANGUAGE_CORE_V191.md`.


## V192: local const character identifiers in fixed-array borrow projections

Strict local-borrow projection analysis can now resolve initialized local scalar `const char` and `const unichar` identifiers when their initializers are supported pure integer-like constants. A `char` binding uses an 8-bit unsigned representation; `unichar` uses a 32-bit unsigned representation, matching the compiler's scalar type layout and integer-like conversion rules. Character constants can chain through supported expressions and can participate in supported integer comparison predicates used by `ifv / eiv / elv`. Values are associated with the exact declaration node, preserving shadowing and initializer-before-shadow behavior. Mutable character variables, parameters, globals/statics, uninitialized constants, side-effecting/unsupported initializers and values that cannot be represented by the bounded signed-64-bit projection value remain unknown/may-alias. This is not general const evaluation, Unicode scalar validation, runtime array bounds checking or a complete borrow/lifetime proof. See `LANGUAGE_CORE_V192.md`.


## V196: reachable-CFG local-borrow liveness

The local-borrow CFG now separates forward reachability from backward may-liveness. Only blocks reachable from the function entry participate in the fixed-point loan-use equations. Unreachable syntax is still visited by the semantic checker, but receives empty flow facts so a borrow conflict in code that cannot execute does not behave like an active runtime loan. `defer` use pinning is similarly limited to reachable defer nodes. This corrects the earlier behavior where a dead `else` block could contribute a borrow use even though the CFG condition had already removed its incoming edge.

The CFG can prove a limited set of predicates from syntax alone: Boolean literals, unary `!`, short-circuit `&&` / `||`, integer-literal comparisons and Boolean-literal equality/inequality. It does not fold identifiers, const-variable names, calls, arithmetic, floating comparisons or other unknown expressions; those remain conservative may-branches. This improves NLL/CFG precision without changing code generation, ownership syntax, public APIs or Runtime ABI. It is not general constant evaluation, inferred lifetime parameters or a complete borrow checker. Regression tests cover literal conditions, nested integer/Boolean comparisons, short-circuit pruning, runtime output preservation and a negative dynamic-condition case.

## V194: bounded floating-point arithmetic in fixed-array borrow projections

The strict local-borrow projection evaluator now folds a bounded subset of floating arithmetic: `+`, `-`, `*`, `/` and `%`. Operands must resolve to floating literals or visible initialized local `const float` / `const double` bindings, optionally mixed with supported integer/boolean/character constants. The evaluator tracks whether an operand is FAC float32 or float64 and follows `commonT()` promotion: if either operand is double, the operation is performed as float64; otherwise a float operand selects float32 and the result is rounded to single precision after each operation. `%` follows IEEE remainder (`frem` / `fmod`) behavior. These values can then flow through the V193 explicit saturating float-to-integer / Boolean cast logic to resolve fixed-array indexes.

The evaluator is bounded by the existing expression-visit budget and deliberately leaves exponentiation (`**`), division/remainder by zero, non-finite arithmetic results, calls, mutable variables, side effects and unsupported nested forms unknown/may-alias. It does not provide general floating-point constant evaluation, constant-condition comparison over floats, runtime bounds checking, dynamic alias analysis, lifetime parameters or a complete borrow checker. Regression tests include a float32 rounding-boundary case that would select a different index if accidentally evaluated as host double, double arithmetic and remainder, mixed float/double promotion, runtime alias writes, exact same-index conflict rejection and conservative rejection of unsupported exponentiation. See `LANGUAGE_CORE_V194.md`.

## V197: implicit control-flow lifetime regions

The local-borrow checker now assigns child lexical regions to each `if` arm, each `switch`/statement-`match` case and default arm, and each `match`-expression case and default arm, and each `try`/`catch`/`finally` body. This applies even when the branch statement has no explicit block. Synthetic `match` payload bindings are associated with the case region in both the symbol and frame-storage maps for statement and expression matches. Pointer-origin collection for match expressions also evaluates each branch in that case region, preventing `return`/store paths from losing the payload provenance. An address derived from such a binding can be used locally or passed through a verified noescape call, but cannot be stored in a pointer whose destination region is an ancestor of the case region. This closes a specific lifetime-provenance gap; it does not add general named lifetime parameters, reference returns/stores, arbitrary closure escape analysis or a complete borrow checker. See `LANGUAGE_CORE_V197.md`.
