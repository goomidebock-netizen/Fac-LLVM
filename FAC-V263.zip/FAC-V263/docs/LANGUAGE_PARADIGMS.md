# FAC Language Core — Programming Paradigms (V220)

เอกสารนี้กำหนดภาพรวมของ programming paradigms ที่ FAC รองรับและทิศทางการพัฒนาใน Language Core โดยยึด syntax และข้อจำกัดที่มีอยู่จริงใน source tree ของ V220 เป็นหลัก หัวข้อเหล่านี้เป็นรูปแบบการออกแบบโปรแกรมที่ใช้ร่วมกันได้ ไม่ใช่ dialect หรือ language mode แยกกัน

> **สถานะสำคัญ:** การมี syntax หรือ API ที่เกี่ยวข้องไม่ได้แปลว่า paradigm นั้นสมบูรณ์ทุกความสามารถ ตารางด้านล่างจะแยก implemented, partial และ planned ให้ชัดเจน

## 1. Paradigm overview

| Paradigm | แนวคิดหลัก | FAC surface ปัจจุบัน | สถานะ |
|---|---|---|---|
| Procedural Programming | แบ่งงานเป็น function/procedure และควบคุมลำดับการทำงาน | free functions, parameters, local state, modules, loops, branches, `switch`/`match`, `try`/`catch`, `defer` | รองรับใน core |
| Object-Oriented Programming | จัดการ identity, state และ behavior ผ่าน objects และ contracts | `class`, `obj`, constructors/destructors, inheritance, interfaces, abstract/final/override, virtual dispatch, access control | รองรับหลายส่วน; ยังมีข้อจำกัดตาม `OOP.md` |
| Generic Programming | เขียน algorithm/type ให้ใช้กับหลาย concrete types | generic class/struct/interface/method, `auto` generic functions, explicit type parameters, constraints, specialization | รองรับบางส่วน; free-function inference จำกัดตามรูปแบบพารามิเตอร์และ interface/virtual cases ยังจำกัด |
| Functional Programming | ใช้ function values, callbacks, expression และการแปลงข้อมูล | function values, lambda/closure, higher-order functions, `match` expression, `Option<T>`, `Result<T,E>`, postfix `?` | รองรับบางส่วน; capture และ composition ยังมีข้อจำกัด |
| Metaprogramming | ตรวจสอบหรือคำนวณข้อมูลระหว่าง compile time | integer/bool constant evaluation, `static_assert`, bounded scalar free-function `consteval`, `typeOf<T>()`, `sizeof<T>()`, `alignof<T>()`, `fieldCount<T>()`, `fieldName<T,I>()`, `fieldType<T,I>()`, `fieldOffset<T,I>()`, compile-time specialization, immutable typed-expression HIR projection และ internal C++ `TypedAstFactory` สำหรับ generated expression nodes | มี bounded structural reflection เฉพาะ public non-static fields ของ resolved struct/class; Factory ยังไม่เปิดให้ FAC source, ไม่สร้าง declarations หรือเชื่อม codegen; ยังไม่มี generic/full reflection, general compile-time execution หรือ macro system |
| Template Programming | สร้าง type/code ตาม compile-time parameters | type-level specialization, named generic arguments, type defaults on struct/class/interface/enum/function/method, `const int` parameters and defaults on struct/class/function/method, plus bounded free-function const inference | รองรับบางส่วน; const arguments ยังจำกัดเป็น integer constant expressions และ fixed-array layout |
| Low-level Programming | ควบคุม memory, pointer, ABI และการเชื่อม native code | `ptr`, dereference, pointer arithmetic, `alloc`/`free`, `volatile`, `align`, `extern`, `link`, LLVM native codegen | มี native subset; unsafe และ ABI บางส่วนยังเป็นข้อจำกัด |

## 2. Procedural Programming

ใช้ free function เป็นหน่วยแบ่งความรับผิดชอบ ส่งข้อมูลผ่าน parameters และ return values ส่วน state ที่เปลี่ยนแปลงได้ควรถูกจำกัดให้อยู่ใน scope ที่จำเป็น

```fac
function int sum(array int values[4]) {
    var int total = 0
    for++(sizeof(values)) {
        total += values[for++.i]
    }
    return total
}

public function void main() {
    array var int scores[4] = {10, 20, 30, 40}
    terminal.out.println(sum(scores))
}
```

แนวปฏิบัติของ core:

- ใช้ function parameters/return values เป็นช่องทางหลักในการส่งข้อมูลระหว่างขั้นตอน
- ใช้ `ref` เฉพาะเมื่อ function ต้องแก้ไข storage ของ caller; ใช้ `ref const` สำหรับการอ่านผ่าน borrow
- ใช้ `defer` สำหรับ cleanup ที่ต้องผูกกับ scope และใช้ `try`/`catch` เฉพาะเส้นทาง error ที่ต้องจัดการ
- หลีกเลี่ยง mutable global state เมื่อ local state หรือ explicit parameter ทำได้

## 3. Object-Oriented Programming

FAC แยกความหมายของ type ให้ชัด:

- `class` + `obj` ใช้กับ identity/reference semantics และ object lifetime
- `struct` ใช้กับ value semantics; การส่ง/คัดลอกเป็น value ตามกฎของ type
- `interface` ใช้กำหนด contract; `abstract class` ใช้แชร์ state/implementation บางส่วน

```fac
interface Shape {
    function int area()
}

class Rectangle implements Shape {
    public var int width
    public var int height

    constructor Rectangle(int w, int h) {
        this.width = w
        this.height = h
    }

    public function int area() {
        return this.width * this.height
    }
}

obj Shape shape = new Rectangle(3, 4)
var int size = shape.area()
```

รองรับ access control, constructors/destructors, inheritance, interface implementation, abstract/final/override, static members และ virtual dispatch ตามขอบเขตที่อธิบายใน [`OOP.md`](OOP.md) และ [`CLASS_OBJECTS.md`](CLASS_OBJECTS.md) ไม่ควรตีความว่า FAC มี feature parity กับ Java/C++ ทุกกรณี; generic virtual/interface methods และข้อกำหนดบางส่วนของ initialization/resource policy ยังเป็นงานต่อเนื่อง

## 4. Generic Programming

Generic programming ใช้ type parameter และ constraints เพื่อ reuse algorithm/type โดยยังคง static typing จากนั้น compiler สร้าง concrete specialization ใน compile time

```fac
public struct Pair<K, V> {
    public K key
    public V value
}

function auto first(list auto values) {
    return values[0]
}

public function void main() {
    struct Pair<int, dyn string> item = Pair<int, dyn string>(1, "one")
    list var int values = {10, 20}
    var int initial = first(values)
}
```

ขอบเขตปัจจุบัน:

- generic classes, structs, interfaces, methods และ generic payload enums ใช้ type parameters และ compile-time specialization
- generic method ใช้ `auto` หรือ explicit `function<T>`; multi-bounds ใช้ `T: BoundA & BoundB`
- V220 HIR บันทึก generic free-function inference สำหรับ direct `T`, `ptr T`, `list T` และ `array T` ที่พิสูจน์ชนิด argument ได้ แต่ HIR diagnostics ยังเป็น provisional และ Codegen ยังเป็นผู้ตัดสินผล compile จริง
- inference ของ arbitrary nested generic constructors, return-only type parameters, generic interface methods และ generic virtual/override methods ยังไม่รองรับครบ

รายละเอียด specialization/budget: [`GENERIC_SPECIALIZATION.md`](GENERIC_SPECIALIZATION.md) และ inference: [`GENERIC_INFERENCE_HIR_V220.md`](GENERIC_INFERENCE_HIR_V220.md)

## 5. Functional Programming

Function เป็นค่าได้ จึงเก็บในตัวแปร ส่งเป็น argument และใช้เป็น callback ได้ Lambda สร้าง closure โดย capture ตัวแปรภายนอกแบบ by-value ตามกฎปัจจุบัน

```fac
function int apply(function int callback(int), int value) {
    return callback(value)
}

public function void main() {
    var function int triple = function(int value) {
        return value * 3
    }
    var int answer = apply(triple, 7)
}
```

องค์ประกอบ functional ใน core ยังรวม expression `match`, payload enums เช่น `Option<T>`/`Result<T,E>` และ postfix `?` สำหรับ propagate failure

ข้อจำกัดที่ต้องรักษาไว้ในเอกสารและ compiler diagnostics:

- lambda capture เป็น by-value; การ capture object เก็บ reference ไปยัง object เดิมตาม ownership rules
- ไม่รองรับ general capture-by-reference; การเขียนทับ captured local โดยปริยายถูกปฏิเสธ (มี compatibility flag สำหรับพฤติกรรมเก่า)
- nested higher-order workflows, immutable collection APIs, lazy iterators และชุด combinators สำหรับ `Option`/`Result` ยังไม่ครบ

ดู [`LAMBDA.md`](LAMBDA.md) และ [`LANGUAGE_CORE.md`](LANGUAGE_CORE.md)

## 6. Metaprogramming

Compile-time behavior ที่เปิดให้ผู้ใช้ใช้ได้ในปัจจุบันประกอบด้วย bounded constant evaluation, module-level `static_assert`, scalar free-function `consteval` และ typed type/layout queries:

```fac
const var int PAGE_SIZE = 4096
const var int ALIGNMENT = 64

static_assert(PAGE_SIZE % ALIGNMENT == 0, "page alignment")
static_assert((ALIGNMENT & (ALIGNMENT - 1)) == 0, "alignment must be a power of two")
```

Base evaluator รองรับ integer/boolean constant expressions ตามรายการใน [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md) และไม่มี runtime side effects ส่วน `consteval` เป็น interpreter แยกที่รันเฉพาะ function ที่ทำเครื่องหมายไว้และใช้ subset ตาม [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md); ไม่สามารถเรียก ordinary runtime functions, อ่านไฟล์, ใช้ network, spawn process หรือเรียก FFI ได้

V220 รองรับ `consteval` subset สำหรับ scalar free functions โดยมี local variables, `if/else`, return, nested calls และ recursion ภายใต้ depth/step budget และมี `typeOf<T>()`, `sizeof<T>()`, `alignof<T>()` เป็น typed constant intrinsics (`Type` category หรือ integer layout values). เพิ่ม structural field queries `fieldCount<T>()`, `fieldName<T,I>()`, `fieldType<T,I>()`, `fieldOffset<T,I>()` สำหรับ resolved struct/class โดย enumerate เฉพาะ public non-static instance fields (รวม inherited public fields ของ class); numeric queries ใช้ใน `static_assert`, supported `consteval` และ const generic expressions ได้. ขอบเขตนี้ไม่ใช่ generic/full reflection, source-level AST builder หรือ declaration generation. ภายใน compiler มี immutable typed-expression projection และ C++ `TypedAstFactory` สำหรับสร้าง literal, unary/binary, tuple และ call node ที่ผ่าน type/identity checks แล้ว แต่ API นี้ไม่เปิดให้ FAC source หรือ `consteval`, ไม่สร้าง declarations และยังไม่ถูกนำไป codegen. ยังไม่มี general compile-time execution, source-level typed declaration builders หรือ macro expansion; ระบบที่กว้างกว่านี้ต้องมี sandbox, deterministic budgets, diagnostics และ source maps ก่อนจึงจะเพิ่มเป็น language feature ได้ ดู [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md), [`TYPED_AST_BUILDER_V220.md`](TYPED_AST_BUILDER_V220.md) และ [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md).

## 7. Template Programming

ในเอกสาร FAC ให้แยกความหมายดังนี้:

- **Generic programming**: parameterize code/type ด้วยชนิด เช่น `Pair<K, V>` หรือ `function<T>`
- **Template programming**: parameterize declarations ด้วย compile-time values เช่น dimensions หรือ layout sizes

FAC รองรับ type-level specialization และ bounded `const int` generic parameters ใน `struct`/`class`, free functions และ methods โดยใช้ integer constant expressions กำหนดค่าที่ฝังใน specialization และใช้กำหนดขนาด fixed array ได้ นอกจากนี้ generic type parameters รองรับ trailing defaults บน struct/class/interface/enum/function/method ส่วน `const int` defaults รองรับบน struct/class/function/method; ทั้งหมดใช้ร่วมกับ named/partial argument lists:

```fac
public struct FixedBuffer<T = int, const int N = 16> {
    public array var T values[N]
    public array var T doubled[N * 2]
}

public function void main() {
    struct FixedBuffer<int, 16> samples
    struct FixedBuffer defaultsToInt
    struct FixedBuffer<N = 8> namedPartial
    samples.values[0] = 42
}
```

ข้อจำกัด V220: รองรับเฉพาะ `const int`; explicit const argument ต้องเป็น integer constant expression ที่ bounded evaluator ประเมินได้ รวมถึงการเรียก scalar free-function `consteval` ที่รองรับตาม [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md). Generic free functions อาจอนุมานค่า const ได้เมื่อพารามิเตอร์ประกาศ fixed-array extent เป็น `[N]` โดยตรงและ argument เป็น fixed-size array ที่ทราบขนาด; การอนุมานไม่แก้สมการเช่น `[N * 2]` และไม่อนุมานจาก list หรือ runtime length. Generic methods และ generic struct/class instantiations ไม่อนุมาน arguments จากบริบท แต่สามารถละ parameters ที่มี defaults ได้. Defaults ต้องอยู่ท้าย declaration ต่อเนื่องกันและถูกประเมินตามลำดับประกาศ; defaults อ้างถึง parameters ก่อนหน้าได้ตามขอบเขตใน `GENERIC_DEFAULT_ARGUMENTS_V220.md`; interface/enum defaults เป็น type-only และยังไม่เพิ่ม const parameters ให้สอง declaration ชนิดนั้น. Type/interface constraints สำหรับ const parameter, generic/method `consteval`, typed AST metaprogramming และ unrestricted macros ยังไม่รองรับ. Array dimensions ที่เกิดจากการแทนค่าต้องมากกว่า 0 และยังผ่าน layout/overflow checks ปกติ. ดู [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md), [`CONST_GENERIC_FUNCTIONS_V220.md`](CONST_GENERIC_FUNCTIONS_V220.md), [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md) และ [`GENERIC_DEFAULT_ARGUMENTS_V220.md`](GENERIC_DEFAULT_ARGUMENTS_V220.md)

## 8. Low-level Programming

FAC เปิด native operations สำหรับกรณีที่ต้องควบคุม memory หรือเชื่อมกับระบบภายนอก:

```fac
ptr int value = alloc(type(Int))
[value] = 42
var int copied = [value]
free(value)
value = null
```

พื้นผิวที่เกี่ยวข้องประกอบด้วย raw pointer/dereference/arithmetic, allocation/free, `volatile`, `align`, `extern`/`link`, FFI และ LLVM native code generation

กฎความปลอดภัย:

- raw `ptr` ไม่ได้ bounds-check แบบ array/list; ต้องตรวจขนาด, อายุการใช้งาน, alignment และการปล่อย memory ให้ครบ
- ทุก pointer ที่ได้จาก `alloc` ต้องมีเจ้าของและ cleanup ที่ชัดเจน; ใช้ `defer free(p)` ได้เมื่อ lifetime ผูกกับ scope
- `volatile` ไม่ใช่ atomic และไม่สร้าง synchronization หรือ happens-before relation
- `extern` lifetime/effect annotations เป็น contract กับ foreign code; compiler ไม่สามารถพิสูจน์ว่า native implementation ปฏิบัติตามคำสัญญา
- อย่าอ้าง stable C layout/calling-convention portability เกินกว่าที่ `FFI.md` และ `PLATFORM_STANDARDS.md` ระบุ

ดู [`FFI.md`](FFI.md), [`OWNERSHIP.md`](OWNERSHIP.md), [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md) และ [`PLATFORM_STANDARDS.md`](PLATFORM_STANDARDS.md)

## 9. Combining paradigms

Paradigms เป็นเครื่องมือหลายชุดในภาษาเดียว ไม่ควรบังคับให้ทั้งโปรแกรมใช้รูปแบบเดียว:

- ใช้ procedural functions สำหรับ orchestration และ business rules ที่ทำงานเป็นลำดับ
- ใช้ OOP สำหรับ object ที่มี identity, lifecycle หรือ polymorphic behavior
- ใช้ struct/enum กับข้อมูลแบบ value และ closed alternatives
- ใช้ generics สำหรับ algorithm/container ที่ต้องใช้กับหลาย concrete types
- ใช้ functional callbacks/lambdas เมื่อการส่ง behavior เป็น parameter ช่วยลด coupling
- ใช้ compile-time assertions เพื่อป้องกัน invariant ที่ตรวจได้ก่อนเริ่ม runtime
- จำกัด low-level pointer/FFI code ไว้ที่ boundary และห่อด้วย API ที่มี ownership contract ชัดเจน

## 10. Implementation gate

การเพิ่ม paradigm feature ใหม่ถือว่า implemented ต่อเมื่อผ่านทุกข้อที่เกี่ยวข้อง:

1. มี syntax/grammar ใน `syntax/fac_spec.fac` และ parser coverage
2. มี semantic/type/ownership rules พร้อม diagnostics ที่ deterministic
3. มี codegen/runtime behavior ที่กำหนดไว้และไม่ทำให้ ABI เปลี่ยนโดยไม่ตั้งใจ
4. มี positive, negative, boundary และ regression tests
5. อัปเดต Language Core, target matrix, README และ API contract เมื่อ public surface เปลี่ยน
6. ผ่าน compiler/runtime builds และ CI ที่เกี่ยวข้อง

โปรแกรมตัวอย่าง/regression ที่รวมการใช้ procedural, OOP, generic/template-style specialization, functional, metaprogramming และ low-level programming อยู่ที่ [`tests/cases/t220_language_paradigms.fac`](../tests/cases/t220_language_paradigms.fac)
