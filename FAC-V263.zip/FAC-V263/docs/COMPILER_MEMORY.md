# FAC compiler memory behavior (V122)

V122 makes the frontend/codegen lifetime end before the LLVM backend is launched. The frontend owns imported `Program` ASTs, `Gen` symbol/type tables, generic specialization caches, IR construction buffers and temporary maps. Once `Gen::generate()` has completed, the backend needs only the completed LLVM IR, link flags, entry-point status and (for `--lib --emit-header`) the generated C header. V122 copies out those small products, exits the frontend scope, and only then invokes the backend.

The import loader also stopped copying each parsed module's `imports` vector. It retains a pointer to the individually heap-allocated `Program` object and iterates its immutable import list while recursive loads may reallocate the outer `vector<unique_ptr<Program>>`; moving a `unique_ptr` does not move its pointee.

On glibc, large compilations additionally call `malloc_trim(0)` after the frontend objects have been destroyed. This is best-effort allocator page return, not a correctness requirement. It is gated to compilations with at least 32 modules or 4 MiB of source to avoid adding allocator-trim overhead to small builds. Other platforms use ordinary C++ object destruction and their native allocator behavior; no platform API or FAC API is added.

## Measurement scope

`benchmarks/compiler_memory.py` creates an import graph and substitutes a tiny `FAC_CC` backend probe. The probe samples `/proc/<facc-pid>/status` at backend launch, so `VmRSS` estimates memory still resident after frontend teardown while `VmHWM` records process peak. It does not run LLVM/native code generation. Run on Linux:

```sh
make clean
make CXXFLAGS='-std=c++17 -O0'
python3 benchmarks/compiler_memory.py ./build/facc --modules 129 --functions 250 --repeat 3
```

On the Linux x86_64 development host, the 130-module / 32,251-function workload (2,832,098 source bytes) measured median RSS at backend launch around 592,500 KiB on V121 and 21,460 KiB on V122 (about 96.4% less memory retained at that phase). Median process peak remained about 609,600 KiB in both versions because all imported ASTs are still needed simultaneously during frontend analysis/code generation. This release therefore reduces memory retained during backend execution, not the frontend peak. The observed compile-to-backend wall times were noisy and did not establish a reliable general speedup.

The glibc trim path is not exercised on Windows/macOS or non-glibc systems. Their source semantics and API surface are unchanged, but memory returned to the OS depends on the platform allocator.
