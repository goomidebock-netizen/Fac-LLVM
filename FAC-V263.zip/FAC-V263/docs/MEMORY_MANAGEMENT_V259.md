# FAC Memory Management — V259

## Pointer arithmetic in inferred returns from enum payloads

V259 closes a bounded strict-ownership escape path in inferred (`auto`) return
functions. V257 introduced a check for direct raw-pointer enum payload returns;
V258 extended it to nested result-producing `match`/`ifv` expressions and fixed
lexical shadowing for nested pattern bindings. Those checks did not cover
pointer-preserving expressions around the payload binding.

The V258 compiler accepted a result arm such as `pointer + 0`. Because enum
payload pointer provenance is not yet tracked, the compiler cannot prove that
such a pointer outlives the returning function. V259 now recognizes these
bounded pointer-valued result forms:

- `pointer + integer` and `integer + pointer`.
- `pointer - integer` (while `pointer - pointer` remains a scalar difference).
- Assignment expression `pointer = pointer`.
- Compound updates `pointer += integer` and `pointer -= integer`.
- Prefix and postfix `++`/`--` on the pointer binding.

Comparisons and other scalar operators remain separate from pointer-valued
result expressions. The regression suite rejects ten pointer-valued forms and
retains an acceptance case for scalar pointer difference.

This remains a bounded fail-closed guard, not general pointer provenance
tracking. Enum payload pointers are still not tracked through arbitrary
operations, heap/container storage, or all call paths. No general borrow
checker, first-class `ref T` return, or general heap escape analysis is added.

No source syntax, Runtime behavior, ARC/GC, public API, ABI, or
`--memory-safe` accepted subset is changed.

## Validation

- Lifetime: 141 PASS, including ten pointer-result rejection cases and the
  scalar pointer-difference acceptance case.
- Ownership, Move, Partial Move, Memory-Safe, Generic, Codegen, Lexer and Parser
  regression suites passed.
- Runtime regression and Tools (91/91) passed.
- Negative (134/134) and Limits (21/21) passed.
- API compatibility: 0 breaking changes; 132 warnings against V128.
- Safe Profile: 433 passed, 4 known V258-baseline failures remain.
- Full Semantic suite did not complete within the execution time limit; full
  CMake/CTest, sanitizer, cross-platform and production qualification are not
  claimed.
