# FAC V163 compiler performance report

## Change

The parser uses two fixed vocabularies on frequently evaluated decision paths:

- `Parser::isTypeWord()` recognizes the primitive type words.
- `Parser::isReserved()` recognizes language-reserved words and primitive types.

V163 stores these vocabularies in immutable `std::unordered_set<std::string_view>` tables. The string views refer only to string literals with static lifetime, so lookups do not allocate or copy keys. Primitive type words are included directly in the reserved table, making `isReserved()` a single lookup instead of a reserved-word lookup plus a type-word lookup. The sets are only queried after initialization and are never mutated. Matching remains exact and case-sensitive.

No syntax, parser diagnostic, AST, language API, Runtime ABI, or generated program semantics are intentionally changed.

## Reproduction

```sh
make bench-compiler-keywords
build/bench_keywords 2000000 9

# Broader parser workload (separate measurement)
g++ -std=c++17 -O2 -DNDEBUG -Isrc \
  benchmarks/compiler_parser.cpp src/lexer.cpp -o build/bench_parser
build/bench_parser 5000 8
```

## Measurements

Host: Linux x86-64, GCC 14.2. Benchmark binary: C++17 `-O3 -DNDEBUG`. Keyword workload: 25 fixed strings (type words, reserved words, and ordinary identifiers), 2,000,000 iterations and 4,000,000 lookups per process. Seven alternating V162/V163 process pairs each used one warm-up and five measured samples; the reported values are the median of the seven process medians.

| Release | Median process time |
|---|---:|
| V162 | 113.514 ms |
| V163 | 47.069 ms |

This is 2.41x faster / 58.5% lower latency for the fixed keyword/type membership workload. It is not a claim about whole compilation or generated-program execution.

The 5,000-function parser benchmark was also run with alternating V162/V163 binaries. Its measurements overlapped and varied across runs; they do not establish a reliable whole-parser speedup. The narrower membership benchmark is the supported performance claim.

## Correctness and validation

- Exact vocabulary comparison against V162: all 16 primitive type words and all 93 reserved words (including primitive types) match; no words were added or removed.
- Focused parser regression: 37/37 checks passed, including case-sensitive positive/negative membership checks.
- `isReserved("int")` and `isReserved("void")` remain true, matching the previous behavior.
- Prefix lookalikes such as `terminal` and `readonly_value` remain ordinary identifiers.
- Compiler and Runtime static-library builds completed with GCC 14.2 / C++17 `-O0`; `facc --version` reports V163.
- Lexer regression: 18 checks passed; generic specialization tests: 3/3; semantic ancestry: 17 checks; codegen constant-fold and recursion-guard checks passed; memory-safe profile: 25 passed / 0 failed.
- Focused parser regression also passed with AddressSanitizer and UndefinedBehaviorSanitizer with leak detection enabled.
- API compatibility against the V128 baseline: 0 breaking changes, 27 warnings and 632 cumulative additions. The warnings/additions are baseline differences accumulated since V128, not new changes introduced by V163; the parser optimization changes no public declarations.
- Version manifest/header consistency and JSON validation passed.

The full top-level test suite was not run. An optimized `-O2` compiler build exceeded the environment time limit while compiling `src/main.cpp`; the compiler and Runtime static library did complete at `-O0`. Windows/macOS and non-x86-64 builds or performance results are not claimed.
