## V135 Runtime cleanup update

The fail-closed `--memory-safe` source restrictions are unchanged from V134. V135 adds targeted cleanup of partially built string lists during `sys.args` and JSON array conversion errors. This improves two Runtime failure paths but does not remove the general `setjmp`/`longjmp` destructor limitation or establish Rust-equivalent guarantees. See [`SECURITY_AUDIT_V135.md`](SECURITY_AUDIT_V135.md).

## V134 `--memory-safe` subset

V134 adds a stricter, opt-in fail-closed language subset. It forbids raw/opaque pointers, manual heap storage, `ref` borrows, FFI/native exports/linking, unsafe blocks/functions, native command-line link inputs, and imports/function references for built-in APIs that expose raw native handles (plus the process-capable `sys` module). It also enables overflow checks and validates imported source stdlib instead of trusting it. This subset can reject programs that are safe by convention; the restriction is intentional because the compiler does not yet have a complete lifetime proof.

It is not equivalent to Rust and does not prove the C++ Runtime correct, eliminate all compiler defects, prove data-race freedom, or provide an OS sandbox. The runtime still uses `setjmp`/`longjmp` for FAC error transfer. See [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md).

# FAC Security Build Profile — V45

## Recommended command

```sh
facc app.fac --secure -O2 -o app
```

`--secure` is an additive convenience flag that enables all existing opt-in static/runtime guardrails together:

- `--safe`: raw pointer dereference/arithmetic, raw allocation/free, FFI and unsafe calls must remain in explicit `unsafe` blocks/functions;
- `--strict-safe`: reject unverified indirect calls from checked thread closures;
- `--strict-ownership`: check direct mutable/shared borrow overlap and writes through `ref const` parameters;
- `--strict-move`: enable explicit `move(local)` and limited use-after-move/double-move checks.

The flag is equivalent to passing those four options individually. It does not disable array bounds or division checks and cannot be combined with the existing unsafe fast flags that turn those checks off.

## Important limits

`--secure` is a **best-available V45 checking profile**, not a formal memory-safety guarantee. It does not create a full CFG borrow checker, lifetime checker, general dangling-pointer detection, whole-program static data-race proof, or verification of foreign/native code. `unsafe` blocks and trusted runtime/stdlib code still require audit. See [`MEMORY_MODEL.md`](MEMORY_MODEL.md) and [`CONCURRENCY.md`](CONCURRENCY.md).

For CI, run the compiler with `--secure` in addition to the normal regression, negative, ownership, move, sanitizer and concurrency test suites. Do not replace sanitizer/stress testing with a successful `--secure` compile.
