# FAC V211 — Runtime DataFrame memory-safety hardening

## Scope

V211 is a targeted Runtime hardening release. It does not add syntax, public APIs, compiler semantics or ABI changes.

## DataFrame handle validation

All APIs that consume a non-null DataFrame handle now pass through a central shape validator. It rejects:

- negative row counts;
- non-positive or over-limit column counts;
- row/column products above the shared 16,777,216 float64-value budget, using division before multiplication;
- column-name vectors whose length differs from the declared column count;
- backing value vectors whose length differs from the checked row/column product.

A zero-row frame remains valid when it has at least one column, matching the existing header-only/empty-filter behavior. `dataframe.free` remains able to release a handle without first validating it.

## Grouped reductions

`groupMean`, `groupSum`, `groupMin`, `groupMax` and `groupCount` now maintain one aggregate record per distinct numeric key. This avoids storing a second vector containing every source value. The result is a two-column DataFrame, so the Runtime caps distinct keys at 8,388,608 before inserting a new map entry. The result is shape-validated before it is published to FAC code.

C++ `std::bad_alloc` and `std::length_error` raised while constructing the group map or result are translated to FAC Resource errors. The temporary group workspace and any partially-built result remain registered on the Runtime cleanup stack until ownership is committed.

Aggregation semantics remain: keys are sorted ascending; mean and sum use accumulated extended precision where supported by the host; minimum and maximum are unchanged; count remains an exact integer-valued float64 for the bounded input size.

## Compatibility and explicit limits

- No new public symbols or API contract changes.
- No C ABI or Runtime ABI layout change.
- No changes to FAC language syntax or ownership analysis.
- DataFrame storage is now checked against the same 16,777,216-value limit as Tensor.
- Grouping remains an in-memory numeric operation; streaming/group spill, mixed-type cells and general database semantics are not added.
- This is targeted DataFrame Runtime hardening, not a universal guarantee that all Runtime C++ allocation failures are contained.

## Regression coverage

`tests/runtime/dataframe_shape_safety.cpp` checks valid empty frames, negative dimensions, over-budget products, mismatched backing storage, over-limit schemas, group ordering and all five aggregate results. It injects one-shot C++ allocation failures across grouped aggregation and verifies that failures surface as FAC Resource errors while the source DataFrame remains usable.
