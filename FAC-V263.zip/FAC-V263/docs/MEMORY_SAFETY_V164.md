# FAC V164 — Memory Safety & Lifetime Analysis

## Change

The compiler now accepts a managed payload enum as the final leaf in the existing local value-struct partial-move operation. The source is transferred into an owned temporary and zero-initialized. This enables recursive drop to safely process the remaining struct fields while skipping the moved payload enum.

The existing projection-aware CFG continues to track moved paths by declaration identity. Reads after a move and repeated/overlapping moves are rejected; assigning a replacement to the moved field clears that moved-path fact. No public API or Runtime ABI changes are made.

## Explicit limits

This release does not implement general lifetime parameters, reference return types/fields, a Rust-equivalent borrow checker, general runtime drop-flag bitmaps, dynamic array/index moves, raw-pointer/FFI lifetime proofs, or whole-program race freedom. Existing strict-ownership local borrows remain a bounded lexical-region/CFG analysis. `--strict-move` and `--strict-ownership` remain opt-in; `--secure` enables both.

## Validation

Validation status is recorded in `docs/STATUS.md`. Only tests actually run for this release are reported there. Platform scope is limited to the Linux x86-64 host used for this release.
