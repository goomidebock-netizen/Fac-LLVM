# FAC Memory Management Direction — V225

V225 extends strict-ownership pointer provenance tracking to a bounded form of **local value-struct storage**. Ownership/lifetime analysis remains the primary compile-time model. This release does not change ARC, the Cycle Collector, Runtime allocation, public APIs or ABI.

## 1. What is supported

Under `--strict-ownership` / `--secure`, a local value `struct` may contain a raw pointer field when the compiler can track the pointer's origin and prove that the origin outlives the lexical storage region of the destination struct. The supported paths include:

- Initializing a local value struct through its constructor with a tracked pointer value.
- Assigning a tracked pointer to a direct pointer field of a local value struct.
- Nested by-value struct fields, including pointer fields below nested value structs.
- Copying a pointer-bearing value struct to another local value struct, subject to the same lifetime constraints.
- Reading a pointer-bearing field and dereferencing it while the recorded origin remains valid.
- Pointers obtained through verified named-lifetime contracts when the contract identifies the source lifetime.

The implementation stores conservative provenance summaries by local declaration identity. Pointer-bearing fields and nested value-struct fields inherit the root aggregate's union of pointer origins. Scalar fields do not inherit pointer provenance. Because this is a root-level union rather than a fully field-sensitive aggregate borrow graph, it may conservatively over-approximate sibling pointer fields and reject some safe programs.

## 2. What remains rejected

The following cases remain fail-closed:

- An untracked non-null pointer passed to a value-struct constructor or assigned to a pointer field.
- A `noescape` parameter stored in an aggregate; `noescape` explicitly forbids retention.
- A pointer whose owner may expire before the destination struct.
- Returning or passing a pointer-bearing aggregate to an unverified/retaining function.
- Capturing a pointer-bearing local aggregate in a closure.
- Storing pointers in `class` / `obj` fields, `weak obj`-reachable storage, globals, containers, array/index destinations or unknown paths.
- Storing through an alias or through a path that crosses a managed-object boundary.
- General heap-stored references, arbitrary pointer aliases, and aggregates whose lifetime cannot be tied to a tracked local destination.

A null pointer is permitted because it carries no referent provenance. The compiler does not infer safety from a raw pointer's spelling alone: it requires a recognized local address or a verified named-lifetime source.

## 3. Analysis limits

This is not a complete aggregate lifetime contract system or a general heap borrow graph. Provenance is conservatively summarized for each local aggregate root and may accumulate across field writes; it is not yet killed with field-specific precision after every overwrite. The checker therefore favors false positives over dropping a possible origin. It does not prove arbitrary pointer dereferences safe, does not cover unsafe/FFI behavior, and does not make raw pointers part of the `--memory-safe` profile.

The implementation is compile-time-only. No FAC syntax, Runtime behavior, ARC reference-counting rules, Cycle Collector policy, public API, C ABI or Runtime ABI changed.

## 4. Validation

V225 adds positive runtime fixtures for nested local value-struct pointer fields, later field assignment, aggregate copy, and a pointer obtained through a verified named-lifetime input. Negative fixtures cover short-lived owners, return escape, calls to unverified functions, managed `obj` field storage, untracked constructor/assignment inputs, and closure capture.

On the delivered Linux GCC C++17 `-O0 -g0` build, the lifetime suite passed 55 checks; ownership suites passed 255 checks; the `--memory-safe` suite passed 39/39; move/partial-move suites passed 48 checks; the tools suite ran 91 tests with 6 skipped; lexer passed 18 checks; parser passed 68 checks plus an AST model regression; and the focused codegen constant-fold/recursion-guard tests passed. `api-check` completed successfully; compatibility audit against V128 reported 0 breaking changes and 132 warnings. Sanitizer, cross-platform and full legacy-suite qualification are not claimed.

See [`MEMORY_MODEL.md`](MEMORY_MODEL.md), [`OWNERSHIP.md`](OWNERSHIP.md), [`MEMORY_SAFE_PROFILE.md`](MEMORY_SAFE_PROFILE.md), and the `v225_*` fixtures under `tests/lifetimes/`.
