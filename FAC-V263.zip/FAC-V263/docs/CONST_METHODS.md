# FAC const-qualified instance methods (V50)

## Syntax

Place `const` after the parameter list of an instance method:

```fac
class Counter {
    public var int value

    public function int get() const {
        return this.value
    }

    public function void increment() {
        this.value++
    }
}

function int read(ref const obj Counter counter) {
    return counter.get()
}
```

With `--strict-ownership`, `counter.get()` is accepted because `get` promises not to mutate its receiver. `counter.increment()` is rejected because `increment` is not const. The same rule applies inside a const method: it cannot directly mutate `this`, call a non-const method on `this`, or capture `self` in a closure.

## Interfaces and inheritance

Interface declarations may carry the qualifier, and implementations must match it exactly:

```fac
interface IReadOnly {
    function int get() const
}

class Counter implements IReadOnly {
    public var int value
    public function int get() const { return this.value }
}
```

Overrides must also preserve the parent's const qualifier. Static methods and top-level functions cannot be const-qualified.

## ABI and performance

The qualifier is compile-time metadata. It does not add a runtime wrapper, hidden parameter, reference count, or ABI change. Calls use the same native calling convention as before.

## Enforcement limits

The current `--strict-ownership` pass checks direct AST-visible receiver writes, calls to non-const receiver methods, known mutable-ref use, and closure capture of `self`. It is conservative and may reject safe code when it cannot identify a method's receiver type. It does not prove deep immutability through raw pointers, FFI, global variables, hidden aliases, arbitrary called functions, or interior-mutability abstractions. Use `unsafe` only at explicit low-level boundaries and do not treat this feature as a full Borrow Checker or Lifetime Checker.
