# FAC V220 — Named Generic Arguments

## Purpose and scope

FAC V220 supports named arguments in generic argument lists for generic
`struct`/`class` types, generic free functions and generic methods. A name is
written with `=` and must match a generic parameter declared by the target.
This is a source-level convenience: after validation, arguments are reordered
to declaration order before type checking, const substitution, specialization
and cache lookup.

Named generic arguments are not named arguments for ordinary runtime function
parameters. A later V220 update adds trailing generic defaults and partial argument
lists when omitted parameters have defaults; see
[`GENERIC_DEFAULT_ARGUMENTS_V220.md`](GENERIC_DEFAULT_ARGUMENTS_V220.md). Another
update adds bounded const-value inference from direct fixed-array extents on generic
free functions; named arguments themselves do not broaden that inference rule. See
[`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md).

## Syntax

```fac
public const int BASE_CAPACITY = 5

public struct FixedBuffer<T, const int N: positive> {
    public array var T values[N]
    public function int capacity() { return N }
}

public function<T, const int N: positive> T keepSized(T value) {
    return value
}

public class Utility {
    public function<const int N: positive> int capacity() {
        return N
    }
}

public function void main() {
    // Named arguments may be written in any order.
    struct FixedBuffer<N = (2 * 4), T = int> reordered

    // Positional arguments may precede named arguments.
    struct FixedBuffer<int, N = 4> mixed

    // Type and const arguments use the same parameter-name mapping.
    var int value = keepSized<N = (BASE_CAPACITY + 7), T = int>(42)

    obj Utility utility = new Utility()
    var int capacity = utility.capacity<N = 9>()
}
```

## Ordering rules

1. Positional arguments are assigned to generic parameters in declaration
   order, starting at the first parameter.
2. Named arguments are assigned by exact generic parameter name.
3. Positional arguments may appear before the first named argument. Once a
   named argument appears, subsequent arguments must also be named.
4. Every parameter must be supplied explicitly or have a declared default.
   Omitted defaulted parameters are filled in declaration order.
5. Duplicate parameter assignment, unknown names, missing required parameters and
   positional arguments after a named argument are errors.

Examples:

| Form | Result |
|---|---|
| `FixedBuffer<int, 8>` | Valid positional form |
| `FixedBuffer<T = int, N = 8>` | Valid named form |
| `FixedBuffer<int, N = 8>` | Valid mixed form |
| `FixedBuffer<N = 8, T = int>` | Valid named form in reverse declaration order |
| `FixedBuffer<N = 8, int>` | Rejected: positional argument follows named argument |
| `FixedBuffer<T = int, T = double, N = 8>` | Rejected: duplicate `T` |
| `FixedBuffer<T = int>` | Valid only if every omitted parameter has a default; otherwise rejected |
| `FixedBuffer<U = int, N = 8>` | Rejected: unknown `U` |

## Compile-time values and constraints

Named labels can address both type parameters and `const int` parameters. The
value expression follows the existing bounded integer constant evaluator.
Parenthesized expressions and eligible module-level constants remain valid,
for example `N = (BASE_CAPACITY + 7)`. Existing overflow, divide-by-zero,
invalid-shift and non-constant-expression checks continue to apply. Built-in
const predicates (`positive`, `nonnegative`, `nonzero`, `negative`, `even`,
`odd`, `power_of_two`) are checked against the resolved value as before.

When a declaration includes const parameters, type and value arguments must
still be explicit for generic methods and generic struct/class instantiations.
Generic free functions may omit the entire argument list only under the fixed-array
`[N]` inference rule documented in
[`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md). Named syntax
changes how explicitly supplied arguments are associated with parameters; it
does not infer values from runtime arguments.

## Specialization identity

The parser preserves each optional argument label in `TypeSpec`. A shared
ordering helper validates labels and produces a vector in declaration order.
Generic type instantiation, generic function/method instantiation, and HIR
explicit-argument normalization use that mapping before specialization. The
specialization key therefore depends on the concrete type arguments and
canonical evaluated const values, not on the order in which named arguments
were written. Equivalent positional and named calls reuse the same cache entry.

## Diagnostics

The implementation reports targeted errors for:

- unknown parameter name;
- duplicate assignment to one parameter;
- missing parameter;
- positional argument after a named argument;
- too many positional arguments.

The diagnostics identify the relevant generic declaration/call context where
available. Existing parser, type, const-expression and constraint diagnostics
remain in force after argument mapping.

## Implementation and regression coverage

Implementation touches `TypeSpec`/AST cloning, generic argument parsing,
generic type and function/method specialization, and HIR explicit-argument
normalization. Regression coverage includes:

- named generic struct arguments in reverse declaration order;
- positional followed by named arguments;
- mixed type and const arguments with constant expressions;
- named free-function and method specialization;
- unknown, duplicate and missing names;
- positional-after-named rejection;
- AST clone preservation and HIR declaration-order substitution.

Run the relevant suites with:

```sh
sh tests/parser/run.sh
sh tests/comptime/run.sh
sh tests/generic/run.sh
CXX=/path/to/gcc-o0-wrapper sh tests/semantic/run.sh
```

The semantic wrapper is useful on constrained build hosts where the default
optimization level makes the C++ semantic test builds exceed local time
budgets. See `docs/STATUS.md` for the validation performed for this source
snapshot.

## Deliberate limits

- Generic defaults and partial argument lists are covered by [`GENERIC_DEFAULT_ARGUMENTS_V220.md`](GENERIC_DEFAULT_ARGUMENTS_V220.md). Const-value inference is a separate bounded feature for fixed-array extents on generic free functions only; it does not infer from runtime values.
- No named arguments for ordinary runtime function parameters.
- No general `consteval` beyond the separate bounded scalar free-function subset, arbitrary compile-time execution, or typed AST
  generation is introduced by this feature.
- Generic virtual/override dispatch and generic interface methods remain
  outside the supported surface.
