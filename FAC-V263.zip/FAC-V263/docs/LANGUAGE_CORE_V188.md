# FAC Language Core — V188

## Bitwise and shift constant array-index projections

V188 extends the existing bounded local-borrow fixed-array projection evaluator so that a pure integer expression may use:

- Binary bitwise AND, OR and XOR: `&`, `|`, `^`.
- Left and right shifts: `<<`, `>>`.
- Unary bitwise complement: `~`.

Examples accepted by the strict local-borrow projection analysis include:

```fac
array var int values[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
ref var int a = values[7 & 3]
ref var int b = values[4 | 1]
ref var int c = values[9 ^ 3]
ref var int d = values[1 << 3]
ref var int e = values[36 >> 2]
ref var int f = values[~(-12)]
```

The evaluator mirrors FAC's integer promotion and common integer signedness/width selection for these operators. Narrow `byte`, `ubyte`, `short` and `ushort` values promote to signed `int`. Shift counts are masked using the promoted operation width, matching code generation; signed right shift is arithmetic, while unsigned right shift is logical. Unary `~` also applies the language's narrow-integer promotion before complementing.

The regression suite checks disjoint projections and runtime aliasing, equivalent expressions that must conflict, shift-count masking (`1 << 32` resolves like `1` for a 32-bit operation), signed arithmetic right shift, unsigned logical right shift, and narrow-integer promotions.

## Boundaries

This remains a deliberately bounded local fixed-array borrow-projection evaluator. It does not add general compile-time evaluation, arbitrary constant propagation, dynamic index analysis, bounds checking, pointer alias analysis or general lifetime solving. Calls, side effects, mutable bindings, unsupported expression forms and values outside the non-negative signed-64-bit projection range remain unknown/conservative. It is not a claim of complete borrow checking or general memory safety.

## Validation

Linux x86-64, GCC 14.2: CMake Debug configure/build succeeded; CTest passed 28/28; local-borrow regressions passed 119/119. Ownership base 11/11, const-method 8/8, noescape 17/17, field-sensitive borrow 19/19, effect contracts 19/19 and function-effect tests 13/13 passed. Semantic 17/17, move 20/20, partial move 28/28, compile-time assertions 7/7, generic specialization 3/3, lexer 18/18, parser 37/37, negative tests 132/132, safe profile 430/430 and memory-safe profile 25/25 passed. See `docs/STATUS.md` for the full validation boundary.
