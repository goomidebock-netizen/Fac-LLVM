# FAC V260 — focused source-code audit

## Finding

**Severity: High — pointer field returned from an untracked enum pointer payload**

V259 rejected direct pointer payload returns and a bounded set of pointer-valued
arithmetic/assignment result forms from inferred (`auto`) functions. It still
accepted a pointer-valued struct field loaded through a pointer-capable enum
payload binding. A minimal reproducer was:

```fac
struct PayloadBox {
    ptr int value
    int count
}

enum MaybeBox { Empty, Value(ptr PayloadBox) }

function auto choosePointerField(enum MaybeBox value) {
    return match (value) {
        case (MaybeBox.Value(box)) => box.value,
        default => null
    }
}
```

The V259 compiler accepted this under `--strict-ownership`. The enum payload
binding `box` has no tracked pointer provenance, and the checker could not
prove that the pointer stored in `box.value` outlives the returning function.

## V260 change

The inferred-return guard now retains the source type of pointer-capable enum
payload bindings and resolves member-field types against the compiler's
aggregate field metadata. It rejects a return when a result arm reads a raw
pointer field from such an untracked payload, including nested projections
such as `box.leaf.value`. Unknown or unresolved field layouts are treated as
pointer-capable and fail closed. Known scalar fields, such as `box.count`, are
not classified as pointer returns and remain accepted.

Nested match-binding shadowing is retained: an inner binding replaces the
outer binding's type before the inner payload is classified. Existing V257
through V259 result-path handling remains in place.

This is a bounded member-projection check, not general enum-payload pointer
provenance, arbitrary expression typing, method/call result analysis, heap
escape analysis, or a complete borrow checker. No source syntax, Runtime
behavior, ARC/GC, public API, ABI, or `--memory-safe` accepted subset is
intended to change.

## Validation

- Compiler and Runtime build: Clang 17, C++17, `-O0 -g0`; succeeded.
- `facc --version` and `tools/check_versions.py`: FAC/Core/Lib/API/Lang/Runtime/Stdlib all V260.
- Lifetime regression runner: 144 PASS, including two pointer-field rejection tests, a nested-field rejection test, and a scalar-field acceptance test.
- Reproduction check: V259 accepted `box.value`; V260 rejects it with the unverified match-payload provenance diagnostic.
- Ownership: passed; function-effect tests 13/13.
- Move: 20/20; Partial Move: 28/28.
- `--memory-safe`: 39/39.
- Compile-time/const-generic: 57/57; Generic specialization: 3/3.
- Lexer: 18/18; Parser: 68 checks; AST model: 1/1.
- Codegen constant-fold and recursion-guard checks: passed.
- Runtime regression suite: exited 0.
- Legacy examples: `-O0` 132/132; `-O2` 132/132.
- Negative tests: 134/134; Limits: 21/21.
- Tools: 91/91.
- Formatter: passed. Standards check: passed for 5 OS families and 6 architecture families.
- API checks: passed; 663 built-ins and 1,014 source declarations audited, 5 findings and 0 beyond baseline; strict contract audit covered 950 public source functions with 0 missing required annotations; compatibility against V128 reported 0 breaking changes and 132 warnings; generated docs up to date (114 files).
- Safe-profile integration: 433 passed, 4 failed. The same four failures and diagnostics reproduce with the V259 compiler baseline: V75 `worker_join_struct_move.fac` and V76 `worker_join_struct_helpers.fac` move/provenance and plain-compile/IR-equivalence checks. These are not claimed as passing or introduced by V260.
- Semantic suite: did not complete within the 5-minute execution window; the ancestry fast-path reported 17 checks passed before the remaining suite was terminated. No full semantic-suite success is claimed.

Full CMake/CTest, ASan/UBSan/TSan, Windows/macOS cross-platform qualification,
and production qualification are not claimed.
