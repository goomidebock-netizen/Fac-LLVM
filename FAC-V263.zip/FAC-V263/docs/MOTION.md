# FAC Motion Library

`motion.fac` contains scalar motion primitives for UI and game code. It has no platform dependency and does not create threads or timers; the caller owns update timing.

## Tween

```fac
import motion.fac

obj motion.Tween opacity = new motion.Tween(0.0)
opacity.to(1.0, 0.22, 3)
while (opacity.isAnimating()) {
    opacity.update(frameDt)
    draw(opacity.value())
}
```

The `to()` arguments are target, duration in seconds and easing ID. IDs: `0` linear, `1` smoothstep, `2` outQuad, `3` outCubic, `4` inOutCubic. Retargeting starts from the current value. `snap()` changes the value immediately. Duration must be finite and within 0–60 seconds. `update()` rejects non-finite delta and caps a single step at 0.1 seconds.

## Spring

```fac
obj motion.Spring offset = new motion.Spring(0.0, 180.0, 24.0)
offset.setTarget(1.0)
offset.update(frameDt)
var double x = offset.position
```

A spring uses semi-implicit integration with bounded substeps. Stiffness must be in (0, 2000], damping in [0, 200]. `settled()` reports when the position and velocity are within the settling thresholds.

## Reduced motion

Both classes expose `setReduceMotion(boolean)`. When enabled, active tweens snap to their target and springs snap to the requested position. Applications should respect a user accessibility preference and pass it to all active states. `ui.Theme.setReduceMotion()` propagates that preference through FAC's built-in animated controls.
