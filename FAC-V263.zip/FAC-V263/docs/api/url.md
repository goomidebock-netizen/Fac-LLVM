# `url` (source library)

Source: `stdlib/url.fac` · `import url.fac` · release V263

### `Url`

```fac
public class Url
```

Url supports hierarchical scheme://authority URLs. It deliberately rejects user-info credentials and requires IPv6 literals to use square brackets.

### `Url.parse`

```fac
public function boolean parse(string input)
```

- **Returns:** True and populates fields when input is a supported absolute hierarchical URL.
- **Ownership:** input=borrowed; parsed fields=owned by this object.
- **Errors:** Returns false for malformed or unsupported input; does not throw for parse failure.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Url.isSecure`

```fac
public function boolean isSecure() { return this.scheme == "https" }
```

- **Returns:** True when the parsed scheme is HTTPS.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `Url.toString`

```fac
public function string toString()
```

- **Returns:** A normalized hierarchical URL string. IPv6 literals are bracketed; host and scheme are lowercased.
- **Ownership:** result=owned string.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable object.

### `encodeComponent`

```fac
public function string encodeComponent(string value) { return net.urlEncode(value) }
```

- **Returns:** RFC 3986 percent-encoded query component using the existing net encoder.
- **Ownership:** value=borrowed; result=owned string.
- **Errors:** None for a valid FAC string.
- **Thread-safety:** Safe-pure.

### `decodeComponent`

```fac
public function string decodeComponent(string value)
```

- **Returns:** Percent-decoded RFC 3986 component; a literal plus sign remains a plus sign.
- **Ownership:** value=borrowed; result=owned string.
- **Errors:** None for malformed percent sequences; invalid sequences are preserved literally.
- **Thread-safety:** Safe-pure.

### `decodeQueryValue`

```fac
public function string decodeQueryValue(string value) { return net.urlDecode(value) }
```

- **Returns:** Decoded application/x-www-form-urlencoded query value; plus signs become spaces.
- **Ownership:** value=borrowed; result=owned string.
- **Errors:** None for malformed percent sequences; invalid sequences are preserved literally.
- **Thread-safety:** Safe-pure.
