# `locale` (source library)

Source: `stdlib/locale.fac` · `import locale.fac` · release V263

### `LocaleTools`

```fac
public class LocaleTools
```

LocaleTools provides a deliberately small, deterministic convention table. It is not ICU/CLDR and does not query or mutate the process locale.

### `LocaleTools.isValidTag`

```fac
public function boolean isValidTag(string tag)
```

- **Returns:** True for the supported simplified BCP-47 shape: 2-3 letter language followed by optional 2-8 ASCII alphanumeric subtags.
- **Ownership:** tag=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `LocaleTools.language`

```fac
public function string language(string tag)
```

- **Returns:** Lowercase primary language subtag, or empty for an invalid tag.
- **Ownership:** tag=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `LocaleTools.region`

```fac
public function string region(string tag)
```

- **Returns:** Uppercase first region subtag when it is two letters or three digits; otherwise empty.
- **Ownership:** tag=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `LocaleTools.decimalSeparator`

```fac
public function string decimalSeparator(string tag)
```

- **Returns:** Decimal separator from the built-in convention table (comma for de/fr/es/it/pt/ru; dot otherwise).
- **Ownership:** tag=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `LocaleTools.groupSeparator`

```fac
public function string groupSeparator(string tag)
```

- **Returns:** Group separator from the built-in convention table (dot for de, narrow no-break space for fr, comma otherwise).
- **Ownership:** tag=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `LocaleTools.datePattern`

```fac
public function string datePattern(string tag)
```

- **Returns:** A conventional numeric date pattern for the built-in locale table.
- **Ownership:** tag=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `LocaleTools.firstWeekday`

```fac
public function int firstWeekday(string tag)
```

- **Returns:** First weekday as 0=Sunday or 1=Monday for the built-in convention table.
- **Ownership:** tag=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.
