# `state` (source library)

Source: `stdlib/state.fac` · `import state.fac` · release V263

### `StateStore`

```fac
public class StateStore
```

StateStore is an in-memory string-keyed application state store. Typed convenience methods encode values as text; invalid typed reads return the caller-provided fallback rather than throwing.

### `StateStore.setString`

```fac
public function void setString(string key, string value)
```

- **Returns:** Stores/replaces a string and increments revision only on change.
- **Ownership:** key/value=borrowed; the store retains the text.
- **Errors:** Throws InvalidArgument (4) for an invalid key.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `StateStore.setInt`

```fac
public function void setInt(string key, int value) { this.setString(key, str(value)) }
```

- **Returns:** Stores an integer in decimal text form.
- **Ownership:** key=borrowed; value=by value.
- **Errors:** Same as setString.
- **Thread-safety:** Not thread-safe when shared mutably.

### `StateStore.setBoolean`

```fac
public function void setBoolean(string key, boolean value)
```

- **Returns:** Stores a boolean as lowercase true/false.
- **Ownership:** key=borrowed; value=by value.
- **Errors:** Same as setString.
- **Thread-safety:** Not thread-safe when shared mutably.

### `StateStore.has`

```fac
public function boolean has(string key) { return this.values.has(key) }
```

- **Returns:** True when key exists.
- **Ownership:** key=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable store; not safe during concurrent mutation.

### `StateStore.getString`

```fac
public function string getString(string key, string fallback = "")
```

- **Returns:** Stored string or fallback when missing.
- **Ownership:** key/fallback=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable store; not safe during concurrent mutation.

### `StateStore.getInt`

```fac
public function int getInt(string key, int fallback = 0)
```

- **Returns:** Parsed integer or fallback when missing/invalid.
- **Ownership:** key=borrowed; fallback/result=by value.
- **Errors:** Parse errors are caught and converted to fallback.
- **Thread-safety:** Safe for a stable store; not safe during concurrent mutation.

### `StateStore.getBoolean`

```fac
public function boolean getBoolean(string key, boolean fallback = false)
```

- **Returns:** Parsed boolean or fallback; accepts true/false, 1/0, yes/no and on/off.
- **Ownership:** key=borrowed; fallback/result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable store; not safe during concurrent mutation.

### `StateStore.remove`

```fac
public function void remove(string key)
```

- **Returns:** Removes a key; revision increments only when it existed.
- **Ownership:** key=borrowed.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `StateStore.size`

```fac
public function int size() { return sizeof(this.values) }
```

- **Returns:** Number of stored keys.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable store.

### `StateStore.revision`

```fac
public function long revision() { return this.revisionNumber }
```

- **Returns:** Current mutation revision, initially zero.
- **Ownership:** result=by value.
- **Errors:** Integer overflow follows FAC checked arithmetic behavior.
- **Thread-safety:** Not thread-safe when concurrently mutated.

### `StateStore.keys`

```fac
public function list dyn string keys() { return this.values.keys() }
```

- **Returns:** A copy of keys; iteration order is unspecified.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable store.

### `StateStore.clear`

```fac
public function void clear()
```

- **Returns:** Removes all keys and increments revision only when non-empty.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
