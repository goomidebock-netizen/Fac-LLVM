# `iter` (source library)

Source: `stdlib/iter.fac` · `import iter.fac` · release V263

### `ListIterator`

```fac
public class ListIterator<T>
```

Explicit pull iterators are used because FAC does not currently have a foreach/yield syntax. Each next() returns Option<T>; None means exhausted.

### `ListIterator.hasNext`

```fac
public function boolean hasNext() { return this.cursor < sizeof(this.values) }
```

- **Returns:** True while another element can be read.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; do not mutate the iterator concurrently.

### `ListIterator.next`

```fac
public function enum Option<T> next()
```

- **Returns:** Some(next element), or None after the end; advances only on Some.
- **Ownership:** result=owned payload value.
- **Errors:** None for exhaustion.
- **Thread-safety:** Not thread-safe; do not mutate the iterator concurrently.

### `ListIterator.peek`

```fac
public function enum Option<T> peek()
```

- **Returns:** Some(next element) without advancing, or None after the end.
- **Ownership:** result=owned payload value.
- **Errors:** None for exhaustion.
- **Thread-safety:** Not thread-safe; do not mutate the iterator concurrently.

### `ListIterator.reset`

```fac
public function void reset() { this.cursor = 0 }
```

- **Returns:** Resets the cursor to the first element.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; do not mutate the iterator concurrently.

### `ListIterator.position`

```fac
public function int position() { return this.cursor }
```

- **Returns:** Number of elements already consumed.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; do not mutate the iterator concurrently.

### `ListIterator.remaining`

```fac
public function int remaining() { return sizeof(this.values) - this.cursor }
```

- **Returns:** Number of elements remaining at the time of the call.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; do not mutate the iterator concurrently.

### `RangeIterator`

```fac
public class RangeIterator
```

Half-open integer range [start, end). A negative step walks downward.

### `RangeIterator.hasNext`

```fac
public function boolean hasNext()
```

- **Returns:** True when the next integer is inside the half-open range.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; use one iterator per consumer.

### `RangeIterator.next`

```fac
public function enum Option<int> next()
```

- **Returns:** Some(next integer), or None when the range is exhausted.
- **Ownership:** result=owned scalar payload.
- **Errors:** None for exhaustion.
- **Thread-safety:** Not thread-safe; use one iterator per consumer.

### `RangeIterator.reset`

```fac
public function void reset()
```

- **Returns:** Resets the iterator to its original start.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; use one iterator per consumer.
