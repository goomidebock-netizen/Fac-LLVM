# `stats`

Population descriptive statistics including quantiles, robust spread, skewness and excess kurtosis.

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 15 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `stats.correlation(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Pearson correlation over flattened paired values; computed without multiplying the two variances, returns 0 if either input has zero variance. |
| `stats.covariance(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle |
| `stats.describe(handle)` → string | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller |
| `stats.iqr(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Returns quantile(0.75)-quantile(0.25), using linear interpolation. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `stats.kurtosis(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Returns population excess kurtosis (fourth standardized central moment minus 3); constant data returns 0. |
| `stats.mad(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Returns median absolute deviation from the median. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `stats.max(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | **alias** of `tensor.max`; args: #1 borrowed-handle |
| `stats.mean(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | **alias** of `tensor.mean`; args: #1 borrowed-handle |
| `stats.median(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Uses an overflow-safe midpoint for even-sized inputs; input values must be finite. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `stats.min(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | **alias** of `tensor.min`; args: #1 borrowed-handle |
| `stats.quantile(handle, double)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Uses stable linear interpolation over [0,1]; input values must be finite and the result must fit float64. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `stats.skewness(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Returns population standardized third central moment; constant data returns 0. |
| `stats.stddev(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | **alias** of `tensor.std`; args: #1 borrowed-handle |
| `stats.sum(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | **alias** of `tensor.sum`; args: #1 borrowed-handle; Uses checked accumulation and rejects non-finite input or a result outside finite float64 range. |
| `stats.variance(handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; Population variance (division by N) using Welford accumulation; finite input and representable finite output required. |

_Parameter names are not part of the built-in contract; positional types are shown._
