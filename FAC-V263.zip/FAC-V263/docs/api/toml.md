# `toml` (source library)

Source: `stdlib/toml.fac` · `import toml.fac` · release V263

### `TomlDocument`

```fac
public class TomlDocument
```

TomlDocument implements a deliberately bounded TOML scalar/table subset. Supported: [table], bare keys, quoted strings, signed integers and booleans. Arrays, inline tables, floats, dates, multiline strings and dotted keys are not supported.

### `TomlDocument.has`

```fac
public function boolean has(string table, string key) { return this.values.has(this.makeKey(table, key)) }
```

- **Returns:** True when table/key exists.
- **Ownership:** table/key=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `TomlDocument.getRaw`

```fac
public function string getRaw(string table, string key, string fallback = "")
```

- **Returns:** Raw TOML scalar spelling, including quotes when present, or fallback.
- **Ownership:** arguments=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `TomlDocument.getString`

```fac
public function string getString(string table, string key, string fallback = "")
```

- **Returns:** String value with one matching pair of single/double quotes removed.
- **Ownership:** arguments=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `TomlDocument.getInt`

```fac
public function long getInt(string table, string key, long fallback = 0)
```

- **Returns:** Parsed integer or fallback when missing/invalid.
- **Ownership:** arguments=borrowed; fallback=result by value.
- **Errors:** None; invalid input returns fallback.
- **Thread-safety:** Safe for a stable document.

### `TomlDocument.getBoolean`

```fac
public function boolean getBoolean(string table, string key, boolean fallback = false)
```

- **Returns:** Parsed boolean or fallback when missing/invalid.
- **Ownership:** arguments=borrowed; fallback=result by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `TomlDocument.setRaw`

```fac
public function void setRaw(string table, string key, string value)
```

- **Returns:** Replaces a raw scalar. Caller supplies valid TOML scalar syntax.
- **Ownership:** table/key/value=borrowed.
- **Errors:** Throws InvalidArgument (4) for unsupported delimiters or empty keys.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TomlDocument.clear`

```fac
public function void clear() { this.values.clear() }
```

- **Returns:** Removes all values.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TomlDocument.parse`

```fac
public function boolean parse(string text)
```

- **Returns:** Parses simple TOML tables and scalar assignments. Duplicate keys use the last value.
- **Ownership:** text=borrowed; stored values=owned.
- **Errors:** Returns false on unsupported/malformed syntax; entries before failure remain.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TomlDocument.toText`

```fac
public function string toText()
```

- **Returns:** Normalized TOML scalar/table text; ordering is unspecified.
- **Ownership:** result=owned string.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable document.
