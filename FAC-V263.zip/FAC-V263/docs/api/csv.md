# `csv`

CSV line helpers.

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 3 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `csv.field(string, int)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `csv.formatLine(list<string>)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `csv.parseLine(string)` → list<string> | no direct throw site | args: #1 borrowed; result: owned by caller |

_Parameter names are not part of the built-in contract; positional types are shown._
