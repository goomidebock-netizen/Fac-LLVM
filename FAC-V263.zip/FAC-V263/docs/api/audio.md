# `audio`

PCM clips, mixing, playback.

- Status: **stable**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 17 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `audio.available()` → boolean | predicate (never throws on a normal miss) |  |
| `audio.channels(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `audio.create(int, int, long)` → handle | throws `Error` (code 14 Media) + OOM | result: owned by caller (release with `audio.free`) |
| `audio.duration(handle)` → double | no direct throw site | args: #1 borrowed-handle |
| `audio.frames(handle)` → long | no direct throw site | args: #1 borrowed-handle |
| `audio.free(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the clip |
| `audio.gain(handle, double)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle |
| `audio.load(string)` → handle | no direct throw site | args: #1 borrowed; result: owned by caller (release with `audio.free`) |
| `audio.mix(handle, handle, double)` → void | throws `Error` (code 14 Media) + OOM | args: #1 borrowed-handle, #2 borrowed-handle |
| `audio.play(handle)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle |
| `audio.playLoop(handle)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle |
| `audio.playing()` → int | no direct throw site |  |
| `audio.rate(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `audio.saveWav(handle, string)` → void | throws `Error` (code 7 Io, 14 Media) | args: #1 borrowed-handle, #2 borrowed |
| `audio.stop()` → void | no direct throw site |  |
| `audio.tone(double, double, int, double)` → handle | throws `Error` (code 14 Media) + OOM | result: owned by caller (release with `audio.free`) |
| `audio.volume(double)` → void | throws `Error` (code 14 Media) |  |

_Parameter names are not part of the built-in contract; positional types are shown._
