# `telemetry` (source library)

Source: `stdlib/telemetry.fac` · `import telemetry.fac` · release V263

### `TelemetryRegistry`

```fac
public class TelemetryRegistry
```

TelemetryRegistry is a synchronous in-memory metrics collector. It exports simple Prometheus text exposition; it is not an OTLP exporter or timer daemon.

### `TelemetryRegistry.increment`

```fac
public function void increment(string name, long amount = 1)
```

- **Returns:** Adds a non-negative amount to a named counter; creates it at zero when absent.
- **Ownership:** name=borrowed; registry retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid name/amount and Resource (8) on signed overflow.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `TelemetryRegistry.counter`

```fac
public function long counter(string name)
```

- **Returns:** Counter value or zero when absent.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.setGauge`

```fac
public function void setGauge(string name, double value)
```

- **Returns:** Creates or updates a finite gauge value.
- **Ownership:** name=borrowed; registry retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid name or non-finite value.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TelemetryRegistry.gauge`

```fac
public function double gauge(string name, double fallback = 0.0)
```

- **Returns:** Gauge value or fallback when absent.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.observe`

```fac
public function void observe(string name, double value)
```

- **Returns:** Records a finite sample and updates count/sum/min/max.
- **Ownership:** name=borrowed; registry retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid name/value and Resource (8) on count overflow.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TelemetryRegistry.sampleCount`

```fac
public function long sampleCount(string name)
```

- **Returns:** Sample count for a named observation series.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.sampleSum`

```fac
public function double sampleSum(string name)
```

- **Returns:** Sample sum or zero when absent.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.sampleMin`

```fac
public function double sampleMin(string name, double fallback = 0.0)
```

- **Returns:** Minimum observed value or fallback when no observations exist.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.sampleMax`

```fac
public function double sampleMax(string name, double fallback = 0.0)
```

- **Returns:** Maximum observed value or fallback when no observations exist.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.sampleMean`

```fac
public function double sampleMean(string name, double fallback = 0.0)
```

- **Returns:** Arithmetic mean or fallback when no observations exist.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.prometheusText`

```fac
public function string prometheusText()
```

- **Returns:** Prometheus text exposition for counters and gauges. Observation series are exported as _count and _sum.
- **Ownership:** result=owned string.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable registry.

### `TelemetryRegistry.clear`

```fac
public function void clear()
```

- **Returns:** Removes every metric series.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
