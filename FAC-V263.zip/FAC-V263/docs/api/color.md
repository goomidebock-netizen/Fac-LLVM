# `color` (source library)

Source: `stdlib/color.fac` · `import color.fac` · release V263

### `rgb`

```fac
public function int rgb(int r, int g, int b)
```

- **Returns:** int by value.
- **Ownership:** r=by value; g=by value; b=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `red`

```fac
public function int red(int c) { return (c >> 16) & 255 }
```

- **Returns:** int by value.
- **Ownership:** c=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `green`

```fac
public function int green(int c) { return (c >> 8) & 255 }
```

- **Returns:** int by value.
- **Ownership:** c=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `blue`

```fac
public function int blue(int c) { return c & 255 }
```

- **Returns:** int by value.
- **Ownership:** c=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `withRed`

```fac
public function int withRed(int c, int r) { return rgb(r, green(c), blue(c)) }
```

- **Returns:** int by value.
- **Ownership:** c=by value; r=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `withGreen`

```fac
public function int withGreen(int c, int g) { return rgb(red(c), g, blue(c)) }
```

- **Returns:** int by value.
- **Ownership:** c=by value; g=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `withBlue`

```fac
public function int withBlue(int c, int b) { return rgb(red(c), green(c), b) }
```

- **Returns:** int by value.
- **Ownership:** c=by value; b=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `invert`

```fac
public function int invert(int c) { return rgb(255 - red(c), 255 - green(c), 255 - blue(c)) }
```

- **Returns:** int by value.
- **Ownership:** c=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `grayscale`

```fac
public function int grayscale(int c)
```

- **Returns:** int by value.
- **Ownership:** c=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `lerp`

```fac
public function int lerp(int a, int b, double t)
```

Mix two colors. t is clamped to [0,1].

- **Returns:** int by value.
- **Ownership:** a=by value; b=by value; t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `multiply`

```fac
public function int multiply(int c, double factor)
```

Multiply each channel by factor; factor < 0 clamps to black, > 1 clamps to white.

- **Returns:** int by value.
- **Ownership:** c=by value; factor=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `over`

```fac
public function int over(int foreground, int background, int alpha)
```

Alpha composite foreground over background. alpha is 0..255.

- **Returns:** int by value.
- **Ownership:** foreground=by value; background=by value; alpha=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `fromHsv`

```fac
public function int fromHsv(double hue, double saturation, double value)
```

Convert normalized HSV (hue in degrees, saturation/value in [0,1]) to packed RGB.

- **Returns:** int by value.
- **Ownership:** hue=by value; saturation=by value; value=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `fromHsl`

```fac
public function int fromHsl(double hue, double saturation, double lightness)
```

Convert normalized HSL (hue in degrees, saturation/lightness in [0,1]) to packed RGB.

- **Returns:** int by value.
- **Ownership:** hue=by value; saturation=by value; lightness=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `toHsv`

```fac
public function (double, double, double) toHsv(int c)
```

Return (hue degrees, saturation [0,1], value [0,1]). Achromatic colors use hue 0.

- **Returns:** Tuple (double,double,double) by value.
- **Ownership:** c=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `toHsl`

```fac
public function (double, double, double) toHsl(int c)
```

Return (hue degrees, saturation [0,1], lightness [0,1]). Achromatic colors use hue 0.

- **Returns:** Tuple (double,double,double) by value.
- **Ownership:** c=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
