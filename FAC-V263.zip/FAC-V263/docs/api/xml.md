# `xml` (source library)

Source: `stdlib/xml.fac` · `import xml.fac` · release V263

### `XmlDocument`

```fac
public class XmlDocument
```

XmlDocument is a bounded, safe XML reader for element-only documents. Supports one root, nested simple-name elements, comments, an optional XML declaration, self-closing tags and the five predefined XML entities. Attributes, namespaces, DTD/entity declarations, CDATA and processing instructions are rejected. Every element path carries a zero-based index.

### `XmlDocument.clear`

```fac
public function void clear()
```

- **Returns:** Removes all parsed elements and resets parser state.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `XmlDocument.parse`

```fac
public function boolean parse(string source)
```

- **Returns:** Parses an XML element-only document; all element paths use zero-based indexes.
- **Ownership:** source=borrowed; parsed names/text=owned by this document.
- **Errors:** Returns false for malformed or unsupported XML. Parsed nodes before failure remain available.
- **Thread-safety:** Not thread-safe when shared mutably.

### `XmlDocument.has`

```fac
public function boolean has(string path) { return this.textValues.has(path) }
```

- **Returns:** True when an exact indexed element path exists (for example "root[0].item[1]").
- **Ownership:** path=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `XmlDocument.getText`

```fac
public function string getText(string path, string fallback = "") { return this.textValues.getOr(path, fallback) }
```

- **Returns:** Direct text content of an element; child element text is not included.
- **Ownership:** path/fallback=borrowed; result=owned string.
- **Errors:** None; missing elements return fallback.
- **Thread-safety:** Safe for a stable document.

### `XmlDocument.rootPath`

```fac
public function string rootPath()
```

- **Returns:** First root path or empty string for an empty document.
- **Ownership:** result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `XmlDocument.childCount`

```fac
public function int childCount(string parentPath, string name) { return this.siblingCounts.getOr(parentPath + "|" + name, 0) }
```

- **Returns:** Number of direct children with this name under parentPath.
- **Ownership:** parentPath/name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `XmlDocument.childPath`

```fac
public function string childPath(string parentPath, string name, int index)
```

- **Returns:** Indexed child path or empty string when index is out of range.
- **Ownership:** arguments=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `XmlDocument.size`

```fac
public function int size() { return sizeof(this.nodePaths) }
```

- **Returns:** Number of parsed elements.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.
