# `rate_limit` (source library)

Source: `stdlib/rate_limit.fac` · `import rate_limit.fac` · release V263

### `FixedWindowRateLimiter`

```fac
public class FixedWindowRateLimiter
```

FixedWindowRateLimiter is a deterministic, caller-clock rate limiter. Its window begins on the first accepted call after reset/expiry, not at a wall-clock-aligned boundary. Callers must provide monotonic milliseconds.

### `FixedWindowRateLimiter.configure`

```fac
public function void configure(int maxRequests, long windowMs)
```

- **Returns:** Replaces the limit/window and clears current usage.
- **Ownership:** scalar arguments=by value.
- **Errors:** Throws InvalidArgument (4) for non-positive limits/windows.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `FixedWindowRateLimiter.allow`

```fac
public function boolean allow(long nowMs)
```

- **Returns:** True and consumes one slot when allowed; false when the window is full.
- **Ownership:** nowMs=by value; result=by value.
- **Errors:** Throws InvalidArgument (4) for negative or decreasing clock values; throws on deadline overflow.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `FixedWindowRateLimiter.remaining`

```fac
public function int remaining() { return this.maximumRequests - this.acceptedRequests }
```

- **Returns:** Number of additional requests allowed in the current window.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable limiter; not concurrent mutation.

### `FixedWindowRateLimiter.used`

```fac
public function int used() { return this.acceptedRequests }
```

- **Returns:** Accepted requests in the current window.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable limiter; not concurrent mutation.

### `FixedWindowRateLimiter.resetAtMs`

```fac
public function long resetAtMs()
```

- **Returns:** Current window deadline, or -1 before the first request.
- **Ownership:** result=by value.
- **Errors:** Deadline overflow is rejected before a window begins.
- **Thread-safety:** Safe for a stable limiter; not concurrent mutation.

### `FixedWindowRateLimiter.limit`

```fac
public function int limit() { return this.maximumRequests }
```

- **Returns:** Maximum accepted requests per window.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable limiter.

### `FixedWindowRateLimiter.windowDuration`

```fac
public function long windowDuration() { return this.windowDurationMs }
```

- **Returns:** Configured window duration in milliseconds.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable limiter.

### `FixedWindowRateLimiter.reset`

```fac
public function void reset()
```

- **Returns:** Clears usage and forgets the previous clock observation.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
