# `message_queue` (source library)

Source: `stdlib/message_queue.fac` · `import message_queue.fac` · release V263

### `MessageQueue`

```fac
public class MessageQueue
```

MessageQueue is a bounded in-memory work queue with explicit leases and a dead-letter list. It is not durable, distributed or thread-safe.

### `MessageQueue.enqueue`

```fac
public function int enqueue(string payload, long nowMs)
```

- **Returns:** Enqueues a message and returns its positive monotonic ID.
- **Ownership:** payload=borrowed; queue retains a copy.
- **Errors:** Throws InvalidArgument (4), Resource (8) if capacity is full or IDs are exhausted.
- **Thread-safety:** Not thread-safe.

### `MessageQueue.claim`

```fac
public function int claim(long nowMs, long visibilityTimeoutMs)
```

- **Returns:** Claims the next ready message, or -1 when none is available. Expired leases are redelivered until maxAttempts, then dead-lettered.
- **Ownership:** result=message ID by value.
- **Errors:** Throws InvalidArgument (4) for negative time or non-positive visibility timeout; Resource (8) on timestamp overflow.
- **Thread-safety:** Not thread-safe; claim is not atomic across concurrent consumers.

### `MessageQueue.payload`

```fac
public function string payload(int id)
```

- **Returns:** Payload for a currently claimed message.
- **Ownership:** result=owned string.
- **Errors:** Throws InvalidArgument (4) if the ID is unknown or is not currently claimed.
- **Thread-safety:** Safe for a stable queue; not safe during concurrent mutation.

### `MessageQueue.attempts`

```fac
public function int attempts(int id)
```

- **Returns:** Delivery-attempt count for an active message.
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) for an unknown message ID.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.ack`

```fac
public function boolean ack(int id)
```

- **Returns:** Acknowledges and removes a currently claimed message.
- **Ownership:** id=by value.
- **Errors:** None; false when ID is absent or not claimed.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MessageQueue.nack`

```fac
public function boolean nack(int id, long nowMs, long delayMs = 0)
```

- **Returns:** Releases a claimed message and makes it available after delayMs.
- **Ownership:** id/delayMs/nowMs=by value.
- **Errors:** Throws InvalidArgument (4) for negative time/delay; Resource (8) on timestamp overflow. Returns false if ID is not claimed.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MessageQueue.reapExpired`

```fac
public function int reapExpired(long nowMs)
```

- **Returns:** Moves expired leases that have exhausted maxAttempts to dead letters and releases other expired leases for redelivery. Returns count changed.
- **Ownership:** nowMs=by value.
- **Errors:** Throws InvalidArgument (4) for negative time.
- **Thread-safety:** Not thread-safe.

### `MessageQueue.size`

```fac
public function int size() { return sizeof(this.messageIds) }
```

- **Returns:** Number of active queued/in-flight messages.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.capacity`

```fac
public function int capacity() { return this.capacityLimit }
```

- **Returns:** Active capacity limit.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.deadLetterCapacity`

```fac
public function int deadLetterCapacity() { return this.deadLetterLimit }
```

- **Returns:** Maximum retained dead-letter count.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.payloadLimitBytes`

```fac
public function int payloadLimitBytes() { return this.maxPayloadBytes }
```

- **Returns:** Maximum byte length for an individual payload.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.deadLetterSize`

```fac
public function int deadLetterSize() { return sizeof(this.deadIds) }
```

- **Returns:** Number of retained dead-letter messages.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.deadLetterPayload`

```fac
public function string deadLetterPayload(int index)
```

- **Returns:** Dead-letter payload at a zero-based index.
- **Ownership:** result=owned string.
- **Errors:** Throws IndexOutOfRange (2) for an invalid index.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.deadLetterId`

```fac
public function int deadLetterId(int index)
```

- **Returns:** Dead-letter ID at a zero-based index.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) for an invalid index.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.deadLetterAttempts`

```fac
public function int deadLetterAttempts(int index)
```

- **Returns:** Number of attempts before the message was dead-lettered.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) for an invalid index.
- **Thread-safety:** Safe for a stable queue.

### `MessageQueue.redriveDeadLetter`

```fac
public function int redriveDeadLetter(int index, long nowMs)
```

- **Returns:** Requeues one dead-letter item with the same ID and a fresh attempt count.
- **Ownership:** index/nowMs=by value.
- **Errors:** Throws InvalidArgument (4) for invalid time/index or Resource (8) when the active queue is full.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MessageQueue.purgeDeadLetters`

```fac
public function int purgeDeadLetters()
```

- **Returns:** Removes all dead-letter entries and returns the number removed.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MessageQueue.clear`

```fac
public function void clear()
```

- **Returns:** Removes all active messages without changing dead letters or the monotonic ID counter.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
