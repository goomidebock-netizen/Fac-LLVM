# `http_server` (source library)

Source: `stdlib/http_server.fac` · `import http_server.fac` · release V263

### `HttpServer`

```fac
public class HttpServer
```

Small synchronous HTTP/1.x server primitives built on FAC TCP sockets. The server intentionally closes each client connection after one response. It does not implement chunked request bodies, keep-alive, TLS, or callbacks.

### `HttpServer.accept`

```fac
public function ptr socket accept()
```

- **Returns:** Accepts one TCP client. This call blocks until a client arrives.
- **Ownership:** result=owned socket handle; caller must close it with net.close.
- **Errors:** Throws Network (11) when listener is closed or accept fails.
- **Thread-safety:** Not safe for concurrent close/accept; accept is blocking native I/O.

### `HttpServer.port`

```fac
public function int port()
```

- **Returns:** The actual listening port, useful when constructed with port 0.
- **Ownership:** result=by value.
- **Errors:** Returns -1 if the underlying socket no longer reports a port.
- **Thread-safety:** Safe while the listener is stable.

### `HttpServer.close`

```fac
public function void close()
```

- **Returns:** Closes the listening socket. Accepted client sockets remain caller-owned.
- **Ownership:** consumes the listener resource.
- **Errors:** None for a valid/closed server.
- **Thread-safety:** Do not race with accept().

### `HttpRequest`

```fac
public class HttpRequest
```

### `HttpRequest.readFrom`

```fac
public function void readFrom(ptr socket client, int timeoutMs = 5000)
```

- **Returns:** Reads one bounded HTTP/1.0 or HTTP/1.1 request from a connected socket.
- **Ownership:** client=borrowed socket handle; request fields are copied/owned by this object.
- **Errors:** Throws Network (11), InvalidArgument (4), or Parse (10) for malformed, incomplete, oversized, or unsupported requests.
- **Thread-safety:** Not thread-safe when shared mutably; blocks up to timeoutMs per socket operation; requires CRLF and rejects EOF before a line terminator.

### `HttpRequest.header`

```fac
public function string header(string name, string fallback = "")
```

- **Returns:** A lowercased header value or fallback when absent.
- **Ownership:** name/fallback=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable request.

### `HttpRequest.hasHeader`

```fac
public function boolean hasHeader(string name) { return this.headers.has(string.lower(name)) }
```

- **Returns:** True when a header exists, case-insensitively.
- **Ownership:** name=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe for a stable request.

### `HttpRequest.headerCount`

```fac
public function int headerCount() { return sizeof(this.headers) }
```

- **Returns:** Number of parsed headers.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable request.

### `HttpResponse`

```fac
public class HttpResponse
```

### `HttpResponse.setStatus`

```fac
public function void setStatus(int status, string reasonPhrase)
```

- **Returns:** Sets an HTTP status and reason phrase.
- **Ownership:** reason=borrowed; response retains a copy.
- **Errors:** Throws InvalidArgument (4) for a status outside 100..599 or unsafe reason text.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HttpResponse.setBody`

```fac
public function void setBody(string body) { this.body = body }
```

- **Returns:** Replaces the response body. The body is sent byte-for-byte as stored.
- **Ownership:** body=borrowed; response retains a copy.
- **Errors:** May allocate.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HttpResponse.setHeader`

```fac
public function void setHeader(string name, string value)
```

- **Returns:** Adds/replaces an ordinary response header.
- **Ownership:** name/value=borrowed; response retains copies.
- **Errors:** Throws InvalidArgument (4) for invalid names/values or reserved framing headers.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HttpResponse.toWire`

```fac
public function string toWire()
```

- **Returns:** Builds an HTTP/1.1 response with a computed byte Content-Length and Connection: close.
- **Ownership:** result=owned string.
- **Errors:** May allocate; body byte length is checked by the string runtime.
- **Thread-safety:** Safe for a stable response.

### `HttpResponse.writeTo`

```fac
public function void writeTo(ptr socket client) { net.send(client, this.toWire()) }
```

- **Returns:** Sends the serialized response. Caller owns and must close the client socket.
- **Ownership:** client=borrowed socket handle; response remains owned by caller.
- **Errors:** Throws Network (11) when socket send fails.
- **Thread-safety:** Not thread-safe if response is concurrently mutated.
