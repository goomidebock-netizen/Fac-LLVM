# `mat4`

4x4 matrix helpers (provider module: math).

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 11 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `mat4.identity()` → mat4 | no direct throw site |  |
| `mat4.inverse(mat4)` → mat4 | throws `Error` (code 18 Math) |  |
| `mat4.lookAt(vec3, vec3, vec3)` → mat4 | no direct throw site |  |
| `mat4.ortho(float, float, float, float, float, float)` → mat4 | no direct throw site |  |
| `mat4.perspective(float, float, float, float)` → mat4 | no direct throw site |  |
| `mat4.rotateX(float)` → mat4 | no direct throw site |  |
| `mat4.rotateY(float)` → mat4 | no direct throw site |  |
| `mat4.rotateZ(float)` → mat4 | no direct throw site |  |
| `mat4.scale(float, float, float)` → mat4 | no direct throw site |  |
| `mat4.translate(float, float, float)` → mat4 | no direct throw site |  |
| `mat4.transpose(mat4)` → mat4 | no direct throw site |  |

_Parameter names are not part of the built-in contract; positional types are shown._
