# `ui` (source library)

Source: `stdlib/ui.fac` · `import ui.fac` · release V263

### `FlexBox.setBounds`

```fac
public function void setBounds(int px, int py, int w, int h)
```

- **Returns:** Nothing; replaces the outer layout rectangle.
- **Ownership:** x/y/width/height=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe: mutates this FlexBox receiver.

### `FlexBox.setGap`

```fac
public function void setGap(int spacing) { this.gap = clampInt(spacing, 0, 100000) }
```

- **Returns:** Nothing; sets the gap between main-axis children.
- **Ownership:** spacing=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe: mutates this FlexBox receiver.

### `FlexBox.clearItems`

```fac
public function void clearItems()
```

- **Returns:** Nothing; removes all child constraints and resolved sizes.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe: mutates this FlexBox receiver.

### `FlexBox.setPadding`

```fac
public function void setPadding(int left, int top, int right, int bottom)
```

- **Returns:** Nothing.
- **Ownership:** left/top/right/bottom=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe: mutates this FlexBox receiver.

### `FlexBox.add`

```fac
public function int add(int basis, int grow, int shrink, int minSize, int maxSize, int crossSize, int crossAlign)
```

basis/min/max/crossSize are pixels. grow/shrink are nonnegative weights. crossSize=0 stretches; crossAlign 0=start, 1=center, 2=end.

- **Returns:** Child index, or -1 when the 4096-child limit is reached.
- **Ownership:** basis/grow/shrink/minSize/maxSize/crossSize/crossAlign=by value.
- **Errors:** Container allocation errors may propagate.
- **Thread-safety:** Not thread-safe: mutates this FlexBox receiver.

### `FlexBox.resolve`

```fac
public function void resolve()
```

- **Returns:** Nothing; calculates the main-axis size of every child.
- **Ownership:** no parameters.
- **Errors:** Container allocation errors may propagate.
- **Thread-safety:** Not thread-safe: mutates this FlexBox receiver.

### `FlexBox.itemX`

```fac
public function int itemX(int index)
```

- **Returns:** Child x-coordinate.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Read-only; call resolve() after changing children or bounds.

### `FlexBox.itemY`

```fac
public function int itemY(int index)
```

- **Returns:** Child y-coordinate.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Read-only; call resolve() after changing children or bounds.

### `FlexBox.itemWidth`

```fac
public function int itemWidth(int index)
```

- **Returns:** Child width.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Read-only; call resolve() after changing children or bounds.

### `FlexBox.itemHeight`

```fac
public function int itemHeight(int index)
```

- **Returns:** Child height.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Read-only; call resolve() after changing children or bounds.

### `FlexBox.count`

```fac
public function int count() { return sizeof(this.bases) }
```

- **Returns:** Number of children registered in this layout.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Read-only.

### `ButtonMotion.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled)
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `ButtonMotion.update`

```fac
public function void update(double dt, boolean hoveredNow, boolean pressedNow)
```

- **Returns:** Nothing.
- **Ownership:** dt=by value; hoveredNow=by value; pressedNow=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: mutates the ButtonMotion receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `SidebarMotion.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled)
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `SidebarMotion.update`

```fac
public function void update(double dt, boolean hoveredNow, boolean selectedNow)
```

- **Returns:** Nothing.
- **Ownership:** dt=by value; hoveredNow=by value; selectedNow=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: mutates the SidebarMotion receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `ToggleMotion.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled) { this.position.setReduceMotion(enabled) }
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `TabsMotion.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled) { this.indicator.setReduceMotion(enabled) }
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `PanelMotion.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled) { this.entrance.setReduceMotion(enabled) }
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `PanelMotion.restart`

```fac
public function void restart()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: mutates the PanelMotion receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `beginFrame`

```fac
public function void beginFrame(ptr graphic c)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue, keyAHeld, keyAPressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `frameDelta`

```fac
public function double frameDelta() { return frameDeltaValue }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `mouseX`

```fac
public function int mouseX() { return mouseXValue }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseXValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `mouseY`

```fac
public function int mouseY() { return mouseYValue }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseYValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `mouseDown`

```fac
public function boolean mouseDown() { return mouseHeld }
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseHeld).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `mousePressed`

```fac
public function boolean mousePressed() { return mousePressedValue }
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `mouseReleased`

```fac
public function boolean mouseReleased() { return mouseReleasedValue }
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseReleasedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `hovered`

```fac
public function boolean hovered(int x, int y, int w, int h) { return inside(x, y, w, h) }
```

- **Returns:** boolean by value.
- **Ownership:** x=by value; y=by value; w=by value; h=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `roundedRect`

```fac
public function void roundedRect(ptr graphic c, int x, int y, int w, int h, int radius, int fill)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; radius=by value; fill=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `card`

```fac
public function void card(ptr graphic c, int x, int y, int w, int h, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `animatedPanel`

```fac
public function void animatedPanel(ptr graphic c, int x, int y, int w, int h, obj PanelMotion state, obj theme.Theme t)
```

Subtle 8px rise on first appearance. Call state.restart() to replay on reopening.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; state=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `divider`

```fac
public function void divider(ptr graphic c, int x, int y, int w, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `text`

```fac
public function void text(ptr graphic c, int x, int y, string value, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; value=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `mutedText`

```fac
public function void mutedText(ptr graphic c, int x, int y, string value, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; value=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `centeredText`

```fac
public function void centeredText(ptr graphic c, int x, int y, int w, string value, int scale, int col)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; value=borrowed (immutable, shared); scale=by value; col=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `title`

```fac
public function void title(ptr graphic c, int x, int y, string value, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; value=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `button`

```fac
public function boolean button(ptr graphic c, int x, int y, int w, int h, string label, string kind, obj theme.Theme t)
```

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); kind=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseHeld, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `animatedButton`

```fac
public function boolean animatedButton(ptr graphic c, int x, int y, int w, int h, string label, string kind, obj ButtonMotion state, obj theme.Theme t)
```

Animated variant of button(). Keep state alive and reuse it on each frame.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); kind=borrowed (immutable, shared); state=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue, mouseHeld, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `badge`

```fac
public function void badge(ptr graphic c, int x, int y, string label, string kind, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; label=borrowed (immutable, shared); kind=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `progress`

```fac
public function void progress(ptr graphic c, int x, int y, int w, int h, double value, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; value=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `slider`

```fac
public function double slider(ptr graphic c, int x, int y, int w, double minValue, double maxValue, double value, obj theme.Theme t)
```

Returns the updated value while the primary mouse button is held over its track.

- **Returns:** double by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; minValue=by value; maxValue=by value; value=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseHeld, mousePressedValue, mouseXValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `checkbox`

```fac
public function boolean checkbox(ptr graphic c, int x, int y, string label, boolean checked, obj theme.Theme t)
```

Returns the new checked state; call beginFrame() once at the top of each frame.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; label=borrowed (immutable, shared); checked=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `toggle`

```fac
public function boolean toggle(ptr graphic c, int x, int y, int w, int h, boolean enabled, obj theme.Theme t)
```

Toggle control returns its new value. Width should be at least 34 px.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; enabled=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `animatedToggle`

```fac
public function boolean animatedToggle(ptr graphic c, int x, int y, int w, int h, boolean enabled, obj ToggleMotion state, obj theme.Theme t)
```

Toggle with a smoothly moving thumb. Persist ToggleMotion across frames.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; enabled=by value; state=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `statCard`

```fac
public function void statCard(ptr graphic c, int x, int y, int w, int h, string label, string value, string detail, string kind, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); value=borrowed (immutable, shared); detail=borrowed (immutable, shared); kind=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `verticalDivider`

```fac
public function void verticalDivider(ptr graphic c, int x, int y, int h, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; h=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `navItem`

```fac
public function boolean navItem(ptr graphic c, int x, int y, int w, int h, string label, boolean active, obj theme.Theme t)
```

Sidebar navigation row. Returns true only on the mouse press edge.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); active=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `workspaceBar`

```fac
public function void workspaceBar(ptr graphic c, int x, int y, int w, int h, string appName, string context, obj theme.Theme t)
```

Minimal application header for workspace-style desktop layouts. This is a visual primitive, not a native OS title bar or window-management API.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; appName=borrowed (immutable, shared); context=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `sidebarItem`

```fac
public function boolean sidebarItem(ptr graphic c, int x, int y, int w, int h, string label, boolean active, obj theme.Theme t)
```

Sidebar item with a quiet selected state. Returns true on the press edge.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); active=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `animatedSidebarItem`

```fac
public function boolean animatedSidebarItem(ptr graphic c, int x, int y, int w, int h, string label, boolean active, obj SidebarMotion state, obj theme.Theme t)
```

Sidebar item with interpolated hover/selection surface and a growing accent marker.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); active=by value; state=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `toolbarButton`

```fac
public function boolean toolbarButton(ptr graphic c, int x, int y, int w, int h, string label, boolean active, obj theme.Theme t)
```

Compact flat action for a workspace toolbar. Returns true on the press edge.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); active=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `animatedToolbarButton`

```fac
public function boolean animatedToolbarButton(ptr graphic c, int x, int y, int w, int h, string label, boolean active, obj ButtonMotion state, obj theme.Theme t)
```

Toolbar action with a restrained, animated hover surface.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); active=by value; state=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue, mouseHeld, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `workspaceRow`

```fac
public function boolean workspaceRow(ptr graphic c, int x, int y, int w, int h, string title, string detail, string trailing, boolean selected, obj theme.Theme t)
```

Two-line workspace row with an optional right-aligned metadata label.

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; title=borrowed (immutable, shared); detail=borrowed (immutable, shared); trailing=borrowed (immutable, shared); selected=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `tabs`

```fac
public function int tabs(ptr graphic c, int x, int y, int w, int h, list dyn string labels, int active, obj theme.Theme t)
```

Segmented tab row; labels are supplied as list dyn string. Returns active index.

- **Returns:** int by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; labels=borrowed (read-only view for the call); active=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `animatedTabs`

```fac
public function int animatedTabs(ptr graphic c, int x, int y, int w, int h, list dyn string labels, int active, obj TabsMotion state, obj theme.Theme t)
```

Tabs with a gliding underline. Tab widths are equal, matching ui.tabs().

- **Returns:** int by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; labels=borrowed (read-only view for the call); active=by value; state=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (frameDeltaValue, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `dropdown`

```fac
public function int dropdown(ptr graphic c, int x, int y, int w, int h, list dyn string labels, int selected, int id, obj theme.Theme t)
```

Dropdown with mouse and keyboard navigation. IDs must be unique/non-negative. Up/Down changes the selection, Enter accepts/closes, Esc closes without changing it. At most eight options are drawn at once; keyboard navigation scrolls the popup.

- **Returns:** int by value.
- **Ownership:** c=non-owning handle, not freed here; x/y/w/h/id/selected=by value; labels=borrowed (read-only view for the call); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level mouse and keyboard state.

### `radioGroup`

```fac
public function int radioGroup(ptr graphic c, int x, int y, int rowHeight, list dyn string labels, int selected, obj theme.Theme t)
```

Vertical radio group. The selected index is returned; an empty list leaves it unchanged.

- **Returns:** int by value.
- **Ownership:** c=non-owning handle, not freed here; x/y/rowHeight/selected=by value; labels=borrowed (read-only view for the call); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level mouse state.

### `alert`

```fac
public function void alert(ptr graphic c, int x, int y, int w, int h, string heading, string message, string kind, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; heading=borrowed (immutable, shared); message=borrowed (immutable, shared); kind=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `avatar`

```fac
public function void avatar(ptr graphic c, int cx, int cy, int radius, string initials, int fill, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; cx=by value; cy=by value; radius=by value; initials=borrowed (immutable, shared); fill=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `sectionTitle`

```fac
public function void sectionTitle(ptr graphic c, int x, int y, string label, string note, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; label=borrowed (immutable, shared); note=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inputField`

```fac
public function void inputField(ptr graphic c, int x, int y, int w, int h, string label, string value, boolean focused, obj theme.Theme t)
```

Visual-only text field frame. Use textField() for interactive single-line editing.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); value=borrowed (immutable, shared); focused=by value; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `canUndoText`

```fac
public function boolean canUndoText()
```

- **Returns:** boolean by value.
- **Ownership:** no parameters.
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads module-level text history state.

### `canRedoText`

```fac
public function boolean canRedoText()
```

- **Returns:** boolean by value.
- **Ownership:** no parameters.
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads module-level text history state.

### `undoText`

```fac
public function string undoText(string current)
```

- **Returns:** string by value.
- **Ownership:** current=borrowed input; returned value is the restored string.
- **Errors:** Errors from string.graphemeLength propagate.
- **Thread-safety:** Not thread-safe: mutates module-level text history and cursor state.

### `redoText`

```fac
public function string redoText(string current)
```

- **Returns:** string by value.
- **Ownership:** current=borrowed input; returned value is the restored string.
- **Errors:** Errors from string.graphemeLength propagate.
- **Thread-safety:** Not thread-safe: mutates module-level text history and cursor state.

### `focusedTextField`

```fac
public function int focusedTextField() { return activeTextFieldId }
```

- **Returns:** int by value.
- **Ownership:** no parameters.
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads module-level focus state.

### `focusTextField`

```fac
public function void focusTextField(ptr graphic c, int id)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning graphic handle; id=by value.
- **Errors:** Errors from graphic.startTextInput propagate.
- **Thread-safety:** Not thread-safe: mutates module-level focus and history state.

### `textField`

```fac
public function string textField(ptr graphic c, int x, int y, int w, int h, string label, string value, int id, int nextId, int prevId, int maxLength, obj theme.Theme t)
```

Editable single-line text field. IDs must be unique and stable; nextId/prevId are the IDs of the fields reached by Tab / Shift+Tab, or -1 to stay in place. maxLength is measured in supported grapheme clusters (0 means the 65535-cluster cap).

- **Returns:** Updated string by value; assign the result back to the caller's dyn string.
- **Ownership:** c=non-owning graphic handle; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); value=borrowed input (immutable, shared), returned string is a new value; id=by value; nextId=by value; prevId=by value; maxLength=by value; t=shared object reference, not consumed
- **Errors:** No direct throw; errors from called string, graphic or render APIs propagate.
- **Thread-safety:** Not thread-safe: uses module-level focus, selection and keyboard-edge state; call from one UI thread.

### `blurTextField`

```fac
public function void blurTextField(ptr graphic c)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning graphic handle, not freed here.
- **Errors:** No direct throw; errors from graphic.stopTextInput propagate.
- **Thread-safety:** Not thread-safe: clears module-level text field focus state; call from one UI thread.

### `textArea`

```fac
public function string textArea(ptr graphic c, int x, int y, int w, int h, string label, string value, int id, int nextId, int prevId, int maxLength, obj theme.Theme t)
```

Multi-line immediate-mode editor. It shares the text focus and history session with textField; IDs must remain unique across both control types. Arrow Up/Down preserves the preferred column. Enter inserts a line break.

- **Returns:** Updated string by value; assign it back to the caller's dyn string.
- **Ownership:** c=non-owning graphic handle; geometry and IDs=by value; label/value=borrowed inputs; returned string is a new value; theme=shared object reference, not consumed.
- **Errors:** Errors from string, graphic or render APIs propagate.
- **Thread-safety:** Not thread-safe: uses the module-level text editor state; call from one UI thread.

### `Column.next`

```fac
public function int next(int childHeight)
```

- **Returns:** int by value.
- **Ownership:** childHeight=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Column receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Column.reset`

```fac
public function void reset(int py) { this.y = py; this.cursorY = py }
```

- **Returns:** Nothing.
- **Ownership:** py=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Column receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Row.next`

```fac
public function int next(int childWidth)
```

- **Returns:** int by value.
- **Ownership:** childWidth=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Row receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Row.reset`

```fac
public function void reset(int px) { this.x = px; this.cursorX = px }
```

- **Returns:** Nothing.
- **Ownership:** px=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Row receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Grid.cellWidth`

```fac
public function int cellWidth()
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads the Grid receiver.

### `Grid.cellX`

```fac
public function int cellX(int index)
```

- **Returns:** int by value.
- **Ownership:** index=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads the Grid receiver.

### `Grid.cellY`

```fac
public function int cellY(int index)
```

- **Returns:** int by value.
- **Ownership:** index=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads the Grid receiver.

### `Grid.next`

```fac
public function int next()
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Grid receiver.

### `Grid.reset`

```fac
public function void reset() { this.cursorIndex = 0 }
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Grid receiver.

### `Flex.itemX`

```fac
public function int itemX(int index)
```

- **Returns:** int by value.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Reads this Flex receiver; synchronize externally if shared.

### `Flex.itemY`

```fac
public function int itemY(int index)
```

- **Returns:** int by value.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Reads this Flex receiver; synchronize externally if shared.

### `Flex.itemWidth`

```fac
public function int itemWidth(int index)
```

- **Returns:** int by value.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Reads this Flex receiver; synchronize externally if shared.

### `Flex.itemHeight`

```fac
public function int itemHeight(int index)
```

- **Returns:** int by value.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Reads this Flex receiver; synchronize externally if shared.

### `Flex.next`

```fac
public function int next()
```

- **Returns:** int by value.
- **Ownership:** No parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe: mutates this Flex receiver.

### `Flex.reset`

```fac
public function void reset() { this.cursorIndex = 0 }
```

- **Returns:** Nothing.
- **Ownership:** No parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe: mutates this Flex receiver.

### `styledBox`

```fac
public function void styledBox(ptr graphic c, int x, int y, int w, int h, obj Style s, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; s=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `styledText`

```fac
public function void styledText(ptr graphic c, int x, int y, string value, obj Style s, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; value=borrowed (immutable, shared); s=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `styledButton`

```fac
public function boolean styledButton(ptr graphic c, int x, int y, int w, int h, string label, obj Style s, obj theme.Theme t)
```

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; label=borrowed (immutable, shared); s=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (mouseHeld, mousePressedValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `label`

```fac
public function void label(ptr graphic c, int x, int y, string value, obj Style s, obj theme.Theme t)
```

A conventional component-library alias for application code.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; value=borrowed (immutable, shared); s=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `panel`

```fac
public function void panel(ptr graphic c, int x, int y, int w, int h, obj Style s, obj theme.Theme t)
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; s=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `buttonStyle`

```fac
public function boolean buttonStyle(ptr graphic c, int x, int y, int w, int h, string value, obj Style s, obj theme.Theme t)
```

- **Returns:** boolean by value.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; value=borrowed (immutable, shared); s=object reference, shared, not consumed; t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `contentX`

```fac
public function int contentX(int x, obj Style s) { return x + s.padding }
```

Padding helpers keep box geometry explicit while allowing CSS-like spacing tokens.

- **Returns:** int by value.
- **Ownership:** x=by value; s=object reference, shared, not consumed
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `contentY`

```fac
public function int contentY(int y, obj Style s) { return y + s.padding }
```

- **Returns:** int by value.
- **Ownership:** y=by value; s=object reference, shared, not consumed
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `contentWidth`

```fac
public function int contentWidth(int w, obj Style s)
```

- **Returns:** int by value.
- **Ownership:** w=by value; s=object reference, shared, not consumed
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `contentHeight`

```fac
public function int contentHeight(int h, obj Style s)
```

- **Returns:** int by value.
- **Ownership:** h=by value; s=object reference, shared, not consumed
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `image`

```fac
public function void image(ptr graphic c, ptr graphic source, int x, int y, int w, int h)
```

Display an existing Graphics texture/image inside a UI layout. The source image remains owned by the caller; this function only blits it.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `viewportFrame`

```fac
public function void viewportFrame(ptr graphic c, int x, int y, int w, int h, string caption, obj theme.Theme t)
```

Draw a lightweight frame/title over a Graphics-rendered scene region. This is an overlay decoration, not a clipped render target or a separate 3D viewport.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; caption=borrowed (immutable, shared); t=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
