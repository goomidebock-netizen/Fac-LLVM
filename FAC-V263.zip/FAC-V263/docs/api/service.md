# `service` (source library)

Source: `stdlib/service.fac` · `import service.fac` · release V263

### `ServiceRegistry`

```fac
public class ServiceRegistry
```

ServiceRegistry tracks declared service lifecycles only. It does not create service objects, invoke start/stop hooks, supervise processes or spawn threads.

### `ServiceRegistry.register`

```fac
public function void register(string name)
```

- **Returns:** Registers a stopped service; duplicate names are rejected.
- **Ownership:** name=borrowed; registry retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid or duplicate names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `ServiceRegistry.has`

```fac
public function boolean has(string name) { return this.findName(name) >= 0 }
```

- **Returns:** True if the service name is registered.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `ServiceRegistry.start`

```fac
public function boolean start(string name)
```

- **Returns:** Starts a stopped or paused service; false for invalid current states.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for unknown names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `ServiceRegistry.stop`

```fac
public function boolean stop(string name)
```

- **Returns:** Stops a running, paused or failed service; false if already stopped.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for unknown names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `ServiceRegistry.pause`

```fac
public function boolean pause(string name)
```

- **Returns:** Pauses a running service.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for unknown names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `ServiceRegistry.fail`

```fac
public function boolean fail(string name, string message)
```

- **Returns:** Marks a running or paused service as failed and stores a message.
- **Ownership:** name/message=borrowed; registry retains copies.
- **Errors:** Throws InvalidArgument (4) for unknown service or invalid message.
- **Thread-safety:** Not thread-safe when shared mutably.

### `ServiceRegistry.state`

```fac
public function string state(string name)
```

- **Returns:** Current lifecycle state or empty string for an unknown name.
- **Ownership:** name=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `ServiceRegistry.lastFailure`

```fac
public function string lastFailure(string name)
```

- **Returns:** Last failure message or empty string when none/unknown.
- **Ownership:** name=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `ServiceRegistry.isRunning`

```fac
public function boolean isRunning(string name) { return this.state(name) == "running" }
```

- **Returns:** True only while the service is running.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `ServiceRegistry.unregister`

```fac
public function boolean unregister(string name)
```

- **Returns:** Unregisters a stopped service; running services must be stopped first.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for an unknown or running service.
- **Thread-safety:** Not thread-safe when shared mutably.

### `ServiceRegistry.size`

```fac
public function int size() { return sizeof(this.names) }
```

- **Returns:** Number of registered services.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `ServiceRegistry.revision`

```fac
public function long revision() { return this.revisionNumber }
```

- **Returns:** Mutation revision.
- **Ownership:** result=by value.
- **Errors:** Integer overflow follows FAC checked arithmetic.
- **Thread-safety:** Not safe during concurrent mutation.
