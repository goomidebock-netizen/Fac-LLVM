# `database` (source library)

Source: `stdlib/database.fac` · `import database.fac` · release V263

### `ConnectionOptions`

```fac
public class ConnectionOptions
```

ConnectionOptions carries the small set of options shared by database drivers. Drivers must document when a setting is unsupported. The default timeout is 5000 ms.

### `ConnectionOptions.setReadOnly`

```fac
public function void setReadOnly(boolean enabled)
```

- **Returns:** Sets whether the connection must reject writes.
- **Ownership:** enabled=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; configure before opening a connection.

### `ConnectionOptions.setCreateIfMissing`

```fac
public function void setCreateIfMissing(boolean enabled)
```

- **Returns:** Sets whether the driver may create a missing database file.
- **Ownership:** enabled=by value.
- **Errors:** Throws InvalidArgument (4) when create is requested for a read-only connection.
- **Thread-safety:** Not thread-safe; configure before opening a connection.

### `ConnectionOptions.setTimeoutMs`

```fac
public function void setTimeoutMs(int milliseconds)
```

- **Returns:** Sets a bounded connection/busy timeout in milliseconds.
- **Ownership:** milliseconds=by value.
- **Errors:** Throws InvalidArgument (4) outside 0..600000.
- **Thread-safety:** Not thread-safe; configure before opening a connection.

### `ConnectionOptions.isReadOnly`

```fac
public function boolean isReadOnly() { return this.readOnly }
```

- **Returns:** Whether the configured connection is read-only.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable options object.

### `ConnectionOptions.createIfMissing`

```fac
public function boolean createIfMissing() { return this.createIfMissing }
```

- **Returns:** Whether a missing database may be created.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable options object.

### `ConnectionOptions.timeoutMs`

```fac
public function int timeoutMs() { return this.timeoutMs }
```

- **Returns:** Connection/busy timeout in milliseconds.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable options object.
