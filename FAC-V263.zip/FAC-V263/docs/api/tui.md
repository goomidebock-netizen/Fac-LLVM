# `tui` (source library)

Source: `stdlib/tui.fac` · `import tui.fac` · release V263

### `esc`

```fac
public function string esc() { return str(cast(Char, 27)) }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `reset`

```fac
public function string reset() { return esc() + "[0m" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `clear`

```fac
public function string clear() { return esc() + "[2J" + esc() + "[H" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `hideCursor`

```fac
public function string hideCursor() { return esc() + "[?25l" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `showCursor`

```fac
public function string showCursor() { return esc() + "[?25h" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `moveTo`

```fac
public function string moveTo(int row, int col) { return esc() + "[" + str(row) + ";" + str(col) + "H" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** row=by value; col=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `saveCursor`

```fac
public function string saveCursor() { return esc() + "[s" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `restoreCursor`

```fac
public function string restoreCursor() { return esc() + "[u" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `enterAltScreen`

```fac
public function string enterAltScreen() { return esc() + "[?1049h" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `leaveAltScreen`

```fac
public function string leaveAltScreen() { return esc() + "[?1049l" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `eraseLine`

```fac
public function string eraseLine() { return esc() + "[2K" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `eraseDown`

```fac
public function string eraseDown() { return esc() + "[J" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `cursorUp`

```fac
public function string cursorUp(int n) { return esc() + "[" + str(n) + "A" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** n=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `cursorDown`

```fac
public function string cursorDown(int n) { return esc() + "[" + str(n) + "B" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** n=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `cursorForward`

```fac
public function string cursorForward(int n) { return esc() + "[" + str(n) + "C" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** n=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `cursorBack`

```fac
public function string cursorBack(int n) { return esc() + "[" + str(n) + "D" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** n=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `scrollRegion`

```fac
public function string scrollRegion(int topRow, int bottomRow) { return esc() + "[" + str(topRow) + ";" + str(bottomRow) + "r" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** topRow=by value; bottomRow=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `resetScrollRegion`

```fac
public function string resetScrollRegion() { return esc() + "[r" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `spinner`

```fac
public function string spinner(int frame)
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** frame=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `fg`

```fac
public function string fg(int code) { return esc() + "[38;5;" + str(code) + "m" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** code=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `bg`

```fac
public function string bg(int code) { return esc() + "[48;5;" + str(code) + "m" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** code=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `rgb`

```fac
public function string rgb(int r, int g, int b) { return esc() + "[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** r=by value; g=by value; b=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `rgbBg`

```fac
public function string rgbBg(int r, int g, int b) { return esc() + "[48;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** r=by value; g=by value; b=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `bold`

```fac
public function string bold(string s) { return esc() + "[1m" + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `dim`

```fac
public function string dim(string s) { return esc() + "[2m" + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `italic`

```fac
public function string italic(string s) { return esc() + "[3m" + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `underline`

```fac
public function string underline(string s) { return esc() + "[4m" + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inverse`

```fac
public function string inverse(string s) { return esc() + "[7m" + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `pad`

```fac
public function string pad(string s, int width)
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared); width=by value
- **Errors:** Can throw: propagates Error from string.repeat.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `center`

```fac
public function string center(string s, int width)
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared); width=by value
- **Errors:** Can throw: propagates Error from string.repeat.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `repeat`

```fac
public function string repeat(string s, int n) { return string.repeat(s, n) }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared); n=by value
- **Errors:** Can throw: propagates Error from string.repeat.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `hr`

```fac
public function string hr(int width) { return "├" + repeat("─", width - 2) + "┤" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `top`

```fac
public function string top(int width) { return "╭" + repeat("─", width - 2) + "╮" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `bottom`

```fac
public function string bottom(int width) { return "╰" + repeat("─", width - 2) + "╯" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `asciiTop`

```fac
public function string asciiTop(int width) { return "+" + repeat("-", width - 2) + "+" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `asciiBottom`

```fac
public function string asciiBottom(int width) { return "+" + repeat("-", width - 2) + "+" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `asciiRule`

```fac
public function string asciiRule(int width) { return "+" + repeat("-", width - 2) + "+" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `asciiBoxLine`

```fac
public function string asciiBoxLine(string s, int width) { return "| " + pad(s, width - 4) + " |" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `boxLine`

```fac
public function string boxLine(string s, int width) { return "│ " + pad(s, width - 4) + " │" }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `rule`

```fac
public function void rule(int width) { terminal.out.println(fg(39) + hr(width) + reset()) }
```

- **Returns:** Nothing.
- **Ownership:** width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `header`

```fac
public function void header(string title, int width)
```

- **Returns:** Nothing.
- **Ownership:** title=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `panel`

```fac
public function void panel(string title, string body, int width)
```

- **Returns:** Nothing.
- **Ownership:** title=borrowed (immutable, shared); body=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `section`

```fac
public function void section(string title, int width)
```

- **Returns:** Nothing.
- **Ownership:** title=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `keyValue`

```fac
public function void keyValue(string key, string value, int width)
```

- **Returns:** Nothing.
- **Ownership:** key=borrowed (immutable, shared); value=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `progressBar`

```fac
public function string progressBar(int current, int total, int width)
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** current=by value; total=by value; width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `progress`

```fac
public function void progress(string label, int current, int total, int width)
```

- **Returns:** Nothing.
- **Ownership:** label=borrowed (immutable, shared); current=by value; total=by value; width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `status`

```fac
public function void status(string kind, string message)
```

- **Returns:** Nothing.
- **Ownership:** kind=borrowed (immutable, shared); message=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `tableHeader`

```fac
public function void tableHeader(string a, string b, string c, int wa, int wb, int wc)
```

- **Returns:** Nothing.
- **Ownership:** a=borrowed (immutable, shared); b=borrowed (immutable, shared); c=borrowed (immutable, shared); wa=by value; wb=by value; wc=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `tableRow`

```fac
public function void tableRow(string a, string b, string c, int wa, int wb, int wc)
```

- **Returns:** Nothing.
- **Ownership:** a=borrowed (immutable, shared); b=borrowed (immutable, shared); c=borrowed (immutable, shared); wa=by value; wb=by value; wc=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `menu`

```fac
public function int menu(string title, list dyn string options)
```

- **Returns:** int by value.
- **Ownership:** title=borrowed (immutable, shared); options=borrowed (read-only view for the call)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `banner`

```fac
public function void banner(string name, string subtitle, int width)
```

- **Returns:** Nothing.
- **Ownership:** name=borrowed (immutable, shared); subtitle=borrowed (immutable, shared); width=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `title`

```fac
public function string title(string s) { return bold(rgb(120, 166, 255) + s) }
```

---------------------------------------------------------------------- Small semantic helpers. TUI intentionally stays a lightweight secondary module; it does not pretend to provide raw-key event loops or a full widget tree. ----------------------------------------------------------------------

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `muted`

```fac
public function string muted(string s) { return fg(244) + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `success`

```fac
public function string success(string s) { return fg(46) + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `warning`

```fac
public function string warning(string s) { return fg(220) + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `error`

```fac
public function string error(string s) { return fg(196) + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `info`

```fac
public function string info(string s) { return fg(39) + s + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `kbd`

```fac
public function string kbd(string s) { return bg(236) + fg(255) + " " + s + " " + reset() }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `bullet`

```fac
public function string bullet(string s) { return fg(39) + "• " + reset() + s }
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** s=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `keyHint`

```fac
public function string keyHint(string key, string description)
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** key=borrowed (immutable, shared); description=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `notice`

```fac
public function void notice(string heading, string message, string kind)
```

- **Returns:** Nothing.
- **Ownership:** heading=borrowed (immutable, shared); message=borrowed (immutable, shared); kind=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
