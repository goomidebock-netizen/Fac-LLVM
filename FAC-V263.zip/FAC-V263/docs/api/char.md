# `char`

Character classification/conversion (provider module: string).

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 10 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `char.isAlnum(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.isAlpha(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.isDigit(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.isLower(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.isPunct(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.isSpace(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.isUpper(unichar)` → boolean | predicate (never throws on a normal miss) |  |
| `char.toInt(unichar)` → int | no direct throw site | also: `unichar.toInt` |
| `char.toLower(unichar)` → unichar | no direct throw site |  |
| `char.toUpper(unichar)` → unichar | no direct throw site |  |

_Parameter names are not part of the built-in contract; positional types are shown._
