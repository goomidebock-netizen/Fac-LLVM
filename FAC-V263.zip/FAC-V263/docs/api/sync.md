# `sync` (source library)

Source: `stdlib/sync.fac` · `import sync.fac` · release V263

### `Atomic.get`

```fac
public function int get() { return thread.atomicGet(this.cell) }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Atomic: built on thread.atomic*/mutex operations; safe for concurrent calls.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Atomic.set`

```fac
public function void set(int v) { thread.atomicSet(this.cell, v) }
```

- **Returns:** Nothing.
- **Ownership:** v=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Atomic: built on thread.atomic*/mutex operations; safe for concurrent calls.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Atomic.add`

```fac
public function int add(int d) { return thread.atomicAdd(this.cell, d) }
```

- **Returns:** int by value.
- **Ownership:** d=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Atomic: built on thread.atomic*/mutex operations; safe for concurrent calls.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Atomic.cas`

```fac
public function boolean cas(int expected, int desired) { return thread.atomicCas(this.cell, expected, desired) }
```

- **Returns:** boolean by value.
- **Ownership:** expected=by value; desired=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Atomic: built on thread.atomic*/mutex operations; safe for concurrent calls.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Channel.send`

```fac
public function boolean send(string msg, int timeoutMs)
```

- **Returns:** boolean by value.
- **Ownership:** msg=borrowed (immutable, shared); timeoutMs=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Channel.recv`

```fac
public function enum Option<string> recv(int timeoutMs)
```

- **Returns:** Option<string> value; managed payloads are owned by the caller.
- **Ownership:** timeoutMs=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Channel.close`

```fac
public function void close() { unsafe { fac_sync_chan_close(this.h) } }
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Channel.done`

```fac
public function boolean done()
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Channel.len`

```fac
public function int len()
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Cell.get`

```fac
public function dyn string get()
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Cell.set`

```fac
public function boolean set(string val)
```

- **Returns:** boolean by value.
- **Ownership:** val=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Cell.swap`

```fac
public function dyn string swap(string val)
```

- **Returns:** Owned string (caller-owned, immutable).
- **Ownership:** val=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Cell.cas`

```fac
public function boolean cas(string expected, string desired)
```

- **Returns:** boolean by value.
- **Ownership:** expected=borrowed (immutable, shared); desired=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
