# `circuit_breaker` (source library)

Source: `stdlib/circuit_breaker.fac` · `import circuit_breaker.fac` · release V263

### `CircuitBreaker`

```fac
public class CircuitBreaker
```

CircuitBreaker is a caller-driven state machine. Each successful allow() reserves one in-flight call; every reservation must end in recordSuccess() or recordFailure(). It does not execute callbacks or measure call duration.

### `CircuitBreaker.configure`

```fac
public function void configure(int threshold, long resetTimeout)
```

- **Returns:** Reconfigures policy and resets the breaker to closed.
- **Ownership:** scalar arguments=by value.
- **Errors:** Throws InvalidArgument (4) for non-positive values.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `CircuitBreaker.allow`

```fac
public function boolean allow(long nowMs)
```

- **Returns:** True when a call is admitted; one half-open probe is admitted after timeout.
- **Ownership:** nowMs=by value; result=by value.
- **Errors:** Throws InvalidArgument (4) for negative/decreasing time or deadline overflow.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `CircuitBreaker.recordSuccess`

```fac
public function void recordSuccess()
```

- **Returns:** Records a successful admitted call; closes a half-open breaker.
- **Ownership:** no parameters.
- **Errors:** Throws InvalidArgument (4) when no call is pending.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `CircuitBreaker.recordFailure`

```fac
public function void recordFailure(long nowMs)
```

- **Returns:** Records an admitted call failure; opens/reopens at the failure threshold.
- **Ownership:** nowMs=by value.
- **Errors:** Throws InvalidArgument (4) for no pending call or invalid/decreasing time.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `CircuitBreaker.state`

```fac
public function string state() { return this.currentState }
```

- **Returns:** Current state: closed, open or half_open.
- **Ownership:** result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable breaker.

### `CircuitBreaker.failures`

```fac
public function int failures() { return this.consecutiveFailures }
```

- **Returns:** Consecutive failure count since the last success/reset.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable breaker.

### `CircuitBreaker.pending`

```fac
public function int pending() { return this.pendingCalls }
```

- **Returns:** Number of admitted calls awaiting completion.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable breaker.

### `CircuitBreaker.threshold`

```fac
public function int threshold() { return this.failureThreshold }
```

- **Returns:** Configured failure threshold.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable breaker.

### `CircuitBreaker.resetTimeout`

```fac
public function long resetTimeout() { return this.resetTimeoutMs }
```

- **Returns:** Configured open-state timeout in milliseconds.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable breaker.

### `CircuitBreaker.reset`

```fac
public function void reset()
```

- **Returns:** Resets to closed and clears failures, pending calls and clock history.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
