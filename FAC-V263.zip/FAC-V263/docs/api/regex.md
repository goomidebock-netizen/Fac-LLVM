# `regex`

Regular expressions.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 7 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `regex.count(string, string)` → int | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed |
| `regex.find(string, string)` → string | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `regex.findAll(string, string)` → list<string> | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `regex.groups(string, string)` → list<string> | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `regex.match(string, string)` → boolean | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed |
| `regex.replace(string, string, string)` → string | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed, #3 borrowed; result: owned by caller |
| `regex.split(string, string)` → list<string> | throws `Error` (code 9 Regex) | args: #1 borrowed, #2 borrowed; result: owned by caller |

_Parameter names are not part of the built-in contract; positional types are shown._
