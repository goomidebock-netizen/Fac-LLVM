# `tls`

Optional POSIX OpenSSL 1.1.1+/3.x TLS 1.2+ transport loaded dynamically; client validates default CA trust and DNS hostname, server loads PEM certificate/key; unavailable on Windows in this release.

- Status: **preview**
- Thread-safety: **serialized per opaque handle (do not race managed close/destruction)**
- Entries: 8 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `tls.available()` → boolean | predicate (never throws on a normal miss) |  |
| `tls.cipher(handle)` → string | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller; Negotiated metadata query synchronized with operations and close; stale/closed handles fail with Network (11). |
| `tls.close(handle)` → void | no direct throw site | args: #1 borrowed-handle; Marks the stream closing before waiting for any in-flight TLS operation, then closes the TLS stream and its owned TCP socket once. New operations are rejected; repeated close is harmless and stale TLS aliases fail with Network (11). |
| `tls.recvExactBytes(handle, int)` → list<int> | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller; TLS operations on one stream are serialized with close to prevent concurrent OpenSSL SSL-object access. A blocking receive therefore holds the stream lock and delays sends on the same stream; use separate streams when independent simultaneous directions are required. |
| `tls.sendBytes(handle, list<int>)` → int | throws `Error` (code 11 Network, 13 Encoding) | args: #1 borrowed-handle, #2 borrowed; TLS operations on one stream are serialized with close to prevent concurrent OpenSSL SSL-object access. A blocking receive therefore holds the stream lock and delays sends on the same stream; use separate streams when independent simultaneous directions are required. |
| `tls.version(handle)` → string | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller; Negotiated metadata query synchronized with operations and close; stale/closed handles fail with Network (11). |
| `tls.wrapClient(handle, string)` → handle | throws `Error` (code 4 AssertionFailed, 11 Network) + OOM | args: #1 borrowed-handle, #2 borrowed; result: owned by caller (release with `tls.close`); On successful handshake, transfers ownership of the TCP connection to the returned TLS handle and retires the old socket token. If setup or handshake fails, the caller retains ownership of the original socket. |
| `tls.wrapServer(handle, string, string)` → handle | throws `Error` (code 4 AssertionFailed, 11 Network) + OOM | args: #1 borrowed-handle, #2 borrowed, #3 borrowed; result: owned by caller (release with `tls.close`); On successful handshake, transfers ownership of the TCP connection to the returned TLS handle and retires the old socket token. If setup or handshake fails, the caller retains ownership of the original socket. |

_Parameter names are not part of the built-in contract; positional types are shown._
