# `sql` (source library)

Source: `stdlib/sql.fac` · `import sql.fac` · release V263

### `quoteIdentifier`

```fac
public function string quoteIdentifier(string identifier)
```

- **Returns:** A double-quoted SQL identifier with embedded double quotes doubled.
- **Ownership:** identifier=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) for an empty identifier or embedded NUL.
- **Thread-safety:** Safe-pure.

### `placeholder`

```fac
public function string placeholder(int index)
```

- **Returns:** A numbered SQLite/SQL positional placeholder such as ?1.
- **Ownership:** index=by value; result=owned string.
- **Errors:** Throws InvalidArgument (4) unless index is positive.
- **Thread-safety:** Safe-pure.

### `placeholders`

```fac
public function string placeholders(int count)
```

- **Returns:** A comma-and-space separated list of numbered placeholders.
- **Ownership:** count=by value; result=owned string.
- **Errors:** Throws InvalidArgument (4) for count outside 0..100000.
- **Thread-safety:** Safe-pure.

### `likeContains`

```fac
public function string likeContains(string value)
```

- **Returns:** An escaped SQL LIKE pattern for a contains-search; use SQLite `ESCAPE '\'` (one backslash in the SQL string literal). In a FAC double-quoted string, write `\\`.
- **Ownership:** value=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) when the input contains NUL.
- **Thread-safety:** Safe-pure.
