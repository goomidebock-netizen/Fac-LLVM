# `router` (source library)

Source: `stdlib/router.fac` · `import router.fac` · release V263

### `RouteRegistry`

```fac
public class RouteRegistry
```

RouteRegistry stores declarative method/path -> handler-name mappings. It resolves names only; it does not invoke handlers or implement an HTTP server. A trailing /* pattern matches its literal prefix and any following path.

### `RouteRegistry.add`

```fac
public function void add(string method, string pattern, string handler)
```

- **Returns:** Registers a route. Exact duplicates are rejected.
- **Ownership:** method/pattern/handler=borrowed; registry retains copies.
- **Errors:** Throws InvalidArgument (4) for invalid or duplicate routes.
- **Thread-safety:** Not thread-safe when shared mutably.

### `RouteRegistry.setFallback`

```fac
public function void setFallback(string handler) { this.fallbackHandler = handler }
```

- **Returns:** Replaces the name returned when no route matches; empty disables fallback.
- **Ownership:** handler=borrowed; registry retains a copy.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `RouteRegistry.resolve`

```fac
public function string resolve(string method, string path)
```

- **Returns:** Handler for an exact route or the longest matching trailing /* prefix; otherwise fallback/empty.
- **Ownership:** method/path=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) for an invalid path or method.
- **Thread-safety:** Safe for a stable registry.

### `RouteRegistry.remove`

```fac
public function boolean remove(string method, string pattern)
```

- **Returns:** Removes a route by method and exact registered pattern; false if absent.
- **Ownership:** method/pattern=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for invalid method or pattern.
- **Thread-safety:** Not thread-safe when shared mutably.

### `RouteRegistry.size`

```fac
public function int size() { return sizeof(this.methods) }
```

- **Returns:** Number of registered routes.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `RouteRegistry.clear`

```fac
public function void clear()
```

- **Returns:** Removes all routes and fallback.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
