# `camera` (source library)

Source: `stdlib/camera.fac` · `import camera.fac` · release V263

### `Camera.setBounds`

```fac
public function void setBounds(double w, double h)
```

- **Returns:** Nothing.
- **Ownership:** w=by value; h=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Camera receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.clearBounds`

```fac
public function void clearBounds() { this.bounded = false }
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Camera receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.clamp`

```fac
public function void clamp()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Camera receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.snapTo`

```fac
public function void snapTo(double tx, double ty)
```

ย้ายให้จุด (tx, ty) อยู่กึ่งกลางจอทันที

- **Returns:** Nothing.
- **Ownership:** tx=by value; ty=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Camera receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.follow`

```fac
public function void follow(double tx, double ty, double speed, double dt)
```

เลื่อนเข้าหาเป้า (tx, ty) ด้วยความเร็วเข้าหา speed (ต่อวินาที; speed <= 0 = snap ทันที) dt ต้อง finite และไม่ติดลบ; dt ติดลบจะ throw แทนการ snap โดยไม่ตั้งใจ

- **Returns:** Nothing.
- **Ownership:** tx=by value; ty=by value; speed=by value; dt=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Camera receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.moveBy`

```fac
public function void moveBy(double dx, double dy)
```

เลื่อนกล้องเป็นระยะพิกเซลโลก; ใช้ clamp เหมือน follow/snapTo

- **Returns:** Nothing.
- **Ownership:** dx=by value; dy=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Camera receiver; synchronize externally.

### `Camera.px`

```fac
public function int px() { return cast(Int, math.floor(this.x)) }
```

พิกเซลจำนวนเต็มของมุมซ้ายบน (ปัดลง) -- ใช้กับ Tilemap.draw เพื่อไม่ให้ภาพสั่น

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.py`

```fac
public function int py() { return cast(Int, math.floor(this.y)) }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.screenX`

```fac
public function double screenX(double wx) { return wx - this.x }
```

- **Returns:** double by value.
- **Ownership:** wx=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.screenY`

```fac
public function double screenY(double wy) { return wy - this.y }
```

- **Returns:** double by value.
- **Ownership:** wy=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.worldX`

```fac
public function double worldX(double sx) { return sx + this.x }
```

- **Returns:** double by value.
- **Ownership:** sx=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.worldY`

```fac
public function double worldY(double sy) { return sy + this.y }
```

- **Returns:** double by value.
- **Ownership:** sy=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Camera.sees`

```fac
public function boolean sees(double wx, double wy, double w, double h)
```

สี่เหลี่ยมโลก (x, y, w, h) มองเห็นบนจอหรือไม่

- **Returns:** boolean by value.
- **Ownership:** wx=by value; wy=by value; w=by value; h=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Camera receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
