# `unicode` (source library)

Source: `stdlib/unicode.fac` · `import unicode.fac` · release V263

### `UnicodeTools`

```fac
public class UnicodeTools
```

UnicodeTools works with Unicode scalar values exposed by FAC strings. Grapheme operations inherit the Runtime's practical subset, not full UAX #29.

### `UnicodeTools.codePointLength`

```fac
public function int codePointLength(string text) { return string.length(text) }
```

- **Returns:** Number of Unicode code points (not bytes or grapheme clusters).
- **Ownership:** text=borrowed.
- **Errors:** None for a valid FAC string.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.graphemeLength`

```fac
public function int graphemeLength(string text) { return string.graphemeLength(text) }
```

- **Returns:** Number of grapheme clusters supported by the FAC Runtime.
- **Ownership:** text=borrowed.
- **Errors:** None for a valid FAC string.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.codePointAt`

```fac
public function int codePointAt(string text, int index)
```

- **Returns:** One Unicode scalar value at a zero-based code-point index.
- **Ownership:** text=borrowed; result=by value.
- **Errors:** Throws IndexOutOfRange (2) when index is outside the string.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.isAscii`

```fac
public function boolean isAscii(string text)
```

- **Returns:** True when every code point is in the ASCII range U+0000..U+007F.
- **Ownership:** text=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.isAsciiAlpha`

```fac
public function boolean isAsciiAlpha(string text)
```

- **Returns:** True when every code point is an ASCII letter A-Z or a-z.
- **Ownership:** text=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.isAsciiNumeric`

```fac
public function boolean isAsciiNumeric(string text)
```

- **Returns:** True when every code point is an ASCII digit 0-9.
- **Ownership:** text=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.sliceCodePoints`

```fac
public function string sliceCodePoints(string text, int start, int end)
```

- **Returns:** A new string containing code points in [start,end).
- **Ownership:** text=borrowed; result=owned string.
- **Errors:** Throws IndexOutOfRange (2) for invalid boundaries.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.fromCodePoints`

```fac
public function string fromCodePoints(list dyn int codePoints)
```

- **Returns:** A new string formed from Unicode scalar values.
- **Ownership:** codePoints=borrowed (read-only); result=owned string.
- **Errors:** Throws Encoding (13) for negative values, surrogate values or values above U+10FFFF.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.toCodePoints`

```fac
public function list dyn int toCodePoints(string text)
```

- **Returns:** A list of Unicode scalar values represented as integers.
- **Ownership:** text=borrowed; result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe-pure.

### `UnicodeTools.graphemeAt`

```fac
public function string graphemeAt(string text, int index)
```

- **Returns:** A new string containing one grapheme cluster at index.
- **Ownership:** text=borrowed; result=owned string.
- **Errors:** Throws IndexOutOfRange (2) when index is outside the supported grapheme sequence.
- **Thread-safety:** Safe-pure.
