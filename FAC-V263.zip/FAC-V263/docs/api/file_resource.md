# `file_resource` (source library)

Source: `stdlib/file_resource.fac` · `import file_resource.fac` · release V263

### `FileHandle`

```fac
public class FileHandle
```

FileHandle is a managed owner for the raw built-in file handle. Copies of the obj share one owner; the native file is closed when the final owner is released.

### `FileHandle.isOpen`

```fac
public function boolean isOpen() { return this.handle != null }
```

- **Returns:** Whether the native file handle is still owned and open.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Read only; do not race with close or I/O.

### `FileHandle.readLine`

```fac
public function string readLine()
```

- **Returns:** Reads one line without its trailing line ending.
- **Ownership:** result=owned string; this object retains the file handle.
- **Errors:** Throws Error (7) when closed or when reading fails.
- **Thread-safety:** Concurrent I/O calls are serialized by the Runtime token. Do not race with close or final-owner destruction.

### `FileHandle.readAll`

```fac
public function string readAll()
```

- **Returns:** Reads the remaining file contents.
- **Ownership:** result=owned string; this object retains the file handle.
- **Errors:** Throws Error (7) when closed or when reading fails/limits are exceeded.
- **Thread-safety:** Concurrent I/O calls are serialized by the Runtime token. Do not race with close or final-owner destruction.

### `FileHandle.write`

```fac
public function void write(string text)
```

- **Returns:** Writes the complete string to the file.
- **Ownership:** text=borrowed; this object retains the file handle.
- **Errors:** Throws Error (7) when closed or when writing fails.
- **Thread-safety:** Concurrent I/O calls are serialized by the Runtime token. Do not race with close or final-owner destruction.

### `FileHandle.close`

```fac
public function void close()
```

- **Returns:** Closes the native handle; repeated calls are harmless.
- **Ownership:** consumes this object's native handle but not the managed object.
- **Errors:** None; the underlying built-in close operation is best-effort.
- **Thread-safety:** Do not race managed close with other wrapper methods or final-owner destruction; the low-level Runtime token itself makes duplicate close idempotent.
