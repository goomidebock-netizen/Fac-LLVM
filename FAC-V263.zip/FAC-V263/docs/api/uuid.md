# `uuid` (source library)

Source: `stdlib/uuid.fac` · `import uuid.fac` · release V263

### `v4`

```fac
public function string v4() { return crypto.uuid() }
```

- **Returns:** A newly generated RFC 4122 / RFC 9562 UUID version 4 string.
- **Ownership:** result=owned string.
- **Errors:** May fail when the operating-system random source is unavailable.
- **Thread-safety:** Safe; generation uses the Runtime cryptographic random source.

### `isValid`

```fac
public function boolean isValid(string value)
```

- **Returns:** True when value has the canonical 8-4-4-4-12 hexadecimal UUID text shape.
- **Ownership:** value=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `version`

```fac
public function int version(string value)
```

- **Returns:** RFC UUID version (1..8), or -1 for invalid text or a version nibble outside 1..8.
- **Ownership:** value=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `hasRfcVariant`

```fac
public function boolean hasRfcVariant(string value)
```

- **Returns:** True when the UUID variant nibble is RFC-compatible (8, 9, a or b).
- **Ownership:** value=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe-pure.
