# `result` (source library)

Source: `stdlib/result.fac` · `import result.fac` · release V263

### `Option`

```fac
public enum Option<T>
```

### `Result`

```fac
public enum Result<T, E>
```
