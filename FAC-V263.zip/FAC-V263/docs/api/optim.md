# `optim`

CPU SGD, Adam, Momentum and RMSProp parameter updates plus gradient clipping.

- Status: **basic**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 12 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `optim.adamCreate(int, int)` → handle | throws `Error` (code 8 Resource) | result: owned by caller (release with `optim.adamFree`) |
| `optim.adamFree(handle)` → void | no direct throw site | args: #1 borrowed-handle |
| `optim.adamStep(handle, handle, handle, double)` → void | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Transactional Adam update with beta1=0.9, beta2=0.999 and epsilon=1e-8; parameters, moments and step count commit only after all candidate values validate. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `optim.clipNorm(handle, double)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns a copy scaled down when its flattened L2 norm exceeds maxNorm. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `optim.clipValue(handle, double, double)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns a copy clamped elementwise to finite ordered min/max bounds. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `optim.momentumCreate(int, int)` → handle | throws `Error` (code 8 Resource) | result: owned by caller (release with `optim.momentumFree`); Creates zero velocity state with the supplied shape; release with momentumFree. |
| `optim.momentumFree(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees a Momentum optimizer state handle; Consumes and frees Momentum state. |
| `optim.momentumStep(handle, handle, handle, double, double)` → void | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Transactional Momentum update: velocity and parameters are committed only after all candidate values pass finite float64 checks. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `optim.rmspropCreate(int, int)` → handle | throws `Error` (code 8 Resource) | result: owned by caller (release with `optim.rmspropFree`); Creates zero square-average state with the supplied shape; release with rmspropFree. |
| `optim.rmspropFree(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees an RMSProp optimizer state handle; Consumes and frees RMSProp state. |
| `optim.rmspropStep(handle, handle, handle, double, double, double)` → void | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Transactional RMSProp update: square-average state and parameters remain unchanged if a candidate value is non-finite or out of float64 range. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `optim.sgdStep(handle, handle, double)` → void | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Transactional parameter update: candidate values are fully validated before commit; on overflow, parameters remain unchanged. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |

_Parameter names are not part of the built-in contract; positional types are shown._
