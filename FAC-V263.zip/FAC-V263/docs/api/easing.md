# `easing` (source library)

Source: `stdlib/easing.fac` · `import easing.fac` · release V263

### `lerp`

```fac
public function double lerp(double a, double b, double t) { return a + (b - a) * t }
```

- **Returns:** double by value.
- **Ownership:** a=by value; b=by value; t=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inverseLerp`

```fac
public function double inverseLerp(double a, double b, double value)
```

- **Returns:** double by value.
- **Ownership:** a=by value; b=by value; value=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `remap`

```fac
public function double remap(double value, double inA, double inB, double outA, double outB)
```

- **Returns:** double by value.
- **Ownership:** value=by value; inA=by value; inB=by value; outA=by value; outB=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `linear`

```fac
public function double linear(double t) { return clamp01(t) }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `smoothstep`

```fac
public function double smoothstep(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `smootherstep`

```fac
public function double smootherstep(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inQuad`

```fac
public function double inQuad(double t) { t = clamp01(t); return t * t }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outQuad`

```fac
public function double outQuad(double t) { t = clamp01(t); return 1.0 - (1.0 - t) * (1.0 - t) }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutQuad`

```fac
public function double inOutQuad(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inCubic`

```fac
public function double inCubic(double t) { t = clamp01(t); return t * t * t }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outCubic`

```fac
public function double outCubic(double t) { t = clamp01(t); var double q = 1.0 - t; return 1.0 - q * q * q }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutCubic`

```fac
public function double inOutCubic(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inSine`

```fac
public function double inSine(double t) { return 1.0 - math.cos(clamp01(t) * 1.5707963267948966) }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outSine`

```fac
public function double outSine(double t) { return math.sin(clamp01(t) * 1.5707963267948966) }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutSine`

```fac
public function double inOutSine(double t) { return -(math.cos(3.141592653589793 * clamp01(t)) - 1.0) / 2.0 }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `damp`

```fac
public function double damp(double current, double target, double speed, double dt)
```

Frame-rate-independent exponential damping. speed <= 0 leaves current unchanged.

- **Returns:** double by value.
- **Ownership:** current=by value; target=by value; speed=by value; dt=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `moveTowards`

```fac
public function double moveTowards(double current, double target, double maxDelta)
```

Move by at most maxDelta without overshooting. maxDelta < 0 is treated as zero.

- **Returns:** double by value.
- **Ownership:** current=by value; target=by value; maxDelta=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `repeat`

```fac
public function double repeat(double value, double span)
```

Positive modulo; returns 0 when span <= 0.

- **Returns:** double by value.
- **Ownership:** value=by value; span=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `pingPong`

```fac
public function double pingPong(double value, double length)
```

Triangle wave in [0,length]; returns 0 when length <= 0.

- **Returns:** double by value.
- **Ownership:** value=by value; length=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inQuart`

```fac
public function double inQuart(double t) { t = clamp01(t); return t * t * t * t }
```

Quartic and quintic curves.

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outQuart`

```fac
public function double outQuart(double t) { t = clamp01(t); var double q = 1.0 - t; return 1.0 - q * q * q * q }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutQuart`

```fac
public function double inOutQuart(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inQuint`

```fac
public function double inQuint(double t) { t = clamp01(t); return t * t * t * t * t }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outQuint`

```fac
public function double outQuint(double t) { t = clamp01(t); var double q = 1.0 - t; return 1.0 - q * q * q * q * q }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutQuint`

```fac
public function double inOutQuint(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inExpo`

```fac
public function double inExpo(double t)
```

Exponential curves preserve exact endpoints.

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outExpo`

```fac
public function double outExpo(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutExpo`

```fac
public function double inOutExpo(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inCirc`

```fac
public function double inCirc(double t) { t = clamp01(t); return 1.0 - math.sqrt(math.max(0.0, 1.0 - t * t)) }
```

Circular curves. sqrt input is clamped against round-off below zero.

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outCirc`

```fac
public function double outCirc(double t) { t = clamp01(t); var double q = t - 1.0; return math.sqrt(math.max(0.0, 1.0 - q * q)) }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutCirc`

```fac
public function double inOutCirc(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outBounce`

```fac
public function double outBounce(double t)
```

Bounce curves. These intentionally have several local reversals.

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inBounce`

```fac
public function double inBounce(double t) { return 1.0 - outBounce(1.0 - clamp01(t)) }
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutBounce`

```fac
public function double inOutBounce(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inBack`

```fac
public function double inBack(double t)
```

Back curves intentionally overshoot the [0,1] range.

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outBack`

```fac
public function double outBack(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutBack`

```fac
public function double inOutBack(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inElastic`

```fac
public function double inElastic(double t)
```

Elastic curves intentionally oscillate; endpoints remain exact.

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `outElastic`

```fac
public function double outElastic(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inOutElastic`

```fac
public function double inOutElastic(double t)
```

- **Returns:** double by value.
- **Ownership:** t=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
