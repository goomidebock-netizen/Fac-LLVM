# `decimal` (source library)

Source: `stdlib/decimal.fac` · `import decimal.fac` · release V263

### `Decimal`

```fac
public class Decimal
```

Decimal is a signed fixed-point decimal with six fractional digits. The stored value is an Int64 count of millionths; operations never use binary float. Overflow is reported by FAC's checked integer arithmetic.

### `Decimal.scaledValue`

```fac
public function long scaledValue() { return this.scaled }
```

- **Returns:** Creates a value from the exact scaled integer (1 unit = 0.000001).
- **Ownership:** value=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `Decimal.setScaledValue`

```fac
public function void setScaledValue(long value) { this.scaled = value; this.negative = value < 0 }
```

- **Returns:** Replaces the value using an exact scaled integer.
- **Ownership:** value=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Decimal.parse`

```fac
public function boolean parse(string text)
```

- **Returns:** True when text is a signed base-10 decimal with at most six fractional digits.
- **Ownership:** text=borrowed.
- **Errors:** None; false is returned for malformed or out-of-range input.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Decimal.toString`

```fac
public function string toString()
```

- **Returns:** Fixed-six-place decimal text (for example, 1.5 becomes 1.500000).
- **Ownership:** result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `Decimal.addScaled`

```fac
public function void addScaled(long otherScaled) { this.scaled += otherScaled; this.negative = this.scaled < 0 }
```

- **Returns:** Adds a raw scaled integer in place; pass Decimal.scaledValue().
- **Ownership:** otherScaled=by value.
- **Errors:** Integer overflow is reported by the checked runtime.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Decimal.subtractScaled`

```fac
public function void subtractScaled(long otherScaled) { this.scaled -= otherScaled; this.negative = this.scaled < 0 }
```

- **Returns:** Subtracts a raw scaled integer in place; pass Decimal.scaledValue().
- **Ownership:** otherScaled=by value.
- **Errors:** Integer overflow is reported by the checked runtime.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Decimal.multiplyInt`

```fac
public function void multiplyInt(long factor) { this.scaled *= factor; this.negative = this.scaled < 0 }
```

- **Returns:** Multiplies by an integer in place.
- **Ownership:** factor=by value.
- **Errors:** Integer overflow is reported by the checked runtime.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Decimal.divideInt`

```fac
public function void divideInt(long divisor)
```

- **Returns:** Divides by an integer in place, truncating toward zero at the scaled-integer boundary.
- **Ownership:** divisor=by value.
- **Errors:** Throws InvalidArgument (4) when divisor is zero.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Decimal.compareScaled`

```fac
public function int compareScaled(long otherScaled)
```

- **Returns:** -1, 0, or 1 according to this value's relation to other.
- **Ownership:** otherScaled=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.
