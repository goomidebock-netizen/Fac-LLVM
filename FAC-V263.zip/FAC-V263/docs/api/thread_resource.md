# `thread_resource` (source library)

Source: `stdlib/thread_resource.fac` · `import thread_resource.fac` · release V263

### `Task`

```fac
public class Task
```

Task is a managed owner for a handle already returned by thread.start. Keep thread.start(lambda) at the call site so the compiler can inspect captures. Copies of obj Task share one owner. join() consumes the native handle once; final-owner destruction joins any still-running worker. Call join() explicitly to observe worker failures: the destructor suppresses a worker error while performing best-effort cleanup. Never capture a Task in its own worker: final-owner destruction would attempt to join that worker.

### `Task.adopt`

```fac
public function void adopt(ptr thread handle)
```

- **Returns:** Transfers a handle returned by thread.start into this owner.
- **Ownership:** handle=transferred only when adoption succeeds; on error the caller still owns it and must join/consume it.
- **Errors:** Throws NullPointer (6) for a null handle or Resource (8) if this owner already has a handle.
- **Thread-safety:** Call thread.start(lambda) at the caller site so normal worker-capture checks remain active; serialize all handle operations and never capture this Task in its own worker.

### `Task.isActive`

```fac
public function boolean isActive() { return this.handle != null }
```

- **Returns:** Whether this Task still owns an unconsumed native handle.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Do not race with join or final-owner destruction; never destroy this owner on its own worker.

### `Task.isDone`

```fac
public function boolean isDone()
```

- **Returns:** True when no handle is owned (not yet adopted or already joined), or when the worker has reached a terminal state.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Do not race with join or final-owner destruction.

### `Task.isCancelled`

```fac
public function boolean isCancelled()
```

- **Returns:** Whether the worker observed a cooperative cancellation request and returned normally.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Do not race with join or final-owner destruction.

### `Task.cancel`

```fac
public function boolean cancel()
```

- **Returns:** Whether the worker accepted a cooperative cancellation request.
- **Ownership:** no transferred parameters.
- **Errors:** None.
- **Thread-safety:** Do not race with join or final-owner destruction.

### `Task.join`

```fac
public function void join()
```

- **Returns:** Nothing; consumes the native handle. A repeated join throws Resource (8).
- **Ownership:** consumes this object's native join handle; aliases share the consumed state.
- **Errors:** Re-raises the worker's original FAC error, or Resource (8) for a foreign C++ exception.
- **Thread-safety:** Must be serialized with cancel/status calls and all aliases; never destroy the owner on its own worker.
