# `crypto`

Hashes, HMAC, encodings and OS CSPRNG; TLS transport is provided separately by the optional tls module.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 18 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `crypto.base64Decode(string)` → string | throws `Error` (code 13 Encoding) | args: #1 borrowed; result: owned by caller |
| `crypto.base64Encode(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `crypto.constantTimeEq(string, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed, #2 borrowed |
| `crypto.crc32(string)` → uint | no direct throw site | args: #1 borrowed |
| `crypto.hexDecode(string)` → string | throws `Error` (code 13 Encoding) | args: #1 borrowed; result: owned by caller |
| `crypto.hexEncode(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `crypto.hmacSha256(string, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `crypto.hmacSha512(string, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `crypto.md5(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `crypto.pbkdf2(string, string, int, int)` → string | throws `Error` (code 13 Encoding) | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `crypto.randomBytes(int)` → string | throws `Error` (code 13 Encoding) | result: owned by caller |
| `crypto.randomHex(int)` → string | throws `Error` (code 13 Encoding) | result: owned by caller |
| `crypto.randomInt(long, long)` → long | throws `Error` (code 13 Encoding) |  |
| `crypto.sha1(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `crypto.sha256(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `crypto.sha256File(string)` → string | throws `Error` (code 7 Io) | args: #1 borrowed; result: owned by caller |
| `crypto.sha512(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `crypto.uuid()` → string | throws `Error` (code 13 Encoding) | result: owned by caller |

_Parameter names are not part of the built-in contract; positional types are shown._
