# `debug` (source library)

Source: `stdlib/debug.fac` · `import debug.fac` · release V263

### `DebugPrinter`

```fac
public class DebugPrinter
```

DebugPrinter is intentionally small: it prints explicitly supplied labels and values to stderr. It does not inspect private fields or a call stack.

### `DebugPrinter.dumpInt`

```fac
public function void dumpInt(string label, int value) { terminal.err.println("[debug] ", label, " = ", value) }
```

- **Returns:** Writes a labelled integer to stderr.
- **Ownership:** label=borrowed; value=by value.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `DebugPrinter.dumpLong`

```fac
public function void dumpLong(string label, long value) { terminal.err.println("[debug] ", label, " = ", value) }
```

- **Returns:** Writes a labelled long integer to stderr.
- **Ownership:** label=borrowed; value=by value.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `DebugPrinter.dumpDouble`

```fac
public function void dumpDouble(string label, double value) { terminal.err.println("[debug] ", label, " = ", value) }
```

- **Returns:** Writes a labelled double to stderr.
- **Ownership:** label=borrowed; value=by value.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `DebugPrinter.dumpBoolean`

```fac
public function void dumpBoolean(string label, boolean value) { terminal.err.println("[debug] ", label, " = ", value) }
```

- **Returns:** Writes a labelled boolean to stderr.
- **Ownership:** label=borrowed; value=by value.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `DebugPrinter.dumpString`

```fac
public function void dumpString(string label, string value) { terminal.err.println("[debug] ", label, " = \"", value, "\"") }
```

- **Returns:** Writes a labelled string to stderr.
- **Ownership:** label/value=borrowed immutable strings.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `DebugPrinter.trace`

```fac
public function void trace(string message) { terminal.err.println("[trace] ", message) }
```

- **Returns:** Writes a trace marker to stderr; it does not generate a stack trace.
- **Ownership:** message=borrowed.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.
