# `collections` (source library)

Source: `stdlib/collections.fac` · `import collections.fac` · release V263

### `CollectionOps`

```fac
public class CollectionOps<T>
```

CollectionOps adds generic list algorithms without replacing FAC's native list/array/arraylist/linked/hashmap/hashset/tree/graph/stack/queue/heap types.

### `CollectionOps.indexOf`

```fac
public function int indexOf(list dyn T values, T target)
```

- **Returns:** First matching index, or -1 when absent; O(n).
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None for a normal miss; equality behavior follows T.
- **Thread-safety:** Safe when the input list is not concurrently mutated.

### `CollectionOps.contains`

```fac
public function boolean contains(list dyn T values, T target)
```

- **Returns:** True when at least one element equals target; O(n).
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None for a normal miss.
- **Thread-safety:** Safe when the input list is not concurrently mutated.

### `CollectionOps.count`

```fac
public function int count(list dyn T values, T target)
```

- **Returns:** Number of elements equal to target; O(n).
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None.
- **Thread-safety:** Safe when the input list is not concurrently mutated.

### `CollectionOps.copy`

```fac
public function list dyn T copy(list dyn T values)
```

- **Returns:** An independent shallow copy of values; O(n).
- **Ownership:** values=borrowed (read-only); result=owned list.
- **Errors:** May allocate; allocation failure raises the Runtime error.
- **Thread-safety:** Safe when the input list is not concurrently mutated.

### `CollectionOps.distinct`

```fac
public function list dyn T distinct(list dyn T values)
```

- **Returns:** A new list with duplicate values removed, preserving first occurrence order; O(n²).
- **Ownership:** values=borrowed (read-only); result=owned list.
- **Errors:** May allocate; equality behavior follows T.
- **Thread-safety:** Safe when the input list is not concurrently mutated.

### `CollectionOps.reversed`

```fac
public function list dyn T reversed(list dyn T values)
```

- **Returns:** A new list whose elements appear in reverse order; O(n).
- **Ownership:** values=borrowed (read-only); result=owned list.
- **Errors:** May allocate; allocation failure raises the Runtime error.
- **Thread-safety:** Safe when the input list is not concurrently mutated.
