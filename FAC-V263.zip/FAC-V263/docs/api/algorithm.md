# `algorithm` (source library)

Source: `stdlib/algorithm.fac` · `import algorithm.fac` · release V263

### `Algorithms`

```fac
public class Algorithms<T>
```

Algorithms<T> operates on lists whose elements support equality and ordering. Sort the list with FAC's native sort(list) before binarySearch/lowerBound/upperBound.

### `Algorithms.linearSearch`

```fac
public function int linearSearch(list dyn T values, T target)
```

- **Returns:** First matching position, or -1 when absent; O(n).
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None for a normal miss.
- **Thread-safety:** Safe when the list is not concurrently mutated.

### `Algorithms.binarySearch`

```fac
public function int binarySearch(list dyn T values, T target)
```

- **Returns:** Matching position, or -1 when absent; O(log n). Input must be sorted ascending.
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None for a normal miss; precondition violations may produce an incorrect result.
- **Thread-safety:** Safe when the list is not concurrently mutated.

### `Algorithms.lowerBound`

```fac
public function int lowerBound(list dyn T values, T target)
```

- **Returns:** First index whose value is not less than target; O(log n). Input must be sorted ascending.
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None; result is in [0, size].
- **Thread-safety:** Safe when the list is not concurrently mutated.

### `Algorithms.upperBound`

```fac
public function int upperBound(list dyn T values, T target)
```

- **Returns:** First index whose value is greater than target; O(log n). Input must be sorted ascending.
- **Ownership:** values=borrowed (read-only); target=by value.
- **Errors:** None; result is in [0, size].
- **Thread-safety:** Safe when the list is not concurrently mutated.

### `Algorithms.isSorted`

```fac
public function boolean isSorted(list dyn T values)
```

- **Returns:** True when values are in nondecreasing order; O(n).
- **Ownership:** values=borrowed (read-only).
- **Errors:** None.
- **Thread-safety:** Safe when the list is not concurrently mutated.
