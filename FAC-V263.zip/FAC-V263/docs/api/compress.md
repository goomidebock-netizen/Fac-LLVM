# `compress` (source library)

Source: `stdlib/compress.fac` · `import compress.fac` · release V263

### `rleEncode`

```fac
public function list dyn int rleEncode(list dyn int input)
```

- **Returns:** RLE-encoded bytes as [count,value] pairs; each count is 1..255.
- **Ownership:** input=borrowed (read-only); result=owned list.
- **Errors:** Throws Encoding (13) for a non-byte input; may allocate.
- **Thread-safety:** Safe for a stable input list.

### `rleDecode`

```fac
public function list dyn int rleDecode(list dyn int input, int maxOutputBytes = 16777216)
```

- **Returns:** Decoded byte values from [count,value] pairs.
- **Ownership:** input=borrowed (read-only); result=owned list.
- **Errors:** Throws Encoding (13) for odd input length, zero count, non-byte data or output above limit.
- **Thread-safety:** Safe for a stable input list.
