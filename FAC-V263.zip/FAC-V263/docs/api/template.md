# `template` (source library)

Source: `stdlib/template.fac` · `import template.fac` · release V263

### `TemplateEngine`

```fac
public class TemplateEngine
```

TemplateEngine replaces \{\{name}} placeholders using an explicit string map. Raw rendering is suitable for trusted text; HTML rendering escapes values. There are no loops, includes, expressions, filesystem loads or eval hooks.

### `TemplateEngine.set`

```fac
public function void set(string name, string value)
```

- **Returns:** Stores or replaces a value for a placeholder name.
- **Ownership:** name/value=borrowed; stored values are retained by the map.
- **Errors:** Throws InvalidArgument (4) for empty names or delimiter-containing names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TemplateEngine.has`

```fac
public function boolean has(string name) { return this.values.has(name) }
```

- **Returns:** True when a placeholder value exists.
- **Ownership:** name=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe for a stable engine.

### `TemplateEngine.remove`

```fac
public function void remove(string name) { this.values.remove(name) }
```

- **Returns:** Removes one value; missing names are ignored.
- **Ownership:** name=borrowed.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `TemplateEngine.size`

```fac
public function int size() { return sizeof(this.values) }
```

- **Returns:** Number of stored placeholder values.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable engine.

### `TemplateEngine.render`

```fac
public function string render(string source) { return this.renderInternal(source, false, false) }
```

- **Returns:** Renders \{\{name}} placeholders; missing keys remain unchanged.
- **Ownership:** source=borrowed; result=owned string.
- **Errors:** May allocate; source expressions are never evaluated.
- **Thread-safety:** Safe for a stable engine.

### `TemplateEngine.renderHtml`

```fac
public function string renderHtml(string source) { return this.renderInternal(source, true, false) }
```

- **Returns:** Renders placeholders while HTML-escaping inserted values only.
- **Ownership:** source=borrowed; result=owned string.
- **Errors:** May allocate; this is contextual text escaping, not a sanitizer for URLs/CSS/JS.
- **Thread-safety:** Safe for a stable engine.

### `TemplateEngine.renderStrict`

```fac
public function string renderStrict(string source) { return this.renderInternal(source, false, true) }
```

- **Returns:** Renders placeholders and throws when any referenced key is missing.
- **Ownership:** source=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) for a missing key.
- **Thread-safety:** Safe for a stable engine.

### `TemplateEngine.renderHtmlStrict`

```fac
public function string renderHtmlStrict(string source) { return this.renderInternal(source, true, true) }
```

- **Returns:** Strict rendering with HTML-escaped inserted values.
- **Ownership:** source=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) for a missing key.
- **Thread-safety:** Safe for a stable engine.

### `TemplateEngine.clear`

```fac
public function void clear() { this.values.clear() }
```

- **Returns:** Removes every stored placeholder value.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
