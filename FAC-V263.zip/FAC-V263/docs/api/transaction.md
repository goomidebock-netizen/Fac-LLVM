# `transaction` (source library)

Source: `stdlib/transaction.fac` · `import transaction.fac` · release V263

### `StateTransaction`

```fac
public class StateTransaction
```

StateTransaction stages a batch of StateStore key/value writes and removals. Commit applies the staged operations in order. It is not an ACID/database transaction: there is no isolation, persistence or rollback after partial commit.

### `StateTransaction.setString`

```fac
public function void setString(string key, string value) { this.stage(key, value, false) }
```

- **Returns:** Stages a string value; repeated writes to a key replace its staged operation.
- **Ownership:** key/value=borrowed; transaction retains copies.
- **Errors:** Throws InvalidArgument (4) when inactive or key is invalid.
- **Thread-safety:** Not thread-safe.

### `StateTransaction.remove`

```fac
public function void remove(string key) { this.stage(key, "", true) }
```

- **Returns:** Stages removal of a key; repeated operations on the key replace earlier ones.
- **Ownership:** key=borrowed.
- **Errors:** Throws InvalidArgument (4) when inactive or key is invalid.
- **Thread-safety:** Not thread-safe.

### `StateTransaction.getString`

```fac
public function string getString(string key, string fallback = "")
```

- **Returns:** Reads staged value/removal first, otherwise the current target value.
- **Ownership:** key/fallback=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) when inactive.
- **Thread-safety:** Not isolated from external target mutation.

### `StateTransaction.size`

```fac
public function int size() { return sizeof(this.stagedKeys) }
```

- **Returns:** Number of distinct staged keys.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable transaction.

### `StateTransaction.isActive`

```fac
public function boolean isActive() { return this.active }
```

- **Returns:** True while more operations can be staged or committed.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable transaction.

### `StateTransaction.commit`

```fac
public function void commit()
```

- **Returns:** Applies staged operations in insertion order and closes the transaction.
- **Ownership:** target is mutated; staged data remains owned by this object until destruction.
- **Errors:** Throws InvalidArgument (4) when inactive; target/runtime failures may interrupt application.
- **Thread-safety:** Not atomic with concurrent readers/writers; synchronize externally.

### `StateTransaction.rollback`

```fac
public function void rollback()
```

- **Returns:** Discards staged operations and closes the transaction without changing the target.
- **Ownership:** no parameters.
- **Errors:** Throws InvalidArgument (4) when already inactive.
- **Thread-safety:** Not thread-safe.
