# `simd`

Two-lane float64 CPU SIMD bulk operations over CPU-backed numeric buffers, with scalar fallback and transactional output.

- Status: **experimental**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 8 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `simd.addF64x2(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Adds an even number of little-endian float64 elements in two-lane vectors; buffers are gpu buffers and false leaves destination unchanged. |
| `simd.backend()` → string | no direct throw site | result: owned by caller; CPU float64 SIMD backend name: x86-sse2, arm-advanced-simd, compiler-vector-128 or scalar-fallback. |
| `simd.divF64x2(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Divides an even number of little-endian float64 elements in two-lane vectors; zero divisors or non-finite output return false without writes. |
| `simd.mulF64x2(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Multiplies an even number of little-endian float64 elements in two-lane vectors; false leaves destination unchanged. |
| `simd.nativeF64x2()` → boolean | predicate (never throws on a normal miss) | True when this compiler build has a native 128-bit float64 vector path; scalar fallback remains correct otherwise. |
| `simd.scaleF64x2(handle, handle, long, double)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle; Scales an even number of little-endian float64 elements in two-lane vectors; false leaves destination unchanged. |
| `simd.subF64x2(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Subtracts an even number of little-endian float64 elements in two-lane vectors; false leaves destination unchanged. |
| `simd.widthF64()` → int | no direct throw site | Logical float64 vector width; this API processes two float64 lanes per vector. |

_Parameter names are not part of the built-in contract; positional types are shown._
