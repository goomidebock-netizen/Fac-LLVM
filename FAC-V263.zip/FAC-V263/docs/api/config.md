# `config` (source library)

Source: `stdlib/config.fac` · `import config.fac` · release V263

### `Config`

```fac
public class Config
```

Config reads a deliberately small INI format. Section/key pairs are stored internally as flattened "section.key" entries; save() writes normalized INI.

### `Config.has`

```fac
public function boolean has(string section, string key) { return this.entries.has(this.makeKey(section, key)) }
```

- **Returns:** True when a section/key pair exists.
- **Ownership:** section/key=borrowed.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.getString`

```fac
public function string getString(string section, string key, string fallback = "")
```

- **Returns:** Stored text or fallback when the key is missing.
- **Ownership:** section/key/fallback=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.getInt`

```fac
public function int getInt(string section, string key, int fallback = 0)
```

- **Returns:** Parsed integer or fallback when missing/invalid.
- **Ownership:** section/key=borrowed; fallback=result by value.
- **Errors:** None; invalid numeric text returns fallback.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.getBoolean`

```fac
public function boolean getBoolean(string section, string key, boolean fallback = false)
```

- **Returns:** Parsed boolean or fallback when missing/invalid. Accepted values: true/false, 1/0, yes/no, on/off.
- **Ownership:** section/key=borrowed; fallback=result by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.set`

```fac
public function void set(string section, string key, string value)
```

- **Returns:** Stores or replaces a value. Section may be empty for a root key.
- **Ownership:** section/key/value=borrowed.
- **Errors:** Throws InvalidArgument (4) for an empty key or delimiters that cannot be represented by this format.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.remove`

```fac
public function void remove(string section, string key) { this.entries.remove(this.makeKey(section, key)) }
```

- **Returns:** Removes a key when present; missing keys are ignored.
- **Ownership:** section/key=borrowed.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.clear`

```fac
public function void clear() { this.entries.clear() }
```

- **Returns:** Removes every entry.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.size`

```fac
public function int size() { return sizeof(this.entries) }
```

- **Returns:** Number of stored key/value pairs.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `Config.keys`

```fac
public function list dyn string keys() { return this.entries.keys() }
```

- **Returns:** A copy of all flattened keys; order is unspecified.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable object.

### `Config.parse`

```fac
public function boolean parse(string text)
```

- **Returns:** Parses comments, [section] headers and key=value lines. Duplicate keys use the last value.
- **Ownership:** text=borrowed; stored keys/values=owned by this object.
- **Errors:** Returns false for malformed lines; the entries parsed before the failure remain stored.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.load`

```fac
public function boolean load(string path)
```

- **Returns:** Reads and parses a UTF-8 text file; false for an I/O or parse failure.
- **Ownership:** path=borrowed; parsed values=owned by this object.
- **Errors:** File read errors are caught and reported as false.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Config.toText`

```fac
public function string toText()
```

- **Returns:** Normalized INI text with section headers reconstructed; key/section order is unspecified.
- **Ownership:** result=owned string.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable object.

### `Config.save`

```fac
public function void save(string path) { file.writeAll(path, this.toText()) }
```

- **Returns:** Writes normalized key=value text to path.
- **Ownership:** path=borrowed; serialized text is temporary owned data.
- **Errors:** Throws Io (7) when the destination cannot be written.
- **Thread-safety:** Not thread-safe when shared mutably.
