# `path`

Path string manipulation and filesystem queries.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 16 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `path.absolute(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `path.changeExtension(string, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller; Changes only the final filename extension; an extension without a leading dot receives one. A leading dot in a filename such as .config is not treated as an existing extension; a path ending in a separator is returned unchanged. |
| `path.componentCount(string)` → int | no direct throw site | args: #1 borrowed; Counts non-empty path components separated by slash or backslash. Repeated separators are ignored; dot and dot-dot components are counted; root separators are not counted. |
| `path.exists(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed; also: `file.exists` |
| `path.ext(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `path.isAbsolute(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed |
| `path.isDir(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed |
| `path.isFile(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed; also: `file.isFile` |
| `path.isSymlink(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed; Checks the directory entry itself without following the link. Returns false for missing or inaccessible paths; use exists separately when target existence matters. |
| `path.join(string, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `path.list(string)` → list<string> | throws `Error` (code 7 Io) | args: #1 borrowed; result: owned by caller |
| `path.name(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `path.normalize(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `path.parent(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `path.stem(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `path.withName(string, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller; Replaces the final path component. If the input ends in a path separator, the new name is appended as a child. Existing slash or backslash style is preserved. |

_Parameter names are not part of the built-in contract; positional types are shown._
