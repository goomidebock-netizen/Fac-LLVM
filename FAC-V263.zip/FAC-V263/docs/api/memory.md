# `memory`

Raw memory helpers, weak references, tracking counters.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 21 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `memory.collectCycles()` → ulong | throws `Error` (code ) |  |
| `memory.compare(handle, handle, long)` → int | throws `Error` (code 6 NullPointer) + OOM | args: #1 borrowed-handle, #2 borrowed-handle |
| `memory.copy(handle, handle, long)` → void | throws `Error` (code 6 NullPointer) + OOM | args: #1 borrowed-handle, #2 borrowed-handle |
| `memory.liveObjects()` → ulong | no direct throw site |  |
| `memory.resetPeak()` → void | no direct throw site |  |
| `memory.runtimeStackBytes()` → ulong | no direct throw site |  |
| `memory.runtimeStackPeakBytes()` → ulong | no direct throw site |  |
| `memory.set(handle, int, long)` → void | throws `Error` (code 6 NullPointer) + OOM | args: #1 borrowed-handle |
| `memory.sizeof(Type)` → long | see note |  |
| `memory.startTracking()` → void | no direct throw site |  |
| `memory.trackedAllocs()` → ulong | no direct throw site |  |
| `memory.trackedBlocks()` → ulong | no direct throw site |  |
| `memory.trackedPeak()` → ulong | no direct throw site |  |
| `memory.trackedReallocs()` → ulong | no direct throw site |  |
| `memory.trackedReserved()` → ulong | no direct throw site | Reports tracked live payload bytes plus the reserved storage of the flat allocation-tracking index; excludes libc allocator metadata and process RSS. Tracking starts only for allocations made after memory.startTracking(). |
| `memory.trackedUsed()` → ulong | no direct throw site |  |
| `memory.trimThread()` → boolean | boolean status flag (`false` = failed, no detail) |  |
| `memory.weak(obj)` → weak handle | see note | Non-owning. |
| `memory.weakAlive(weak)` → boolean | see note |  |
| `memory.weakLock(weak)` → obj or null | see note | Returns a strong reference when still alive. |
| `memory.zero(handle, long)` → void | throws `Error` (code 8 Resource) | args: #1 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
