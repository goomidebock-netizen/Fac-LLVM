# `tilemap` (source library)

Source: `stdlib/tilemap.fac` · `import tilemap.fac` · release V263

### `Tilemap.inside`

```fac
public function boolean inside(int c, int r) { return c >= 0 && r >= 0 && c < this.cols && r < this.rows }
```

- **Returns:** boolean by value.
- **Ownership:** c=by value; r=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.get`

```fac
public function int get(int c, int r)
```

นอกแผนที่ = 0 (ว่าง)

- **Returns:** int by value.
- **Ownership:** c=by value; r=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.set`

```fac
public function void set(int c, int r, int id)
```

- **Returns:** Nothing.
- **Ownership:** c=by value; r=by value; id=by value
- **Errors:** Can throw: explicit throw Error (code 2, 3).
- **Thread-safety:** Not thread-safe: mutates the Tilemap receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.fill`

```fac
public function void fill(int id)
```

- **Returns:** Nothing.
- **Ownership:** id=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Tilemap receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.fillRect`

```fac
public function void fillRect(int c, int r, int w, int h, int id)
```

- **Returns:** Nothing.
- **Ownership:** c=by value; r=by value; w=by value; h=by value; id=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Tilemap receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.widthPx`

```fac
public function double widthPx() { return cast(Double, this.cols) * cast(Double, this.tileSize) }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.heightPx`

```fac
public function double heightPx() { return cast(Double, this.rows) * cast(Double, this.tileSize) }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.clear`

```fac
public function void clear()
```

- **Returns:** Nothing; sets every tile to the empty id 0.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Tilemap receiver; synchronize externally.

### `Tilemap.occupiedCount`

```fac
public function int occupiedCount()
```

- **Returns:** Number of cells whose tile id is non-zero.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.

### `Tilemap.setSolid`

```fac
public function void setSolid(int id, boolean solid)
```

- **Returns:** Nothing.
- **Ownership:** id=by value; solid=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.isSolidId`

```fac
public function boolean isSolidId(int id)
```

- **Returns:** boolean by value.
- **Ownership:** id=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.solidAt`

```fac
public function boolean solidAt(int c, int r)
```

ไทล์ตัน? นอกแผนที่นับเป็นตัน (กันตัวละครหลุดออกนอกโลก)

- **Returns:** boolean by value.
- **Ownership:** c=by value; r=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.colAt`

```fac
public function int colAt(double x) { return this.tileOf(x) }
```

- **Returns:** int by value.
- **Ownership:** x=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.rowAt`

```fac
public function int rowAt(double y) { return this.tileOf(y) }
```

- **Returns:** int by value.
- **Ownership:** y=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.hitsSolid`

```fac
public function boolean hitsSolid(double x, double y, double w, double h)
```

สี่เหลี่ยม (x, y, w, h) ซ้อนกับไทล์ตันใดๆ หรือไม่ (ซ้อนจริง: แตะขอบเฉยๆ ไม่นับ)

- **Returns:** boolean by value.
- **Ownership:** x=by value; y=by value; w=by value; h=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.move`

```fac
public function (double, double) move(double x, double y, double w, double h, double dx, double dy)
```

เคลื่อนสี่เหลี่ยม (x, y, w, h) ไป (dx, dy) แล้วถูกกำแพงกั้น: คืน (x', y') ใหม่ แยกแกน X แล้วค่อย Y (เดินเลียกำแพงได้), แบ่งเป็นก้าวย่อยไม่เกินครึ่งไทล์ จึงไม่ทะลุกำแพงบางแม้ dx/dy ใหญ่ ชนกำแพง -> ชิดผิวกำแพงพอดี (ไม่ทิ้งช่องว่าง) ; ตัวละครเริ่มซ้อนกำแพงอยู่แล้วจะเคลื่อนไม่ได้ในแกนที่ติด

- **Returns:** Tuple (double,double) by value.
- **Ownership:** x=by value; y=by value; w=by value; h=by value; dx=by value; dy=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tilemap.draw`

```fac
public function void draw(ptr graphic dst, ptr graphic atlas, int atlasCols, int camX, int camY)
```

วาดส่วนที่มองเห็นลง dst โดยมุมซ้ายบนของจอ = พิกัดโลก (camX, camY) (พิกเซลจำนวนเต็ม เพื่อไม่ให้ภาพสั่น) atlas = ภาพ tileset ที่ช่องขนาด tileSize x tileSize เรียงเป็น atlasCols คอลัมน์; ไทล์ที่ id เกินขนาด atlas จะถูกข้าม

- **Returns:** Nothing.
- **Ownership:** dst=non-owning handle, not freed here; atlas=non-owning handle, not freed here; atlasCols=by value; camX=by value; camY=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Read-only on the Tilemap receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
