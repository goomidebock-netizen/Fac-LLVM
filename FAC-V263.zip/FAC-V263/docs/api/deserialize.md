# `deserialize` (source library)

Source: `stdlib/deserialize.fac` · `import deserialize.fac` · release V263

### `BinaryReader`

```fac
public class BinaryReader
```

### `BinaryReader.fromFrozenBuffer`

```fac
public static function obj BinaryReader fromFrozenBuffer(obj ByteBuffer source)
```

- **Returns:** Creates a reader that shares an immutable frozen ByteBuffer without copying its bytes.
- **Ownership:** source=shared immutable; the reader retains the buffer for its full lifetime.
- **Errors:** InvalidArgument (4) unless source is non-null and frozen; Resource (8) above 64 MiB.
- **Thread-safety:** Safe for stable frozen input; reader cursor itself is not thread-safe.

### `BinaryReader.isFailed`

```fac
public function boolean isFailed() { return this.failed }
```

- **Returns:** True after malformed input or a failed integrity/schema validation has poisoned this reader. A failed reader cannot be reused.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable reader.

### `BinaryReader.readHeader`

```fac
public function int readHeader(string expectedSchema)
```

- **Returns:** Reads and validates the FACB v1 header and exact expected schema identifier.
- **Ownership:** expectedSchema=borrowed.
- **Errors:** Throws Encoding (13) for invalid magic/version/flags/schema; Resource (8) for oversized input.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readHeaderV2`

```fac
public function int readHeaderV2(string expectedSchema, int minSchemaVersion = 1, int maxSchemaVersion = 65535)
```

- **Returns:** Validates a FACB v2 stream, CRC32, schema identifier and accepted schema-version range.
- **Ownership:** expectedSchema=borrowed.
- **Errors:** Throws Encoding (13) for checksum/header/schema/version failures; InvalidArgument (4) for an invalid range. Any data error poisons the reader; create a new reader to retry.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.beginRecord`

```fac
public function int beginRecord(string expectedType, int maxFields = 65535)
```

- **Returns:** Opens a named record and returns the declared number of fields.
- **Ownership:** expectedType=borrowed.
- **Errors:** Throws Encoding (13) for marker/type mismatch or malformed count; InvalidArgument (4) for nested/invalid calls. Impossible counts are rejected using the minimum encoded field size.
- **Thread-safety:** Not thread-safe. Nested records are not supported.

### `BinaryReader.endRecord`

```fac
public function void endRecord()
```

- **Returns:** Completes the active record after every declared field has been read.
- **Ownership:** no parameters.
- **Errors:** Throws Encoding (13) when fields remain; InvalidArgument (4) with no active record.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.skipField`

```fac
public function string skipField()
```

- **Returns:** Reads the next field's name and skips its validated payload, for forward-compatible optional fields.
- **Ownership:** result=owned string.
- **Errors:** Throws Encoding (13) for unknown types, invalid booleans or malformed/truncated payloads.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldByte`

```fac
public function int readFieldByte(string name) { this.beginRecordField(name, 1); var int value = this.readByte(); this.endRecordField(); return value }
```

- **Returns:** Reads a named byte record field.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or malformed value.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldBoolean`

```fac
public function boolean readFieldBoolean(string name) { this.beginRecordField(name, 2); var boolean value = this.readBoolean(); this.endRecordField(); return value }
```

- **Returns:** Reads a named boolean record field.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or malformed boolean.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldI32`

```fac
public function int readFieldI32(string name) { this.beginRecordField(name, 3); var int value = this.readI32(); this.endRecordField(); return value }
```

- **Returns:** Reads a named signed Int32 record field.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch; IntegerOverflow is not applicable to decoding bits.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldI64`

```fac
public function long readFieldI64(string name) { this.beginRecordField(name, 4); var long value = this.readI64(); this.endRecordField(); return value }
```

- **Returns:** Reads a named signed Int64 record field.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldI64FromI32`

```fac
public function long readFieldI64FromI32(string name)
```

- **Returns:** Reads a legacy Int32 field and widens it losslessly to Int64.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldI32FromI64`

```fac
public function int readFieldI32FromI64(string name)
```

- **Returns:** Reads a legacy Int64 field and narrows it to Int32 only when in range.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or truncation; IntegerOverflow (17) when outside Int32 range.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldF32`

```fac
public function float readFieldF32(string name) { this.beginRecordField(name, 5); var float value = this.readF32(); this.endRecordField(); return value }
```

- **Returns:** Reads a named IEEE-754 binary32 record field.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldF64`

```fac
public function double readFieldF64(string name) { this.beginRecordField(name, 6); var double value = this.readF64(); this.endRecordField(); return value }
```

- **Returns:** Reads a named IEEE-754 binary64 record field.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** Throws Encoding (13) on field name/type mismatch or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldString`

```fac
public function string readFieldString(string name) { this.beginRecordField(name, 7); dyn string value = this.readString(); this.endRecordField(); return value }
```

- **Returns:** Reads a named UTF-8 string record field.
- **Ownership:** name=borrowed; result=owned string.
- **Errors:** Throws Encoding (13) on field name/type mismatch, malformed UTF-8 or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldBytes`

```fac
public function list dyn int readFieldBytes(string name) { this.beginRecordField(name, 8); list dyn int value = this.readBytes(); this.endRecordField(); return value }
```

- **Returns:** Reads a named byte-list record field.
- **Ownership:** name=borrowed; result=owned byte list.
- **Errors:** Throws Encoding (13) on field name/type mismatch or malformed payload.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldByteView`

```fac
public function obj ByteView readFieldByteView(string name)
```

- **Returns:** Reads a named byte field as a zero-copy immutable view.
- **Ownership:** name=borrowed; result=shared view retaining the reader's frozen backing buffer.
- **Errors:** Throws Encoding (13) on field mismatch or malformed length; Resource (8) above stream cap.
- **Thread-safety:** Safe for a stable view; reader cursor is not thread-safe.

### `BinaryReader.readFieldI32List`

```fac
public function list dyn int readFieldI32List(string name, int maxCount = 1048576)
```

- **Returns:** Reads a named Int32 list record field.
- **Ownership:** name=borrowed; result=owned list.
- **Errors:** Throws Encoding (13) on field name/type mismatch or invalid count/payload.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldStringList`

```fac
public function list dyn string readFieldStringList(string name, int maxCount = 1048576)
```

- **Returns:** Reads a named UTF-8 string-list record field.
- **Ownership:** name=borrowed; result=owned list.
- **Errors:** Throws Encoding (13) on field name/type mismatch or invalid count/payload.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readFieldStringMap`

```fac
public function hashmap dyn string, string readFieldStringMap(string name, int maxCount = 262144)
```

- **Returns:** Reads a named string-to-string map record field.
- **Ownership:** name=borrowed; result=owned hashmap.
- **Errors:** Throws Encoding (13) on field name/type mismatch, duplicate keys or invalid count/payload.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readByte`

```fac
public function int readByte()
```

- **Returns:** Reads one unsigned byte.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when input is truncated or malformed.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readBoolean`

```fac
public function boolean readBoolean()
```

- **Returns:** Reads a boolean encoded as exactly 0 or 1.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) for truncation or any value other than 0/1.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readU16`

```fac
public function int readU16()
```

- **Returns:** Reads an unsigned 16-bit integer in little-endian order.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when input is truncated.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readU32`

```fac
public function long readU32()
```

- **Returns:** Reads an unsigned 32-bit integer as a non-negative long, little-endian.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when input is truncated.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readI32`

```fac
public function int readI32()
```

- **Returns:** Reads a signed 32-bit integer from a two's-complement little-endian field.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when input is truncated.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readI64`

```fac
public function long readI64()
```

- **Returns:** Reads a signed 64-bit little-endian value, preserving its two's-complement bit pattern.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when input is truncated.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readF32`

```fac
public function float readF32()
```

- **Returns:** Reads an IEEE-754 binary32 value from a little-endian field.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when truncated; NaN payloads are canonicalized by writers.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readF64`

```fac
public function double readF64()
```

- **Returns:** Reads an IEEE-754 binary64 value from a little-endian field.
- **Ownership:** result=by value.
- **Errors:** Throws Encoding (13) when truncated.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readRawBytes`

```fac
public function list dyn int readRawBytes(int count)
```

- **Returns:** Reads exactly count raw bytes without a length prefix.
- **Ownership:** result=owned byte list.
- **Errors:** Throws InvalidArgument (4) outside 0..16 MiB; Encoding (13) when truncated.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readRawByteView`

```fac
public function obj ByteView readRawByteView(int count)
```

- **Returns:** Reads exactly count bytes as a zero-copy immutable view over the reader's frozen backing buffer.
- **Ownership:** result=shared read-only view; the view retains the backing buffer and outlives the reader variable.
- **Errors:** InvalidArgument (4) outside 0..16 MiB; Encoding (13) when truncated.
- **Thread-safety:** Safe for a stable view; reader cursor is not thread-safe.

### `BinaryReader.readByteView`

```fac
public function obj ByteView readByteView()
```

- **Returns:** Reads a length-prefixed byte field as a zero-copy immutable view.
- **Ownership:** result=shared read-only view; backing storage is retained without copying payload bytes.
- **Errors:** Encoding (13) for malformed length or truncation.
- **Thread-safety:** Safe for a stable view; reader cursor is not thread-safe.

### `BinaryReader.readBytes`

```fac
public function list dyn int readBytes()
```

- **Returns:** Reads a length-prefixed byte list (U32 length, then bytes).
- **Ownership:** result=owned byte list.
- **Errors:** Throws Encoding (13) for a malformed length or truncation; Resource (8) for oversized total input.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readI32List`

```fac
public function list dyn int readI32List(int maxCount = 1048576)
```

- **Returns:** Reads a count-prefixed Int32 list with a caller-configurable element cap.
- **Ownership:** result=owned list.
- **Errors:** Throws Encoding (13) for malformed/oversized count or truncation before allocation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readStringList`

```fac
public function list dyn string readStringList(int maxCount = 1048576)
```

- **Returns:** Reads a count-prefixed UTF-8 string list with a caller-configurable element cap.
- **Ownership:** result=owned list.
- **Errors:** Throws Encoding (13) for malformed/oversized count, invalid UTF-8 or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readStringMap`

```fac
public function hashmap dyn string, string readStringMap(int maxCount = 262144)
```

- **Returns:** Reads a count-prefixed string map; duplicate keys are rejected.
- **Ownership:** result=owned hashmap.
- **Errors:** Throws Encoding (13) for malformed/oversized count, duplicate keys, invalid UTF-8 or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.readString`

```fac
public function string readString()
```

- **Returns:** Reads a length-prefixed UTF-8 string; invalid UTF-8 is rejected.
- **Ownership:** result=owned string.
- **Errors:** Throws Encoding (13) for invalid UTF-8, malformed length or truncation.
- **Thread-safety:** Not thread-safe.

### `BinaryReader.remaining`

```fac
public function int remaining() { return this.dataEnd - this.cursor }
```

- **Returns:** Number of unread bytes remaining in the stream.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable reader.

### `BinaryReader.position`

```fac
public function int position() { return this.cursor }
```

- **Returns:** Current zero-based byte offset into the stream.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable reader.

### `BinaryReader.isAtEnd`

```fac
public function boolean isAtEnd() { return this.cursor == this.dataEnd }
```

- **Returns:** True when all bytes have been consumed.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable reader.

### `BinaryReader.requireEnd`

```fac
public function void requireEnd()
```

- **Returns:** Verifies that no trailing or unconsumed bytes remain.
- **Ownership:** no parameters.
- **Errors:** Throws Encoding (13) when trailing data remains.
- **Thread-safety:** Not thread-safe.
