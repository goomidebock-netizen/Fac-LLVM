# `theme` (source library)

Source: `stdlib/theme.fac` · `import theme.fac` · release V263

### `Theme.setDark`

```fac
public function void setDark()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Theme receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Theme.setLight`

```fac
public function void setLight()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Theme receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Theme.setAccent`

```fac
public function void setAccent(int r, int g, int b)
```

- **Returns:** Nothing.
- **Ownership:** r=by value; g=by value; b=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Theme receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Theme.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled) { this.reduceMotion = enabled }
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Theme receiver; synchronize externally.
