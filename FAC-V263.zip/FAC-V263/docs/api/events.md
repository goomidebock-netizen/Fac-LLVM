# `events` (source library)

Source: `stdlib/events.fac` · `import events.fac` · release V263

### `EventQueue`

```fac
public class EventQueue
```

EventQueue provides a FIFO event log for polling consumers. It deliberately does not claim callback-based dispatch: current FAC module APIs do not expose a stable general-purpose callable/factory storage contract.

### `EventQueue.publish`

```fac
public function void publish(string topic, string payload)
```

- **Returns:** Appends one named event and its opaque text payload.
- **Ownership:** topic/payload=borrowed; queue retains copies.
- **Errors:** Throws InvalidArgument (4) when topic is empty.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `EventQueue.size`

```fac
public function int size() { return sizeof(this.topics) }
```

- **Returns:** Number of pending events.
- **Ownership:** no parameters; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue; not safe during concurrent mutation.

### `EventQueue.hasNext`

```fac
public function boolean hasNext() { return sizeof(this.topics) > 0 }
```

- **Returns:** True when at least one event is pending.
- **Ownership:** no parameters; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable queue; not safe during concurrent mutation.

### `EventQueue.peekTopic`

```fac
public function string peekTopic()
```

- **Returns:** The next event topic without removing the event.
- **Ownership:** result=owned string.
- **Errors:** Throws InvalidArgument (4) when the queue is empty.
- **Thread-safety:** Not thread-safe when shared mutably.

### `EventQueue.peekPayload`

```fac
public function string peekPayload()
```

- **Returns:** The next event payload without removing the event.
- **Ownership:** result=owned string.
- **Errors:** Throws InvalidArgument (4) when the queue is empty.
- **Thread-safety:** Not thread-safe when shared mutably.

### `EventQueue.consume`

```fac
public function void consume()
```

- **Returns:** Removes the next event after the consumer has inspected it.
- **Ownership:** no parameters.
- **Errors:** Throws InvalidArgument (4) when the queue is empty.
- **Thread-safety:** Not thread-safe when shared mutably.

### `EventQueue.clear`

```fac
public function void clear()
```

- **Returns:** Removes all pending events.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
