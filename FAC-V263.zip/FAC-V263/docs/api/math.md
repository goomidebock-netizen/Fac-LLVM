# `math`

Scalar/vector math, constants, mat4 helpers.

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 46 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `math.E`: double | see note |  |
| `math.INF`: double | see note |  |
| `math.NAN`: double | see note |  |
| `math.PI`: double | see note |  |
| `math.TAU`: double | see note |  |
| `math.abs(number)` → same numeric type | see note |  |
| `math.acos(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.asin(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.atan(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.atan2(double, double)` → double | IEEE-754 (NaN/inf) |  |
| `math.cbrt(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.ceil(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.clamp(double, double, double)` → double | no direct throw site |  |
| `math.cos(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.cosh(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.deg(double)` → double | no direct throw site |  |
| `math.degToRad(double)` → double | no direct throw site | Converts degrees to radians. |
| `math.exp(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.floor(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.fmod(double, double)` → double | IEEE-754 (NaN/inf) |  |
| `math.gcd(long, long)` → long | throws `Error` (code 8 Resource) |  |
| `math.hypot(double, double)` → double | IEEE-754 (NaN/inf) |  |
| `math.isFinite(double)` → boolean | predicate (never throws on a normal miss) | Returns true for finite numbers and false for NaN or positive/negative infinity. |
| `math.isInf(double)` → boolean | predicate (never throws on a normal miss) |  |
| `math.isNaN(double)` → boolean | predicate (never throws on a normal miss) |  |
| `math.lcm(long, long)` → long | throws `Error` (code 8 Resource) |  |
| `math.lerp(double, double, double)` → double | no direct throw site |  |
| `math.log(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.log10(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.log2(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.max(number, number)` → common numeric type | see note |  |
| `math.min(number, number)` → common numeric type | see note |  |
| `math.mod(long, long)` → long | throws `Error` (code 3 DivisionByZero) |  |
| `math.pow(double, double)` → double | IEEE-754 (NaN/inf) |  |
| `math.rad(double)` → double | no direct throw site |  |
| `math.radToDeg(double)` → double | no direct throw site | Converts radians to degrees. |
| `math.round(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.sign(double)` → int | no direct throw site |  |
| `math.sin(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.sinh(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.smoothstep(double, double, double)` → double | throws `Error` (code 18 Math) | Smoothstep interpolation with clamped normalized t; requires finite edges with edge1 > edge0. |
| `math.sqrt(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.tan(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.tanh(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.trunc(double)` → double | IEEE-754 (NaN/inf) |  |
| `math.wrap(double, double, double)` → double | throws `Error` (code 18 Math) | Wraps x into [min,max); requires finite bounds with max > min. |

_Parameter names are not part of the built-in contract; positional types are shown._
