# `rpc` (source library)

Source: `stdlib/rpc.fac` · `import rpc.fac` · release V263

### `JsonRpcCodec`

```fac
public class JsonRpcCodec
```

JsonRpcCodec constructs and inspects JSON-RPC 2.0 envelopes. It is a codec, not a transport, dispatcher, authentication system or callback registry.

### `JsonRpcCodec.request`

```fac
public function string request(string idJson, string method, string paramsJson = "[]")
```

- **Returns:** Builds a JSON-RPC 2.0 request; paramsJson must be a JSON object or array.
- **Ownership:** idJson/method/paramsJson=borrowed; result=owned JSON string.
- **Errors:** Throws Json (10) for invalid id/params or InvalidArgument (4) for invalid method.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.notification`

```fac
public function string notification(string method, string paramsJson = "[]")
```

- **Returns:** Builds a JSON-RPC notification without an id.
- **Ownership:** method/paramsJson=borrowed; result=owned JSON string.
- **Errors:** Throws Json (10) for invalid params and InvalidArgument (4) for invalid method.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.success`

```fac
public function string success(string idJson, string resultJson)
```

- **Returns:** Builds a JSON-RPC success response; resultJson may be any valid JSON value.
- **Ownership:** idJson/resultJson=borrowed; result=owned JSON string.
- **Errors:** Throws Json (10) for invalid JSON/id.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.failure`

```fac
public function string failure(string idJson, int code, string message)
```

- **Returns:** Builds a JSON-RPC error response with the supplied numeric code and message.
- **Ownership:** idJson/message=borrowed; result=owned JSON string.
- **Errors:** Throws Json (10) for invalid id and InvalidArgument (4) for empty message.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.isRequest`

```fac
public function boolean isRequest(string input)
```

- **Returns:** True when input is a valid JSON object with jsonrpc="2.0" and a string method.
- **Ownership:** input=borrowed.
- **Errors:** False for malformed or non-request messages.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.isResponse`

```fac
public function boolean isResponse(string input)
```

- **Returns:** True when input is a valid JSON-RPC response with exactly one of result/error.
- **Ownership:** input=borrowed.
- **Errors:** False for malformed or non-response messages.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.method`

```fac
public function string method(string input)
```

- **Returns:** Method name from a valid JSON-RPC request.
- **Ownership:** input=borrowed; result=owned string.
- **Errors:** Throws Json (10) for malformed/non-request input.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.

### `JsonRpcCodec.responseId`

```fac
public function string responseId(string input)
```

- **Returns:** Compact JSON text for the id member of a valid JSON-RPC response.
- **Ownership:** input=borrowed; result=owned string.
- **Errors:** Throws Json (10) for malformed/non-response input.
- **Thread-safety:** Safe-pure apart from temporary JSON allocations.
