# `net`

TCP sockets and simple HTTP.

- Status: **stable**
- Thread-safety: **serialized per opaque handle (do not race managed close/destruction)**
- Entries: 21 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `net.accept(handle)` → handle | throws `Error` (code 11 Network) + OOM | args: #1 borrowed-handle; result: owned by caller (release with `net.close`); Returns an opaque Runtime socket token, not a native socket descriptor. Operations on one handle are synchronized and close waits for active I/O; stale aliases fail with Network (11). |
| `net.close(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: closes and frees the socket; Closes the socket once and waits for already-started I/O to finish. Repeated close is harmless. New operations through stale/closed aliases fail with Network (11). After a successful TLS wrap, the original socket token is retired because TLS owns the connection. |
| `net.connect(string, int)` → handle | throws `Error` (code 11 Network) + OOM | args: #1 borrowed; result: owned by caller (release with `net.close`); Returns an opaque Runtime socket token, not a native socket descriptor. Operations on one handle are synchronized: reads, writes and socket options use separate locks so TCP full-duplex read/write is supported. Closing waits for active I/O; stale aliases fail with Network (11). |
| `net.get(string)` → string | throws `Error` (code 11 Network) + OOM | **deprecated** of `net.httpGet` (remove ≥ V47); args: #1 borrowed; result: owned by caller |
| `net.httpGet(string)` → string | throws `Error` (code 11 Network) + OOM | args: #1 borrowed; result: owned by caller; Uses cleartext HTTP only; HTTPS is not supported. Returns the response body and rejects HTTP status codes >= 400. Enforces a 64 MiB response cap; validates HTTP/1.0 and HTTP/1.1 status lines and headers, exact Content-Length framing, and chunked framing including the terminal zero chunk and trailers. Accepts matching duplicate Content-Length headers, rejects conflicting or simultaneous Transfer-Encoding and Content-Length, ignores informational responses except unsupported 101 upgrades, supports query-only request targets and removes URL fragments before sending.; also: `net.get` |
| `net.httpPost(string, string)` → string | throws `Error` (code 11 Network) + OOM | args: #1 borrowed, #2 borrowed; result: owned by caller; Uses cleartext HTTP only; HTTPS is not supported. Returns the response body and rejects HTTP status codes >= 400. Enforces a 64 MiB response cap; validates HTTP/1.0 and HTTP/1.1 status lines and headers, exact Content-Length framing, and chunked framing including the terminal zero chunk and trailers. Accepts matching duplicate Content-Length headers, rejects conflicting or simultaneous Transfer-Encoding and Content-Length, ignores informational responses except unsupported 101 upgrades, supports query-only request targets and removes URL fragments before sending.; also: `net.post` |
| `net.listen(int)` → handle | throws `Error` (code 11 Network) + OOM | result: owned by caller (release with `net.close`); Returns an opaque Runtime socket token, not a native socket descriptor. Operations on one handle are synchronized and close waits for active I/O; stale aliases fail with Network (11). |
| `net.localPort(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `net.post(string, string)` → string | throws `Error` (code 11 Network) + OOM | **deprecated** of `net.httpPost` (remove ≥ V47); args: #1 borrowed, #2 borrowed; result: owned by caller |
| `net.recv(handle, int)` → string | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller |
| `net.recvAll(handle)` → string | throws `Error` (code 11 Network) + OOM | args: #1 borrowed-handle; result: owned by caller |
| `net.recvExact(handle, int)` → string | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller |
| `net.recvExactBytes(handle, int)` → list<int> | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller; Reads exactly count bytes or throws on timeout/EOF, returning an owned list dyn int. Count is limited to 16 MiB. |
| `net.recvLine(handle)` → string | throws `Error` (code 11 Network) | args: #1 borrowed-handle; result: owned by caller |
| `net.recvLineStrict(handle)` → string | throws `Error` (code 10 Json, 11 Network) | args: #1 borrowed-handle; result: owned by caller |
| `net.send(handle, string)` → int | throws `Error` (code 11 Network) | args: #1 borrowed-handle, #2 borrowed |
| `net.sendBytes(handle, list<int>)` → int | throws `Error` (code 11 Network, 13 Encoding) | args: #1 borrowed-handle, #2 borrowed; Accepts only list dyn int with 32-bit signed elements in [0,255], validates the complete list before sending, writes all bytes or throws, and caps each call at 16 MiB. |
| `net.sendLine(handle, string)` → int | throws `Error` (code 11 Network) | args: #1 borrowed-handle, #2 borrowed |
| `net.setTimeout(handle, int)` → void | throws `Error` (code 11 Network) | args: #1 borrowed-handle |
| `net.urlDecode(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller; Decodes valid percent triplets and converts plus to space. Invalid or incomplete percent sequences are preserved literally rather than rejected. |
| `net.urlEncode(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller; Percent-encodes UTF-8 bytes using the RFC 3986 ASCII-only unreserved set (A-Z, a-z, 0-9, hyphen, underscore, period and tilde), independent of the active C locale. |

_Parameter names are not part of the built-in contract; positional types are shown._
