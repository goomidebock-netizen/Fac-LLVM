# `mouse`

Mouse state query.

- Status: **stable**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 4 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `mouse.button(handle, string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed |
| `mouse.down(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `mouse.x(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `mouse.y(handle)` → int | no direct throw site | args: #1 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
