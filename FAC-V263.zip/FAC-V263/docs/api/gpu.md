# `gpu`

CPU-backed float64 numeric buffers and transactional arithmetic compatibility API; no native GPU execution.

- Status: **experimental**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 17 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `gpu.addF64(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Adds count little-endian IEEE-754 float64 values using CPU SIMD/reference execution; stages and validates output before commit. |
| `gpu.backend()` → string | no direct throw site | result: owned by caller; Always returns software-reference in the current release. |
| `gpu.backendCapabilities()` → string | no direct throw site | result: owned by caller; Describes CPU buffer and float64 arithmetic operations; no native GPU backend is available in the current release. |
| `gpu.bufferSize(handle)` → long | no direct throw site | args: #1 borrowed-handle |
| `gpu.copyBuffer(handle, long, handle, long, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #3 borrowed-handle |
| `gpu.createBuffer(long)` → handle | throws `Error` (code 14 Media) + OOM | result: owned by caller (release with `gpu.freeBuffer`) |
| `gpu.freeBuffer(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the buffer |
| `gpu.hardware()` → boolean | predicate (never throws on a normal miss) | Always returns false in the current release; no hardware device is probed. |
| `gpu.matmulF64(handle, handle, handle, long, long, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Multiplies row-major float64 matrices on the CPU; invalid dimensions/ranges or non-finite output return false without partial destination writes. |
| `gpu.mulF64(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Multiplies count little-endian IEEE-754 float64 values element-wise using CPU SIMD/reference execution; stages and validates output before commit. |
| `gpu.openclStatus()` → string | no direct throw site | result: owned by caller; Deprecated compatibility shim; always returns disabled and performs no device probing. |
| `gpu.readBuffer(handle, long, long)` → string | throws `Error` (code 14 Media) | args: #1 borrowed-handle; result: owned by caller |
| `gpu.readF64(handle, long)` → double | throws `Error` (code 14 Media) | args: #1 borrowed-handle; Reads one little-endian IEEE-754 float64 element at an element index. |
| `gpu.scaleF64(handle, handle, long, double)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle; Scales count little-endian IEEE-754 float64 values using CPU SIMD/reference execution; stages and validates output before commit. |
| `gpu.subF64(handle, handle, handle, long)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed-handle, #3 borrowed-handle; Subtracts count little-endian IEEE-754 float64 values using CPU SIMD/reference execution; stages and validates output before commit. |
| `gpu.writeBuffer(handle, long, string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #3 borrowed |
| `gpu.writeF64(handle, long, double)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle; Writes one finite little-endian IEEE-754 float64 element at an element index. |

_Parameter names are not part of the built-in contract; positional types are shown._
