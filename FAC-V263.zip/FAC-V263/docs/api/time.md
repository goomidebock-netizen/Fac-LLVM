# `time`

Clock, formatting and parsing.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 16 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `time.day(long)` → int | throws `Error` (code 12 TimeParse) |  |
| `time.format(long, string)` → string | throws `Error` (code 12 TimeParse) | args: #2 borrowed; result: owned by caller |
| `time.formatUtc(long, string)` → string | throws `Error` (code 12 TimeParse) | args: #2 borrowed; result: owned by caller |
| `time.hour(long)` → int | throws `Error` (code 12 TimeParse) |  |
| `time.iso(long)` → string | throws `Error` (code 12 TimeParse) | result: owned by caller |
| `time.minute(long)` → int | throws `Error` (code 12 TimeParse) |  |
| `time.mono()` → ulong | no direct throw site |  |
| `time.month(long)` → int | throws `Error` (code 12 TimeParse) |  |
| `time.now()` → ulong | no direct throw site |  |
| `time.nowSec()` → long | no direct throw site |  |
| `time.parse(string, string)` → long | throws `Error` (code 12 TimeParse) | args: #1 borrowed, #2 borrowed |
| `time.second(long)` → int | throws `Error` (code 12 TimeParse) |  |
| `time.sleep(long)` → void | no direct throw site | also: `graphic.delay`, `thread.sleep` |
| `time.utcOffset()` → int | throws `Error` (code 12 TimeParse) |  |
| `time.weekday(long)` → int | throws `Error` (code 12 TimeParse) |  |
| `time.year(long)` → int | throws `Error` (code 12 TimeParse) |  |

_Parameter names are not part of the built-in contract; positional types are shown._
