# `sys`

Process, environment and platform queries.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 13 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `sys.args()` → list<string> | see note | owned |
| `sys.chdir(string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed |
| `sys.cpuCount()` → int | no direct throw site |  |
| `sys.cwd()` → string | no direct throw site | result: owned by caller |
| `sys.env(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `sys.exit(int)` → void | no direct throw site |  |
| `sys.hostname()` → string | no direct throw site | result: owned by caller |
| `sys.output(string)` → string | throws `Error` (code 15 Process) | args: #1 borrowed; result: owned by caller |
| `sys.pid()` → int | no direct throw site |  |
| `sys.platform()` → string | no direct throw site | result: owned by caller |
| `sys.run(string)` → int | no direct throw site | args: #1 borrowed |
| `sys.setEnv(string, string)` → void | no direct throw site | args: #1 borrowed, #2 borrowed |
| `sys.tempDir()` → string | no direct throw site | result: owned by caller |

_Parameter names are not part of the built-in contract; positional types are shown._
