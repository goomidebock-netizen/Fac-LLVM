# `autograd`

Scalar and tensor reverse-mode automatic differentiation with bounded explicit tapes and tape-local node identifiers. Each mutable tape is confined to the thread that created it; cross-thread use and release throw Error(Concurrency, 16).

- Status: **basic**
- Thread-safety: **thread-confined (each mutable handle belongs to its creating thread)**
- Entries: 38 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `autograd.add(handle, int, int)` → int | throws `Error` (code 2 IndexOutOfRange, 3 DivisionByZero, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle |
| `autograd.backward(handle, int)` → void | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 16 Concurrency, 18 Math) | args: #1 borrowed-handle; Clears all accumulated gradients, seeds the selected output with 1, and propagates gradients through its ancestor graph in reverse creation order. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `autograd.backwardSeed(handle, int, double)` → void | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 16 Concurrency, 18 Math) | args: #1 borrowed-handle; Like backward, but uses the supplied finite scalar seed. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `autograd.create()` → handle | no direct throw site | result: owned by caller (release with `autograd.free`); Creates an owned scalar reverse-mode differentiation tape; release with autograd.free. |
| `autograd.div(handle, int, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.exp(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.free(handle)` → void | throws `Error` (code 16 Concurrency) | args: #1 borrowed-handle |
| `autograd.grad(handle, int)` → double | no direct throw site | args: #1 borrowed-handle |
| `autograd.log(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.mul(handle, int, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.neg(handle, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle |
| `autograd.pow(handle, int, double)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Differentiable scalar power; base must be positive and exponent finite. |
| `autograd.relu(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.sigmoid(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.softplus(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.sub(handle, int, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.tanh(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `autograd.tensorAdd(handle, int, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Differentiable exact-shape elementwise addition. |
| `autograd.tensorBackward(handle, int)` → void | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Resets tape gradients and computes reverse-mode gradients; output must contain exactly one element. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `autograd.tensorBackwardSeed(handle, int, double)` → void | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Like tensorBackward with a finite custom scalar seed. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `autograd.tensorCreate()` → handle | no direct throw site | result: owned by caller (release with `autograd.tensorFree`); Creates an owned tensor reverse-mode tape; release with autograd.tensorFree. The tape is CPU float64 and has bounded node/value storage. |
| `autograd.tensorFree(handle)` → void | throws `Error` (code 16 Concurrency) | args: #1 borrowed-handle |
| `autograd.tensorGrad(handle, int)` → handle | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 16 Concurrency, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns an owned tensor copy of the selected node gradient; release with tensor.free. |
| `autograd.tensorHadamard(handle, int, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Differentiable exact-shape elementwise multiplication. |
| `autograd.tensorMatmul(handle, int, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Differentiable matrix product; left columns must equal right rows. |
| `autograd.tensorMean(handle, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Reduces all elements to a 1x1 mean node; backward distributes the upstream gradient evenly. |
| `autograd.tensorRelu(handle, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle |
| `autograd.tensorScale(handle, int, double)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Differentiable scalar multiplication; scalar must be finite. |
| `autograd.tensorSigmoid(handle, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle |
| `autograd.tensorSub(handle, int, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Differentiable exact-shape elementwise subtraction. |
| `autograd.tensorSum(handle, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Reduces all elements to a 1x1 tensor node, suitable as a scalar backward target. |
| `autograd.tensorTanh(handle, int)` → int | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle |
| `autograd.tensorValue(handle, int)` → handle | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 16 Concurrency, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns an owned tensor copy of the selected node value; release with tensor.free. |
| `autograd.tensorVariable(handle, handle)` → int | throws `Error` (code 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle, #2 borrowed-handle; Copies a finite tensor into the tape and returns a tape-local integer node ID. |
| `autograd.tensorZeroGrad(handle)` → void | throws `Error` (code 6 NullPointer, 16 Concurrency) + OOM | args: #1 borrowed-handle |
| `autograd.value(handle, int)` → double | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 16 Concurrency) | args: #1 borrowed-handle |
| `autograd.variable(handle, double)` → int | throws `Error` (code 6 NullPointer, 8 Resource, 14 Media, 16 Concurrency, 18 Math) + OOM | args: #1 borrowed-handle; Appends a finite scalar leaf and returns a tape-local int node ID. Node IDs are invalid after tape release. |
| `autograd.zeroGrad(handle)` → void | throws `Error` (code 6 NullPointer, 16 Concurrency) | args: #1 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
