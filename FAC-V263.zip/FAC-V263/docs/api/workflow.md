# `workflow` (source library)

Source: `stdlib/workflow.fac` · `import workflow.fac` · release V263

### `Workflow`

```fac
public class Workflow
```

Workflow is a small explicit finite-state machine. Transitions are declared as state-name pairs and executed by moveTo(); no callbacks or side effects run.

### `Workflow.allow`

```fac
public function void allow(string from, string to)
```

- **Returns:** Declares an allowed state transition; duplicate pairs are ignored.
- **Ownership:** from/to=borrowed; workflow retains copies.
- **Errors:** Throws InvalidArgument (4) for invalid state names.
- **Thread-safety:** Not thread-safe.

### `Workflow.canMoveTo`

```fac
public function boolean canMoveTo(string target)
```

- **Returns:** True when target is an allowed successor of the current state.
- **Ownership:** target=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for an invalid target name.
- **Thread-safety:** Safe for a stable workflow.

### `Workflow.moveTo`

```fac
public function boolean moveTo(string target)
```

- **Returns:** Moves to an allowed state and records history; false leaves state unchanged.
- **Ownership:** target=borrowed; history retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid state names.
- **Thread-safety:** Not thread-safe.

### `Workflow.state`

```fac
public function string state() { return this.currentState }
```

- **Returns:** Current state name.
- **Ownership:** result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable workflow.

### `Workflow.history`

```fac
public function list dyn string history() { return this.stateHistory }
```

- **Returns:** Copy of visited states, including the initial state.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable workflow.

### `Workflow.historySize`

```fac
public function int historySize() { return sizeof(this.stateHistory) }
```

- **Returns:** Number of recorded states.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable workflow.

### `Workflow.reset`

```fac
public function void reset(string initialState)
```

- **Returns:** Resets to a supplied state and clears history; transition declarations remain.
- **Ownership:** initialState=borrowed; workflow retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid state names.
- **Thread-safety:** Not thread-safe.
