# `di` (source library)

Source: `stdlib/di.fac` · `import di.fac` · release V263

### `InstanceRegistry`

```fac
public class InstanceRegistry<T>
```

InstanceRegistry<T> holds pre-created dependencies in a typed list. Every registry stores one T only; no type erasure, factories or lifetime management.

### `InstanceRegistry.register`

```fac
public function void register(string key, T value)
```

- **Returns:** Registers/replaces a pre-created value under key.
- **Ownership:** key=borrowed; value follows T copy/ownership rules.
- **Errors:** Throws InvalidArgument (4) for invalid key; allocation/copy errors propagate.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `InstanceRegistry.has`

```fac
public function boolean has(string key) { return this.findKey(key) >= 0 }
```

- **Returns:** True when key has a registered value.
- **Ownership:** key=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `InstanceRegistry.resolve`

```fac
public function enum Option<T> resolve(string key)
```

- **Returns:** Some(value) when present; None otherwise.
- **Ownership:** key=borrowed; payload follows T copy/ownership rules.
- **Errors:** Payload copying may propagate runtime errors.
- **Thread-safety:** Safe for a stable registry; not concurrent mutation.

### `InstanceRegistry.remove`

```fac
public function boolean remove(string key)
```

- **Returns:** Removes a registered dependency; false when absent.
- **Ownership:** key=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `InstanceRegistry.size`

```fac
public function int size() { return sizeof(this.keys) }
```

- **Returns:** Number of registered values.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `InstanceRegistry.clear`

```fac
public function void clear()
```

- **Returns:** Clears all registered values.
- **Ownership:** no parameters; element destruction follows FAC T semantics.
- **Errors:** Runtime destruction errors propagate.
- **Thread-safety:** Not thread-safe when shared mutably.
