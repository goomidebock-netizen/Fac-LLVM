# `font`

Optional Pango/Cairo TTF/OTF rasterization with a built-in bitmap fallback and process-local Fontconfig loading.

- Status: **stable**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 12 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `font.backendAvailable()` → boolean | boolean status flag (`false` = failed, no detail) |  |
| `font.create(int)` → handle | throws `Error` (code 14 Media) + OOM | result: owned by caller (release with `font.free`) |
| `font.draw(handle, handle, int, int, string, int)` → void | throws `Error` (code 6 NullPointer, 14 Media) + OOM | args: #1 borrowed-handle, #2 borrowed-handle, #5 borrowed |
| `font.family(handle)` → string | no direct throw site | args: #1 borrowed-handle; result: owned by caller |
| `font.free(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the font |
| `font.height(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `font.isVector(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `font.load(string, int)` → handle | throws `Error` (code 7 Io, 14 Media) | args: #1 borrowed; result: owned by caller (release with `font.free`) |
| `font.measure(handle, string)` → int | no direct throw site | args: #1 borrowed-handle, #2 borrowed |
| `font.setScale(handle, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle |
| `font.setSize(handle, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle |
| `font.size(handle)` → int | no direct throw site | args: #1 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
