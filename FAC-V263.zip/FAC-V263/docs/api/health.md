# `health` (source library)

Source: `stdlib/health.fac` · `import health.fac` · release V263

### `HealthRegistry`

```fac
public class HealthRegistry
```

HealthRegistry stores explicitly reported component states. It does not run probes or execute callbacks; the host application updates each check.

### `HealthRegistry.register`

```fac
public function void register(string name)
```

- **Returns:** Registers a check initially marked unknown; duplicate names are rejected.
- **Ownership:** name=borrowed; registry retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid or duplicate names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HealthRegistry.report`

```fac
public function void report(string name, string state, string detail = "")
```

- **Returns:** Updates a check to healthy/degraded/unhealthy/unknown.
- **Ownership:** name/detail=borrowed; registry retains copies.
- **Errors:** Throws InvalidArgument (4) for missing check or unsupported state.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HealthRegistry.markHealthy`

```fac
public function void markHealthy(string name) { this.report(name, "healthy", "") }
```

- **Returns:** Sets a named check healthy and clears detail.
- **Ownership:** name=borrowed.
- **Errors:** Throws InvalidArgument (4) when check is missing.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HealthRegistry.markUnhealthy`

```fac
public function void markUnhealthy(string name, string detail = "") { this.report(name, "unhealthy", detail) }
```

- **Returns:** Sets a named check unhealthy with detail.
- **Ownership:** name/detail=borrowed.
- **Errors:** Throws InvalidArgument (4) when check is missing.
- **Thread-safety:** Not thread-safe when shared mutably.

### `HealthRegistry.state`

```fac
public function string state(string name)
```

- **Returns:** Current state for a named check.
- **Ownership:** name=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) when check is missing.
- **Thread-safety:** Safe for a stable registry.

### `HealthRegistry.detail`

```fac
public function string detail(string name)
```

- **Returns:** Detail text for a named check.
- **Ownership:** name=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) when check is missing.
- **Thread-safety:** Safe for a stable registry.

### `HealthRegistry.summary`

```fac
public function string summary()
```

- **Returns:** Overall worst state: unhealthy, degraded, unknown, or healthy.
- **Ownership:** result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `HealthRegistry.isHealthy`

```fac
public function boolean isHealthy() { return sizeof(this.names) > 0 && this.summary() == "healthy" }
```

- **Returns:** True only when all registered checks are healthy; empty registry is false.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.

### `HealthRegistry.size`

```fac
public function int size() { return sizeof(this.names) }
```

- **Returns:** Number of registered checks.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable registry.
