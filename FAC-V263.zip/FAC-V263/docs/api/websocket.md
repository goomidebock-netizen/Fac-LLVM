# `websocket` (source library)

Source: `stdlib/websocket.fac` · `import websocket.fac` · release V263

### `WebSocketFrameCodec`

```fac
public class WebSocketFrameCodec
```

One-frame RFC 6455 codec. This class does not own sockets or assemble messages.

### `WebSocketFrameCodec.encodeFrame`

```fac
public function list dyn int encodeFrame(int opcode, list dyn int payload, boolean fin = true, boolean masked = false, list dyn int maskKey)
```

- **Returns:** Encodes one RFC 6455 frame as an owned byte list. Close frames validate status codes and UTF-8 reasons; masked frames require a caller-supplied four-byte key.
- **Ownership:** payload/maskKey=borrowed; result=owned list of unsigned bytes.
- **Errors:** Throws InvalidArgument (4), Parse (10), or Encoding (13) for invalid frame fields/bytes or size limits.
- **Thread-safety:** Not thread-safe when shared mutably.

### `WebSocketFrameCodec.decodeFrame`

```fac
public function boolean decodeFrame(list dyn int wire, boolean expectMasked)
```

- **Returns:** Decodes exactly one complete frame, validating close status codes and UTF-8 reasons. Mask expectation is strict: true for client-to-server frames, false for server-to-client frames.
- **Ownership:** wire=borrowed; decoded payload is retained internally and copied by payload().
- **Errors:** Throws Parse (10), Encoding (13), or InvalidArgument (4) for malformed, incomplete, unexpected-mask or oversized frames.
- **Thread-safety:** Not thread-safe when shared mutably.

### `WebSocketFrameCodec.randomMaskKey`

```fac
public function list dyn int randomMaskKey()
```

- **Returns:** Generates a cryptographically random four-byte mask key for client frames.
- **Ownership:** result=owned list.
- **Errors:** Propagates Crypto/Encoding errors if the Runtime random source fails.
- **Thread-safety:** Safe; uses the Runtime cryptographic random source.

### `WebSocketFrameCodec.hasFrame`

```fac
public function boolean hasFrame() { return this.decoded }
```

- **Returns:** True after a successful decodeFrame call.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable codec.

### `WebSocketFrameCodec.isFinal`

```fac
public function boolean isFinal()
```

- **Returns:** FIN bit of the last decoded frame.
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) before a successful decode.
- **Thread-safety:** Safe for a stable codec.

### `WebSocketFrameCodec.opcode`

```fac
public function int opcode()
```

- **Returns:** Opcode of the last decoded frame (0 continuation, 1 text, 2 binary, 8 close, 9 ping, 10 pong).
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) before a successful decode.
- **Thread-safety:** Safe for a stable codec.

### `WebSocketFrameCodec.wasMasked`

```fac
public function boolean wasMasked()
```

- **Returns:** Whether the last decoded frame was masked on the wire.
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) before a successful decode.
- **Thread-safety:** Safe for a stable codec.

### `WebSocketFrameCodec.payload`

```fac
public function list dyn int payload()
```

- **Returns:** An independently owned copy of the last decoded payload bytes.
- **Ownership:** result=owned list.
- **Errors:** Throws InvalidArgument (4) before a successful decode.
- **Thread-safety:** Safe for a stable codec.

### `WebSocketHandshake`

```fac
public class WebSocketHandshake
```

### `WebSocketHandshake.validateUpgrade`

```fac
public function boolean validateUpgrade(string method, string upgrade, string connection, string version, string key)
```

- **Returns:** True for a syntactically valid RFC 6455 HTTP/1.1 upgrade request header set.
- **Ownership:** all parameters=borrowed.
- **Errors:** None; invalid request data returns false.
- **Thread-safety:** Safe; no shared mutable state.

### `WebSocketHandshake.acceptKey`

```fac
public function string acceptKey(string key)
```

- **Returns:** Sec-WebSocket-Accept value for a valid 16-byte Base64 client key.
- **Ownership:** key=borrowed; result=owned string.
- **Errors:** Throws Parse (10) when the key is not canonical Base64 for exactly 16 bytes.
- **Thread-safety:** Safe; uses pure hashing/encoding helpers.

### `WebSocketHandshake.createClientRequest`

```fac
public function string createClientRequest(string host, string path)
```

- **Returns:** Builds an HTTP/1.1 WebSocket client upgrade request with a fresh cryptographic nonce; the key is retained for response verification.
- **Ownership:** host/path=borrowed; result=owned request text.
- **Errors:** Throws InvalidArgument (4) for unsafe host/path values; propagates Crypto errors.
- **Thread-safety:** Not thread-safe when one handshake object is shared mutably.

### `WebSocketHandshake.verifyClientResponse`

```fac
public function boolean verifyClientResponse(string statusLine, string upgrade, string connection, string accept)
```

- **Returns:** Whether an HTTP/1.1 101 response contains the required Upgrade/Connection tokens and matching Sec-WebSocket-Accept value.
- **Ownership:** parameters=borrowed.
- **Errors:** Returns false for malformed or mismatched response data.
- **Thread-safety:** Safe for stable handshake state.

### `WebSocketHandshake.clientKeyValue`

```fac
public function string clientKeyValue() { return this.clientKey }
```

- **Returns:** The current client nonce key, or an empty string before createClientRequest.
- **Ownership:** result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for stable handshake state.

### `WebSocketHandshake.clientUpgrade`

```fac
public function boolean clientUpgrade(ptr socket socket, string host, string path)
```

- **Returns:** Performs a complete cleartext WebSocket HTTP upgrade on an already-connected TCP socket.
- **Ownership:** socket=borrowed; handshake object retains only the nonce key.
- **Errors:** Throws Network (11) for I/O and returns false for a rejected/malformed peer response.
- **Thread-safety:** Not thread-safe when handshake state is shared.

### `WebSocketHandshake.clientUpgradeTls`

```fac
public function boolean clientUpgradeTls(obj TlsStream stream, string host, string path)
```

- **Returns:** Performs a complete TLS WebSocket HTTP upgrade on an already-connected TlsStream.
- **Ownership:** stream=borrowed; remains open for WebSocketConnection construction.
- **Errors:** Throws Network (11) for I/O and returns false for a rejected/malformed peer response.
- **Thread-safety:** Not thread-safe when handshake state is shared.

### `WebSocketHandshake.serverUpgrade`

```fac
public function boolean serverUpgrade(ptr socket socket)
```

- **Returns:** Reads, validates and answers a client HTTP upgrade request on a TCP socket.
- **Ownership:** socket=borrowed; the socket remains open for WebSocketConnection.
- **Errors:** Throws Network (11); returns false for invalid, oversized, or unsupported requests.
- **Thread-safety:** Not thread-safe when shared mutably.

### `WebSocketHandshake.serverUpgradeTls`

```fac
public function boolean serverUpgradeTls(obj TlsStream stream)
```

- **Returns:** Reads, validates and answers a client HTTP upgrade request on a TlsStream.
- **Ownership:** stream=borrowed; it remains open for WebSocketConnection.
- **Errors:** Throws Network (11); returns false for invalid, oversized, or unsupported requests.
- **Thread-safety:** Not thread-safe when shared mutably.

### `WebSocketHandshake.responseHeader`

```fac
public function string responseHeader(string key)
```

- **Returns:** Complete HTTP/1.1 101 response header block for a validated client key; caller sends it on the upgraded TCP socket.
- **Ownership:** key=borrowed; result=owned string.
- **Errors:** Throws Parse (10) when the key is invalid.
- **Thread-safety:** Safe; no shared mutable state.

### `WebSocketConnection`

```fac
public class WebSocketConnection
```

A synchronous frame/message transport layered on TCP or an owned TLS handle. Construction transfers ownership of the native transport handle to this object.

### `WebSocketConnection.sendFrame`

```fac
public function int sendFrame(int opcode, list dyn int payload, boolean fin = true)
```

- **Returns:** Sends exactly one frame. Client endpoints mask every outgoing frame; server endpoints do not.
- **Ownership:** payload=borrowed; transport=owned by this connection; result=byte count.
- **Errors:** Propagates Network (11), Crypto, Encoding and frame validation errors.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.receiveFrame`

```fac
public function boolean receiveFrame()
```

- **Returns:** Reads one complete frame from TCP and stores it in the frame codec.
- **Ownership:** result=boolean; decoded payload is owned by codec and copied by framePayload().
- **Errors:** Throws Network (11), Parse (10), or InvalidArgument (4) for truncated or malformed frames.
- **Thread-safety:** Not thread-safe; blocking socket read follows net.setTimeout on the underlying socket.

### `WebSocketConnection.framePayload`

```fac
public function list dyn int framePayload() { return this.codec.payload() }
```

- **Returns:** A copied payload from the last successful receiveFrame call.
- **Ownership:** result=owned list.
- **Errors:** Throws InvalidArgument (4) when no frame has been received.
- **Thread-safety:** Safe for a stable connection state.

### `WebSocketConnection.frameOpcode`

```fac
public function int frameOpcode() { return this.codec.opcode() }
```

- **Returns:** Opcode of the last received frame.
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) when no frame has been received.
- **Thread-safety:** Safe for a stable connection state.

### `WebSocketConnection.sendText`

```fac
public function int sendText(string text)
```

- **Returns:** Sends a UTF-8 text frame.
- **Ownership:** text=borrowed; wire bytes are generated and owned internally.
- **Errors:** Throws Encoding (13) if the text exceeds the byte-list limit; propagates network/crypto errors.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.sendBinary`

```fac
public function int sendBinary(list dyn int payload) { return this.sendFrame(2, payload, true) }
```

- **Returns:** Sends one binary frame.
- **Ownership:** payload=borrowed.
- **Errors:** Throws Encoding (13) for invalid bytes; propagates network/crypto errors.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.sendPing`

```fac
public function int sendPing(list dyn int payload) { return this.sendFrame(9, payload, true) }
```

- **Returns:** Sends a ping control frame.
- **Ownership:** payload=borrowed.
- **Errors:** Throws frame validation or network errors; ping payload is limited to 125 bytes.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.sendPong`

```fac
public function int sendPong(list dyn int payload) { return this.sendFrame(10, payload, true) }
```

- **Returns:** Sends a pong control frame.
- **Ownership:** payload=borrowed.
- **Errors:** Throws frame validation or network errors; pong payload is limited to 125 bytes.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.sendClose`

```fac
public function int sendClose(list dyn int payload) { return this.sendFrame(8, payload, true) }
```

- **Returns:** Sends a close control frame; the caller may continue receiving until the peer replies.
- **Ownership:** payload=borrowed; normally empty or a valid two-byte status code plus UTF-8 reason.
- **Errors:** Throws frame validation or network errors.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.receiveMessage`

```fac
public function boolean receiveMessage()
```

- **Returns:** Receives and reassembles one message; ping frames are answered automatically, pong frames ignored, and peer close is echoed before closing TCP. Returns false on peer close.
- **Ownership:** returned message is retained internally and copied by messageBytes()/messageText().
- **Errors:** Throws Network (11), Parse (10), Encoding (13), or InvalidArgument (4) on protocol errors.
- **Thread-safety:** Not thread-safe; synchronous socket I/O.

### `WebSocketConnection.messageText`

```fac
public function string messageText()
```

- **Returns:** Last complete text message as a UTF-8 string.
- **Ownership:** result=owned string.
- **Errors:** Throws InvalidArgument (4) unless the last completed message was text.
- **Thread-safety:** Safe for a stable connection state.

### `WebSocketConnection.messageBytes`

```fac
public function list dyn int messageBytes()
```

- **Returns:** Last complete binary message as an independently owned byte list.
- **Ownership:** result=owned list.
- **Errors:** Throws InvalidArgument (4) unless the last completed message was binary.
- **Thread-safety:** Safe for a stable connection state.

### `WebSocketConnection.messageOpcode`

```fac
public function int messageOpcode()
```

- **Returns:** Opcode of the last complete message (1 text or 2 binary).
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) if no complete message is available.
- **Thread-safety:** Safe for a stable connection state.

### `WebSocketConnection.isOpen`

```fac
public function boolean isOpen() { return this.active }
```

- **Returns:** Whether the underlying TCP socket is still open in this wrapper.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable connection state.

### `WebSocketConnection.close`

```fac
public function void close()
```

- **Returns:** Closes and releases the owned TCP or TLS transport. Safe to call more than once.
- **Ownership:** consumes the socket transferred to the constructor.
- **Errors:** None for a valid connection.
- **Thread-safety:** Do not race with send/receive operations.
