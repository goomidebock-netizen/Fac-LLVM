# `cache` (source library)

Source: `stdlib/cache.fac` · `import cache.fac` · release V263

### `CacheStore`

```fac
public class CacheStore
```

CacheStore is a string-keyed in-memory cache. Time is supplied by the caller so expiration tests and event loops can use a deterministic monotonic clock.

### `CacheStore.set`

```fac
public function void set(string key, string value)
```

- **Returns:** Stores a value without expiration.
- **Ownership:** key/value=borrowed; cache retains copies.
- **Errors:** Throws InvalidArgument (4) for an invalid key.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `CacheStore.setFor`

```fac
public function void setFor(string key, string value, long nowMs, long ttlMs)
```

- **Returns:** Stores a value expiring at nowMs + ttlMs; ttl must be positive.
- **Ownership:** key/value=borrowed; cache retains copies.
- **Errors:** Throws InvalidArgument (4) for invalid key/time/TTL or timestamp overflow.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `CacheStore.hasAt`

```fac
public function boolean hasAt(string key, long nowMs)
```

- **Returns:** True when key exists and is not expired at nowMs; expired entries are removed.
- **Ownership:** key=borrowed; result=by value.
- **Errors:** Throws InvalidArgument (4) for negative nowMs.
- **Thread-safety:** Not thread-safe when shared mutably.

### `CacheStore.get`

```fac
public function string get(string key, long nowMs, string fallback = "")
```

- **Returns:** Value or fallback; expired entries are removed.
- **Ownership:** key/fallback=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) for negative nowMs.
- **Thread-safety:** Not thread-safe when shared mutably.

### `CacheStore.remove`

```fac
public function void remove(string key)
```

- **Returns:** Removes a key and its expiration metadata.
- **Ownership:** key=borrowed.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `CacheStore.prune`

```fac
public function int prune(long nowMs)
```

- **Returns:** Removes all entries whose deadline is <= nowMs and returns the removal count.
- **Ownership:** result=by value.
- **Errors:** Throws InvalidArgument (4) for negative nowMs.
- **Thread-safety:** Not thread-safe when shared mutably.

### `CacheStore.size`

```fac
public function int size() { return sizeof(this.values) }
```

- **Returns:** Number of currently stored entries, including entries not yet lazily expired.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable cache.

### `CacheStore.clear`

```fac
public function void clear()
```

- **Returns:** Removes all values and expiration metadata.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
