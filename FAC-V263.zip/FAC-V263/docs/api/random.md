# `random`

Per-thread non-cryptographic RNG, weighted and standard-distribution sampling, deterministic coordinate noise and Markov transitions.

- Status: **stable**
- Thread-safety: **safe (per-thread state)**
- Entries: 17 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `random.boolean()` → boolean | predicate (never throws on a normal miss) |  |
| `random.choice(sequence)` → element type | see note | Throws Error code 8 on an empty sequence. |
| `random.exponential(double)` → double | throws `Error` (code 8 Resource) | Uses lambda as the rate parameter and requires finite lambda > 0; result type matches lambda. |
| `random.fbm(double, int)` → double | throws `Error` (code 8 Resource) | One- and two-dimensional deterministic Perlin fractal Brownian motion; octaves must be in [1, 16], with lacunarity 2 and gain 0.5. |
| `random.fbm(double, double, int)` → double | throws `Error` (code 8 Resource) | One- and two-dimensional deterministic Perlin fractal Brownian motion; octaves must be in [1, 16], with lacunarity 2 and gain 0.5. |
| `random.float()` → double | no direct throw site |  |
| `random.gauss(double, double)` → double | throws `Error` (code 8 Resource) |  |
| `random.int(long, long)` → int|long | no direct throw site |  |
| `random.markov(integer currentStateIndex, sequence numeric transitionMatrix, integer stateCount)` → long | see note | Uses the current state's row in a row-major stateCount × stateCount matrix and returns the next state index. |
| `random.normal(double, double)` → double | throws `Error` (code 8 Resource) | Returns the common numeric type of mean and standardDeviation; non-floating targets use FAC's saturating floating-to-integer conversion. |
| `random.perlin(double)` → double | throws `Error` (code 8 Resource) | One- and two-dimensional deterministic coordinate noise; coordinates must be finite and have magnitude below 2^52. |
| `random.perlin(double, double)` → double | throws `Error` (code 8 Resource) | One- and two-dimensional deterministic coordinate noise; coordinates must be finite and have magnitude below 2^52. |
| `random.poisson(double)` → ulong | throws `Error` (code 8 Resource) | Returns an unsigned event count (ulong); lambda must be finite and in [0, 1e12]. |
| `random.seed(long)` → void | no direct throw site |  |
| `random.shuffle(sequence)` → void | see note | In place. |
| `random.simplex(double)` → double | throws `Error` (code 8 Resource) | One- and two-dimensional deterministic coordinate noise; coordinates must be finite and have magnitude below 2^52. The 1D form shares the 1D gradient-noise implementation. |
| `random.simplex(double, double)` → double | throws `Error` (code 8 Resource) | One- and two-dimensional deterministic coordinate noise; coordinates must be finite and have magnitude below 2^52. The 1D form shares the 1D gradient-noise implementation. |
| `random.triangular(double, double, double)` → double | throws `Error` (code 8 Resource) | Requires finite min <= mode <= max; returns the common numeric type of all three arguments. |
| `random.uniform(number min, number max | boolean min, boolean max)` → common numeric type or boolean | see note | Uniform integer bounds are inclusive; floating-point bounds produce [min,max). Descending bounds are accepted. |
| `random.weighted(sequence values, sequence numeric weights)` → element type | see note | Weights may be percentages or relative weights and need not sum to 100. Lengths must match; weights must be finite, non-negative and have a positive total. |

_Parameter names are not part of the built-in contract; positional types are shown._
