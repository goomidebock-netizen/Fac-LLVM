# `pubsub` (source library)

Source: `stdlib/pubsub.fac` · `import pubsub.fac` · release V263

### `PubSubBus`

```fac
public class PubSubBus
```

PubSubBus is a bounded, in-process polling bus. Each matching subscriber gets its own pending copy; callbacks, persistence and cross-process delivery are intentionally outside this module.

### `PubSubBus.subscribe`

```fac
public function boolean subscribe(string subscriber, string topic)
```

- **Returns:** Subscribes a named consumer to one exact topic; duplicate subscription is a no-op returning false.
- **Ownership:** subscriber/topic=borrowed; bus retains copies.
- **Errors:** Throws InvalidArgument (4) for empty or multi-line names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `PubSubBus.unsubscribe`

```fac
public function boolean unsubscribe(string subscriber, string topic)
```

- **Returns:** Removes one exact subscription and any queued messages for that subscriber/topic pair.
- **Ownership:** subscriber/topic=borrowed.
- **Errors:** None; false if absent.
- **Thread-safety:** Not thread-safe when shared mutably.

### `PubSubBus.publish`

```fac
public function int publish(string topic, string payload)
```

- **Returns:** Publishes to every exact-topic subscriber and returns delivery count.
- **Ownership:** topic/payload=borrowed; each queue retains a payload copy.
- **Errors:** Throws InvalidArgument (4) for bad topic and Resource (8) if any subscriber queue is full.
- **Thread-safety:** Not thread-safe; publication is synchronous and may partially deliver before a full queue is found.

### `PubSubBus.hasMessage`

```fac
public function boolean hasMessage(string subscriber) { return this.nextIndex(subscriber) >= 0 }
```

- **Returns:** True when a subscriber has a queued message.
- **Ownership:** subscriber=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe for a stable bus.

### `PubSubBus.nextTopic`

```fac
public function string nextTopic(string subscriber)
```

- **Returns:** Next queued topic without consuming it.
- **Ownership:** subscriber=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) when no message exists.
- **Thread-safety:** Not thread-safe when shared mutably.

### `PubSubBus.nextPayload`

```fac
public function string nextPayload(string subscriber)
```

- **Returns:** Next queued payload without consuming it.
- **Ownership:** subscriber=borrowed; result=owned string.
- **Errors:** Throws InvalidArgument (4) when no message exists.
- **Thread-safety:** Not thread-safe when shared mutably.

### `PubSubBus.consume`

```fac
public function void consume(string subscriber)
```

- **Returns:** Consumes the next queued message for a subscriber.
- **Ownership:** subscriber=borrowed.
- **Errors:** Throws InvalidArgument (4) when no message exists.
- **Thread-safety:** Not thread-safe when shared mutably.

### `PubSubBus.clearPending`

```fac
public function void clearPending()
```

- **Returns:** Removes all queued messages but leaves subscriptions intact.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `PubSubBus.pending`

```fac
public function int pending(string subscriber) { return this.pendingCount(subscriber) }
```

- **Returns:** Number of pending messages for one subscriber.
- **Ownership:** subscriber=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable bus.

### `PubSubBus.subscriptionCount`

```fac
public function int subscriptionCount() { return sizeof(this.subscribers) }
```

- **Returns:** Total number of active exact-topic subscriptions.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable bus.
