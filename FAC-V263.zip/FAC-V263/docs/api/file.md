# `file`

Whole-file and handle based file I/O; native operations on one opaque handle are serialized and closed-token aliases fail closed.

- Status: **stable**
- Thread-safety: **serialized per opaque handle (do not race managed close/destruction)**
- Entries: 24 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `file.append(string, string)` → void | throws `Error` (code 7 Io) | args: #1 borrowed, #2 borrowed |
| `file.close(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: closes and frees the handle |
| `file.copy(string, string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed, #2 borrowed |
| `file.delete(string)` → boolean | boolean status flag (`false` = failed, no detail) | **deprecated** of `file.remove` (remove ≥ V47); args: #1 borrowed |
| `file.eof(handle)` → boolean | throws `Error` (code 7 Io) | args: #1 borrowed-handle |
| `file.exists(string)` → boolean | predicate (never throws on a normal miss) | **alias** of `path.exists`; args: #1 borrowed |
| `file.flush(handle)` → void | throws `Error` (code 7 Io) | args: #1 borrowed-handle |
| `file.isFile(string)` → boolean | predicate (never throws on a normal miss) | **alias** of `path.isFile`; args: #1 borrowed |
| `file.liveHandles()` → ulong | no direct throw site |  |
| `file.mkdir(string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed |
| `file.modified(string)` → long | throws `Error` (code 7 Io) | args: #1 borrowed |
| `file.open(string, string)` → handle | throws `Error` (code 7 Io) + OOM | args: #1 borrowed, #2 borrowed; result: owned by caller (release with `file.close`) |
| `file.readAll(handle)` → string | throws `Error` (code 7 Io) | args: #1 borrowed-handle; result: owned by caller; also: `file.readall` |
| `file.readLine(handle)` → string | throws `Error` (code 7 Io) + OOM | args: #1 borrowed-handle; result: owned by caller; also: `file.readline` |
| `file.readLines(string)` → list<string> | throws `Error` (code 7 Io) | args: #1 borrowed; result: owned by caller |
| `file.readText(string)` → string | throws `Error` (code 7 Io) | args: #1 borrowed; result: owned by caller |
| `file.readall(handle)` → string | throws `Error` (code 7 Io) | **deprecated** of `file.readAll` (remove ≥ V47); args: #1 borrowed-handle; result: owned by caller |
| `file.readline(handle)` → string | throws `Error` (code 7 Io) + OOM | **deprecated** of `file.readLine` (remove ≥ V47); args: #1 borrowed-handle; result: owned by caller |
| `file.remove(string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed; also: `file.delete` |
| `file.rename(string, string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed, #2 borrowed |
| `file.size(string)` → long | throws `Error` (code 7 Io) | args: #1 borrowed |
| `file.write(handle, string)` → void | throws `Error` (code 7 Io) | args: #1 borrowed-handle, #2 borrowed |
| `file.writeAll(string, string)` → void | throws `Error` (code 7 Io) | args: #1 borrowed, #2 borrowed |
| `file.writeLine(handle, string)` → void | throws `Error` (code 7 Io) | args: #1 borrowed-handle, #2 borrowed |

_Parameter names are not part of the built-in contract; positional types are shown._
