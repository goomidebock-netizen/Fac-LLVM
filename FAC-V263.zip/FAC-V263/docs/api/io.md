# `io` (source library)

Source: `stdlib/io.fac` · `import io.fac` · release V263

### `TextReader`

```fac
public class TextReader
```

TextReader reads lines from an in-memory UTF-8 string. File-system access is provided by file.fac/fs.fac; this class is useful for parsers and tests.

### `TextReader.hasNext`

```fac
public function boolean hasNext() { return this.cursor < sizeof(this.lines) }
```

- **Returns:** True while another line is available.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; use one reader per consumer.

### `TextReader.readLine`

```fac
public function enum Option<string> readLine()
```

- **Returns:** Some(next line) without its line terminator, or None at end.
- **Ownership:** result=owned string payload.
- **Errors:** None for exhaustion.
- **Thread-safety:** Not thread-safe; use one reader per consumer.

### `TextReader.lineNumber`

```fac
public function int lineNumber() { return this.cursor }
```

- **Returns:** Number of lines already consumed.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TextReader.reset`

```fac
public function void reset() { this.cursor = 0 }
```

- **Returns:** Resets the reader to the first line.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TextWriter`

```fac
public class TextWriter
```

TextWriter buffers chunks and joins once in toString(), avoiding repeated full-string concatenation when constructing large text documents.

### `TextWriter.append`

```fac
public function void append(string value) { this.parts.add(value) }
```

- **Returns:** Appends text without adding a line break.
- **Ownership:** value=borrowed (immutable, shared); the writer stores its own string reference.
- **Errors:** May allocate; allocation failure raises the Runtime error.
- **Thread-safety:** Not thread-safe.

### `TextWriter.appendLine`

```fac
public function void appendLine(string value)
```

- **Returns:** Appends text followed by a single LF line break.
- **Ownership:** value=borrowed (immutable, shared).
- **Errors:** May allocate; allocation failure raises the Runtime error.
- **Thread-safety:** Not thread-safe.

### `TextWriter.toString`

```fac
public function string toString() { return string.join(this.parts, "") }
```

- **Returns:** The buffered text as one owned string.
- **Ownership:** result=owned string.
- **Errors:** May allocate; allocation failure raises the Runtime error.
- **Thread-safety:** Not thread-safe.

### `TextWriter.chunkCount`

```fac
public function int chunkCount() { return sizeof(this.parts) }
```

- **Returns:** Number of appended chunks, not the number of characters.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TextWriter.clear`

```fac
public function void clear() { this.parts.clear() }
```

- **Returns:** Clears all buffered chunks.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.
