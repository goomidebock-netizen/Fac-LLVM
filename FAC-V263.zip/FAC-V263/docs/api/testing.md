# `testing` (source library)

Source: `stdlib/testing.fac` · `import testing.fac` · release V263

### `TestSuite`

```fac
public class TestSuite
```

A small in-process test accumulator for examples and application-level tests. It records assertion labels; it does not replace the compiler's test harness.

### `TestSuite.check`

```fac
public function void check(boolean condition, string label)
```

- **Returns:** Records one boolean check and its label.
- **Ownership:** label=borrowed (immutable, shared).
- **Errors:** May allocate when a failure label is stored.
- **Thread-safety:** Not thread-safe.

### `TestSuite.equalInt`

```fac
public function void equalInt(int actual, int expected, string label)
```

- **Returns:** Records an integer equality check.
- **Ownership:** label=borrowed.
- **Errors:** May allocate when a failure label is stored.
- **Thread-safety:** Not thread-safe.

### `TestSuite.equalString`

```fac
public function void equalString(string actual, string expected, string label)
```

- **Returns:** Records a string equality check.
- **Ownership:** actual/expected/label=borrowed immutable strings.
- **Errors:** May allocate when a failure label is stored.
- **Thread-safety:** Not thread-safe.

### `TestSuite.totalCount`

```fac
public function int totalCount() { return this.total }
```

- **Returns:** Total number of checks recorded.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TestSuite.passedCount`

```fac
public function int passedCount() { return this.passed }
```

- **Returns:** Number of passing checks.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TestSuite.failedCount`

```fac
public function int failedCount() { return this.total - this.passed }
```

- **Returns:** Number of failed checks.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TestSuite.success`

```fac
public function boolean success() { return this.total == this.passed }
```

- **Returns:** True when all recorded checks passed.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `TestSuite.failureMessages`

```fac
public function list dyn string failureMessages()
```

- **Returns:** A shallow copy of failure labels.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Not thread-safe.

### `TestSuite.report`

```fac
public function void report()
```

- **Returns:** Prints a summary and each failed label to stdout.
- **Ownership:** no parameters.
- **Errors:** Terminal output errors follow terminal.out.println behavior.
- **Thread-safety:** Not thread-safe.

### `TestSuite.assertAll`

```fac
public function void assertAll()
```

- **Returns:** Nothing when all checks passed.
- **Ownership:** no parameters.
- **Errors:** Throws Error code 4 when one or more checks failed.
- **Thread-safety:** Not thread-safe.
