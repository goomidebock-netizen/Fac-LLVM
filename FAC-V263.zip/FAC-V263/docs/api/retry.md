# `retry` (source library)

Source: `stdlib/retry.fac` · `import retry.fac` · release V263

### `RetryPolicy`

```fac
public class RetryPolicy
```

RetryPolicy describes retry decisions and deterministic exponential delays. It does not execute callbacks or sleep: the caller owns operation invocation.

### `RetryPolicy.set`

```fac
public function void set(int maxAttempts, long initialDelay, long maximumDelay)
```

- **Returns:** Replaces the policy after validating its bounds.
- **Ownership:** arguments=by value.
- **Errors:** Throws InvalidArgument (4) for invalid attempt or delay bounds.
- **Thread-safety:** Not thread-safe when shared mutably.

### `RetryPolicy.maxAttempts`

```fac
public function int maxAttempts() { return this.attemptsLimit }
```

- **Returns:** Maximum total operation attempts, including the initial attempt.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable policy.

### `RetryPolicy.shouldRetry`

```fac
public function boolean shouldRetry(int completedAttempts)
```

- **Returns:** True when another attempt is allowed after completedAttempts.
- **Ownership:** completedAttempts=by value.
- **Errors:** Throws InvalidArgument (4) for completedAttempts < 0.
- **Thread-safety:** Safe for a stable policy.

### `RetryPolicy.delayFor`

```fac
public function long delayFor(int retryNumber)
```

- **Returns:** Delay before retryNumber (1-based), with exponential doubling and max-delay cap.
- **Ownership:** retryNumber=by value; result=by value.
- **Errors:** Throws InvalidArgument (4) for retryNumber < 1.
- **Thread-safety:** Safe for a stable policy.
