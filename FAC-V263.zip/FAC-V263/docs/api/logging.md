# `logging` (source library)

Source: `stdlib/logging.fac` · `import logging.fac` · release V263

### `Logger`

```fac
public class Logger
```

Logger is a small synchronous stderr logger. It deliberately does not claim asynchronous sinks, file rotation, structured JSON, or thread safety.

### `Logger.setMinimum`

```fac
public function void setMinimum(enum LogLevel value) { this.minimumLevel = value.toInt() }
```

- **Returns:** Changes the minimum level accepted by this logger.
- **Ownership:** value=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; synchronize calls from multiple threads.

### `Logger.minimum`

```fac
public function enum LogLevel minimum()
```

- **Returns:** The current minimum log level.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `Logger.log`

```fac
public function void log(enum LogLevel level, string message)
```

- **Returns:** Writes one accepted log message to stderr; filtered messages are ignored.
- **Ownership:** message=borrowed (immutable, shared); no retention.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe; synchronize calls from multiple threads.

### `Logger.debug`

```fac
public function void debug(string message) { this.log(LogLevel.Debug, message) }
```

- **Returns:** Writes a Debug message when Debug is enabled.
- **Ownership:** message=borrowed.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `Logger.info`

```fac
public function void info(string message) { this.log(LogLevel.Info, message) }
```

- **Returns:** Writes an Info message when Info or Debug is enabled.
- **Ownership:** message=borrowed.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `Logger.warn`

```fac
public function void warn(string message) { this.log(LogLevel.Warn, message) }
```

- **Returns:** Writes a Warn message when Warn, Info, or Debug is enabled.
- **Ownership:** message=borrowed.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.

### `Logger.error`

```fac
public function void error(string message) { this.log(LogLevel.Error, message) }
```

- **Returns:** Writes an Error message when Error or a more verbose level is enabled.
- **Ownership:** message=borrowed.
- **Errors:** Terminal output errors follow terminal.err.println behavior.
- **Thread-safety:** Not thread-safe.
