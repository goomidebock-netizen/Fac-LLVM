# `entity` (source library)

Source: `stdlib/entity.fac` · `import entity.fac` · release V263

### `World.add`

```fac
public function void add(obj Entity e) { this.items.add(e) }
```

- **Returns:** Nothing.
- **Ownership:** e=object reference, shared, not consumed
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `World.count`

```fac
public function int count() { return sizeof(this.items) }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the World receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `World.clear`

```fac
public function void clear() { this.items.clear() }
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `World.update`

```fac
public function void update(double dt)
```

- **Returns:** Nothing.
- **Ownership:** dt=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `World.draw`

```fac
public function void draw(ptr graphic g, int camX, int camY)
```

- **Returns:** Nothing.
- **Ownership:** g=non-owning handle, not freed here; camX=by value; camY=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the World receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
