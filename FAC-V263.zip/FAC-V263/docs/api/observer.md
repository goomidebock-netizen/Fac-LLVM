# `observer` (source library)

Source: `stdlib/observer.fac` · `import observer.fac` · release V263

### `ObservableValue`

```fac
public class ObservableValue<T>
```

ObservableValue is a polling-oriented observable. Consumers retain the revision returned by version() and call changedSince(revision); it does not store callback closures or invoke observers automatically.

### `ObservableValue.get`

```fac
public function T get() { return this.current }
```

- **Returns:** Current value by value.
- **Ownership:** result follows T; reference-like T values are shallow copies.
- **Errors:** None.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `ObservableValue.set`

```fac
public function boolean set(T value)
```

- **Returns:** Replaces the value; returns true only when equality reports a change.
- **Ownership:** value=by value; stored value follows T's copy semantics.
- **Errors:** None apart from allocation/copy failures of T.
- **Thread-safety:** Not thread-safe; synchronize externally when shared.

### `ObservableValue.version`

```fac
public function long version() { return this.revisionNumber }
```

- **Returns:** Monotonically increasing change revision, initially zero.
- **Ownership:** result=by value.
- **Errors:** Integer overflow follows FAC checked arithmetic behavior.
- **Thread-safety:** Not thread-safe when concurrently mutated.

### `ObservableValue.changedSince`

```fac
public function boolean changedSince(long observedRevision)
```

- **Returns:** True when this value changed after the supplied revision.
- **Ownership:** observedRevision=by value.
- **Errors:** Throws InvalidArgument (4) for a negative or future revision.
- **Thread-safety:** Not thread-safe when concurrently mutated.
