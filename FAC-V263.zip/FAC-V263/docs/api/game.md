# `game` (source library)

Source: `stdlib/game.fac` · `import game.fac` · release V263

### `reset`

```fac
public function void reset()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (accNs, alphaValue, droppedNsValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `setUpdateRate`

```fac
public function void setUpdateRate(int hz)
```

- **Returns:** Nothing.
- **Ownership:** hz=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: uses module-level state (updNs).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `setMaxCatchUp`

```fac
public function void setMaxCatchUp(int n)
```

- **Returns:** Nothing.
- **Ownership:** n=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: uses module-level state (maxCatch).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `quit`

```fac
public function void quit() { stopFlag = true }
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (stopFlag).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `quitting`

```fac
public function boolean quitting() { return stopFlag }
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (stopFlag).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `dt`

```fac
public function double dt() { return cast(Double, updNs) / 1000000000.0 }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (updNs).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `alpha`

```fac
public function double alpha() { return alphaValue }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (alphaValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `elapsed`

```fac
public function double elapsed() { return cast(Double, simNs) / 1000000000.0 }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (simNs).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `frame`

```fac
public function long frame() { return frameNo }
```

- **Returns:** long by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (frameNo).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `updates`

```fac
public function long updates() { return updateCount }
```

- **Returns:** long by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (updateCount).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `fps`

```fac
public function double fps() { return fpsValue }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (fpsValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `droppedNs`

```fac
public function long droppedNs() { return droppedNsValue }
```

- **Returns:** long by value; cumulative simulation time discarded by frame clamping or catch-up limits, in nanoseconds.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads module-level game-loop state.

### `updatesLastFrame`

```fac
public function int updatesLastFrame() { return updatesLastFrameValue }
```

- **Returns:** int by value; fixed updates executed during the most recent stepNs call.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: reads module-level game-loop state.

### `stepNs`

```fac
public function void stepNs(long elapsedNs, function void update(double), function void draw())
```

เดินเกม 1 เฟรม โดยบอกว่าเวลาจริงผ่านไป elapsedNs นาโนวินาที (ใช้ในลูปเอง / เทสต์ / replay แบบกำหนดผล)

- **Returns:** Nothing.
- **Ownership:** elapsedNs=by value; update(double)=borrowed callable; draw()=borrowed callable
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (accNs, alphaValue, droppedNsValue).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `simulate`

```fac
public function void simulate(int frames, int fps, function void update(double), function void draw())
```

เดินเกมแบบกำหนดผลโดยไม่แตะนาฬิกาจริง: frames เฟรม เฟรมละ 1/fps วินาที (เหมาะกับเทสต์/replay/เซิร์ฟเวอร์ไม่มีหน้าต่าง)

- **Returns:** Nothing.
- **Ownership:** frames=by value; fps=by value; update(double)=borrowed callable; draw()=borrowed callable
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: uses module-level state (stopFlag).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `run`

```fac
public function void run(ptr graphic w, int fps, function void update(double), function void draw())
```

ลูปเวลาจริง: poll event -> update (fixed dt, 0..N ครั้ง) -> draw -> present -> หน่วงให้ได้ fps ที่ต้องการ หลับช่วงใหญ่ด้วย time.sleep (ความละเอียด ms) แล้ว spin ช่วงท้ายให้แม่น; ถ้าช้ากว่า 4 เฟรมจะเริ่มนับจังหวะใหม่ ใช้กับ canvas ที่ไม่มีหน้าต่างได้ (graphic.create) -- จบเมื่อเรียก game.quit()

- **Returns:** Nothing.
- **Ownership:** w=non-owning handle, not freed here; fps=by value; update(double)=borrowed callable; draw()=borrowed callable
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: uses module-level state (stopFlag).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
