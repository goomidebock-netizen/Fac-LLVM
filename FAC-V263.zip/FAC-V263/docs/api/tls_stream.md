# `tls_stream` (source library)

Source: `stdlib/tls_stream.fac` · `import tls_stream.fac` · release V263

### `available`

```fac
public function boolean available() { return tls.available() }
```

Optional OpenSSL transport. The native Runtime loads OpenSSL dynamically; importing this source module does not add a link-time dependency. Configure socket timeouts with net.setTimeout before wrapping the TCP socket.

- **Returns:** Whether the optional native OpenSSL backend is available at runtime.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for concurrent availability queries.

### `TlsStream`

```fac
public class TlsStream
```

### `TlsStream.sendBytes`

```fac
public function int sendBytes(list dyn int bytes)
```

- **Returns:** Writes all supplied bytes to the encrypted stream.
- **Ownership:** bytes=borrowed; stream=borrowed.
- **Errors:** Throws Network (11) for TLS/socket failures or Encoding (13) for invalid byte values.
- **Thread-safety:** Native TLS calls serialize per handle; a blocking operation delays other operations. Do not race wrapper close/detach/destruction.

### `TlsStream.send`

```fac
public function int send(string text)
```

- **Returns:** Encodes a UTF-8 string and writes its bytes to the encrypted stream.
- **Ownership:** text=borrowed.
- **Errors:** Throws Network (11), Encoding (13).
- **Thread-safety:** Native TLS calls serialize per handle; a blocking operation delays other operations. Do not race wrapper close/detach/destruction.

### `TlsStream.recvExactBytes`

```fac
public function list dyn int recvExactBytes(int count)
```

- **Returns:** Reads exactly count bytes from the encrypted stream.
- **Ownership:** result=owned byte list.
- **Errors:** Throws Network (11) on timeout, TLS error, close_notify or truncated input.
- **Thread-safety:** Native TLS calls serialize per handle; a blocking operation delays other operations. Do not race wrapper close/detach/destruction.

### `TlsStream.recvLineStrict`

```fac
public function string recvLineStrict()
```

- **Returns:** Reads one CRLF-terminated UTF-8 line (without CRLF), up to 1 MiB.
- **Ownership:** result=owned string.
- **Errors:** Throws Network (11), Parse (10) for malformed line endings, or Encoding (13) for invalid UTF-8.
- **Thread-safety:** Native TLS calls serialize per handle; a blocking operation delays other operations. Do not race wrapper close/detach/destruction.

### `TlsStream.version`

```fac
public function string version() { this.requireOpen(); return tls.version(this.handle) }
```

- **Returns:** Negotiated protocol name (normally TLSv1.2 or TLSv1.3).
- **Ownership:** result=owned string.
- **Errors:** Throws Network (11) after close.
- **Thread-safety:** Native metadata queries serialize per handle; do not race wrapper close/detach/destruction.

### `TlsStream.cipher`

```fac
public function string cipher() { this.requireOpen(); return tls.cipher(this.handle) }
```

- **Returns:** Negotiated cipher suite name.
- **Ownership:** result=owned string.
- **Errors:** Throws Network (11) after close.
- **Thread-safety:** Native metadata queries serialize per handle; do not race wrapper close/detach/destruction.

### `TlsStream.isOpen`

```fac
public function boolean isOpen() { return this.active }
```

- **Returns:** Whether this TLS stream remains open.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Read-only wrapper-field query; not synchronized with close/detach/destruction.

### `TlsStream.detach`

```fac
public function ptr socket detach()
```

- **Returns:** Transfers the native TLS handle out of this object for use by a transport such as WebSocketConnection.
- **Ownership:** consumes this object's native handle; the caller becomes the sole owner and must close it.
- **Errors:** Throws Network (11) when already closed.
- **Thread-safety:** Do not race with I/O, close, or destruction; the native handle itself serializes close after in-flight operations.

### `TlsStream.close`

```fac
public function void close()
```

- **Returns:** Closes TLS and the owned TCP socket; safe to call repeatedly.
- **Ownership:** consumes this stream's native handle.
- **Errors:** None.
- **Thread-safety:** Do not race with I/O, close, or destruction; the native handle itself serializes close after in-flight operations.
