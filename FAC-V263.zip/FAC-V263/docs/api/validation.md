# `validation` (source library)

Source: `stdlib/validation.fac` · `import validation.fac` · release V263

### `Validator`

```fac
public class Validator
```

Validator accumulates field-level validation failures. It intentionally offers scalar/string rules rather than claiming full RFC/JSON-Schema support.

### `Validator.required`

```fac
public function boolean required(string field, string value)
```

- **Returns:** True when value contains non-whitespace text; otherwise records a failure.
- **Ownership:** field/value=borrowed.
- **Errors:** None; failures are accumulated.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.minLength`

```fac
public function boolean minLength(string field, string value, int minimum)
```

- **Returns:** True when value has at least minimum grapheme units.
- **Ownership:** field/value=borrowed; minimum=by value.
- **Errors:** Throws InvalidArgument (4) when minimum is negative.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.maxLength`

```fac
public function boolean maxLength(string field, string value, int maximum)
```

- **Returns:** True when value has at most maximum grapheme units.
- **Ownership:** field/value=borrowed; maximum=by value.
- **Errors:** Throws InvalidArgument (4) when maximum is negative.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.integer`

```fac
public function boolean integer(string field, string value)
```

- **Returns:** True when value parses as a signed 64-bit integer.
- **Ownership:** field/value=borrowed.
- **Errors:** None; parse errors become accumulated validation failures.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.number`

```fac
public function boolean number(string field, string value)
```

- **Returns:** True when value parses as a finite FAC double.
- **Ownership:** field/value=borrowed.
- **Errors:** None; parse errors become accumulated validation failures.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.oneOf`

```fac
public function boolean oneOf(string field, string value, list dyn string allowed)
```

- **Returns:** True when value is in the supplied allowed list.
- **Ownership:** field/value/allowed=borrowed (read-only).
- **Errors:** None; a miss becomes an accumulated validation failure.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.emailLike`

```fac
public function boolean emailLike(string field, string value)
```

- **Returns:** True for a conservative email-like value (one @, non-empty sides, dot in domain, no whitespace).
- **Ownership:** field/value=borrowed.
- **Errors:** None; this is a practical form check, not full RFC validation or mailbox verification.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.clear`

```fac
public function void clear() { this.failures.clear() }
```

- **Returns:** Removes all accumulated failures.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `Validator.errorCount`

```fac
public function int errorCount() { return sizeof(this.failures) }
```

- **Returns:** Number of accumulated failures.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable validator.

### `Validator.valid`

```fac
public function boolean valid() { return sizeof(this.failures) == 0 }
```

- **Returns:** True when no failures have been recorded.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable validator.

### `Validator.errors`

```fac
public function list dyn string errors()
```

- **Returns:** A shallow copy of accumulated failure messages.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable validator.

### `Validator.errorAt`

```fac
public function string errorAt(int index) { return this.failures[index] }
```

- **Returns:** Failure at zero-based index.
- **Ownership:** result=owned string.
- **Errors:** Throws IndexOutOfRange (2) for an invalid index.
- **Thread-safety:** Safe for a stable validator.
