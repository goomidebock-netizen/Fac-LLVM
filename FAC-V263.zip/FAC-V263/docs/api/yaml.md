# `yaml` (source library)

Source: `stdlib/yaml.fac` · `import yaml.fac` · release V263

### `YamlDocument`

```fac
public class YamlDocument
```

YamlDocument accepts a safe, intentionally small YAML mapping subset. Supported: block mappings with at most one nested mapping level, scalar strings, signed integers, booleans, full-line comments and simple quoted scalars. Sequences, anchors, tags, aliases, flow collections, block scalars and directives are rejected.

### `YamlDocument.has`

```fac
public function boolean has(string path) { return this.values.has(path) }
```

- **Returns:** True when a flattened mapping path exists (for example "server.port").
- **Ownership:** path=borrowed.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `YamlDocument.getRaw`

```fac
public function string getRaw(string path, string fallback = "") { return this.values.getOr(path, fallback) }
```

- **Returns:** Raw scalar spelling or fallback.
- **Ownership:** arguments=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `YamlDocument.getString`

```fac
public function string getString(string path, string fallback = "")
```

- **Returns:** Scalar text with one matching quote pair removed.
- **Ownership:** arguments=borrowed; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `YamlDocument.getInt`

```fac
public function long getInt(string path, long fallback = 0)
```

- **Returns:** Parsed signed integer or fallback.
- **Ownership:** arguments=borrowed; fallback=result by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `YamlDocument.getBoolean`

```fac
public function boolean getBoolean(string path, boolean fallback = false)
```

- **Returns:** Parsed boolean or fallback.
- **Ownership:** arguments=borrowed; fallback=result by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable document.

### `YamlDocument.clear`

```fac
public function void clear() { this.values.clear() }
```

- **Returns:** Removes all mappings.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `YamlDocument.parse`

```fac
public function boolean parse(string text)
```

- **Returns:** Parses a basic YAML block mapping. Duplicate paths use the last value.
- **Ownership:** text=borrowed; stored values=owned.
- **Errors:** Returns false for unsupported or malformed syntax; values before failure remain.
- **Thread-safety:** Not thread-safe when shared mutably.
