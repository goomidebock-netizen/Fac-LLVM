# `json`

JSON encode/decode (typed) and DOM tree API.

- Status: **stable**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 28 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `json.array()` → handle | no direct throw site | result: owned by caller (release with `json.free`) |
| `json.at(handle, long)` → handle | throws `Error` (code 2 IndexOutOfRange, 10 Json) | args: #1 borrowed-handle; result: borrowed view — view into the parent tree; valid until the parent root is freed; never free it |
| `json.bool(handle)` → boolean | throws `Error` (code 10 Json) | args: #1 borrowed-handle |
| `json.compact(string)` → string | throws `Error` (code 10 Json) | args: #1 borrowed; result: owned by caller |
| `json.decode(Type, string json)` → T | see note | owned; Throws (code 10) on malformed or mismatching input. |
| `json.encode(value)` → string | see note | owned; Throws (code 10) for unsupported types. |
| `json.float(handle)` → double | throws `Error` (code 10 Json) | args: #1 borrowed-handle |
| `json.free(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the whole tree rooted at the node |
| `json.get(handle, string)` → handle | throws `Error` (code 10 Json) | args: #1 borrowed-handle, #2 borrowed; result: borrowed view — view into the parent tree; valid until the parent root is freed or the key is replaced; never free it |
| `json.has(handle, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle, #2 borrowed |
| `json.int(handle)` → long | throws `Error` (code 10 Json) | args: #1 borrowed-handle |
| `json.keys(handle)` → list<string> | no direct throw site | args: #1 borrowed-handle; result: owned by caller |
| `json.kind(handle)` → string | no direct throw site | args: #1 borrowed-handle; result: owned by caller |
| `json.len(handle)` → long | no direct throw site | args: #1 borrowed-handle |
| `json.newBool(int)` → handle | no direct throw site | result: owned by caller (release with `json.free`) |
| `json.newFloat(double)` → handle | no direct throw site | result: owned by caller (release with `json.free`) |
| `json.newInt(long)` → handle | no direct throw site | result: owned by caller (release with `json.free`) |
| `json.newNull()` → handle | no direct throw site | result: owned by caller (release with `json.free`) |
| `json.newStr(string)` → handle | no direct throw site | args: #1 borrowed; result: owned by caller (release with `json.free`) |
| `json.object()` → handle | no direct throw site | result: owned by caller (release with `json.free`) |
| `json.parse(string)` → handle | throws `Error` (code 10 Json) | args: #1 borrowed; result: owned by caller (release with `json.free`) |
| `json.pretty(string)` → string | throws `Error` (code 10 Json) | args: #1 borrowed; result: owned by caller |
| `json.push(handle, handle)` → void | throws `Error` (code 10 Json) + OOM | args: #1 borrowed-handle, #2 consumed; the child node becomes owned by the parent array |
| `json.set(handle, string, handle)` → void | throws `Error` (code 10 Json) + OOM | args: #1 borrowed-handle, #2 borrowed, #3 consumed; the child node becomes owned by the parent object; a replaced old child is freed |
| `json.str(handle)` → string | throws `Error` (code 10 Json) | args: #1 borrowed-handle; result: owned by caller |
| `json.stringify(handle)` → string | throws `Error` (code 10 Json) | args: #1 borrowed-handle; result: owned by caller |
| `json.stringifyPretty(handle)` → string | throws `Error` (code 10 Json) | args: #1 borrowed-handle; result: owned by caller |
| `json.valid(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed |

_Parameter names are not part of the built-in contract; positional types are shown._
