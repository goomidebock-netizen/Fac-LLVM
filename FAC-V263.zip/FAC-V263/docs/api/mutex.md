# `mutex`

Mutex methods (provider module: thread).

- Status: **stable**
- Thread-safety: **safe (atomic)**
- Entries: 2 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `mutex.lock(mutex)` → void | no direct throw site | args: #1 borrowed-handle |
| `mutex.unlock(mutex)` → void | no direct throw site | args: #1 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
