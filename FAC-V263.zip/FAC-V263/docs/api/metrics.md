# `metrics`

Regression and binary-classification evaluation metrics including balanced accuracy and log loss.

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 15 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `metrics.accuracy(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Binary classification metric: values >= 0.5 are treated as positive labels. |
| `metrics.balancedAccuracy(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Mean of binary recall and specificity at threshold 0.5. |
| `metrics.confusionMatrix(handle, handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `metrics.f1(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle |
| `metrics.logLoss(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Binary log loss for exact 0/1 targets; probabilities are clipped to [1e-12,1-1e-12]. |
| `metrics.mae(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Rejects non-finite inputs and throws Error(Math) if the result cannot be represented as finite float64. |
| `metrics.mape(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Mean absolute percentage error in percent; zero target entries are skipped and all-zero targets throw Error(Math). |
| `metrics.maxError(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Maximum absolute prediction error. |
| `metrics.medianAbsoluteError(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Median absolute prediction error. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. |
| `metrics.mse(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Rejects non-finite inputs and throws Error(Math) if the result cannot be represented as finite float64. |
| `metrics.precision(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Binary classification metric: values >= 0.5 are treated as positive labels; returns 0 when no positive predictions exist. |
| `metrics.r2(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle |
| `metrics.recall(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Binary classification metric: values >= 0.5 are treated as positive labels; returns 0 when there are no positive targets. |
| `metrics.rmse(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle |
| `metrics.specificity(handle, handle)` → double | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; Binary classification metric at threshold 0.5; returns 0 when there are no negative targets. |

_Parameter names are not part of the built-in contract; positional types are shown._
