# `data`

Numeric CSV ingestion/export, tabular transforms, one-hot encoding and deterministic train/test splitting.

- Status: **stable**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 15 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `data.dropColumn(handle, int)` → handle | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns a copy without the selected column; removing the only column is rejected. |
| `data.freeSplit(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the split handle; extracted tensor copies remain independently owned; Consumes and frees the split handle; extracted tensor copies remain independently owned. |
| `data.loadCSV(string)` → handle | throws `Error` (code 6 NullPointer, 7 Io, 8 Resource, 18 Math) | args: #1 borrowed; result: owned by caller (release with `tensor.free`); Loads a numeric CSV file. CSV rows must be rectangular and contain only finite numeric values; the resulting handle is released with tensor.free. |
| `data.normalize(handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns a new tensor scaled independently per column into [0,1]; constant columns become zero. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. Rejects non-finite input or a normalization result that cannot be represented as finite float64. |
| `data.oneHot(handle, int)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Input labels must be a [N,1] tensor of integer class IDs from 0 through classes-1; classes must be at least 2. |
| `data.parseCSV(string)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed; result: owned by caller (release with `tensor.free`); Parses numeric CSV text with quoted fields. Headers, missing cells, ragged rows and non-finite values are rejected; use a separate preprocessing step for header rows. |
| `data.saveCSV(handle, string)` → void | throws `Error` (code 6 NullPointer, 7 Io, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed |
| `data.selectColumns(handle, int, int)` → handle | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `data.selectRows(handle, int, int)` → handle | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `data.shuffleRows(handle, long)` → void | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle |
| `data.splitTest(handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns an owned copy of the test partition; release with tensor.free. |
| `data.splitTrain(handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns an owned copy of the training partition; release with tensor.free. |
| `data.standardize(handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns a new tensor standardized independently per column using population standard deviation; constant columns become zero. Temporary workspace allocation is guarded by the FAC cleanup stack; allocation or cleanup-stack exhaustion throws Error(Resource), and an in-flight FAC error releases the workspace. Rejects non-finite input or a standardized result that cannot be represented as finite float64. |
| `data.toCSV(handle)` → string | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller |
| `data.trainTestSplit(handle, double, long)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle; result: owned by caller (release with `data.freeSplit`); Returns a split handle with deterministic seeded row shuffling. trainRatio must be in (0,1); each partition contains at least one row. |

_Parameter names are not part of the built-in contract; positional types are shown._
