# `thread`

Threads, cooperative task cancellation, atomics and parallel loops.

- Status: **stable**
- Thread-safety: **safe (atomic)**
- Entries: 30 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `thread.atomicAdd(handle, int)` → int | no direct throw site | args: #1 borrowed-handle; also: `thread.atomicAddSeqCst` |
| `thread.atomicAddAcqRel(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicAddAcquire(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicAddRelaxed(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicAddRelease(handle, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicAddSeqCst(handle, int)` → int | no direct throw site | **alias** of `thread.atomicAdd`; args: #1 borrowed-handle |
| `thread.atomicCas(handle, int, int)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle; also: `thread.atomicCasSeqCst` |
| `thread.atomicCasAcqRel(handle, int, int)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `thread.atomicCasAcquire(handle, int, int)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `thread.atomicCasRelaxed(handle, int, int)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `thread.atomicCasRelease(handle, int, int)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `thread.atomicCasSeqCst(handle, int, int)` → boolean | predicate (never throws on a normal miss) | **alias** of `thread.atomicCas`; args: #1 borrowed-handle |
| `thread.atomicGet(handle)` → int | no direct throw site | args: #1 borrowed-handle; also: `thread.atomicGetSeqCst` |
| `thread.atomicGetAcquire(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicGetRelaxed(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicGetSeqCst(handle)` → int | no direct throw site | **alias** of `thread.atomicGet`; args: #1 borrowed-handle |
| `thread.atomicSet(handle, int)` → void | no direct throw site | args: #1 borrowed-handle; also: `thread.atomicSetSeqCst` |
| `thread.atomicSetRelaxed(handle, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicSetRelease(handle, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `thread.atomicSetSeqCst(handle, int)` → void | no direct throw site | **alias** of `thread.atomicSet`; args: #1 borrowed-handle |
| `thread.cancel(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle; Requests cooperative cancellation for a live thread.start task. Returns true when the request is accepted; it does not forcibly terminate the worker. The caller must serialize handle queries/cancel with the consuming thread.join call. |
| `thread.cancelled()` → boolean | predicate (never throws on a normal miss) | Called inside a thread.start callback to poll its cancellation request. Returns false outside a thread.start worker. A task is marked cancelled only when the callback observes the request and returns without raising an error. |
| `thread.id()` → long | no direct throw site |  |
| `thread.isCancelled(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle; Returns true only when the worker observed a cancellation request and returned without raising an error. Query before thread.join consumes the handle. |
| `thread.isDone(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle; Returns true after the worker has completed (successfully, with an error, or cooperatively cancelled). The handle remains valid until thread.join consumes it; do not race handle queries with join. |
| `thread.join(handle)` → void | throws `Error` (code 8 Resource) | args: #1 consumed; consumes arg 1: joins and frees the thread handle; Joins and consumes the handle; re-raises worker FAC errors with their original code and maps uncaught C++ callback exceptions to Resource (8). |
| `thread.parallelFor(int, function(int))` → void | throws `Error` (code 6 NullPointer, 8 Resource) | args: #2 borrowed-callable |
| `thread.sleep(long)` → void | no direct throw site | **alias** of `time.sleep` |
| `thread.start(function())` → handle | throws `Error` (code 6 NullPointer, 7 Io, 8 Resource) + OOM | args: #1 borrowed-callable; result: owned by caller (release with `thread.join`); Rejects null closures/entry points; worker FAC and C++ callback failures are saved on the returned handle and re-raised by thread.join. |
| `thread.yield()` → void | no direct throw site |  |

_Parameter names are not part of the built-in contract; positional types are shown._
