# `sqlite` (source library)

Source: `stdlib/sqlite.fac` · `import sqlite.fac` · release V263

### `available`

```fac
public function boolean available()
```

- **Returns:** True when a compatible SQLite shared library can be loaded.
- **Ownership:** result=by value.
- **Errors:** None; loader diagnostics are available from Database construction failure.
- **Thread-safety:** Safe; initialization is process-wide and one-time.

### `Database`

```fac
public class Database
```

### `Database.execute`

```fac
public function void execute(string sqlText)
```

- **Returns:** Executes SQL text (including a batch). Use changes() for the last DML row count.
- **Ownership:** sqlText=borrowed; connection is used but not consumed.
- **Errors:** Throws Database (19) on SQLite errors; may throw OutOfMemory (5).
- **Thread-safety:** Runtime and SQLite serialize native calls per connection, including close/free; do not interleave logical transactions across threads.

### `Database.prepare`

```fac
public function obj Statement prepare(string sqlText)
```

- **Returns:** Creates an owned prepared Statement retaining shared native connection state; it may finish after Database.close(). Bind user values rather than building SQL by concatenation.
- **Ownership:** sqlText=borrowed; returned Statement owns its native statement handle.
- **Errors:** Throws Database (19) for invalid SQL or Resource (5) on allocation failure.
- **Thread-safety:** Per-connection locking protects native connection state and lifetime; do not share a Statement across threads unless its logical operation sequence is externally coordinated.

### `Database.begin`

```fac
public function void begin() { this.execute("BEGIN IMMEDIATE") }
```

- **Returns:** Begins a write transaction with BEGIN IMMEDIATE.
- **Ownership:** no parameters; connection remains owned by Database.
- **Errors:** Throws Database (19) when a transaction cannot begin.
- **Thread-safety:** Do not interleave separate logical transactions on the same connection across threads.

### `Database.commit`

```fac
public function void commit() { this.execute("COMMIT") }
```

- **Returns:** Commits the current transaction.
- **Ownership:** no parameters.
- **Errors:** Throws Database (19) when SQLite rejects COMMIT.
- **Thread-safety:** Do not interleave separate logical transactions on the same connection across threads.

### `Database.rollback`

```fac
public function void rollback() { this.execute("ROLLBACK") }
```

- **Returns:** Rolls back the current transaction.
- **Ownership:** no parameters.
- **Errors:** Throws Database (19) when SQLite rejects ROLLBACK.
- **Thread-safety:** Do not interleave separate logical transactions on the same connection across threads.

### `Database.setTimeoutMs`

```fac
public function void setTimeoutMs(int timeoutMs)
```

- **Returns:** Changes the connection busy timeout in milliseconds.
- **Ownership:** timeoutMs=by value.
- **Errors:** Throws InvalidArgument (4) outside 0..600000; Database (19) on SQLite failure.
- **Thread-safety:** Native calls are serialized per connection; do not change connection policy during concurrent transactions.

### `Database.changes`

```fac
public function int changes()
```

- **Returns:** Number of rows changed by the most recent INSERT/UPDATE/DELETE on this connection.
- **Ownership:** result=by value.
- **Errors:** None; returns 0 if the connection has been closed.
- **Thread-safety:** Safe for a stable object; native reads are serialized with writes and close, but the returned value reflects the last connection-local operation.

### `Database.lastInsertRowId`

```fac
public function long lastInsertRowId()
```

- **Returns:** Row identifier from the most recent successful INSERT on this connection.
- **Ownership:** result=by value.
- **Errors:** None; returns 0 if the connection has been closed.
- **Thread-safety:** Safe for a stable object; native reads are serialized with writes and close, but the returned value reflects the last connection-local operation.

### `Database.close`

```fac
public function void close()
```

- **Returns:** Closes the connection. SQLite defers final native destruction while outstanding statements remain.
- **Ownership:** consumes the connection handle on success; existing Statements own their own handles.
- **Errors:** Throws Database (19) if sqlite3_close_v2 fails.
- **Thread-safety:** Native handle operations serialize with close/free; prevent racing object destruction or mutation of this Database value with method calls.

### `Database.isOpen`

```fac
public function boolean isOpen() { return this.h != null }
```

- **Returns:** True while this Database object still owns an open connection handle.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `Statement`

```fac
public class Statement
```

### `Statement.bindInt`

```fac
public function void bindInt(int index, long value)
```

- **Returns:** Binds a signed 64-bit integer to a 1-based placeholder index.
- **Ownership:** index/value=by value.
- **Errors:** Throws InvalidArgument (4) for an invalid index; Database (19) when SQLite rejects the binding.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.bindFloat`

```fac
public function void bindFloat(int index, double value)
```

- **Returns:** Binds a double to a 1-based placeholder index.
- **Ownership:** index/value=by value.
- **Errors:** Throws InvalidArgument (4) for an invalid index; Database (19) when SQLite rejects the binding.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.bindText`

```fac
public function void bindText(int index, string value)
```

- **Returns:** Binds a UTF-8 NUL-free string to a 1-based placeholder index.
- **Ownership:** value=borrowed; SQLite copies the value before this call returns.
- **Errors:** Throws InvalidArgument (4) for invalid index; Database (19) on SQLite error; text is capped at 16 MiB.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.bindNull`

```fac
public function void bindNull(int index)
```

- **Returns:** Binds SQL NULL to a 1-based placeholder index.
- **Ownership:** index=by value.
- **Errors:** Throws InvalidArgument (4) for invalid index; Database (19) on SQLite error.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.step`

```fac
public function boolean step()
```

- **Returns:** Advances the statement; true means a row is ready, false means SQLITE_DONE.
- **Ownership:** no parameters; returned column text must be copied before the next step/reset/finalize.
- **Errors:** Throws Database (19) for SQLITE_BUSY, SQLITE_CONSTRAINT and other step errors.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.reset`

```fac
public function void reset()
```

- **Returns:** Resets execution state; bound values are retained as SQLite specifies.
- **Ownership:** no parameters.
- **Errors:** Throws Database (19) when reset reports a prior execution error.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.clearBindings`

```fac
public function void clearBindings()
```

- **Returns:** Clears all bound parameters.
- **Ownership:** no parameters.
- **Errors:** Throws Database (19) when SQLite rejects the operation.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.columnCount`

```fac
public function int columnCount() { this.ensureOpen(); unsafe { return fac_sqlite_column_count(this.h) } }
```

- **Returns:** Number of result columns.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.columnName`

```fac
public function string columnName(int column)
```

- **Returns:** Column name copied into an owned FAC string.
- **Ownership:** column=by value; result=owned string.
- **Errors:** None for a valid column index; invalid index returns empty string.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.columnType`

```fac
public function int columnType(int column) { this.ensureOpen(); unsafe { return fac_sqlite_column_type(this.h, column) } }
```

- **Returns:** SQLite storage class code: INTEGER=1, FLOAT=2, TEXT=3, BLOB=4, NULL=5.
- **Ownership:** column/result=by value.
- **Errors:** None; invalid column index returns NULL code (5).
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.columnInt`

```fac
public function long columnInt(int column) { this.ensureOpen(); unsafe { return fac_sqlite_column_int64(this.h, column) } }
```

- **Returns:** Column converted to signed 64-bit integer using SQLite conversion rules.
- **Ownership:** column=by value.
- **Errors:** None; out-of-range column returns 0.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.columnFloat`

```fac
public function double columnFloat(int column) { this.ensureOpen(); unsafe { return fac_sqlite_column_double(this.h, column) } }
```

- **Returns:** Column converted to double using SQLite conversion rules.
- **Ownership:** column=by value.
- **Errors:** None; out-of-range column returns 0.0.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.columnText`

```fac
public function string columnText(int column)
```

- **Returns:** Column converted to an owned FAC string; SQL NULL maps to empty string.
- **Ownership:** column=by value; result=owned string.
- **Errors:** None; out-of-range/NULL returns empty string. Embedded NUL text is not preserved by this string API.
- **Thread-safety:** Copy the returned FAC string before advancing; native column access is serialized, but multi-call row consumption requires external sequencing.

### `Statement.columnBytes`

```fac
public function int columnBytes(int column) { this.ensureOpen(); unsafe { return fac_sqlite_column_bytes(this.h, column) } }
```

- **Returns:** Byte length of a text/blob column as reported by SQLite.
- **Ownership:** column/result=by value.
- **Errors:** None; invalid column returns 0.
- **Thread-safety:** Native calls serialize per connection; do not concurrently interleave a multi-call bind/step/reset sequence on one Statement.

### `Statement.close`

```fac
public function void close()
```

- **Returns:** Finalizes the native statement. Repeated calls are harmless.
- **Ownership:** consumes the statement handle.
- **Errors:** Throws Database (19) if SQLite returns an error while finalizing.
- **Thread-safety:** Native finalization serializes with in-flight calls; prevent racing destruction of the managed Statement object with method calls.

### `Statement.isOpen`

```fac
public function boolean isOpen() { return this.h != null }
```

- **Returns:** True until the Statement has been finalized.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.
