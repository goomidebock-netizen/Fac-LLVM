# `option` (source library)

Source: `stdlib/option.fac` · `import option.fac` · release V263

### `OptionTools`

```fac
public class OptionTools<T>
```

Utility methods for the native Option<T> payload enum. The enum itself remains in result.fac; this module adds common inspection and fallback operations.

### `OptionTools.isSome`

```fac
public function boolean isSome(enum Option<T> value)
```

- **Returns:** True when the value is Some.
- **Ownership:** value=borrowed (read-only).
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `OptionTools.isNone`

```fac
public function boolean isNone(enum Option<T> value) { return !this.isSome(value) }
```

- **Returns:** True when the value is None.
- **Ownership:** value=borrowed (read-only).
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `OptionTools.unwrapOr`

```fac
public function T unwrapOr(enum Option<T> value, T fallback)
```

- **Returns:** The Some payload, or fallback for None.
- **Ownership:** value=borrowed (read-only); fallback=by value; result=by value or owned payload.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `OptionTools.unwrap`

```fac
public function T unwrap(enum Option<T> value)
```

- **Returns:** The Some payload.
- **Ownership:** value=borrowed (read-only); result=owned payload value.
- **Errors:** Throws Error code 4 when value is None.
- **Thread-safety:** Safe-pure.
