# `three`

Software 3D rasterizer: camera controls, projection, points, lines, triangles, cubes, spheres, planes and grids.

- Status: **basic**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 16 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `three.begin(handle, handle)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.camera(double, double, double, double, double, double)` → handle | throws `Error` (code 14 Media) | result: owned by caller (release with `three.free`) |
| `three.cube(handle, handle, double, double, double, double, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.free(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the camera |
| `three.grid(handle, handle, double, double, double, double, int, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle, #2 borrowed-handle; Draws a square XZ grid at constant Y; divisions must be 1..256. |
| `three.line(handle, handle, double, double, double, double, double, double, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.moveCamera(handle, double, double, double)` → void | throws `Error` (code 6 NullPointer, 14 Media) | args: #1 borrowed-handle; Moves the camera by a world-space delta; coordinates must remain finite. |
| `three.plane(handle, handle, double, double, double, double, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle, #2 borrowed-handle; Draws a square in the XY plane at constant Z; size must be positive and finite. |
| `three.point(handle, handle, double, double, double, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.projectDepth(handle, handle, double, double, double)` → double | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.projectX(handle, handle, double, double, double)` → int | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.projectY(handle, handle, double, double, double)` → int | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `three.rotateCamera(handle, double, double)` → void | throws `Error` (code 6 NullPointer, 14 Media) | args: #1 borrowed-handle; Adds yaw/pitch deltas in radians; pitch is clamped to approximately +/-89 degrees. |
| `three.setFov(handle, double)` → void | throws `Error` (code 6 NullPointer, 14 Media) | args: #1 borrowed-handle; Sets perspective field of view in degrees, within 1..179. |
| `three.sphere(handle, handle, double, double, double, double, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle, #2 borrowed-handle; Draws a UV-tessellated sphere using 16 slices and 10 stacks into the software canvas depth buffer. |
| `three.triangle(handle, handle, double, double, double, double, double, double, double, double, double, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
