# `render` (source library)

Source: `stdlib/render.fac` · `import render.fac` · release V263

### `clear`

```fac
public function void clear(ptr graphic c, int color) { graphic.clear(c, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `pixel`

```fac
public function void pixel(ptr graphic c, int x, int y, int color) { graphic.pixel(c, x, y, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `line`

```fac
public function void line(ptr graphic c, int x1, int y1, int x2, int y2, int color) { graphic.line(c, x1, y1, x2, y2, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x1=by value; y1=by value; x2=by value; y2=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `rect`

```fac
public function void rect(ptr graphic c, int x, int y, int w, int h, int color) { graphic.rect(c, x, y, w, h, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `fillRect`

```fac
public function void fillRect(ptr graphic c, int x, int y, int w, int h, int color) { graphic.fillRect(c, x, y, w, h, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `circle`

```fac
public function void circle(ptr graphic c, int x, int y, int r, int color) { graphic.circle(c, x, y, r, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; r=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `fillCircle`

```fac
public function void fillCircle(ptr graphic c, int x, int y, int r, int color) { graphic.fillCircle(c, x, y, r, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; r=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `fillTriangle`

```fac
public function void fillTriangle(ptr graphic c, int x1, int y1, int x2, int y2, int x3, int y3, int color) { graphic.fillTriangle(c, x1, y1, x2, y2, x3, y3, color) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x1=by value; y1=by value; x2=by value; y2=by value; x3=by value; y3=by value; color=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `text`

```fac
public function void text(ptr graphic c, int x, int y, string value, int color, int scale) { graphic.text(c, x, y, value, color, scale) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; x=by value; y=by value; value=borrowed (immutable, shared); color=by value; scale=by value
- **Errors:** Can throw: propagates Error from graphic.text.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `measureText`

```fac
public function int measureText(string value, int scale) { return graphic.textWidth(value, scale) }
```

- **Returns:** int by value.
- **Ownership:** value=borrowed (immutable, shared); scale=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `image`

```fac
public function void image(ptr graphic c, ptr graphic source, int x, int y, int w, int h) { graphic.blitScaled(c, source, x, y, w, h) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; x=by value; y=by value; w=by value; h=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `present`

```fac
public function void present(ptr graphic c) { graphic.present(c) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `blit`

```fac
public function void blit(ptr graphic c, ptr graphic source, int x, int y) { graphic.blit(c, source, x, y) }
```

Image composition operations exposed by the same renderer boundary.

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; x=by value; y=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `blitKey`

```fac
public function void blitKey(ptr graphic c, ptr graphic source, int x, int y, int colorKey) { graphic.blitKey(c, source, x, y, colorKey) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; x=by value; y=by value; colorKey=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `blitAlpha`

```fac
public function void blitAlpha(ptr graphic c, ptr graphic source, int x, int y) { graphic.blitAlpha(c, source, x, y) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; x=by value; y=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `blitRegion`

```fac
public function void blitRegion(ptr graphic c, ptr graphic source, int sx, int sy, int sw, int sh, int dx, int dy) { graphic.blitRegion(c, source, sx, sy, sw, sh, dx, dy) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; sx=by value; sy=by value; sw=by value; sh=by value; dx=by value; dy=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `blitRegionEx`

```fac
public function void blitRegionEx(ptr graphic c, ptr graphic source, int dx, int dy, int sx, int sy, int sw, int sh, int flags) { graphic.blitRegionEx(c, source, dx, dy, sx, sy, sw, sh, flags) }
```

- **Returns:** Nothing.
- **Ownership:** c=non-owning handle, not freed here; source=non-owning handle, not freed here; dx=by value; dy=by value; sx=by value; sy=by value; sw=by value; sh=by value; flags=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `hasAlpha`

```fac
public function int hasAlpha(ptr graphic source) { return graphic.hasAlpha(source) }
```

- **Returns:** int by value.
- **Ownership:** source=non-owning handle, not freed here
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.

### `alphaAt`

```fac
public function int alphaAt(ptr graphic source, int x, int y) { return graphic.alphaAt(source, x, y) }
```

- **Returns:** int by value.
- **Ownership:** source=non-owning handle, not freed here; x=by value; y=by value
- **Errors:** None: does not throw.
- **Thread-safety:** The graphic backend serializes operations on live Canvas handles; callers must not free a handle while an operation is running.
