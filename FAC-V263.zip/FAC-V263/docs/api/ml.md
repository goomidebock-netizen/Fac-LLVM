# `ml`

CPU linear/ridge/logistic regression, k-means and k-nearest-neighbor classification. Fully fitted immutable models support concurrent read-only prediction; callers must synchronize model/input lifetimes and must not race prediction with mutation or release.

- Status: **basic**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 16 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `ml.freeKMeans(handle)` → void | no direct throw site | args: #1 borrowed-handle |
| `ml.freeKNN(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees a k-nearest-neighbor model handle; Consumes and frees a kNN model handle. |
| `ml.freeModel(handle)` → void | no direct throw site | args: #1 borrowed-handle |
| `ml.kmeans(handle, int, int, long)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) + OOM | args: #1 borrowed-handle; result: owned by caller (release with `ml.freeKMeans`); CPU k-means with seeded shuffled-row initialization and Euclidean distance; empty clusters keep their previous center. |
| `ml.kmeansCenters(handle)` → handle | throws `Error` (code 6 NullPointer) | args: #1 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `ml.kmeansPredict(handle, handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `ml.knnFit(handle, handle, int)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `ml.freeKNN`); Creates a CPU k-nearest-neighbor classifier from X[N,F], y[N,1], with 1 <= k <= N. Labels are numeric; ties choose the smallest numeric label. |
| `ml.knnPredict(handle, handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 14 Media, 18 Math) + OOM | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `tensor.free`); Returns a [query_rows,1] tensor of majority-vote class labels; release with tensor.free. |
| `ml.linearBias(handle)` → double | throws `Error` (code 6 NullPointer) | args: #1 borrowed-handle |
| `ml.linearFit(handle, handle, double, int)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) + OOM | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `ml.freeModel`); Batch gradient descent for least-squares linear regression; expects X[N,F] and y[N,1]. Uses no intercept regularization. |
| `ml.linearPredict(handle, handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `tensor.free`); also: `ml.logisticPredict` |
| `ml.linearWeight(handle, int)` → double | throws `Error` (code 2 IndexOutOfRange, 6 NullPointer) | args: #1 borrowed-handle |
| `ml.logisticClassify(handle, handle, double)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `ml.logisticFit(handle, handle, double, int)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) + OOM | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `ml.freeModel`); Batch gradient descent for binary logistic regression; labels must be exactly 0 or 1. logisticPredict returns probabilities. |
| `ml.logisticPredict(handle, handle)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) | **alias** of `ml.linearPredict`; args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `tensor.free`) |
| `ml.ridgeFit(handle, handle, double, int, double)` → handle | throws `Error` (code 6 NullPointer, 8 Resource, 18 Math) + OOM | args: #1 borrowed-handle, #2 borrowed-handle; result: owned by caller (release with `ml.freeModel`); Batch-gradient-descent ridge regression with L2 penalty lambda on weights only; intercept is not regularized. Returns a model released by ml.freeModel. |

_Parameter names are not part of the built-in contract; positional types are shown._
