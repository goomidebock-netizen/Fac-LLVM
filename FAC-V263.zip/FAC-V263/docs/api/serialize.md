# `serialize` (source library)

Source: `stdlib/serialize.fac` · `import serialize.fac` · release V263

### `BinaryWriter`

```fac
public class BinaryWriter
```

### `BinaryWriter.begin`

```fac
public function void begin(string schemaId, int version = 1)
```

- **Returns:** Starts a FACB version-1 stream and records the caller's schema identifier.
- **Ownership:** schemaId=borrowed; writer retains only encoded bytes.
- **Errors:** Throws InvalidArgument (4) for invalid schema/version; Resource (8) above 64 MiB.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.beginV2`

```fac
public function void beginV2(string schemaId, int schemaVersion = 1)
```

- **Returns:** Starts a FACB version-2 stream with a schema version and CRC32 trailer.
- **Ownership:** schemaId=borrowed; writer retains only encoded bytes.
- **Errors:** Throws InvalidArgument (4) for invalid schema/version; Resource (8) above 64 MiB.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.beginRecord`

```fac
public function void beginRecord(string typeName, int fieldCount)
```

- **Returns:** Starts a named record with an explicit fixed field count. Fields must be written in schema order.
- **Ownership:** typeName=borrowed; encoded name and fields are copied into the writer.
- **Errors:** Throws InvalidArgument (4) for invalid state/name/count; Resource (8) above 64 MiB.
- **Thread-safety:** Not thread-safe. Nested records are not supported.

### `BinaryWriter.endRecord`

```fac
public function void endRecord()
```

- **Returns:** Completes the active record after exactly the declared number of fields.
- **Ownership:** no parameters.
- **Errors:** Throws InvalidArgument (4) when no record is active or field count differs.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldByte`

```fac
public function void writeFieldByte(string name, int value)
```

- **Returns:** Writes a named record field containing a byte value.
- **Ownership:** name=borrowed; value=by value.
- **Errors:** Throws Encoding (13) outside [0,255]; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldBoolean`

```fac
public function void writeFieldBoolean(string name, boolean value)
```

- **Returns:** Writes a named record field containing a boolean.
- **Ownership:** name=borrowed; value=by value.
- **Errors:** Throws InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldI32`

```fac
public function void writeFieldI32(string name, long value)
```

- **Returns:** Writes a named record field containing a signed Int32.
- **Ownership:** name=borrowed; value=by value.
- **Errors:** Throws IntegerOverflow (17) outside Int32 range; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldI64`

```fac
public function void writeFieldI64(string name, long value)
```

- **Returns:** Writes a named record field containing a signed Int64.
- **Ownership:** name=borrowed; value=by value.
- **Errors:** Throws InvalidArgument (4) for record state/name; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldF32`

```fac
public function void writeFieldF32(string name, float value)
```

- **Returns:** Writes a named record field containing IEEE-754 binary32.
- **Ownership:** name=borrowed; value=by value.
- **Errors:** Throws InvalidArgument (4) for record state/name; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldF64`

```fac
public function void writeFieldF64(string name, double value)
```

- **Returns:** Writes a named record field containing IEEE-754 binary64.
- **Ownership:** name=borrowed; value=by value.
- **Errors:** Throws InvalidArgument (4) for record state/name; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldString`

```fac
public function void writeFieldString(string name, string value)
```

- **Returns:** Writes a named record field containing a UTF-8 string.
- **Ownership:** name/value=borrowed; encoded bytes are copied into the writer.
- **Errors:** Throws Encoding (13) above 16 MiB; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldBytes`

```fac
public function void writeFieldBytes(string name, list dyn int value)
```

- **Returns:** Writes a named record field containing length-prefixed bytes.
- **Ownership:** name/value=borrowed; bytes are copied into the writer.
- **Errors:** Throws Encoding (13) for invalid/oversized bytes; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldI32List`

```fac
public function void writeFieldI32List(string name, list dyn int values)
```

- **Returns:** Writes a named Int32 list field (count followed by little-endian I32 values).
- **Ownership:** name/values=borrowed; encoded values are copied.
- **Errors:** Throws Encoding (13) above 1,048,576 elements; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldStringList`

```fac
public function void writeFieldStringList(string name, list dyn string values)
```

- **Returns:** Writes a named UTF-8 string-list field.
- **Ownership:** name/values=borrowed; encoded strings are copied.
- **Errors:** Throws Encoding (13) above 1,048,576 elements; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeFieldStringMap`

```fac
public function void writeFieldStringMap(string name, hashmap dyn string, string values)
```

- **Returns:** Writes a named string-to-string map field with lexicographically sorted keys.
- **Ownership:** name/values=borrowed; encoded keys and values are copied.
- **Errors:** Throws Encoding (13) above 262,144 entries; InvalidArgument (4) for record state/name.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeByte`

```fac
public function void writeByte(int value)
```

- **Returns:** Appends one unsigned byte.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,255]; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeBoolean`

```fac
public function void writeBoolean(boolean value)
```

- **Returns:** Appends a boolean as exactly 0 or 1.
- **Ownership:** value=by value.
- **Errors:** Throws Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeU16`

```fac
public function void writeU16(int value)
```

- **Returns:** Appends an unsigned 16-bit integer in little-endian order.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,65535]; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeU32`

```fac
public function void writeU32(long value)
```

- **Returns:** Appends an unsigned 32-bit integer in little-endian order.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,4294967295]; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeI32`

```fac
public function void writeI32(long value)
```

- **Returns:** Appends a signed 32-bit integer using two's-complement little-endian encoding.
- **Ownership:** value=by value.
- **Errors:** Throws IntegerOverflow (17) outside Int32 range; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeI64`

```fac
public function void writeI64(long value)
```

- **Returns:** Appends a signed 64-bit integer as its two's-complement bit pattern, little-endian.
- **Ownership:** value=by value.
- **Errors:** Throws Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeF32`

```fac
public function void writeF32(float value)
```

- **Returns:** Appends an IEEE-754 binary32 value in little-endian order.
- **Ownership:** value=by value.
- **Errors:** Throws Resource (8) above stream limit; NaN is canonicalized and signed zero is preserved.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeF64`

```fac
public function void writeF64(double value)
```

- **Returns:** Appends an IEEE-754 binary64 value in little-endian order.
- **Ownership:** value=by value.
- **Errors:** Throws Resource (8) above stream limit; NaN is canonicalized and signed zero is preserved.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeI32List`

```fac
public function void writeI32List(list dyn int values)
```

- **Returns:** Appends a bounded count-prefixed list of signed Int32 values.
- **Ownership:** values=borrowed; all elements are copied by value.
- **Errors:** Throws Encoding (13) above 1,048,576 values; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeStringList`

```fac
public function void writeStringList(list dyn string values)
```

- **Returns:** Appends a bounded count-prefixed list of UTF-8 strings.
- **Ownership:** values=borrowed; encoded strings are copied.
- **Errors:** Throws Encoding (13) above 1,048,576 values or per-string limit; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeStringMap`

```fac
public function void writeStringMap(hashmap dyn string, string values)
```

- **Returns:** Appends a bounded string-to-string map with lexicographically sorted keys for deterministic output.
- **Ownership:** values=borrowed; all keys and values are copied.
- **Errors:** Throws Encoding (13) above 262,144 entries or per-string limit; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeString`

```fac
public function void writeString(string value)
```

- **Returns:** Appends a length-prefixed UTF-8 string (U32 byte length, then bytes).
- **Ownership:** value=borrowed; encoded bytes are copied into the writer.
- **Errors:** Throws Encoding (13) above 16 MiB or for conversion errors; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.writeBytes`

```fac
public function void writeBytes(list dyn int value)
```

- **Returns:** Appends a length-prefixed byte list (U32 byte length, then raw bytes).
- **Ownership:** value=borrowed; bytes are copied into the writer.
- **Errors:** Throws Encoding (13) for non-byte values or above 16 MiB; Resource (8) above stream limit.
- **Thread-safety:** Not thread-safe.

### `BinaryWriter.size`

```fac
public function int size()
```

- **Returns:** Number of encoded bytes, including the stream header.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable writer.

### `BinaryWriter.toBytes`

```fac
public function list dyn int toBytes()
```

- **Returns:** An independently owned copy of the completed binary stream.
- **Ownership:** result=owned byte list.
- **Errors:** Throws InvalidArgument (4) if begin() was not called; may throw OutOfMemory (5).
- **Thread-safety:** Safe for a stable writer.

### `BinaryWriter.toFrozenBuffer`

```fac
public function obj ByteBuffer toFrozenBuffer()
```

- **Returns:** Finalizes the stream and exposes its frozen ByteBuffer without copying the encoded bytes.
- **Ownership:** result=shared immutable buffer; the writer and any readers/views retain the same backing storage.
- **Errors:** InvalidArgument (4) when begin() was not called or a record is open; Resource (8) above 64 MiB.
- **Thread-safety:** Not thread-safe while finalizing; safe to share after this returns.
