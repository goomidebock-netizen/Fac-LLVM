# `datetime` (source library)

Source: `stdlib/datetime.fac` · `import datetime.fac` · release V263

### `DateTime`

```fac
public class DateTime
```

DateTime stores Unix epoch milliseconds, matching the built-in time API. Local getters use the machine timezone; UTC formatting is explicit.

### `DateTime.setNow`

```fac
public function void setNow() { this.unixMilliseconds = time.now() }
```

- **Returns:** A DateTime initialized to the current instant.
- **Ownership:** no parameters; object is owned by caller.
- **Errors:** None.
- **Thread-safety:** Safe; reads the system clock.

### `DateTime.toUnixMilliseconds`

```fac
public function long toUnixMilliseconds() { return this.unixMilliseconds }
```

- **Returns:** Unix timestamp in milliseconds.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `DateTime.toUnixSeconds`

```fac
public function long toUnixSeconds()
```

- **Returns:** Containing Unix epoch second, flooring negative sub-second timestamps as well.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `DateTime.yearLocal`

```fac
public function int yearLocal() { return time.year(this.unixMilliseconds) }
```

- **Returns:** Local calendar year in the process timezone.
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.monthLocal`

```fac
public function int monthLocal() { return time.month(this.unixMilliseconds) }
```

- **Returns:** Local calendar month (1..12).
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.dayLocal`

```fac
public function int dayLocal() { return time.day(this.unixMilliseconds) }
```

- **Returns:** Local day of month (1..31).
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.hourLocal`

```fac
public function int hourLocal() { return time.hour(this.unixMilliseconds) }
```

- **Returns:** Local hour in [0,23].
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.minuteLocal`

```fac
public function int minuteLocal() { return time.minute(this.unixMilliseconds) }
```

- **Returns:** Local minute in [0,59].
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.secondLocal`

```fac
public function int secondLocal() { return time.second(this.unixMilliseconds) }
```

- **Returns:** Local second in [0,60].
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.weekdayLocal`

```fac
public function int weekdayLocal() { return time.weekday(this.unixMilliseconds) }
```

- **Returns:** Local weekday where Sunday is 0 and Saturday is 6.
- **Ownership:** no parameters.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.toIsoUtc`

```fac
public function string toIsoUtc() { return time.iso(this.unixMilliseconds) }
```

- **Returns:** ISO-8601 UTC timestamp ending in Z.
- **Ownership:** result=owned string.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Safe for a stable timezone-independent timestamp.

### `DateTime.formatLocal`

```fac
public function string formatLocal(string format) { return time.format(this.unixMilliseconds, format) }
```

- **Returns:** Formatted local-time text using the platform strftime directives.
- **Ownership:** format=borrowed; result=owned string.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Depends on process timezone configuration.

### `DateTime.formatUtc`

```fac
public function string formatUtc(string format) { return time.formatUtc(this.unixMilliseconds, format) }
```

- **Returns:** Formatted UTC text using the platform strftime directives.
- **Ownership:** format=borrowed; result=owned string.
- **Errors:** TimeParse (12) if the timestamp is outside the platform time range.
- **Thread-safety:** Safe for a stable timestamp.

### `DateTime.setUnixMilliseconds`

```fac
public function void setUnixMilliseconds(long value) { this.unixMilliseconds = value }
```

- **Returns:** Replaces this instant with a Unix-millisecond timestamp.
- **Ownership:** value=by value.
- **Errors:** None; range validation occurs when calendar fields are requested.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DateTime.addMilliseconds`

```fac
public function void addMilliseconds(long duration) { this.unixMilliseconds += duration }
```

- **Returns:** Advances this instant by a millisecond duration.
- **Ownership:** duration=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DateTime.addSeconds`

```fac
public function void addSeconds(long duration) { this.unixMilliseconds += duration * 1000 }
```

- **Returns:** Advances this instant by a second duration.
- **Ownership:** duration=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DateTime.addDays`

```fac
public function void addDays(long days) { this.unixMilliseconds += days * 86400000 }
```

- **Returns:** Advances this instant by an elapsed 24-hour duration per day.
- **Ownership:** days=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `isLeapYear`

```fac
public function boolean isLeapYear(int year)
```

- **Returns:** True for Gregorian leap years.
- **Ownership:** year=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `daysInMonth`

```fac
public function int daysInMonth(int year, int month)
```

- **Returns:** Number of days in a Gregorian month, or 0 for an invalid month.
- **Ownership:** year/month=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `isValidDate`

```fac
public function boolean isValidDate(int year, int month, int day)
```

- **Returns:** True when year/month/day form a valid Gregorian calendar date.
- **Ownership:** arguments=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `nowMilliseconds`

```fac
public function long nowMilliseconds() { return time.now() }
```

- **Returns:** Current Unix epoch time in milliseconds (same unit as DateTime and time.now).
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe; reads the system clock.

### `parseUtc`

```fac
public function long parseUtc(string text, string format) { return time.parse(text, format) }
```

- **Returns:** Unix epoch milliseconds parsed from a UTC text value using the supported time format directives.
- **Ownership:** text/format=borrowed; result=by value.
- **Errors:** Throws TimeParse (12) on mismatch or unsupported directives.
- **Thread-safety:** Safe; parsing is timezone-independent.
