# `reflection` (source library)

Source: `stdlib/reflection.fac` · `import reflection.fac` · release V263

### `Reflector`

```fac
public class Reflector<T>
```

Reflector exposes FAC's existing compile-time type/category queries through a generic convenience object. This is not runtime field/member reflection: struct/class names and field metadata are not exposed by the current compiler.

### `Reflector.typeOf`

```fac
public function enum Type typeOf(T value) { return typeof(value) }
```

- **Returns:** Existing Type enum classification for the specialized value type.
- **Ownership:** value=by value; result=enum by value.
- **Errors:** None.
- **Thread-safety:** Safe (compile-time type classification).

### `Reflector.byteSize`

```fac
public function int byteSize(T value) { return type(typeof(value)) }
```

- **Returns:** Size of the type reported by typeof/type; for arrays/lists this is the element type, not total allocation size.
- **Ownership:** value=by value; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe (compile-time type layout query).

### `Reflector.dataStructureOf`

```fac
public function enum DS dataStructureOf(T value) { return DSof(value) }
```

- **Returns:** Existing DS enum classification for supported native collections/aggregates.
- **Ownership:** value=borrowed/read-only; result=enum by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable value.

### `Reflector.typeName`

```fac
public function string typeName(enum Type kind)
```

- **Returns:** Human-readable built-in type name; Struct/Enum do not include declaration names.
- **Ownership:** kind=by value; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe (pure).

### `Reflector.dataStructureName`

```fac
public function string dataStructureName(enum DS kind)
```

- **Returns:** Human-readable collection/data-structure category name.
- **Ownership:** kind=by value; result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe (pure).
