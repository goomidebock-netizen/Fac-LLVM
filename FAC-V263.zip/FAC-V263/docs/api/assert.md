# `assert` (source library)

Source: `stdlib/assert.fac` · `import assert.fac` · release V263

### `that`

```fac
public function void that(boolean condition, string message = "assertion failed")
```

Assertion failures are programmer/test failures and use Runtime error code 4.

- **Returns:** Nothing when condition is true.
- **Ownership:** condition=by value; message=borrowed (immutable, shared).
- **Errors:** Throws Error code 4 when condition is false.
- **Thread-safety:** Safe-pure.

### `equalInt`

```fac
public function void equalInt(int actual, int expected, string message = "integer values differ")
```

- **Returns:** Nothing when actual equals expected.
- **Ownership:** actual/expected=by value.
- **Errors:** Throws Error code 4 when values differ.
- **Thread-safety:** Safe-pure.

### `equalLong`

```fac
public function void equalLong(long actual, long expected, string message = "long values differ")
```

- **Returns:** Nothing when actual equals expected.
- **Ownership:** actual/expected=by value.
- **Errors:** Throws Error code 4 when values differ.
- **Thread-safety:** Safe-pure.

### `equalString`

```fac
public function void equalString(string actual, string expected, string message = "strings differ")
```

- **Returns:** Nothing when actual equals expected.
- **Ownership:** actual/expected=borrowed immutable strings.
- **Errors:** Throws Error code 4 when strings differ.
- **Thread-safety:** Safe-pure.
