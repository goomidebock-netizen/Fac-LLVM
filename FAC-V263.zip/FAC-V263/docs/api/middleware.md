# `middleware` (source library)

Source: `stdlib/middleware.fac` · `import middleware.fac` · release V263

### `MiddlewarePipeline`

```fac
public class MiddlewarePipeline
```

MiddlewarePipeline stores ordered middleware descriptors. The host framework is responsible for resolving names and invoking actual functions/callbacks.

### `MiddlewarePipeline.add`

```fac
public function void add(string name, int priority)
```

- **Returns:** Registers a name/priority pair; duplicate names are rejected.
- **Ownership:** name=borrowed; pipeline retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid or duplicate names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MiddlewarePipeline.remove`

```fac
public function boolean remove(string name)
```

- **Returns:** Removes a descriptor; false if absent.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MiddlewarePipeline.setEnabled`

```fac
public function boolean setEnabled(string name, boolean enabled)
```

- **Returns:** Enables/disables a registered middleware; false when absent.
- **Ownership:** name=borrowed; enabled=by value; result=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `MiddlewarePipeline.isEnabled`

```fac
public function boolean isEnabled(string name)
```

- **Returns:** True when the registered middleware is enabled.
- **Ownership:** name=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable pipeline.

### `MiddlewarePipeline.orderedNames`

```fac
public function list dyn string orderedNames()
```

- **Returns:** A stable, ascending-priority list of enabled middleware names; ties retain registration order.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable pipeline.

### `MiddlewarePipeline.size`

```fac
public function int size() { return sizeof(this.names) }
```

- **Returns:** Number of registered middleware descriptors, including disabled ones.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable pipeline.

### `MiddlewarePipeline.enabledCount`

```fac
public function int enabledCount()
```

- **Returns:** Number of enabled descriptors.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable pipeline.

### `MiddlewarePipeline.clear`

```fac
public function void clear()
```

- **Returns:** Removes every descriptor.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.
