# `terminal`

Console output/input.

- Status: **stable**
- Thread-safety: **unspecified**
- Entries: 14 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `terminal.clear()` → void | no direct throw site |  |
| `terminal.err.print(any...)` → void | see note |  |
| `terminal.err.println(any...)` → void | see note |  |
| `terminal.in.Scanner(Type)` → T | see note |  |
| `terminal.in.eof()` → boolean | predicate (never throws on a normal miss) |  |
| `terminal.in.readAll()` → string | no direct throw site | result: owned by caller |
| `terminal.in.readChar()` → int | no direct throw site |  |
| `terminal.in.readLine()` → string | see note | owned; also: `terminal.in.readline` |
| `terminal.in.readline()` → string | see note | **deprecated** of `terminal.in.readLine` (remove ≥ V47); owned |
| `terminal.out.answer(string prompt, Type)` → T | see note | string results are owned by the caller; also: `terminal.out.anwser` |
| `terminal.out.anwser(string prompt, Type)` → T | see note | **deprecated** of `terminal.out.answer` (remove ≥ V47) |
| `terminal.out.flush()` → void | no direct throw site |  |
| `terminal.out.print(any...)` → void | see note |  |
| `terminal.out.println(any...)` → void | see note | Formats each argument; adds a newline. |

_Parameter names are not part of the built-in contract; positional types are shown._
