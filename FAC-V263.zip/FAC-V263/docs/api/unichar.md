# `unichar`

unichar helpers (provider module: string).

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 1 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `unichar.toInt(unichar)` → int | no direct throw site | **alias** of `char.toInt` |

_Parameter names are not part of the built-in contract; positional types are shown._
