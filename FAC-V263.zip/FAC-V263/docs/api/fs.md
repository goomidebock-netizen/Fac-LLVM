# `fs` (source library)

Source: `stdlib/fs.fac` · `import fs.fac` · release V263

### `FsError`

```fac
public enum FsError
```

### `describe`

```fac
public function string describe(enum FsError err)
```

- **Returns:** Human-readable text of the error (borrowed from the error's payload copy; owned string).
- **Ownership:** err=borrowed (read-only).
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `exists`

```fac
public function boolean exists(string p)
```

- **Returns:** True when the path currently resolves to a file or directory (predicate, never fails).
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: reads the filesystem only; the answer may be stale immediately.

### `isFile`

```fac
public function boolean isFile(string p)
```

- **Returns:** True only when the path currently resolves to a regular file.
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: reads filesystem metadata only; the answer may be stale immediately.

### `isDir`

```fac
public function boolean isDir(string p)
```

- **Returns:** True only when the path currently resolves to a directory.
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: reads filesystem metadata only; the answer may be stale immediately.

### `list`

```fac
public function enum Result<list dyn string, FsError> list(string p)
```

- **Returns:** Ok(sorted list of entry names) or Err(NotFound | Io); entries are names, not joined paths.
- **Ownership:** p=borrowed (immutable, shared); result list and strings are owned by the caller.
- **Errors:** Never throws for I/O failure; failures are returned as FsError.
- **Thread-safety:** Safe for concurrent calls; listing is a snapshot only to the extent provided by the OS.

### `readText`

```fac
public function enum Result<string, FsError> readText(string p)
```

- **Returns:** Ok(owned file contents) or Err(NotFound | Io).
- **Ownership:** p=borrowed (immutable, shared); result string is owned by the caller.
- **Errors:** Never throws for I/O failure; failures are returned as FsError.
- **Thread-safety:** Safe for concurrent calls on different paths; concurrent writers to the same path are not synchronized.

### `readLines`

```fac
public function enum Result<list dyn string, FsError> readLines(string p)
```

- **Returns:** Ok(owned list of lines) or Err(NotFound | Io).
- **Ownership:** p=borrowed (immutable, shared); result list is owned by the caller.
- **Errors:** Never throws for I/O failure; failures are returned as FsError.
- **Thread-safety:** Same as readText.

### `size`

```fac
public function enum Result<long, FsError> size(string p)
```

- **Returns:** Ok(size in bytes) or Err(NotFound | Io).
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** Never throws for I/O failure; failures are returned as FsError.
- **Thread-safety:** Safe: reads metadata only.

### `modified`

```fac
public function enum Result<long, FsError> modified(string p)
```

- **Returns:** Ok(modification time as reported by file.modified) or Err(NotFound | Io).
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** Never throws for I/O failure; failures are returned as FsError.
- **Thread-safety:** Safe: reads metadata only.

### `writeText`

```fac
public function enum Result<boolean, FsError> writeText(string p, string text)
```

- **Returns:** Ok(true) after the file was created/replaced with `text`, or Err(Io).
- **Ownership:** p, text=borrowed (immutable, shared); nothing is retained.
- **Errors:** Never throws for I/O failure; failures are returned as FsError.Io.
- **Thread-safety:** Not synchronized: concurrent writers to one path can interleave.

### `appendText`

```fac
public function enum Result<boolean, FsError> appendText(string p, string text)
```

- **Returns:** Ok(true) after `text` was appended (file created if missing), or Err(Io).
- **Ownership:** p, text=borrowed (immutable, shared); nothing is retained.
- **Errors:** Never throws for I/O failure; failures are returned as FsError.Io.
- **Thread-safety:** Not synchronized: concurrent appenders can interleave.

### `makeDir`

```fac
public function enum Result<boolean, FsError> makeDir(string p)
```

- **Returns:** Ok(true) when the directory (and missing parents) exists afterwards, or Err(Io).
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** Never throws; the built-in status flag is converted to FsError.Io.
- **Thread-safety:** Safe for concurrent calls (the OS arbitrates).

### `rename`

```fac
public function enum Result<boolean, FsError> rename(string from, string to)
```

- **Returns:** Ok(true) after the rename, or Err(NotFound if `from` is missing, otherwise Io).
- **Ownership:** from, to=borrowed (immutable, shared).
- **Errors:** Never throws; the built-in status flag is converted to FsError.
- **Thread-safety:** Safe for concurrent calls on different paths.

### `copy`

```fac
public function enum Result<boolean, FsError> copy(string from, string to)
```

- **Returns:** Ok(true) after the copy, or Err(NotFound if `from` is missing, otherwise Io).
- **Ownership:** from, to=borrowed (immutable, shared).
- **Errors:** Never throws; the built-in status flag is converted to FsError.
- **Thread-safety:** Safe for concurrent calls on different paths.

### `remove`

```fac
public function enum Result<boolean, FsError> remove(string p)
```

- **Returns:** Ok(true) after removal, or Err(NotFound if the path is missing, otherwise Io).
- **Ownership:** p=borrowed (immutable, shared).
- **Errors:** Never throws; the built-in status flag is converted to FsError.
- **Thread-safety:** Safe for concurrent calls on different paths.
