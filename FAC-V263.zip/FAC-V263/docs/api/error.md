# `error` (source library)

Source: `stdlib/error.fac` · `import error.fac` · release V263

### `ErrorTools`

```fac
public class ErrorTools
```

ErrorTools describes the built-in Error value and maps stable Runtime codes to names. Messages remain human-readable; programs should branch on codes.

### `ErrorTools.codeName`

```fac
public function string codeName(int code)
```

- **Returns:** Stable symbolic name for a documented FAC Runtime error code, or "Unknown".
- **Ownership:** code=by value.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `ErrorTools.describe`

```fac
public function string describe(Error value)
```

- **Returns:** A human-readable string containing the symbolic code and message.
- **Ownership:** value=borrowed (read-only); result=owned string.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `ResultTools`

```fac
public class ResultTools<T, E>
```

ResultTools is a convenience layer over result.fac's native Result<T,E> enum.

### `ResultTools.isOk`

```fac
public function boolean isOk(enum Result<T, E> value)
```

- **Returns:** True when the value is Ok.
- **Ownership:** value=borrowed (read-only).
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `ResultTools.isErr`

```fac
public function boolean isErr(enum Result<T, E> value) { return !this.isOk(value) }
```

- **Returns:** True when the value is Err.
- **Ownership:** value=borrowed (read-only).
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `ResultTools.unwrapOr`

```fac
public function T unwrapOr(enum Result<T, E> value, T fallback)
```

- **Returns:** Ok payload, or fallback when Err.
- **Ownership:** value=borrowed (read-only); fallback=by value; result=by value or owned payload.
- **Errors:** None.
- **Thread-safety:** Safe-pure.

### `ResultTools.unwrap`

```fac
public function T unwrap(enum Result<T, E> value)
```

- **Returns:** Ok payload.
- **Ownership:** value=borrowed (read-only); result=owned payload value.
- **Errors:** Throws Error code 4 when value is Err.
- **Thread-safety:** Safe-pure.
