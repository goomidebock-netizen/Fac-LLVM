# `collide` (source library)

Source: `stdlib/collide.fac` · `import collide.fac` · release V263

### `overlapRect`

```fac
public function boolean overlapRect(double ax, double ay, double aw, double ah, double bx, double by, double bw, double bh)
```

- **Returns:** boolean by value.
- **Ownership:** ax=by value; ay=by value; aw=by value; ah=by value; bx=by value; by=by value; bw=by value; bh=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `overlapCircle`

```fac
public function boolean overlapCircle(double ax, double ay, double ar, double bx, double by, double br)
```

- **Returns:** boolean by value.
- **Ownership:** ax=by value; ay=by value; ar=by value; bx=by value; by=by value; br=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `pointInRect`

```fac
public function boolean pointInRect(double px, double py, double x, double y, double w, double h)
```

จุดอยู่ในสี่เหลี่ยม: รวมขอบซ้าย/บน ไม่รวมขอบขวา/ล่าง (ไม่ให้พิกเซล/ไทล์ที่ติดกันนับซ้ำ)

- **Returns:** boolean by value.
- **Ownership:** px=by value; py=by value; x=by value; y=by value; w=by value; h=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `pointInCircle`

```fac
public function boolean pointInCircle(double px, double py, double cx, double cy, double r)
```

- **Returns:** boolean by value.
- **Ownership:** px=by value; py=by value; cx=by value; cy=by value; r=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `circleRect`

```fac
public function boolean circleRect(double cx, double cy, double r, double x, double y, double w, double h)
```

- **Returns:** boolean by value.
- **Ownership:** cx=by value; cy=by value; r=by value; x=by value; y=by value; w=by value; h=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `distance`

```fac
public function double distance(double x1, double y1, double x2, double y2)
```

- **Returns:** double by value.
- **Ownership:** x1=by value; y1=by value; x2=by value; y2=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `separate`

```fac
public function (double, double) separate(double ax, double ay, double aw, double ah, double bx, double by, double bw, double bh)
```

เวกเตอร์เล็กที่สุดที่ต้องเลื่อนสี่เหลี่ยม A เพื่อให้พ้นสี่เหลี่ยม B (minimum translation vector); (0, 0) ถ้าไม่ซ้อนกัน พิจารณา 4 ทิศ (เลื่อนไปซ้าย/ขวา/ขึ้น/ลง) ด้วย "ระยะที่ต้องเลื่อนจริง" แล้วเลือกทิศที่สั้นสุด -- ถูกต้องแม้ B อยู่ในช่วงของ A เท่ากันเลือกตามลำดับ ซ้าย, ขวา, ขึ้น, ลง; ผลเป็น (dx, dy) ที่บวกเข้าตำแหน่งของ A ได้เลย

- **Returns:** Tuple (double,double) by value.
- **Ownership:** ax=by value; ay=by value; aw=by value; ah=by value; bx=by value; by=by value; bw=by value; bh=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `rayRect`

```fac
public function double rayRect(double ox, double oy, double dx, double dy, double x, double y, double w, double h)
```

ยิงรังสีจาก (ox, oy) ทิศ (dx, dy) ใส่สี่เหลี่ยม: คืน t >= 0 ที่รังสีเริ่มเข้าสี่เหลี่ยม (จุดชน = o + t * d) หรือ -1.0 ถ้าไม่โดน จุดเริ่มอยู่ในสี่เหลี่ยมคืน 0.0; การแตะขอบนับเป็นโดน; (dx, dy) = (0, 0) -> คืน 0.0 ถ้าจุดอยู่ในสี่เหลี่ยม (รวมขอบ) ไม่งั้น -1.0

- **Returns:** double by value.
- **Ownership:** ox=by value; oy=by value; dx=by value; dy=by value; x=by value; y=by value; w=by value; h=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `rayCircle`

```fac
public function double rayCircle(double ox, double oy, double dx, double dy, double cx, double cy, double r)
```

ยิงรังสีใส่วงกลม: คืน t >= 0 (จุดชน = origin + t * direction), -1 ถ้าไม่โดน ทิศทางไม่จำเป็นต้อง normalize; ถ้าจุดเริ่มอยู่ใน/บนวงกลม คืน 0; direction เป็นศูนย์และอยู่นอกวงกลม คืน -1

- **Returns:** double by value.
- **Ownership:** ox=by value; oy=by value; dx=by value; dy=by value; cx=by value; cy=by value; r=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `closestPointOnSegment`

```fac
public function (double, double) closestPointOnSegment(double px, double py, double ax, double ay, double bx, double by)
```

จุดบน segment AB ที่ใกล้ P ที่สุด; ถ้า A==B จะคืน A

- **Returns:** Tuple (double,double) by value.
- **Ownership:** px=by value; py=by value; ax=by value; ay=by value; bx=by value; by=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `pointSegmentDistance`

```fac
public function double pointSegmentDistance(double px, double py, double ax, double ay, double bx, double by)
```

ระยะสั้นที่สุดจาก P ถึง segment AB

- **Returns:** double by value.
- **Ownership:** px=by value; py=by value; ax=by value; ay=by value; bx=by value; by=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `segmentRect`

```fac
public function double segmentRect(double ax, double ay, double bx, double by, double x, double y, double w, double h)
```

ทดสอบ segment AB กับ rectangle; คืน t ของจุดตัดบน AB ใน [0,1], -1 ถ้าไม่ตัด

- **Returns:** double by value.
- **Ownership:** ax=by value; ay=by value; bx=by value; by=by value; x=by value; y=by value; w=by value; h=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `segmentCircle`

```fac
public function double segmentCircle(double ax, double ay, double bx, double by, double cx, double cy, double r)
```

Segment AB against a circle: return the first contact parameter t in [0,1], where P=A+t*(B-A); return -1 when there is no contact. Boundary counts.

- **Returns:** double by value.
- **Ownership:** ax=by value; ay=by value; bx=by value; by=by value; cx=by value; cy=by value; r=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `sweepCircle`

```fac
public function double sweepCircle(double ax, double ay, double ar, double dx, double dy, double bx, double by, double br)
```

Continuous circle-vs-circle collision. A moves by (dx,dy) over normalized frame time [0,1]; B is stationary. Returns first contact time, or -1.

- **Returns:** double by value.
- **Ownership:** ax=by value; ay=by value; ar=by value; dx=by value; dy=by value; bx=by value; by=by value; br=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `sweepRect`

```fac
public function (double, double, double) sweepRect(double ax, double ay, double aw, double ah, double dx, double dy, double bx, double by, double bw, double bh)
```

Continuous AABB-vs-AABB collision. A=(x,y,w,h) moves by (dx,dy) during normalized frame time [0,1]; B is stationary. Returns (t,nx,ny): t is the first contact time and (nx,ny) is the outward collision normal of B. A miss is (-1,0,0); an initial strict overlap is (0,0,0) because no unique impact normal exists. Touching while moving inward counts; moving away does not. Widths/heights must be positive and all inputs finite.

- **Returns:** Tuple (double,double,double) by value.
- **Ownership:** ax=by value; ay=by value; aw=by value; ah=by value; dx=by value; dy=by value; bx=by value; by=by value; bw=by value; bh=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `overlapOrientedRect`

```fac
public function boolean overlapOrientedRect(double acx, double acy, double ahw, double ahh, double aa, double bcx, double bcy, double bhw, double bhh, double ba)
```

Separating Axis Theorem for two oriented rectangles (OBB). (cx,cy) is center; (halfW,halfH) are half extents; angle is in radians. Strict overlap: exact edge contact returns false. Non-finite/invalid input returns false.

- **Returns:** boolean by value.
- **Ownership:** acx=by value; acy=by value; ahw=by value; ahh=by value; aa=by value; bcx=by value; bcy=by value; bhw=by value; bhh=by value; ba=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `pointInPolygon`

```fac
public function boolean pointInPolygon(double px, double py, array double vertices[])
```

General simple-polygon point test. Vertex storage is interleaved: x0,y0,x1,y1,... The polygon may be concave; boundary points count as inside.

- **Returns:** boolean by value.
- **Ownership:** px=by value; py=by value; vertices=by value (read-only array view)
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `overlapConvexPolygons`

```fac
public function boolean overlapConvexPolygons(array double a[], array double b[])
```

Separating Axis Theorem for two convex polygons. Arrays are interleaved x/y coordinates in clockwise or counter-clockwise perimeter order. Strict overlap: edge-only contact is false. Invalid, concave, degenerate or non-finite input is false.

- **Returns:** boolean by value.
- **Ownership:** a=by value (read-only array view); b=by value (read-only array view)
- **Errors:** None: does not throw.
- **Thread-safety:** Safe: depends only on its arguments.

### `SpatialHash.clear`

```fac
public function void clear()
```

- **Returns:** Nothing; discards all indexed objects and cell entries.
- **Ownership:** no parameters
- **Errors:** No direct throw; allocation/cleanup errors from underlying containers may propagate.
- **Thread-safety:** Not thread-safe: mutates the SpatialHash receiver.

### `SpatialHash.objectCount`

```fac
public function int objectCount() { return this.objectIds.size() }
```

- **Returns:** Number of unique object IDs inserted since the last clear.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only; safe concurrently with other readers, not with a writer.

### `SpatialHash.membershipCount`

```fac
public function int membershipCount() { return sizeof(this.entryObjectIds) }
```

- **Returns:** Number of object-to-cell membership entries (usually greater than objectCount).
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only; safe concurrently with other readers, not with a writer.

### `SpatialHash.insert`

```fac
public function boolean insert(int id, double x, double y, double w, double h)
```

- **Returns:** true on success; false for invalid/oversized bounds, duplicate IDs or >1,048,576 total cell memberships.
- **Ownership:** id/x/y/w/h=by value
- **Errors:** Container allocation errors may propagate.
- **Thread-safety:** Not thread-safe: mutates the SpatialHash receiver.

### `SpatialHash.query`

```fac
public function list int query(double x, double y, double w, double h)
```

- **Returns:** Unique candidate object IDs whose occupied cells intersect the query cells.
- **Ownership:** x/y/w/h=by value
- **Errors:** Container allocation errors may propagate while constructing the result.
- **Thread-safety:** Read-only on the SpatialHash receiver; safe concurrently with other readers, not with a writer.
