# `scheduler` (source library)

Source: `stdlib/scheduler.fac` · `import scheduler.fac` · release V263

### `PollScheduler`

```fac
public class PollScheduler
```

PollScheduler is a deterministic, caller-clock scheduler. pollDue(nowMs) returns all due identifiers; repeating jobs coalesce missed ticks and are rescheduled relative to the poll time. It does not spawn threads or callbacks.

### `PollScheduler.scheduleOnce`

```fac
public function void scheduleOnce(string id, long firstDueMs) { this.addTask(id, firstDueMs, 0) }
```

- **Returns:** Adds/replaces a one-shot task due at firstDueMs.
- **Ownership:** id=borrowed; scheduler retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid id/time.
- **Thread-safety:** Not thread-safe.

### `PollScheduler.scheduleEvery`

```fac
public function void scheduleEvery(string id, long firstDueMs, long intervalMs)
```

- **Returns:** Adds/replaces a repeating task; interval must be positive.
- **Ownership:** id=borrowed; scheduler retains a copy.
- **Errors:** Throws InvalidArgument (4) for invalid id/time/interval.
- **Thread-safety:** Not thread-safe.

### `PollScheduler.cancel`

```fac
public function boolean cancel(string id)
```

- **Returns:** Removes a task; false if the id is unknown.
- **Ownership:** id=borrowed; result=by value.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `PollScheduler.pollDue`

```fac
public function list dyn string pollDue(long nowMs)
```

- **Returns:** IDs due at nowMs. One-shot entries are removed; repeats move to nowMs + interval.
- **Ownership:** result=owned list of strings.
- **Errors:** Throws InvalidArgument (4) for negative nowMs.
- **Thread-safety:** Not thread-safe.

### `PollScheduler.size`

```fac
public function int size() { return sizeof(this.ids) }
```

- **Returns:** Number of pending tasks.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable scheduler.

### `PollScheduler.clear`

```fac
public function void clear()
```

- **Returns:** Removes all scheduled tasks.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.
