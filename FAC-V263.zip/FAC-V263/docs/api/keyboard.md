# `keyboard`

Keyboard state query.

- Status: **stable**
- Thread-safety: **externally synchronized** (policy; see [API conventions](../API_CONVENTIONS.md))
- Entries: 1 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `keyboard.down(handle, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle, #2 borrowed |

_Parameter names are not part of the built-in contract; positional types are shown._
