# `ip` (source library)

Source: `stdlib/ip.fac` · `import ip.fac` · release V263

### `IpAddress`

```fac
public class IpAddress
```

IpAddress stores its 16 bytes in scalar fields to keep the value self-contained. IPv6 output preserves the supplied compression and letter case; embedded IPv4 tails and zone identifiers are not supported yet.

### `IpAddress.parseIPv4`

```fac
public function boolean parseIPv4(string text)
```

- **Returns:** True and stores four bytes when text is a dotted-decimal IPv4 address.
- **Ownership:** text=borrowed; address bytes=owned by this object.
- **Errors:** Returns false for malformed text; does not throw for parse failure.
- **Thread-safety:** Not thread-safe when shared mutably.

### `IpAddress.parseIPv6`

```fac
public function boolean parseIPv6(string text)
```

- **Returns:** True and stores sixteen bytes when text is a supported IPv6 literal.
- **Ownership:** text=borrowed; address bytes=owned by this object.
- **Errors:** Returns false for malformed text; does not throw for parse failure.
- **Thread-safety:** Not thread-safe when shared mutably.

### `IpAddress.parse`

```fac
public function boolean parse(string text)
```

- **Returns:** True when text parses as IPv4 or IPv6.
- **Ownership:** text=borrowed.
- **Errors:** Returns false for malformed text; does not throw for parse failure.
- **Thread-safety:** Not thread-safe when shared mutably.

### `IpAddress.version`

```fac
public function int version() { return this.family }
```

- **Returns:** Address family number: 4, 6, or 0 when no address has been parsed.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `IpAddress.byteAt`

```fac
public function int byteAt(int offset)
```

- **Returns:** One byte at a zero-based offset, or -1 when no address/invalid offset.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `IpAddress.isLoopbackV4`

```fac
public function boolean isLoopbackV4() { return this.family == 4 && this.b0 == 127 }
```

- **Returns:** True for IPv4 loopback 127.0.0.0/8.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `IpAddress.isLoopbackV6`

```fac
public function boolean isLoopbackV6()
```

- **Returns:** True for IPv6 loopback ::1.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Safe for a stable object.

### `IpAddress.toString`

```fac
public function string toString()
```

- **Returns:** Original accepted dotted IPv4 or IPv6 text; empty when unset.
- **Ownership:** result=owned string.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable object.
