# `encoding` (source library)

Source: `stdlib/encoding.fac` · `import encoding.fac` · release V263

### `hexEncode`

```fac
public function string hexEncode(list dyn int data)
```

- **Returns:** Lowercase hexadecimal text for the supplied bytes.
- **Ownership:** data=borrowed (read-only); result=owned string.
- **Errors:** Throws Encoding (13) if any value is outside [0,255]; may allocate.
- **Thread-safety:** Safe for a stable input list.

### `hexDecode`

```fac
public function list dyn int hexDecode(string text)
```

- **Returns:** Decoded bytes from even-length hexadecimal text.
- **Ownership:** text=borrowed; result=owned list.
- **Errors:** Throws Encoding (13) for odd length or a non-hexadecimal character.
- **Thread-safety:** Safe-pure.

### `base64Encode`

```fac
public function string base64Encode(list dyn int data)
```

- **Returns:** RFC 4648 Base64 text with standard '=' padding.
- **Ownership:** data=borrowed (read-only); result=owned string.
- **Errors:** Throws Encoding (13) when a value is outside [0,255]; may allocate.
- **Thread-safety:** Safe for a stable input list.

### `base64Decode`

```fac
public function list dyn int base64Decode(string text)
```

- **Returns:** Decoded byte values from canonical padded RFC 4648 Base64 text.
- **Ownership:** text=borrowed; result=owned list.
- **Errors:** Throws Encoding (13) for invalid alphabet, length, or padding.
- **Thread-safety:** Safe-pure.
