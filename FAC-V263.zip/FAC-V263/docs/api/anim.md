# `anim` (source library)

Source: `stdlib/anim.fac` · `import anim.fac` · release V263

### `Anim.updateNs`

```fac
public function void updateNs(long ns)
```

- **Returns:** Nothing.
- **Ownership:** ns=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Anim receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Anim.update`

```fac
public function void update(double dt)
```

- **Returns:** Nothing.
- **Ownership:** dt=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Anim receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Anim.reset`

```fac
public function void reset() { this.timeNs = 0 }
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Anim receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Anim.setLooping`

```fac
public function void setLooping(boolean enabled)
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: mutates the Anim receiver; synchronize externally.

### `Anim.setFrame`

```fac
public function void setFrame(int index)
```

- **Returns:** Nothing.
- **Ownership:** index=by value
- **Errors:** Can throw: explicit throw Error (code 2).
- **Thread-safety:** Not thread-safe: mutates the Anim receiver; synchronize externally.

### `Anim.durationNs`

```fac
public function long durationNs() { return this.cycleNs }
```

- **Returns:** long by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Anim receiver: safe concurrently with other readers, not with a writer.

### `Anim.frameProgress`

```fac
public function double frameProgress()
```

- **Returns:** double by value; fraction of the current frame in [0,1].
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Anim receiver: safe concurrently with other readers, not with a writer.

### `Anim.frame`

```fac
public function int frame()
```

เฟรมปัจจุบัน 0..count-1

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Anim receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Anim.cell`

```fac
public function int cell() { return this.firstCell + this.frame() }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Read-only on the Anim receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Anim.finished`

```fac
public function boolean finished()
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Anim receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Anim.draw`

```fac
public function void draw(ptr graphic dst, ptr graphic sheet, int x, int y, boolean flipX)
```

วาดเฟรมปัจจุบันที่ (x, y) = มุมซ้ายบน; flipX = พลิกซ้าย-ขวา (ตัวละครหันซ้าย); เคารพ alpha ของ sheet

- **Returns:** Nothing.
- **Ownership:** dst=non-owning handle, not freed here; sheet=non-owning handle, not freed here; x=by value; y=by value; flipX=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Reads the Anim receiver; the delegated graphic Canvas handles are synchronized internally. Do not mutate the Anim receiver concurrently.
