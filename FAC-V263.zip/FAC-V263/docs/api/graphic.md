# `graphic`

Software canvas and image buffers with per-handle synchronization for drawing, reading, blitting, depth updates and save snapshots; callers still synchronize handle destruction.

- Status: **stable**
- Thread-safety: **safe (atomic)**
- Entries: 44 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `graphic.alphaAt(handle, int, int)` → int | no direct throw site | args: #1 borrowed-handle |
| `graphic.bitmapText(handle, int, int, string, int, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle, #4 borrowed |
| `graphic.bitmapText(handle, int, int, string, int)` → void | throws `Error` (code 14 Media) | args: #1 borrowed-handle, #4 borrowed |
| `graphic.bitmapTextWidth(string, int)` → int | no direct throw site | args: #1 borrowed |
| `graphic.blend(handle, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.blit(handle, handle, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `graphic.blitAlpha(handle, handle, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `graphic.blitKey(handle, handle, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `graphic.blitRegion(handle, handle, int, int, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `graphic.blitRegionEx(handle, handle, int, int, int, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `graphic.blitScaled(handle, handle, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed-handle |
| `graphic.circle(handle, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.clear(handle, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.clipboardGet(handle)` → string | no direct throw site | args: #1 borrowed-handle; result: owned by caller |
| `graphic.clipboardSet(handle, string)` → boolean | boolean status flag (`false` = failed, no detail) | args: #1 borrowed-handle, #2 borrowed |
| `graphic.create(int, int)` → handle | throws `Error` (code 14 Media) + OOM | result: owned by caller (release with `graphic.free`) |
| `graphic.delay(long)` → void | no direct throw site | **alias** of `time.sleep` |
| `graphic.fillCircle(handle, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.fillRect(handle, int, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.fillTriangle(handle, int, int, int, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.free(handle)` → void | no direct throw site | args: #1 consumed; consumes arg 1: frees the canvas |
| `graphic.get(handle, int, int)` → uint | no direct throw site | args: #1 borrowed-handle |
| `graphic.hasAlpha(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `graphic.height(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `graphic.hsv(double, double, double)` → uint | throws `Error` (code 14 Media) |  |
| `graphic.key(handle, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle, #2 borrowed |
| `graphic.line(handle, int, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.load(string)` → handle | no direct throw site | args: #1 borrowed; result: owned by caller (release with `graphic.free`) |
| `graphic.mouseDown(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `graphic.mouseX(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `graphic.mouseY(handle)` → int | no direct throw site | args: #1 borrowed-handle |
| `graphic.open(int, int, string)` → handle | throws `Error` (code 14 Media) + OOM | args: #3 borrowed; result: owned by caller (release with `graphic.free`) |
| `graphic.pixel(handle, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.poll(handle)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed-handle |
| `graphic.present(handle)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.rect(handle, int, int, int, int, int)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.rgb(int, int, int)` → uint | no direct throw site |  |
| `graphic.save(handle, string)` → void | no direct throw site | args: #1 borrowed-handle, #2 borrowed |
| `graphic.startTextInput(handle)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.stopTextInput(handle)` → void | no direct throw site | args: #1 borrowed-handle |
| `graphic.systemTextAvailable()` → boolean | boolean status flag (`false` = failed, no detail) |  |
| `graphic.text(handle, int, int, string, int)` → void | throws `Error` (code 6 NullPointer, 14 Media) + OOM | args: #1 borrowed-handle, #4 borrowed |
| `graphic.text(handle, int, int, string, int, int)` → void | throws `Error` (code 6 NullPointer, 14 Media) + OOM | args: #1 borrowed-handle, #4 borrowed |
| `graphic.textInput(handle)` → string | no direct throw site | args: #1 borrowed-handle; result: owned by caller |
| `graphic.textWidth(string, int)` → int | no direct throw site | args: #1 borrowed |
| `graphic.width(handle)` → int | no direct throw site | args: #1 borrowed-handle |

_Parameter names are not part of the built-in contract; positional types are shown._
