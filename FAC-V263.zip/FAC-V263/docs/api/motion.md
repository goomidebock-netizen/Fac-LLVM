# `motion` (source library)

Source: `stdlib/motion.fac` · `import motion.fac` · release V263

### `Tween.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled)
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: mutates the Tween receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tween.snap`

```fac
public function void snap(double value)
```

- **Returns:** Nothing.
- **Ownership:** value=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Not thread-safe: mutates the Tween receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tween.to`

```fac
public function void to(double target, double seconds, int easingId)
```

- **Returns:** Nothing.
- **Ownership:** target=by value; seconds=by value; easingId=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Not thread-safe: mutates the Tween receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tween.update`

```fac
public function void update(double dt)
```

- **Returns:** Nothing.
- **Ownership:** dt=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Not thread-safe: mutates the Tween receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tween.value`

```fac
public function double value() { return this.currentValue }
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tween receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tween.progress`

```fac
public function double progress()
```

- **Returns:** double by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tween receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Tween.isAnimating`

```fac
public function boolean isAnimating() { return this.active }
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Tween receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Spring.setTarget`

```fac
public function void setTarget(double value)
```

- **Returns:** Nothing.
- **Ownership:** value=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Not thread-safe: mutates the Spring receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Spring.setReduceMotion`

```fac
public function void setReduceMotion(boolean enabled)
```

- **Returns:** Nothing.
- **Ownership:** enabled=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: mutates the Spring receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Spring.snap`

```fac
public function void snap(double value)
```

- **Returns:** Nothing.
- **Ownership:** value=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Not thread-safe: mutates the Spring receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Spring.update`

```fac
public function void update(double dt)
```

- **Returns:** Nothing.
- **Ownership:** dt=by value
- **Errors:** Can throw: explicit throw Error (code 18).
- **Thread-safety:** Not thread-safe: mutates the Spring receiver; synchronize externally.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `Spring.settled`

```fac
public function boolean settled() { return this.position == this.target && this.velocity == 0.0 }
```

- **Returns:** boolean by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Read-only on the Spring receiver: safe concurrently with other readers, not with a writer.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
