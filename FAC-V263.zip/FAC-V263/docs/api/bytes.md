# `bytes` (source library)

Source: `stdlib/bytes.fac` · `import bytes.fac` · release V263

### `ByteBuffer`

```fac
public class ByteBuffer
```

ByteBuffer is an owned, growable sequence of unsigned 8-bit values. It deliberately stores bytes as integers instead of reusing FAC UTF-8 strings: a FAC string is text, not an arbitrary binary buffer.

### `ByteBuffer.freeze`

```fac
public function void freeze() { this.frozen = true }
```

- **Returns:** Freezes this buffer for safe sharing with read-only ByteView and BinaryReader.
- **Ownership:** no parameters; the buffer remains owned by this object and any views retain it.
- **Errors:** None; idempotent.
- **Thread-safety:** Not thread-safe. Freeze before publishing to other threads.

### `ByteBuffer.isFrozen`

```fac
public function boolean isFrozen() { return this.frozen }
```

- **Returns:** True when this buffer has been frozen against mutation.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.append`

```fac
public function void append(int value)
```

- **Returns:** Appends one unsigned byte.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) when value is outside [0,255]; may allocate.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.appendAll`

```fac
public function void appendAll(list dyn int source)
```

- **Returns:** Appends all values from source, validating each byte.
- **Ownership:** source=borrowed (read-only).
- **Errors:** Throws Encoding (13) for a non-byte value; may allocate.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.size`

```fac
public function int size() { return sizeof(this.data) }
```

- **Returns:** Number of bytes in the buffer.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.isEmpty`

```fac
public function boolean isEmpty() { return sizeof(this.data) == 0 }
```

- **Returns:** True when the buffer has no bytes.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.get`

```fac
public function int get(int offset)
```

- **Returns:** Byte at a zero-based offset.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) for an invalid offset.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.set`

```fac
public function void set(int offset, int value)
```

- **Returns:** Replaces one byte at offset.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) for a non-byte; IndexOutOfRange (2) for an invalid offset.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.clear`

```fac
public function void clear() { this.ensureMutable(); this.data.clear() }
```

- **Returns:** Clears all bytes.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.toList`

```fac
public function list dyn int toList()
```

- **Returns:** An independently owned shallow copy of the byte values.
- **Ownership:** result=owned list.
- **Errors:** May allocate.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.appendU16LE`

```fac
public function void appendU16LE(int value)
```

- **Returns:** Appends a 16-bit unsigned integer in little-endian byte order.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,65535]; may allocate.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.appendU16BE`

```fac
public function void appendU16BE(int value)
```

- **Returns:** Appends a 16-bit unsigned integer in big-endian byte order.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,65535]; may allocate.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.appendU32LE`

```fac
public function void appendU32LE(long value)
```

- **Returns:** Appends a 32-bit unsigned integer in little-endian byte order.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,4294967295]; may allocate.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.appendU32BE`

```fac
public function void appendU32BE(long value)
```

- **Returns:** Appends a 32-bit unsigned integer in big-endian byte order.
- **Ownership:** value=by value.
- **Errors:** Throws Encoding (13) outside [0,4294967295]; may allocate.
- **Thread-safety:** Not thread-safe.

### `ByteBuffer.readU16LE`

```fac
public function int readU16LE(int offset)
```

- **Returns:** A 16-bit unsigned integer read in little-endian order.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) unless two bytes are available.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.readU16BE`

```fac
public function int readU16BE(int offset)
```

- **Returns:** A 16-bit unsigned integer read in big-endian order.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) unless two bytes are available.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.readU32LE`

```fac
public function long readU32LE(int offset)
```

- **Returns:** A 32-bit unsigned integer represented as long, read little-endian.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) unless four bytes are available.
- **Thread-safety:** Safe for a stable buffer.

### `ByteBuffer.readU32BE`

```fac
public function long readU32BE(int offset)
```

- **Returns:** A 32-bit unsigned integer represented as long, read big-endian.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) unless four bytes are available.
- **Thread-safety:** Safe for a stable buffer.

### `ByteView`

```fac
public class ByteView
```

Immutable, zero-copy window over a frozen ByteBuffer. The view retains the backing object, so it remains valid after the original variable goes out of scope. It deliberately exposes no mutation API.

### `ByteView.size`

```fac
public function int size() { return this.length }
```

- **Returns:** Number of bytes visible through this view.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable frozen backing buffer.

### `ByteView.isEmpty`

```fac
public function boolean isEmpty() { return this.length == 0 }
```

- **Returns:** True when the view contains no bytes.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable frozen backing buffer.

### `ByteView.get`

```fac
public function int get(int index)
```

- **Returns:** Byte at a zero-based view-relative offset.
- **Ownership:** result=by value.
- **Errors:** Throws IndexOutOfRange (2) outside the view.
- **Thread-safety:** Safe for a stable frozen backing buffer.

### `ByteView.slice`

```fac
public function obj ByteView slice(int offset, int count)
```

- **Returns:** A zero-copy sub-view sharing the same frozen backing buffer.
- **Ownership:** result=shared read-only view; no payload bytes are copied.
- **Errors:** Throws IndexOutOfRange (2) when the requested range is outside the view.
- **Thread-safety:** Safe for a stable frozen backing buffer.

### `ByteView.toList`

```fac
public function list dyn int toList()
```

- **Returns:** An independently owned byte list copied from this view.
- **Ownership:** result=owned list.
- **Errors:** May throw OutOfMemory (5).
- **Thread-safety:** Safe for a stable frozen backing buffer.
