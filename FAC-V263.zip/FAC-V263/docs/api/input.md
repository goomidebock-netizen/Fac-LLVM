# `input` (source library)

Source: `stdlib/input.fac` · `import input.fac` · release V263

### `bind`

```fac
public function void bind(string action, string key)
```

- **Returns:** Nothing.
- **Ownership:** action=borrowed (immutable, shared); key=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (bAction, bCur, bKey).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `unbind`

```fac
public function void unbind(string action)
```

- **Returns:** Nothing.
- **Ownership:** action=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (bAction, bCur, bKey).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `clearBindings`

```fac
public function void clearBindings()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (bAction, bCur, bKey).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `bindingCount`

```fac
public function int bindingCount() { return sizeof(bAction) }
```

- **Returns:** int by value.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (bAction).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `inject`

```fac
public function void inject(string key, boolean down)
```

- **Returns:** Nothing.
- **Ownership:** key=borrowed (immutable, shared); down=by value
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (vDown, vKey).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `releaseAll`

```fac
public function void releaseAll()
```

- **Returns:** Nothing.
- **Ownership:** no parameters
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (vDown).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `update`

```fac
public function void update(ptr graphic w)
```

- **Returns:** Nothing.
- **Ownership:** w=non-owning handle, not freed here
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Not thread-safe: uses module-level state (bAction, bCur, bKey).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `down`

```fac
public function boolean down(string action)
```

- **Returns:** boolean by value.
- **Ownership:** action=borrowed (immutable, shared)
- **Errors:** None: does not throw.
- **Thread-safety:** Not thread-safe: uses module-level state (bAction, bCur).
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `pressed`

```fac
public function boolean pressed(string action) { return down(action) && !wasDown(action) }
```

- **Returns:** boolean by value.
- **Ownership:** action=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `released`

```fac
public function boolean released(string action) { return !down(action) && wasDown(action) }
```

- **Returns:** boolean by value.
- **Ownership:** action=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._

### `axis`

```fac
public function double axis(string negative, string positive)
```

-1.0 / 0.0 / 1.0 จากคู่ action (ลบ, บวก); กดทั้งคู่ = 0.0

- **Returns:** double by value.
- **Ownership:** negative=borrowed (immutable, shared); positive=borrowed (immutable, shared)
- **Errors:** No direct throw; errors thrown by called FAC functions or methods propagate.
- **Thread-safety:** Unspecified: calls other APIs (or constructs objects); synchronize externally unless every callee is documented safe.
- _Contract derived mechanically (see `tools/api_contract.py`); not a hand review._
