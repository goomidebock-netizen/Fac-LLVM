# `schema` (source library)

Source: `stdlib/schema.fac` · `import schema.fac` · release V263

### `DataSchema`

```fac
public class DataSchema
```

DataSchema validates flat/nested scalar mappings from Config (INI), TOML or YAML. It intentionally validates declared fields only; unknown-field policy and rich JSON Schema are future work.

### `DataSchema.addString`

```fac
public function void addString(string name, boolean required = true) { this.addField(name, "string", required) }
```

- **Returns:** Adds a string field rule.
- **Ownership:** name=borrowed.
- **Errors:** Throws InvalidArgument (4) for empty/duplicate names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DataSchema.addInteger`

```fac
public function void addInteger(string name, boolean required = true) { this.addField(name, "integer", required) }
```

- **Returns:** Adds a signed 64-bit integer field rule.
- **Ownership:** name=borrowed.
- **Errors:** Throws InvalidArgument (4) for empty/duplicate names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DataSchema.addBoolean`

```fac
public function void addBoolean(string name, boolean required = true) { this.addField(name, "boolean", required) }
```

- **Returns:** Adds a boolean field rule.
- **Ownership:** name=borrowed.
- **Errors:** Throws InvalidArgument (4) for empty/duplicate names.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DataSchema.clear`

```fac
public function void clear()
```

- **Returns:** Removes all field rules.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Not thread-safe when shared mutably.

### `DataSchema.size`

```fac
public function int size() { return sizeof(this.names) }
```

- **Returns:** Number of declared rules.
- **Ownership:** result=by value.
- **Errors:** None.
- **Thread-safety:** Safe for a stable schema.

### `DataSchema.validateConfig`

```fac
public function list dyn string validateConfig(obj Config document)
```

- **Returns:** Validation error messages for an INI Config document.
- **Ownership:** document=borrowed (read-only); result=owned list.
- **Errors:** None; invalid fields are returned as messages.
- **Thread-safety:** Safe for stable schema/document values.

### `DataSchema.validateToml`

```fac
public function list dyn string validateToml(obj TomlDocument document)
```

- **Returns:** Validation error messages for a TOML document.
- **Ownership:** document=borrowed (read-only); result=owned list.
- **Errors:** None; invalid fields are returned as messages.
- **Thread-safety:** Safe for stable schema/document values.

### `DataSchema.validateYaml`

```fac
public function list dyn string validateYaml(obj YamlDocument document)
```

- **Returns:** Validation error messages for a YAML document.
- **Ownership:** document=borrowed (read-only); result=owned list.
- **Errors:** None; invalid fields are returned as messages.
- **Thread-safety:** Safe for stable schema/document values.
