# `string`

UTF-8 string helpers (strings are immutable, shared by atomic refcount).

- Status: **stable**
- Thread-safety: **safe (pure)**
- Entries: 31 · generated from the compiler tables (release V263)

| API | Errors | Ownership / notes |
|---|---|---|
| `string.byteLength(string)` → int | no direct throw site | args: #1 borrowed |
| `string.capitalize(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.chars(string)` → list<string> | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.compare(string, string)` → int | no direct throw site | args: #1 borrowed, #2 borrowed |
| `string.contains(string, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed, #2 borrowed |
| `string.count(string, string)` → int | no direct throw site | args: #1 borrowed, #2 borrowed |
| `string.endsWith(string, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed, #2 borrowed |
| `string.equalsIgnoreCase(string, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed, #2 borrowed |
| `string.find(string, string)` → int | no direct throw site | args: #1 borrowed, #2 borrowed; also: `string.indexOf` |
| `string.fromBytes(list<int>)` → string | throws `Error` (code 13 Encoding) + OOM | args: #1 borrowed; result: owned by caller; Requires list dyn int with byte values in [0,255], validates strict well-formed UTF-8 and returns an owned FAC string; maximum input is 16 MiB. |
| `string.graphemeLength(string)` → int | no direct throw site | args: #1 borrowed |
| `string.graphemeSlice(string, long, long)` → string | throws `Error` (code 2 IndexOutOfRange) | args: #1 borrowed; result: owned by caller |
| `string.indexOf(string, string)` → int | no direct throw site | **alias** of `string.find`; args: #1 borrowed, #2 borrowed |
| `string.isNumber(string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed |
| `string.join(list<string>, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `string.lastFind(string, string)` → int | no direct throw site | args: #1 borrowed, #2 borrowed |
| `string.length(string)` → int | no direct throw site | args: #1 borrowed |
| `string.lines(string)` → list<string> | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.lower(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.padLeft(string, int, unichar)` → string | throws `Error` (code 8 Resource) | args: #1 borrowed; result: owned by caller |
| `string.padRight(string, int, unichar)` → string | throws `Error` (code 8 Resource) | args: #1 borrowed; result: owned by caller |
| `string.repeat(string, int)` → string | throws `Error` (code 8 Resource) | args: #1 borrowed; result: owned by caller |
| `string.replace(string, string, string)` → string | no direct throw site | args: #1 borrowed, #2 borrowed, #3 borrowed; result: owned by caller |
| `string.reverse(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.split(string, string)` → list<string> | no direct throw site | args: #1 borrowed, #2 borrowed; result: owned by caller |
| `string.startsWith(string, string)` → boolean | predicate (never throws on a normal miss) | args: #1 borrowed, #2 borrowed |
| `string.toBytes(string)` → list<int> | throws `Error` (code 8 Resource) | args: #1 borrowed; result: owned by caller; Copies the exact stored UTF-8 bytes to an owned list dyn int (maximum 16 MiB); the list contains unsigned byte values represented as ints. |
| `string.trim(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.trimLeft(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.trimRight(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |
| `string.upper(string)` → string | no direct throw site | args: #1 borrowed; result: owned by caller |

_Parameter names are not part of the built-in contract; positional types are shown._
