# `typography` (source library)

Source: `stdlib/typography.fac` · `import typography.fac` · release V263

### `lineCount`

```fac
public function int lineCount(string value)
```

- **Returns:** Number of logical lines (at least one).
- **Ownership:** value=by value.
- **Errors:** Errors from string.count propagate.
- **Thread-safety:** Safe: depends only on the input string.

### `measureHeight`

```fac
public function int measureHeight(string value, int scale, int lineGap)
```

- **Returns:** Pixel height of the block.
- **Ownership:** value/scale/lineGap=by value.
- **Errors:** Errors from lineCount propagate.
- **Thread-safety:** Safe: depends only on the arguments.

### `TextLayout.reflow`

```fac
public function void reflow(string value, int width, int scale, int spacing)
```

- **Returns:** Nothing; replaces the layout's current lines and measurements.
- **Ownership:** value=borrowed; width/scale/spacing=by value.
- **Errors:** Resource error code 8 for input/output limits.
- **Thread-safety:** Not thread-safe: mutates this layout.

### `TextLayout.reflowWithFont`

```fac
public function void reflowWithFont(string value, int width, ptr font face, int spacing)
```

- **Returns:** Nothing; wraps using the same font metrics used by font.draw.
- **Ownership:** value=borrowed; face=borrowed handle; width/spacing=by value.
- **Errors:** Media error code 14 for a null font; Resource error code 8 for limits.
- **Thread-safety:** Not thread-safe: mutates this layout; the font must not be concurrently mutated/freed.

### `TextLayout.count`

```fac
public function int count() { return sizeof(this.lines) }
```

- **Returns:** Number of wrapped lines.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Read-only; safe concurrently with other readers.

### `TextLayout.lineAt`

```fac
public function string lineAt(int index)
```

- **Returns:** Line text, or an empty string for an out-of-range index.
- **Ownership:** index=by value.
- **Errors:** None.
- **Thread-safety:** Read-only; safe concurrently with other readers.

### `TextLayout.lineWidth`

```fac
public function int lineWidth(int index)
```

- **Returns:** Pixel width of the line, or zero for an out-of-range index.
- **Ownership:** index=by value.
- **Errors:** Text measurement errors may propagate.
- **Thread-safety:** Read-only; safe concurrently with other readers.

### `TextLayout.lineHeight`

```fac
public function int lineHeight()
```

- **Returns:** Baseline advance in pixels, including configured line gap.
- **Ownership:** no parameters.
- **Errors:** None.
- **Thread-safety:** Read-only; safe concurrently with other readers.

### `TextLayout.draw`

```fac
public function void draw(ptr graphic canvas, int x, int y, int color)
```

- **Returns:** Nothing.
- **Ownership:** canvas=non-owning handle, not freed here; x/y/color=by value.
- **Errors:** Errors from render.text propagate.
- **Thread-safety:** Not thread-safe if the canvas is concurrently mutated.
