# FAC Memory Management Direction — V222

V222 continues the Ownership-first direction introduced in V221. This release adds a bounded lifetime-elision rule for verified direct FAC functions and expands regression coverage for local borrows into fields of managed heap objects.

## 1. Single-input pointer return lifetime elision

A source-defined, non-extern, non-abstract FAC function may omit an explicit named lifetime on its pointer return only when all of these conditions hold:

- the function returns `ptr T`;
- the return type has no explicit lifetime annotation;
- the function declares no named lifetime parameters;
- exactly one parameter has pointer type and that parameter is not declared `noescape`;
- the function body is available to the compiler and is checked by the ownership/lifetime pass.

The checker synthesizes one abstract input region for that parameter, checks that returned pointer provenance outlives it, and carries the inferred contract through direct call sites. This allows a straightforward pointer identity/wrapper function without requiring the caller to restate a one-input lifetime relationship.

This is intentionally not general lifetime elision:

- functions with multiple pointer parameters remain ambiguous and require explicit named lifetimes for a pointer return;
- `extern` and abstract declarations are not inferred because their bodies cannot be verified;
- function-value/callback type declarations do not receive an inferred lifetime from their shape alone;
- `noescape` parameters cannot be used as the inferred return source;
- local-stack addresses and pointers derived from a shorter inner scope remain rejected when returned or stored into a longer-lived destination.

## 2. Borrowing managed heap-object fields

The local loan checker can track a local `ref` alias whose source is a metadata-resolved field of a tracked local `obj` handle. The object handle remains the loan root: conflicting owner mutation, move/overwrite and overlapping access are rejected while the mutable loan is live. The new memory-safe fixtures verify both runtime aliasing and an owner-write conflict.

This does not add reference-valued object fields, borrowed references stored in containers, arbitrary heap reference graphs, or cross-object lifetime transfer. Aggregate fields and module globals still cannot store local `ref` bindings. Raw pointers, manual heap and FFI remain outside `--memory-safe`.

## 3. Memory-management policy

Ownership and local borrowing remain the primary mechanism. ARC continues to represent intentionally shared managed objects; weak references do not extend object lifetime; the Runtime cycle collector remains limited to unreachable cycles in its managed object graph. These mechanisms do not replace static exclusivity or establish data-race freedom.

The proposed 75–80% Ownership/Borrow, limited ARC and minimal cycle-collection mix is a design goal, not a measured allocation or instruction ratio.

## 4. Validation

V222 adds regression cases for:

- a one-pointer-input identity function with an elided return lifetime;
- rejection when a pointer to an inner-scope local escapes through that function;
- rejection of returning a local stack address;
- mutable borrowing of a field in a managed heap object under `--memory-safe`;
- rejection of direct owner mutation while the heap-field mutable borrow remains live.

The lifetime and ownership checks remain conservative: unsupported aliases and unmodeled escape paths must fail closed rather than be guessed safe.
