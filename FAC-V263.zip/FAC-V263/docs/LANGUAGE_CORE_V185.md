# FAC Language Core — V185

## Scope

V185 extends the bounded fixed-array local-borrow projection evaluator to recognize visible, initialized local `const int` and `const long` declarations whose initializer is itself a supported pure integer constant expression.

## Implemented

- `const int first = 1` may be used as an exact array index in `values[first]`.
- Constant locals may reference previously visible constant locals, e.g. `const int next = first + 1`.
- Values are recorded only for direct scalar local `const int` / `const long` declarations with an initializer that the existing checked evaluator can prove.
- The initializer is evaluated in the pre-declaration environment, preserving ordinary shadowing behavior for declarations such as `const int item = item`.
- Each folded value is tied to the exact declaration node. A shadowing declaration cannot inherit a constant from an outer declaration by name alone.
- The declared integer width is checked before a constant value is recorded. Values that do not fit the declared `int` / `long` type remain unknown to the borrow evaluator.
- The existing expression node budget and checked arithmetic behavior remain in force.

## Conservative boundary

Mutable locals, parameters, globals/statics, uninitialized const locals, non-integer const values, arrays/containers, calls, assignments, increments and unsupported expressions are not folded. The evaluator does not perform general data-flow constant propagation, interprocedural evaluation, path-sensitive reasoning or arbitrary `const` evaluation. A const declaration is recorded only when its initializer is fully proven using earlier visible local constants and supported integer literal arithmetic. Unknown values remain conservative may-alias projections.

This does not add reference return/store types, general lifetime parameters, indexed partial moves, dynamic range analysis, whole-program alias analysis or a complete/Rust-equivalent borrow checker. It remains within strict local-borrow analysis (`--strict-ownership` / `--secure`) and does not change default legacy compilation, generated array layout, public APIs or Runtime ABI.

## Regression coverage

- `good_array_const_identifier_indices.fac`: chained local constants resolve to disjoint array element projections; runtime writes through aliases update the original array storage.
- `good_array_const_shadowing.fac`: a nested `const int index = index + 1` initializer reads the outer binding before shadowing it, then resolves to the inner declaration.
- `bad_array_mutable_shadowing_const_index.fac`: a mutable inner variable with the same name is not folded using an outer const binding and remains a conservative may-alias index.
- `bad_array_const_identifier_same_index.fac`: a constant identifier and equivalent literal resolve to the same projection and conflict.
- Existing dynamic-index cases continue to reject unknown indexes conservatively.

Validation is recorded in `docs/STATUS.md`; only suites run for this archive are claimed.
