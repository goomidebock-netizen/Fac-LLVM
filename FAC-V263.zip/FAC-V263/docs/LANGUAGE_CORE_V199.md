# FAC Language Core V199 — transitive reborrow suspension

V199 makes reborrow suspension explicitly transitive. When checking access through a mutable borrow, the checker now searches for any live descendant loan in the parent chain rather than only a directly linked child. The ancestry walk uses loan declaration identity (and the existing parent-declaration links), so alias spelling and lexical shadowing do not determine the relationship.

This applies consistently to parent writes, reads through mutable parents, member access, method calls and passing mutable aliases to calls. An ancestor remains suspended while a grandchild or deeper descendant is live.

NLL still releases the whole chain after the last reachable use of its deepest descendant. Regression coverage includes rejecting writes through an ancestor and an intermediate parent while a grandchild remains live, plus accepting and executing a parent/child/grandchild chain after NLL reaches the descendants' last use. The runtime test confirms the final parent write still aliases the original owner storage.

The analysis remains an intraprocedural local-loan checker over the existing CFG and lexical regions. V199 does not add named lifetime parameters, cross-function region inference, reference-valued aggregate fields, or a complete Rust-style borrow checker. See `docs/OWNERSHIP.md`, `docs/MEMORY_MODEL.md` and `tests/ownership/local_borrows/` for related rules and fixtures.
