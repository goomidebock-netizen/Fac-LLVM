# FAC Language Core V203 — Lifetime Region Inference

## Scope

V203 uses the named lifetime parameters and `where` relationships introduced in V200–V202 as inputs to the function-body lifetime checker. It unifies abstract parameter lifetimes and concrete lexical regions in a directed outlives graph and uses pointer-origin facts to validate pointer returns.

## Region model

- The function-call region is the root lexical region for a function body.
- Each declared lifetime parameter (for example, `a` in `lifetime<a>`) is represented by an abstract region that outlives the function-call region.
- Every lexical child region is outlived by its parent region.
- Each declared `where longer: shorter` clause adds a directed edge between the corresponding abstract regions.
- Region reachability is inferred transitively over this graph.

This is an intraprocedural model. The assumption that an input lifetime remains valid for the duration of the callee is the normal call contract; the caller-side instantiation of that contract is not yet inferred in V203.

## Pointer provenance

A pointer parameter declared as `ptr<a> T` seeds a pointer-origin fact associated with abstract region `a`. Those facts continue through ordinary pointer-variable initializers and assignments and are merged conservatively across control-flow branches. The checker validates every possible origin at a pointer return:

- Returning an origin whose region outlives the declared return region is accepted.
- A `where` chain may justify the relationship transitively (for example, `a: b, b: c` permits an origin from `a` to satisfy a return annotated `c`).
- A pointer from an unrelated or shorter lifetime is rejected.
- An address derived from function-local storage cannot satisfy an external named return lifetime.
- `noescape` parameters remain forbidden from escaping through return values.

An unannotated pointer return does not gain a lifetime guarantee from this feature; stack-derived origins remain conservatively rejected.

## Example

```fac
function lifetime<a, b, c> ptr<c> shorten(ptr<a> int value) where a: b, b: c {
    ptr int local = value
    return local
}
```

The local alias retains the origin region `a`; the alias's lexical storage region is not mistaken for the referent's lifetime. The outlives graph proves that `a` outlives `c`.

## Explicit limitations

V203 does not instantiate lifetime parameters at call sites, infer caller/callee constraints interprocedurally, model pointer provenance stored in aggregate fields or arbitrary containers, or extend lifetime annotations to extern/function-value signatures. Calls that may return a pointer still use the existing conservative call provenance rules. Lifetime annotations remain restricted to direct pointer types in function signatures. This is not a complete general-purpose borrow checker.

## Validation

The lifetime integration suite checks identity return, provenance through a local pointer alias, transitive outlives through a local alias, rejection of an unrelated parameter origin, conservative branch-merge rejection, and rejection of a function-local address returned as an external lifetime. The full CTest suite and the existing local-borrow suite are run for each release; exact results are recorded in `docs/STATUS.md`.
