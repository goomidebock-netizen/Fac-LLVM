# FAC V220 Generic Inference HIR (development)

## Scope

This pass extends `fac_hir::OverloadResolver` for statically identifiable class
method calls and generic free-function calls. It records generic substitutions
and concrete result types in the semantic model. A separate diagnostic collector
attaches structured, source-mapped provisional diagnostics to the HIR model; it
does not print CLI diagnostics or replace the legacy Codegen decisions.

The pass deliberately follows the current language surface:

- Named method type parameters declared with `function<T>` still require
  explicit type arguments such as `box.identity<int>(42)`.
- Methods using `auto` in parameter positions infer the `auto` binding from
  known argument expression types, including element positions in `list auto`
  and `array auto` parameters when the container element type is known.
- Generic class parameters are substituted from the receiver's concrete type,
  for example `obj Box<int> box` followed by `box.get()`. Unqualified explicit
  user-defined type arguments are normalized to the local/imported class,
  struct, enum or interface symbol when accessible.
- Static methods on a locally declared type can be resolved with explicit
  method type arguments, for example `Utility.same<long>(42)`.
- Generic free functions declared with `function<T>` infer named type
  parameters from direct, `ptr T`, `list T` and `array T` argument positions.
  Multiple type parameters are inferred independently. Repeated occurrences
  of the same parameter must agree on the same semantic type; implicit numeric
  widening is not used to reconcile contradictory inference evidence.
- Generic free-function calls keep ordinary call syntax such as `identity(42)`
  for inference. They may also provide explicit type arguments, for example
  `identity<int>(42)`. A free function with `const int N` may omit its whole
  generic argument list when a parameter exposes `N` directly as a fixed-array
  extent (`array var T values[N]`) and a fixed-size array argument supplies the
  extent. The same argument may infer `T` from its element type. Generic methods
  and generic struct/class instantiations with const parameters still require
  explicit arguments. Positional, named and positional-before-named explicit
  forms are accepted; named arguments are normalized to declaration order before
  HIR resolution and Codegen specialization, for example
  `keepSized<N = (PAGE_SIZE / 2), T = int>(42)`.
- Generic virtual/override dispatch and generic interface methods remain
  unsupported by the language and are not introduced by this pass.

## HIR records

`CallResolution` retains the selected method `SymbolId`, candidate set,
conversion cost, `isMethodCall`, explicit type argument `TypeId`s, a
`GenericInferenceState`, and a deterministic map of substitution names to
concrete `TypeId`s. States distinguish non-generic calls, explicit arguments,
type/const inference from arguments, deferred calls and constraint failures. `TypeSpec` preserves
a source generic-argument label during parsing; the shared argument-ordering
helper validates labels and produces declaration-order arguments before HIR
substitution and specialization.

Substituted composite return types are interned through
`TypeArena::internDescriptor`. The descriptor key follows the canonical
`TypeSpec` structural encoding, so a result such as `Option<int>` reuses its
existing structural `TypeId` rather than creating an unrelated duplicate.

Generic struct/class/function/method declarations retain their `const int`
parameter names in `Declaration::constTypeParameters`. Literal values are
interned as value-bearing `TypeDescriptor`s (`isConstValue` plus `int64`
value); unevaluated generic-call expressions are retained as
`isConstExpression` plus a canonical expression key. HIR checks the
value-versus-type argument kind and records explicit arguments/substitutions.
For the bounded free-function inference path, HIR also records an inferred
fixed-array extent as a value-bearing const substitution. Codegen derives the
same value from the concrete fixed-array argument, includes it in the
specialization key, and performs final specialization. Codegen substitutes
values through bodies and dependent types; array sizes then use the existing
constant-evaluation/layout path.

## Inference and constraints

The pass currently supports direct generic parameter positions, nested
`TypeSpec` generic arguments, and type parameters used as the element base of
`list` and `array` parameter types. `auto` placeholders in direct, list-element
and array-element positions are bound from known arguments. Container element
substitution is limited to built-in types and locally/import-accessible named
types whose declaration can be identified. For const inference, HIR recognizes
a parameter extent that is exactly the identifier `[N]` and a call argument
bound to a local fixed-size array declaration. Its source extent evaluator
supports integer/character/Boolean literals, unary `+`, `-`, `!`, and binary
`+`, `-`, `*`, `/`, `%` with overflow and zero-divisor rejection. Repeated
bindings must have identical values and built-in const predicates are checked
against the resulting value. Unknown or non-fixed extents are deferred; a
conflicting value is a constraint failure. HIR does not solve `[N * 2]`
backwards or infer from runtime lengths, lists, arbitrary calls or integer
arguments.

Constraint checks cover the built-in numeric/integral/floating/signed/unsigned,
value/reference categories and resolved named base/interface constraints that
can be proven from declaration inheritance and implementation metadata. A
candidate that violates a known constraint is rejected in HIR metadata. A
constraint with an unresolved actual or bound type is recorded as `Deferred`,
not as a definite constraint failure.

## Deliberate limits

- Method receiver lookup is limited to receiver types and static type names
  identifiable from the current semantic model; complex imported/aliased
  receiver paths remain deferred or unsupported.
- Full member access control, receiver conversions, inherited method lookup,
  indirect function-value calls and virtual dispatch are not migrated.
- Free-function generic type inference is limited to direct type parameters,
  pointer pointees and the element type of `list` / `array`. Const-value
  inference is limited to a direct `[N]` parameter extent paired with a local
  fixed-size array argument in HIR; Codegen also requires a concrete fixed-size
  array extent. It does not solve affine/arithmetic extent patterns. Arbitrary
  nested user-defined generic type constructors, map key/value pairs, other
  container encodings, and type parameters appearing only in the return type
  remain deferred or rejected as uninferable by Codegen.
- Variadic ABI promotion and complete constraint solving are not migrated.
- Structured HIR diagnostics currently cover generic free-function resolution
  outcomes (inferred, deferred, ambiguous, no viable candidate and known
  constraint failure). They are provisional analysis records, not yet emitted
  as user-facing CLI diagnostics. Codegen remains authoritative for language
  diagnostics, specialization, ownership/lifetime checks and LLVM lowering.

## Regression

`tests/semantic/generic_inference_hir.cpp` covers explicit method type arguments,
`auto` argument inference (including `list auto`), explicit generic parameters
inside `list T` and `array T`, static generic methods, generic class receiver
substitution for primitive and named types, nested generic return substitution,
built-in and interface constraints, definite constraint rejection, deferred
constraints for unresolved types, method overload selection and conservative
deferral when named type arguments are omitted. The test is registered as
`generic-inference-hir-regression` in CMake and runs through
`tests/semantic/run.sh`.

## Generic free-function regression

`tests/semantic/generic_free_function_hir.cpp` covers direct and multi-parameter
inference, `list T` inference, named explicit type arguments with declaration-order
substitution, explicit const-expression value arguments,
`isConstExpression` TypeDescriptor preservation, inferred fixed-array const
values represented by an `isConstValue` substitution, numeric and const-value constraints,
concrete-over-generic overload ranking, ambiguous candidates, conflicting
repeated type parameters, and deferred evidence. `tests/cases/t220_generic_free_function.fac` exercises
real parser-to-specialization-to-runtime paths for direct, constrained, `list T`
and `array T` generic free functions. A negative fixture verifies that a known
constraint violation is still rejected by Codegen. These tests are registered
through `tests/semantic/run.sh` and the normal case / negative runners.
