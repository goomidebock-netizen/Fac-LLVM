# FAC Language Core V197 — implicit control-flow lifetime regions

## Problem

The local borrow checker already models a lexical region tree for explicit blocks, loops, lambdas and several synthetic bindings. However, `if` arms and `switch`/`match` case contexts inherited the parent region. In particular, a payload binding created by a `match` case was recorded in the enclosing region. Pointer provenance created with `addr(payload)` could consequently appear to have the lifetime of the enclosing function rather than the case that owns the binding.

## V197 behavior

V197 gives each control-flow branch its own child region:

- true and false arms of `if`;
- every `switch`/`match` statement case and default arm;
- every `match` expression case and default arm, including pointer-origin collection from each result expression;
- `try`, `catch` and `finally` bodies.

Synthetic pattern bindings are registered in the case region in both `symbolRegions` and `frameStorage`. An origin from a pattern binding therefore outlives a destination only when the destination is in that case region or a descendant region. Storing it in a pointer whose region is an ancestor is rejected. The same-case noescape use remains valid because the case region outlives the call's temporary use.

The branch region is present even when the branch statement has no explicit braces. An explicit `Block` creates a nested region beneath the branch region, matching the additional lexical scope.

## Tests

- `good_match_payload_pointer_same_region.fac`: address of a statement-match payload binding is passed to a verified `noescape` parameter within the same case.
- `bad_match_payload_pointer_escape.fac`: address of a statement-match payload binding is stored into a pointer declared outside the match and must be rejected.
- `good_match_expression_pointer_same_region.fac`: address from a match-expression payload is passed to a verified `noescape` parameter.
- `bad_match_expression_pointer_escape.fac`: address returned by a match-expression branch is stored into an enclosing pointer and must be rejected.
- Existing `try/catch/finally`, `if`, switch/match, borrow-liveness, pointer-origin, and shadowing tests remain regression coverage.

## Boundary

This remains a lexical region-tree check. It does not add named lifetime parameters, outlives syntax, general reference-valued fields/containers, reference return types, raw-pointer alias proofs, arbitrary closure escape analysis, whole-program alias analysis, or a Rust-equivalent memory-safety guarantee. No public API or Runtime ABI changes are intended.
