# Java-style class entry point in FAC (V49)

FAC keeps its existing top-level entry point and adds a class-based entry point with Java-like structure. This is **not** a Java compatibility mode and does not change FAC's type or runtime model.

## Canonical form

```fac
import terminal.fac

public class main {
    public static function void main(list dyn string args) {
        terminal.out.println("Hello, World!")
        terminal.out.println("Argument count: ", sizeof(args))
    }
}
```

The class name does not have to be `main`; a source file can use a descriptive class name:

```fac
public class App {
    public static function void main() {
        terminal.out.println("Hello from App")
    }
}
```

The compiler synthesizes the native process entry point and invokes the class's static `main` after runtime and module initialization.

## Entry-point contract

- The entry class must be declared in the input (main) module and must be public. Top-level classes are public by default; `private class` cannot be an application entry class.
- The method must be declared directly in that class, named `main`, `public`, and `static`. An inherited `main` method is not selected.
- Return type must be `void`.
- It may take no parameters, or exactly one parameter declared as `list dyn string args`.
- The argument list contains process arguments **excluding** the executable path/name (the same convention used by `sys.args`). The list is owned by the entry call and is released using normal FAC scope cleanup when the method returns.
- Exactly one class entry point may be defined in the input module. The old top-level `public function void main()` remains supported, but a program cannot define both entry-point forms.
- A source module used as an imported library does not become the program entry point merely by defining a class `main` method.
- `import terminal.fac` is accepted for the terminal API; the API itself is compiler/runtime built-in and does not require an extra source file.

## Syntax and implementation notes

The lexer already tokenizes keywords/modifiers as identifier tokens. The V48 parser already accepted `public class`, `public static function`, and the `list dyn string` parameter type, so V49 intentionally does not add duplicate tokens or alter the existing grammar. The V49 change is in entry-point discovery, semantic validation, and LLVM wrapper generation. The process wrapper initializes the Runtime and module globals, calls `fac_args()` for the optional parameter, invokes the static method, then shuts down the Runtime.

The following are deliberately rejected as entry points: non-static methods, private/protected methods, non-public classes, generic/abstract methods, non-void return types, unsupported parameter types, and multiple competing entry points.

## Difference from Java

| Java convention | FAC convention |
|---|---|
| `public class App` | `public class App` |
| `public static void main(String[] args)` | `public static function void main(list dyn string args)` |
| JVM launcher/runtime | FAC-generated native process wrapper + FAC Runtime |
| Java `String[]` | FAC managed dynamic `list dyn string` |

FAC does not currently promise Java source compatibility, JVM bytecode compatibility, Java package semantics, annotations, or Java's complete method/field rules.

## Build and test

```sh
make CXX=clang++
sh tests/java_entry/run.sh
```
