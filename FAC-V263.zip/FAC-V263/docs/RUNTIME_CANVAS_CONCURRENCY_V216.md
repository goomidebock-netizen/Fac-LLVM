# V216 Runtime Canvas and image-buffer concurrency safety

## Shared mutable state

A `Canvas` owns mutable vectors for RGB pixels, depth values and optional alpha; it also stores window handles, keyboard/mouse state and a per-frame text-input buffer. Before V216, drawing and reading functions directly accessed those fields with no per-handle synchronization. Two FAC workers sharing a live Canvas could therefore race during drawing, pixel inspection, blitting, 3D depth updates or save operations. Cross-Canvas blits also read one mutable buffer while writing another, so simply locking only the destination would leave races on the source.

## Per-handle serialization

V216 adds an internal `std::recursive_mutex stateMutex` to each opaque Canvas. Public operations that inspect or mutate the live Canvas acquire the lock. Recursive locking is required because rectangle/text helpers delegate to other guarded drawing primitives and 3D grid rendering delegates to the line renderer. The lock covers dimensions, RGB writes/reads, raster primitives, alpha queries and blend, text-input snapshots, window polling/presentation, bitmap/GDI/Pango raster writes, depth-buffer operations and coherent image save snapshots.

Cross-handle blits use `FacCanvasPairLock`. For distinct handles it creates deferred `unique_lock`s and passes both to `std::lock`, which safely handles simultaneous opposite-direction operations without requiring pointer-address ordering. For a self-blit it acquires the handle once. SDL2 calls that use process-wide video, clipboard or text-input state keep the lock order Canvas state mutex then SDL video mutex. SDL event polling mutates the associated Canvas while both relevant locks are held.

## Lifetime boundaries

The mutex protects operations only while the `Canvas` object remains alive. The public API exposes a raw opaque handle and has no retain/lease operation for Canvas. A caller must therefore prevent any new operation from starting before calling `graphic.free`, and must join/finish all users first. The free routine takes the handle lock while it tears down platform resources, but the release is not a safe concurrent close protocol for a raw pointer. `FacCamera3D` is another mutable handle; callers must externally synchronize concurrent camera updates and reads. This release does not claim that every Runtime subsystem is generally thread-safe.

## Regression coverage

`tests/runtime/canvas_concurrency.cpp` drives shared Canvas operations from eight workers: drawing and querying pixel buffers, alpha/blend access, same-handle overlapping blit, cross-handle blit in opposing directions, 3D depth and pixel writes, bitmap text and save snapshots. It checks that all workers finish, the output remains within RGB range and the opaque alpha metadata remains unchanged. The ordinary `tests/runtime/run.sh` suite executes this test against the built Runtime object.

The test does not destroy handles while other workers are still using them. That would violate the raw-handle lifetime contract rather than exercise the protected operation paths.

## Vector-font backend lifetime

The POSIX vector-font backend keeps Pango/Cairo/Fontconfig library handles loaded for the process lifetime. These libraries own process-global font-map caches and may retain worker/TLS teardown state; unloading them from a C++ static destructor can race with library-owned teardown at process shutdown. The Runtime intentionally does not call `dlclose` for these backend handles; the operating system reclaims the mappings at process exit.
