# FAC API Layers — V53 design contract

This document defines the two API families requested for FAC. It is an architecture and compatibility contract; it does **not** claim that every proposed module or platform adapter exists in V53.

## 1. Cross-platform API

A cross-platform API has the same FAC source syntax, exported names, parameter/return types, ownership rules, error model, and observable semantics on every supported target. The implementation may be different per OS or architecture.

Examples of the intended surface:

```fac
import cross.fs.fac
import cross.net.fac
import cross.audio.fac
import cross.ui.fac
import cross.gpu.fac

var Result<string, Error> text = cross.fs.readText("config.json")
```

A cross API may expose a *portable capability subset*. It must not silently pretend that all native capabilities exist everywhere. It reports capability availability with `Option`, `Result`, or an explicit capability query; it must not change the meaning of an existing call by target.

Rules:

1. Names and semantics are platform-independent; implementation is selected by target configuration.
2. Unsupported capabilities fail deterministically with a documented error or are reported as unavailable before use.
3. Handles are opaque. Cross modules do not expose HWND, `FILE*`, `JNIEnv*`, `VkDevice`, or other native handles as their primary abstraction.
4. Blocking, async, cancellation, timeout, thread-safety, ownership, and error behavior are part of the API contract.
5. Cross APIs must not require callers to branch on the OS for normal use.
6. Optional advanced features are negotiated through capabilities, not platform-specific overload ambiguity.

## 2. Native API

Native APIs expose OS-, ABI-, driver-, or architecture-specific functionality. Their names and signatures may intentionally differ.

Planned import families:

```fac
import native.win32.fac       # Win32 / Windows SDK
import native.posix.fac       # POSIX interfaces available on the selected target
import native.linux.fac       # Linux-specific interfaces
import native.cocoa.fac       # Apple Cocoa / Objective-C interop layer
import native.android.fac     # Android NDK / JNI interop layer
import native.vulkan.fac      # Vulkan API bindings
import native.d3d12.fac       # Direct3D 12 bindings (Windows)
import native.metal.fac       # Metal bindings (Apple platforms)
```

The import examples above are target design examples. Missing files are not implemented modules. Current native access remains possible through the existing `extern function`, `link`, compiler link flags, and explicitly unsafe code described in `FFI.md`.

Native API rules:

- Native modules must declare target OS, architecture, ABI, minimum OS/SDK, and required libraries.
- A wrong-target import must fail at compile time with an actionable diagnostic; it must not silently become a no-op.
- Native handles are explicitly typed/opaque and must document who creates, retains, releases, and destroys them.
- Unsafe functions are marked `unsafe`; safe wrappers must validate inputs and define lifetime/ownership guarantees.
- Native API is allowed to expose capabilities unavailable in the cross layer, but source portability is not promised.

## 3. V45 compatibility mapping

For compatibility, the existing top-level `stdlib/*.fac` and compiler built-ins remain the V44-compatible public surface. They are classified as follows until migrated:

| Existing module | Intended classification | Current caveat |
|---|---|---|
| `math`, `string`, `result`, `time`, `random`, `json` | Cross-platform | Runtime/backend behavior still needs per-target verification |
| `file`, `fs`, `path`, `net`, `thread`, `sync` | Cross-platform façade | OS implementation and capability matrix are incomplete |
| `graphic`, `render`, `font`, `input`, `keyboard`, `mouse`, `ui`, `tui` | Cross-platform façade | Current window/input backend has Windows-only limitations; rendering/font are limited |
| `audio` | Cross-platform façade | PCM16/WAV/reference support; device playback is platform-dependent |
| `gpu` | Cross-platform façade | Current implementation is CPU reference buffers, not hardware GPU allocation/compute |
| `sys` | Platform-oriented built-in | Environment/process access is OS-dependent |

Do not move or rename these modules in place. A future cross namespace may add forwarding modules, and old imports must remain valid for the compatibility window defined in `COMPATIBILITY.md`.

## 4. Runtime adapter architecture

The intended runtime split is:

```text
FAC source
  ├── cross API (stable FAC contract)
  │     └── platform adapter selected by target
  │            ├── Windows adapter
  │            ├── POSIX/Linux adapter
  │            ├── Apple adapter
  │            └── Android adapter
  └── native API (explicit target contract)
        └── direct OS / ABI / driver binding
```

A cross API adapter must pass the same behavioral test suite on each supported target. Platform-specific tests supplement the shared suite; they do not replace it.

## 5. Support levels

Every module and target must publish one of these states:

- **Implemented + tested**: implementation exists and CI ran the test on the named target.
- **Implemented, not validated**: implementation exists but CI/runtime validation has not run.
- **Reference backend**: correct for contract tests or fallback use; not production hardware acceleration.
- **Planned**: design only; importing the module must not be advertised as supported.
- **Unsupported**: explicit compile-time rejection.

The word "cross-platform" is reserved for APIs whose semantics and conformance tests are shared across the targets claimed in the support matrix.


## 6. V53 current implementation status

`stdlib/cross/` and `stdlib/native/` contain only design documentation in this release. The older `stdlib/*.fac` modules are retained as the compatibility surface, and some are platform façades with incomplete target parity. No API is promoted to `cross.*` until it has identical source-level behavior and shared conformance tests on each supported target. No `native.*` module is promised until its target guard, ABI, SDK, link requirements and ownership wrappers are implemented.

For the complete product domain map, including audio/UI/2D/3D/ML libraries and target limitations, see [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md).
