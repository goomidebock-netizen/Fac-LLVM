# FAC V220 — Structural Type Reflection

## 1. Scope

V220 adds a bounded set of compiler intrinsics for inspecting the field metadata of a resolved `struct` or class-object type. The feature is compile-time metadata inspection, not unrestricted runtime reflection and not a source-level AST/declaration builder.

The supported forms are:

```fac
fieldCount<T>()
fieldName<T, I>()
fieldType<T, I>()
fieldOffset<T, I>()
```

`T` must be written as an explicit type argument and resolve to a complete `struct` type or class-object type (`obj`). These intrinsics take no runtime arguments. The index `I` must be a nonnegative integer constant expression.

## 2. Query contracts

| Intrinsic | Result | Meaning |
|---|---|---|
| `fieldCount<T>()` | `int` | Number of public, non-static instance fields |
| `fieldName<T, I>()` | static `string` literal | Name of the I-th visible field |
| `fieldType<T, I>()` | `enum Type` | Existing FAC `Type` category for the I-th visible field |
| `fieldOffset<T, I>()` | `int` | Byte offset of the I-th visible field in the compiler's active record layout |

The index is over the *visible field sequence*, not the raw declaration sequence. Private/protected fields and static fields are omitted from `fieldCount`, `fieldName` and `fieldType` indexing. Inherited public instance fields are included for resolved classes.

`fieldOffset` returns the actual layout offset of the selected field. The compiler calculates it from the full instance-field layout, so preceding private/protected fields and alignment padding still affect the value even though those fields are not enumerable. The offset is therefore layout metadata, not an access-control or security boundary. It is specific to the active target/layout rules used by the compiler.

`fieldType` returns the existing `Type` enum category, not a full `TypeId`, source type spelling or generic type descriptor. As with `typeOf<T>()`, array/list fields are classified by their element type.

`fieldName` materializes a static string literal. It can be used as a string expression in ordinary FAC code, but the current scalar integer/bool constant evaluator used by `static_assert` and `consteval` does not evaluate string values.

## 3. Example

```fac
import terminal.fac

public struct PlayerRecord {
    private var byte secret
    public var int id
    public var double score
    public array var byte payload[4]
}

public class BaseRecord {
    private var int internalTag
    public var int baseId
}

public class PlayerHandle extends BaseRecord {
    public static var int liveCount = 0
    public var byte state
}

static_assert(fieldCount<struct PlayerRecord>() == 3,
              "only public instance fields are enumerable")
static_assert(fieldType<struct PlayerRecord, 1>() == Type.Double,
              "second visible field type")
static_assert(fieldOffset<struct PlayerRecord, 1>() == 8,
              "offset follows the full instance layout")
static_assert(fieldCount<obj PlayerHandle>() == 2,
              "inherited public fields are included, static fields excluded")

public function void main() {
    terminal.out.println(fieldName<struct PlayerRecord, 0>())
}
```

Numeric queries (`fieldCount`, `fieldType`, `fieldOffset`) can be used in `static_assert`, supported scalar `consteval` bodies and const generic expressions. For example:

```fac
public consteval function int playerFieldCount() {
    return fieldCount<struct PlayerRecord>()
}

static_assert(playerFieldCount() == 3, "reflection query in consteval")
```

## 4. Validation and diagnostics

Compilation rejects:

- runtime arguments to a field query;
- a target that is not a resolved `struct` or class-object type;
- interfaces, enums and unresolved/incomplete record layouts;
- a missing, named, negative or non-constant field index;
- an index outside the public non-static instance-field sequence.

The compiler emits diagnostics at the query call site. An out-of-range query reports the query name, requested index and target record name.

## 5. Deliberate limitations

This V220 subset does not support:

- generic-specialized struct/class reflection (not implemented/verified in this release);
- enumeration of private or protected fields;
- enumeration of static fields;
- interface or enum member reflection;
- full field `TypeId`, generic arguments or source-level type spelling from `fieldType`;
- field attributes/annotations, method lists, constructors or visibility metadata as values;
- mutating reflected declarations or generating new declarations;
- source-level AST values, arbitrary compile-time execution, plugins or unrestricted macros.

The existing `stdlib/reflection.fac` module remains a convenience wrapper for type/category helpers. These structural intrinsics are compiler built-ins and do not change the module's `Reflector<T>` API.

## 6. Implementation and regression coverage

The implementation resolves the explicit type argument to a completed compiler `StructInfo`, builds the public non-static field-index sequence, and derives field categories/names/offsets from the compiler's own record metadata/layout. The semantic HIR model also assigns result types to these intrinsic calls (`int`, `string` or built-in `enum Type`) and validates them as built-in contracts.

Regression fixture: [`../tests/comptime/structural_reflection.fac`](../tests/comptime/structural_reflection.fac). Negative fixtures cover wrong target kinds, runtime arguments, non-constant indexes and out-of-range indexes. The fixtures also cover private/static filtering, inherited public fields, array element category reporting, actual layout offsets, `static_assert` and `consteval` integration.

Run:

```sh
make compiler-only CXX=g++ COMPILER_CXXFLAGS='-std=c++17 -O0 -g0' -j1
make runtime-only CXX=g++ CXXFLAGS='-std=c++17 -O0 -g0' -j1
sh tests/comptime/run.sh
sh tests/parser/run.sh
sh tests/run.sh -O0
sh tests/run.sh -O2
```

The V220 validation snapshot recorded in `docs/STATUS.md` gives the exact results for the current source tree.
