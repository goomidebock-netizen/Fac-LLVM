# FAC API conventions (V45)

One style for every library, built-in or written in FAC, so that how to call a function can be
guessed from its name. Nothing here changes the language syntax; it constrains how libraries are
designed. Machine-readable facts live in `api/manifest.json` (generated), judgement calls in
`api/meta.json`, enforcement in `tools/api_audit.py`, `tools/api_contract.py`, `tools/api_compat.py`.

## 1. Naming

| Thing | Rule | Example |
|---|---|---|
| module | lowercase, one word (it is the file name) | `string`, `tilemap` |
| function / method / field | lowerCamelCase, verb first for actions | `readText`, `trimLeft` |
| type (class, struct, enum, interface) | UpperCamelCase | `Tilemap`, `FsError` |
| constant | UPPER_SNAKE_CASE | `PI`, `INF` |
| predicate | `is` / `has` / `can` / `supports` + noun, returns `boolean` | `isFile`, `hasKey` |
| release | `free` (memory), `close` (stream/socket/file), `join` (thread); returns `void` | `json.free` |
| size | `length` (text/sequence), `size` (bytes of a file/buffer), `count` (occurrences) | `string.length` |
| conversion | `toX` returns a new value; `parseX`/`parse` reads text | `char.toInt` |

Word boundaries are always capitalised (`readLine`, never `readline`). Spell words completely and
correctly: the audit (rule N003) rejects known misspellings and adjacent-letter transpositions between
sibling names. A name that is not lowerCamelCase must be listed under `known_deviations` in
`api/meta.json` with a reason (today only `terminal.in.Scanner`).

One concept, one canonical name per module. Where a second name exists it is recorded in
`api/meta.json` as an alias with a reason and, when it should disappear, a deprecation window
(see `docs/COMPATIBILITY.md`). `docs/API_AUDIT.md` lists every recorded alias.

## 2. Error handling

Decision table for **new** APIs:

| Situation | Mechanism |
|---|---|
| Expected failure the caller should handle (missing file, bad input, network down) | return `Result<T, E>` (`import result.fac`), `E` a small enum with a message payload |
| Value may legitimately be absent (lookup miss) | return `Option<T>` |
| Yes/no question | `boolean` predicate; it never throws |
| Programmer error / violated precondition (bad index, null, invalid argument) | `throw Error(msg, code)` |
| Unrecoverable environment failure inside a *built-in* (out of memory, I/O in the runtime) | `Error` with a code from `docs/ERROR_CODES.md` |

Rules:

1. A function uses exactly **one** style. Do not mix a throwing and a `false`-on-failure function in
   one family (audit rule E001).
2. `boolean` is never used to mean "succeeded" in a new API (no detail is possible). Use `Result`.
3. `Error.code` values are never renumbered or reused (`docs/ERROR_CODES.md`); new failure kinds get new numbers.
4. Messages are for humans. Programs branch on the code or on the `Result` variant, never on text.
5. Legacy built-ins keep their behaviour (see compatibility). For the `file` family the standard-conforming
   wrappers are in `stdlib/fs.fac`; the same pattern applies to other families when they are migrated.
6. V218 `file.open` results are opaque Runtime tokens, not native `FILE*` values. Native operations sharing one
   token serialize with close, and stale-token I/O fails with Io (7). Never dereference/cast the token in FFI;
   managed `FileHandle` methods must not race close or final-owner destruction on the same object.

Today's built-ins fall into the classes below (`errors.model` in the manifest): `throws`, `predicate`,
`status-flag`, `ieee754` (math), `none-direct`. `none-direct` means the scan found no throw site in the
runtime function, not that it cannot fail.

## 3. Return types

| Result kind | Return type |
|---|---|
| nothing | `void` |
| yes/no | `boolean` |
| counts, lengths, indexes | `int`; sizes/offsets of files or memory `long`; time stamps `long` (seconds) or `ulong` (milliseconds, `time.now`) |
| search by position | index, or a negative value when absent (`string.find`) |
| text | `string` (owned) |
| several values | `list<T>` (owned) or a tuple `(A, B)` by value |
| may fail | `Result<T, E>` / `Option<T>` |
| native resource | handle (`ptr X`), with a documented release function |

The same operation has the same return type in every module (`find` returns `int`, `exists` returns
`boolean`, `free`/`close` return `void`). The audit enforces the name-driven cases (R001–R003).

## 4. Ownership

Vocabulary used in `@ownership` tags, in the manifest and in the generated reference:

| Term | Meaning |
|---|---|
| by value | a copy of a scalar; nothing to manage |
| borrowed | the callee reads it during the call and does not keep it; strings are immutable and shared, so borrowing is free |
| borrowed mutable (`ref T`) | exclusive borrow; the callee may modify the caller's variable |
| borrowed immutable (`ref const T`) | shared/read-only borrow for the duration of the call; direct writes are rejected by `--strict-ownership` |
| consumed | the callee takes over the value; the caller must not use or free it afterwards (`json.set` child, `thread.join` handle, every `free`/`close`) |
| retained | the callee stores a reference (documented explicitly) |
| owned result | the caller owns it and releases it (strings and lists are released automatically; handles need the paired `free`/`close`/`join`) |
| borrowed view | a result that points into another object; valid until that object changes or is freed; never freed by the caller (`json.get`, `json.at`) |
| non-owning handle | a `ptr` the callee does not free |

Every function that returns an owned handle documents its release function (audit rule O001).
Ownership of arguments is never transferred implicitly: transfer is a documented exception. `ref const`
contracts must not retain the argument beyond the call; the V45 static checker is conservative and is not
proof that a hidden alias or foreign callback cannot escape.

## 5. Thread safety

| Label | Meaning |
|---|---|
| safe-pure | depends only on its arguments; any number of threads |
| safe-atomic | built on atomics/locks; concurrent calls are fine |
| safe-per-thread | uses per-thread state (random engines) |
| thread-confined | a mutable handle may be used and released only by its creating thread; create one handle per worker |
| externally-synchronized | a handle/object must not be used by two threads at once without the caller's lock (policy for handle-based APIs: files, sockets, JSON trees; also camera mutation and raw-handle destruction) |
| unspecified | not analysed; treat as externally synchronized |

The software `graphic` Canvas is an internally synchronized exception: operations on a live handle serialize through a per-Canvas lock, and two-Canvas blits acquire both handles without lock-order deadlock. The caller must still prevent new uses before `graphic.free`; an in-object mutex cannot make concurrent destruction of a raw pointer safe. See `docs/RUNTIME_CANVAS_CONCURRENCY_V216.md`. The POSIX vector-font backend keeps Pango/Cairo/Fontconfig loaded for process lifetime because their process-global caches and worker/TLS teardown state cannot be safely unloaded during static destruction.

## 6. Documentation comments

FAC comments start with `#`; `##` marks documentation (same lexing). `//` and `///` are **not** FAC
comments. Put the block directly above the declaration, indentation matching it:

```fac
# Free-text description (one or more # lines, optional)
## @returns Owned string with the file contents.
## @ownership p=borrowed (immutable, shared); result owned by the caller.
## @errors Never throws for I/O failure; returns Err(NotFound | Io).
## @thread-safety Safe for concurrent calls on different paths.
public function enum Result<string, FsError> readText(string p) { ... }
```

All public functions of source libraries carry the four tags (`python3 tools/api_contract.py audit --strict`).
`python3 tools/api_contract.py generate --write` derives a first version mechanically from the declaration
and body, marked `## @generated V44 (...)`; delete that marker line to take over the block. Generated
text is conservative ("Unspecified", "No direct throw; callee errors propagate") rather than optimistic.

## 7. Checklist for a new or changed API

1. Name follows section 1; no second spelling is introduced without an alias entry and reason.
2. One error style (section 2); codes documented.
3. Return type from section 3.
4. Ownership and thread-safety stated (section 4/5), release function named.
5. `##` contract tags written; example added under `examples/api/` if it introduces a new pattern.
6. `make api-check` is green (manifest, audit, compatibility against the last release, docs, contract tags, platform standards inventory).
