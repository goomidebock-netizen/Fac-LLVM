# FAC `--memory-safe` profile — V263

## V260 note — profile unchanged

V260 tightens pointer-field return rejection only in ordinary `--strict-ownership`
analysis for inferred (`auto`) returns through untracked enum pointer payloads.
It does not admit raw pointer types, `addr`, or these enum payload cases into
`--memory-safe`, and does not widen this profile's accepted subset.



## V256 note — profile unchanged

V256 tightens enum-payload pointer-return rejection in ordinary `--strict-ownership` analysis only. It does not add enum payload provenance, raw pointer types or `addr` to `--memory-safe`, and does not widen this profile's accepted subset.

## V235 note — profile unchanged

V235 improves branch-aware return provenance only in ordinary `--strict-ownership` analysis. It does not admit raw pointer types or `addr` into `--memory-safe`, does not add a `ref T` return type, and does not widen this profile's accepted subset.


## V233 note — profile unchanged

V233 adds a bounded local direct-call-only closure capture proof only to ordinary strict-ownership analysis. It does not add raw pointers or `addr` to `--memory-safe`, does not permit pointer-bearing closure captures in this profile, and does not widen the accepted subset. General closure lifetime inference and whole-program escape analysis remain unsupported. See [`MEMORY_MANAGEMENT_V233.md`](MEMORY_MANAGEMENT_V233.md).

## V231 note — strict-ownership improvements only

V231 extends bounded pointer-return lifetime inference through nested local aliases and tightens closure-capture checks in ordinary strict-ownership code. It does not add raw pointers or `addr` to `--memory-safe`, does not widen this profile, and does not provide general closure/heap escape analysis. See [`MEMORY_MANAGEMENT_V231.md`](MEMORY_MANAGEMENT_V231.md).

## V228 note — strict-ownership aggregate flow only

V228 propagates local aggregate pointer provenance through blocks and selected control-flow joins in ordinary strict-ownership analysis. It does not add raw pointer types or `addr` to `--memory-safe`, and does not widen this profile's accepted subset. Loop-carried changes are invalidated because no loop fixed point is claimed. See [`MEMORY_MANAGEMENT_V228.md`](MEMORY_MANAGEMENT_V228.md).

## V227 note — nested local reborrow graph validation

V227 strengthens the strict-ownership loan graph used by this profile: each nested local reborrow must preserve the original storage owner, stay within a known exact parent field projection, have a parent loan that outlives the child, and link to a present acyclic parent chain. This improves checking of local nested value-struct borrows but does not expand the profile's accepted pointer/escape subset, does not permit storing borrows in aggregates/globals/containers/closures, and does not prove general heap aliasing or thread race freedom. See [`MEMORY_MANAGEMENT_V227.md`](MEMORY_MANAGEMENT_V227.md).

## V225 note — profile unchanged

V225 permits certain tracked pointer fields only in local value structs under ordinary `--strict-ownership` / `--secure` analysis. The `--memory-safe` profile continues to reject raw pointer types and `addr`, so it does not admit these aggregate pointer-field cases. The profile's accepted language subset and Runtime behavior are unchanged.

## Purpose

## V224 note — profile unchanged

V224 adds a bounded lifetime-elision rule for raw-pointer return functions under ordinary strict-ownership analysis. The profile in this document still rejects raw pointer types and `addr`, so none of the new pointer-return inference cases are admitted by `--memory-safe`. This release does not add borrowed-reference fields in aggregates/globals/containers, and it does not change the `ref` storage restrictions of this profile.

## V223 borrow/lifetime regression coverage

`tests/memory_safe/run.sh` runs 39 checks. In addition to checked parameter/local borrows, the suite compiles and executes `good_heap_object_field_borrow.fac` and nested value-field fixtures. It verifies that a local mutable alias updates the borrowed field, permits disjoint nested value-field paths, and rejects overlapping owner writes and nested managed-object/weak-reference boundaries. This remains a local borrow rooted at a tracked strong `obj` handle; storing a borrow in an aggregate/object field or container is unsupported.

V222's single-input pointer return lifetime elision and V224's body-proven multi-pointer return-source inference apply to verified direct FAC functions outside the `--memory-safe` profile, because that profile continues to reject raw pointer types and `addr`. Multi-pointer inference requires one direct return source and verified `noescape` contracts on every other pointer input. Extern, abstract and unverified function-value cases remain conservative. See [`MEMORY_MANAGEMENT_V222.md`](MEMORY_MANAGEMENT_V222.md) and [`MEMORY_MANAGEMENT_V224.md`](MEMORY_MANAGEMENT_V224.md).

## V135 Runtime note

V135 does not expand the accepted `--memory-safe` language subset or claim a stronger borrow/lifetime proof. It fixes two Runtime list-construction error paths (`sys.args` and JSON array conversion) so partial lists and already-converted strings are released when a later FAC error transfers control through the existing cleanup stack. The focused leak-counter test passes under ASan+UBSan. The broader `setjmp`/`longjmp` destructor limitation remains unchanged.


`--memory-safe` is a deliberately conservative, fail-closed language subset. It is intended for programs that want the compiler to reject facilities whose lifetime/aliasing guarantees are not fully enforced by FAC's current static analyses.

It is **not Rust-equivalent** and is **not a formal memory-safety proof**. In particular, FAC does not yet have a complete region-based borrow checker, a general lifetime/type system, or a whole-program data-race proof. The compiler, LLVM backend, C++ Runtime, and every enabled built-in implementation remain trusted components.

## Enforced by this profile

The profile automatically enables:

- `--safe` and `--strict-safe`;
- strict Ownership and Move checks;
- `--no-trust-stdlib` (source standard-library modules are checked rather than silently trusted);
- integer overflow checks;
- the normal array/list bounds and division-by-zero checks.

It rejects source programs that use:

- raw and opaque pointer types, manual `heap` storage, pointer dereference, `addr`, `alloc`, `realloc`, `free`, C function-pointer and raw memory primitives;
- `unsafe` blocks/functions, `extern` declarations, native `export`, and native `link` directives;
- native object/source inputs, external linker flags/packages, shared/native library output, or generated native headers supplied on the compiler command line;
- imports of built-in modules whose public built-in table exposes raw native pointer/handle parameters or results (for example file handles, sockets, graphics, JSON DOM handles, threads, GPU/audio/tensor handles), even if only a function value is requested;
- the `sys` built-in module, because it exposes process execution; `sys.run` and `sys.output` references/calls are also rejected, including import aliases.

Checked `ref` parameters and function-local `ref` / `ref const` bindings are permitted in V221. They must pass strict ownership and local-loan analysis; unsupported roots, aliasing, projections and escape paths are rejected. Borrow bindings are not permitted in module globals or aggregate fields because those storage lifetimes are not covered by the local loan model. The profile is still a restricted safe subset, not a complete lifetime/type system or a Rust-equivalent guarantee. Some otherwise-safe APIs remain excluded because they expose manually managed opaque handles rather than compiler-checked ownership types.

## What remains guaranteed only by trusted components

The profile still relies on the correctness of FAC's compiler, generated LLVM IR, and C++ Runtime. Managed strings, arrays/lists, closures, class objects and the runtime's retain/release implementation are not formally verified. Internal runtime operations can still contain defects. `setjmp` / `longjmp` based FAC exception transfer remains part of the runtime implementation and is not a Rust-style destructor-unwinding model.

The profile also does not establish:

- race freedom or safe sharing of mutable state between threads;
- deadlock freedom, termination, CPU limits, or memory quotas;
- filesystem confinement, network isolation, process isolation, or OS sandboxing;
- safety of code generated by a compromised/misconfigured external toolchain;
- correctness of all parser, optimizer, code generator, or runtime paths.

`--memory-safe` is a compiler language-subset gate, **not** an OS sandbox. Do not run untrusted binaries with elevated privileges. Do not load native plugins or pass native inputs; those paths are rejected by this profile but remain available in normal FAC builds.

## Usage

```sh
facc app.fac --memory-safe -O2 -o app
```

The profile cannot be combined with options that disable bounds or division checks, including `--unsafe-fast`. It rejects native link flags and native compilation inputs. Use ordinary FAC build modes for systems programming requiring FFI or raw handles; those programs are outside this profile and require explicit review.

## V221 regression coverage

`tests/memory_safe/run.sh` runs 31 checks: managed scalar, pure-math, class/list and payload-enum acceptance (including a managed object/list execution smoke test), pointer/heap/unsafe/extern/link rejection, checked ref-parameter/local-borrow acceptance and runtime smoke tests, conflicting/unknown borrow rejection, and global/aggregate-field borrow-storage rejection, raw-memory primitive rejection, built-in native-handle rejection, shell-process rejection through an import alias, `--unsafe-fast` and external linker-flag rejection, plus runtime bounds/overflow guard checks. This test set is targeted coverage, not proof of soundness.

`tests/runtime/refcount_concurrency.cpp` stress-tests concurrent final release of managed strings, objects, weak handles and closures. It is a regression test for those paths, not a proof of all runtime races or memory-safety properties.


## Performance measurement

The V134 microbenchmark figures below describe an older implementation and must not be treated as V221 measurements. V221 expands the profile to permit checked borrows, so the earlier compile-time overhead comparison is no longer a measurement of the current profile. Re-run `benchmarks/memory_safe_compile.py` against a V221 compiler before making performance claims.
