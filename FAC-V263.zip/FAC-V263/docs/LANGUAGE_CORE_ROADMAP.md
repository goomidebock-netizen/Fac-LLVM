# FAC Language Core Architecture and Roadmap — V61

This is the authoritative plan for the language's core direction. It distinguishes features already present from planned work so that Syntax, compiler behavior, and marketing claims remain aligned.

## 1. Product target

FAC is intended to be one statically typed, native-capable, general-purpose language for small and large applications: system tools, desktop/mobile applications, backend services, interactive UI, 2D/3D games, audio processing, ML/DL/AI workloads, and low-level systems programming. It is not intended to replace HTML/CSS/JavaScript, PHP, or SQL as specialized web/database languages.

Primary quality goals, in order:

1. **Correctness and stability**: predictable semantics, diagnostics, compatibility policy, regression coverage and reproducible builds.
2. **Memory and concurrency safety**: safe-by-default managed types, static ownership/borrowing, checked unsafe boundaries and data-race prevention.
3. **Very high native performance**: zero-cost abstractions where practical, specialization, LLVM optimization, efficient runtime data structures and low allocation overhead.
4. **Broad application capability**: common language core and reusable standard APIs across OS/architecture, with explicit native escape hatches.
5. **Approachable syntax**: clear, explicit, Java-readable declarations and type information; use concise syntax only where it materially improves readability.

The goals are quality targets, not measured claims or guarantees that V47 already achieves them.

## 2. Syntax design principles

- Keep the existing FAC spelling and block syntax where possible.
- Prefer explicit declarations such as `array var int values[10]`, `public function int sum(...)`, `class`, `struct`, `enum`, and named constructors.
- Use `var`, `ptr`, `dyn`, `heap`, `array`, `list`, `struct`, `enum`, `obj` consistently; do not add overlapping keywords that mean the same thing.
- Make ownership-changing operations visible (`move`, future `take`, borrow modifiers).
- Put unsafe operations behind `unsafe` boundaries and require `--safe` checks by default in safety-focused build profiles.
- Preserve V44 source compatibility: add syntax where possible; any breaking syntax change needs a proposal, migration tool, tests and compatibility-window decision.

## 3. Current implementation vs target

| Area | V47 state | Next engineering milestone |
|---|---|---|
| Basic core / lexical / modules | Implemented broad subset | Formalize grammar, module visibility and diagnostics |
| Variables, arrays, lists, structs, enums, tuples | Implemented with documented limits | Consistent layout, bounds and value semantics |
| Control flow | `if`, loops, switch/match, guards, labels, `defer`, try/catch | Add structured pattern coverage, iterators and loop control specification |
| Functions / closures | Functions, overload, default/variadic parameters, function values and lambdas | Explicit capture modes, better inference and effect contracts |
| OOP | Classes, objects, constructors/destructors, inheritance, interfaces, access modifiers, virtual dispatch | Const methods, sealed hierarchies, property rules and stronger variance/dispatch semantics |
| Generic programming | Generic class/struct/interface/enum and methods; multiple `&` bounds, named arguments, type defaults across generic declarations, const defaults on structs/classes/functions/methods and bounded free-function inference | Broader type/class/method inference, generic interface methods and generalized trait solving |
| Functional programming | Lambda, higher-order callbacks, function values, expression match, Option/Result payload enums | Complete function-returning-function workflows, immutable collections and composable result helpers |
| Type system | Static scalar/aggregate types, generic specialization, bounds, aliases and enum payloads | Type inference, explicit nullability, variance, trait/interface solver and better diagnostics |
| Ownership / move | Managed retain/drop, weak handles, explicit `move`; V51 CFG fixed-point analysis over whole-local moves | Partial-move analysis, ownership-taking APIs and typed initialization states |
| Borrowing | `ref` / `ref const`; V53 lexical local loan aliases with exclusive/shared checks, tracked-root and pointer-escape guardrails | Persistent CFG loan graph, NLL, reborrow, borrow escape and alias-aware lifetime analysis |
| Lifetime / dangling references | No general lifetime checker; no first-class returned borrow model | Infer lifetimes for all borrow-capable values; detect escape/dangling at safe boundaries |
| Static data races | Conservative closure isolation for checked thread calls; atomic/channel/cell APIs | Effect summaries, alias analysis, lock/atomic reasoning and sendability |
| Compile-time programming | Integer/bool constant evaluator, `static_assert`, bounded `const int` parameters/constraints, named/default arguments, direct fixed-array inference for generic free functions, restricted scalar free-function `consteval`, type/layout and public-field queries, immutable typed-expression AST, internal `TypedAstFactory`, `TypedDeclarationBuilder`/`TypedFunctionBodyBuilder`, and bounded Codegen lowering for generated structs, external prototypes and scalar function bodies with mutable locals/assignments/nested if-else | Full typed/aggregate constants, generic structural reflection, broader dependent-expression solving, generic/method consteval, loops, multiple returns and branch-local generated scopes, source-level AST/declaration APIs, generated classes/methods/generics and full post-generation semantic analysis |
| Template programming | Type-generic specialization plus restricted `const int` struct/class parameters, substituted through declaration-body expressions and usable for fixed-array fields | Const parameters on enums/interfaces, general dependent-expression solving and wider compile-time values |
| Metaprogramming | Compiler-internal immutable typed-expression AST projection and C++ `TypedAstFactory`, bounded public-field reflection, C++ `TypedDeclarationBuilder`/`TypedFunctionBodyBuilder`, and bounded Codegen projection for generated non-generic structs, external prototypes and scalar free-function bodies with mutable locals, assignments and nested if/else; no FAC-level AST/declaration values or macros | Source-level typed AST/declaration values, generic/full structural reflection, loops, multiple returns, branch-local scopes, classes/methods/generics, richer field layouts and full post-generation semantic integration |
| Low-level programming | Raw pointers, volatile, alignment, FFI, target flags and native code generation | Inline assembly, stable intrinsic surface, packed/layout controls and bare-metal profiles (separate design) |
| Concurrency | Threads, atomics, channel, cell | Task runtime, async/await, cancellation and safe shared ownership |
| GPU | CPU reference buffers only | Real backend(s), shader pipeline and queue synchronization |
| Cross-platform API | Existing mostly portable façade modules; not every backend validated | Formal cross API semantics and shared conformance tests |
| Native API | Existing FFI and OS-dependent runtime code | Versioned, target-gated native modules |

## 4. Core feature design requirements

### 4.0 Multi-paradigm contract

FAC is a multi-paradigm language, not a collection of separate modes. Procedural functions/control flow form the baseline; OOP adds identity and polymorphism; structs/enums preserve value-oriented modeling; generics provide statically typed reuse; function values/lambdas enable selected functional composition; compile-time evaluation supports bounded invariants and specialization; and raw pointers/FFI provide explicit native escape hatches.

Do not add a paradigm-specific keyword when an existing construct already expresses the intent. In particular, `auto` generic functions and explicit type parameters belong to the same generic system, while template programming with compile-time value parameters is a bounded capability: V220 supports bounded `const int` parameters on structs/classes, free functions and methods; named arguments, trailing generic defaults and direct fixed-array extent inference for generic free functions are supported, not a general template execution system. The current syntax, maturity labels, limitations and examples are consolidated in [`LANGUAGE_PARADIGMS.md`](LANGUAGE_PARADIGMS.md).

Procedural support should keep evaluation order, parameter passing, `ref`/`ref const`, scope cleanup and error propagation explicit. OOP additions must preserve the distinction between identity-bearing `class`/`obj` and value-semantic `struct`. Functional additions must define closure capture, ownership and result propagation before broadening inference or collection APIs. Metaprogramming/template additions must remain deterministic, resource-bounded and unable to bypass ordinary type/ownership checking. Low-level additions must preserve explicit unsafe boundaries and must never confuse `volatile` with atomic synchronization.


### 4.1 Basic language and control flow

The core must specify declaration order, scope and shadowing, evaluation order, integer overflow, numeric conversions, default initialization, nullability, pattern exhaustiveness, unreachable branches, exceptions and `defer` execution order. Array indexing and allocation size must be overflow-checked before memory allocation. `switch` should remain for scalar compatibility; `match` should be the expressive destructuring form.

Recommended future additions:

- `for (Type value : collection)` as a readable, scoped iteration form only after iterator semantics exist;
- `match` support for nested struct/tuple patterns and guards;
- a documented `break`/`continue` policy for nested labelled loops;
- `static_assert` for compile-time invariants;
- explicit `fallthrough` only if switch semantics ever require it.

### 4.2 Object-oriented programming

Keep `class` for identity/reference semantics, `struct` for value semantics, and `enum` for tagged sum types. Keep constructors/destructors explicit. Additions should prioritize const-correct methods, `sealed`/`final` type semantics, deterministic virtual dispatch and clear field initialization. Do not make every data type an object; value-oriented programming remains first-class.

### 4.3 Type system and generics

The type system should converge on:

- inference for local variables and generic call arguments without weakening static checking;
- interface/trait constraints with multiple bounds;
- associated types only if they solve a concrete library need;
- explicit nullable/reference distinctions;
- variance rules for read-only vs mutable generic containers;
- monomorphization budget and recursion diagnostics;
- no implicit dynamic boxing in hot generic paths unless requested.

### 4.4 Functional programming

The existing closure and function-value model should grow toward composable code: reliable closure return, nested higher-order functions, explicit capture policies, immutable values, lazy iterators and `Option`/`Result` combinators. Do not force a pure functional model on native systems code; support procedural, object-oriented and functional styles together.

### 4.5 Low-level programming

Expose low-level ability without silently making it safe. Keep raw `ptr` operations, `volatile`, `align`, FFI and future assembly/intrinsics inside clear safety boundaries. Add explicit `repr(C)`/layout attributes, fixed-width C interop types, atomic pointer operations and SIMD types only with backend/runtime tests. `volatile` must never be presented as atomic synchronization.

## 5. Standard library shape

Use consistent namespaces and avoid one giant standard module. API naming should use lowerCamelCase for functions, UpperCamelCase for class/type names and named enums for modes/results. Each public function must document return ownership, errors, thread safety, blocking behavior and target availability.

Preferred API split:

- functional APIs for stateless operations (`math.sqrt`, `string.split`, `json.parse`);
- objects for owned resources and state (`audio.Stream`, `ui.Window`, `gpu.Buffer`, `net.Client`);
- explicit creation/disposal or RAII via deterministic destructors with documented failure/cancellation semantics;
- `Result<T, E>` for expected failures and exceptions only for exceptional propagation/compatibility boundaries.

## 6. Release gates

A feature is **implemented** only when it has: grammar/parser support, semantic/type checking, code generation/runtime semantics, diagnostics, unit and negative tests, documentation/spec updates, API manifest updates if public, and build/CI coverage. A parser accepting syntax is not sufficient.

A platform is **supported** only after meeting `PLATFORM_STANDARDS.md` conformance gates. A library is **cross-platform** only after shared behavior tests pass on every target claimed.

## 7. Prioritized V48 → later release order

1. Stabilize V47 changes and build/test tooling.
2. Complete type/ownership analysis on the typed AST/CFG: immutable/mutable loans, moves, escape, partial initialization.
3. Runtime safety and stress tests: allocation arithmetic, destructor/unwind paths, async-safe cleanup.
4. Specify and implement type inference and multi-bound generics.
5. Formalize cross/native API contracts and build one proven backend adapter at a time.
6. Async/task model and static race/effect analysis.
7. Compile-time execution, const generics and typed metaprogramming.
8. GPU/audio/UI production backends and ML/DL integration APIs.


## V48 implementation notes

- At V48, strict ownership rejected calls through all `ref const` member receivers because const-qualified methods were not yet modeled. V50 adds trailing const method contracts and permits calls only to checked const methods; defaulted and variadic ref parameters remain rejected.
- The runtime now captures FAC errors and uncaught C++ exceptions from `thread.start` workers and reports them from `thread.join`.
- Full control-flow loan analysis, inferred lifetimes, dangling-reference detection, typed task results, cancellation, and whole-program static race analysis remain future milestones.


## V51 progress

V51 adds CFG-based forward fixed-point move-state analysis, including loop back-edges, branch joins, lexical shadowing, early exits and conservative exceptional paths. It improves `--strict-move` but does not yet implement a persistent loan graph, general inferred lifetimes, dangling-reference analysis, partial moves or static race analysis. The V50 const-qualified method contracts remain in place.


## V52 progress and product-wide alignment

V52 adds top-level `static_assert` with a side-effect-free integer/bool constant evaluator. It supports arithmetic, comparisons, bitwise and short-circuit logical operators, and rejects overflow, divide-by-zero, invalid shifts and runtime-dependent expressions. V220 adds a restricted `consteval` interpreter for scalar free functions, with supported locals/branches/returns/nested calls/recursion and depth/step budgets; `typeOf<T>()`, `sizeof<T>()` and `alignof<T>()` provide typed type/layout constants. V220 additionally exposes bounded structural field queries: `fieldCount<T>()`, `fieldName<T,I>()`, `fieldType<T,I>()` and `fieldOffset<T,I>()` for public non-static fields of resolved struct/class records, including inherited public class fields. V220 also builds an immutable, source-mapped typed-expression AST projection from expression HIR nodes whose types and required children are fully known; unresolved or unsupported expressions are deliberately omitted. It now includes an internal C++ `TypedAstFactory` for validated immutable generated expression nodes (literals, supported unary/binary expressions, tuples and exact pre-resolved non-generic free-function calls). The factory is not exposed to FAC programs, does not generate declarations and does not feed generated nodes to code generation. Separately, `TypedDeclarationBuilder` can register bounded non-generic generated structs and free functions in HIR; the generated-declaration Codegen bridge lowers eligible struct layouts and external function prototypes and now also emits bounded generated scalar function bodies with mutable locals, assignments and nested `if/else`, without source-AST mutation. See [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md). Structural queries do not provide full/generic reflection, arbitrary compile-time execution or a macro system. V220 also adds a separate bounded `const int` generic subset for types and functions: values are substituted in declaration-body expressions and can determine fixed-array dimensions.

V67 propagates observed lock context through direct worker-call chains and classifies common-lock versus unprotected ordinary accesses on top of V66 typed global effects; it is not yet a whole-program race proof. Mutable global payload access remains rejected until aliases and all concurrent accesses can be verified. The authoritative full product/status matrix covering Basic Core, Control, Functions, OOP, Generic/Type System, Functional, Low-level, CTM, Ownership/Borrowing/Lifetimes, Static Race Analysis, Runtime, Cross/Native APIs, OS/Architecture/ABI/GPU standards and application libraries is [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md). It must be updated whenever implementation or support status changes.


## V53 progress

V53 adds lexical local borrow bindings (`ref var T alias = lvalue` and `ref const var T alias = lvalue`) under strict ownership mode. The checker enforces shared/mutable exclusivity, blocks conflicting owner access and moves, restricts shared method calls, rejects pointer exposure, and fails closed for const/untracked roots and unsupported alias declarations; verified direct `ref` calls may use temporary reborrows. This is an initial lexical analysis, not NLL or a CFG loan graph. The V53 matrix records exact maturity and remaining product goals.


## V53 progress: local borrowing

V53 adds local `ref var T alias = lvalue` and `ref const var T alias = lvalue` declarations under `--strict-ownership` / `--secure`. These aliases point at original local/parameter/receiver storage and hold conservative lexical loans. Shared loans may coexist; mutable loans are exclusive; owner access, moves, address exposure, shared-method mutation and unsupported alias declarations are checked; verified direct `ref` calls may use temporary reborrows. Closure bodies are analyzed under active loans; non-scalar borrow-alias captures are rejected until escape/lifetime analysis exists.

V54 adds bounded statement-level last-use expiration, but this is not a persistent CFG loan graph or full NLL. The checker remains conservative, without reference return/store support, partial moves, field-sensitive disjointness, raw pointer/FFI alias proof, general lifetime checking or whole-program data-race analysis. See `docs/OWNERSHIP.md` and `docs/FAC_LANGUAGE_TARGETS.md`.


## V56 ownership update

The current strict local-borrow implementation resolves both borrow aliases and local owner roots by declaration identity. It handles shadowed locals and same-name reborrows without merging unrelated storage. The remaining work is a general region/outlives solver, reference return/store model, precise exceptional/defer edge semantics, field-sensitive alias analysis, partial move and static race analysis. See `OWNERSHIP.md` and `FAC_LANGUAGE_TARGETS.md`.


## V61 implementation update

V61 adds bounded field-sensitive borrowing for distinct direct first-level fields of the same resolved local aggregate declaration, plus pointer `readonly` effects independent from `noescape`. The combined `readonly noescape` contract supports synchronous read-only access to caller storage. Abstract/interface effect declarations are accepted and implementations cannot weaken promised effects. Nested/indexed/computed paths, general effect inference, target-aware indirect-call proof, overload-aware effect resolution and whole-program data-race proofs remain incomplete; V64 adds function-value effect signature preservation and compatibility checks. See [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md) and [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md).


## V64 — effect-aware function types

V64 preserves `noescape` and `readonly` parameter effects in explicit function-value signatures, named function values and lambdas. Function-value compatibility allows stronger implementation guarantees but rejects weakened required effects. The metadata does not change closure ABI. Indirect-call escape proof remains conservative until the checker can resolve and verify the concrete function-value target; overload-aware effect resolution and static data-race analysis remain next steps.

## Compiler frontend: Expression HIR (V220 development)

A source-mapped Expression HIR index now follows declaration HIR and
name/type resolution. It types only literal and syntax-provable operator forms,
known tuple/lambda shapes, `new Class`, and selected builtin result contracts.
Local/parameter lookup, user-call overload resolution, member/index typing,
generic inference and control-flow type unification deliberately remain in the
legacy Codegen semantic path until their diagnostic behavior can be migrated
with differential regression coverage. See `docs/EXPRESSION_HIR_V220.md`.


## V220 named generic arguments

Named generic arguments are now supported for generic struct/class types, free
functions and methods using `parameter = argument`. Positional arguments may
precede named arguments, but not follow them. All parameters remain required;
unknown, duplicate and missing names are rejected. The compiler normalizes the
argument vector to declaration order before HIR mapping and specialization
cache lookup. This improves call-site readability without changing generic
inference or adding defaults/partial application. See
`docs/NAMED_GENERIC_ARGUMENTS_V220.md` and `docs/GENERIC_SPECIALIZATION.md`.


## V220 compiler frontend extraction: lexical scopes, overloads and generic methods

The declaration and expression HIR includes a lexical-scope index and a
conservative overload resolver. Parameters and local declarations receive
`LocalSymbolId` values in nested module/function/block/loop/lambda/catch/match-arm
scopes; source-order metadata preserves declaration-point visibility and
shadowing. Known local types flow into expression HIR, including `auto` locals
whose initializer type becomes known after direct calls are resolved.

Non-generic free functions can be selected when argument types are known. The
resolver supports exact semantic matches, conservative numeric widening,
default arguments and imported module aliases with `just`/`without` filtering.
It also resolves statically identifiable class instance/static method calls.
Named method type parameters keep the existing explicit type-argument syntax;
`auto` parameter positions, including list/array element positions, can be
inferred from known arguments. Generic parameters in `list T` and `array T`
are matched against concrete element types, and generic class parameters are
substituted from concrete receiver types including named arguments. Nested
generic return types are structurally interned. Built-in and resolved named
constraints distinguish proven violations from unresolved evidence.

Ambiguous, no-viable, constraint-failure and unresolved calls are recorded as
HIR states; the pass does not emit diagnostics or replace Codegen's decisions.
Generic virtual/interface methods, inherited and complex imported receiver
lookup, indirect calls, complete trait solving, member/index typing and full
conversion checking remain outside this extraction boundary. See
`docs/GENERIC_INFERENCE_HIR_V220.md` for exact rules and limits.


## V220 semantic diagnostics and generic free-function inference

The development HIR now records conservative generic free-function inference
for direct type parameters and `ptr T`, `list T` and `array T` parameter forms.
Repeated named type parameters require consistent semantic type evidence; the
HIR does not use numeric widening to reconcile conflicting generic deductions.
Built-in and resolvable named constraints retain satisfied / failed / deferred
semantics. A source-mapped diagnostic collector records inference notes and
known ambiguous, no-viable and constraint-failure outcomes. These diagnostics
remain provisional HIR data and are not yet emitted by the CLI; Codegen remains
authoritative for final diagnostics, specialization and LLVM lowering.
See `docs/GENERIC_INFERENCE_HIR_V220.md`.
