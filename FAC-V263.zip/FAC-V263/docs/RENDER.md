# FAC Shared Renderer Contract

Import `render.fac` when code should issue common 2D drawing commands through the shared renderer facade.

```fac
import graphic.fac
import render.fac

public function void main() {
    ptr graphic win = graphic.open(640, 360, "Renderer facade")
    while (graphic.poll(win)) {
        render.clear(win, graphic.rgb(18, 22, 32))
        render.fillRect(win, 24, 24, 180, 72, graphic.rgb(70, 130, 220))
        render.text(win, 40, 50, "FAC Renderer", graphic.rgb(255, 255, 255), 2)
        render.present(win)
    }
    graphic.free(win)
}
```

Current operations: clear, pixel, line, rect, fillRect, circle, fillCircle, fillTriangle, text, measureText, image, blit, blitKey, blitAlpha, blitRegion, blitRegionEx, hasAlpha, alphaAt, and present.

## Image composition

Image operations are available through `render` so UI/application code does not need to reach into `graphic` for common composition:

```fac
render.blitAlpha(canvas, sprite, 32, 48)
render.blitRegion(canvas, atlas, 0, 0, 16, 16, 64, 48)
render.blitRegionEx(canvas, atlas, 80, 48, 16, 0, 16, 16, 0)
```

`blitRegionEx` takes destination x/y, source x/y/width/height, then flip flags (bit 0 = horizontal, bit 1 = vertical). `hasAlpha` and `alphaAt` query source-image alpha metadata/pixels. These calls preserve the current software backend's behavior; they do not imply GPU texture support.

**Backend status:** V16 maps this contract to `graphic.fac`'s software canvas. The contract centralizes the drawing boundary, but backend selection, GPU command buffers, render targets, clipping/scissor state, and GPU resource lifetime are future work. `three.fac` still performs its 3D rasterization through the Graphics canvas directly.
