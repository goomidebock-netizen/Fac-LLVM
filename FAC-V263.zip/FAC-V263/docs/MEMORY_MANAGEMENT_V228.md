# FAC Memory Management Direction — V228

V228 makes local aggregate pointer-lifetime facts flow through lexical blocks and supported control-flow merge points. It closes a stale-provenance gap where a write performed in a nested block could be discarded with the block's temporary analysis context, leaving the enclosing scope with an older pointer origin.

## 1. Lexical block propagation

A block still owns its declarations and lexical lifetime region. Writes to an aggregate declared outside the block, however, remain visible after the block. On block exit, the checker propagates only facts whose root declaration identity is unchanged; a same-spelling shadow declaration cannot overwrite the outer binding's facts. Pointer-local origins are propagated under the same declaration-identity rule because a pointer local can later initialize or overwrite an aggregate field.

## 2. Control-flow joins

`if` arms and `switch` / `match` alternatives now join field-path provenance for visible local value structs. `try` and `catch` alternatives are joined before the `finally` body is analyzed. At a merge, each exact field path must have a known fact on every possible predecessor. The checker unions every possible `PointerOrigin` for that path, and later stores/returns must prove that all origins satisfy the destination lifetime.

A branch with no `else`, or a switch without `default`, contributes the incoming state as an additional possible predecessor. Known-null facts remain present empty-origin facts; a missing path fact remains Unknown and is never converted to Null. This is deliberately a may-origin join, not a guessed single-source result.

## 3. Loop boundary and fail-closed escape handling

V228 does not claim a loop fixed-point analysis. If a loop body changes a visible aggregate pointer-field fact or pointer-local origin, the corresponding post-loop fact is invalidated. A later read therefore fails closed until a separately verified fact is established. This avoids retaining a pre-loop origin that may not describe a value written in a later iteration. Loop-local declarations are excluded by declaration-identity checks.

At return, the existing aggregate escape checker now receives joined origins from blocks and supported branch merges. Every possible origin must outlive the declared return lifetime; an explicit `where longer: shorter` relation can justify a source only when the function contract states that relation. Shorter or incomparable branch origins are rejected. Unknown field provenance remains rejected.

## 4. Regression coverage

V228 adds rejection tests for: a shorter-lifetime pointer written in an `if` arm; a write in a nested lexical block; a shorter-lifetime pointer written in a `switch` case; a shorter-lifetime pointer written in a `try`/`catch` path; a pointer local reassigned in a nested block before aggregate initialization; and an aggregate field changed inside a loop. Positive tests cover two sources with the same named lifetime, a known-null branch, and a branch source justified by an explicit `where b: a` contract.

## 5. Explicit boundaries

This remains intraprocedural and limited to local value structs and tracked pointer locals. It does not add pointer-bearing aggregate parameters/returns as a general public contract, references stored in globals/containers/closures, arbitrary heap alias analysis, a loop fixed-point solver, general raw-pointer safety, whole-program escape proof, or data-race freedom. ARC, Cycle Collector, Runtime allocation, public API, C ABI and Runtime ABI are unchanged. `--memory-safe` acceptance is unchanged; these checks remain part of ordinary strict-ownership analysis.

## 6. Validation

V228 validation is recorded in `docs/STATUS.md`. The lifetime, ownership, move, memory-safe, parser, lexer, focused codegen and secure-profile suites were run against the rebuilt V228 compiler. The complete tooling suite exceeded the local command time limit; only its two version-bump unit tests are claimed. Full legacy-suite, all sanitizers, cross-platform and production qualification are not claimed.
