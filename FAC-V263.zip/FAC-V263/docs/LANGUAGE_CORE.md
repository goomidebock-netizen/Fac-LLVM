# FAC Language Core — Control Flow, Pattern Matching and Native Payload Enums

> ภาพรวม paradigms ของ FAC ทั้ง Procedural, OOP, Generic, Functional, Metaprogramming, Template และ Low-level รวมถึงสถานะที่รองรับจริงใน V220 อยู่ใน [`LANGUAGE_PARADIGMS.md`](LANGUAGE_PARADIGMS.md)

## V127: expressive control flow

### `until`

`until(condition) { ... }` is a pre-test loop: it runs while `condition` is false and skips the body when the condition is already true. `do { ... } until(condition)` is the post-test form and always executes the body at least once. Existing `while` and `do ... while` semantics are unchanged.

### `select`

```fac
select {
    case (isReady()) { start() }
    case (hasFallback()) { recover() }
    default { wait() }
}
```

`select` checks boolean conditions from top to bottom and executes only the first matching branch. Later conditions are not evaluated after a match. It has no fallthrough and is intentionally different from `switch`, which compares one selector against case values. `select` is also different from `match`, which applies patterns, range checks, enum-payload destructuring, guards and exhaustiveness rules.

### `guard`

```fac
function int requirePositive(int value) {
    guard (value > 0) else { return -1 }
    return value
}
```

The condition is evaluated once. On success, execution continues after the guard. On failure, the `else` block must leave the current path on every route with `return`, `throw`, or a valid surrounding-loop `break`/`continue`. A block that can fall through is rejected. This is a control-flow guarantee, not a runtime assertion that can silently continue.

### `defer`

`defer statement` registers a statement for the current lexical scope. Deferred statements run in last-in-first-out order on normal scope exit and compiler-controlled `return`, `break` and `continue` exits. For example, two registrations `defer A()` then `defer B()` run as `B()` then `A()`. Current FAC `throw` uses non-local error transfer; `defer` is not yet a general exception-unwind hook across skipped call frames, so do not rely on it as the sole cleanup mechanism for resources that must be released through arbitrary thrown exceptions. Use managed ownership/`try`-`finally` for those paths.

### Counted-loop index paths

The legacy counted-loop forms remain: `for++(n)` counts upward; `for--(n)`, `++for(n)` and `--for(n)` count downward. `i` is a special loop-index expression, not a declared local variable. A selector path is written from the innermost matching counted loop outward:

```fac
for++(3) {
    for++(2) {
        terminal.out.println(for++.for++.i, ":", for++.i)
    }
}

for++(2) {
    for--(2) {
        terminal.out.println(for--.for++.i, ":", for--.i)
    }
}
```

Each segment selects the next enclosing counted loop of that direction; non-counted loops and counted loops with a different direction are skipped. Thus `for--.for++.i` means: start at the innermost descending counted loop, then select the enclosing ascending counted loop. Prefix aliases are supported in selector paths too. This avoids relying on shadow-prone names such as `i` and `j`; use ordinary `for(int i = ...)` / `for(int j = ...)` when named loop variables are preferred.

### `ifv` and `match` versus `if`, `switch` and `select`

| Construct | Main purpose | Result | Selection model |
|---|---|---|---|
| `if` | General control flow | No value | Boolean branch |
| `switch` | Value dispatch | No value | Equality against selector values |
| `select` | Ordered predicate dispatch | No value | First true condition |
| `ifv` | Conditional expression | Required value | First true condition; branch result types must join |
| `match` | Pattern matching | Statement or value | Literal/range/enum payload/wildcard patterns, guards and coverage checks |

`ifv` branches must return the same type or numeric types with a safe common type. For example `int`, `double`, `int` branches join to `double`. Only the selected branch expression executes; conditions are tested in order. `match` remains stricter: match-expression branch types must match exactly, while the selector receives pattern-specific validation. `case(_)` is a wildcard; an unguarded wildcard is exhaustive and any later case is rejected as unreachable. A guarded wildcard does not count as exhaustive because its guard may be false.

`match` is a core control-flow construct with statement and expression forms. It is separate from class/object features and can be used with numeric, boolean, character, string, unit-enum and native payload-enum values.

## Syntax

```fac
match (value) {
    case (0..9) {
        terminal.out.println("single digit")
    }
    case (10..99, 100) {
        terminal.out.println("two digits or 100")
    }
    case ("FAC") {
        terminal.out.println("language")
    }
    default {
        terminal.out.println("other")
    }
}
```

- `case(...)` accepts one or more comma-separated patterns.
- `low..high` is an inclusive range. Both endpoints must be compile-time integer constants, and `low <= high`. Ranges are supported only for integer, `char`, and `unichar` selectors.
- Exact patterns must be literals, enum members, or compile-time integer constants (float and string literals are supported directly). Strings compare by content.
- The selector is evaluated once. A pattern is checked in source order.
- `default` is optional for scalar/string selectors; if no pattern matches and there is no default, execution continues after the `match`.
- Enum and boolean selectors have finite domains: without `default`, every enum variant or both `true` and `false` must be covered. This rule applies to statement and expression matches.
- Integer patterns/ranges and string literal patterns cannot be duplicated or overlap after an earlier unguarded branch. Multiple alternatives with guards are allowed; an unguarded branch after a guarded alternative may serve as its fallback.
- `break` exits the current `match`; `continue` targets the nearest enclosing loop.
- Statement cases may add `if (guard)` after the pattern. The guard is evaluated only after the pattern matches; a false guard continues to the next case.

## Example

```fac
import terminal.fac

enum Mode { Fast, Safe, Debug }

function dyn string label(int score) {
    dyn string result = "N/A"
    match (score) {
        case (0..49) { result = "F" }
        case (50..79) { result = "C" }
        case (80..100) { result = "A" }
        default { result = "?" }
    }
    return result
}

public function void main() {
    enum Mode mode = Mode.Safe
    match (mode) {
        case (Mode.Fast) { terminal.out.println("fast") }
        case (Mode.Safe) { terminal.out.println("safe") }
        case (Mode.Debug) { terminal.out.println("debug") }
    }
    terminal.out.println(label(87))
}
```

## Native Payload Enum และ Pattern Destructuring

Enum สามารถมี variant ที่เก็บ payload แบบระบุชนิดได้ โดยไม่ต้องสร้าง class หรือ object:

```fac
import terminal.fac

enum Token {
    End,
    Number(int),
    Pair(int, int),
    Ratio(double)
}

function int readToken(enum Token token) {
    match (token) {
        case (Token.End) { return -1 }
        case (Token.Number(value)) { return value }
        case (Token.Pair(x, y)) { return x + y }
        case (Token.Ratio(value)) { return cast(Int, value) }
    }
    return -9
}

public function void main() {
    enum Token token = Token.Pair(20, 22)
    terminal.out.println(readToken(token))
}
```

- สร้าง variant ด้วย `Token.Number(42)` หรือใช้ variant เปล่า `Token.End`.
- Destructure payload ใน pattern เช่น `case(Token.Pair(x, y))`; ใช้ `_` เพื่อทิ้ง payload ที่ไม่ต้องการ.
- รองรับ variant หลายชนิดใน enum เดียว, payload หลายช่อง, `float`/`double`, integer, boolean, char/unichar, unit enum และ raw `ptr`.
- Native representation เป็น tag `i32` และ payload slots แบบ `i64`; scalar ถูก encode/decode ตามชนิดตอนสร้างและ match.
- Payload enum ส่งผ่าน/คืนค่าฟังก์ชันและ assign ได้; imported enum ใช้ qualified path เช่น `N.Token.Number(x)` และเคารพ `public/private` กับ `just/without`.
- `match` ตรวจชื่อ enum, variant, จำนวน binding และชื่อ binding ซ้ำระหว่าง compile.
- Statement match ที่ใช้ enum/boolean ต้อง exhaustive เมื่อไม่มี `default`; scalar/string statement match ยังคงอนุญาตให้ไม่มี `default` เพื่อคงพฤติกรรม fall-through.
- `switch` ไม่รองรับ payload enum; ใช้ `match` แทน.

## Match Expression, Exhaustive Match และ Guard

`match` ใช้เป็น expression เพื่อคืนค่าได้ โดยทุก branch ต้องคืนชนิดข้อมูลเดียวกัน:

```fac
var int score = match (token) {
    case (Token.End) => 0,
    case (Token.Number(n)) => n,
    case (Token.Pair(a, b)) => a + b
}
```

- ใช้ `=> expression` สำหรับ branch ที่คืนค่า และ `default => expression` เป็น fallback.
- Match expression ต้อง exhaustive: payload/unit enum ต้องครอบคลุมทุก variant ที่ไม่มี guard; boolean ต้องครอบคลุม `true` และ `false`; selector ชนิดอื่นต้องมี `default`.
- `case (pattern) if (condition) => expression` เป็น guarded branch; guard จะทำงานหลัง pattern match. Guarded case ไม่นับเป็นการครอบคลุม variant จนกว่าจะมี unguarded case หรือ default.
- ค่าที่คืนจากทุก branch ต้องมีชนิดตรงกันแบบ exact type; การแปลงตัวเลขต้องเขียน `cast(...)` อย่างชัดเจน.
- Guard ใช้ได้ทั้ง statement match (`case (...) if (condition) { ... }`) และ match expression.
- Variant/literal เดียวกันสามารถมีหลาย guarded branches ได้เพื่อรองรับ fallback ตามเงื่อนไข; branch ที่ซ้ำหลัง unguarded branch จะถูกปฏิเสธเป็น unreachable.

Native payload enum รองรับ ownership-aware payload แล้ว: scalar (integer/float/boolean/char/unichar), unit enum, raw pointer, string/dyn string, list, struct, function/closure, object/weak handle และ nested payload enum. Compiler สร้าง copy/drop/trace callbacks ตามชนิด payload; การ copy enum จะ retain หรือ deep-copy ตาม semantics ของชนิด field และการปล่อย enum จะ release payload ที่ active ตาม tag เท่านั้น. Payload enum ใช้เป็น element ของ `list` ได้ รวมถึง `list Option<string>`; fixed-size `array` ของ generic/payload enum ยังไม่รองรับ. Payload แบบ raw pointer ยังคงเป็น non-owning pointer และไม่ถูก retain/free โดยอัตโนมัติ. สำหรับ cycle collector การอ้างอิงที่ซ่อนอยู่ใน list/closure ยังถือเป็น conservative external roots; cycle ผ่าน container เหล่านี้จึงอาจยังคงถูกเก็บไว้แทนที่จะถูก reclaim.

---

# Native Generic Option, Result และ Error Propagation

`stdlib/result.fac` ประกาศ `Option<T>` และ `Result<T, E>` เป็น **native generic payload enums** ของ Language Core ไม่ใช่ tagged struct และไม่พึ่ง `class` หรือ `obj`:

```fac
enum Option<T> {
    None,
    Some(T)
}

enum Result<T, E> {
    Ok(T),
    Err(E)
}
```

ใช้ `enum` ใน type position และระบุ generic arguments ชัดเจนตอนสร้าง Variant:

```fac
import result.fac just Option, Result
import terminal.fac

enum ParseError { Invalid, Missing }

function enum Option<int> findScore(boolean found) {
    if (found) { return Option<int>.Some(95) }
    return Option<int>.None
}

function enum Result<int, ParseError> parseScore(boolean valid) {
    if (!valid) { return Result<int, ParseError>.Err(ParseError.Invalid) }
    return Result<int, ParseError>.Ok(95)
}

public function void main() {
    enum Option<int> score = findScore(true)
    terminal.out.println(match(score) {
        case (Option.Some(value)) => value,
        case (Option.None) => 0
    })

    enum Result<int, ParseError> parsed = parseScore(false)
    terminal.out.println(match(parsed) {
        case (Result.Ok(value)) => value,
        case (Result.Err(error)) => 100 + error.toInt()
    })
}
```

- Variants คือ `Option.None`, `Option.Some(T)`, `Result.Ok(T)` และ `Result.Err(E)`; constructor ใช้รูป `Option<int>.Some(7)` / `Option<int>.None` และ `Result<int, ParseError>.Err(ParseError.Invalid)`.
- ใช้ `match` เพื่ออ่านค่าและ destructure payload; Enum/Boolean match ที่ไม่มี `default` ต้อง exhaustive. `.unwrap()`, `.isNone()` และ field อย่าง `.value` จาก generic struct รุ่นเก่าไม่ได้เป็น API ของ native enums.
- Generic enum สร้าง specialization ตาม type arguments; รองรับ imported generic enum, module alias และ `just/without` filters. Constructor แบบ alias ใช้ได้ เช่น `R.Option<int>.Some(7)`.
- Runtime payload รองรับ scalar, unit enum, raw pointer และ managed payload เช่น `string`, `list`, `struct`, `object`, `weak`, function/closure และ nested payload enum. Managed payload ใช้ generated ownership callbacks; raw pointer ยังคงไม่ถูกจัดการอายุโดยอัตโนมัติ.

## Postfix `?` (early propagation)

```fac
function enum Result<long, ParseError> doubledScore(boolean valid) {
    var int score = parseScore(valid)?
    return Result<long, ParseError>.Ok(cast(Long, score) * 2)
}

function enum Option<int> nextScore(boolean found) {
    var int score = findScore(found)?
    return Option<int>.Some(score + 1)
}
```

- Operand ต้องเป็น specialization ของ `result.Option<T>` หรือ `result.Result<T, E>` จาก `result.fac` และถูกประเมินเพียงครั้งเดียว.
- `Some/Ok` จะคืน payload เพื่อใช้ใน expression; `None/Err` จะ return failure variant จาก function ปัจจุบันทันที.
- `Option<T>?` ต้องอยู่ใน function ที่ return `Option<U>`; `Result<T,E>?` ต้องอยู่ใน function ที่ return `Result<U,E>` โดยชนิด `E` ต้องตรงกันแบบ exact type. ชนิด success payload ของ source และ destination เปลี่ยนได้ตามการแปลงค่าที่เขียนอย่างชัดเจน.
- `?` ใช้ได้เฉพาะ function ที่ประกาศ return type เป็น native Option/Result specialization ชัดเจน; ไม่รองรับ `void`, inferred `auto` return หรือ automatic error conversion.
- `?` ไม่ได้จับ exception; `throw`/`try`/`catch` ยังคงแยกจากกัน และ `finally` จะทำงานก่อน early return.

## ขอบเขตปัจจุบัน

Generic payload enum รองรับ scalar, unit-enum, raw pointer และ managed payload (string/list/struct/object/weak/function/closure) รวมถึง nested payload enum. Payload enum ใช้เป็น element ของ `list` ได้ แต่ fixed-size `array` ยังไม่รองรับ payload enum. Generic payload-enum argument inference ยังไม่รองรับ. `Option`/`Result` ยังไม่มี `map`/`andThen`/`orElse` helper APIs; ใช้ `match` และ `?` เป็นกลไกหลัก. `?` ไม่แปลงชนิด error อัตโนมัติและไม่จับ exception.


## V46 additions and current scope

V45 adds the additive parameter form `ref const T name`, which represents a shared immutable borrow. `ref T name` remains a mutable/exclusive borrow. With `--strict-ownership`, direct writes through a `ref const` parameter and direct call alias conflicts involving a mutable borrow are rejected. The checker is intentionally conservative and is not a complete borrow or lifetime checker.

The broader planned design, implementation matrix and syntax policy are in [`LANGUAGE_CORE_ROADMAP.md`](LANGUAGE_CORE_ROADMAP.md), [`MEMORY_MODEL.md`](MEMORY_MODEL.md), [`CONCURRENCY.md`](CONCURRENCY.md) and [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md).


## V46 generic constraint update

V46 supports multiple bounds per generic parameter using `&` (all bounds are required) and method-level constraints on explicitly specialized generic methods. Generic methods in interfaces or virtual/override dispatch remain unsupported.


## V220 const generic parameters and constant-expression arguments

Generic `struct`/`class` declarations, generic free functions and generic methods may declare `const int` parameters alongside type parameters. Const values are explicit generic arguments and use the same ordered parameter list as type arguments:

```fac
public struct FixedBuffer<T, const int N> {
    public array var T values[N]
    public array var T doubled[N * 2]
}

public function<const int N> int capacity() {
    return N
}

public function<T, const int N> T keepSized(T value) {
    return value
}

public function void main() {
    struct FixedBuffer<int, (2 * 8)> samples
    var int count = capacity<(3 * 4)>()
    var int value = keepSized<int, (PAGE_SIZE / 2)>(42)
}
```

At a call site, const values may be integer constant expressions supported by the bounded constant evaluator. Parentheses disambiguate value expressions from type names. Supported operations and eligible module-level `const` values follow [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md); expressions may also call explicitly marked scalar free functions supported by the bounded V220 `consteval` interpreter (see [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md)). Compile-time arguments are evaluated as signed 64-bit integers with overflow and undefined operations rejected; ordinary runtime functions are not executed during compilation.

Generic methods and generic struct/class instantiations with const parameters do not infer omitted arguments; trailing generic defaults may supply those parameters. Generic free functions are an exception: when a `const int N` appears directly as a fixed-array extent in a parameter type (`array var T values[N]`), a call with no explicit generic argument list may infer `N` from a fixed-size array argument. Ordinary type parameters such as `T` may be inferred from that argument at the same time, and supported inference takes precedence over defaults. If the same `N` is exposed by multiple array parameters, the extents must agree. Calls may use explicit positional or named arguments, including partial lists when omitted parameters have defaults, for example `keepSized<int>(42)` or `keepSized<N = (2 * 8), T = int>(42)`. Named arguments are mapped to declaration order before specialization and cache lookup, so spelling order does not create a distinct specialization. Inferred, explicit or defaulted const values are part of the specialization key, so different values produce distinct specializations and repeated equal values share the cache. See [`GENERIC_DEFAULT_ARGUMENTS_V220.md`](GENERIC_DEFAULT_ARGUMENTS_V220.md) for default and resolution rules.

A const parameter may be substituted through function/method bodies and dependent type arguments, including fixed-array dimensions and local array dimensions. Any resulting array dimension must be positive; the existing array/record layout checks continue to reject zero/negative dimensions, overflow and oversized layouts. The generic specialization depth and 5,000-distinct-specialization budgets still apply.

Const parameters support built-in value predicates: `positive` (`N > 0`), `nonnegative` (`N >= 0`), `nonzero` (`N != 0`), `negative` (`N < 0`), `even`, `odd` and `power_of_two`. Multiple predicates may be combined with `&` and all must pass, for example `const int N: positive & power_of_two`. These are value constraints only; type/interface bounds on const parameters and inference from runtime values or algebraic array extents are not implemented. V220 additionally supports a bounded `consteval` interpreter for explicitly marked scalar free functions and typed constant queries `typeOf<T>()`, `sizeof<T>()` and `alignof<T>()`. Structural field queries `fieldCount<T>()`, `fieldName<T,I>()`, `fieldType<T,I>()` and `fieldOffset<T,I>()` enumerate public non-static instance fields of resolved struct/class records (including inherited public class fields); private/protected and static fields are omitted. Numeric field queries can participate in `static_assert`, supported `consteval` bodies and const generic expressions. This is bounded field metadata reflection, not generic/full reflection or a source-level AST/declaration builder. V220 also provides internal C++ APIs: `fac_hir::TypedAstFactory` for immutable, validated generated expression nodes; `fac_hir::TypedDeclarationBuilder` for non-generic generated struct/free-function declarations; and `fac_hir::TypedFunctionBodyBuilder` for scalar bodies with mutable locals, exact-TypeId assignments and nested `if/else` on generated free functions. The Codegen bridge projects eligible generated structs, body-less external C-ABI function prototypes and generated functions with supported bodies into the existing LLVM backend using temporary Programs; source `Program` AST ownership is unchanged. These builders consume pre-resolved TypeIds and do not expose builder calls to FAC/`consteval`, resolve imported types from bare TypeIds, or perform a full post-generation HIR re-analysis. Generated bodies currently have scalar value parameters/locals, typed literals, unary/binary expressions, exact same-module non-generic calls, mutable-local assignments, nested bool-conditioned `if/else` and one terminal return; loops, branch-local declarations/returns, multiple return paths, aggregates, generic declarations, classes/methods and source-level declaration generation remain unsupported. Generic/method consteval, arbitrary compile-time execution and macro expansion also remain unsupported. See [`CONSTEVAL_V220.md`](CONSTEVAL_V220.md), [`TYPED_CONSTANT_VALUES_V220.md`](TYPED_CONSTANT_VALUES_V220.md), [`STRUCTURAL_REFLECTION_V220.md`](STRUCTURAL_REFLECTION_V220.md), [`TYPED_AST_BUILDER_V220.md`](TYPED_AST_BUILDER_V220.md), [`TYPED_AST_FACTORY_V220.md`](TYPED_AST_FACTORY_V220.md), [`TYPED_DECLARATION_BUILDER_V220.md`](TYPED_DECLARATION_BUILDER_V220.md), [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md) and [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md). The supported fixed-array inference rule for generic free functions is described in [`CONST_VALUE_INFERENCE_V220.md`](CONST_VALUE_INFERENCE_V220.md). Named generic arguments are supported for generic struct/class types, free functions and methods; they do not add named arguments to ordinary runtime function calls. Generic virtual/override dispatch and generic interface methods remain unsupported. See [`CONST_GENERIC_FUNCTIONS_V220.md`](CONST_GENERIC_FUNCTIONS_V220.md), [`CONST_GENERIC_CONSTRAINTS_V220.md`](CONST_GENERIC_CONSTRAINTS_V220.md), [`COMPTIME_METAPROGRAMMING.md`](COMPTIME_METAPROGRAMMING.md) and [`GENERIC_SPECIALIZATION.md`](GENERIC_SPECIALIZATION.md).

## V48 ownership-related language constraints

V50 adds trailing `const` on instance methods. With `--strict-ownership`, a `ref const` receiver may call a method only when it is declared `const`; const method bodies are checked for direct receiver writes and non-const calls on `self`. `ref` parameters with default values or variadic capture remain rejected. These constraints are opt-in guardrails, not a complete borrow/lifetime proof; ordinary compilation syntax remains unchanged.


## Java-style class entry point (V49)

The Language Core permits a class-based application entry point in addition to the existing top-level function form. Example: `public class App { public static function void main(list dyn string args) { ... } }`. The `args` parameter is an owned managed list of strings with the executable path omitted. Only one entry point is allowed per application module. See [`JAVA_STYLE_ENTRY.md`](JAVA_STYLE_ENTRY.md) for the exact type, visibility, initialization and compatibility rules.


## Const-qualified instance methods (V50)

A method may declare `const` after its parameter list: `public function int get() const`. The qualifier is a static receiver contract; it allows calls through `ref const` under `--strict-ownership` only when the selected method is const. Interface and override signatures must match. It does not alter the ABI and is not deep constness.


## V53: local scoped borrow bindings

V53 adds local `ref var T alias = owner` and `ref const var T alias = owner` bindings under `--strict-ownership` / `--secure`. The alias addresses the original storage and has no independent drop. Loans are lexical to their enclosing block; multiple shared loans may coexist, while mutable loans are exclusive. Owner access is restricted while a mutable loan is active, and shared aliases cannot mutate or call non-const methods.

The current checker is conservative: it supports tracked local/parameter/receiver roots and recognized fields/elements; rejects untracked global/static roots, local alias declarations from another alias/`ref` parameter, and pointer escape; statically known direct `ref` calls may use temporary reborrows; and treats an aggregate's fields/elements as one aliasing root. It is not yet NLL, a persistent CFG loan graph, a general lifetime checker, dangling-reference proof or static race analyzer. See [`OWNERSHIP.md`](OWNERSHIP.md) and [`MEMORY_MODEL.md`](MEMORY_MODEL.md).


## V54 local-borrow last-use shortening

V54 adds bounded last-use expiration to local `ref` / `ref const` aliases. When the checker reaches a statement after the alias's last possible use in the current block, it removes the local loan and permits owner access again. Nested control-flow constructs are treated as a single conservative statement; `defer` extends the loan to block exit. This reduces unnecessary lexical restrictions without claiming a persistent CFG loan graph or full NLL. See [`OWNERSHIP.md`](OWNERSHIP.md).


## V55 ownership core

`--strict-ownership` now builds a per-function CFG for local-borrow alias liveness and supports local parent/child reborrows. The implementation uses a backwards may-liveness fixed point and conservatively pins aliases across `defer` and `try` regions. It does not yet implement declaration-ID-exact NLL, reference return types, complete lifetime parameters, or whole-program static race detection.


## V56 borrow symbol and owner identity

V56 changes strict local-borrow analysis from name-based use sets to declaration identity. Identifier occurrences are resolved through lexical scopes; shadowing declarations (including lambda parameters, foreach variables, catch names and match bindings) no longer count as uses of an outer borrow with the same spelling. Owner storage also has a declaration identity, so distinct nested locals with the same name are separate borrow roots. Reborrow parent/child relations use the parent declaration, including same-name nested reborrows.

This does not add new FAC syntax or public APIs. It tightens the semantics of existing `ref` / `ref const` local aliases under `--strict-ownership` / `--secure`. Current local references are lexically bounded because the language does not yet expose reference return types or reference fields and the checker rejects untracked roots/unsupported escapes. General lifetime parameters, returned/stored references, raw-pointer/FFI escape proofs and whole-program static race checking remain future work. See [`OWNERSHIP.md`](OWNERSHIP.md) and [`FAC_LANGUAGE_TARGETS.md`](FAC_LANGUAGE_TARGETS.md).


## V57 ownership/lifetime model update

V57 does not introduce new syntax. In `--strict-ownership` / `--secure`, local `ref` aliases now participate in a lexical lifetime-region tree and exceptional CFG. The owner or parent-loan region must outlive the child borrow region. Explicit `throw`, protected expressions, catch handlers and finally cleanup participate in borrow liveness. See `OWNERSHIP.md` and `MEMORY_MODEL.md` for the exact bounded proof boundary.

## V59 parameter effect: `noescape`

V59 adds `noescape ptr T name` for pointer parameters. The annotation is enforced by strict ownership checking and requires `--strict-ownership` or `--secure`. It lets a caller pass a frame-derived address to a direct callee only when the callee body is checked not to return/store/capture/forward that pointer beyond the call. `extern noescape` is explicitly trusted rather than body-verified. The effect is not yet represented in function-pointer types, and it does not change the ABI. See `docs/NOESCAPE_CONTRACTS.md`.


## V60: bounded partial field move

With `--strict-move` or `--secure`, the existing `move()` operation also accepts `move(record.field)` for a direct first-level managed leaf field of a local mutable value `struct`. Supported field types are `dyn string`, list/data-structure handles, function handles, `obj` and `weak obj`. FAC `ptr T` is an unmanaged raw pointer and is not accepted as an ownership-bearing partial-move field.

The field's handle is transferred into an owned expression and its source storage is set to null. The ordinary struct drop path then releases remaining fields and safely ignores the moved-from null field. The CFG checker tracks declaration/field identity, rejects reads/repeated moves and blocks use of the whole partially moved aggregate. Reassigning every moved field restores whole-aggregate use. Branch joins are conservative and loop moves require reinitialization before the back-edge. Nested paths/aggregates, enum payloads, arrays, classes, parameters, self, borrow aliases, heap storage and scalar/raw-pointer fields are rejected. This is a bounded initial subset, not general per-field drop flags or field-sensitive borrowing.

## V61: first-level field projections and pointer effects

V61 permits disjoint local borrows of different direct first-level fields when both paths resolve to the same owner declaration. Whole-object, same-field, nested, indexed, dereferenced and computed paths remain overlapping unless a future analysis can prove otherwise. This also permits disjoint sibling mutable reborrows and access to a sibling owner field while another field is borrowed.

V61 adds `readonly ptr T p` as a compile-time promise not to write through the pointee and allows it to combine with `noescape` (`readonly noescape ptr T p`). The modifiers are independent and require `--strict-ownership` or `--secure`. Abstract/interface declarations may publish the effects; concrete overrides and implementations must not weaken them. Extern declarations are trusted FFI promises. These effects do not change ABI/runtime behavior and remain bounded direct-call checks; see [`POINTER_EFFECTS.md`](POINTER_EFFECTS.md).


## V62 nested field projections

V62 extends the V61 local-borrow projection proof to pure named-member chains rooted at a tracked local/parameter/receiver declaration. Each segment must resolve through declared aggregate field metadata. Thus `outer.inner.left` and `outer.inner.right` can be borrowed independently. Projection overlap is hierarchical: equal paths overlap, a path overlaps its descendants (`inner` vs `inner.left`), and distinct sibling paths do not. Whole-root, unknown, indexed, dereferenced and computed paths remain conservative. This change does not extend Partial Move or alter Runtime/ABI.


## V63 nested partial move

Under `--strict-move` / `--secure`, `move()` accepts metadata-validated named field paths rooted at a directly owned local mutable value struct. Intermediate path elements must themselves be value structs; the final path may be a managed handle or managed value struct. The CFG checker tracks each root declaration and dotted projection. Equal and prefix/descendant paths overlap, while proven sibling paths are independent. Reinitializing the moved projection or replacing a containing subaggregate restores the corresponding moved-state facts.

Code generation stores null into a moved managed-handle field and `zeroinitializer` into a moved managed value-struct field. Existing recursive drop helpers and the temporary cleanup stack handle normal exit and exception unwind. This remains bounded to named local paths: arrays/indexes, enum payloads, class traversal, scalar/raw-pointer fields, and heap/indirect roots are rejected. It does not add a general runtime drop-flag bitmap or alter the Runtime ABI. See `MOVE_SEMANTICS.md`, `OWNERSHIP.md`, and `MEMORY_MODEL.md`.


## V164: managed payload-enum partial moves

`move(local.valueStructPath.payloadEnumField)` is supported when the final field is a managed payload enum and all intermediate path elements are value structs. The enum value is transferred out and the source field is zero-initialized so recursive drop only processes the remaining active fields. The existing `--strict-move` / `--secure` projection analysis rejects later reads and repeated/overlapping moves, and accepts reinitialization of the moved field. This remains a bounded partial-move feature; it does not add array/index moves, unit-enum moves, reference return types, general lifetime parameters or a complete drop-flag bitmap. See [`MOVE_SEMANTICS.md`](MOVE_SEMANTICS.md) and [`OWNERSHIP.md`](OWNERSHIP.md).


## V183: fixed-array constant-index borrow projections

The strict local-borrow checker now resolves non-negative integer-literal indexes for fixed-size arrays when the full storage path is rooted at a tracked named local. Different literal indexes are disjoint, equal indexes overlap, and whole-array projections still overlap each element. Variable or computed indexes, lists, matrices, pointer-derived storage and unknown projections remain conservative. This does not add indexed Partial Move, dynamic alias analysis, reference return/store types or general lifetime parameters. See `OWNERSHIP.md`, `MEMORY_MODEL.md` and the `good_array_disjoint_indices` / `bad_array_*_index` regressions.


## V185: local const identifier array-index projections

The strict local-borrow checker can resolve a visible initialized local `const int` / `const long` identifier to an exact fixed-array index when the initializer is a supported checked integer constant expression. Chained constants are allowed, and the binding is tied to the exact declaration identity so shadowing is safe. Mutable variables, parameters and unknown/side-effecting expressions remain conservative. See `LANGUAGE_CORE_V185.md` for the exact boundary and regression cases.


## V187: unsigned local const identifier array-index projections

The strict local-borrow checker can resolve visible initialized local `const ubyte`, `const ushort`, `const uint` and `const ulong` identifiers to exact fixed-array indexes, alongside the signed `byte`/`short`/`int`/`long` subset. Values must be proven, non-negative and within the declared unsigned width; declaration identity and chained constants are preserved. Equal resolved values still overlap. The projection evaluator stores indexes as `int64_t`, so unsigned `ulong` values above `INT64_MAX`, unsigned negation, negative/out-of-width values and unknown or side-effecting expressions remain conservative. See `LANGUAGE_CORE_V187.md`.


## V186: narrow signed const identifier array-index projections

The strict local-borrow checker can resolve visible initialized local `const byte` and `const short` identifiers to exact fixed-array indexes, alongside the existing `const int` and `const long` support. Values must fit the declared signed width (8, 16, 32 or 64 bits) and are tied to the exact declaration identity. Different resolved indexes are disjoint; equivalent values still overlap. Unsigned integer types, mutable locals, parameters and unknown/side-effecting expressions remain conservative. See `LANGUAGE_CORE_V186.md`.


## V188: bitwise and shift constant array-index projections

The strict local-borrow fixed-array projection evaluator recognizes pure integer bitwise AND/OR/XOR (`&`, `|`, `^`), shifts (`<<`, `>>`) and unary complement (`~`). It follows FAC integer promotions and common integer width/signedness, including narrow integer promotion, shift-count masking, arithmetic signed right shift and logical unsigned right shift. Exact equal results still conflict; distinct exact indexes remain disjoint. This is not general constant evaluation, dynamic alias analysis or complete borrow/lifetime checking. See `LANGUAGE_CORE_V188.md`.


## V189: constant `ifv` array-index projections

Strict local-borrow analysis can now resolve a fixed-array index selected by `ifv / eiv / elv` when all tested conditions are provably constant and every result arm is a supported pure integer constant with identical width and signedness. Constant predicates include boolean literals, integer truth values, logical short-circuit operations and integer comparisons. Unknown conditions or arms retain conservative may-alias behavior. See `LANGUAGE_CORE_V189.md`; this is not general compile-time evaluation or a complete borrow/lifetime proof.


## V190: local const-boolean conditional borrow projections

The bounded strict local-borrow fixed-array evaluator can use an initialized local scalar `const boolean` binding as an `ifv / eiv / elv` predicate when the initializer is proven by the supported constant-condition evaluator. Boolean constants may chain from earlier visible const booleans and const integers; values are associated with the exact declaration node so lexical shadowing and initializer-before-shadow behavior remain correct. Mutable, unknown, uninitialized, global/static, parameter, side-effecting and unsupported values remain conservative. Conditional result arms still require matching integer width/signedness and the existing visit budget applies. This does not add general const evaluation, lifetime solving or a complete borrow checker. See `LANGUAGE_CORE_V190.md`.




## V191: explicit casts in constant array-borrow projections

The bounded strict local-borrow fixed-array projection evaluator can resolve supported pure `cast(Type, value)` expressions for primitive integer, boolean, `char` and `unichar` types. It models FAC's truncation, signed/unsigned extension and Boolean zero/nonzero conversion rules, including nested casts and conditional predicates derived from a cast. Float, pointer, class/enum, side-effecting and unresolved forms remain conservative. This is not general constant evaluation or complete lifetime/borrow checking. See `LANGUAGE_CORE_V191.md`.


The bounded strict local-borrow fixed-array projection evaluator can also resolve initialized local `const char` and `const unichar` identifiers whose initializers are supported pure integer-like constants. `char` is represented as an 8-bit unsigned scalar and `unichar` as a 32-bit unsigned scalar; bindings are keyed by declaration identity to preserve shadowing. Mutable or unsupported values remain conservative. See `LANGUAGE_CORE_V192.md`.
