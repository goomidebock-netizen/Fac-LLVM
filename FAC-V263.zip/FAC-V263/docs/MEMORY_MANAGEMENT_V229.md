# FAC Memory Management Direction — V229

V229 adds a bounded may-origin fixed-point analysis for local pointer variables and pointer-bearing fields in local value structs across loop back-edges. Earlier releases invalidated every changed visible pointer fact after a loop because a single body visit could miss sources introduced on later iterations. The new analysis repeatedly transfers the loop body and joins the loop-entry state with the back-edge state until the visible pointer facts stop changing.

## 1. Loop-carried abstract state

The loop header tracks two existing provenance domains:

- pointer-local origins keyed by the visible local binding; and
- aggregate pointer origins keyed by the local value-struct root and exact field path.

At each join, a field/path remains verified only when every possible predecessor has a fact for that exact path. All possible `PointerOrigin` values are unioned. A missing fact remains Unknown; an explicit known-null field remains a present fact with an empty origin set. A later store or return must satisfy the lifetime of every possible non-null origin.

The fixed-point transfer uses the lexical entry state plus the loop back-edge. This is a may-origin analysis: it may retain an origin from an iteration that is only one of several possible paths, but it must not omit a possible source. The loop is considered converged only when every visible value-struct field fact and pointer-local fact is unchanged.

## 2. Supported loop forms and execution order

The pass applies to `while`, `do-while` / `until`, C-style `for`, foreach, and the compact `ForPP` form. A `for` initializer and foreach iterable are analyzed once. A C-style `for` is transferred in source execution order: condition, body, then step. A `do-while` transfers body before condition, so its normal exit state includes the body execution. Loop-local declarations and for-init bindings are not propagated outside their lexical lifetime; only bindings already visible before the loop are projected back to the enclosing context.

Lexical blocks and supported branch joins inside the body use the existing V228 provenance propagation. Therefore writes to an outer aggregate field or pointer local inside nested blocks/branches can contribute to the loop back-edge.

## 3. Region identity and convergence

Re-analysis of the same syntax node reuses its lexical lifetime region, keyed by parent region and AST node identity. This prevents each fixed-point pass from creating fresh region IDs that would make equivalent origins appear different. Lifetime constraints are deduplicated across passes.

The solver is bounded to 32 transfer passes. If visible facts do not converge within that bound, changed facts are invalidated rather than treated as proven. This keeps the analysis fail-closed under unexpected state growth.

## 4. Explicit control-flow limits

A loop containing an explicit `break` is still handled conservatively using the previous one-pass invalidation behavior because break exits are not yet represented as distinct provenance predecessor states. This includes nested break statements and can reject safe cases. `continue` is not yet modeled as a separate provenance edge. The analysis is intraprocedural and does not create a general heap borrow graph, does not prove arbitrary raw-pointer/FFI behavior, and does not establish whole-program escape or data-race freedom.

The pass does not change ARC, Cycle Collector, Runtime allocation, public API, C ABI, Runtime ABI, or `--memory-safe` acceptance. It refines strict-ownership lifetime provenance for local pointer variables and local value structs.

## 5. Regression coverage

V229 tests cover:

- a `while` loop that may write a second pointer source with the same named lifetime (accepted and executed);
- a `while` loop that may write an incomparable lifetime source (rejected);
- a pointer local reassigned inside a loop with an incomparable source (rejected);
- a `do-while` loop that executes the body before its condition (same-lifetime source accepted; shorter source rejected);
- a `for` loop whose back-edge source is valid under an explicit `where` outlives relationship (accepted);
- a `for` loop with an incomparable possible source (rejected);
- a `for++` compact loop with same-lifetime sources (accepted and executed);
- a post-loop overwrite that kills the loop-carried aggregate field origin (accepted); and
- the prior explicit-break case, which remains fail-closed.

## 6. Validation

The V229 lifetime regression script passed 83 checks on the Linux host, including the nine new loop cases. Compiler and Runtime were built with Clang 17 C++17 (`-O0` Compiler, `-O2` Runtime). Other test suites, API checks, Sanitizer runs and cross-platform validation are recorded in `docs/STATUS.md`; no Production Safety certification is implied.
