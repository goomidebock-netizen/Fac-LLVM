# FAC Memory Management Direction — V221

This document records the memory-management policy and the limits of the current implementation. It is a design direction, not a claim that every planned analysis is complete.

## 1. Primary policy: Ownership first

FAC should prefer compile-time ownership and borrowing wherever the source-level relationship can be checked statically:

- ordinary value data uses normal value semantics and explicit `move` where ownership is transferred;
- short-lived aliases use `ref` / `ref const` and must pass strict ownership, loan-liveness, reborrow and lifetime checks;
- the compiler rejects borrow paths it cannot model instead of guessing that they are safe;
- raw pointers, manual heap operations and FFI remain explicit escape hatches and are excluded from `--memory-safe`.

The design target is that most everyday code does not need runtime reference counting for ordinary local/value data. This is a qualitative goal, not a measured claim that a fixed percentage of allocations or instructions use one mechanism.

## 2. Runtime mechanisms are specialised fallbacks

### ARC

ARC remains appropriate for shared class-object handles and other managed values whose public semantics intentionally allow multiple owners. Strong references keep an object alive; weak handles observe/upgrade without extending the object's lifetime. ARC is not a substitute for compile-time exclusivity: a positive reference count does not prove that concurrent mutation is safe.

### Cycle collection

The existing Runtime cycle collector is a recovery mechanism for unreachable cycles in its managed object graph. It is not a general tracing collector for every FAC value, stack local, raw pointer or arbitrary native allocation. The collector must not reclaim objects that remain reachable from a valid strong root.

### No overlapping ownership authorities

A value should have one clear management model. Borrowed aliases must not silently become strong owners. Weak references must not keep an object alive. A value already governed by ordinary value ownership should not be routed through ARC/GC merely to simplify code generation. When a managed object is intentionally shared, ARC owns the shared-lifetime bookkeeping and the cycle collector handles only eligible unreachable cycles.

## 3. V221 implementation change

`--memory-safe` now permits checked `ref` parameters and function-local `ref` / `ref const` bindings. This is intentionally narrower than a general-purpose borrow system:

- the profile enables strict ownership and strict move checks before code generation;
- borrow declarations are accepted only inside function scopes, where the ownership/loan checker can inspect them;
- module globals and aggregate fields cannot store borrow bindings;
- the checker remains fail-closed for unknown roots, unmodelled escapes, ambiguous aliases and unsupported projections;
- raw/opaque pointers, manual `heap`, pointer primitives, FFI/extern/export, unsafe code, native link inputs and native-handle built-in modules remain outside the profile;
- source standard-library modules are checked rather than silently trusted, and overflow/bounds/division checks remain enabled.

This lets safe-profile programs use the implemented Ownership/Move and local-borrow analysis instead of rejecting every borrow. It does not turn the current checker into a full Rust-equivalent region solver.

## 4. Current proof boundary

The source contains CFG-based local-loan liveness, NLL pruning, ancestor/descendant reborrow tracking, metadata-validated field projections, named lifetime contracts for selected direct/indirect calls, and bounded contracts for aggregate callback fields. These are useful static guarantees within their documented domains.

The current implementation does **not** establish all of the following:

- general reference-valued aggregate fields or references stored in arbitrary containers;
- arbitrary heap-stored reference graphs and unrestricted pointer alias analysis;
- whole-program proof for raw pointers, FFI or foreign `noescape` promises;
- full data-race freedom, Send/Sync equivalence, deadlock freedom or atomic happens-before proof;
- correctness of the compiler, LLVM backend, C++ Runtime or every generated cleanup path.

When an analysis cannot establish a safe relationship, the intended behavior is rejection in the strict profile, not implicit runtime fallback.

## 5. Next development order

1. Complete the loan graph for heap/aggregate reference paths without weakening current fail-closed behavior.
2. Expand lifetime/escape summaries for returned references and verified callback/closure contracts.
3. Make ARC/GC boundaries explicit in HIR and generated cleanup, then test weak upgrades, final release and cycle collection under stress/sanitizers.
4. Add a separate concurrency ownership model for shared mutable state; do not infer race freedom from ARC alone.
5. Keep performance claims tied to reproducible benchmarks against the same programs, compiler flags and hardware.

## 6. Release numbering

`VERSION.toml` is the single release-version source of truth. All component values and `include/fac/version.h` macros must match its `[release].label`. Run `make bump-version` for the next delivery; it advances exactly one (`Vn` to `Vn+1`), synchronizes version-bearing release files, regenerates the API manifest/docs and runs the version consistency check. Historical milestone files and references remain unchanged.
