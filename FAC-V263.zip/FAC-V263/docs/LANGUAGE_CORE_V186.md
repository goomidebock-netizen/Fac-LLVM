# FAC Language Core — V186

## Scope

V186 extends the V185 local-constant array-index subset from signed `int`/`long` declarations to signed `byte`/`short` declarations. This improves precision for fixed-array local borrows when code uses narrow integer constants without requiring an explicit cast to `int`.

## Implemented

- Visible initialized local `const byte` declarations can be used as exact fixed-array indexes when the initializer is proven by the bounded checked integer evaluator and fits the signed 8-bit range.
- Visible initialized local `const short` declarations can be used as exact fixed-array indexes when the initializer is proven and fits the signed 16-bit range.
- Existing `const int` and `const long` behavior is retained with 32-bit and 64-bit signed range checks.
- Chained constants, declaration-identity tracking, nested shadowing and pre-shadowing initializer evaluation continue to apply.
- Constant values that do not fit their declared type are not recorded by this borrow evaluator.
- Distinct resolved constant indexes remain disjoint; values that resolve to the same index remain overlapping.

## Conservative boundary

Unsigned integer declarations (`ubyte`, `ushort`, `uint`, `ulong`) are not folded. Mutable variables, parameters, globals/statics, uninitialized const declarations, non-integer const values, calls, assignments, increments and unsupported expressions remain unknown/conservative. The evaluator is not general constant propagation, does not evaluate arbitrary FAC compile-time expressions and does not implement dynamic range analysis.

This release does not add indexed partial moves, reference return/store types, general lifetime parameters, general region/outlives inference, a complete borrow checker or a Rust-equivalent memory-safety proof. It does not change array layout, code generation, public API signatures or Runtime ABI.

## Regression coverage

- `good_array_const_narrow_integer_indices.fac`: chained `const byte` / `const short` indexes prove distinct array elements; runtime outputs verify references still alias original storage.
- `bad_array_const_narrow_integer_same_index.fac`: a `const byte` and `const short` resolving to the same array index are rejected as conflicting mutable borrows.
- The existing V182–V185 local-borrow positive and negative cases remain in the regression runner.

Validation results for this archive are recorded in `docs/STATUS.md`.
