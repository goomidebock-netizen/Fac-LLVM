# V180 Runtime allocation-tracking benchmark

`benchmarks/allocator_small.cpp` measures repeated small `fac_alloc` / `fac_realloc` / `fac_free` operations with FAC allocation diagnostics either disabled (`plain`) or enabled (`tracked`). The pointer vector is reserved outside the timed region. Each sample allocates 160,000 small blocks, reallocates every other block, frees all blocks in reverse order and verifies tracked live bytes/blocks return to zero. It performs one warm-up and nine timed samples, then reports the median. Reproduce with `make bench-allocator`, or build directly:

```sh
make runtime-only
make bench-allocator
```

The V179/V180 paired measurement used GCC 14.2, identical Runtime `-O2` plus hardening flags, benchmark `-O3 -DNDEBUG`, CPU 0 affinity, five alternating process pairs and the median of each process's nine timed samples. The median of the five process medians for tracked mode was **157.55 ns/operation on V179** and **76.53 ns/operation on V180** (51.4% lower latency, about 2.06x throughput). The untracked medians were 39.01 and 36.58 ns/operation respectively, but their run-to-run ranges overlapped; no improvement is claimed for the normal untracked path. This synthetic benchmark isolates opt-in memory diagnostics and does not predict whole-program performance. Re-run on the target machine with identical host, compiler, flags, affinity and sample count.

# FAC V163 — parser keyword/type lookup validation

`benchmarks/compiler_keywords.cpp` exercises `Parser::isReserved()` and `Parser::isTypeWord()` over a fixed 25-word mix of primitive types, reserved words, and ordinary identifiers. Reproduce from the repository root:

```sh
make bench-compiler-keywords
build/bench_keywords 2000000 9
```

On Linux x86-64 with GCC 14.2, both benchmark binaries were built as C++17 `-O3 -DNDEBUG`. Seven alternating V162/V163 process pairs, each running a warm-up plus five measured samples, compared 2,000,000 word iterations (4,000,000 membership lookups) per process. The median of the seven process medians was 113.514 ms on V162 and 47.069 ms on V163 (2.41x faster, 58.5% lower latency). The change uses immutable `unordered_set<string_view>` tables and combines primitive types into the reserved vocabulary, preserving exact case-sensitive matches. This measures fixed-word classification only; it excludes parser traversal, semantic analysis, LLVM generation, backend work, linking and program execution.

The 5,000-function parser microbenchmark (`benchmarks/compiler_parser.cpp`) was also run in alternating processes. Timings varied across runs and did not establish a reliable whole-parser speedup, so no compiler-wide performance claim is made. Re-run both benchmarks on the target machine before drawing workload conclusions.

---

# FAC V162 — bounded `parallelFor` queue validation

`benchmarks/parallel_for_pool.cpp` was used to compare the warmed persistent pool before and after queue back-pressure. On Linux x86_64 with Clang 17, both Runtime objects used C++17 `-O2 -fstack-protector-strong -D_FORTIFY_SOURCE=2 -fcf-protection=none -fPIC -pthread`; the harness used `-O2 -pthread`. Seven alternating process runs measured 1,000 synchronous calls per process:

| Batch size | V161 median | V162 median | Difference |
|---:|---:|---:|---:|
| 8 items | 22.102 ms | 22.345 ms | +1.1% latency |
| 32 items | 19.760 ms | 19.473 ms | -1.5% latency |

The differences are small relative to run-to-run variation. This change is a bounded-memory/back-pressure hardening, not a throughput optimization; the measurements do not establish a whole-program performance change. The separate 80-caller × 96-callback stress test exercises the saturation path and verifies exact-once completion.

# FAC V161 — Runtime weak-handle throughput benchmark

`benchmarks/weak_handle.cpp` measures `fac_obj_weak_alive` and a `fac_obj_weak_retain` + `fac_obj_weak_release` pair over warmed samples. Reproduce with identical Runtime and harness flags on the same machine:

```sh
g++ -std=c++17 -O2 -DNDEBUG -g0 -pthread -c runtime/fac_rt.cpp -o build/fac_rt.o
g++ -std=c++17 -O3 -DNDEBUG benchmarks/weak_handle.cpp build/fac_rt.o -pthread -lm -ldl -o build/bench-weak
./build/bench-weak 3000000
```

On Linux x86_64 with GCC 14.2, Runtime C++17 `-O2 -DNDEBUG -g0`, and benchmark `-O3 -DNDEBUG`, three alternating V159/V161 process pairs each used nine samples of 3,000,000 iterations. The median of the three process medians was:

| Operation | V159 | V161 | Improvement |
|---|---:|---:|---:|
| `weak_alive` | 10.46 ns/op | 2.26 ns/op | 4.63x faster (78.4% lower latency) |
| weak retain + release pair | 19.00 ns/pair | 8.33 ns/pair | 2.28x faster (56.2% lower latency) |

V161 stores weak controls in lazily allocated stable blocks. The generation, object-anchor flag and external-handle count are packed into one atomic state word, so normal alive/retain/release operations do not acquire the global object lifecycle mutex. `weak_lock` still uses that mutex to synchronize registry validation and strong-reference promotion. The slot blocks remain allocated until process exit and are reused; these measurements exclude the memory high-water trade-off, multithread contention, string/object application work, and process startup. This is a narrow single-thread C-ABI microbenchmark, not a whole-program speed claim. Re-run on the target machine before capacity planning.

## Historical V138 weak-handle baseline

`benchmarks/weak_handle.cpp` measures two narrow Runtime paths using warmed samples and medians: `fac_obj_weak_alive` and a pair of `fac_obj_weak_retain` + `fac_obj_weak_release` calls. Build the Runtime and harness with the same compiler and optimization flags for before/after comparisons; record compiler version, platform, flags, sample count and iteration count. Example on Linux x86_64:

```sh
g++ -std=c++17 -O3 -DNDEBUG -pthread -c runtime/fac_rt.cpp -o build/fac_rt_v138.o
g++ -std=c++17 -O3 -DNDEBUG benchmarks/weak_handle.cpp build/fac_rt_v138.o -pthread -lm -ldl -o build/bench-weak-v138
./build/bench-weak-v138 3000000
```

On Linux x86_64 with GCC 14.2, the benchmark was run in three alternating V137/V138 process pairs. Each process used nine samples of 3,000,000 iterations. Both Runtime objects used the same C++17 `-O2 -DNDEBUG -g0 -fPIC -fstack-protector-strong -fcf-protection=none` flags; the harness used `-O3 -DNDEBUG`. The median of the three process medians was:

| Operation | V137 | V138 | Change |
|---|---:|---:|---:|
| `weak_alive` | 2.14 ns/op | 14.07 ns/op | 6.57× slower |
| weak retain + release pair | 22.15 ns/pair | 30.50 ns/pair | 37.7% slower |

The increase is the cost of taking the lifecycle mutex and validating a generation token instead of dereferencing the previous control-block pointer directly. These are narrow, uncontended single-handle microbenchmarks; they do not measure multithread contention or whole-program performance. The safety change is deliberate, but the latency cost is real and should be an optimization target without removing generation validation. See `docs/SECURITY_AUDIT_V138.md` for validation scope and residual safety boundaries.
---

# FAC V129 — Performance and correctness notes

## Scope

V129 addresses three separate hot paths: Graph bulk insertion, repeated edge-existence queries on high-degree nodes, and the per-FAC-call recursion guard. It also tightens the weighted-Graph contract because Dijkstra is only correct for finite non-negative edge weights.

## Graph storage strategy

Node metadata vectors now grow geometrically instead of calling `reserve(size + 1)` on every insertion. Adjacency vectors also use their normal geometric growth. Each row retains a compact vector for ordinary degrees; rows that reach 48 neighbors gain a secondary `unordered_set<int>` for expected constant-time membership tests. The threshold avoids allocating a hash table for every low-degree node. Edge-index insertion is staged and rolled back if either direction fails; removals update the secondary index.

`make bench-graph-scale` reports median timings for node insertion and a high-degree star build plus repeated membership queries. Run it with the same compiler, machine, load and flags when comparing revisions. The output includes a checksum to prevent dead-code-only measurements. These are microbenchmarks; they do not predict all Graph workloads.

### Local V128 → V129 comparison

On the Linux x86_64 development host, the same `benchmarks/graph_scale.cpp` harness (five repetitions, median) was linked once against the original V128 Runtime object and once against the V129 Runtime object. Both Runtime objects and the harness were built with GCC C++17 `-O2`. Values are milliseconds:

| Workload | V128 | V129 | Approx. speedup |
|---|---:|---:|---:|
| Insert 1,000 nodes | 11.310 | 0.136 | 83× |
| Insert 2,000 nodes | 41.766 | 0.225 | 186× |
| Insert 4,000 nodes | 178.888 | 0.378 | 473× |
| 1,000-node star build + 20,000 membership queries | 102.541 | 0.947 | 108× |
| 2,000-node star build + 40,000 membership queries | 396.174 | 1.939 | 204× |
| 4,000-node star build + 80,000 membership queries | 1,597.098 | 4.791 | 333× |

These are deliberately high-degree / bulk-insert stress cases that expose the old exact-capacity reservation and linear membership scan. They are not representative of every graph shape; the hybrid index is intended to keep low-degree rows compact.

## Recursion guard

The generated LLVM IR performs thread-local stack-distance and call-depth checks inline. A cold failure branch calls `fac_recursion_fail`; normal calls no longer make separate enter/leave Runtime calls. The depth limit (4,096) and platform-specific stack budget remain active. FAC exception boundaries save and restore both guard values so a `longjmp` cannot leave stale depth/stack state behind. The stack anchor is cleared when the outermost FAC function returns.

The existing `tests/bench/b01_fib` benchmark is the recursive-call workload. `python3 tests/bench/run_bench.py --only fib --runs 5` compares C, normal FAC and `--unsafe-fast`; all outputs must match the checked-in expected value. The runner reports a median, not a best-of-N sample.

### Local recursion microbenchmark

A separate same-source comparison used naïve recursive Fibonacci(39), alternating five runs per revision and checking the exact result `63,245,986` on each run. The native output used the same Clang 17 `-O2` backend and the respective V128/V129 Runtime objects; median process wall time was **1,575.5 ms (V128)** and **1,219.8 ms (V129)**, about **1.29× faster**. This synthetic workload is recursion-heavy and should not be read as a whole-program speedup.

## Weighted paths

`fac_g_addedge3` and `fac_g_addarc3` accept only finite, non-negative weights. Invalid weights raise the established Resource/Argument error (code 8) before new nodes are published. This is required by the Dijkstra implementation used by `fac_g_shortest`. Distance initialization uses IEEE positive infinity, so large finite paths are not confused with unreachable nodes by an arbitrary `1e300` cutoff.

## Reproducibility and limits

Record OS, architecture, compiler version, optimization flags, run count and CPU/load conditions with any published comparison. Use medians and checksums. Do not compare the old V128 best-of-N results directly with V129 median-of-N results without rerunning both revisions under the same harness. Sanitizer and cross-platform jobs are configured in CI; they are not evidence of a pass until the relevant runner completes.

---

## V123 generic specialization cache benchmark

The reproducible harness is `benchmarks/compiler_generic.py` (also `make bench-generic`). It creates 100 generic struct templates and references each concrete specialization 40 times (4,000 references total), then measures complete frontend/codegen process wall time across nine repetitions. On Linux x86_64 with GCC C++17 `-O0`, the same workload measured median source-to-IR time of 373.091 ms on V122 and 356.334 ms on V123 (about 4.5% lower). Generated LLVM IR was the same size in both versions: 557,191 bytes. The improvement is consistent with replacing the lookup-only generic-template, type-specialization and generic-method caches with `std::unordered_map`; it does not demonstrate faster generated program execution or a general 4.5% compiler speedup. The test and benchmark source generator are in `tests/generic/run.sh` and `benchmarks/compiler_generic.py`.

V123 also corrects generic instantiation accounting: a cache hit no longer increments the 5,000 distinct-specialization budget. A source using one specialization in 5,001 fields now compiles, while 5,001 distinct specializations still receive the established limit diagnostic. This is a compiler correctness fix; no type-system rule or syntax changed.

## V122 compiler memory probe

The reproducible Linux probe is `benchmarks/compiler_memory.py` (also `make bench-memory`). It generates an import graph and substitutes a `FAC_CC` probe that samples the facc parent process through `/proc/<pid>/status` at backend launch. On Linux x86_64, 130 modules / 32,251 functions / 2,832,098 source bytes measured median backend-launch RSS about 592,536 KiB on V121 versus 21,460 KiB on V122 (about 96.4% lower). Peak RSS stayed about 609.6 MiB in both because frontend AST/codegen still needs the complete graph. This is retained memory at backend launch, not a reduction in frontend peak and not a native backend/runtime benchmark. Details and commands: `docs/COMPILER_MEMORY.md`.

## V121 conservative constant-folding microbenchmark

The reproducible harness is `benchmarks/compiler_codegen.py` and accepts a compiler path, function count and repetition count. Example: `python3 benchmarks/compiler_codegen.py ./build/facc 600 15`. It generates 600 functions (65,372 source bytes) containing constant integer subexpressions mixed with runtime parameters, invokes the compiler with `--emit-ll`, and reports median source-to-IR wall time plus generated IR byte count. On the Linux x86_64 development host with GCC C++17 `-O0`, using the same harness and 15 timed repetitions, V120 measured 101.189 ms and 398,563 IR bytes; V121 measured 92.092 ms and 201,489 IR bytes (about 9.0% lower wall time and 49.4% fewer IR bytes for this constant-heavy input). These measurements include frontend/codegen and process startup; they exclude LLVM backend optimization, native code generation, linking and execution. They are not a general-purpose speedup claim.

V121's evaluator is deliberately conservative and bounded to 64 AST nodes per candidate. It folds only pure literal integer/character/boolean trees when every intermediate value is representable in its FAC type. This preserves signed-width wrapping behavior by leaving overflowing intermediate expressions explicit. Division by zero, signed minimum divided by -1, uncertain signed/unsigned conversions, calls, side effects, shifts and exponent operations remain on the regular code-generation path. `tests/codegen/run.sh` validates emitted IR and runtime results at FAC `-O0` and `-O2`, including `--check-overflow` guard retention. A deterministic differential test of 200 arithmetic expressions matched V120 results and the integer reference model exactly.

## V120 semantic ancestry microbenchmark

Build and run the subtype-check workload from the repository root:

```sh
c++ -std=c++17 -O2 -DNDEBUG -Isrc benchmarks/compiler_semantic.cpp -o build/bench_semantic
./build/bench_semantic 2048 15
```

The benchmark constructs a 2,048-class single-parent hierarchy and checks 4,094 child/base relationships per round. It reports a cold pass and repeated-pass median separately. On the Linux x86_64 development host with GCC C++17 `-O2 -DNDEBUG`, the same benchmark source and flags measured a V119 repeated-pass median of 661.670 ms and a V120 median of 209.615 ms (about 68.3% lower for this synthetic hierarchy). This isolates `Gen::isSubclass`; it excludes parsing, complete type checking, IR generation, LLVM optimization, linking and program execution. A real project may show a smaller benefit depending on the number and shape of inheritance checks. Do not interpret this as an end-to-end compiler speedup.

# FAC performance notes

## Runtime improvements in this edition

- `string` is immutable. Copying/assigning a string, passing it by value, or copying it as a managed field now shares the same UTF-8 buffer and increments an atomic reference count. This changes copy cost from O(string length) plus allocation to O(1). Literal strings remain immortal and do not need reference-count updates.
- Dynamic strings now allocate the `FacStr` header and UTF-8 bytes in one contiguous block instead of two separate heap allocations. This keeps the public/internal `FacStr` field layout unchanged while reducing allocator traffic and improving locality; all runtime creation paths (`mk`, binary concat, and concat-many) use this representation.
- The compiler flattens a left-associated chain of 3 or more string `+` operands into one `fac_str_cat_many` call. It evaluates fragments once, in source order, then allocates and copies the final result once. Two-fragment concatenation keeps the simpler binary path. For dynamically sized batches, use `string.join(parts, separator)`.
- Temporary owned values (including managed structs) are registered for exception unwinding. Runtime temporary/cleanup stack exhaustion now raises a FAC error instead of silently skipping a release or terminating without unwinding.
- Memory APIs reject negative/oversized lengths and null pointers for non-zero operations. List construction/copy/slice and capacity changes validate metadata and byte-size arithmetic before allocation.
- Dynamic lists retain geometric capacity growth. `reserve(n)` can preallocate when the final size is known; `shrink()` releases spare capacity. Capacity and byte-size arithmetic is checked before allocation to avoid overflow.
- List insertion snapshots a source element when it aliases the list's own allocation, so growth/reallocation and shifting cannot invalidate the source. The target slot is made a valid zero value and included in the list length before a managed copy callback can throw. Generated struct-copy helpers clear all managed destination fields before retaining them, so partial copies can be safely dropped.
- Compiler-generated list paths register owned string/struct/object temporaries before operations that may throw. String-list insertion transfers its owned reference only after the element is safely stored; object/struct list insertion retains a separate list-owned copy.
- `-O2` remains the default. `-O3`, `--cpu native`, optional CPU features and LTO should be benchmarked on the actual target; they can increase code size or reduce portability.

## Reproducing the string-copy microbenchmark

After building FAC:

```sh
clang++ -std=c++17 -O2 -pthread benchmarks/string_copy.cpp build/fac_rt.o -ldl -o build/bench_string_copy
build/bench_string_copy 3000000
```

One local run with 3,000,000 copies of a 1 KiB string measured about 1.32–1.40 seconds on the previous deep-copy runtime and 0.017–0.019 seconds with shared immutable strings (roughly 70x for this isolated operation). This is a microbenchmark, not a general language-vs-language or application benchmark.

## Reproducing dynamic string allocation benchmark

```sh
clang++ -std=c++17 -O2 -pthread benchmarks/string_alloc.cpp build/fac_rt.o -lm -ldl -o build/bench_string_alloc
build/bench_string_alloc
```

On the same host/toolchain, 3,000,000 dynamic 78-byte string create/free operations measured a median of 0.204 s with the prior two-allocation representation and 0.181 s with the contiguous representation (about 11% faster in this focused test). This is not a whole-program speedup claim.

## Current costs worth knowing

- `+` on strings creates new storage; repeated left-associated concatenation can copy the accumulated prefix repeatedly. Prefer `string.join` for batches.
- Passing arrays by value only copies when the compiler detects mutation in the callee; use `ref` when mutation is intended to affect the caller.
- Managed `list` and `struct` copies preserve value semantics and may be O(n); use `ref` for large mutable structures when sharing mutation is intended.
- Bounds checks and divide-by-zero checks are enabled by default. Keep them for normal development; only disable them after profiling and validating inputs.
- Regex patterns are compiled by the runtime for each call; repeatedly using the same complex pattern is a candidate for a future compiled-pattern API.

## Portability

The shared-string implementation uses compiler atomic builtins for its reference count and keeps the existing LLVM-visible `FacStr` layout. It is intended for the supported Clang/GCC toolchains. Run the regression and sanitizer suites on each OS/architecture target before treating it as validated there.

## Reproducing the string-concatenation microbenchmark

```sh
clang++ -std=c++17 -O2 -pthread benchmarks/string_concat.cpp build/fac_rt.o -ldl -o build/bench_string_concat
build/bench_string_concat 500000
```

One local run with eight 10-byte fragments over 500,000 rounds measured 0.0827 s for repeated binary concatenation and 0.0248 s for the flattened `cat_many` path (about 3.34x in this isolated benchmark). This result depends on the host/compiler and does not imply a 3.34x whole-program speedup.

## Safety validation in this update

The regression suite includes the managed-temporary, allocation-size, string-concatenation, ownership, collection, import, terminal-input, and struct-closure-field cases. On the development host, the current 71 regression cases passed at `-O0` and `-O2` under both GCC and Clang; all 38 negative tests passed. The full language sanitizer suite was not run. Focused ASan+UBSan+LeakSanitizer runs with `FAC_TMP_CHECK=1` covered 7 ownership/collection cases and 3 thread/library cases (10/10). Runtime sanitizer tests passed for array operations, alias-safe list insertion, and concurrent random reseeding. The network-heavy `t14_apis` case passed the regular regression run with its stdin fixture, but was not included in the focused sanitizer groups.

Run runtime unit tests after `make` with `CXX=clang++ tests/runtime/run.sh` (or `CXX=g++ tests/runtime/run.sh`); run ASan/UBSan/LeakSanitizer with `CXX=clang++ tests/runtime/run_sanitizers.sh`.


## Stability and driver hardening

- The compiler driver passes backend commands as an argv array using `execvp` on POSIX and `_spawnvp` on Windows. Paths with spaces or shell metacharacters remain single literal arguments; they are not evaluated by a command shell. `FAC_CC` must identify one executable.
- `--pkg` validates package identifiers before querying `pkg-config`, then tokenizes its output into compiler arguments rather than appending it to a shell command.
- Runtime array helpers validate negative counts, element widths, null pointers and `count × element_size` overflow before operating. `fill` snapshots the source element so a source that aliases the destination does not change during the fill.
- `sort(sequence, comparator)` registers its temporary merge-sort buffer with the FAC unwind stack, so a throwing comparator does not leak that allocation. Plain `sort(sequence)` is limited to runtime-supported scalar/string types. Managed types cannot use raw-byte `fill`.
- Terminal output destination is thread-local, and writes to stdout/stderr are serialized after the runtime enters multithreaded mode.
- The default C++ build adds `-fstack-protector-strong` and `_FORTIFY_SOURCE=2` when supported. These flags harden the compiler/runtime binaries; they do not replace FAC bounds checks or input validation.

## Added hardening tests

- `tests/runtime/array_ops.cpp` covers sorting, reverse, alias-safe fill, find, invalid dimensions and cleanup when a custom comparator throws.
- `tests/runtime/run.sh` also verifies special-character paths remain literal and unsafe `--pkg` identifiers are rejected.
- Negative compiler tests reject default sort for custom structs and raw-byte fill for managed string collections.

## V159 HashMap flat index

The Runtime HashMap/HashSet lookup index now uses a flat open-addressed table rather than one `std::unordered_map` node allocation per key. Slots store compact item indices, while the item vector remains the owner of key/value blobs and preserves insertion order. Triangular probing works with power-of-two capacities; the table grows before reaching 75% occupancy, reuses tombstones, and rebuilds after deletion-heavy workloads. Item compaction remains best-effort: if allocation fails, the completed removal and the existing lookup table remain valid. String-key ownership and value-replacement rollback semantics are unchanged.

Reproduce the focused runtime benchmark with `make bench-hashmap` (or `build/bench_hashmap_runtime 1000000 7`). It performs one warm-up and seven timed rounds of 1,000,000 integer-key inserts, gets and even-key membership checks, validates the checksum on every round, and reports median operation times. On the Linux x86_64 development host with Clang 17 C++17 `-O2`, a paired run of the same harness against the supplied V159 runtime and the flat-index runtime measured medians of **526.201 / 190.144 / 198.502 ms** and **338.118 / 124.801 / 112.496 ms** for `set / get / has`, respectively (about **35.7% / 34.4% / 43.3% lower**). This is a direct Runtime C-ABI microbenchmark for integer keys; it excludes FAC frontend/backend compilation, process startup, string-key workloads, memory profiling and complete applications. Re-run on the target machine before using these percentages for capacity planning.

The optimization does not change HashMap/HashSet syntax, public methods, insertion-order behavior, key equality, C ABI or Runtime ABI. It remains exception-safe under allocation failure, with regressions in `tests/runtime/hashmap_flat.cpp`, `tests/runtime/ds_exception.cpp` and `tests/runtime/ds_memory.cpp`.

## Random-number generation under concurrency

- Runtime random APIs use a separate `mt19937_64` engine per thread rather than serializing every draw through one global engine. The common path checks one atomic seed epoch and then draws locally; `random.seed()` publishes a new epoch, and each thread reseeds on its next random call. This avoids the old global RNG mutex contention when many FAC threads generate random values.
- The first stream initialized after a seed preserves the historical single-thread seeded sequence. Other threads receive distinct derived streams; interleaving across threads is intentionally not deterministic. A seed call concurrent with draws takes effect on each thread's next call, so parallel sequences should not be used as reproducible simulations unless the application controls thread startup and seed assignment.
- Reproduce the concurrency/stability check with `CXX=clang++ tests/runtime/run.sh`; run it under ASan/UBSan/LeakSanitizer with `CXX=clang++ tests/runtime/run_sanitizers.sh`.


## V118 compiler frontend microbenchmark

The lexer hot path was improved by parsing numeric literals directly from the source buffer when no digit separator is present, and by rejecting multi-character operator candidates using the first character before doing a full comparison. Separator-bearing numbers keep the compacting fallback so the established spelling rules remain intact.

Reproduce the synthetic identifier/operator workload from the repository root:

```sh
c++ -std=c++17 -O2 -Isrc benchmarks/compiler_lexer.cpp src/lexer.cpp -o build/lexer-bench
./build/lexer-bench 20000
```

The benchmark warms the lexer once and reports the median of seven measurements. On the Linux x86_64 development host, a V117 vs V118 comparison for 20,000 statements (320,001 tokens) measured 48.6075 ms vs 30.5151 ms, or about 37.2% faster for this specific lexer workload. This measures lexing only: it excludes parsing, semantic analysis, LLVM IR generation, LLVM optimization, linking and program execution. Do not use this percentage as a whole-compiler or generated-program speed claim. Re-run on the target machine before making performance decisions.



## V119 Parser microbenchmark

Build and run the synthetic parser benchmark from the repository root:

```sh
c++ -std=c++17 -O2 -DNDEBUG -Isrc benchmarks/compiler_parser.cpp src/lexer.cpp -o build/bench_parser
./build/bench_parser 5000 8
```

The workload generates 5,000 small FAC function definitions and reports Lexer, Parser and combined frontend time separately. Measurements should include a warm-up run and compare medians over several invocations on the same host. On the Linux x86_64 development host, a V118 baseline built from the original `src/parser.hpp` had a 37.62 ms Parser median across five benchmark invocations; V119 measured 30.75 ms, about 18.3% faster for this synthetic parser workload. The Lexer portion is reported separately. The benchmark excludes semantic analysis, IR generation, LLVM optimization, linking and runtime execution; it does not support a whole-compiler speedup claim.

V119 also adds `tests/parser/parser_regression.cpp`, which locks down the 15 supported assignment operators, right-associative assignment and exponentiation, binary precedence, postfix increment and source-column reporting for malformed expressions. `make test-parser` runs this focused suite.


## V128 Graph lookup index

The Graph runtime previously built a temporary `std::string` around every lookup key and copied each stored key into the `std::unordered_map` index. V128 stores Graph nodes in `std::deque<std::string>` and indexes them through non-owning `std::string_view` keys. `std::deque` preserves references to existing elements when appending at either end, including the object address for short-string-optimized keys. The index is always erased before its backing node key is released. Insert and clone paths roll back a newly retained managed key when deque or index allocation fails; removal and clear paths drop index views before freeing key payloads.

The regression coverage in `tests/runtime/ds_memory.cpp` grows the graph across thousands of nodes, verifies both edge directions, removes and reinserts a key, clones the graph, and checks managed-string keys after the caller releases its references. `tests/runtime/ds_exception.cpp` and `tests/runtime/ds_clone_exception.cpp` continue to inject allocation failures through node insertion, edge insertion and cloning.

Reproduce the lookup microbenchmark with `make bench-graph-lookup`. It creates a 12,000-node ring and measures 500,000 `fac_g_hasedge` calls per repetition, with five timed repetitions after warm-up, separately for 64-bit integer keys and managed string keys. On the Linux x86_64 development host with Clang C++17 `-O2`, a paired run of the same harness against the V127 runtime object and the V128 runtime object measured integer-key lookup medians of 32.180 ms and 24.863 ms (about 22.7% lower). Repeated runs at 20,000 nodes / 1,000,000 lookups also showed a lower integer-key median (83.316–85.642 ms on V127 versus 71.985 ms on V128). Managed-string key timings varied between runs and did not show a repeatable improvement, so no string-key speedup is claimed. This is a focused lookup microbenchmark: graph construction, adjacency storage, complete application workloads and cross-platform performance are not included. Re-run on the target machine before using these percentages for capacity planning.

This is a storage/index optimization only. It does not change Graph semantics, key equality, node ordering, public declarations, C ABI, Runtime ABI or language syntax. Safety checks remain enabled; the optimization does not rely on `--unsafe-fast`.
