# FAC V220 — Socket and TLS handle lifetime/concurrency safety

## Scope

V220 applies the Runtime's opaque-token and lifecycle-guard approach to TCP sockets and optional OpenSSL TLS streams. It does not change public API signatures, pointer-sized opaque-handle representation, or exported C ABI symbol names.

### TCP sockets

- `Sock*` is now a stable opaque token. Runtime code resolves it through a registry and never dereferences caller-provided token memory. Token storage is retained for process lifetime to prevent address reuse from reviving stale aliases.
- A shared socket-state record owns the native descriptor, lifecycle state, active-operation count, and synchronization primitives.
- Read and write paths have independent mutexes, while socket options have their own lock. A read waiting for input no longer blocks a simultaneous write on the same TCP connection.
- `close` marks the socket as closing, prevents new operations, waits for existing operations to release their leases, closes the descriptor once, and retires the token. Repeated close is harmless; later I/O through a stale alias reports Network (11).
- TLS wrapping reserves the socket, drains existing TCP operations, and transfers ownership only after the handshake succeeds. A failed handshake leaves the socket with the caller.

### TLS streams

- `FacTlsHandle*` is a stable opaque token backed by a registry record; token addresses are not reused during process lifetime.
- A TLS state retains shared ownership of the socket record and owns its OpenSSL context/session. A successful wrap retires the original socket token.
- OpenSSL operations and TLS close are serialized by a per-stream mutex. Close first marks the stream as closing atomically, so operations that begin afterward fail closed, then waits for any active TLS call and destroys SSL/context and the owned socket exactly once. Stale TLS aliases report Network (11) for operations and metadata queries; repeated close is harmless.
- FAC cleanup callbacks release held locks and socket leases when a FAC error uses the Runtime's longjmp-based throw path.
- TLS is intentionally single-flight per stream: a blocking `recvExactBytes` holds the stream lock and delays a concurrent `sendBytes` on that same TLS object. Use independent streams for independent concurrent traffic directions.

## Regression coverage

- `tests/runtime/socket_handle_concurrency.cpp` checks close versus active I/O, stale-token rejection after 256 create/close cycles, repeated close, and full-duplex TCP read/write where the blocked reader does not block an independent writer.
- `tests/runtime/tls_loopback.cpp`, launched through `tests/runtime/tls_loopback.sh`, verifies TLS 1.2/1.3 negotiation, hostname verification, socket ownership transfer, stale socket/TLS token rejection, idempotent close, and close racing a timed TLS read. The script also runs encrypted WebSocket loopback cases.
- `tests/runtime/run.sh` includes the TCP socket test. `tests/runtime/run_tsan.sh` and `tests/runtime/run_sanitizers.sh` include it for future sanitizer runs.

## Constraints

- The token registries retain token objects until process shutdown; memory use therefore grows with the number of socket/TLS handles created over the process lifetime. Native descriptor and OpenSSL resources are released on close.
- TLS calls on one stream are serialized rather than allowing simultaneous SSL_read/SSL_write.
- The wrapper object's own fields must not be concurrently mutated or destroyed while another thread invokes methods on that same managed object.
- Windows TLS remains unavailable in this release. Full cross-platform qualification is not claimed.
