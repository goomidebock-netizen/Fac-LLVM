# FAC Language Core V196 — reachable CFG and borrow liveness

## Problem

The strict local-borrow checker uses a backward CFG may-liveness analysis to expire local aliases after their last possible use. The CFG builder already removes one outgoing edge for literal Boolean conditions, but the solver previously initialized and processed every block regardless of whether it was reachable from the function entry. Consequently, a dead branch could still compute non-empty local liveness and trigger a borrow conflict while the AST semantic pass visited that unreachable branch.

## V196 behavior

1. Build the existing CFG, including branch, loop, exceptional and finalizer edges.
2. Run a forward graph walk from the function entry and mark reachable basic blocks.
3. Collect resolved alias uses and predecessor edges only for reachable blocks.
4. Solve backward may-liveness over the reachable subgraph.
5. Associate unreachable syntax nodes with empty flow facts. The checker still performs ordinary semantic/type checks on those nodes, but they cannot keep a loan live or cause an impossible owner-access conflict.
6. Pin `defer`-captured aliases only when the defer node itself is reachable.

The CFG recognizes a bounded set of proven constant predicates: Boolean literals, unary logical negation, short-circuit conjunction/disjunction when the left operand fixes the outcome or both operands are constant, integer literal comparisons (`==`, `!=`, `<`, `<=`, `>`, `>=`) and Boolean literal equality/inequality. Unknown identifiers, const-variable references, calls, arithmetic, floating-point comparisons and side-effecting expressions are not folded. They keep both control-flow edges.

## Tests

- A mutable borrow remains live after the branch and is used later; owner writes in a literal-unreachable `else` arm are accepted.
- Integer and Boolean literal comparisons prune proven-impossible arms.
- `true || runtimeFlag` and `false && runtimeFlag` prune only the arm that short-circuit semantics make impossible.
- Runtime program output is checked to ensure analysis-only branch pruning does not rewrite generated control flow.
- A mutable `runtimeFlag` condition still has both CFG edges and the same owner write is rejected.
- A potentially reachable `defer` still pins its captured alias conservatively; only a defer in a proven-unreachable branch is omitted from pinning.

## Boundaries

V196 does not add source lifetime annotations, reference-valued return/field types, general outlives inference, arbitrary const evaluation, runtime branch elimination, raw-pointer alias proof, FFI verification, concurrency safety or a complete borrow checker. It changes only static local-borrow CFG reachability/liveness. The V195 system-font UI implementation is carried forward unchanged.
