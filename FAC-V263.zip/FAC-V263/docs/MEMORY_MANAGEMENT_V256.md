# FAC V256 — nested match-payload pointer-return fail-closed check

V256 closes a gap in the strict-ownership return check for pointer-bearing return types. Before this change, a direct `return match (...) { ... }` that returned an enum payload binding was rejected because payload provenance is not tracked. The same `match` nested inside an `ifv / eiv / elv` result arm could bypass that top-level-only guard: payload bindings had no verified origin, so the pointer-return escape check could incorrectly see no origin to validate.

The checker now walks the returned expression's result-producing structure. It detects an untracked payload binding in a `match` expression even when that match is nested within conditional result arms, then rejects the return with the existing fail-closed diagnostic. It deliberately ignores `ifv` conditions and match scrutinees, patterns and guards because those expressions select a result rather than supply the returned pointer. Nested lambdas/functions are separate return domains and are not traversed.

This is a conservative rejection fix, not enum-payload provenance support. FAC still does not track pointer provenance through enum payload storage, and such pointer returns remain unsupported. No source syntax, Runtime, ARC/GC, public API, C ABI, Runtime ABI or `--memory-safe` accepted subset changed.

## Regression coverage

- A pointer returned from a match payload binding directly remains rejected.
- A pointer returned from a match payload binding nested inside an `ifv` result arm is now rejected.
- A match expression used only as an `ifv` condition does not contaminate return-value provenance and remains accepted.
- Existing V235 conditional/match return-source tests continue to pass.

## Validation on this host

- Compiler build: Clang 17, C++17, `-O0 -g0` — passed.
- Lifetime regression: 123 checks — passed, including both V256 cases.
- Ownership regression: 261 checks — passed (12 base, 8 const-method, 167 local-borrow, 17 noescape, 25 field-sensitive, 19 effect-contract, 13 function-effect).
- Secure profile: 6/6; `--memory-safe`: 39/39.
- Move/partial-move: 20/20 and 28/28.
- Compile-time/const-generic: 57/57; Generic specialization: 3/3.
- Lexer: 18/18; Parser: 68 checks plus AST model 1/1; focused Codegen checks — passed.
- API/standards checks against the existing V128 compatibility baseline — passed; 0 breaking changes, 132 warnings, and 5 findings all within the existing API-audit baseline.

The semantic suite began and passed its 17 ancestry checks but did not complete within the command time limit. The Tools suite also did not complete within the command time limit. Full CMake/CTest, Runtime sanitizer qualification (ASan/UBSan/TSan), cross-platform testing and production qualification are not claimed for V256.
