# FAC Language Core V205 — Trusted FFI Lifetime Contracts

## Scope

V205 permits extern declarations to state named pointer lifetimes and outlives requirements using the existing signature forms:

```fac
extern function lifetime<a> ptr<a> int ffi_identity(ptr<a> int value) as "ffi_identity"
extern function lifetime<a, b> void ffi_consume(ptr<a> int longer, ptr<b> int shorter) where a: b as "ffi_consume"
```

No new runtime representation or native calling convention is introduced. `TypeSpec` lifetime names are bound to the same stable indices used by ordinary FAC function declarations. Extern declarations are included in the call-contract table, so the V204 caller-side substitution and pointer-return provenance logic applies without a separate FFI-specific solver.

## Safety model

An extern lifetime contract is a trusted promise made by the declaration author. The compiler:

- checks that every `ptr<name>` refers to a declared lifetime parameter;
- checks that a pointer return lifetime can be supplied by a pointer parameter whose declared lifetime outlives it;
- instantiates named lifetimes from actual pointer provenance at resolved direct call sites;
- validates each declared `where longer: shorter` relation against the caller's region graph;
- propagates a returned pointer's provenance only from declared pointer parameters that can satisfy the declared return lifetime.

The compiler cannot inspect foreign implementation code. If the external implementation returns a pointer to storage unrelated to the parameter contract, retains a pointer beyond the contract, or otherwise violates the declaration, the guarantee does not hold. FFI authors must only write contracts that the foreign implementation actually satisfies. Existing `extern` behavior without lifetime annotations is unchanged.

## Parser and semantic behavior

The parser now shares lifetime declaration parsing, `where` edge resolution, and pointer annotation binding between ordinary FAC functions and extern declarations. This avoids two independently maintained implementations of the same signature rules. Extern return types use the normal type parser with lifetime annotations enabled; the pre-existing leading `volatile` return spelling is retained.

The current checker still requires resolved direct calls with an unambiguous lifetime contract. It does not infer contracts for function values/indirect calls, does not attach lifetime metadata to function-value types, and does not track pointer origins in aggregate fields or arbitrary containers. Ambiguous overloads remain conservative.

## Compatibility

- No public Runtime API or C ABI changes.
- No Runtime source changes.
- No ownership/refcount representation changes.
- Existing extern declarations without lifetime syntax continue to parse and use their prior behavior.
- `noescape` and `readonly` extern annotations remain trusted FFI promises; V205 adds lifetime promises under the same trust boundary.

## Validation

Linux x86-64, GCC 14.2, CMake Debug (`-O0`):

- Compiler target and Runtime static library built successfully.
- Lifetime integration: 19 checks passed, including valid extern identity/where contracts, reversed `where` rejection, caller-side returned-pointer escape rejection, and invalid return-lifetime signature rejection.
- CTest: 30/30 passed, including lexer/parser, lifetime integration, frontend/runtime fuzz smoke, memory-safe profile, Runtime regression tests, and package-install consumer.

Optimized compiler, sanitizer qualification, cross-platform builds, and foreign-implementation conformance are not claimed by these tests.
