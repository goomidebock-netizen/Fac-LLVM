# FAC V220 — Const Generic Value Inference

## Status and scope

V220 adds a bounded inference path for `const int` parameters on **generic free functions**. When a const parameter appears directly as the fixed-array extent of a function parameter, the compiler can obtain its value from a fixed-size array argument and specialize the function without an explicit generic argument list.

This is not general const-expression solving and does not infer values from runtime lengths. Generic struct/class instantiation and generic methods do not infer omitted arguments when const parameters are present, but declared defaults may supply omitted parameters.

## Basic syntax

```fac
public function<const int N: positive>
int getCapacity(array var int values[N]) {
    return N
}

public function void main() {
    array var int data[8]

    // Compiler infers N = 8 from the fixed array's type/extent.
    var int count = getCapacity(data)
}
```

Type parameters and const parameters may be inferred from the same argument:

```fac
public function<T, const int N: positive>
T first(array var T values[N]) {
    return values[0]
}

public function void main() {
    array var int numbers[4]
    array var double samples[3]

    var int firstNumber = first(numbers)       // T = int, N = 4
    var double firstSample = first(samples)    // T = double, N = 3
}
```

The inferred value is substituted through the specialized function body, including local fixed-array dimensions. Existing const generic predicates are checked against the inferred value, and the evaluated value participates in the specialization cache key.

## Inference rules

1. Inference applies to generic **free functions** only. Generic methods and generic struct/class instantiations do not infer generic arguments from call/initializer context; they may omit parameters only when those parameters have defaults.
2. For the inference path, the call omits the generic argument list entirely. Supported inference runs first; declared defaults then fill parameters that remain unresolved. A call with an explicit partial generic argument list uses defaults for omitted parameters rather than inferring those omissions from ordinary function arguments.
3. A const parameter must occur directly as a fixed-array extent in a function parameter type, for example `array var T values[N]`. The current matcher does not solve algebraic patterns such as `values[N * 2]` or `values[N + 1]` backwards.
4. The corresponding argument must have a fixed-size array type whose extent is known at compile time. A dynamic `list`, unknown-length array or runtime length is not evidence for `N`.
5. If the same const parameter appears in more than one array parameter, all inferred extents must agree. Contradictory extents are rejected.
6. Ordinary type parameters can be inferred at the same call from supported argument positions, including the element type of `array T` parameters. Every type and const parameter still needs sufficient argument evidence.
7. Explicit positional or named generic arguments remain available when inference is not suitable. The named/positional ordering rules are unchanged.

A const parameter that does not appear in a supported fixed-array extent cannot be inferred from an integer argument, a return type or a runtime expression. The compiler reports the missing evidence instead of guessing.

## Diagnostics

The regression fixtures cover three important failure classes:

- **Conflicting extents:** two arguments bind the same `N` to different sizes.
- **Missing evidence:** the function declares `N`, but no fixed-array parameter exposes it.
- **Dynamic extent:** a list or other non-fixed-size sequence is passed where `array[N]` evidence is required.

The relevant tests are `tests/comptime/const_generic_inference_conflict.fac`, `const_generic_inference_missing.fac` and `const_generic_inference_dynamic.fac`.

## Codegen and HIR boundaries

Codegen derives the value from the actual fixed-array type/extent and inserts the signed integer into the normalized specialization key. The value is substituted into the cloned function declaration before dependent types and local array dimensions are normalized. Existing const value constraints, integer checks, array layout checks and specialization limits continue to apply.

The semantic HIR also records an inferred const value as a value-bearing `TypeDescriptor` substitution (`isConstValue` plus the signed 64-bit value). Its current conservative source analysis recognizes a fixed-size array local with a supported literal/integer-arithmetic extent. It defers when the source declaration or extent cannot be established. HIR remains a provisional semantic model; Codegen remains authoritative for final diagnostics and specialization.

## Deliberate limits

- Only `const int` values are inferred.
- Only generic free functions use this inference path.
- The const parameter must appear directly as an array extent identifier (`[N]`); no inverse arithmetic or general constraint solving is performed.
- No value is inferred from a list, slice, pointer, runtime length, integer argument, arbitrary function result or return-only type/value parameter.
- Generic defaults are supported separately and may fill unresolved parameters. With an explicit partial generic argument list, omitted values are default-filled rather than inferred from ordinary call arguments.
- Generic method inference and generic type/class inference are not introduced.
- Const-value inference itself does not invoke user-defined functions; V220 later adds a separate bounded scalar free-function `consteval` subset. This feature does not add typed AST construction, reflection or macro expansion.

## Regression and validation

Run:

```sh
sh tests/comptime/run.sh
sh tests/generic/run.sh
sh tests/parser/run.sh
sh tests/run.sh -O0
sh tests/run.sh -O2
sh tests/run_neg.sh
sh tests/memory_safe/run.sh
```

The positive fixture `tests/comptime/const_generic_inference.fac` checks const-only inference, simultaneous type/value inference, specialized local arrays and runtime output. The negative fixtures verify conflicting, missing and dynamic-array evidence. `tests/semantic/generic_free_function_hir.cpp` verifies the inferred `N` is recorded as a const-value substitution in HIR.
