# FAC V212 — Runtime Tensor shape and backing-store safety

## Scope

V212 is a targeted Runtime memory-safety release for Tensor access paths. It does not add language syntax, public API entries, compiler semantics, UI changes or ABI changes.

## Tensor handle invariant

Every non-null opaque Tensor handle is checked before public Tensor operations use it. The validator rejects non-positive dimensions, shapes above the existing 16,777,216-value budget, and backing vectors whose element count does not exactly equal `rows * cols`. The budget is checked by division before multiplication, so malformed dimensions cannot trigger signed multiplication overflow during validation. The existing public empty-tensor behavior is unchanged only where the API already operates on ordinary, valid positive-dimension Tensor values; malformed zero-dimension handles are rejected.

## Embedded Tensor state

The same invariant is checked for Momentum and RMSProp accumulators, both Adam moment tensors, train/test split result tensors and tensor-autograd node values. Autograd node gradient storage must match its value tensor exactly. This closes internal paths that do not pass through the public opaque Tensor handle validator.

## Buffers

The existing software-reference float64 buffer path retains its 256 MiB allocation ceiling, checked subtraction-based range validation, overlap-safe `memmove` copies, complete-output validation before SIMD writes, and safe rejection of non-finite values. The Runtime regression suite continues to run `tests/runtime/buffer_bounds.cpp`; V212 does not change the buffer ABI or claim native GPU execution.

## Regression coverage

`tests/runtime/tensor_shape_safety.cpp` injects malformed Tensor handles and nested state, then checks FAC error codes before the Runtime can index inconsistent storage. It injects allocation failures into Tensor, optimizer-state, train/test split, and byte-buffer creation and verifies conversion to FAC error code 5; repeated split failures must preserve the source Tensor and eventually allow a successful construction. The full `tests/runtime/run.sh` suite is the integration boundary for this change.

## Qualification boundary

This is targeted Tensor and buffer boundary hardening, not a complete proof of memory safety for all Runtime subsystems. ASan/UBSan and TSan qualification, cross-platform qualification and native GPU execution are not claimed unless separately run and recorded.
