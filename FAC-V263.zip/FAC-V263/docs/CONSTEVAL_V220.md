# FAC `consteval` — V220

## Status

FAC V220 implements a **bounded, compile-time-only interpreter** for explicitly marked scalar free functions. This is a deliberately small language subset; it is not general-purpose compile-time execution, a macro system, or a host-language plugin API.

## Syntax

```fac
public consteval function long factorial(long n) {
    if (n <= 1) {
        return 1
    }
    return n * factorial(n - 1)
}

const var long FACTORIAL_7 = factorial(7)
static_assert(FACTORIAL_7 == 5040, "factorial is evaluated at compile time")

public function void main() {
    array var int samples[factorial(3)]
}
```

A `consteval` call is evaluated when its result is needed as a compile-time value. It can be used in module-level scalar `const` initializers, `static_assert`, fixed-array dimensions, integer const-generic arguments, and other supported constant-expression positions. A call with a runtime-dependent argument is rejected; the function is not emitted as a normal runtime function and cannot be used as a runtime function value.

## Supported function contract

- Declaration form: `consteval function ReturnType name(ScalarType parameter, ...) { ... }`; `public consteval function ...` is also accepted.
- Only free functions are supported. The declaration cannot be generic, overloaded, `unsafe`, abstract, exported, a constructor or a destructor.
- Return and parameter types must be scalar integer-like types: integer widths, `bool`, `char`, `unichar`, or scalar enum. Parameters are by value and cannot be ref/readonly/noescape, variadic or defaulted.
- Every argument must itself be evaluable at compile time and fit the declared parameter type. The result must fit the declared return type.
- Calls may nest and recurse. A function may call another supported `consteval` function in its own module. Calls to public `consteval` free functions in an imported user module are supported through a module-qualified path or import alias; module import selection (`just`/`without`) is respected.
- Eligible scalar module-level `const` values in the currently evaluated function's module can be read, as can enum member constants.

## Supported body subset

The interpreter executes only these statement forms:

- Blocks and nested lexical scopes.
- Initialized scalar local declarations.
- `if` / `else` with a compile-time-evaluable condition.
- `return` with one scalar expression.
- Expression statements whose evaluated expression is supported.

Supported expressions include scalar integer/boolean/character literals, local variables, eligible module constants, enum members, unary and binary integer operators supported by the constant evaluator, short-circuit `&&` / `||`, local-variable assignment and compound assignment, local `++` / `--`, and direct calls to other supported `consteval` functions. Arithmetic overflow, division by zero, invalid shifts, unsupported expressions and values outside the declared scalar type range cause evaluation to fail.

## Deterministic resource limits and effects

- Maximum evaluation depth: 64 frames / nested evaluation depth.
- Maximum interpreter work budget: 100,000 counted steps per top-level constant evaluation.
- No file, environment, network, process, thread, device or FFI access is provided.
- Runtime functions, I/O, methods, dynamic allocation, aggregate mutation, arrays, pointers, strings, floating-point values, loops, exception flow and arbitrary runtime side effects are outside the supported body subset. If evaluation reaches an unsupported construct, the compile-time evaluation fails rather than executing it at runtime.
- The interpreter is implemented in the compiler; `consteval` declarations are skipped by runtime code emission.

## Regression coverage in this source snapshot

`tests/comptime/consteval_functions.fac` covers recursive factorial/Fibonacci, nested calls, local scalar variables, branches, module constants, `static_assert`, fixed-array dimensions and const-generic arguments. `tests/comptime/consteval_import.fac` and `ConstevalMath.fac` cover an imported consteval function through an alias and a provider-module constant. Negative fixtures cover runtime-dependent arguments, unsupported methods, non-scalar return types, recursion-budget exhaustion, I/O attempts and violations of import `just` selection. Run them with `sh tests/comptime/run.sh`.

Validation performed for this update: compiler-only build with GCC C++17 `-O0 -g0`; FAC V220 version check; compile-time/const-generic suite 47/47; negative suite 134/134; legacy runtime/compiler cases 132/132 at FAC `-O0` and 132/132 at FAC `-O2`. These are Linux host results, not cross-platform qualification. The full semantic wrapper was not run to completion, so no full semantic-suite pass is claimed.

## Not implemented

This feature does not provide arbitrary compile-time execution, loops, unrestricted user code, compile-time memory/heap facilities, general typed constant values, generic `consteval` functions, consteval methods, overload resolution, typed AST/declaration builders, reflection, macro expansion, source maps for generated declarations, or a host execution API. Those require separate language and safety contracts.
