# FAC portability and performance policy (V165)

## Goal
FAC aims for source portability, not a JVM-style universal binary. A project should keep the same `.fac` source where the chosen OS/architecture has a working FAC backend, runtime build, and the libraries it uses. Platform-specific code should be isolated behind small modules/adapters.

## What is portable today
- The compiler emits LLVM IR and then uses Clang to generate native code. Normal integer/floating-point logic, loops, FAC collections, and most runtime calls are not written against one CPU ISA.
- `-O2` is the default optimization level. `-O3` can improve compute-heavy work but may increase code size or be slower for some workloads; benchmark actual applications.
- LLVM can auto-vectorize suitable loops. It is not guaranteed: aliasing, side effects, loop shape, alignment knowledge, optimization level and target features all affect vectorization. `align(N)` provides an alignment promise for the declared storage only. V165 prepares the software-reference float64 add/scale operations as aligned contiguous blocks on little-endian IEEE-754 hosts; x86-64 and AArch64 use two-lane 128-bit compiler vector operations, other architectures use the scalar block kernel, and big-endian/non-IEEE hosts keep the byte-wise fallback.
- `--cpu` and `--features` are optional target-specific tuning controls. `--cpu native` or enabling optional features can prevent the resulting binary from running on older/different CPUs.

## Build for a different target
First build `facc` for the host (ordinary `make`). Build the runtime archive for the target with the same target triple and sysroot, for example:

```sh
make clean
make CXX=clang++ CXXFLAGS='-std=c++17 -O2' \
  RT_CXXFLAGS='--target=aarch64-unknown-linux-gnu --sysroot=/opt/aarch64-sysroot'
```

Then invoke the host compiler with a target-built runtime archive:

```sh
FAC_RT=build/libfacrt.a FAC_CC=clang++ \
  build/facc app.fac -O2 --target aarch64-unknown-linux-gnu \
  --sysroot /opt/aarch64-sysroot -o app-aarch64
```

This example assumes the selected Clang installation has a working target toolchain and the sysroot contains matching C/C++ libraries. Depending on the target, you may also need a cross linker, C++ standard library, pthread implementation, SDL2/system libraries, and a target-specific `FAC_RT`. `--target` alone cannot transform a host-built `libfacrt.a` into a target library.

## 64-bit limitation
The current compiler/runtime contains 64-bit pointer-size assumptions (for example, opaque pointers and pointer-bearing values are laid out as 8 bytes). Treat V16 as a 64-bit language implementation. 32-bit targets, wasm32, and 16-bit microcontrollers are not supported claims. The driver allowlist currently includes x86_64/amd64, aarch64/arm64, riscv64, ppc64/ppc64le, powerpc64 variants, s390x, and loongarch64. Being on this allowlist only passes the pointer-width guard; it does not mean every OS/ABI/toolchain combination is validated. x86_64 Linux is locally exercised; other target triples need separate CI and runtime validation.

## OS abstraction
For portable code, prefer FAC standard APIs (`file`, `net`, `thread`, `time`, math/string/collections) over direct OS calls. Keep OS calls in platform-specific modules and expose one stable FAC-facing interface. FFI is intentionally an escape hatch; every `extern`, C struct layout, and native library dependency can reduce portability.

## Hardware access
- A native user process normally reaches devices through OS APIs/drivers. `volatile` is for access semantics after a valid mapping is supplied; it does not map physical memory or bypass OS permissions.
- Do not treat `volatile` as an atomic operation or a memory barrier between threads. Use the atomic APIs or locks for synchronization.
- V170 and later are CPU-only for float64 numeric buffers: SIMD is used where supported and a portable scalar fallback is retained. Native OpenCL/GPU device loading, discovery and dispatch are not compiled into the current Runtime. No device runtime or driver is required.

## Performance build profiles

```sh
# Portable baseline (use the same runtime archive built for this target)
facc app.fac -O2 --target x86_64-unknown-linux-gnu --cpu generic -o app

# Tune for the build machine only; do not distribute to unknown CPUs
facc app.fac -O3 --cpu native -o app-native

# ThinLTO; requires a Clang toolchain with LLD available
facc app.fac -O3 --lto -o app-lto
```

`-O2` remains the default. `-O3` and LTO are not universally faster; compare representative workloads and include startup time, code size, runtime checks, and memory use. The `--lto` driver option currently selects ThinLTO with LLD; the selected toolchain must provide an LLD linker that supports the target OS/ABI.


## V45 platform/ABI contract

The supported standards and the distinction between cross-platform and native APIs are now recorded in [`PLATFORM_STANDARDS.md`](PLATFORM_STANDARDS.md) and [`API_LAYERS.md`](API_LAYERS.md). The machine-readable inventory is `api/standards.json`; validate it with `make standards-check`. These documents deliberately distinguish target allowlists from tested support. The existing 64-bit limitation and runtime archive/sysroot matching requirements remain in force.

## V165 cross-platform CI coverage

The CMake CI matrix is configured for Linux x86-64 (GCC and Clang), Linux ARM64 (GCC on `ubuntu-24.04-arm`), and macOS ARM64 (Apple Clang on `macos-15`). Windows x64 remains covered by the existing Windows build/test job. These are CI smoke lanes, not a blanket support claim; check the actual workflow run and retain the full platform conformance gates in `PLATFORM_STANDARDS.md` before changing a target to supported.
