# FAC class / object syntax (V20)

This note describes the class/object syntax and access rules implemented in V20. It documents the supported subset, not a claim of full C++/Java feature parity.

## Declare a class

```fac
class Dog {
    public var int age
    public dyn string name

    constructor Dog(int years, dyn string n) {
        this.age = years
        this.name = n
    }

    public function void bark() {
        terminal.out.println(this.name, " says woof")
    }

    public static function int legs() {
        return 4
    }

    protected function int protectedCode() {
        return this.age + 50
    }

    private function int secretCode() {
        return this.age + 100
    }
}
```

`this.member` refers to the current instance; `this` is translated to the method receiver internally. Constructors use `constructor ClassName(params)` and the constructor name must match the class name.

Class fields are **private by default**. Methods and constructors default to public. Use `public`, `private`, or `protected` on class fields/methods/constructors. A private member is accessible only inside its declaring class; protected members are accessible inside that class and its subclasses. Access is checked at compile time. Struct fields and methods remain public by default, but can be marked private/public; protected is class-only.

## Create an object

```fac
obj Dog d = new Dog(2, "Bob")
d.bark()
terminal.out.println(Dog.legs())
```

`obj` is a reference type. Assigning one `obj` variable to another makes both variables refer to the same object; the runtime uses reference counting. If a class does not declare a constructor, use `new Name` (the implementation also accepts empty parentheses). Class constructor calls are not written as `Dog(...)` without `new`.

Objects may be fields of other classes, passed to and returned from functions, and stored in variables typed as a base class where that base class is an ancestor.

## Inheritance

```fac
class Animal {
    public var int age
    public function int getAge() { return this.age }
}

class Dog extends Animal {
    public dyn string name
    constructor Dog(int years, dyn string n) {
        this.age = years
        this.name = n
    }
}

obj Dog d = new Dog(2, "Bob")
obj Animal a = d
terminal.out.println(a.getAge())
```

Inheritance copies the base layout and lets derived classes use inherited fields and methods. Public/protected parent members remain accessible according to their access modifier; private parent members are not accessible from a child. A parent constructor with no parameters is called automatically. To forward arguments, call `super(args)` as the first statement in the child constructor; it invokes the parent constructor on the same object. A constructor may call `super(...)` only once. Virtual dispatch is supported; see [`OOP.md`](OOP.md).

## Access modifiers on types

Top-level types are public by default for backwards compatibility. Use an explicit modifier to hide an implementation type inside its source module:

```fac
public class User { ... }
private class UserCache { ... }
public struct Point { public var int x; public var int y }
private struct CacheEntry { var int key }
public enum Color { Red, Green, Blue }
private enum InternalState { Ready, Busy }
```

`public`/`private` work on `class`, `abstract class`, `interface`, `struct`, and `enum`. The same rule applies when another module imports a type: private types cannot be named, constructed, or used as a field/parameter/return type from outside their module.

`import Module.fac just TypeA, TypeB` and `import Module.fac without TypeC` also filter types. Import aliases work for types as well as functions.

## Additional class modifiers

```fac
final class FixedValue { }
class Base {
    protected var int state
    protected function int readState() { return this.state }
    public final function int id() { return 1 }
}
class Child extends Base {
    public function int read() { return this.readState() }
}
```

`protected` allows access from the declaring class and subclasses. `final class` cannot be extended; `final function` cannot be overridden. Constructors may be `public`, `private`, or `protected`, with visibility checked both for `new` and `super(...)`.

## Import classes, structs and enums

If `Dog.fac` declares `class Dog`, then another module can write:

```fac
import Dog.fac

obj Dog.Dog d = new Dog.Dog(2, "Bob")
obj Dog second = new Dog(3, "Rex")
```

The qualified form is `Module.Type`. User-defined class/struct/enum names must currently be unique across all loaded modules. Imported classes may be used as base classes when their module/type is imported and public. Dotted directories / arbitrary nested package names are not fully supported yet.

Imported `struct` and `enum` types use the same qualified form:

```fac
struct Dog.Point p = Dog.Point(4, 5)
enum Dog.Mood m = Dog.Mood.Happy
```

## Current limitations

- `static function` and `static` fields are supported. Static fields currently support scalar, enum and pointer types; managed types such as string/list/object are intentionally rejected until module shutdown ownership is defined.
- Interface methods without a body are abstract contracts; methods with a body are default methods. Conflicting defaults from multiple interfaces require an explicit class override.
- Generic methods use `auto` or explicit `function<T> Return method(T value)` parameters and specialize per call. Generic classes, interfaces and structs use compile-time monomorphization; generic arguments are explicit unless a declared trailing default supplies an omitted parameter; one compile-time bound per type parameter is supported. Generic enums and generic virtual/override methods remain unsupported.
- `destructor ClassName()` runs when the final object reference is released (derived before base, then managed fields). Keep it non-throwing; explicit `throw` is rejected. `memory.collectCycles()` can additionally reclaim unreachable cycles formed by direct object fields and nested by-value struct fields; see [`OOP.md`](OOP.md) for the explicit collection safety contract.
- Names for records/classes must be unique across loaded modules in this version.
- Constructor failure cleanup is integrated with the cleanup stack. The temporary-`Error` leak previously found by LeakSanitizer was fixed in R12; object constructor failure and repeated object replacement have dedicated sanitizer regressions in R13.

Build and regression tests:

```sh
make clean && make CXX=clang++
tests/run.sh -O0
tests/run.sh -O2
tests/run_neg.sh
make clean && make CXX=g++
tests/run.sh -O0
tests/run.sh -O2
tests/run_neg.sh
```

## Parent constructor forwarding (R15)

```fac
class Base {
    public var int id
    constructor Base(int n) { this.id = n }
}
class Child extends Base {
    constructor Child(int n) {
        super(n) // must be the first statement
    }
}
```

The compiler checks that an explicit `super(...)` is the first statement and occurs only once. Without it, the parent constructor is called automatically only when it accepts zero arguments.

## `override` contract (R14)

A method may be marked with `override` to require a same-named method in its parent class:

```fac
class Animal {
    public function int sound() { return 1 }
}
class Dog extends Animal {
    public override function int sound() { return 2 }
}
```

The compiler rejects `override` when there is no parent method or when the parent/child declarations disagree about `static` versus instance method. Since V16 `override` also takes part in virtual dispatch: a call through a base-class (or interface) typed variable runs the implementation of the object's real class, and `super.method()` calls the parent's implementation. A method implementing an interface method may also be marked `override`. Details: [`OOP.md`](OOP.md).


## Generic methods and destructors

- Instance and static class methods may use `auto` in a parameter or return type, or declare explicit method parameters such as `function<T> T identity(T value)` and call `box.identity<int>(42)`. Explicit generic methods also work inside generic classes. V46 adds method-level constraints such as `function<T: IReadable & ISerializable> int score(T value)`; generic interface methods and virtual/override generic dispatch are not supported.
- Generic classes, interfaces and structs use `<T>` and compile-time specialization. Constraints support one or more bounds per parameter, joined by `&` (`T: IReadable & ISerializable`); every bound must be satisfied. Supported bounds include interfaces, base classes, struct names and `numeric`, `integral`, `reference`, `value`. Type arguments must be explicit; generic enums, payload variants, variance and runtime generic reflection are not implemented.
- `destructor ClassName()` is called automatically when the last strong object reference is released. Derived destructors run before base destructors, followed by managed-field release. Destructors should not throw; explicit `throw` is rejected.
- Weak references use `weak obj ClassName name = memory.weak(obj)`, `memory.weakAlive(name)`, and `memory.weakLock(name)`. The compiler manages weak-control-block ownership across copies and fields; weak edges do not keep objects alive or count as cycle-collector edges.
- Cycle collection is explicit via `memory.collectCycles()` and only traces strong object fields plus nested by-value struct fields. Local variables, object lists and closure-held references are conservative roots; cycles involving untraced containers may remain. Call only when no other thread reads or mutates the object graph. Foreign raw pointers are not automatically retained or registered.


## Java-style class entry point (V49)

The compiler can launch an application through a directly declared `public static function void main()` or `public static function void main(list dyn string args)` method on a public class in the input module. `args` receives command-line arguments excluding the executable name. The original top-level `public function void main()` remains compatible; define only one entry form. See [`JAVA_STYLE_ENTRY.md`](JAVA_STYLE_ENTRY.md).
