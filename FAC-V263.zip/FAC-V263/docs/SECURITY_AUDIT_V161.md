# FAC V161 Runtime Audit — atomic weak-handle slots

## Scope

This change optimizes the Runtime weak-reference paths while preserving the public C function signatures and pointer-sized opaque token format. It does not redesign strong object-pointer validation or the `setjmp`/`longjmp` FAC error model.

## Slot representation and invariants

- A token still encodes a one-based slot index and a nonzero generation. The 64-bit layout remains 23 slot bits / 24 generation bits; the 32-bit layout remains 12 slot bits / 19 generation bits. Tokens are never dereferenced.
- The slot directory is a fixed atomic directory of lazily allocated blocks. A published block and each slot cell remain at a stable address for process lifetime. Slots are reused, but generation increments before reuse; a maximum-generation slot is retired instead of wrapping.
- Each slot state is one atomic 64-bit word: 39 bits of external-handle count, one object-anchor bit, and the generation in the high 24 bits. Retain/release compare-and-exchange the generation and count together, so a stale token cannot change a new generation after slot reuse.
- The object pointer is a separate atomic field. The object lifecycle mutex serializes weak creation, anchor detach, registry checks, and weak-to-strong promotion. `weak_alive`, `weak_retain`, and `weak_release` do not need that global mutex on their normal path; the last release of an already-expired slot takes it briefly to update the free list.
- Weak-slot blocks remain allocated until process exit. Allocation is lazy and block-based; this is the memory high-water trade-off for stable lock-free readers. The external-handle count is capped at `2^39-1`.

## Safety properties retained

- Invalid token bit patterns and unallocated slots are rejected before object access.
- Generation mismatch rejects stale tokens after reuse. Generation never wraps.
- Atomic state transitions prevent old-generation retain/release operations from affecting a newly allocated control slot.
- `weak_lock` still checks the managed-object registry while holding the lifecycle mutex and increments the strong count before returning; object destruction cannot race that promotion.
- The public managed-object header remains 64 bytes and the weak API C signatures are unchanged. Native code must treat weak values as opaque handles and must not dereference or do pointer arithmetic on them.

## Validation completed

- `CXX=clang++ sh tests/runtime/run.sh`: passed on Linux x86-64 with Clang 17; all Runtime regression cases completed, including object-registry ABA, 5,000-slot multi-block reuse, concurrent weak-lock/release, HashMap/Graph tests, OOM rollback, thread pool, network, UTF-8 and compiler-driver checks.
- Focused GCC 14.2 ASan/UBSan/LSan tests: `weak_refs`, `object_registry_safety`, and `refcount_concurrency` passed.
- Focused GCC 14.2 ThreadSanitizer tests: `weak_refs`, `object_registry_safety`, and `refcount_concurrency` passed.
- Paired benchmark: V159 → V161 `weak_alive` 10.46 → 2.26 ns/op; weak retain+release pair 19.00 → 8.33 ns/pair. See `docs/PERFORMANCE.md` for flags, run count and limitations.

## Not claimed

This is Linux x86-64 validation only. Windows, macOS and 32-bit builds/runs were not performed. The microbenchmark is single-threaded and does not establish a whole-application speedup. Stable slot blocks are retained until process exit, so memory usage follows the process high-water mark of slot indices.
