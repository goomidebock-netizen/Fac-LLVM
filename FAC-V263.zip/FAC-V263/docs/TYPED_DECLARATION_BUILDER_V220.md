# FAC V220 — Internal Typed Declaration Builder

## 1. Scope

V220 adds a compiler-internal C++ API, `fac_hir::TypedDeclarationBuilder`, for staging and registering generated declarations in `SemanticModel`. The first supported declarations are non-generic `struct` records and non-generic free functions. The builder consumes already-resolved HIR `TypeId` values; it does not parse FAC source, execute from `consteval` or rewrite parser-owned AST. The V220 Codegen bridge lowers a bounded subset of these generated declarations through temporary backend projection; see [`GENERATED_DECLARATION_CODEGEN_V220.md`](GENERATED_DECLARATION_CODEGEN_V220.md).

Generated records are marked `DeclarationOrigin::Generated` and have no parser-owned `sourceNode`. They receive deterministic `SymbolId` values in append order, are inserted into the owning module's declaration list and `symbolsByQualifiedName`, and are checked by the ordinary `SemanticModel::validate()` routine. Generated struct types are interned as named `struct` TypeIds and returned to the caller so later generated declarations in the same module can use them.

## 2. Supported operations

```cpp
fac_hir::TypedDeclarationBuilder builder(model); // model must already validate

fac_hir::GeneratedFieldSpec id;
id.name = "id";
id.type = intType;
id.visibility = fac_hir::GeneratedVisibility::Public;

const auto record = builder.addStruct(
    "app", "Record", {id}, fac_hir::GeneratedVisibility::Public,
    {"generated.fac", "app", 10});

fac_hir::GeneratedParameterSpec value;
value.name = "record";
value.type = record.declaredType;
const auto function = builder.addFunction(
    "app", "consume", intType, {value},
    fac_hir::GeneratedVisibility::Public,
    {"generated.fac", "app", 20});

if (!model.validate())
  throw std::logic_error("generated declarations failed HIR validation");
```

| API | Result | Contract |
|---|---|---|
| `addStruct(module, name, fields, visibility, location)` | `DeclarationBuildResult{symbol, declaredType}` | Creates a non-generic `SymbolKind::Struct` and its named TypeId |
| `addFunction(module, name, returnType, parameters, visibility, location)` | `DeclarationBuildResult{symbol, kInvalidType}` | Creates a non-generic free-function declaration |

Fields carry a name, already-resolved TypeId, visibility, static/const flags and optional source provenance. Parameters carry a name, TypeId, reference, immutable-reference, variadic, noescape and readonly flags. The builder supports private/protected/public visibility metadata.

## 3. Validation and registration

Before registration the builder checks:

- the target module already exists in the semantic model;
- declaration, field and parameter names are valid ASCII identifiers;
- a struct name and its field names do not collide;
- function parameter names are unique and a variadic parameter is last;
- TypeIds exist and do not denote unresolved/unknown types;
- fields and parameters do not have `void` type;
- immutable-reference and noescape parameter flags require `ref`;
- direct named field/parameter/return types are declared in the same module;
- an existing function with the same parameter TypeIds and reference/variadic shape is not duplicated.

Registration updates `declarations`, the matching `Module::declarations` list and `symbolsByQualifiedName` as one rollback-capable operation. The builder requires the semantic model to remain valid before each operation, validates the complete model after each commit and removes declaration/module/index entries if validation fails. TypeIds are interned monotonically by `TypeArena` and are not recycled; a type interned during a failed post-registration validation remains as an unused canonical TypeId.

## 4. Important boundaries

This is an internal HIR declaration registry, not source-level metaprogramming. Builder-level features that remain outside its contract include:

- create `class`, interface, enum, global, method, generic or nested declarations;
- resolve imported/cross-module named types from a bare TypeId;
- perform overload lookup, access checks, generic substitution, default arguments or implicit conversions;
- create parser `Node` objects or update source `Program` ownership;
- expose declaration creation to FAC source or `consteval`;
- provide a persistent generated-source map beyond the supplied `SourceLocation`;
- implement macros, arbitrary compile-time execution or a source-level AST API.

The original source AST remains authoritative and is not mutated. The bounded backend projection lowers generated structs, body-less external free-function declarations and generated functions with an eligible scalar body with mutable locals, assignments and nested `if/else`. Bodies are created by the separate internal `TypedFunctionBodyBuilder`; see [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md). Neither builder adds source-level declaration syntax or exposes generated declaration/body construction to FAC programs or `consteval`.

## 5. Regression coverage

`tests/semantic/typed_decl_builder.cpp` builds a source semantic model, adds a generated struct, uses its TypeId in a generated function parameter, adds a valid overload, and verifies `SemanticModel::validate()` and symbol/module registration. Negative cases cover duplicate declarations/fields/parameters, malformed identifiers, invalid and `void` field types, missing modules and duplicate function signatures.

Validation commands:

```sh
g++ -std=c++17 -O0 -g0 -I. tests/semantic/typed_decl_builder.cpp -o /tmp/fac_typed_decl_builder
/tmp/fac_typed_decl_builder
```

The fixture is also wired into `tests/semantic/run.sh`. Codegen integration is covered separately by `tests/semantic/generated_declaration_codegen.cpp`, which verifies LLVM struct layout, nested generated type references, external function declaration/call emission, source-AST immutability and LLVM IR parsing. Generated scalar function bodies with mutable locals and nested conditional branches are covered by `tests/semantic/generated_function_body.cpp` and [`GENERATED_FUNCTION_BODY_V220.md`](GENERATED_FUNCTION_BODY_V220.md). The broader project validation snapshot is recorded in `docs/STATUS.md`. These are Linux-host results and do not qualify other platforms.
